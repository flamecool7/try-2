# Cropping System Lock

The question-paper and mark-scheme crop/extraction/rendering code is read-only.
Topic classification, JSON metadata, folder routing, and validation must only consume
its output and must not change its behavior.

## Baseline verification

These SHA-256 values were verified against the originally downloaded project archive
`workspace-019fe775-86df-7d2b-ab07-2899f1093d24.zip`. Each current file is byte-for-byte
identical to that baseline.

| Locked file | SHA-256 |
|---|---|
| `core/cropping_engine.py` | `6a7ae3bb65012176cd6095d021e671418d9814986d15a63108367562073a9a01` |
| `core/cropping_engine_reference.py` | `9b88d3effa522e618fd631b44056602cc533aa5f151faef2cdd56999b0ba5c32` |
| `core/ms_cropping_engine.py` | `2f4c7aee5239cc99018a3fca9becaed1ccb5f9dc895e1d1be2463b9bdd006583` |
| `core/ms_crop_gold.py` | `8a55e3dbc790c4850cce44e3b324705a5652741ed8462f4794ebe3fa433641d6` |
| `core/question_split.py` | `2f8721d097f9302c3e13aa2ddda8c5d762e63d2a4195114b7198d1d9eb9f83ee` |
| `core/multipage_optimizer.py` | `17276c801666b72971fdae8aa2844d2e0feb5e2b2a75de5bdc052af01fb584ca` |
| `core/multipage_optimizer_reference.py` | `17276c801666b72971fdae8aa2844d2e0feb5e2b2a75de5bdc052af01fb584ca` |
| `core/mcq_support.py` | `76582bf541d1ef10cf3b5c4168338a66d0ed3feb5be84aaf71221f5a0c942d72` |
| `core/webp_utils.py` | `770e3ba06fb86517250c19ec6cfc620ae70eca8a147f7d559cb767210e1e4994` |
| `core/pdf_io.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` |
| `core/pdf_io_gold.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` |
| `core/markscheme_split_gold.py` | `a3213e2fe574c81b5a4a5c051638173816000c170d8fc80f733daaa251a02087` |

## Immutable behavior

Do not modify crop boundaries, dimensions, padding, page/question detection, QP/MS
cropping, multi-page assembly, image processing, WebP output, or crop quality. The
routing layer may call these components and route their already-generated outputs only.

## Amendment 1 (2026-08-10): Anti top-clipping fix — authorised by the maintainer

The maintainer explicitly ordered a fix for top-clipped question crops
("full question text always preserved; slight extra whitespace acceptable; text
clipping never acceptable; no blind hardcoded pixel padding; proportional or
validation-based adjustments"). The following controlled changes were made to the
QP cropping path only (MS path byte-identical, untouched):

- `question_split.adaptive_crop_page` (all three copies: `core/question_split.py`,
  `core/cropping_engine_reference.py`, `original_reference/cambridge_qb/question_split.py`):
  - REPLACED the blind fixed page-top constants (`QP_SAFE_TOP_PDF = 55.0`, and legacy
    `top_pdf - 5px` in the mirrors) with:
    1. structural header-junk recognition (page number = digits-only, centred,
       >= 9pt, vertically alone in the top band; `* 00008... *` barcode; running-header
       boilerplate) -> `header_floor` + `junk_boxes`;
    2. content-top detection with NO artificial y-floor (text spans + vector drawings),
       so question content starting high on the page is never destroyed;
    3. a proportional margin `0.45 * median body font size`, clamped [3, 16] pt,
       converted through the page's own render scale (adapts to layout and DPI);
    4. a raster validation pass (`_validate_top_against_ink`) that pulls the boundary
       UP over any unexpected non-junk ink (only ever adds whitespace, never clips);
    5. white-out of recognised junk boxes that survive inside the kept region
       (recognition is conservative; real content is never erased — same precedent as
       the existing watermark/imposition scrubbing).
  - `build_question_segments`: shared-page fallback split and prior-question `y0` now
    use this per-page proportional guard (`PageCropInfo.top_guard_px`) instead of the
    tight fixed 5 px.
- `multipage_optimizer.find_content_bbox` (all three copies): validation-based top
  extension absorbs faint anti-aliased rows just above the detected content top,
  bounded to one padding band (24 px). Purely additive.
- `core/cropping_engine.py`: docstring/comment updates only (no behavior change).
- Locked-output guarantees retained: final width EXACTLY 2280 px (LANCZOS, aspect
  preserved), bottom/left/right crop logic unchanged, marker detection unchanged,
  whitespace-cut algorithm unchanged, WebP output unchanged, MS cropping untouched.

Verified on the regression pack in `test-crops/fix-repro/` (7709/9709 real pages +
adversarial synthetic with content above the old 55pt cliff): zero clipping,
page numbers still excluded, outputs remain 2280-px-wide `.webp`.

### Updated baseline SHA-256

| Locked file | SHA-256 |
|---|---|
| `core/cropping_engine.py` | `01576fde63cfb005e7c71672842b1453392a5f51e7dc7dc846fa385e2c16b2a0` |
| `core/cropping_engine_reference.py` | `17e8917c759d100c498a8c5b191808d6ef61c3e8009330794af562fb49132924` |
| `core/ms_cropping_engine.py` | `9a1dc1e828f1e45e16686a8f8fcd0aaccd1dc543d68ca93468fe01832610d760` (unchanged by this amendment; already drifted from the original lock baseline before it) |
| `core/ms_crop_gold.py` | `8a55e3dbc790c4850cce44e3b324705a5652741ed8462f4794ebe3fa433641d6` (unchanged) |
| `core/question_split.py` | `17e8917c759d100c498a8c5b191808d6ef61c3e8009330794af562fb49132924` |
| `core/multipage_optimizer.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` |
| `core/multipage_optimizer_reference.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` |
| `core/mcq_support.py` | `76582bf541d1ef10cf3b5c4168338a66d0ed3feb5be84aaf71221f5a0c942d72` (unchanged) |
| `core/webp_utils.py` | `770e3ba06fb86517250c19ec6cfc620ae70eca8a147f7d559cb767210e1e4994` (unchanged) |
| `core/pdf_io.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` (unchanged) |
| `core/pdf_io_gold.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` (unchanged) |
| `core/markscheme_split_gold.py` | `a3213e2fe574c81b5a4a5c051638173816000c170d8fc80f733daaa251a02087` (unchanged) |

Also kept in sync (not locked, same fixed content): `original_reference/cambridge_qb/question_split.py`
(= `core/question_split.py`) and `original_reference/cambridge_qb/multipage_optimizer.py`
(= `core/multipage_optimizer.py`).

## Amendment 2 (2026-08-10): QP top boundary = 20px above detected question line

Maintainer instruction (QP CROPPING TEST - 20px above question + visual feedback loop):
for **every QP crop**, the top boundary begins **exactly 20 pixels above the detected
question line**. Only the QP top-boundary calculation changed.

- `question_split.build_question_segments`: the shared-page/continuation split and the
  per-question start-page top now use `cut / y0 = complete_first_line_top_px - 20`
  (`QUESTION_TOP_GUARD_PX = 20`).
- New `_question_first_line_top_pdf()`: "detected question line" = COMPLETE first line —
  walks upward from the marker through overlapping/adjoining text lines so fraction
  numerators / superscripts rising above the bare question number are preserved
  (e.g. 9709 s22 Q4: marker '4' at 72.19pt, true line top 62.65pt), then the fixed
  20px whitespace band is measured above that complete line top. The previous
  whitespace-band search for shared-page splits was superseded by this fixed rule.
- `adaptive_crop_page`: page-level structural/raster-validated anti-clip machinery
  (Amendment 1) retained; page guard floored at 24px so the 20px band always exists.
- Kept intact: 2280px exact width, horizontal alignment, marker/question detection,
  bottom boundary (mirror of the shared cut), multi-page handling & assembly,
  WebP output, question naming, and all other behavior. Untouched: MS cropping,
  Examiner Report cropping, JSON, folder structure, naming, classification.

Verification protocol (per maintainer): small visual test batch on a Biology paper,
images shown for approval BEFORE any full-paper processing; adjust 20px value only
on feedback.

### Amendment 2 refinements (2026-08-10), via maintainer's visual feedback loop

Maintainer verdict on the first visual batch was **B (adjust)**, then **A (approve)**
on the adjusted batch. The approved final state adds:

- **Junction-junk robustness fixes** (landed while preparing the visual batch):
  horizontal end-cap margin rules classified as junk alongside vertical margin rules;
  the off-page fill drawing `(0,-9.9,21,854.6)` now joins `junk_boxes` (clamped) so the
  raster validation pass masks it (root cause of a `top=0` clamp); junk paint pad
  raised to `max(4, round(2.5*scale_y))` to cover stroke spread (fixed "═" ghost lines).
  Detection-regression verified: Bio hf=51.02/ct=64.08/junk=10 per page;
  Math 62.65/86.48 — unchanged.
- **Visible-band anchor `_align_top_white_band_final()`** (applied in
  `crop_page_segments` after assembly, QP path only): because assembly re-trims
  sections to ink+24px and rescales ×2280/w, the render-scale 20px pre-cut drifted to
  ~24px *visible* white. The anchor measures the actual final 2280px image and
  trims/pads the top to exactly **20 rows of visible white above the first ink**
  (removes only rows verified all-white; never clips; pads if ever short). Width,
  bottoms, seams untouched — instrumented proof: everything below the band
  pixel-identical after anchoring.
- Unit tests 9/9 for the anchor; full-paper validation 6/6 questions of
  9700_w25_qp_22: width 2280 exact, band 20px at both ink thresholds (250/2px and
  QC's 246/3px), seam gaps clean, QC OK.

### Amendment 2 SHA-256 (changed files only; final approved state)

| Locked file | SHA-256 |
|---|---|
| `core/question_split.py` | `5c5c7a2bda2f23d74151df86e467e9d2d82b1733dedae73027f6cedf9f847837` |
| `core/cropping_engine_reference.py` | `5c5c7a2bda2f23d74151df86e467e9d2d82b1733dedae73027f6cedf9f847837` |

All other locked hashes from Amendment 1 remain valid (`core/multipage_optimizer.py` =
`c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5`, unchanged).
`original_reference/cambridge_qb/question_split.py` kept byte-identical to
`core/question_split.py`.

## Amendment 3 (2026-08-10): QP-fix audit trio — verified/aligned — authorised by the maintainer

The maintainer supplied the previous audit's QP fix (three parts) as locked. Conflict
mapping against the current locked state:

1. **`converter.py` — 300 DPI render at all times.** ALREADY SATISFIED and locked:
   `render_pdf_local` renders at fixed 2480×3508 geometry (= 300.0 DPI for A4 at
   595.3×841.9pt; `Matrix(scale, scale)` with `scale = max(2480/w, 3508/h)`), never
   below 300 DPI. The "72 DPI default" the audit cites predates this tree. No change.
2. **`question_split.py` — proportional guard + raster top validation.** SATISFIED and
   SUPERSEDED by something stronger: the proportional page-level machinery from
   Amendment 1 (structural header-junk recognition, `0.45 × median font` guard,
   `_validate_top_against_ink`) is retained, and per-question tops were replaced by the
   maintainer-approved fixed **20px visible band** (Amendment 2, verdict B→A: complete
   first line + raster-exact anchor at final 2280px scale). Reverting to the audit's
   literal `clamp(0.45 × median_line_height_px, 18, 60)` formula would regress the
   approved 20px rule, so no rollback is applied.
3. **`core/webp_utils.py` — compression strength.** ALIGNED: `save_webp` defaults raised
   quality 88 → **92**, method 2 → **4** (both save sites; the audit's "80" baseline
   never existed in this tree — it was already 88). Measured on a real assembled
   question (2280×5365, thin numeral glyph): 88/m2 lost thin-stroke ink (99.5% glyph
   retention) and deviated MAE 0.228 from lossless; **92/m4 retains 100.0% glyph ink,
   MAE 0.160**, +12% size, ~2× encode time. Note: the production pipeline's final question
   crops were already written ABOVE the audit target — `core/output_manager.OutputManager`
   (used by `main.py`) saves at quality=95, method=6; `original_reference/cambridge_qb`
   remains archive-pristine (its sibling already had method=4, keeps quality=88).

### Amendment 3 SHA-256 (changed files only)

| Locked file | SHA-256 |
|---|---|
| `core/webp_utils.py` | `4677261fdbdaf879b1b61c484ce0f4b2218b0ef54e584c350361eedd7ba6fa64` |

## Amendment 4 (2026-08-10): Imposition-mark scrub content guards — authorised by the maintainer

Root cause of the "MS label erasure" defect: `_scrub_imposition_marks` in
`core/webp_utils.py` (NOT the MS engine margins, which are gold/locked) was erasing
real markscheme ink — its barcode/comb heuristics matched table digits and label
columns on 9700 m25/w25 MS rasters.

Guards added:

1. **`_band_is_barcode`** — a candidate vertical band must pass all three tests
   before erasure: full-height dark-column coverage ≥ 60%, inter-bar gap CV ≤ 0.25,
   and ±8px white isolation on both sides.
2. **P2 restricted to comb-group erasure** — only groups of ≥ 8 tall periodic bars
   are erased; isolated specks and digit-like marks are kept by design (better a
   speck survives than a mark point is erased).

Evidence (ink wrongly targeted, real papers): m25@75dpi 16,657 → 0, w25@75dpi
24,246 → 0, m25@150dpi 39,230 → 0 dark pixels. Synthetic comb strips are still
erased (no regression). Suite: `test-crops/scrub-fix/test_scrub_guard.py` 9/9,
evidence pack `test-crops/scrub-fix/MS_scrubguard_dpi150_evidence_pack.html`.

### Amendment 4 SHA-256 (changed files only)

| Locked file | SHA-256 |
|---|---|
| `core/webp_utils.py` | `f865edff4e642a0b5ce983708f75ad8e38f7c2a03a0784f59742414ce258d723` |

## Amendment 5 (2026-08-10): QP frame side trim 45pt → 35pt (side air) — authorised by the maintainer

Maintainer directive "2 QP Crop Fixes", Fix 1 (≈ +40px whitespace per side). The
audit premise was fact-checked and found fabricated: there is NO `LEFT_MARGIN_PX` /
`RIGHT_MARGIN_PX` / `PAGE_WIDTH_PX` / `HEADER_ZONE_PX` / `FOOTER_ZONE_PX` /
`build_question_crop()` / `stitch_strips()` / `enforce_2280_width()` anywhere in
this codebase, and `CONTENT_PADDING_LR` in the multipage pair is a clamp CEILING
only (byte-identical output at 100 vs 140 — proven no-op for this path). The real
side-air knob is the page-frame trim in `adaptive_crop_page` (triplet).

Change (triplet only):

1. New constant **`PAGE_SIDE_TRIM_PT = 35.0`** in `core/question_split.py`
   (previously inline 45.0), used for both page sides; explanatory comment warns
   future auditors off the nonexistent constants.
2. **Sliver-paint**: the newly-kept [35pt, 45pt] band per side is whitened after the
   frame crop. On real 9700 m25 pages this band contains ONLY the printer's corner
   registration marks (identical every page, both sides); question ink starts
   ≥ ~50pt, so no content is touched. Verified: final outer 40px contain 0 dark
   pixels on 12/12 crops (m25 + w25).

Fix 2 (continuation-banner stripper) was SKIPPED as a verified no-op: Cambridge
structured QPs print no "Question N continues…" banners; `find_question_bottom_pdf`
already excludes footer furniture (© / Turn over / DO NOT WRITE, bbox < 94% page
height); the proposed banner regexes were a clip-risk on real question text.

Evidence: air +41/+42px per side on 12/12 crops (m25 v3 + w25); locked 20px top
band (engine metric) 12/12; width exactly 2280 12/12; ink-mass ratio inside the
geometric window [s²·0.995, s·1.005], s = 505/525 (content drawn 4% smaller in the
wider window; nothing clipped by construction); suites `test-crops/pad140/
test_pad140.py` 36/36 and `test-crops/pad140/w25_spot.py` 31/31; full regression
battery green (ER 56, extractor 32, classifier 21, routing 17, anchor 9, scrub 9,
boundary-shadow 8/8); m25 full-pipeline v3 run: validator 0 issues / 55 files.
Packs: `test-crops/pad140/AMENDMENT5_side_air_evidence_pack.html`,
`test-crops/m25-proof-v3/M25_V3_TEST_RUN_pack.html`.

### Amendment 5 SHA-256

| Locked file | SHA-256 |
|---|---|
| `core/question_split.py` | `00cc779ed631bdfc44c7ec537c7e5c7d255479d15f011680fdc1eda1d78b87c1` |
| `core/cropping_engine_reference.py` | `00cc779ed631bdfc44c7ec537c7e5c7d255479d15f011680fdc1eda1d78b87c1` (byte-identical triplet) |
| `original_reference/cambridge_qb/question_split.py` | `00cc779ed631bdfc44c7ec537c7e5c7d255479d15f011680fdc1eda1d78b87c1` (byte-identical triplet) |
| `core/multipage_optimizer.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` (unchanged) |
| `core/multipage_optimizer_reference.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` (unchanged) |


## Findings note (2026-08-10, no code change — documentation only)

**Upgrade 3 (reference-detector question-signal veto) — verified already
satisfied.** `core/chemistry_reference.py::classify_page` runs the question
structure veto BEFORE every reference detector; the only earlier exits are the
structural blank/candidate-info checks, and moving the veto above them is
PROVABLY harmful (real cover pages trip the veto via boilerplate: "1 hour 15
minutes" leading-number + "show" command word — A/B evidence on 9700 m25/w25
QPs in `test-crops/refdet-upgrade3/`; file restored byte-pristine, sha
`193820b9…` == packaged copy). Do not re-attempt that reorder.

## Amendment 6 (2026-08-10) — QP page-render scratch ownership + tempdir leak fix (Efficiency U2)

The locked triplet (`question_split.py:1230`) renders pages into
`tempfile.mkdtemp("qp_pages_*")` and never deletes it (no `rmtree` in file) —
an orphan tempdir of page webps per QP paper, forever (reproduced on a real
9700 m25 slice: 6 webps / 1517 KB per run). The triplet stays byte-untouched;
the caller now owns the scratch dir.

Change (behavior-neutral): `core/cropping_engine.py` passes an owned
`webp_dir` (RAM-backed `/dev/shm` when writable, system temp otherwise;
"ramdisk=yes/no" logged) to `split_questions(..., webp_dir=...)` and removes
it in a `finally`. Crops byte-identical pre/post (sha `a6a284304c876acb` on
the test slice; zero leaked dirs after). DPI, webp quality/method, all crop
logic untouched.

| File | sha256 |
|---|---|
| `core/cropping_engine.py` | `c0344ddb3bb01841c8c7b5a4cbb222431b981710d1f203181fba45b4bd38c2dc` (was `01576fde…`) |

## Amendment 7 (2026-08-11): Confidence-gate defect fixes (Overseer spec) — authorised by the maintainer

Approved decisions: wrap architecture (locked gold stays the production cropper;
new packages orchestrate around it), fix-bundle yes, year policy = loud flag.

1. **core/cropping_engine.py** — defect 5 (dummy fabrication) eliminated:
   `HAS_FITZ` false, gold-import failure and gold exception paths no longer
   fabricate `Question {i} dummy text` crops; they return zero crops with
   `self.last_error` set and a loud ❌ line. `_dummy_process` /
   `_fallback_process` deleted outright. Defect 4: gold QC verdicts are no
   longer dropped at the adapter — `CroppedQuestion` gains `needs_review` +
   `qc_reasons` (from the gold `Question`), and the engine exposes
   `last_confident` (+ low-confidence ⚠️ print). Defect 3 comments corrected
   to the audited truth (gold `crop_page_segments` stitches ALL segments; the
   adapter receives one fully-stitched image — approved artifact proof:
   2280x12422 4-page Q1) plus a defensive locked-`assemble_multipage_question`
   branch if a future gold ever returns >1 segment.
2. **core/ms_cropping_engine.py** — FIRST amendment of this engine. The
   "using dummy" log line lied (the engine always returned `[]`); print made
   honest + loud ❌; dead (never-called) `_dummy_process` fabrication code
   deleted. Its exceptions were and are fail-closed (traceback + `[]`).

Bounds honoured: question_split triplet `00cc779e…` ×3, multipage pair
`c384248b…`, converter `d8bf74d8…`, webp_utils `f865edff…`, all gold modules —
byte-untouched. No crop-geometry, DPI, quality or naming change.

Evidence: grep DUMMY-FREE across engines+runners; unit suite 14/14
(`tests/test_confidence_gate_fixes.py`: fail-closed on gold-unavailable /
fitz-unavailable / forced-gold-exception; QC propagation; honest prints);
real-paper guarded run (9700 m25+w25+er, --low-ram): 8 stages ALL GREEN,
both papers state=complete; 33/33 surviving RS-2 baseline webps
byte-identical; m25 Q1/Q2/Q4 folders (absent from the eroded reference tree)
restored and dims match the in-run assembly ledger exactly
(Q1 2280x11526, Q2 2280x8425, Q4 2280x11503). Log:
test-crops/redesign/defectfix_run.log.

| File | sha256 |
|---|---|
| `core/cropping_engine.py` | `b58110d3fc32666605274492b59e8ac9c928e9613c849f7e08dfe875f457aded` (was `c0344ddb…`) |
| `core/ms_cropping_engine.py` | `e87043e9eab533da004ad05cf12b7fefbb768bd82e76d7d6fded6fdf6205bc9a` (was `9a1dc1e8…`; first amendment) |
## Amendment 8 (2026-08-11): IGCSE paper-format round — MCQ answer-grid extraction + detection fast-path — authorised by the maintainer

Overseer IGCSE-format spec; approved decision set: prod_homes / rename /
advisory counts / letters. Spec-premise receipts recorded in
`test-crops/redesign/IGCSE_FORMATS_ROUND_EVIDENCE.md` (spec's `markscheme.py` /
`mcq_detector.py` filenames do not exist — real homes: locked
`markscheme_gold.py` / this module).

1. **core/ms_cropping_engine.py** — SECOND amendment of this engine: gains
   `extract_mcq_answers(pdf_path)`, a THIN ADAPTER delegating parsing to the
   LOCKED gold `core/markscheme_gold._parse_mcq_answers` over
   `core/pdf_io.render_pdf_with_rotation_info` — exactly the call pattern gold
   `process_mark_schemes()` itself uses for MCQ papers. No new parsing logic.
   Fail-closed: gold engine unavailable / exception → empty dict + loud ❌.
   No crop geometry, boundary, DPI, quality or naming change anywhere; the
   structured MS path is byte-identical in behavior.
2. **core/mcq_support.py** — gains `MCQPaperInfo` + `detect_mcq()`:
   `paper_meta` fast-path (`confirmed_by=["paper_meta_profile"]`), identifier
   profile fallback, unresolved identity fail-closed (not-MCQ). All prior
   detectors untouched.

Evidence: real grids 0620_s16_ms_21/22 and 9701_s15_ms_12 parse exactly 40
letters each; MCQ end-to-end 0620_s16 P22 (`--low-ram`): worker 348 checks +
full run 21 checks ALL GREEN, S8 audit errors=0; A-Level regression 9700_m25
P22: 6/6 overlapping webps byte-identical to the RS-2 baseline manifest;
suite 24/24 (`tests/test_igcse_formats.py` new: 10 tests, incl. the spec's
exact 17/17 truth table). Bounds honoured: triplet `00cc779e…` ×3, multipage
pair `c384248b…`, all gold modules byte-untouched.

| File | sha256 |
|---|---|
| `core/ms_cropping_engine.py` | `b69285eee913829874d5138ab933cb7ac534e340a01fcb0f312d045b2317125c` (was `e87043e9…`) |
| `core/mcq_support.py` | `d35afbc13b7213c922e2ebf48276c902acf17de24d391e8caa50ddf118cd5e9e` (was `76582bf5…`) |
## CROPPING-NOTE (2026-08-11) — RS-12 import-block-only amendment — authorised by the maintainer

`core/cropping_engine.py` was amended by the RS-12 page-classifier round in
its IMPORT BLOCK ONLY (sys.modules pre-seed binding the gold package's page
classifier to the maintained core copy). **No crop mathematics, no boundary
logic, no render DPI, no webp settings were touched**; the question_split
triplet `00cc779e…` remains the sole crop authority and is byte-untouched.
The amended file's hash is recorded in ROUTING_STATE_LOCK RS-12 (this note
carries no hash rows by design).
