# Routing & Pipeline State Lock

This lock covers the output-routing, JSON-generation and pipeline-state layer of
the generator, plus `main.py` wiring. The cropping engines and examiner-report
subsystem are covered by `CROPPING_LOCK.md` and `EXAMINER_REPORT_LOCK.md`; topic
classification by `CLASSIFICATION_LOCK.md`. The locked MS engine and gold files
remain byte-untouched.

## Baseline decisions recorded (2026-08-10, all authorised by the maintainer)

1. **G3 — grouped topics adopted**: a question may carry up to 4 grouped topic
   entries in `metadata.json` (`topic` array); placeholder topics rejected;
   bare-"D"-style low-signal assignments rejected.
2. **G4 — relative weights kept**: classifier relative weighting left as-is
   (no renormalisation).
3. **G7 — ER presence warning**: warning emitted only when an ER PDF was actually
   supplied; math papers matching `paper-\d+` keep their pruning exception.
4. **G8 — pipeline state integrated**: `core/pipeline_state.py` is the single
   checkpoint/resume store used by `main.py`.
5. **MS render resolution**: `main.py` constructs the (locked) MS engine at
   **150 dpi** (was 75); the QP engine line is untouched. Measured with Amendment
   4 scrub guards: zero content erasure at 150 dpi on real 9700 MS rasters.
6. **ER question crops wiring**: after `attach_examiner_reports_to_output`,
   `main.py` calls `core.er_question_crops.attach_question_er_crops` inside
   try/except — ER-crop failure is never fatal to a run.
7. **Boundary detector**: `core/boundary_detector.py` runs in **shadow mode**
   (question-signal veto first; never imports reference data; 8/8 matched on the
   shadow suite, zero extras) and does not alter output.

Evidence: `test-crops/audit-fixes/test_routing_fixes.py` 17/17,
`test-crops/bnd-shadow/run_shadow.py` 8/8 matched, extractor suite 32/32,
full regression battery green after every amendment wave (m25 v3 full pipeline:
validator 0 issues / 55 files).

## Rules

- No routing/state/json change may alter the folder taxonomy, the question-pair
  file naming, or the metadata schema guarded by `CLASSIFICATION_LOCK.md`.
- Any change to a file below requires a recorded amendment with evidence.

## Baseline SHA-256 (2026-08-10)

| File | SHA-256 |
|---|---|
| `core/json_generator.py` | `4b905aec3433a6d5f8fc3f02e03e15d9690af07451bcca70b4b9d11c7f5d241a` |
| `core/output_manager.py` | `3aa13d813d8cf503cefaa859cec07f691e6d4e46fb4b0f161e9011d964563936` |
| `core/pipeline_state.py` | `73832bed29e1e4daa32c5a0c35950f880df998d03fbd79912668aeea2487942f` |
| `core/boundary_detector.py` | `841ec231b1684d89b1bb218f620defe1fd6826613bbfea7c6d7a8b0e3c1facdb` |
| `main.py` | `5f1b06072c2f8a984cc346b0371e1f1e1fa3911e3b6d0b9e704ff943e9899731` |

Unchanged reference points (locked elsewhere, recorded for cross-checking):
`core/ms_cropping_engine.py` `9a1dc1e8…`, `core/ms_crop_gold.py` `8a55e3db…`,
`core/markscheme_split_gold.py` `a3213e2f…`, `core/markscheme_gold.py`
`c74496a9…` (all byte-untouched).

## Amendment RS-1 (2026-08-10): Final-upgrade small fixes — authorised by the maintainer

Three parts:

1. **Atomic state saves** (Issue 6): `core/pipeline_state.py::save` now dumps to
   `<STATE_FILE>.tmp` then `replace()`s it into place — a crash mid-save can no
   longer corrupt the resume state. Evidence: crash-injection test leaves the
   pre-crash state byte-identical; no `.tmp` survives a successful save
   (`test-crops/final-fixes/test_final_fixes.py` I6 ×3; routing suite 17/17).
2. **Extended season tokens in filename parsing** (Issue 7): new module record
   `core/paper_identifier.py` — the season group grows from single letters
   `[msw]` to a shared token set (`mj, on, fm, sp, m_j, m-j, o_n, o-n, f_m, f-m,
   summer, winter, spring, march, may, june, specimen, spec`) applied to both
   `EXAMINER_REPORT_PATTERN` and `PAPER_PATTERN`, plus two additive ER
   arrangements (year-first `9701_2024_s_er.pdf`, type-first
   `9701_er_s24.pdf`); a `_norm_season_letter` helper maps every token onto the
   canonical letter (so downstream season labels/folder names are unchanged);
   `SEASON_MAP` gains `'sp': 'Specimen'`. Evidence: all four directive failing
   names now parse (`m-j`, `summer24`, `2024_s`, `er_s24`), 12 filename cases +
   3 standard-format regressions + long-format intact (I7 ×16; ER suite 56/56,
   extractor suite 32/32).
3. **New module record** `core/difficulty.py` (Issue 4, built per maintainer
   decision): log-scale marks→difficulty (1→1.00, 5→2.89, 10→3.71, 20→4.52,
   30→5.00, cap 5.0, defensive floor 1.0). Standalone; consumed by the future
   quality scorer (Upgrade 5 notes recorded in its docstring, incl. the
   subject-path normalisation requirement from Issue 8). Evidence: I4 ×3.

Full regression battery after all edits: 36/36 final-fixes, 18/18 real-paper
classify regression (both uploaded papers), 21/21 classifier factors, 17/17
routing, 56/56 ER, 32/32 extractor, 9/9 anchor, 9/9 scrub, 8/8 boundary shadow,
31/31 w25 spot.

### Updated SHA-256 (Amendment RS-1)

| File | SHA-256 |
|---|---|
| `core/pipeline_state.py` | `d317ac21eab84c32c096f514d853dce8f78b6b0c929851a527bfff37c457cf54` |
| `core/paper_identifier.py` | `083c6bd50006fb3202ed4fd543c3644b33198dabf10ca4db53d1799e0282192f` (newly recorded) |
| `core/difficulty.py` | `a30986196496e8f0e9709b9518b56a283b1d3372859b9bbe2ec48d6e6f24c96d` (new module) |
| `core/json_generator.py` | `4b905aec3433a6d5f8fc3f02e03e15d9690af07451bcca70b4b9d11c7f5d241a` (unchanged) |
| `core/output_manager.py` | `3aa13d813d8cf503cefaa859cec07f691e6d4e46fb4b0f161e9011d964563936` (unchanged) |
| `core/boundary_detector.py` | `841ec231b1684d89b1bb218f620defe1fd6826613bbfea7c6d7a8b0e3c1facdb` (unchanged) |
| `main.py` | `5f1b06072c2f8a984cc346b0371e1f1e1fa3911e3b6d0b9e704ff943e9899731` (unchanged) |

## Amendment RS-2 (2026-08-10): Guarded-runner audit findings — authorised by the maintainer

Background: the new self-checking runner (`run_guarded.py`, "check itself
every step" mode) ran the locked FinalValidator against a REAL output tree
containing ER content — the first run ever to do so (previous proofs validated
via `OutputManager.validate_qp_ms_pairs` only). Its S8 gate surfaced three
pre-existing production bugs:

1. **validation.py V1 — R9 QP counting excludes `_ER`** (`check_question_folders`):
   the `"_MS" not in f.name` filter counted full-report tiles and per-question
   ER crops as QP files ("must have exactly 1 QP webp, found 6"), so the final
   production audit could NEVER pass with ER attached. Filter now mirrors the
   locked OutputManager semantics exactly (`"_MS" not in … and "_ER" not in …`).
2. **validation.py V2 + output_manager.py V2b — dotfile state protection**:
   both orphan-JSON scans flagged `.pipeline_state.json`; validation.py's
   auto-heal then DELETED it on every audited run — silently killing the RS-1
   crash-resume file right after PipelineState wrote it. Both scanners now skip
   dotfiles loudly ("kept dotfile state JSON (not an orphan)"), never flag or
   delete them.
3. **validation.py V3 — package-relative `subjects_root`**: the default
   `"subjects"` was CWD-relative, so any caller outside the project root got
   `known_subjects=[]` and every subject folder flagged "Unknown subject
   folder". Default resolves package-relative; an explicit missing path falls
   back package-relatively, loudly.
4. **New module record `run_guarded.py`**: stage-gated self-checking
   orchestrator (S0–S8) driving the exact locked engines (main.py constructor
   args); per-paper subprocess isolation (worker crash/OOM surfaces as a loud
   failed gate); `--low-ram` streaming QP mode for ~2GB machines using the
   approved locked-triplet harness; loud ❌ banners + `failure_report.txt`;
   exit 1 on any failed check, never greenwashes.

Evidence: full real-paper run (9700 m25+w25 QP/MS + m25 ER, --low-ram): exit 0,
288 PASS / 0 FAIL; classifications exact match to approved baselines (12/12:
m25 Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5
Genetics; w25 Q1/Q2 Cell_Structure, Q3/Q5 Genetics, Q4 Cell_Membranes, Q6
Physiology); `.pipeline_state.json` survives the final audit; regression suite
`test-crops/guarded-run/test_validator_amendments.py` 10/10 (real orphan JSON
still flagged + auto-deleted; duplicate QP still caught; foreign-cwd subject
resolution); two organic loud aborts demonstrated during the build.

### Updated SHA-256 (Amendment RS-2)

| File | SHA-256 |
|---|---|
| `core/output_manager.py` | `1ae25f9dc0e6ce922f8b2595dadc454331f9c1ff499161d9bdb9141478745554` (was `3aa13d81…`; V2b) |
| `core/validation.py` | `2a62f1ce53f852cd60bf6e9a3efd5a1030780d9e6d9203c0c3570f2952998fac` (newly recorded; V1+V2+V3) |
| `run_guarded.py` | `240f4a3f1ca072305d06b1c94276ee0f8b185b1e92274c0d0dc9d52b0624e972` (new module) |
| `core/pipeline_state.py` | `d317ac21eab84c32c096f514d853dce8f78b6b0c929851a527bfff37c457cf54` (unchanged) |
| `core/paper_identifier.py` | `083c6bd50006fb3202ed4fd543c3644b33198dabf10ca4db53d1799e0282192f` (unchanged) |
| `core/difficulty.py` | `a30986196496e8f0e9709b9518b56a283b1d3372859b9bbe2ec48d6e6f24c96d` (unchanged) |
| `core/json_generator.py` | `4b905aec3433a6d5f8fc3f02e03e15d9690af07451bcca70b4b9d11c7f5d241a` (unchanged) |
| `core/boundary_detector.py` | `841ec231b1684d89b1bb218f620defe1fd6826613bbfea7c6d7a8b0e3c1facdb` (unchanged) |
| `main.py` | `5f1b06072c2f8a984cc346b0371e1f1e1fa3911e3b6d0b9e704ff943e9899731` (unchanged) |

## RS-3 (2026-08-10) — quality scorer (read-only; previously approved, recorded now)

| File | sha256 |
|---|---|
| `core/quality_scorer.py` | `5dd491d8769d4ec51fed33a5ec530d2cc34dc250666235915fe0f602349af6ab` (new module) |

## RS-4 (2026-08-10) — parallel orchestrator + child-state isolation + config cache (Efficiency U1/U4/U6)

`pipeline.py` (new): Overseer parallel-batch spec ported onto the real system —
workers are the proven `run_guarded.py --_worker` subprocesses, concurrency
RAM-guarded (`guard_decision`, calibrated 1100MB/worker + 400MB reserve from
measured 933MB RSS), parent owns `.pipeline_state.json`, tqdm optional.
`run_guarded.py`: `_NullState` + `GUARDED_CHILD_NO_STATE=1` child mode
(no concurrent state-file writers), gc + RSS line at worker end.
`core/config_loader.py`: `_CONFIG_TREE_CACHE` (mtime fingerprint invalidation);
115 json.loads per 5 lookups -> 0 warm. requirements.txt: +tqdm, +psutil(optional).

| File | sha256 |
|---|---|
| `run_guarded.py` | `c24a2bec3cd7bd1cb3b3950789b7be4a9944d19bfecc7bce6399ea1cf2302ad0` (was `240f4a3f…`) |
| `pipeline.py` | `ef52dee2a16169132810b07706b2d9f2f9758c6d6efd2bda114d3d3a078cfc04` (new module) |
| `core/config_loader.py` | `2ec52386486aaa551199fcfffd24d9b653f30e294f28bd7e9b5ca781cd3da0f5` (newly recorded) |

## RS-5 (2026-08-10) — Uncategorized preservation (never-discard routing) — authorised by the maintainer

Overseer Uncategorized directive, decisions: desperate_only routing;
adopt_keep_crop; single_level path `output/{Level}/{Subject}/Uncategorized/{QID}/`;
scorer reporting (no forbidden metadata fields). QP crops are ALWAYS saved;
a question with no mark scheme is preserved, never discarded.

1. **`core/output_manager.py`** — `UNC_FOLDER = "Uncategorized"`;
   `UNC_SENTINELS = {classification_failed: "Uncategorized",
   no_markscheme: "Uncategorized_No_MS"}`; `UNC_REASON_MESSAGES` (directive text
   verbatim); `save_uncategorized_question(matched, reason, config)` — QP always
   saved, MS only when `matched.ms` is present, `metadata.json` via the locked
   JSONGenerator schema carrying the sentinel topic, `REASON.txt` beside it;
   no-shadow rule (a real classified twin wins and the UNC save reports
   skipped_duplicate); promotion inside `save_question_pair` — an Uncategorized
   twin is retired loudly when a real classification later lands for the same
   question, while real duplicate folders remain fatal-skips;
   helper `_is_uncategorized_no_ms`.
   **RS-5b** (same round, follow-up fix): `validate_qp_ms_pairs` Phase-0a
   auto-heal no longer MOVES Uncategorized folders into a folder literally named
   after the `Uncategorized_No_MS` sentinel (sentinel bypass before heal), and the
   Phase-1 "missing MS webp" check skips `_is_uncategorized_no_ms` folders.
2. **`core/validation.py`** — `_check_uncategorized_folder()` (exactly 1 QP webp,
   1 metadata.json, 1 REASON.txt; 1 MS webp unless the no-MS sentinel, then 0;
   sentinel check; question number in folder name). Exemptions wired through
   `validate_subject_context`, `check_qp_ms_pairing_new`,
   `check_json_folder_topic_consistency` (sentinel accepted BEFORE auto-rename,
   loud print), `check_topic_classification`, the second taxonomy site inside
   `check_no_cross_contamination`, and `check_major_mapping`. NOT exempt: 2280px
   width, mandatory-file presence, JSON validity.
3. **`core/quality_scorer.py`** (amends the RS-3 record) —
   `report["needs_review"]` = {uncategorized_total, no_markscheme,
   classification_failed, needs_review, folders[:20]}.
4. **Runner wiring** — `main.py`: uncategorized counters, MISSING_MS ->
   QP-preserve block, desperate-tier routing in the classify loop, unmatched-QP
   routing, summary prints. `run_guarded.py`: qp-only bundles flow to workers,
   S3 skipped when ms is None, `ms=None` stubs, S5 routes ms-None ->
   no_markscheme and desperate -> classification_failed, qp-only papers get
   `state.mark_failed("MISSING_MS (QP crops preserved to Uncategorized)")` so a
   re-run reprocesses them, per-run prints `Uncategorized (no MS): X /
   (classify failed): Y`. `pipeline.py`: `_collect_bundles` allows qp-only
   bundles.

Evidence (real 9700 m25 uploads, --low-ram): parity gate output3 vs RS-2 approved
tree 33/33 webp byte-identical and 0 Uncategorized on clean input; T1 qp-only run
6/6 preserved (QP+metadata+REASON, ER commentary still attached) validator
ALL GREEN; T2 truncated-MS (7-page) 3 normal topics + 3 routed, ALL GREEN;
T3 forced-tier unit (classification_failed = exactly 4 files; weak_keyword NOT
routed); T4 1000px webp inside Uncategorized still flagged (width NOT exempt),
sentinels quiet, cleanup -> 0 unc-related errors; T5 scorer needs_review
{total 3, no_markscheme 3} on mixed tree / {0} on clean; promotion unit
(twin retired + idempotent rewrite); main.py mini-QP wiring proof. Logs:
test-crops/eff-bench/{qponly4,mixed2,mainmini2,regression3}.log, unc_unit/,
promo/. Full write-up: UNCATEGORIZED_IMPLEMENTATION.md.

| File | sha256 |
|---|---|
| `core/output_manager.py` | `fdbf8c8504cde851a214d082d6d5acc37dcca3840937995ffd271e502a566b7e` (was `1ae25f9d…`) |
| `core/validation.py` | `3b971478b492f48fd53dff2908d82267ee6e653b2aec937a499a675ca9aca320` (was `2a62f1ce…`) |
| `core/quality_scorer.py` | `bdb6ca4744891ead3023ce86c2877e30e2f6d6d9291b22e3694a44ac456641ee` (amends RS-3; was `5dd491d8…`) |
| `main.py` | `01f7c6768ebe91cab100835640b0044cb093178ca88e792f96a221f24dbd1677` (was `5f1b0607…`) |
| `run_guarded.py` | `0fc96374b5de92a443283f0ca021e4eac50fa2a76b800987a0d39d357539b850` (was `c24a2bec…`) |
| `pipeline.py` | `6bd045bdaf7eb4674ca30b9fd204da72b9d597e9ca0857cb0f913000af39bc01` (was `ef52dee2…`) |

## RS-6 (2026-08-11) — confidence-gate runner/validator/config gates + new module records — authorised by the maintainer

Overseer confidence-gate spec (same approved decision set as CROPPING Am-7).

1. **main.py** — defect 6 completeness gate before the state commit: a paper
   is marked complete ONLY when QP crops exist, no output write failed, every
   detected question was saved (classified or Uncategorized), and no
   propagated QC `needs_review` stands; otherwise `state.mark_failed` with the
   exact reason (CROP_EMPTY / OUTPUT_WRITE_FAILED / INCOMPLETE / QC
   needs_review) + loud line.
2. **run_guarded.py** — same gates in the guarded runner (defect 4+6): QC
   verdicts captured BEFORE the RAM-hygiene `del qp_cropped` (scalars kept;
   fixes the UnboundLocalError found by the runner's own S5 self-check);
   CROP_EMPTY and QC-flagged papers are mark_failed loudly instead of
   complete. Low-ram namespaces now carry `needs_review`/`qc_reasons` from the
   harness QC status.
3. **core/validation.py** — defect 10: `check_single_folder_distribution`
   rewired from the vacuous `*_QP.webp` glob (matched ZERO production files —
   silently passed everything) to the real writer convention
   (`{variant}_{Season}_{Year}_Q{n}.webp`, minus `_MS`/`_ER` twins); docstring
   structure diagram updated to the real naming.
4. **core/config_loader.py** — defect 7 with approved policy: unsupported exam
   year for a configured subject now prints a loud `YEAR FLAG` (syllabus years
   are syllabus EDITIONS — real 2025 papers legitimately use 2026-edition
   configs) and still resolves the same-subject config; no silent fallback.

New module records (all created this round-chain):
- `tools/download_fixtures.py` + `tools/fixture_manifest.json` — real-fixture
  corpus: 30 remote Cambridge PDFs (dynamicpapers 2015/16 archive,
  bestexamhelp 9618-2023) + 6 user uploads; %PDF magic enforced after a
  papacambridge HTML-shell incident was caught; SHA-256 pinned per file;
  organic rotated-MS fixture (`0620_s16_ms_42.pdf`, pages 1-6 @90°).
- `tests/` — 14-test confidence-gate + identity suite (14/14 OK).
- `engine/` (discoverer + renderer), `profiles/` (base_profile + registry),
  `parsers/` (base_parser) — rebuild Steps 1-3 (approved; 22/22 step checks).

Evidence: real-paper guarded run ALL GREEN with both papers state=complete and
zero gate false-fires; 33/33 baseline byte-parity; F10 unit test proves the
planted cross-topic duplicate is caught and the old glob sees nothing; F7 unit
tests both directions; YEAR FLAG printed live for the 2025 uploads;
marker-less synthetic paper aborts loudly at S2 with failure_report and no
fabricated output. Logs: test-crops/redesign/defectfix_run.log, step1_3_checks.log.

| File | sha256 |
|---|---|
| `main.py` | `557e493ed158c7df07e24b2c02235439a60f1a293d5a1304a52b869ec2a3a31b` (was `01f7c676…`) |
| `run_guarded.py` | `2d16aacd9fd1115d5a2f3ea567aa124a356099d4aa2666826e5d6d84f4e55e9f` (was `0fc96374…`) |
| `core/validation.py` | `fc3420394fa308b4613f3bf5b498645c8d5f880931c0861b031eb25727aaeb5d` (was `3b971478…`) |
| `core/config_loader.py` | `d687454764de9a7aa014c890fe9ece204a564a77907de2c601664021b58e9ce9` (was `2ec52386…`) |
| `tools/download_fixtures.py` | `9352806a58b21e57a3ecd6924028bedf669b724010d07c2f8f5ed4383b62a38b` (newly recorded) |
| `tools/fixture_manifest.json` | `e6d8f157682e8c850f84b749aa15428d93f60512a4dd51e0f485d4728f51d6b2` (newly recorded) |
| `tests/__init__.py` | `7a915dad20bbec055ddf00dc44232d5a48469a909b13339b04cd547f3ed915fd` (newly recorded) |
| `tests/test_confidence_gate_fixes.py` | `6b8a7490679ad30cab26cbb38c3a19ebc21626fc798362d60df9116917701a34` (newly recorded) |
| `engine/__init__.py` | `15a9b327f0061722e61593e09d8a2a10ebe21378185477d1c93b777428127e53` (newly recorded) |
| `engine/discoverer.py` | `393f15a3de9149f2130686f7a33712ad895f2e0d047b26eb18879fa5cb89cc78` (newly recorded) |
| `engine/renderer.py` | `8f9ed0a1951ea283c84ab2e434107c2e04dfc83fff07ec2e638b256a35c84c5f` (newly recorded) |
| `profiles/__init__.py` | `0c3780d38a35b95ffda1313bae8f4a1a2d0013db61b419a18e2fb15171fbf3f1` (newly recorded) |
| `profiles/base_profile.py` | `a20d10938021e71856bd76956738ae57e48fa1e7b125045834ad145298e382b0` (newly recorded) |
| `profiles/registry.py` | `9126e56dfe8d5cb2f4ec607fb0fb89021c0f541fbe247eae09e2281547831617` (newly recorded) |
| `parsers/__init__.py` | `fc878b4a3267f9336a845a60a32949fde73495c10bfeb1b6043f0e93efb411be` (newly recorded) |
| `parsers/base_parser.py` | `e909eec68e96d0f72bd910e13ca43448825410d9900c0433994666659dbe479c` (newly recorded) |
## RS-7 (2026-08-11) — IGCSE paper-format round: truthful identification, folders, letters, wiring — authorised by the maintainer

Overseer IGCSE-format spec; approved decision set: prod_homes / rename /
advisory counts / letters. Premise audit receipts: spec's "0620 all
structured" core claim TRUE; spec's count table partially disproved by real
fixtures (0580 structured ~21-24 anchors vs claimed 10 → counts advisory);
spec's file names wrong (real homes recorded here).

1. **core/paper_identifier.py** — verbatim `IGCSE_COMPONENT_MAP` (14 syllabi
   from the spec), honest `IGCSE_QUESTION_COUNT` (only MEASURED values: 40
   MCQ sciences, 30 for 0455 noted Cambridge-published; structured counts
   `None` = never asserted), `resolve_paper_format()`,
   `expected_question_count()`, `_ALEVEL_MCQ_P1_SYLLABI`, and `PaperInfo`
   `__post_init__` filling additive `paper_format` / `is_mcq` /
   `expected_question_count` (`paper_type=="er"` → format `"ER"`) + to_dict
   fields. A-Level behavior byte-identical.
2. **core/paper_scan.py** — NEW module record: `scan_paper(filename)` compat
   shim over the identifier (the spec's test surface), fail-closed on
   unrecognised names.
3. **core/output_manager.py** — IGCSE truthful folder rename
   (`P1_MCQ`, `P2_MCQ`, `P3_Structured`, `P5_Practical`, `P6_ATP`, `P1_Essay`,
   …) resolved from the SAME `IGCSE_COMPONENT_MAP` the identifier uses
   (single source of truth); A-Level ladder byte-identical. MCQ write branch:
   QP webp + `metadata.json` only — the extracted grid letter rides in
   metadata (`ms_answer`, `paper_format` additive keys); an MS webp is NEVER
   fabricated. `save_uncategorized_question` propagates the letter into
   sentinel metadata; phase-1 disk audit exempts MCQ folders (letter
   required instead of MS webp).
4. **core/validation.py** — paper-type tokens extended (`_ATP`, `_Essay`,
   plus `Plan_Analysis`/`Alt_to_Practical` closing the pre-existing latent
   gap for A-Level P5/P6 names the writer was already emittable-but-
   unvalidatable) at ALL FOUR `is_paper_type` sites (an earlier session
   estimate said three; the assert caught the fourth at
   `check_folder_requirements_new`) + the major-mapping exemption; MCQ
   MS-absence exemptions in folder-contents / pairing / subject-isolation /
   Uncategorized checks — each requiring a valid `ms_answer` letter in
   metadata instead of an MS file.
5. **main.py** — MCQ wiring: grid extraction → metadata-only pairing stubs
   (`ms=None` + `ms_answer`) → normal classify/save; crops without a grid
   letter fall into the EXISTING unmatched→Uncategorized/no_markscheme
   machinery; empty grid fail-closed (`MCQ_GRID_EMPTY`, never marked
   complete).
6. **run_guarded.py** — S3 grid-extraction stage gate (fail-closed on empty,
   advisory expected-count print), S4 letter pairing with coverage checks,
   S5 MCQ-aware first branch + metadata letter/format on-disk checks.
7. **tests/test_igcse_formats.py** — NEW: 10 tests (spec 17/17 truth table;
   24-row folder truth table incl. A-Level byte-identical regression rows;
   detect_mcq fast-paths ×3; real-fixture grid extraction ×2; synthetic MCQ
   save + validator accept/reject ×3).

Evidence: MCQ end-to-end 0620_s16 P22 (real fixtures, --low-ram) — worker
348 checks + full run 21 checks ALL GREEN; S8 final audit errors=0; 23 topics
folders under `IGCSE/Chemistry_0620/P2_MCQ/<majors>` + 3 Uncategorized
(letters preserved), every folder exactly one 2280px webp, zero MS webps,
letters equal the gold extraction (Q1..Q5 = A,A,D,B,C). A-Level regression
9700_m25 P22: 6/6 overlapping webps byte-identical to RS-2 baseline manifest;
extras/missings fully explained (w25-paper / ER-absent / previously-eroded).
Full suite 24/24. NOTE (reported, pre-existing, NOT this round): the low-ram
harness page classifier silently dropped 5 real question pages of
0620_s16_qp_22 (Q27-31, Q35-40 incl. a mixed copyright+questions page) —
caught by the advisory counts + fail-closed gates (paper NOT marked
complete). Ledger entry: `test-crops/redesign/IGCSE_FORMATS_ROUND_EVIDENCE.md`.

| File | sha256 |
|---|---|
| `core/paper_identifier.py` | `763135c7cb370ca9b0561defc216572ca26ed3e57efe835c4993567e4450c563` (was `083c6bd5…`) |
| `core/output_manager.py` | `742690021c33798b2643ef8bba9aec16b2200e8eea26f9c5e6e8c9217c0662e8` (was `fdbf8c85…`) |
| `core/validation.py` | `29de98c38605bd7e009bb4c6f76e811509fc19d28471d3ef8b9061fd0f231f89` (was `fc342039…`) |
| `main.py` | `7cbc7c2df4cda06454e8a63926ec4d8cbbf19612a7e8e1bd0b42af711691570b` (was `557e493e…`) |
| `run_guarded.py` | `8f63177b3fab48e356cbe476436aff0f5ff9c696066ed04d2eac5e5e8f960bca` (was `2d16aacd…`) |
| `core/paper_scan.py` | `3f2f9e220716b6f361b841c5532045b72eeb22fc705d128697374868ab5751f5` (newly recorded) |
| `tests/test_igcse_formats.py` | `648e49efa5a5c6163e6161aa3d7b2262ba71c54446b0d9647f695af393edf2c6` (newly recorded) |
## RS-8 (2026-08-11) — Batch-processing infrastructure round: SQLite batch ledger + preflight + staged commit + bundle worker + pool runner + CLI — authorised by the maintainer

Overseer batch-infrastructure spec ("full architectural upgrade", 7 phases,
10 RULES); approved decision set: honest_port / bridge state / workers=1
real proofs. Premise audit: the spec targeted the fictional `cambridge_qb/*`
package with the same five hallucinated APIs the `pipeline.py` docstring
already busts; 10 spec bugs caught on write (markdown-linkification
corruption family) — file:line receipts in
`test-crops/redesign/BATCH_INFRA_ROUND_EVIDENCE.md`.

1. **core/database.py** — NEW: SQLite batch ledger (WAL): files / bundles /
   questions / artifacts / errors tables; BundleStatus
   PENDING/PROCESSING/COMPLETE/FAILED/REVIEW_REQUIRED; ArtifactKind
   QP/MS/ER/IN; BYTES_PER_QUESTION=900_000; attempts<3 retry cap.
   `register_file` is an id-preserving UPSERT — the spec's
   `INSERT OR REPLACE` mints a fresh rowid and orphans bundle FKs
   (unit-proven); `set_bundle_counts` is additive (review bundles were
   reporting "Questions saved: 0" beside a committed 26-question tree);
   `_sync_er_artifacts` is an idempotent post-commit ER-artifact sync pass.
2. **core/preflight.py** — NEW: main-process-only scan/identify/group/
   register + storage check (0.9 threshold). Identification via the REAL
   `paper_identifier.identify_papers_in_dir` (NOT the legacy
   `paper_scan.scan_papers` shim — different PaperInfo ctor). Two-pass
   bundle grouping: glob sorts `*_er` before `*_qp`, so QP/MS bundles are
   formed first and component-less session ERs (`9700_m25_er.pdf` ->
   variant='') attach to ALL bundles of the same code+season+year.
3. **core/staged_writer.py** — NEW: `.staging/bundle_<key>` write-then-
   commit; failed bundles preserve their staging directory (incl.
   worker_log.txt + failure_report.txt). RULES 6/8 honoured.
4. **core/bundle_worker.py** — NEW: `process_bundle(args)` standalone
   (multiprocessing-safe); drives the REAL locked stages via
   `run_guarded.run_paper_stages` with `OutputManager(output_root=staging)`;
   no input-dir rescan (identity via `parse_paper_filename` per path —
   RULE 4), single-subject config via
   `config_loader.load_subject_config_by_code_and_level` (RULE 5),
   throwaway `PipelineState` inside staging. Verdict mapping from
   `state.papers[base_key]`: complete -> complete; error containing
   `QC needs_review` / `MISSING_MS` / `CROP_EMPTY` -> review_required
   (crops + letters still committed, counts recorded); else failed
   (staging preserved). ER attach is post-commit parent-side:
   `examiner_report.attach_examiner_reports_to_output` +
   `er_question_crops.attach_question_er_crops`.
5. **core/batch_runner.py** — NEW: `run_pipeline(pdf_dir, output_dir,
   topics_dir, workers=cpu//2, resume, retry_failed, dry_run)` pool
   orchestrator (ProcessPoolExecutor + tqdm); RAM guard reused from
   `pipeline.py` (`available_mem_mb` / `guard_decision`,
   PER_WORKER_PEAK_MB=1100, PARENT_RESERVE_MB=400) — real proofs ran
   clamped to workers=1 on this box.
6. **run_pipeline.py** — NEW: CLI (--input --output --topics --workers
   --resume --retry-failed --dry-run).
7. **tests/test_batch_infra.py** — NEW: 31/31 (1 heavy tier opt-in via
   BATCH_HEAVY=1).

Bridge note (RULE 10, approved bridge decision): SQLite is the batch
ledger; `main.py` / `run_guarded.py` keep `.pipeline_state.json` until a
parity-proof round authorises cutover.

Evidence: real-fixture E2E (`test-crops/redesign/batch_final.log`,
`batch_step4.log`, `batch_step5.log`, `batch_step5_full.log`): full
2-bundle clean run 1m42s — 0620_s16 P22 review_required (26/26 committed
under `P2_MCQ/`) + 9700_m25 P22 complete (6/6); ER attach 6 text + 6/6
crops; final audit errors=0; "Questions saved: 32". Resume re-run: "0 new.
2 already known. No bundles to process." Forced-failure demo (MS truncated
to 2048 of 625854 bytes): the S3 fail-closed grid gate fired ("0 answers"),
bundle failed + staging preserved + attempts 1->2 via --retry-failed. DB
census: 2 bundles, 32 questions (3 needs_review UNC), 68 artifacts
(32 qp @2280px, 6 ms, 30 er). Zero production files modified; bounds
honoured: triplet `00cc779e…` ×3, multipage `c384248b…` ×2, all gold
byte-untouched, spec RULES 1-3 (ms_crop.py / question_split.py boundaries /
converter.py DPI) untouched; ledger grows 43->50 pure-additive.
requirements.txt already carried tqdm>=4.65.0 + psutil>=5.9.0 (spec
Phase 7 = no-op, receipted).

| File | sha256 |
|---|---|
| `core/database.py` | `ece11f5810877e74f5966fbc620622be954fc8548fd267b73c0632fa0f7f93fa` (newly recorded) |
| `core/preflight.py` | `9acaad024247c4ed8230ed0fc8f8e8ef8b3875413207246be99a3c3259f4eada` (newly recorded) |
| `core/staged_writer.py` | `a4415605cda006e1923b103a0b77427357e47fc16aed122910181c687fd37680` (newly recorded) |
| `core/bundle_worker.py` | `fea7b4630a547b7cd7da9f96fdb14a318fbde6ba5bbf4ba4c5d2dab7a552dd47` (newly recorded) |
| `core/batch_runner.py` | `2d280620670341514439740db8b907b570cbe1685d81d754945fe6b5a661da4e` (newly recorded) |
| `run_pipeline.py` | `474b5815c661612aee35bce346150d42496b611fc110bdc35db3a291569e8f05` (newly recorded) |
| `tests/test_batch_infra.py` | `f18ba0fc673ef26dc7197d7e381f155f527c5aa9c6e7e01a0984556298c86210` (newly recorded) |
## RS-9 (2026-08-11) — Batch manifest round: one-pass input-identity manifest (derived cache) consumed by run_guarded S1 + main.py — authorised by the maintainer

Overseer manifest spec; approved decision set: build-it-for-real /
new_delegate / derived_cache. Premise audit (receipts in
`test-crops/redesign/MANIFEST_ROUND_EVIDENCE.md`): the spec's "step 1
completed, file added, 2 tests passed" claims were FALSE on disk; its
"directly improves 300+ file processing" claim was DISPROVED by measurement
(live identify 0.60 ms vs manifest consume 1.29 ms per call on 36 real
PDFs — the O(N^2) per-worker re-identification was structurally real but
negligible in magnitude; RS-8's pooled runner remains the actual 300+
answer). The round's REAL win: the locked identifier's `rglob("*.pdf")`
silently dropped `.PDF` files — the manifest walk closes that gap (pinned
by test; identifier itself untouched).

1. **core/batch_manifest.py** — NEW: one-pass scan/identify (delegated to
   locked `parse_paper_filename` — zero parsing duplication), sha256
   single-sourced from RS-8 `database.sha256`, size+mtime_ns per file,
   two-pass QP/MS/ER grouping with receipted preflight parity (component-less
   ERs attach to every bundle of the series; component ERs by first-digit),
   duplicate/missing detection (ms-only groups kept as REVIEW_REQUIRED —
   preflight silently drops them; duplicates keep BOTH paths), atomic
   tmp+fsync+replace writes, fail-closed identifier-drift tripwire on
   consume. MANIFEST IS A DERIVED CACHE: any staleness -> silent live
   fallback; workers NEVER build; `.pipeline_state.json` + batch SQLite
   remain the only status truths.
2. **run_guarded.py** — S1 consumes manifest-or-live
   (`identify_via_manifest_or_live`; parents build_if_missing=True, workers
   consume-or-fallback); new flags `--manifest` / `--no-manifest` /
   `--manifest-full-check`, propagated to spawned paper workers.
3. **main.py** — identify phase consumes manifest-or-live (builds as a
   top-level parent entry).
4. **pipeline.py** — UNTOUCHED (byte-identical): workers auto-discover
   `<input>/.batch_manifest.json`; explicit override via
   `GUARDED_MANIFEST_JSON` env (proven).
5. **tests/test_batch_manifest.py** — NEW: 13 tests (real-uploads grouping;
   .PDF gap pin; duplicate/missing/series-ER/first-digit tables; drift
   fail-closed; cheap/full freshness tiers + sha rescue; atomic write;
   load_inputs parent-builds/worker-consumes/disabled wiring; CLI).

Evidence: suite 30/30 (13 new + igcse 10 + batch 7, 1 heavy skipped by
default); real E2E 9700_m25 pair + ER + 9700_w25 pair low-ram 2m07s rc=0,
final audit errors=0, both workers `[identity:manifest:…]`, **33/33
overlapping webps byte-identical to the RS-2 baseline** (21 produced-only
= w25 Qs + ER artifacts, explained), 54/54 webps exactly 2280px; tamper ->
stale advisory -> live fallback proven; `--no-manifest` differential
non-regression at the pre-existing S4 ER-only-subject abort (queued finding,
own round). Bounds honoured: triplet `00cc779e…` ×3, multipage `c384248b…`
×2, all RS-8 batch files byte-untouched, ledger 50->52.

| File | sha256 |
|---|---|
| `run_guarded.py` | `8793d80491104aa093915594d9243d64864a354c160c5c44fb68961ed5ef4cd6` | (was `8f63177b…`) |
| `main.py` | `e1b989e8d62c3caff8d23c74bcc873765c1852371700be8c5179098bb6bb4761` | (was `7cbc7c2d…`) |
| `core/batch_manifest.py` | `2659a2fb3b4aa9789e16676c18828ecaa2a12ec24b052d68f8d9e30f0212137c` | (newly recorded) |
| `tests/test_batch_manifest.py` | `6c95c83832f6e20df773ecc430c4c3d99db8880a5607ee30cd244bf6770e94ca` | (newly recorded) |
## RS-10 (2026-08-11) — Online missing-MS resolver round (opt-in `--fetch-missing-ms`) — authorised by the maintainer

Overseer MS-fetcher spec; premises fact-checked FIRST: the spec targeted the
fictional `cambridge_qb` package again (real home `core/ms_fetcher.py`);
its database path/SQL/consumption-wiring claims all verified TRUE against the
RS-8 schema (`get_pending_bundles` LEFT JOINs files via `ms_file_id`, so the
resolver's UPDATE is sufficient — proven in-test); its requirements phase was
a NO-OP (`requests>=2.31.0` already present). 9 semantic spec bugs fixed on
write (F2 rowid-orphan `INSERT OR REPLACE` -> `Database.register_file`; F3
empty review reason; F4 never-verifiable specimen seasons; F5 report crash
before any fetch; F6 dry-run log poisoning; F7 summary shape; F8 RULE-7 exact
message; F9 pre-2000 limitation) + ~30 corruption artifacts de-linkified —
receipts in `test-crops/redesign/MS_FETCHER_ROUND_EVIDENCE.md`.

1. **core/ms_fetcher.py** — NEW: URLBuilder / Downloader / PDFVerifier /
   MSCache / ms_fetch_log (lazy; core/database.py deliberately NOT amended) /
   MissingMSResolver. Opt-in only; verified-before-use; unverified downloads
   -> REVIEW_REQUIRED, never the pipeline; every attempt logged with
   url/source/sha256/timestamp; cache dir separate from input; REQUEST_DELAY
   2.0s mandatory.
2. **run_pipeline.py** — additive `--fetch-missing-ms` / `--ms-cache-dir` /
   `--fetch-dry-run` + pre-run hook (missing-DB guidance branch included).
3. **core/preflight.py** — additive `print_manifest_report(db)` (with the F5
   ensure_fetch_log guard).
4. **tests/test_ms_fetcher.py** — NEW: 11 tests; spec's 4 validation cases
   PASS; hermetic localhost E2E proves fetch -> verify -> ms_file_id ->
   next-run `ms_path` consumption; RULE-2 review and RULE-7 message pinned.

Evidence: suite 11/11 new, 41/41 total this turn (igcse 10 + batch_infra 7 +
batch_manifest 13 + ms_fetcher 11); CLI three branches proven; live probe of
pastpapers.co non-gating (301/Cloudflare — URL patterns NOT asserted; wrong
fetches land in review by design). Environment incident: wipe #6 was the
first MID-TURN one (PyMuPDF + fixtures vanished mid-turn; re-provisioned,
all suites re-run green). Bounds honoured: triplet `00cc779e…` ×3, multipage
`c384248b…` ×2, `ms_cropping_engine b69285ee…`, `converter d8bf74d8…`
untouched; requirements.txt no-op; ledger 52->54.

| File | sha256 |
|---|---|
| `core/ms_fetcher.py` | `ea73680d543fcd3e83042a8debaab9011f5ded1dfbf09f73b3e45934dbe1b27f` | (newly recorded) |
| `tests/test_ms_fetcher.py` | `d602a9db1842e82949f50c9f9c03506123404be18ee54301198a1cca12d29936` | (newly recorded) |
| `run_pipeline.py` | `e1ff2387fd7ea6e2547d3a4379142c412f61f0afd7f5796cb69c39bd9340a58c` | (was `474b5815…`) |
| `core/preflight.py` | `1d5d2b1fd655d9091530887624805c2f10f433b7df3027c224ceeaa5d3970c05` | (was `9acaad02…`) |
## RS-11 (2026-08-11) — Unified MCQ output across all qualifications (registry-authority round) — authorised by the maintainer

Overseer unified-MCQ spec; explicit maintainer decisions: **adopt_hybrid**
(the new registry is the SOLE MCQ authority; `IGCSE_COMPONENT_MAP` retained
as the format source for STRUCTURED/PRACTICAL/ATP/ESSAY folder formats),
**additive** (`_MS.txt` alongside the locked CLS-5 metadata keys; `ms_answer`
kept and mirrored by additive `question_type:"MCQ"` + `correct_answer`,
cross-checked both ways), **literal-with-gates-kept** (an empty `_MS.txt` IS
written when the grid letter is absent, loudly flagged; routing gates
unchanged — letterless MCQ still routes Uncategorized; the deeper
"route letterless into topic folders" variant stays an open decision),
**adapt** (validator accepts the real `*_ER.webp(+_partN)` naming; the spec's
STEP-7 audit kept its verification but had only its detection replaced).
Premise fact-check FIRST: the spec targeted the fictional `cambridge_qb`
package a third time (real homes `core/mcq_registry.py` + `core/mcq_output.py`);
its literal folder name `MCQ_P1/` and literal `examiner_report.webp` are
stale/fictional — NOT adopted (`P1_MCQ` stays; previously-produced banks stay
valid). Its STEP-8 gate ran BEFORE any other change as ordered: **42/42
registry assertions** (spec promised ~35; runner
`test-crops/redesign/mcq_step8_phaseA.py`).

Registry deltas vs the RS-7 locked map: `9608`/`9696` P1 MCQ -> STRUCTURED
(registry considered correct; inert — no configs exist for those codes),
`+9990` MCQ (spec-asserted, flagged dubious, inert); O-Level rows inert
(`infer_level_from_code` cannot classify them). Every fixture-backed code
resolves identically to RS-7. Retirement receipt: the old `_MCQ_SYLLABI`
table even listed Business 9609 and History 0470 as MCQ syllabi. Pre-existing
defect fixed en route: `check_qp_ms_pairing_new` `Image.open`'d `*_MS.txt`
(webp-only filter added). RS-7 test repaired: it was built on 0620/22 — MCQ
under the registry — so the structured-regression case moved to 0620/42
(`P4_Structured`); the MCQ-folder + `_MS.txt` + missing-`ms_answer` parity
error stays an error, keeping the RS-7 negative test green.

1. **core/mcq_registry.py** — NEW: `MCQ_COMPONENTS` + `MCQ_QUESTION_COUNT`
   + `is_mcq(syllabus_code, component)` — the only MCQ check used anywhere
   (STEP-7 content-audit patterns such as `paper_number == 1` /
   `variant.startswith("1")` / component tuples now delegate to it).
2. **core/mcq_output.py** — NEW: `_MS.txt` writer (exactly one letter
   A/B/C/D + newline; EMPTY file written when the letter is None — never
   skipped) + `validate_mcq_ms_file` immediately after write (logs, never
   crashes) + metadata writer for the additive keys.
3. **core/paper_identifier.py** — registry-first routing/detect shims;
   `IGCSE_COMPONENT_MAP` verbatim-retained for non-MCQ formats.
4. **core/output_manager.py** — MCQ save path writes `_MS.txt` beside the
   locked metadata; loud empty-letter flag surfaced to the audit.
5. **core/validation.py** — webp-only pairing fix + MCQ 4-file check adapted
   to `*_ER.webp(+_partN)` + txt/metadata cross-checks.
6. **core/mcq_support.py**, **run_guarded.py**, **tests/test_igcse_formats.py**
   — wording/adapter/test-repair amendments per the decisions above.
7. **tests/test_mcq_unified.py** — NEW: 16 tests (registry authority,
   additive schema, empty-literal rule, cross-check, routing gates kept,
   audit detection replacement, ER naming acceptance).

Evidence: STEP-8 42/42 FIRST; suites **58/58** (mcq_unified 16 + igcse 11 +
batch_infra 7 + manifest 13 + fetcher 11; 1 heavy tier opt-in skipped);
MCQ E2E real `0620_s16_qp_22` low-ram: 438 PASS, audit errors=0, saved=26,
**26/26 QP webps byte-identical to the RS-7 run**, **26/26 `_MS.txt` letters
== metadata**, Q1–Q5 = A,A,D,B,C == gold answer key, QC needs_review
Q8/Q21/Q24 unchanged; A-Level regression **33/33 webps byte-identical to the
RS-2 baseline** with the RS-9 manifest consumed; gold cross-check:
`markscheme_gold._is_mcq_paper` agrees on its P1 domain, IGCSE P2 divergence
by design (RS-7 adapter bypasses the router). Full receipts in
`test-crops/redesign/MCQ_UNIFIED_ROUND_EVIDENCE.md`. Environment incident:
wipe #8 (packages + fixtures again) — re-provisioned, all suites re-run
green before this commit. Bounds honoured: triplet `00cc779e…` ×3,
multipage `c384248b…` ×2, `ms_cropping_engine b69285ee…`,
`converter d8bf74d8…`, all gold files byte-untouched; CROPPING_LOCK
untouched by this round; ledger 54->57.

| File | sha256 |
|---|---|
| `core/mcq_registry.py` | `c4112a7f69a470060d682ba27d324828f1d8c35dd9910005e14ed37684306851` | (newly recorded) |
| `core/mcq_output.py` | `1dbdb642e7676b4ca015c9db586e2ef974a244bf97f1f2bf05cd4c5ebe128fbc` | (newly recorded) |
| `tests/test_mcq_unified.py` | `51c889de9126e1c20210ee5380328ba42d76bdd62c2f1dfca21e1f3189e27406` | (newly recorded) |
| `core/paper_identifier.py` | `7a61d54b5ddee3ad208e2d74069514ec2e431cbc1b2457f866d13a0935f21ef5` | (was `763135c7…`) |
| `core/output_manager.py` | `ae5e2c3b4f8705b0396f0146ba80c00d542a941e8ccbb30b3db9fa9a4c5c3d67` | (was `74269002…`) |
| `core/validation.py` | `cbc16e5ee1001bd033daea34527daf895f77ceeadb8db261c45c2bcadb97e93f` | (was `29de98c3…`) |
| `core/mcq_support.py` | `934bb3d6fb364000389485cde7945e7bec775d6980656bd8fd2b998577a81b12` | (was `d35afbc1…`) |
| `run_guarded.py` | `7eb9a3383282233f1e44a83fcdefefecaa983ed72a8219feaf93682d1214657c` | (was `8793d804…`) |
| `tests/test_igcse_formats.py` | `c695105e0006923f7b27af55abd70c50c2a4ba4c211f1dc83d30a13736f8a3a4` | (was `648e49ef…`) |
## RS-12 (2026-08-11) — Page-classifier data-loss fix (import-binding + ordered-veto + poison-page rescue) — authorised by the maintainer

Defect round (no overseer spec). Root cause receipted in
`test-crops/redesign/PAGE_CLASSIFIER_ROUND_EVIDENCE.md`: the live QP path ran
the PRISTINE gold classifier — `core/cropping_engine.py` prepends
`original_reference/` to `sys.path` and imports `cambridge_qb.question_split`,
whose relative `from .chemistry_reference import …` bound the gold copy with
its `if is_adm or is_terminal:` fallback (any sparse page in a paper's last
six pages -> `admin_back_matter` at conf=0.80) and its MCQ-blind question
probe. 16 question pages across 5 fixtures were silently eaten
(0620_s16_qp_22 saved only 26/40; Q32-34 were additionally SWALLOWED into
Q26's 2280x3055 crop — visually verified). Third root: the probe's DOTALL
strip of "Permission to reproduce items.*" hid Q38-40 below the copyright
block (poison page).

Maintainer decisions: **D1 shim / D2 composite ordered-veto / D3 rescue
(visual-verification clause) / D4 full oracles**.

1. **core/cropping_engine.py** — import block ONLY: pre-seed
   `sys.modules["cambridge_qb.chemistry_reference"]` with the maintained core
   copy BEFORE any cambridge_qb import (file-path fallback included).
   original_reference/ verified byte-pristine after; question_split triplet
   `00cc779e…` ×3, converter `d8bf74d8…`, ms_cropping_engine `b69285ee…`
   untouched. Zero crop-math change.
2. **core/chemistry_reference.py** — ordered-veto (structural Periodic-Table
   grid check moved BEFORE the question-structure short-circuit — its
   element-symbol rows satisfy the MCQ option-line pattern) + poison-page
   rescue (`_first_admin_sign_pos` / `_has_question_start_beyond` with a loud
   `[page-rescue]` line). `or is_terminal` NOT reintroduced (test-pinned).
3. **tests/test_page_classifier.py** — NEW: 12 tests (subprocess wire-up
   identity, veto order, hermetic synthetic poison/pure pages, terminal-window
   rail, exact corpus removed-set pins for all 12 remote fixtures, m25/w25
   baseline pins).
4. **original_reference/cambridge_qb/chemistry_reference.py** — PRISTINE PIN:
   recorded as-is (it is the gold reference; the defect is bypassed via the
   shim, never edited).

Evidence: MCQ E2E real 0620_s16_qp_22 low-ram — 40/40 questions saved (was
26), audit errors=0, ALL GREEN; letters 40/40 valid, Q1-5 == gold A,A,D,B,C,
txt⟺metadata 40/40; `[page-remove]` now fires exactly twice (cover + PT);
25/26 pre-existing crops byte-identical (Q26 changed 3055px -> 699px = the
fix itself); Q37/Q38/Q39 visually clean, Q40 QC-flagged by design (trailing
copyright block inside the LOCKED splitter's last-question-to-page-bottom
crop — review workflow as intended). A-level regression: **33/33 overlapping
webps byte-identical to the RS-2 baseline**, produced profile identical
(54 = 33 + 21 produced-only, same as RS-9). Suites 70/70 OK (58 + 12 new;
1 heavy opt-in skip). Recovery counts: +14 question pages across
0620/21, 0620/22, 9700/12, 9701/12. Environment incidents: wipes #9 and #10
(#10 MID-TURN: PyMuPDF vanished between patch and verification) —
re-provisioned, everything re-run green. Ledger 57->60.

| File | sha256 |
|---|---|
| `core/chemistry_reference.py` | `c7a06c621d51384293f229f11499e5debd8bd7de3e4590106773c1045345e220` | (newly recorded) |
| `core/cropping_engine.py` | `d7ed6f71cfdb211b2d67939ab2f2294be81da04de464813d9d21815396d8d624` | (was `b58110d3…`) |
| `tests/test_page_classifier.py` | `79ce651ae0d37e54847d759f0b36dd8cd60319addb088799a495be14d61b9493` | (newly recorded) |
| `original_reference/cambridge_qb/chemistry_reference.py` | `829b8fe8b70973cc7b75aaa850f535971cb6d551e63b1b9aa115c7cb5014d579` | (newly recorded — pristine pin) |
## RS-13 (2026-08-11) — Blanket-mandate round: S4 orphan-ER fix + state-mirror parity + letterless routing + quarantine tool + 9990 resolution — authorised by the maintainer

Maintainer mandate ("Implement EVERYTHING… ask later"). Recommended options
applied; the ⏸️ lock/zip gate itself was kept inviolate. Five items:

1. **run_guarded.py** — S4 orphan-ER fix: a subject/year context with zero
   QP/MS bundles is SKIPPED loudly (was: whole-run abort — reproduced rc=1 on
   `9700_w25 pair + 0620_m25_er.pdf`, post-fix rc=0 ALL GREEN); orphan ERs
   (level/code context without question folders) relax ONLY the two ">0
   existence" gates in S6/S7 when every supplied ER is orphan; run end lists
   unused orphan ERs. Inertia oracle: w25 12/12 webps byte-identical to the
   RS-2 baseline. Also carries the S8 state-mirror parity advisory line.
2. **core/pipeline_state.py + core/state_mirror.py (NEW)** — state→SQLite
   cutover phase 1: every save() dual-writes the identical snapshot into
   <output>/pipeline.sqlite (lazy `state_runs`/`state_papers`, UPSERT, WAL,
   core/database.py NOT amended — RS-10 precedent); JSON remains sole
   authority; mirror failure provably cannot touch it; `verify_parity` is
   field-exact, advisory at S8 (loud, never fatal in phase 1). 5/5 tests +
   live `MIRRORED OK`.
3. **main.py** — letterless-MCQ topic routing (deferred unified-round Q3
   variant): a missing grid letter is a markscheme signal, not a
   classification one; letterless questions classify normally (CLS-4 desperate
   tiers still route Uncategorized); ALL loud surfaces kept (empty _MS.txt,
   absent ms_answer, OutputManager flag, RS-7 negative validator gate, batch
   staging rule). Legacy entry (guarded path never runs main.py) — integration
   proof + source pin, 3/3 tests.
4. **tools/quarantine_reviewed_crops.py (NEW)** — OPT-IN review-workflow tool:
   dry-run default; parses run logs' own QC verdict lines (both formats);
   moves flagged folders to `<output>/_Review/<reason>/…` + README; default
   filter REFERENCE_MATERIAL_CONTAMINATION (the RS-12 Q40 class); idempotent;
   rc=2 on unparseable log. 5/5 tests + live parse of the real RS-12 log
   (Q8/Q21/Q24/Q40).
5. **core/mcq_registry.py** — 9990 RESOLVED with Cambridge receipt: the 9990
   Psychology syllabus defines four WRITTEN components only (NO MCQ); the
   overseer spec's assertion was FALSE. Row removed from MCQ_COMPONENTS +
   MCQ_QUESTION_COUNT (36 -> 35), receipt D2-RESOLVED; pins updated in
   tests/test_mcq_unified.py.

Coherence: masthead 83/83 OK (58 prior + 12 RS-12 + 13 RS-13; 1 heavy opt-in
skip); combined MCQ E2E with all patches live: 40/40 saved, audit errors=0,
ALL GREEN, parity MIRRORED OK; invariants re-verified (triplet `00cc779e…`
×3, multipage `c384248b…` ×2, `b69285ee…`/`d8bf74d8…`, gold chem-ref pristine
`829b8fe8…`). No crop-boundary, DPI, or webp bytes touched anywhere. Full
receipts: `test-crops/redesign/RS13_MANDATE_ROUND_EVIDENCE.md`. Ledger 60->65.

| File | sha256 |
|---|---|
| `run_guarded.py` | `464951026c1b6845843b4cedcf573277db904c4e8961a42386208ded424ff561` | (was `7eb9a338…`) |
| `main.py` | `c78e0a6f2abc783d598b5dd992919407d7c6f357ca1774a86c685414fa695723` | (was `e1b989e8…`) |
| `core/pipeline_state.py` | `f0dd8ca749833c2b2da184d85ee7b5aab259b4df1a7831216cd4164b4802d392` | (was `d317ac21…`) |
| `core/mcq_registry.py` | `120976e45e47f558789e1b253dafb0d7dcf7196dac94d6a3f7facac44c6607f8` | (was `c4112a7f…`) |
| `tests/test_mcq_unified.py` | `a08327509f55f2b5efd209b13faee6b45e656533a3d0a429bab34d747e345952` | (was `51c889de…`) |
| `core/state_mirror.py` | `ca8219402a9fd936c62c7d15d38dee863ac1f85f1d3e4ae15040fea4f732dc8c` | (newly recorded) |
| `tools/quarantine_reviewed_crops.py` | `743040338a18c0b5a9469ef3048e75843480cd34439cf0416b74b1ecc1929d24` | (newly recorded) |
| `tests/test_state_mirror.py` | `9b59c1b2956211bec8568ccd8d599d126b2d132dc8120322496564a12f678f99` | (newly recorded) |
| `tests/test_letterless_mcq_routing.py` | `0e337668a0210568bcaf9b00c020382dc351280fe26b5b85124424bcbc72bf01` | (newly recorded) |
| `tests/test_quarantine_tool.py` | `9c268eece3d4e51793b368abe0c7aeb3c54e7f3ab273d60afc6267f428a07028` | (newly recorded) |
## RS-14 (2026-08-11) — Rotation-handling round: sideways-display detector + normalizer — authorised by the maintainer

Backlog item "rotated-MS handling". Premise fact-checked FIRST against real
code + the real fixture: Cambridge-style rotated MS (`0620_s16_ms_42.pdf`,
/Rotate=90 content pages, display upright) ALREADY worked (6/6 questions,
pinned rasters, visually upright) — the real gap was the home-rotated class
(someone sets /Rotate on upright-authored pages): rotated MCQ MS yielded 0/40
answers, rotated QP failed-closed rc=1 at S2 (has-ink dark=0.00000, 0 webps).

1. **core/page_rotation.py (NEW)** — word-geometry sideways detector
   (/Rotate≠0 AND display-mapped multi-letter words predominantly
   tall/votes≥5; measured 142:16…191:11 sideways on case-A vs 0:39…7:130 on
   the real ms_42 -> detector never touches Cambridge-style or rot=0 files) +
   normalizer = verbatim copy with the hint CLEARED via set_rotation(0)
   (insert_pdf + no_new_id=True; deterministic bytes; 15/15 fixed pages
   0.00000% pixel-diff vs the upright twin). Two inferior bake routes
   (show_pdf_page into page.rect — 2× pixmap RAM, worker SIGKILL −9 on a 2 GB
   box; into mediabox — 0.7× shrunk floating page, Q26 white crop) were
   measured and REJECTED. Deliberate abstains documented: mixed-evidence
   pages (0620 QP p16 Periodic Table, 43:143 — classifier removes it anyway),
   pure-raster pages (downstream QC backstop unchanged), ER PDFs (no rotated
   ER fixture exists).
2. **run_guarded.py** — one recorded seam in run_paper_stages: normalize QP
   + MS into <output>/.rotcache/<orig-sha16>__<name>.pdf AFTER
   state.register_paper (provenance keeps the user's ORIGINAL paths) and
   BEFORE the resume check, so low-ram and raw branches, parent and worker,
   all consume upright files. Identity scan still runs on the untouched
   input directory. No locked file touched anywhere (ms_cropping_engine,
   gold splitters/parsers, converter DPI, webp quality all pristine).
3. **tests/test_rotation_handling.py (NEW)** — 9 tests: detector on case-A
   synthetic (pages [1,2] / [1..15]) + case-B real fixture keep + rot=0
   passthrough same-path; normalized grid == original 40 answers (AADBC…);
   pixel-identity of every cleared page; byte-determinism + cache reuse;
   case-B gold-split regression pins (6 Qs, exact raster sizes); heavy
   BATCH_HEAVY E2E oracle (manual receipt: rotated bundle rc=0, 2× ALL
   GREEN, 40/40 webps byte-identical to the upright oracle, zero-drift
   125/125 on upright input with the fix live; logs under
   /home/user/rot_e2e/).

Full receipts: test-crops/redesign/ROTATION_ROUND_EVIDENCE.md.
Ledger 65->67.

| File | sha256 |
|---|---|
| `run_guarded.py` | `97ce057142068f79f0514872d36c3ae5348502f2e3f602ef8c56e5796ab86f08` | (was `46495102…`) |
| `core/page_rotation.py` | `bef080f7a041b124eda93f6240eba136deb60c9b4abfce7c89544d733d65f0f4` | (newly recorded) |
| `tests/test_rotation_handling.py` | `09be757417c952681e8019ec4efe396fafbcc05bc4fdcd9555e2ffb84fcaeb1e` | (newly recorded) |
## RS-15 (2026-08-11) — Proof-report round: single-file proof pack generator — authorised by the maintainer (standing approval)

Backlog item "run_proof.py / proof_report.html" (named hook survived in
tools/download_fixtures.py's fixture-era disclosure comment). Built exactly
that artifact.

1. **tools/run_proof.py (NEW)** — regenerates project/proof_report.html: a
   self-contained (inline CSS, zero JS, zero external references,
   test-pinned) HTML proof pack with seven sections, every figure computed
   FROM DISK at build time: S0–S8 contracts (from run_guarded.ALL_STAGES);
   live checks (ledger verify + triplet/multipage/RULE-6/chem-gold pins
   recomputed); 11-module suite table; sha256-pinned fixture inventory WITH
   ERA DISCLOSURE; deliverable stats; limitations (rotation abstains, heavy
   opt-ins, MCQ letter policy, locked constants, state-cutover phase-1);
   reproduce commands. `--check` = gate mode (exit 1 on any failing live
   check). Default build byte-deterministic (timestamp behind --stamp-now).
2. **tests/test_proof_report.py (NEW)** — 6 tests incl. determinism,
   no-external-resources, manifest row parity, narrow-suite override, and the
   anti-recursion contract (tests never invoke the default masthead through
   the tool; mirrored comment in MASTHEAD).

The generated proof_report.html ships in the deliverable zip but is not
ledgered (regenerable artifact). Masthead 98/98 OK (skipped=2 heavy opt-ins).
Receipts: test-crops/redesign/PROOF_REPORT_ROUND_EVIDENCE.md. Ledger 67->69.

| File | sha256 |
|---|---|
| `tools/run_proof.py` | `2d9bf89f620a37544e9a4690256433bb3856242dbe74ffd2198cf8ad9792ac79` | (newly recorded) |
| `tests/test_proof_report.py` | `2cecad8a79ee43399b5396d60dc0a6ea618ffe83cd2c0682b00413255031dadf` | (newly recorded) |

## RS-16 (2026-08-12) — Subject-coverage round: IGCSE+A-Level bio/chem/phys/maths run green — standing pre-approval

**Authority:** maintainer pre-approval + mega-spec. Full receipts:
`test-crops/redesign/RS161718_ROUND_EVIDENCE.md` (§1). Matrix 8/8 rc=0
ALL GREEN; 17 new real fixtures pinned (manifest regenerated);
portrait-era MS splitter added (fail-closed, QP-validated); RAM surgery
(spooling + malloc_trim) keeps 2GB-box peaks flat — byte-oracle 125/125
preserved after every memory change; ER monolithic-render OOM root-caused
and fixed (streaming tiles + per-source cache).

| `run_guarded.py` | `67a669c9bcb9f6f0ff138739fbdaa9805de427ddf5b90be82c08f4b0a781bdae` | (was `97ce057142068f79…`)
| `core/legacy_ms_split.py` | `5fb5fa01e21d18cc15473a35264d206eaf14e0a18008bb6dee621c000b042e0c` | (newly recorded)
| `tools/download_fixtures.py` | `e360df75b5aaa360b49932a2a622791bd75b0ba4492bfb92fa88d55a01181eaa` | (was `9352806a58b21e57…`)
| `tools/fixture_manifest.json` | `725d997e39c6ef14933ae5fd92ccca959ba8c9e9703b1a60317ebc0bbd2c6c21` | (was `e6d8f157682e8c85…`)

## RS-17 (2026-08-12) — Official-topic taxonomy (mega-spec Fixes 7/8/9/10) — standing pre-approval

**Authority:** mega-spec (maintainer) supersedes the old "configs never
content-modified" law for the named profiles. Official topic arrays only
(no numeric prefixes; 9702=25 / 0625=6 names verbatim from the spec);
question-level math routing with deterministic diagram evidence;
zero-evidence → REVIEW_REQUIRED (alphabetical fallback deleted);
`paper-N/loading` staging DELETED; Fix-10 year gate + no silent default
config; era years receipted (fixtures 2015/2016, user uploads 2025).

| `core/diagram_evidence.py` | `0e84a865b5785e48f0e0952275fe709dc44afc31f2d9ae6830edbac32010c9b6` | (newly recorded)
| `core/math_reference.py` | `732211330915cee2401348b9123c1c27d36325c1c820d8abe7e2a93794489ceb` | (newly recorded)
| `core/output_manager.py` | `753c45c2e5134a681c26a046b202c3d876f26245834f37a3a6c7f9ecb8386908` | (was `ae5e2c3b4f8705b0…`)
| `core/validation.py` | `3a1fd039e784e2d21d6dee3fc4c02e22753b9d0b5bfdf517cfd9121c705e1202` | (was `cbc16e5ee1001bd0…`)
| `references/Mathematics_9709 References.txt` | `a1a9dc362f6f6d91e4e9421029655947642d6beba455ce4f642494c0f6a05124` | (newly recorded)
| `subjects/A-Level/Mathematics_9709/config.json` | `ced59e5099207bca6a0ab5ae3b6248ccacd6864e522a3d2bc3b297fcf9aebd37` | (newly recorded)
| `subjects/A-Level/Further_Mathematics_9231/config.json` | `9b5ea066e9ba15a0cba5ee6c1ab8d6219e11106fd01f5637ed6ca2027918347e` | (newly recorded)
| `subjects/IGCSE/Mathematics_0580/config.json` | `9d8afd9b2b071dbb9e701e990f11dde635fc6c92303ab54655762cc02e89691d` | (newly recorded)
| `subjects/A-Level/Physics_9702/config.json` | `fdf07e23d40534ba0baf556552001f9be96c28491a72cffb1aacc440e97f794f` | (newly recorded)
| `subjects/IGCSE/Physics_0625/config.json` | `76c8ec03745a2319eb4ea5d3b7e2ee64a5590098b67a829d9d19fe7fdec5eb5a` | (newly recorded)
| `subjects/IGCSE/Biology_0610/config.json` | `eb5f415bf76f4fd2657c23ba315aa0af31e54645b6e849478f3375ddead4cc0b` | (newly recorded)
| `subjects/IGCSE/Chemistry_0620/config.json` | `44202ae7ebab82e07eb4daf2472d44dd618fb50a1422a716c9ae5dc482f3af9b` | (newly recorded)
| `subjects/A-Level/Biology_9700/config.json` | `0aa97dcc65ba404f2488b367015a9bf39fe6335ffe5e70cf9d06fe96c2e976d5` | (newly recorded)
| `subjects/A-Level/Chemistry_9701/config.json` | `be36101ec69be91ceffddf5c6848e834403e8bafca16b25d7a06b8375e4eb14b` | (newly recorded)
| `tests/test_math_taxonomy_rs17.py` | `924980c899cdada439d38305355a2474e685072912d67a474af4200588c51acb` | (newly recorded)
| `tests/test_confidence_gate_fixes.py` | `b2dd1b528068c22da023770e0c254d836436037c3adf027bf4a9fb4565ab0863` | (was `6b8a7490679ad30c…`)

## RS-18 (2026-08-12) — Mega-spec build-out in the production path (Fixes 1/4/5/6/12) — standing pre-approval

Strategy registry wired into S3; practical/essay → REVIEW_REQUIRED state;
statuses + flags (--workers/--resume/--retry-failed/--dry-run/
--fetch-missing-ms/--validate); ms_fetcher allowed-source order
(official Cambridge → pastpapers.co → approved; papers.co banned);
main.py delegates to the guarded production path (legacy body pinned
behind --legacy); proof pack writes proof_output/proof_manifest.json and
gains the live subject-coverage/strategy section; validator enforces the
no-loading contract.

| `core/strategies.py` | `11ed543ad5260a95c49fe31a62cb08944b671d116c541f016ab80039c7d292ff` | (newly recorded)
| `core/pipeline_state.py` | `1313b0c51aead206767c6633eaed5cec1c13e8d917de0bbdd371fe39419a2e45` | (was `f0dd8ca749833c2b…`)
| `core/ms_fetcher.py` | `fd2b8b80a417fc04f4db9a4a637fa9f455ec09d3b8fcebae6d0c969484bdd397` | (was `ea73680d543fcd3e…`)
| `main.py` | `6c86931cec82b1db5b78a9c24d3af7c00a02aeaa8abe0030965155312b7f123e` | (was `c78e0a6f2abc783d…`)
| `tools/run_proof.py` | `cbbb0e525ce8355ed1be8c3b2c4292b1cc29064bd3aadf640f3fc5e9496f0a32` | (was `2d9bf89f620a3754…`)
| `tests/test_rs16_subject_coverage.py` | `a950f198a0a2892868be40d76cd5830220d0f8249a7fc245ebfe14b626c603c0` | (newly recorded)
| `tests/test_spec_buildout_rs18.py` | `009d2c27f5c660b50e9a6aa0935f257bdbd42f10fc1c662a571c62df40e55f3f` | (newly recorded)

---

## RS-18b (2026-08-12) — ER tile-cache tempdir cleanup (S6 hook) — standing pre-approval

`/tmp` on the 2GB box must not accumulate 12-tile 70-page render copies;
`clear_er_tile_cache()` runs right after S6. No output-byte change
(proof: main.py delegated full mat_al rerun rc=0 post-change; oracle trees
are unaffected by temp-dir lifecycle).

| `run_guarded.py` | `5ad0067dc5a7c74dc53809cc1a0d88f9754ce8836c8ec35059495fd2ed14045a` | (was 67a669c9bcb9f6f0…) |
| `main.py` | `1f61f4ca20650df8ed18617398b59b50ae01932429fac35c88b7ae6c4c748241` | (was `6c86931cec82b1db…`) |

---

## RS-18c (2026-08-12) — S4 worker OOM: memory-headroom gate + /tmp orphan sweep — standing pre-approval

Root cause found via live RSS watcher + dmesg: the kernel killed a 738MB
S4/S5 worker at MemAvailable=3.8MB (bio_ig batch, deterministic rc=1 ~7.7s
after download) while /tmp (tmpfs = real RAM) held ~830MB of debris from
crashed runs. Fix in `run_guarded.py`: `_wait_for_memory_headroom` gates
every worker spawn on /proc/meminfo (820MB budget + 260MB reserve, hard
60s timeout with diagnostics instead of an OOM coin-flip) and
`_purge_er_tile_orphans` sweeps `/tmp/er_tiles_*` dirs left by crashed
workers before AND after each spawn. No output-byte change (gating only);
full 8-batch matrix re-run green 8/8 rc=0 post-fix
(bio_ig 619w, che_ig 52w, phy_ig 647w, mat_ig 394w, bio_al 624w,
che_al 609w, phy_al 636w, mat_al 287w).

| `run_guarded.py` | `95f736043c316753092589b97fb8ea78efcc6305f1f68c1f8c7542bdce9eac5e` | (was `5ad0067dc5a7c7…`) |

## RS-19 (2026-08-12) — final completion hardening

The production runner now distinguishes a clean run from a safe run with
`review_required` output: child workers exit zero so the parent can complete
S6–S8, while the top-level guarded runner and audit-only validator return exit
code 2. The batch runner also audits/resurfaces unresolved review state on
resume instead of returning early as if the tree were complete.

Missing-MS retrieval now refreshes preflight automatically when explicitly
requested, parses official Cambridge past-paper index pages before trying the
approved `pastpapers.co` mirror, verifies cache hits, and includes the working
session-directory mirror pattern. The formal profile registry is populated
from validated configs. IGCSE Additional Mathematics 0606 is included with
2025–2027 official names and question-level math routing. Chemistry 9701
question evidence was expanded for real MCQ chemistry concepts; the classifier
now routes the tested 40-question 9701 MCQ paper without review fallbacks.

| `run_guarded.py` | `bea3740a1f9d47d6b3b8bdc4bedfaf65c577ac0958084a587831dc8bd658f843` | (was `95f736043c316753…`) |
| `run_pipeline.py` | `52bc0afe31ff42aeefce3255cd552d11faf1aa055482bf1d3d93c1ce9eff78c0` | (was previously recorded) |
| `main.py` | `3e9c7d8dd83f561d528b9a0e9e013390ed55fb467442b3052ec15b0d694699a5` | (was `1f61f4ca20650df…`) |
| `core/batch_runner.py` | `6194230f064fd8bff69e1994aad01071ff802b2c659f7fc178400e31f83bb9df` | (new amendment) |
| `core/config_loader.py` | `6b86dfb147a405ec474a2aef9a7e1c5e8004e49e37a65fe1cece73f1d5160762` | (was previously recorded) |
| `core/classifier.py` | `9bd3de55b21e97c65712a7e25b286e1843e4bc364e85ab9c9a7d24d5b367782b` | (was previously recorded) |
| `core/math_reference.py` | `2c1e3d514087451408b5a194952bf0b68ab78a947c5c1fa15d3ad552d6f4e3ab` | (was previously recorded) |
| `core/ms_fetcher.py` | `7148ebd2533414d9556c14229842500a3ece1ec4f2570e9950c020264a44513a` | (was previously recorded) |
| `profiles/registry.py` | `89ac481aefc8a898b48625f94b51e1081779e988d9385d89f830bf04759d7475` | (new amendment) |
| `profiles/config_profile.py` | `b042dcef433159b1c4fec507011216054871e02a158b6623a7f05c8f551fa4cd` | (new amendment) |

The 0606 and Chemistry profile JSON files are covered by the shipped project
configuration audit; they are not in the historical code-only ledger prefix.

## RS-19a (2026-08-12) — post-proof wiring pins

The missing-MS resolver's real-download path is pinned after the canonical
session-directory retrieval proof; the proof generator's live profile table
now includes IGCSE Additional Mathematics 0606.

| `core/ms_fetcher.py` | `080d03fceb495b134bd676f22d63228fa5979997c22f9aa8ce26bc8f60b69905` | (was `7148ebd2533414d…`) |
| `tools/run_proof.py` | `65ff4616ca43431a8067c835826574881d31b6142a48d877e42454ebbbc6bdb1` | (new amendment) |

## RS-19b (2026-08-12) — explicit 0606 component guard

Additional Mathematics 0606 cannot fall through the legacy component-category
API and receive a paper-number pseudo-topic; that API now returns no category
and the question-level official-topic path remains the only production route.
The shared math reference module documentation was updated to describe all
supported mathematics profiles.

| `core/math_category.py` | `317b64dba5c53da9e9ced4e56672a2cea44c4ca2b7502971effcea04ab726099` | (new amendment) |
| `core/math_reference.py` | `92063c5f309864eb9cd6639e8f93c62d2ae09268ec3253b132f12275493e68e6` | (was `2c1e3d5140874514…`) |

## RS-19c (2026-08-12) — configured demo coverage

The deterministic demo generator now includes all 24 validated configured
syllabus codes, including 0606, 0610, 0625, 9700, 9701, and 9702. Demo PDFs
remain smoke fixtures only; production completion still requires real-paper
processing and the guarded audit.

| `main.py` | `c26b45d7dead43933ffcd7700a0b55b2cf0b8fd071ebe4d16cd4fda44fd0c056` | (was `3e9c7d8dd83f561d…`) |

## RS-20 (2026-08-12) — IGCSE low-RAM crop recovery

Real older IGCSE MCQ PDFs exposed a crop-stage defect: duplicate answer-row
numbers could win over the true top-level marker, so the vector-first cropper
jumped from Q4 and attempted one enormous final segment. Question selection now
uses document order before local score. This was proven on real 0610, 0620,
and 0625 2016 papers: all 40 QP markers are recovered and crops are written.

The batch runner now disposes of the worker process after every bundle even
when `--workers 1`; this prevents native PDF/image allocations from surviving
into the next IGCSE paper. The older portrait 0580 mark-scheme grammar also
gets a strict QP-proven Question-column fallback, recovering all 24 MS crops
instead of accepting only the first 11.

| `core/vector_first_cropper.py` | `28991113a88c8a63b05d1b54dd46cb5c705b2030fcbada9a81a774affd13f65c` | (new amendment) |
| `core/legacy_ms_split.py` | `141be7ce56a16be3071e1d839727b3e5979d103e19a2223084e67ec85400823e` | (was `5fb5fa01e21d18cc…`) |
| `core/batch_runner.py` | `b08a4d594d98bc408559e5c8b309a0db15193fed9d2e7c88f88e88ec46ce40cf` | (was `6194230f064fd8b…`) |
| `run_guarded.py` | `0ef8fd3dbf137b69df8b4207a59ef3e7a3034017f6243d40e848b7c4c5e7a332` | (was `bea3740a1f9d47d…`) |
| `tests/test_igcse_low_ram_crop.py` | `1071cfac02203c90a718748e345def301405e1aea78fe5262a2da677cf09b4c6` | (new amendment) |

## RS-20a (2026-08-12) — dead-worker DB repair

If an isolated worker is killed before its own exception handler runs, the
parent now marks that bundle FAILED in SQLite. It is therefore retryable and
cannot remain stuck in PROCESSING after an OOM or broken child process.

| `core/batch_runner.py` | `48a973f476bc8bcd636e5082ef2414865521e78e321a4a9edbc4e5f730717110` | (was `b08a4d594d98bc4…`) |

## RS-20b (2026-08-12) — IGCSE regression proof pin

The proof masthead now executes the new low-RAM IGCSE marker and portrait-MS
regressions rather than leaving those fixes outside the release evidence.

| `tools/run_proof.py` | `bb7c53c3d067e1a1cd8e36a3ab0e029f680e25741fc5c233c53bf822532f3edd` | (was `65ff4616ca43431…`) |

## RS-21 (2026-08-12) — all-year processing policy

Every configured syllabus code now accepts any four-digit paper year for
processing. Declared syllabus editions remain verified and can complete
normally. An undeclared historical or future year is explicitly bound to
`SYLLABUS_YEAR_UNVERIFIED`: crops and evidence are committed, but the bundle
is REVIEW_REQUIRED and never reported clean. This replaces the previous
pre-crop S1 abort that made valid older/newer papers appear not to work.

Biology 0610 is pinned to the official 21-topic structure and its current
2023–2028 editions, while historical receipts 2015–2016 remain accepted.

| `main.py` | `daca137c7f5551e856740d5e7adb68f5d5ab5c83c4b1f0f2b80aaccca3073115` | (was `c26b45d7dead439…`) |
| `run_guarded.py` | `c053717667cef24cfeddc67147b99c1539ff134e6ba91706ddac36f35d343f3f` | (was `0ef8fd3dbf137b…`) |
| `core/config_loader.py` | `f52b9854ad9092427aa70770a5bc8eef130bf15c70ab4c32351c82366abef4a7` | (was previously recorded) |
| `core/bundle_worker.py` | `15958b9246c857441d0dc234181bb749d0e63d16936440bf93a000ea7b75d7a0` | (new amendment) |
| `tests/test_confidence_gate_fixes.py` | `d9f18eea43f528c4130aec405ea3079de05b38088f8a3aca883203fe2d2696e7` | (was previously recorded) |
| `tests/test_math_taxonomy_rs17.py` | `24454420f80ff8c07f484a72fd28f790335bca51f40f9c30236ab96e3a7bbca5` | (was previously recorded) |

## RS-22 (2026-08-12) — real subject/year matrix proof

A real 19-bundle matrix across nine configured subject codes and fixture years
2015/2016/2023 was run. The first pass exposed and fixed the 9709 reference
alias `Energy,_work_and_power` → `Energy_work_and_power`; the failed bundle was
retried successfully. Final status: 8 clean, 11 review-required, 0 failed,
378 questions saved. The report is `all_subject_year_proof.md`.

| `core/math_reference.py` | `055c86d79499558da5382a443218b226847adaaf7b8973280bc02d5ef2dc5a3d` | (was `92063c5f309864e…`) |

## RS-23 (2026-08-12) — IGCSE Chemistry Papers 5 and 6

IGCSE science Practical and Alternative-to-Practical components are now
profiled for 0610/0620/0625. They use the validated numbered structured QP/MS
splitters rather than being rejected at S3. Real Chemistry 0620 May/June 2024
fixtures proved:

```text
Paper 4 (42): 6 questions, 0 review, exit 0
Paper 5 (52): 3 questions, 0 review, exit 0
Paper 6 (62): 4 questions, 0 review, exit 0
```

Other practical/essay formats still fail closed unless their profile is
explicitly validated; no universal parser is silently reused.

| `core/strategies.py` | `c9279b7ad04c4322ff717bd474da67aad0f7c770dff47e7e74207191b0286342` | (new amendment) |
| `tools/run_proof.py` | `7a7e0f0ad25dbfc94bbc3f65edc50bfb82def6daa281ea43d620ee7c4dc1a08f` | (was `bb7c53c3d067e1a…`) |
| `tests/test_spec_buildout_rs18.py` | `2e4ebec17cbf3b76b7e7f4df4b7a9904efd9a1e879444bc19cce7213fa459c88` | (was previously recorded) |
