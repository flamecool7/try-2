"""
RS-15: tools/run_proof.py — single-file proof-pack generator.

Safety contract enforced here: these tests only ever invoke run_proof with
--no-suite or a narrow --suite-modules override — NEVER the default masthead
— so the suite can never recursively invoke the tool that is measuring it
(mirrored in tools/run_proof.py's MASTHEAD comment).
"""
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
TOOL = PROJ / "tools" / "run_proof.py"
LOCK_DOCS = ["CROPPING_LOCK.md", "ROUTING_STATE_LOCK.md", "CLASSIFICATION_LOCK.md",
             "EXAMINER_REPORT_LOCK.md", "EFFICIENCY_AUDIT.md"]
PREFIXES = ("core/", "main.py", "run_guarded.py", "run_pipeline.py", "pipeline.py",
            "tools/", "tests/", "engine/", "profiles/", "parsers/", "original_reference/")


def ledger_total():
    """Independent re-parse (kept deliberately separate from the tool's)."""
    row_re = re.compile(r"^\| `([^`]+)` \| `?([0-9a-f]{64})`?", re.M)
    latest = {}
    for doc in LOCK_DOCS:
        for p, _h in row_re.findall((PROJ / doc).read_text(encoding="utf-8")):
            if p.startswith(PREFIXES):
                latest[p] = True
    return len(latest)


class TestProofReport(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="proofrep_"))
        self.out = self.tmp / "proof.html"

    def gen(self, *extra, check=True):
        cmd = [sys.executable, str(TOOL), "--output", str(self.out)] + list(extra)
        if check:
            cmd.append("--check")
        return subprocess.run(cmd, cwd=str(PROJ), capture_output=True, text=True, timeout=900)

    def test_generates_passing_selfcontained_report(self):
        proc = self.gen("--no-suite")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        markup = self.out.read_text(encoding="utf-8")
        for marker in ("Proof Report", "PASS — all live checks green",
                       "S8", "final validation + output audit",
                       "lock ledger", "00cc779e", "b69285ee",
                       "Limitations", "download_fixtures.py",
                       "cambridge-topical-generator-final.zip"):
            self.assertIn(marker, markup)
        n = ledger_total()
        self.assertIn(f"{n}/{n} files verified", markup)

    def test_deterministic_bytes_by_default(self):
        a, b = self.tmp / "a.html", self.tmp / "b.html"
        for tgt in (a, b):
            proc = subprocess.run([sys.executable, str(TOOL), "--output", str(tgt),
                                   "--no-suite", "--check"],
                                  cwd=str(PROJ), capture_output=True, text=True, timeout=900)
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertEqual(hashlib.sha256(a.read_bytes()).hexdigest(),
                         hashlib.sha256(b.read_bytes()).hexdigest())

    def test_no_external_resources(self):
        self.assertEqual(self.gen("--no-suite").returncode, 0)
        markup = self.out.read_text(encoding="utf-8")
        for pat in ("<script", "<link", 'src="http', "src='http", "url(http",
                    "@import", "<iframe"):
            self.assertNotIn(pat, markup)
        self.assertTrue(markup.startswith("<!DOCTYPE html>"))
        self.assertIn("<style>", markup)          # inline CSS only

    def test_fixture_rows_match_manifest(self):
        self.assertEqual(self.gen("--no-suite").returncode, 0)
        markup = self.out.read_text(encoding="utf-8")
        man = json.loads((PROJ / "tools" / "fixture_manifest.json").read_text())
        expect = len(man.get("fixtures", [])) + len(man.get("local", []))
        for entry in man.get("fixtures", []):
            self.assertIn(Path(entry["file"]).name, markup)
        self.assertIn(f"{expect} fixtures.", markup)

    def test_narrow_suite_override_runs_and_reports(self):
        proc = self.gen("--suite", "--suite-modules", "tests.test_page_classifier")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        markup = self.out.read_text(encoding="utf-8")
        self.assertIn("tests.test_page_classifier", markup)
        self.assertIn("unittest masthead", markup)
        self.assertIn(">OK</td>", markup)
        self.assertIn("currently 12 tests" if False else "12</td>", markup)  # 12 page-classifier tests

    def test_stamp_now_flag(self):
        proc = self.gen("--no-suite", "--stamp-now")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertIn("(UTC)", self.out.read_text(encoding="utf-8"))
        proc2 = self.gen("--no-suite")
        self.assertNotIn("(UTC)", self.out.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
