#!/usr/bin/env python3
"""Unified-MCQ round — regression suite (Overseer unified-MCQ spec;
approved Q1 adopt_hybrid / Q2 additive / Q3 literal-writer / Q4 adapt).

U1  STEP-7 audit pins: retired MCQ stores stay retired (grep-based, comments
    excluded) — registry is the ONLY MCQ authority (RULE 1).
U2  Consistency sweep: for EVERY (code, component) in IGCSE_COMPONENT_MAP,
    resolve_paper_format=="MCQ" <=> registry.is_mcq — folder names therefore
    byte-identical to RS-7 (P1_MCQ/P2_MCQ/P5_Practical/P6_ATP/P1_Essay…).
U3  A-Level deltas pinned: 9608/9696 P1 now STRUCTURED (registry), 9990
    present; unmapped code -> STRUCTURED; golden codes unchanged.
U4  detect_mcq registry fast-path + counts via registry (0455 -> 30).
U5  is_mcq_paper: registry branch (0620 P2 now MCQ — legacy P1-only fixed);
    content-signal fallback preserved for unmapped codes.
U6  Classified MCQ save: folder gets QP webp ONLY + metadata (ms_answer kept
    + question_type/correct_answer additive) + _MS.txt single letter;
    validator ACCEPTS; tamper txt -> mismatch flagged; letter-strip -> ms_answer
    missing flagged (RS-7 parity).
U7  Q3-literal: ms_answer=None on an MCQ paper -> EMPTY _MS.txt written +
    validator flags visibly (never silently OK, never skipped file).
U8  UNC path: lettered MCQ classification_failed gets _MS.txt (validator
    accepts + cross-checks); no_markscheme MCQ UNC allows single _MS.txt,
    rejects webp contradiction.
U9  Gold cross-check receipt: markscheme_gold._is_mcq_paper agrees with the
    registry for its OWN (P1) domain; divergence on IGCSE P2 is expected and
    receipted (gold router serves gold-internal legacy flows only; the RS-7
    extraction adapter bypasses the router).
U10 Spec STEP-8 truth table (28 is_mcq + 4 counts) re-run here so the full
    unittest suite owns it permanently.
"""
import json
import re
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.mcq_registry import (is_mcq, get_expected_question_count,   # noqa: E402
                               get_all_mcq_codes, MCQ_COMPONENTS)
from core.paper_identifier import (resolve_paper_format,               # noqa: E402
                                   expected_question_count,
                                   IGCSE_COMPONENT_MAP)
from core.mcq_support import detect_mcq, is_mcq_paper                 # noqa: E402
from core.output_manager import OutputManager, _paper_type_folder     # noqa: E402
from core.mcq_output import (write_mcq_ms, validate_mcq_ms_file,      # noqa: E402
                             build_mcq_question_id, mcq_metadata_fields)


class U1AuditPins(unittest.TestCase):
    def test_retired_stores_have_no_live_refs(self):
        dead = ["_ALEVEL_MCQ_P1_SYLLABI", "IGCSE_QUESTION_COUNT",
                "ALEVEL_MCQ_QUESTION_COUNT", "_MCQ_P1_SYLLABI", "_MCQ_SYLLABI"]
        live = []
        for f in (PROJ / "core").glob("*.py"):
            if f.name in ("mcq_registry.py", "markscheme_gold.py"):
                continue  # registry = the store itself; gold stays UNTOUCHED
                # (its internal legacy router is cross-checked in U9)
            for i, line in enumerate(f.read_text().splitlines(), 1):
                code = line.split("#", 1)[0]
                if any(d in code for d in dead):
                    live.append(f"{f.name}:{i}: {line.strip()[:60]}")
        self.assertEqual(live, [], live)

    def test_no_spec_huntlist_patterns(self):
        # spec STEP-7 hunt list — must not appear as detection anywhere
        pats = [r'paper_number == 1', r'paper_number == "1"',
                r'variant\.startswith\("1"\)']
        hits = []
        for f in list((PROJ / "core").glob("*.py")) + [PROJ / "main.py",
                                                       PROJ / "run_guarded.py"]:
            for i, line in enumerate(f.read_text().splitlines(), 1):
                if line.strip().startswith("#"):
                    continue
                for p in pats:
                    if re.search(p, line):
                        hits.append(f"{f.name}:{i}")
        self.assertEqual(hits, [], hits)


class U2ConsistencySweep(unittest.TestCase):
    def test_map_vs_registry_mcq_agree_on_every_mapped_component(self):
        mism = []
        for code, comps in IGCSE_COMPONENT_MAP.items():
            for comp in comps:
                resolver = resolve_paper_format(code, comp) == "MCQ"
                registry = is_mcq(code, comp)
                if resolver != registry:
                    mism.append((code, comp, resolver, registry))
        self.assertEqual(mism, [], mism)

    def test_folder_names_byte_stable_vs_rs7_expectations(self):
        # spot truth table incl. all format families (RS-7 receipts)
        cases = [("0620", "12", "P1_MCQ"), ("0620", "22", "P2_MCQ"),
                 ("0620", "42", "P4_Structured"), ("0620", "52", "P5_Practical"),
                 ("0620", "62", "P6_ATP"), ("0470", "12", "P1_Essay"),
                 ("0610", "23", "P2_MCQ"), ("0455", "12", "P1_MCQ"),
                 ("0455", "22", "P2_Structured"), ("0580", "22", "P2_Structured"),
                 ("9701", "12", "P1_MCQ"), ("9701", "22", "P2_AS_Structured"),
                 ("9708", "13", "P1_MCQ")]
        for code, comp, want in cases:
            self.assertEqual(_paper_type_folder(comp, code), want,
                             f"{code}/{comp}")


class U3AlevelDeltas(unittest.TestCase):
    def test_deltas_pinned(self):
        self.assertFalse(is_mcq("9608", "11"))   # delta D1 (was MCQ pre-round)
        self.assertFalse(is_mcq("9696", "11"))   # delta D1
        self.assertEqual(resolve_paper_format("9608", "12"), "STRUCTURED")
        self.assertFalse(is_mcq("9990", "11"))   # RS-13 resolved: spec-asserted, Cambridge-FALSE (no MCQ in 9990)
        self.assertEqual(resolve_paper_format("9999", "11"), "STRUCTURED")
        self.assertTrue(is_mcq("9701", "13"))
        self.assertEqual(resolve_paper_format("9702", "11"), "MCQ")
        self.assertEqual(expected_question_count("9708", "MCQ", "11"), 30)
        self.assertIsNone(expected_question_count("0580", "STRUCTURED", "22"))


class U4U5Detection(unittest.TestCase):
    def test_detect_mcq_registry_fastpath(self):
        info = detect_mcq(paper_meta={"syllabus_code": "0455", "variant": "12"})
        self.assertTrue(info.is_mcq)
        self.assertEqual(info.question_count, 30)
        self.assertEqual(info.confirmed_by, ["mcq_registry"])

    def test_detect_mcq_registry_negative(self):
        info = detect_mcq(paper_meta={"syllabus_code": "0580", "variant": "22"})
        self.assertFalse(info.is_mcq)
        self.assertEqual(info.confirmed_by, ["mcq_registry"])

    def test_is_mcq_paper_registry_branch(self):
        self.assertTrue(is_mcq_paper("0620", "22"))    # P2! legacy rule missed
        self.assertTrue(is_mcq_paper("9701", "12"))
        self.assertFalse(is_mcq_paper("0580", "22"))
        self.assertFalse(is_mcq_paper("9608", "12"))   # delta D1

    def test_is_mcq_paper_content_fallback_preserved(self):
        sample = ("multiple choice answer sheet there are forty questions. "
                  "four possible answers a, b, c and d")
        self.assertTrue(is_mcq_paper("9999", "99", sample))


def _fake_config(tmp):
    return SimpleNamespace(
        subject="Chemistry_0620", level="IGCSE", syllabus_code="0620",
        board="CIE", major_topics=["Stoichiometry"],
        detailed_topics=["Stoichiometry"])


def _fake_qp():
    from PIL import Image
    return SimpleNamespace(assembled_image=Image.new("RGB", (2280, 400), "white"),
                           question_number="Q1", number_int=1, marks=1,
                           text="Which gas?")


def _fake_matched(**kw):
    base = dict(question_number="Q1", number_int=1,
                qp=_fake_qp(), ms=None, paper_code="0620_s16_22",
                full_qp_code="0620_s16_qp_22", full_ms_code="0620_s16_ms_22",
                year="2016", season="Summer", variant="22", subject="Chemistry")
    base.update(kw)
    return SimpleNamespace(**base)


def _fake_classification():
    return SimpleNamespace(winning_major="Stoichiometry",
                           detailed_topics=["Stoichiometry"],
                           fallback_tier="scored")


class U6ClassifiedWrite(unittest.TestCase):
    def test_letter_mcq_folder_full_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_fake_matched(ms_answer="B"),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            self.assertIn("P2_MCQ", str(qf))
            self.assertEqual([p.name for p in qf.glob("*.webp")],
                             ["22_Summer_2016_Q1.webp"])
            txt = qf / "22_Summer_2016_Q1_MS.txt"
            self.assertTrue(txt.exists())
            self.assertEqual(txt.read_text(), "B\n")
            self.assertIsNone(saved["ms"])
            self.assertEqual(saved["ms_txt"], txt)
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(md["paper_format"], "MCQ")
            self.assertEqual(md["ms_answer"], "B")          # locked key kept
            self.assertEqual(md["question_type"], "MCQ")    # RULE 5 additive
            self.assertEqual(md["correct_answer"], "B")     # RULE 5 additive
            from core.validation import FinalValidator
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            v.check_qp_ms_pairing_new()
            self.assertEqual(v.errors, [], v.errors)

    def test_tampered_txt_flagged_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_fake_matched(ms_answer="B"),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            (qf / "22_Summer_2016_Q1_MS.txt").write_text("D\n")
            from core.validation import FinalValidator
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertTrue(any("_MS.txt letter D != metadata ms_answer B" in e
                                for e in v.errors), v.errors)


class U7EmptyRule(unittest.TestCase):
    def test_none_answer_writes_empty_txt_and_validator_flags(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_fake_matched(ms_answer=None),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            txt = qf / "22_Summer_2016_Q1_MS.txt"
            self.assertTrue(txt.exists())                 # Rule 3: never skip
            self.assertEqual(txt.read_text(), "")         # empty per literal
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(md["question_type"], "MCQ")
            self.assertEqual(md["correct_answer"], "")    # RULE 5 shape
            self.assertNotIn("ms_answer", md)
            from core.validation import FinalValidator
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertTrue(any("ms_answer" in e for e in v.errors), v.errors)

    def test_structured_untouched(self):
        with tempfile.TemporaryDirectory() as tmp:
            from PIL import Image
            ms = SimpleNamespace(assembled_image=Image.new("RGB", (2280, 200),
                                                          "white"),
                                 question_number="Q1", number_int=1, text="B")
            saved = OutputManager(output_root=str(Path(tmp) / "out")).save_question_pair(
                _fake_matched(ms=ms, paper_code="0580_s16_22",
                              full_qp_code="0580_s16_qp_22"),
                _fake_classification(),
                SimpleNamespace(subject="Mathematics_0580", level="IGCSE",
                                syllabus_code="0580", board="CIE",
                                major_topics=["Stoichiometry"],
                                detailed_topics=["Stoichiometry"]))
            qf = Path(saved["question_folder"])
            self.assertEqual(sorted(p.name for p in qf.glob("*")),
                             ["22_Summer_2016_Q1.webp",
                              "22_Summer_2016_Q1_MS.webp", "metadata.json"])
            self.assertEqual(list(qf.glob("*_MS.txt")), [])


class U8UncPath(unittest.TestCase):
    def _save_unc(self, tmp, **kw):
        mgr = OutputManager(output_root=str(Path(tmp) / "out"))
        return mgr.save_uncategorized_question(
            _fake_matched(**kw), "classification_failed", _fake_config(tmp))

    def test_unc_lettered_mcq_gets_txt(self):
        with tempfile.TemporaryDirectory() as tmp:
            saved = self._save_unc(tmp, ms_answer="C")
            qf = Path(saved["question_folder"])
            txt = qf / "22_Summer_2016_Q1_MS.txt"
            self.assertTrue(txt.exists())
            self.assertEqual(txt.read_text(), "C\n")
            from core.validation import FinalValidator
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v._check_uncategorized_folder(qf)  # white-box UNC check entry
            self.assertEqual(v.errors, [], v.errors)


class U9GoldCrossCheck(unittest.TestCase):
    def test_gold_router_agrees_on_its_own_domain(self):
        from core.markscheme_gold import _is_mcq_paper as gold
        # gold routes P1 only; registry agrees for every gold-P1-MCQ code
        for code in ("9701", "9702", "9700", "9708"):
            self.assertTrue(gold("12", syllabus=code))
            self.assertTrue(is_mcq(code, "12"))
        # documented divergence: gold returns False for IGCSE P2 (22) —
        # receipted: the RS-7 extraction adapter bypasses the router.
        self.assertFalse(gold("22", syllabus="0620"))
        self.assertTrue(is_mcq("0620", "22"))


class U10SpecTruthTable(unittest.TestCase):
    def test_all_32_registry_assertions(self):
        rows_true = [("9701", "11"), ("9701", "12"), ("9701", "13"),
                     ("9700", "11"), ("9702", "12"), ("9708", "11"),
                     ("0620", "11"), ("0620", "12"), ("0620", "21"),
                     ("0620", "22"), ("0610", "21"), ("0625", "22"),
                     ("0455", "11"), ("5070", "11"), ("5054", "12"),
                     ("5090", "13"), ("2281", "11")]
        rows_false = [("9701", "21"), ("9701", "41"), ("9709", "11"),
                      ("9708", "21"), ("0620", "31"), ("0620", "41"),
                      ("0580", "11"), ("0606", "11"), ("0455", "21"),
                      ("0478", "11"), ("4024", "11")]
        for code, comp in rows_true:
            self.assertTrue(is_mcq(code, comp), f"{code}/{comp}")
        for code, comp in rows_false:
            self.assertFalse(is_mcq(code, comp), f"{code}/{comp}")
        self.assertEqual(get_expected_question_count("9701", "11"), 40)
        self.assertEqual(get_expected_question_count("0620", "21"), 40)
        self.assertEqual(get_expected_question_count("0455", "11"), 30)
        self.assertEqual(get_expected_question_count("9708", "11"), 30)
        codes = get_all_mcq_codes()
        self.assertNotIn("9990", codes)  # RS-13: removed (Cambridge-verified no MCQ)
        self.assertNotIn("9709", codes)
        self.assertEqual(len(MCQ_COMPONENTS), 35)  # 14 A-Level + 14 IGCSE + 8 O-Level - 1 (9990 resolved out, RS-13)


if __name__ == "__main__":
    unittest.main(verbosity=2)
