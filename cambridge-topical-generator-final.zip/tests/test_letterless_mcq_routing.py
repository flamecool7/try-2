#!/usr/bin/env python3
"""RS-13 letterless-MCQ topic routing tests (mandated deeper variant).

Pins the main.py routing change: a letterless MCQ question reaches the topic
folder under strong classification (not Uncategorized), and every loud
surface survives — empty _MS.txt, absent ms_answer, validator error.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.output_manager import OutputManager  # noqa: E402
from tests.test_mcq_unified import _fake_classification, _fake_config, _fake_matched  # noqa: E402


class TestLetterlessMcqRouting(unittest.TestCase):
    def test_letterless_mcq_lands_in_topic_folder_with_loud_surface(self):
        # This replicates the exact post-RS-13 main.py decision path:
        # valid_matched now CONTAINS letterless questions; classification
        # decides the folder (CLS-4 desperate tiers alone route Uncategorized).
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_fake_matched(ms_answer=None),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            self.assertIn("Stoichiometry", qf.parts[-2], qf)          # topic routed
            self.assertNotIn("Uncategorized", qf.parts, qf)           # NOT exiled
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(md["paper_format"], "MCQ")
            self.assertEqual(md["question_type"], "MCQ")
            self.assertEqual(md["correct_answer"], "")                # loud emptiness
            self.assertNotIn("ms_answer", md)
            txt = list(qf.glob("*_MS.txt"))
            self.assertTrue(txt and txt[0].read_text() == "")         # Rule 3 empty file
            from core.validation import FinalValidator
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertTrue(any("ms_answer" in e for e in v.errors),
                            "RS-7 negative gate must still fire for letterless MCQ")

    def test_lettered_mcq_still_routes_identically(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_fake_matched(ms_answer="C"),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            self.assertIn("Stoichiometry", qf.parts[-2], qf)
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(md["ms_answer"], "C")
            txt = list(qf.glob("*_MS.txt"))
            self.assertEqual(txt[0].read_text(), "C\n")

    def test_main_py_gate_source_pinned(self):
        """The routing line itself: matched list is no longer filtered on letters."""
        src = (PROJ / "main.py").read_text(encoding="utf-8")
        self.assertNotIn("if m.ms_answer is not None]", src)
        self.assertIn("valid_matched = list(matched_questions)", src)
        self.assertIn("LETTERLESS question(s)", src)


if __name__ == "__main__":
    unittest.main()
