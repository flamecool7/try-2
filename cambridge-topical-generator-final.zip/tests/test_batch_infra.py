#!/usr/bin/env python3
"""Batch-infrastructure round — regression suite (spec Steps 1-5).

Fast tiers (always run, seconds):
  T1  Database: schema + WAL, FK-preserving re-register (spec's INSERT OR
      REPLACE would mint a new rowid and orphan bundle FKs — proof of fix),
      bundle lifecycle, question_exists constant-time duplicate index.
  T2  Preflight on REAL fixtures: 2-bundle grouping, two-pass ER attach
      (spec's single-pass order bug — `*_er.pdf` sorts before `*_qp_*.pdf`),
      re-run idempotence (0 new bundles).
  T3  StagedWriter: staging creation, commit moves bytes, identical-dest
      idempotent skip, differing-dest aborts commit (fail-closed).

Heavy tiers (skipUnless BATCH_HEAVY=1; real end-to-end proofs, minutes):
  T4  process_bundle on the real 0620 MCQ pair: staged -> review_required
      (this paper's QC flags) -> committed P2_MCQ tree + DB rows; second
      invocation short-circuits on resume semantics.
  T5  run_pipeline CLI-equivalent: dry-run, then workers=1 over the real
      input (0620 MCQ + 9700 structured), final audit green.
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

FIXTURES = PROJ.parent / "test-crops" / "fixtures"
HEAVY = os.environ.get("BATCH_HEAVY") == "1"


def _mcq_input(tmp):
    d = Path(tmp) / "input"
    d.mkdir(parents=True, exist_ok=True)
    shutil.copy(FIXTURES / "remote" / "0620_s16_qp_22.pdf", d)
    shutil.copy(FIXTURES / "remote" / "0620_s16_ms_22.pdf", d)
    return d


def _mixed_input(tmp):
    d = _mcq_input(tmp)
    for name in ("9700_m25_qp_22.pdf", "9700_m25_ms_22.pdf", "9700_m25_er.pdf"):
        shutil.copy(FIXTURES / "local" / name, d)
    return d


# ---------------------------------------------------------------------------
# T1 — Database (spec STEP 1 + fix proofs)
# ---------------------------------------------------------------------------
class T1Database(unittest.TestCase):
    def setUp(self):
        from core.database import Database
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "t.sqlite")
        # a real file to register
        self.f = Path(self.tmp.name) / "x.pdf"
        self.f.write_bytes(b"%PDF-fake")

    def tearDown(self):
        self.tmp.cleanup()

    def test_spec_step1(self):
        self.db.print_progress()  # spec's exact smoke call

    def test_schema_and_wal(self):
        con = sqlite3.connect(self.db.db_path)
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertLessEqual({"files", "bundles", "questions", "artifacts", "errors"}, tables,
                            f"schema tables missing (sqlite_sequence extra is expected): {tables}")
        mode = con.execute("PRAGMA journal_mode").fetchone()[0]
        self.assertEqual(mode.lower(), "wal")
        con.close()

    def test_reregister_preserves_rowid(self):
        id1 = self.db.register_file(self.f, "qp", "0620", "s", "16", "22", "MCQ")
        bid = self.db.create_bundle("0620_s16_22", "0620", "Chemistry_0620",
                                    "IGCSE", "s", "16", "22", "MCQ",
                                    qp_file_id=id1, ms_file_id=None, er_file_id=None)
        self.f.write_bytes(b"%PDF-fake-v2")  # new bytes, same path
        id2 = self.db.register_file(self.f, "qp", "0620", "s", "16", "22", "MCQ")
        self.assertEqual(id1, id2, "rowid must survive re-register (spec's INSERT OR REPLACE would break it)")
        rows = self.db.get_pending_bundles()
        self.assertEqual(rows[0]["qp_path"], str(self.f))  # join still resolves

    def test_bundle_lifecycle(self):
        fid = self.db.register_file(self.f, "qp", "9700", "m", "25", "22", "STRUCTURED")
        bid = self.db.create_bundle("9700_m25_22", "9700", "Biology_9700",
                                    "A-Level", "m", "25", "22", "STRUCTURED",
                                    qp_file_id=fid, ms_file_id=None, er_file_id=None)
        self.assertTrue(self.db.bundle_exists("9700_m25_22"))
        self.assertEqual(len(self.db.get_pending_bundles()), 1)
        self.db.mark_bundle_processing(bid)
        # spec filter is pending+failed only: 'processing' correctly drops out
        self.assertEqual(len(self.db.get_pending_bundles()), 0)
        self.db.mark_bundle_failed(bid, "boom", "trace")
        self.assertEqual(len(self.db.get_failed_bundles()), 1)
        self.db.mark_bundle_complete(bid, 6, 6)
        self.assertTrue(self.db.bundle_is_complete("9700_m25_22"))
        qid = self.db.register_question(bid, "Q3", "Genetics", "A-Level/Biology_9700/x")
        self.db.register_artifact(qid, "qp", "A-Level/Biology_9700/x/y.webp", 2280, 900, 5000)
        self.assertTrue(self.db.question_exists("9700", "m", "25", "22", "Q3"))
        self.assertFalse(self.db.question_exists("9700", "m", "25", "22", "Q9"))


# ---------------------------------------------------------------------------
# T2 — Preflight on real fixtures (spec STEP 2)
# ---------------------------------------------------------------------------
@unittest.skipUnless((FIXTURES / "remote" / "0620_s16_qp_22.pdf").exists()
                     and (FIXTURES / "local" / "9700_m25_er.pdf").exists(),
                     "fixture corpus absent")
class T2Preflight(unittest.TestCase):
    def test_grouping_er_attach_and_idempotence(self):
        from core.database import Database
        from core.preflight import Preflight
        with tempfile.TemporaryDirectory() as tmp:
            pdf_dir = _mixed_input(tmp)
            out = Path(tmp) / "out"
            db = Database(out / "pipeline.sqlite")
            pf = Preflight(pdf_dir, out, db)
            n = pf.run()
            self.assertEqual(n, 2, "0620 pair + 9700 trio = 2 bundles")
            # ER attached despite sorting before the QP (order-bug fix proof)
            rows = db.get_pending_bundles()
            got = {r["bundle_key"]: r for r in rows}
            self.assertIn("9700_m25_22", got)
            self.assertIn("0620_s16_22", got)
            self.assertTrue(got["9700_m25_22"]["er_path"].endswith("9700_m25_er.pdf"))
            self.assertIsNone(got["0620_s16_22"]["er_path"])
            self.assertEqual(got["0620_s16_22"]["paper_format"], "MCQ")
            self.assertEqual(got["9700_m25_22"]["paper_format"], "STRUCTURED")
            self.assertEqual(got["0620_s16_22"]["subject"], "Chemistry_0620")
            self.assertEqual(got["9700_m25_22"]["level"], "A-Level")
            # re-run registers nothing new
            self.assertEqual(pf.run(), 0)


# ---------------------------------------------------------------------------
# T3 — StagedWriter (spec STEP 3 + collision honesty)
# ---------------------------------------------------------------------------
class T3StagedWriter(unittest.TestCase):
    def test_stage_commit_idempotent_and_conflict(self):
        from core.staged_writer import StagedWriter
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "out"
            sw = StagedWriter(out)
            sp = sw.get_staging_path("test_bundle")
            self.assertTrue(str(sp).endswith(".staging/bundle_test_bundle"))
            (sp / "a").mkdir()
            (sp / "a" / "f.txt").write_text("hello")
            dest = out / "a" / "f.txt"
            self.assertTrue(sw.commit("test_bundle", sp, [("a/f.txt", str(dest))]))
            self.assertEqual(dest.read_text(), "hello")
            self.assertFalse(sp.exists())

            # identical re-commit = idempotent skip
            sp2 = sw.get_staging_path("test_bundle2")
            (sp2 / "a").mkdir()
            (sp2 / "a" / "f.txt").write_text("hello")
            self.assertTrue(sw.commit("test_bundle2", sp2, [("a/f.txt", str(dest))]))
            self.assertEqual(dest.read_text(), "hello")

            # differing dest = abort, no clobber
            sp3 = sw.get_staging_path("test_bundle3")
            (sp3 / "a").mkdir()
            (sp3 / "a" / "f.txt").write_text("DIFFERENT")
            self.assertFalse(sw.commit("test_bundle3", sp3, [("a/f.txt", str(dest))]))
            self.assertEqual(dest.read_text(), "hello")
            sw.rollback("test_bundle3", sp3, preserve=False)
            self.assertFalse(sp3.exists())


# ---------------------------------------------------------------------------
# T4/T5 — heavy real end-to-end (BATCH_HEAVY=1)
# ---------------------------------------------------------------------------
@unittest.skipUnless(HEAVY, "set BATCH_HEAVY=1 for real end-to-end")
@unittest.skipUnless((FIXTURES / "remote" / "0620_s16_qp_22.pdf").exists(),
                     "fixture corpus absent")
class T4RealBundle(unittest.TestCase):
    def test_mcq_bundle_end_to_end(self):
        from core.database import Database
        from core.preflight import Preflight
        from core.bundle_worker import process_bundle
        with tempfile.TemporaryDirectory() as tmp:
            pdf_dir = _mcq_input(tmp)
            out = Path(tmp) / "out"
            db = Database(out / "pipeline.sqlite")
            Preflight(pdf_dir, out, db).run()
            row = db.get_pending_bundles()[0]
            args = {
                "bundle_key": row["bundle_key"], "bundle_id": row["id"],
                "qp_path": row["qp_path"], "ms_path": row["ms_path"],
                "er_path": row["er_path"], "output_dir": str(out),
                "db_path": str(out / "pipeline.sqlite"),
                "syllabus_code": row["syllabus_code"], "subject": row["subject"],
                "level": row["level"], "season": row["season"], "year": row["year"],
                "component": row["component"], "paper_format": row["paper_format"],
                "low_ram": True, "quiet_worker": False,
            }
            result = process_bundle(args)
            # This paper carries QC review flags -> review_required is the
            # HONEST verdict; crops are committed with letters regardless.
            self.assertIn(result["status"], ("complete", "review_required"))
            mcq_dirs = [p for p in out.rglob("*_Q1") if p.is_dir()]
            self.assertTrue(mcq_dirs, "Q1 committed")
            md = json.loads((mcq_dirs[0] / "metadata.json").read_text())
            self.assertEqual(md["paper_format"], "MCQ")
            self.assertIn(str(md["ms_answer"]).upper(), "ABCD")
            self.assertEqual(list(mcq_dirs[0].glob("*_MS.webp")), [], "no fabricated MS webp")
            self.assertIn("P2_MCQ", str(mcq_dirs[0]))
            # DB truth: questions + artifacts rows exist
            with db._conn() as conn:
                qs = conn.execute("SELECT COUNT(*) c FROM questions").fetchone()["c"]
                arts = conn.execute("SELECT COUNT(*) c FROM artifacts").fetchone()["c"]
            self.assertGreaterEqual(qs, 25)
            self.assertGreaterEqual(arts, qs)


if __name__ == "__main__":
    unittest.main(verbosity=2)
