# Universal Cambridge Exam Topical Generator - Official Syllabus Integration

**Transforms Chemistry 9701 reference into genuine universal generator for 22 Cambridge subjects**

Official Cambridge International syllabus documents are authoritative source for every subject's topic hierarchy. The point-based winner is written first in JSON and that exact, unmodified JSON string is the physical folder name; single-folder, no duplication.

## Final Supported Subject Matrix (Official Codes)

```
IGCSE (11 required + official)
├── Chemistry              0620 - 2026 syllabus, 14 major topics
├── Physics                0625 - 2026 syllabus
├── Biology                0610 - 2026 syllabus
├── Mathematics            0580 - 2025-2027 syllabus (Number, Algebra, Geometry...)
├── Computer Science       0478 - 2026-2028 syllabus (Data representation, Data transmission, Hardware, Software, Internet, Automated tech, Algorithm design, Programming, Databases, Boolean logic)
├── Economics              0455 - 2026 syllabus (Basic economic problem, Allocation of resources, Micro decision makers, Government macroeconomy, Economic development, International trade)
├── Business Studies       0450 - 2026 syllabus (Understanding business activity, People in business, Marketing, Operations, Financial, External influences)
├── Literature in English  0475 - 2026 syllabus (Poetry, Prose, Drama, Unseen, Literary techniques, Themes, Context)
├── History                0470 - 2027-2028 syllabus (Core 19th/20th century, Depth Studies: WWI, Germany, Russia, USA, WWII Europe/Asia)
├── ICT                    0417 - 2023-2025 syllabus (Types components, Input/output, Storage, Networks, Effects IT, ICT applications, Systems life cycle, Safety, Practical skills)
└── Geography              0460 - 2027-2029 syllabus (Changing river, coastal, ecosystems, Tectonic hazards, Climate change, Changing populations, towns, Development, economies, Resource provision)

A-LEVEL (11 required + Biology extra)
├── Chemistry              9701 - Reference implementation (Atomic, Bonding, Energetics, Equilibria, Kinetics, Electrochemistry, Inorganic, Organic)
├── Physics                9702
├── Mathematics            9709 - 2028-2030 syllabus (Pure 1,2,3, Mechanics, Stats 1,2)
├── Further Mathematics    9231 - 2026-2027 syllabus (Further Pure 1,2, Further Mechanics, Further Stats)
├── Computer Science       9618 - 2026 syllabus (Information representation, Communication, Hardware, Processor Fundamentals, System Software, Security, Ethics, Databases, Algorithm Design, Data Types, Programming, Software Development, Advanced: Data Rep, Communication tech, Virtual Machines, Security, AI, Computational thinking, Further Programming)
├── Economics              9708 - 2026-2028 syllabus (AS: Basic ideas, Price system, Govt micro, Macroeconomy, Govt macro, International + A-Level extensions Utility, Efficiency, Market structures, Labour market, Growth sustainability, Globalisation)
├── Business                9609 - 2025 syllabus (Business & environment, People, Marketing, Operations, Finance, Strategic management)
├── English Literature     9695 - 2026 syllabus (Poetry, Prose, Drama, Unseen, Literary techniques, Themes)
├── History                9489 - 2026 syllabus (Modern Europe 1750-1921, USA 1820-41, International 1870-1945, Paper 3: WWI origins, Holocaust, Cold War, Depth: European interwar, USA 1944-92, International 1945-92)
├── Information Technology 9626 - 2025-2027 syllabus (Data processing, Hardware software, Monitoring control, Algorithms, eSecurity, Digital divide, Expert systems, Spreadsheets, Modelling, Database, Video/audio, IT in society, Emerging tech, Communications, Project management, System life cycle, Data analysis, Mail merge, Graphics, Animation, Web programming)
└── Geography              9696 - 2025 syllabus (Core Physical: Hydrology, Atmosphere, Rocks; Core Human: Population, Migration, Settlement; Advanced Physical: Tropical, Coastal, Hazardous, Arid; Advanced Human: Production, Environmental management, Global interdependence, Economic transition)
```

All configs validated per Requirement 11.

## Architecture - Syllabus-Year Aware

```
LEVEL (IGCSE/A-Level)
↓
SUBJECT (Chemistry, CS, Econ...)
↓
SYLLABUS CODE (0620, 9618...)
↓
EXAMINATION YEAR (2026, 2027...) → Correct Historical Config
↓
OFFICIAL TOPIC HIERARCHY
↓
QUESTION
↓
DETAILED TOPICS → JSON
↓
MAJOR TOPIC MAPPING (official high-level)
↓
POINT SYSTEM (marks, subquestions, purpose, MS dependency, specialization)
↓
ONE WINNING FOLDER (no duplication)
↓
QP + MS WEBP (2280px)
↓
AUTOMATIC VALIDATION
```

**Year Awareness:** `subjects/A-Level/Chemistry_9701/config.json` default latest, plus optional `2025/config.json`, `2026/config.json` when syllabus differs. Loader: `load_subject_config_by_code_and_level(code, level, year)` picks correct. If paper 2023 uses old syllabus but code same, uses historical config.

## Official Syllabus Is Source Of Truth

Per prompt, not invented:
- Fetched official PDFs: `https://www.cambridgeinternational.org/Images/697167-2026-2028-syllabus.pdf` (0478), `697154-2026-syllabus.pdf` (0455), `596930-2023-2025-syllabus.pdf` (0450), `718150-2027-2029-syllabus.pdf` (0460), `697372-2026-syllabus.pdf` (9618), `744634-2028-2030-syllabus.pdf` (9709), `697357-2026-2027-syllabus.pdf` (9231), `697423-2026-2028-syllabus.pdf` (9708), `662482-2025-2027-syllabus.pdf` (9626), `664556-2025-2026-syllabus.pdf` (9696) etc.
- Preserved hierarchy: e.g., 0478 official shows `1 Data representation → 1.1 Number systems, 1.2 Text sound images, 1.3 Data storage compression` → config: major `Data_representation`, detailed `Number_systems`, `Text_sound_and_images`, `Data_storage_and_compression`
- Official wording preserved as safe identifiers: `"Security, privacy and data integrity"` → `Security_privacy_and_data_integrity`

## Major vs Detailed Rule

- **Major** = high-level official structure and the point-system routing winner.
  The routing winner is stored as `metadata.json` `topic[0]`; its exact string is the physical folder name.
  - Example 9618: `Information_Representation`, `Communication`, `Hardware`, `Processor_Fundamentals`, `System_Software`, `Security_privacy_and_data_integrity`, etc.
- **Detailed** = additional, legitimate multi-topic classification values in the JSON `topic` array. They remain exact reference strings.
  - Example: `{"topic": ["Information_Representation", "Data_Representation", "Compression"]}` routes to `Information_Representation/`—the exact `topic[0]` string.

## Special Handling Per Requirements

**English Literature 0475/9695:**
- Majors: Poetry, Prose, Drama, Unseen_texts, Literary_techniques, Themes_and_characterisation, Context_and_comparison
- NOT set-text names as folders. Detailed: Poetry_analysis, Characterisation_drama, Unseen_poetry, Language_and_imagery, Themes_exploration etc.
- Distinguishes literary techniques, themes, characterisation, structure, language, form, context, comparison per Requirement 13.

**History 0470/9489:**
- Majors: Core_History_19th_century, Core_History_20th_century, Depth_Study_Germany_1918_45, Depth_Study_Russia_1905_41 etc.
- NOT generic Causes/People/Events unless official syllabus uses.
- Preserves official Key Questions and Depth Studies per Requirement 14.

**Geography 0460/9696:**
- Majors: Changing_river_environments, Changing_coastal_environments, Changing_ecosystems, Tectonic_hazards, Climate_change, Changing_populations, Changing_towns_and_cities, Development, Changing_economies, Resource_provision (0460 official 2027-2029)
- And for 9696: Core_Physical_Hydrology, Core_Physical_Atmosphere, Core_Human_Population, Advanced_Physical_Tropical, Advanced_Human_Production etc.
- No invented folder structure per Requirement 15.

**Business + Economics Separate:**
- Business 0450/9609 uses Business syllabus, Economics 0455/9708 uses Economics syllabus
- Similar concepts Demand/Supply etc don't cause cross-subject classification

**Mathematics + Further Mathematics Separate:**
- 9709 vs 9231 completely separate configs, official 9231 topics: Roots polynomial, Rational functions, Polar coordinates, Hyperbolic functions etc.

**Computer Science + ICT/IT Separate:**
- CS: Algorithms, Programming, Data Structures, Computer Architecture
- ICT/IT: Spreadsheets, Databases, Document Production, Data Manipulation, Communication per official 0417/9626

## Configuration Validation (Requirement 11)

Before use, automatically verify per config:
✓ Syllabus code exists (4-digit)
✓ Level correct (IGCSE/A-Level) + code vs level consistency
✓ Subject name correct and contains code (e.g., Chemistry_0620)
✓ Major topics exist
✓ Every minor maps to a major
✓ No minor maps to invalid major
✓ No duplicate identifiers
✓ Folder-safe names (no spaces/illegal chars)
✓ Syllabus year defined (e.g., ["2026","2027","2028"])
✓ Internally consistent

If fails: "Do not process papers using that configuration"

Validated: All 24 configs pass - 12 IGCSE + 12 A-Level (including Additional Mathematics 0606 and Biology 9700).

## Testing - All Required Syllabuses

Demo mode generates official-syllabus-based PDFs for every required syllabus:

```
python main.py --demo --demo-all --clean --validate

IGCSE: 0478 CS, 0580 Math, 0606 Additional Math, 0455 Econ, 0450 Business, 0475 Lit, 0470 Hist, 0417 ICT, 0460 Geog, 0620 Chem, 0625 Phys, 0610 Bio
A-Level: 9618 CS, 9709 Math, 9231 Further Math, 9708 Econ, 9609 Business, 9695 Lit, 9489 Hist, 9626 IT, 9696 Geog (+9701 Chem Ref, 9702 Phys)
```

Demo smoke result varies with the configured fixture list; production completion is determined only by the guarded batch audit and its exit code.

Checks per Requirement 22:
✓ Subject detection, Syllabus detection, Correct config loaded (year-aware)
✓ Questions extracted, Cropping universal (barcode/footer/reference exclusion with validated proportional top margins - no 5px clips, multi-page, 2280px WebP)
✓ Detailed topics classified (official), Major resolved via point system, Exactly one folder, QP/MS pair, JSON, No empty/metadata-only, No duplicates, Final validation passes

Chemistry 9701 reference preserved after expansion.

## Usage

**Windows (run.bat guided menu):**
Double-click `run.bat`:
```
[1] Run with PDFs in input/
[2] Demo ALL configured subjects (IGCSE + A-Level)
[3] Demo core 6 subjects quick
[4] Clean and run
[5] Validate only
[6] Show all configs validation
[7] Show structure
[8] Help - official syllabus
```

**All platforms:**
```bash
pip install -r requirements.txt
python main.py --input input --output output --validate
python main.py --demo --demo-all --clean --validate  # Demo subjects
python run_pipeline.py --input input --output output --workers 1
# Exit 0 = clean; exit 2 = safe output with review_required; exit 1 = failure
# Explicitly fetch missing mark schemes (official Cambridge index first):
python run_pipeline.py --input input --output output --workers 1 --fetch-missing-ms
```

Place PDFs like:
- IGCSE: `0478_m26_qp_12.pdf` + `0478_m26_ms_12.pdf` (CS), `0455_m26_qp_12.pdf` (Econ), `0450_m26_qp_12.pdf` (Business), `0475_m26_qp_12.pdf` (Lit), `0470_m26_qp_12.pdf` (Hist), `0417_m26_qp_12.pdf` (ICT), `0460_m26_qp_12.pdf` (Geog), `0580_m26_qp_42.pdf` (Math)
- A-Level: `9618_m26_qp_12.pdf` (CS), `9231_m26_qp_12.pdf` (Further Math), `9708_m26_qp_12.pdf` (Econ), `9609_m26_qp_12.pdf` (Business), `9695_m26_qp_12.pdf` (Lit), `9489_m26_qp_12.pdf` (Hist), `9626_m26_qp_12.pdf` (IT), `9696_m26_qp_12.pdf` (Geog)

## Production Workspace

```
core/ - universal engine (year-aware, official syllabus validation)
  config_loader.py - syllabus year awareness, validation per R11
  paper_identifier.py - code+year+level
  subject_detector.py - level+code+year conflict detection
  cropping_engine.py - preserved universal (DO NOT modify)
  classifier.py - detailed→major point system
  output_manager.py - IGCSE/A-Level separated, single-folder
  validation.py - cross-level, cross-subject, year-aware

subjects/
  IGCSE/ - 12 official (0478,0580,0606,0455,0450,0475,0470,0417,0460,0620,0625,0610)
  A-Level/ - 12 official (9618,9709,9231,9708,9609,9695,9489,9626,9696,9701,9702,9700)

main.py - supports --demo-all for all 22 official, year-aware config selection
run.bat - guided menu for all 22 subjects, official syllabus help
requirements.txt
input/.gitkeep
output/.gitkeep
```

No empty configs, every subject has official major/detailed/mapping/keywords/weights/order/year/source/validation usable immediately.

## IGCSE low-RAM batch behavior

Older IGCSE PDFs can contain answer-option numbers that look like question
numbers. The low-RAM vector-first cropper chooses the earliest marker in
printed document order, so it cannot jump into an option row and render the
rest of a paper as one giant crop. Each batch bundle runs in a disposable
worker process, and older portrait 0580 mark schemes use a strict QP-proven
Question-column fallback. If a question is ambiguous, its crop is preserved
under `review_required` and the batch exits with code `2`; it is never silently
lost.
