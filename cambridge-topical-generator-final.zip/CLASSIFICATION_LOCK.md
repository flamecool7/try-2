# Classification System Lock

The topic classifier is read-only except by maintainer-authorised amendment.
Folder routing and metadata must only consume its output.

## Baseline (Amendment CLS-1, 2026-08-10): Merged classifier v1.1 — authorised by the maintainer

The maintainer approved (`cls_approach=merge_into_core`) folding the five spec scoring
factors into the existing `core/classifier.py` point system **in place**, keeping the
routing contract (main.py integration unchanged). `original_reference/cambridge_qb/topics_enhanced.py`
and all `original_reference/topics/*/*_topics.json` remain byte-for-byte untouched.

Maintainer decisions folded into the merge:
- **Fallback = spec_forced**: paper-hint chain then alphabetical-first, loudly logged
  (`[classifier-fallback]` ERROR lines). No `Needs_Review` topic.
- **QP-only evidence**: MS corpus input and the `ms_hits * 0.8` bonus are retired.
- **No taxonomy JSON file**: taxonomy stays in the existing per-subject `config.json`
  (`major_topics` / `detailed_topics` / `classification_keywords` / `mapping` /
  `specialization_weights`, plus optional `paper_affinity`).

Engineering facts of the merged engine:
- `MAX_TOPICS = 4`, `FORMULA_BONUS = 3.0`, `COMMAND_MULTIPLIER = 1.5`,
  `COLLISION_THRESHOLD = 0.40`, `COLLISION_DAMPEN = 0.5`.
- Relative mark weight = `subpart_marks / mean_part_marks` (absolute mark weights
  break the calibrated 1.5/1.0 thresholds; `[Total: n]` excluded from extraction).
- `_CHEM_SYMBOL_MAP` includes the U+2212 minus fix; `_SUBSCRIPT_MAP` normalises
  Unicode subscripts; command-verb boost and sub-part parsing per spec.

Evidence: 21/21 exact-arithmetic factor checks
(`test-crops/cls-tests/test_factor_units.py`); 5/6 production baseline decisions
byte-identical (`test-crops/cls-tests/capture_classification.py` + `baseline.json`);
F5 intentionally DIFF (MS-isolation now QP-only, per the approved QP-only decision).

## Locked SHA-256

| File | SHA-256 |
|---|---|
| `core/classifier.py` | `3c92f8e772508ef7755be46abac5c7be3a21c84aac769202cd9ee3686464a3c3` |

Note: quality tooling may read classifier output via `metadata.json` only; the
metadata schema (single `topic` array, max 4 entries, no score sidecars) is part of
this lock.

## Amendment CLS-2 (2026-08-10): Subject-aware fallback paper hints — authorised by the maintainer

Final-upgrade Issue 2. `_FALLBACK_PAPER_HINTS` was a single Chemistry-shaped
map keyed by paper number; it is now keyed **per subject**
(`Chemistry_9701` content preserved verbatim; `Biology_9700` and `Physics_9702`
added from the directive; unlisted subjects keep the previous behaviour).
Resolution is guarded: `_resolve_hint_topic` maps a hint onto a CONFIGURED
detailed topic only (exact, then case/space-insensitive, then unique normalised
prefix/containment) and can never invent a topic. The forced-fallback chain
order (weak-keyword → paper hints → alphabetical-first, always loudly logged)
is unchanged, as are the 1.5 threshold, ≤4-topic cap, metadata schema and all
scoring factors.

Evidence: new suite `test-crops/final-fixes/test_final_fixes.py` 36/36 (I2
section: Chem hints fire only on Chemistry config; Biology paper 2 can never
receive `Atomic_structure`/`Bonding`; unlisted subjects keep the old chain);
real-paper classify regression `test-crops/final-fixes/classify_regression.py`
18/18 on 9700 m25 + w25 — m25 winners byte-identical to the CLS-1 approved set
(Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5 Genetics);
factor suite 21/21 re-run green.

### Updated SHA-256 (Amendment CLS-2)

| File | SHA-256 |
|---|---|
| `core/classifier.py` | `2936b7a63fa5de7a97320d1982710e72c5cbc74e68938784c0c67e6a72571d79` |

Data note (recorded, unwired): the maintainer-supplied 22-file taxonomy batch
now lives at `topics/A-Level/*.json` (9) and `topics/IGCSE/*.json` (13) as
shadow assets — 148 topics total, validated. Nothing in the pipeline reads
`topics/`; wiring any file into `subjects/*/config.json` requires a CLS
amendment with evidence.

## CLS-3 (2026-08-10) — per-keyword regex compiled once per process (Efficiency U3)

`classify_question`'s scoring loop re-invoked `re.compile` once per
topic x subpart x keyword (15,170 compiles of 82 distinct patterns per
process on 9700). Now `core/classifier.py::_keyword_pattern` (module-level
`@lru_cache(maxsize=None)`); pattern string byte-identical. Equivalence
proven: `findall` results identical for all 82 real keywords x real subpart
texts, and end-to-end classifications on 9700 m25/w25 equal the approved
baselines exactly (folder-path identical, webp bytes identical vs RS-2
approved tree). Measured gain ~0.6ms/question — small, honest, never a
behavior change.

| File | sha256 |
|---|---|
| `core/classifier.py` | `375772889600fe0dff5565fce5333bdd0780712a061ff31a0a51b58c68af245f` (was `2936b7a6…`) |

## CLS-4 (2026-08-10) — fallback-tier reporting on ClassificationResult (Uncategorized routing support) — authorised by the maintainer

Overseer Uncategorized directive; decision set desperate_only / adopt_keep_crop /
single_level / quality_scorer_flag (maintainer-confirmed). `ClassificationResult`
gains `fallback_tier: str = "scored"` (defaulted — every math early-return keeps the
default, so all CLS-1..3 behaviour stays bit-compatible). Tiers assigned across the
UNCHANGED fallback chain: `scored` (>= 1.5 threshold) -> `weak_keyword` ->
`paper_hint` (desperate) -> `alphabetical_first` (desperate). Scoring math, 1.5
threshold, <=4-topic cap, chain order, loud `[classifier-fallback]` logging and the
metadata schema are all unchanged. Routing contract for consumers: ONLY the two
desperate tiers may trigger Uncategorized routing; `weak_keyword` must not.

Evidence (real 9700 m25/w25 uploads): classifications equal the approved CLS-2
baselines exactly; 33/33 webp byte-parity vs RS-2 approved tree (eff-bench
regression3); T3 forced-tier unit — desperate tiers route, weak_keyword does NOT,
no-shadow rule verified.

| File | sha256 |
|---|---|
| `core/classifier.py` | `e756cb9a7527ae426d3d28ea362a004dfa84f09f6c1c6c0d620da7403a2269f1` (was `37577288…`) |
## CLS-5 (2026-08-11) — metadata additive keys for MCQ papers (schema note; zero file changes) — authorised by the maintainer

IGCSE paper-format round (mcq_ms=letters decision). Question-folder
`metadata.json` gains two OPTIONAL keys, written only for MCQ papers:

- `paper_format: "MCQ"` — the resolved component format;
- `ms_answer: "A".."D"` — the extracted grid letter, which IS the mark
  scheme for MCQ papers (Cambridge publishes a bare answer grid; there is
  nothing to crop). The MS webp is absent BY DESIGN in exactly these
  folders; every validator exemption requires this letter to be present and
  valid, and the fail-closed gates refuse completion when the grid parses
  empty.

`core/json_generator.py` is UNCHANGED (`4b905aec…`, still neither required
nor forbidden in `check_json_structure` — additive by design). No hash table
entries change in this amendment.
## CLS-6 (2026-08-11) — MCQ additive schema mirror + `_MS.txt` artifact class (schema note; zero file changes) — authorised by the maintainer

Unified-MCQ round (decisions additive / literal-with-gates-kept). The CLS-5
keys stay locked; MCQ question folders gain a PLAIN-TEXT mirror and two
additive metadata keys:

- `_MS.txt` — a new artifact class written beside `metadata.json` in MCQ
  folders ONLY: exactly one letter A/B/C/D + `\n`. When the answer grid
  yields no letter, an EMPTY file is still written (literal decision —
  never skipped) and loudly flagged; the fail-closed routing gates are
  UNCHANGED, so a letterless MCQ folder still routes Uncategorized.
- `question_type: "MCQ"` + `correct_answer: "A".."D"` — additive
  `metadata.json` keys that MUST exactly mirror the locked CLS-5
  `ms_answer`; validators cross-check both directions
  (txt ⟺ metadata, and MCQ folder + `_MS.txt` with a missing `ms_answer`
  remains an error, preserving the CLS-5 negative gate).

The MS webp is STILL never fabricated for MCQ papers — the CLS-5 design
stands (the grid letter IS the mark scheme). Folder naming is unchanged
(`P1_MCQ`); the overseer spec's literal `MCQ_P1/` name and literal
`examiner_report.webp` filename were NOT adopted — the validator accepts the
real `*_ER.webp(+_partN)` naming, so previously-produced banks stay valid.
`core/json_generator.py` remains unchanged (`4b905aec…`). No hash table
entries change in this amendment.
## CLS-7 (2026-08-11) — letterless-MCQ routing semantics + 9990 removal + `_Review/` artifact class (schema note; zero file changes) — authorised by the maintainer

RS-13 schema/routing notes (no hash-table entries change here):

- **Letterless MCQ questions route by classification.** A missing answer-grid
  letter is a MARKSCHEME completeness signal, not a classification one: such a
  question lands in its topic folder when classifiable (CLS-4 desperate tiers
  alone may route it Uncategorized). The folder then carries the CLS-6 loud
  surface UNCHANGED: empty `_MS.txt`, `question_type:"MCQ"` with
  `correct_answer:""`, NO `ms_answer`, OutputManager console flag, the RS-7
  negative validator gate (final-audit error -> paper NOT marked complete)
  and the batch staging error. Nothing about this relaxes a gate — it only
  changes WHERE the flagged crop lives.
- **9990 Psychology is not an MCQ syllabus** (Cambridge-verified:
  short-answer/extended-response/essay written papers only). Its registry rows
  are removed outright (RS-13 record); earlier "spec-asserted" provenance is
  preserved as receipt D2-RESOLVED.
- **`_Review/` is a new output-tree area**, written ONLY by the opt-in tool
  `tools/quarantine_reviewed_crops.py` (never by the pipeline itself). Each
  subfolder name is the QC review reason; a README.md records source log,
  reason, and original location for every moved folder. FinalValidator treats
  `_Review` trees as out-of-sanctioned-namespace review storage (the pipeline
  never routes anything there; user-driven only).

---

## RS-17/18 (2026-08-12) — taxonomy + mega-spec amendments touching this lock's files — standing pre-approval

Full receipts: `test-crops/redesign/RS161718_ROUND_EVIDENCE.md` (§2–§3).

| `core/classifier.py` | `26280dadefea03762f08243d6aa6567b69cb3a42fefeee38964c27ab0b8543e5` | (was `e756cb9a7527ae42…`)

## CLS-8 (2026-08-12) — Chemistry 9701 evidence coverage and 0606 routing seam

The production classifier remains fail-closed, but the 9701 profile now carries
verified vocabulary for formulae, VSEPR, radical/electron-shell evidence,
energetics, Boltzmann distributions, Group 2, ammonium, alcohol oxidation,
halogen mechanisms, stereoisomerism, and carbonyl chemistry. This removes the
previous false review fallbacks on the tested 9701_s24_qp_12 MCQ paper without
introducing a paper-hint or alphabetical fallback. The 0606 question-level
router lives in `core/math_reference.py` and is selected by the subject code.

| `core/classifier.py` | `9bd3de55b21e97c65712a7e25b286e1843e4bc364e85ab9c9a7d24d5b367782b` | (was `26280dadefea0376…`) |
