#!/usr/bin/env python3
"""run_guarded.py — self-checking orchestration runner (2026-08-10, user-approved:
"check itself every step" mode, wrapper architecture).

Runs the locked pipeline stage-by-stage with hard gates BETWEEN every stage.
Any failed check inside a stage aborts the run ON THE SPOT with a loud banner
naming the stage + every failed check + a failure_report.txt — downstream
stages never execute, and nothing half-built is treated as output.

    python3 run_guarded.py --input papers --output output [--clean] [--low-ram]

Exit codes: 0 = every stage green. 1 = a stage gate failed (see banner/report).
This file changes NO locked source: it only calls the same public functions
main.py calls.

Architecture notes
------------------
* Each QP+MS paper bundle runs in its own subprocess ("paper worker"). Peak
  heap stays around ~950MB inside one worker and dies with it, instead of
  accumulating across papers (glibc retains freed heap: one 16+ page paper
  leaves ~935MB RSS that a second paper then kills against — exit 137 in this
  ~2GB sandbox). A worker crash (incl. SIGKILL/137) is surfaced by the parent
  as a loud failed gate naming the paper, not a silent empty log.
* QP paths (loudly reported at start):
    default   : CroppingEngine.process_paper — exactly main.py.
    --low-ram : RAM-safe streaming via test-crops/bio-20px-test/test_harness.py.
                SAME locked segmentation (Amendment-5 question_split triplet),
                same call order and constants; only the page rasters are
                rendered one at a time and freed. QP/MS pairing is then by
                question number (the approved m25/w25 v3 proof packs were built
                this way, byte-identical classifications) instead of
                matcher.match_questions. Every other stage (MS engine,
                validate_pairs, classifier, save, ER, audit) is the untouched
                production path in both modes.
* Width contract: engines may return content-width rasters (MS 1501px); the
  locked OutputManager scales to exactly 2280 at save. The hard 2280 gate
  lives in S5 on the saved files — where production actually guarantees it.
"""
import argparse
import gc
import json
import logging
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))
logging.basicConfig(level=logging.WARNING)

import numpy as np

MIN_HEIGHT_PX = 80
TARGET_WIDTH = 2280
INK_MIN_FRAC = 0.0005

ALL_STAGES = [
    ("S0", "environment + config validation"),
    ("S1", "paper identification + subject separation"),
    ("S2", "QP crop (gold-standard splitter)"),
    ("S3", "MS crop (LOCKED exact splitter)"),
    ("S4", "QP/MS grouping + pairing"),
    ("S5", "classify + save question pairs"),
    ("S6", "examiner-report text attachment"),
    ("S7", "examiner-report per-question crops"),
    ("S8", "final validation + output audit"),
]

WORKER_OK = re.compile(r"WORKER-RESULT saved=(\d+) base=(\S+)")


class StageAbort(Exception):
    pass


def _rss_mb() -> int:
    try:
        with open("/proc/self/statm") as fh:
            pages = int(fh.read().split()[1])
        return pages * 4096 // (1024 * 1024)
    except Exception:
        return -1


class Gate:
    """Collects checks for one stage; abort() ends the run loudly on any fail."""

    def __init__(self, output_root: Path):
        self.output_root = Path(output_root)
        self.stage_results = []

    def run_stage(self, sid: str, name: str, fn):
        checks = []

        def check(nm, ok, detail=""):
            checks.append((nm, bool(ok), str(detail)))
            print(f"    [{'PASS' if ok else 'FAIL'}] {nm}: {detail}")

        print(f"\n=== STAGE {sid} — {name} ===")
        try:
            result = fn(check)
            print(f"  [mem] current RSS after {sid}: {_rss_mb()} MB")
        except StageAbort:
            raise
        except Exception as exc:  # crash containment: exception becomes a failed gate, not a traceback
            import traceback
            tb = traceback.format_exc(limit=3)
            check(f"stage crashed: {type(exc).__name__}", False, f"{exc} | {tb.splitlines()[-1] if tb else ''}")
            result = None

        fails = [(n, d) for n, ok, d in checks if not ok]
        if fails:
            self._abort(sid, name, checks, fails)
        self.stage_results.append((sid, name, checks))
        print(f"  -> STAGE {sid} OK ({len(checks)} checks)")
        return result

    def _abort(self, sid, name, checks, fails):
        print()
        print("!" * 64)
        print(f"  XXX RUN FAILED XXX — stopped at STAGE {sid}: {name}")
        print("!" * 64)
        print("  Failed checks:")
        for i, (n, d) in enumerate(fails, 1):
            print(f"    {i}. {n}" + (f"   ->  {d}" if d else ""))
        print()
        print("  Downstream stages did NOT run. Nothing half-built is treated as output.")
        self.output_root.mkdir(parents=True, exist_ok=True)
        rp = self.output_root / "failure_report.txt"
        lines = [
            f"failure_report  —  {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"run_guarded stopped at STAGE {sid}: {name}",
            f"failed {len(fails)}/{len(checks)} checks in this stage",
            "",
        ] + [f"FAIL  {n}: {d}" for n, d in fails]
        rp.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"  report written: {rp}")
        print("!" * 64)
        sys.exit(1)

    def finish_all(self, title=""):
        total = sum(len(c) for _, _, c in self.stage_results)
        print()
        print("=" * 64)
        print(f"  *** ALL GREEN ***  {len(self.stage_results)} stages, {total} checks passed" +
              (f"  —  {title}" if title else ""))
        print("=" * 64)
        stale = self.output_root / "failure_report.txt"
        if stale.exists():
            stale.unlink()
            print("  (cleared stale failure_report.txt from an earlier failed run)")
        sys.exit(0)


def ink_frac(img) -> float:
    a = np.asarray(img.convert("L"))
    return float((a < 200).mean())


def question_image(cq):
    return getattr(cq, "assembled_image", None) or cq.images[0]


def check_crop_list(check, label, crops):
    check(f"{label}: at least 1 question", len(crops) >= 1, f"{len(crops)} questions")
    nums = [c.number_int for c in crops]
    check(f"{label}: question numbers unique", len(set(nums)) == len(nums),
          f"{sorted(nums)}")
    # NOTE: engines may return content-width rasters (e.g. MS 1501px); the
    # locked OutputManager scales to exactly 2280 at save — the hard width
    # gate lives in S5 on the saved files. Here: sane-raster checks only.
    for c in crops:
        img = question_image(c)
        check(f"{label} {c.question_number}: sane raster", img.width >= 1000,
              f"{img.size} (scaled to 2280 at save)")
        check(f"{label} {c.question_number}: height >= {MIN_HEIGHT_PX}",
              img.height >= MIN_HEIGHT_PX, f"{img.size}")
        frac = ink_frac(img)
        check(f"{label} {c.question_number}: has ink", frac > INK_MIN_FRAC, f"dark={frac:.5f}")


def qp_crops_low_ram(qp_info) -> list:
    """RAM-safe QP crops via the approved test harness (locked triplet
    segmentation, streams one page at a time)."""
    sys.path.insert(0, "/home/user/test-crops/bio-20px-test")
    import test_harness as th

    texts = {}
    _orig = th.QuestionQCValidator.validate
    def spy(**kw):
        texts[str(kw.get("question_number"))] = kw.get("text", "")
        return _orig(**kw)
    th.QuestionQCValidator.validate = staticmethod(spy)
    try:
        results = th.split_test(str(qp_info.file_path), wanted=None,
                                syllabus_code=qp_info.syllabus_code)
    finally:
        th.QuestionQCValidator.validate = staticmethod(_orig)

    out = []
    for qn, (img, status) in sorted(results.items()):
        text = texts.get(str(qn), "")
        marks = sum(int(mm) for mm in re.findall(r"\[(\d+)\]", text))
        out.append(SimpleNamespace(
            question_number=f"Q{qn}", number_int=qn,
            paper_code=qp_info.full_code, images=[img], assembled_image=img,
            text=text, marks=marks, pages=None,
        ))
        print(f"    [low-ram] Q{qn}: {img.size}, QC {status}")
    del results
    gc.collect()
    return out


def pair_low_ram(qp_list, ms_list, qp_info, ms_info, subject):
    """Question-number pairing producing match_questions-compatible objects."""
    ms_by_q = {m.number_int: m for m in ms_list}
    out = []
    for q in sorted(qp_list, key=lambda c: c.number_int):
        mo = ms_by_q.get(q.number_int)
        if mo is None:
            continue
        out.append(SimpleNamespace(
            question_number=q.question_number, number_int=q.number_int,
            qp=q, ms=mo,
            paper_code=f"{qp_info.syllabus_code}_{qp_info.season_letter}{qp_info.year_short}",
            full_qp_code=qp_info.full_code, full_ms_code=ms_info.full_code,
            year=qp_info.year, season=qp_info.season, variant=qp_info.variant,
            subject=subject.split("_")[0],
        ))
    return out


def run_paper_stages(gate, args, base_key, qp_info, ms_info, subject, config, state,
                     cropping_engine, ms_cropping_engine, matcher, output_mgr):
    """S2 -> S3 -> S4-pair -> S5 for ONE paper bundle. Returns saved count."""
    from core.classifier import TopicClassifier

    state.register_paper(base_key, qp_path=str(qp_info.file_path),
                         ms_path=str(ms_info.file_path), er_path=None)
    if state.should_skip(base_key):
        print(f"    [guarded] RESUME-SKIP {base_key}")
        return -1
    state.mark_processing(base_key)

    # ---------- S2 QP crop ----------
    def s2(check):
        if args.low_ram:
            qp_cropped = qp_crops_low_ram(qp_info)
        else:
            qp_cropped = cropping_engine.process_paper(qp_info.file_path)
        check_crop_list(check, f"QP {qp_info.full_code}", qp_cropped)
        for c in qp_cropped:
            check(f"QP {qp_info.full_code} {c.question_number}: text extracted",
                  bool((c.text or "").strip()), f"{len(c.text or '')} chars")
        return qp_cropped

    qp_cropped = gate.run_stage("S2", f"{ALL_STAGES[2][1]} [{qp_info.full_code}]", s2)
    gc.collect()

    # ---------- S3 MS crop ----------
    def s3(check):
        ms_cropped = ms_cropping_engine.process_paper(ms_info.file_path)
        check_crop_list(check, f"MS {ms_info.full_code}", ms_cropped)
        return ms_cropped

    ms_cropped = gate.run_stage("S3", f"{ALL_STAGES[3][1]} [{ms_info.full_code}]", s3)

    # ---------- S4 pair coverage ----------
    def s4b(check):
        if args.low_ram:
            matched = pair_low_ram(qp_cropped, ms_cropped, qp_info, ms_info, subject)
        else:
            matched = matcher.match_questions(qp_cropped, ms_cropped, qp_info, ms_info, subject)
        valid, errors = matcher.validate_pairs(matched)
        check("no pair-validation errors", len(errors) == 0,
              str(errors) if errors else "clean")
        check("every cropped QP question paired", len(valid) == len(qp_cropped),
              f"{len(valid)}/{len(qp_cropped)}")
        qn = [m.question_number for m in valid]
        check("no question paired twice", len(set(qn)) == len(qn), qn)
        return valid

    valid_matched = gate.run_stage("S4", f"pair coverage [{base_key}]", s4b)
    del qp_cropped, ms_cropped
    gc.collect()

    # ---------- S5 classify + save ----------
    classifier = TopicClassifier(config)

    def s5(check):
        topic_union = set(getattr(config, "major_topics", [])) | set(getattr(config, "detailed_topics", []))
        saved_here = 0
        for m in valid_matched:
            c = classifier.classify_question(m)
            check(f"{base_key} {m.question_number}: winner set", bool(c.winning_major), c.winning_major)
            if topic_union:
                check(f"{base_key} {m.question_number}: winner in taxonomy",
                      c.winning_major in topic_union, c.winning_major)
            check(f"{base_key} {m.question_number}: <=4 detailed topics",
                  len(c.detailed_topics) <= 4, str(c.detailed_topics[:4]))
            saved = output_mgr.save_question_pair(m, c, config)
            qfolder = Path(saved["question_folder"])
            if saved.get("skipped_duplicate"):
                qp_f = qfolder / f"{qfolder.name}.webp"
                ms_f = qfolder / f"{qfolder.name}_MS.webp"
                js_f = qfolder / "metadata.json"
            else:
                qp_f, ms_f, js_f = (Path(saved["qp"]), Path(saved["ms"]), Path(saved["json"]))

            def on_disk(p: Path) -> bool:
                return p.exists() or any(p.parent.glob(p.stem + "_part*" + p.suffix))
            check(f"{base_key} {m.question_number}: QP file on disk", on_disk(qp_f), qp_f.name)
            check(f"{base_key} {m.question_number}: MS file on disk", on_disk(ms_f), ms_f.name)
            check(f"{base_key} {m.question_number}: metadata.json on disk", js_f.exists(), js_f.name)
            webps = sorted(qfolder.glob("*.webp"))
            check(f"{base_key} {m.question_number}: webp pair written", len(webps) >= 2,
                  f"{len(webps)} webps")
            from PIL import Image
            for w in webps:
                with Image.open(w) as im:
                    check(f"{base_key} {m.question_number}: {w.name} width 2280",
                          im.width == TARGET_WIDTH, f"{im.size}")
            json.loads(js_f.read_text(encoding="utf-8"))
            check(f"{base_key} {m.question_number}: metadata.json parses",
                  True, f"{js_f.stat().st_size} bytes")
            saved_here += 1
        check(f"{base_key}: all paired questions saved", saved_here == len(valid_matched),
              f"{saved_here}/{len(valid_matched)}")
        return saved_here

    saved_n = gate.run_stage("S5", f"{ALL_STAGES[5][1]} [{base_key}]", s5)
    state.mark_complete(base_key, len(valid_matched), saved_n)
    state.save(output_root_safe(output_mgr))
    del valid_matched
    gc.collect()
    return saved_n


def output_root_safe(output_mgr) -> Path:
    return Path(getattr(output_mgr, "output_root", "output"))


def load_inputs(args):
    """S0+S1 shared by parent and workers. Returns (gate, configs, papers, sep)."""
    input_dir, output_dir = Path(args.input), Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    gate = Gate(output_dir)

    if args.clean and output_dir.exists():
        for item in output_dir.iterdir():
            if item.name == ".gitkeep":
                continue
            shutil.rmtree(item) if item.is_dir() else item.unlink()
        print(f"[guarded] cleaned {output_dir}")

    from core.config_loader import (load_all_subject_configs,
                                    load_subject_config_by_code_and_level,
                                    validate_all_configs)

    def s0(check):
        ok, errors_by_subject = validate_all_configs()
        check("all subject configs validate", ok, f"errors={errors_by_subject if not ok else 'none'}")
        configs = load_all_subject_configs()
        check("configs loaded", len(configs) > 0, f"{len(configs)} entries")
        return configs

    configs = gate.run_stage("S0", ALL_STAGES[0][1], s0)

    from core.paper_identifier import identify_papers_in_dir
    from core.subject_detector import separate_papers_by_subject

    def s1(check):
        papers = identify_papers_in_dir(input_dir)
        check("at least one paper identified", len(papers) > 0, f"{len(papers)} papers in {input_dir}")
        for p in papers:
            check(f"{p.original_name or p.file_path.name}: parsed",
                  p.paper_type in {"qp", "ms", "er", "gt", "in"} and bool(p.syllabus_code),
                  f"type={p.paper_type} code={p.syllabus_code} {p.season_letter}{p.year_short} v{p.variant}")
        sep = separate_papers_by_subject(papers)
        check("no identity conflicts", len(sep["conflicts"]) == 0,
              f"{len(sep['conflicts'])} conflicts" if sep["conflicts"] else "clean")
        check("no papers needing review", len(sep["review"]) == 0,
              f"{len(sep['review'])} for review" if sep["review"] else "clean")
        check("papers sorted into subject contexts", len(sep["by_level_subject"]) > 0,
              str({lvl: list(d) for lvl, d in sep["by_level_subject"].items()}))
        return papers, sep

    papers, sep = gate.run_stage("S1", ALL_STAGES[1][1], s1)
    return gate, configs, papers, sep


def find_bundle(base_key, configs, sep):
    """Locate (level, subject, config, qp_info, ms_info) for a bundle key."""
    from core.config_loader import load_subject_config_by_code_and_level
    for level in ["IGCSE", "A-Level"]:
        for subject, paper_list in sep["by_level_subject"].get(level, {}).items():
            from collections import defaultdict
            by_year = defaultdict(list)
            for p in paper_list:
                by_year[p.year].append(p)
            for year, year_papers in by_year.items():
                from core.qp_ms_matcher import QPMSMatcher
                matcher = QPMSMatcher()
                groups = matcher.group_papers(year_papers)
                if base_key in groups:
                    td = groups[base_key]
                    config = load_subject_config_by_code_and_level(
                        year_papers[0].syllabus_code, level, year) \
                        or configs.get(f"{level}/{subject}") or configs.get(subject)
                    return level, subject, config, td.get("qp"), td.get("ms")
    return None, None, None, None, None


def worker_main(args):
    gate, configs, papers, sep = load_inputs(args)
    level, subject, config, qp_info, ms_info = find_bundle(args.worker, configs, sep)
    from core.cropping_engine import CroppingEngine
    from core.ms_cropping_engine import MSCroppingEngine
    from core.qp_ms_matcher import QPMSMatcher
    from core.output_manager import OutputManager
    from core.pipeline_state import PipelineState

    if not qp_info or not ms_info:
        gate._abort("S4", f"worker bundle {args.worker}", [],
                    [("bundle resolvable", f"qp={qp_info} ms={ms_info}")])
    cropping_engine = CroppingEngine(target_width=2280, quality=95, dpi=75)
    ms_engine = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
    output_mgr = OutputManager(output_root=args.output, target_width=2280, quality=95)
    state = PipelineState.load_or_create(Path(args.output), subject=subject,
                                         syllabus_code=qp_info.syllabus_code, level=level)
    saved_n = run_paper_stages(gate, args, args.worker, qp_info, ms_info, subject,
                               config, state, cropping_engine, ms_engine, QPMSMatcher(),
                               output_mgr)
    print(f"WORKER-RESULT saved={saved_n} base={args.worker}")
    gate.finish_all(f"paper worker {args.worker}")


def spawn_paper_worker(args, base_key) -> tuple:
    """Run one bundle in an isolated subprocess; stream its output. Returns (rc, saved)."""
    cmd = [sys.executable, "-u", str(Path(__file__).resolve()),
           "--input", str(args.input), "--output", str(args.output),
           "--_worker", base_key]
    if args.low_ram:
        cmd.append("--low-ram")
    print(f"\n[guarded] paper {base_key}: isolated process …")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1)
    buf = []
    for line in proc.stdout:
        sys.stdout.write(line)
        buf.append(line)
    rc = proc.wait()
    m = WORKER_OK.search("".join(buf))
    saved = int(m.group(1)) if m else (-9 if rc == 0 else -8)
    return rc, saved


def main():
    ap = argparse.ArgumentParser(description="Self-checking guarded runner (locked pipeline, gate between every stage)")
    ap.add_argument("--input", "-i", default="input")
    ap.add_argument("--output", "-o", default="output")
    ap.add_argument("--clean", action="store_true")
    ap.add_argument("--low-ram", action="store_true",
                    help="QP: RAM-safe streaming harness (production-identical segmentation)")
    ap.add_argument("--_worker", dest="worker", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()

    if args.worker:
        worker_main(args)
        return

    print(f"[guarded] QP path: {'RAM-SAFE streaming (locked triplet, low-ram)' if args.low_ram else 'production CroppingEngine (main.py-exact)'}")
    print(f"[guarded] per-paper process isolation: ON (worker dies with its peak heap)")

    gate, configs, papers, sep = load_inputs(args)
    output_root = Path(args.output)

    from core.qp_ms_matcher import QPMSMatcher
    from core.pipeline_state import PipelineState

    total_saved = 0
    for level in ["IGCSE", "A-Level"]:
        if level not in sep["by_level_subject"]:
            continue
        from collections import defaultdict
        for subject, paper_list in sep["by_level_subject"][level].items():
            print(f"\n[guarded] subject context {level}/{subject}: {len(paper_list)} papers")
            by_year = defaultdict(list)
            for p in paper_list:
                by_year[p.year].append(p)

            for year, year_papers in by_year.items():
                matcher = QPMSMatcher()
                groups = matcher.group_papers(year_papers)

                # ---------- S4 grouping gates (structure only) ----------
                def s4(check, groups=groups, year=year):
                    check("no duplicate-input grouping errors", len(matcher.grouping_errors) == 0,
                          str(matcher.grouping_errors) if matcher.grouping_errors else "clean")
                    bundles = {k: v for k, v in groups.items() if ("qp" in v or "ms" in v)}
                    loners = [k for k, v in groups.items() if ("qp" not in v and "ms" not in v)]
                    check("at least one QP/MS group", len(bundles) > 0,
                          f"{len(bundles)} bundles, {len(loners)} er/insert-only groups")
                    for k in loners:
                        print(f"    [info] {k}: no QP/MS — handled in ER stages S6/S7")
                    for base_key, td in bundles.items():
                        check(f"{base_key}: has QP", "qp" in td, ",".join(td.keys()))
                        check(f"{base_key}: has exact MS", "ms" in td, ",".join(td.keys()))
                        if "qp" in td and "ms" in td:
                            check(f"{base_key}: QP/MS level agree", td["qp"].level == td["ms"].level,
                                  f"{td['qp'].level} vs {td['ms'].level}")
                    return None

                gate.run_stage("S4", f"{ALL_STAGES[4][1]} [{subject} {year}]", s4)

                for base_key, td in groups.items():
                    if "qp" not in td or "ms" not in td:
                        continue
                    rc, saved_n = spawn_paper_worker(args, base_key)

                    def wp(check, bk=base_key, rc=rc, sn=saved_n):
                        check(f"{bk}: worker process exited cleanly", rc == 0,
                              f"exit={rc}" + (" (killed/crashed — report above)" if rc else ""))
                        check(f"{bk}: worker reported saved count", sn >= 0, f"saved={sn}")
                        return max(sn, 0)

                    saved_n = gate.run_stage("S5", f"paper worker result [{base_key}]", wp)
                    total_saved += saved_n
                    gc.collect()

    # ---------- S6 ER text ----------
    er_papers = [p for p in papers if p.paper_type == "er"]

    def s6(check):
        if not er_papers:
            check("no ER papers supplied — stage skipped by design", True, "")
            return None
        from core.examiner_report import attach_examiner_reports_to_output
        stats = attach_examiner_reports_to_output(er_papers, output_root)
        check("ER: no processing errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        check("ER: every detected report parsed", stats["reports_parsed"] == stats["reports_detected"],
              f"{stats['reports_parsed']}/{stats['reports_detected']}")
        check("ER: commentary attached to questions", stats["questions_attached"] > 0,
              f"{stats['questions_attached']} attached")
        return stats

    gate.run_stage("S6", ALL_STAGES[6][1], s6)

    # ---------- S7 ER crops ----------
    def s7(check):
        if not er_papers:
            check("no ER papers supplied — stage skipped by design", True, "")
            return None
        from core.er_question_crops import attach_question_er_crops
        stats = attach_question_er_crops(er_papers, output_root)
        check("ER crops: no errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        check("ER crops: all written crops text-verified", stats["crops_written"] == stats["verified"],
              f"{stats['crops_written']}/{stats['verified']}")
        from PIL import Image
        tiles = [p for p in output_root.rglob("*_ER.webp")]
        check("ER crops: at least one crop on disk", len(tiles) > 0, f"{len(tiles)} tiles")
        for t in tiles:
            with Image.open(t) as im:
                check(f"ER crop {t.parent.name}/{t.name}: width 2280", im.width == TARGET_WIDTH,
                      f"{im.size}")
        return stats

    gate.run_stage("S7", ALL_STAGES[7][1], s7)

    # ---------- S8 final validation ----------
    from core.validation import FinalValidator
    from core.output_manager import OutputManager
    output_mgr = OutputManager(output_root=args.output, target_width=2280, quality=95)

    def s8(check):
        removed = output_mgr.cleanup_empty_and_invalid_folders()
        check("cleanup ran", True, f"removed {len(removed)} invalid folders" if removed else "nothing invalid")
        dup_errors, _ = output_mgr.ensure_no_duplicate_distribution()
        check("no duplicate distribution", len(dup_errors) == 0,
              str(dup_errors[:3]) if dup_errors else "clean")
        qpms_errors = output_mgr.validate_qp_ms_pairs()
        check("QP/MS pairs valid on disk", len(qpms_errors) == 0,
              str(qpms_errors[:3]) if qpms_errors else "clean")
        result = FinalValidator(output_root=output_root).validate_all()
        check("final audit passes", result["passed"], f"errors={result.get('total_errors', 0)}")
        folders = [p for p in output_root.rglob("*_Q*")
                   if p.is_dir() and re.search(r"_Q\d+$", p.name)]
        check("question folders on disk == saved this run", len(folders) == total_saved,
              f"{len(folders)} folders vs {total_saved} saved")
        return result

    gate.run_stage("S8", ALL_STAGES[8][1], s8)

    print(f"\n[guarded] questions saved: {total_saved}")
    gate.finish_all("full guarded run")


if __name__ == "__main__":
    main()
