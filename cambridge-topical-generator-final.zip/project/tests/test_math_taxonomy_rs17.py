"""RS-17 spec tests — official-topic taxonomy, REVIEW_REQUIRED routing,
year gate, math diagram evidence.

Receipts style: every assertion pins a REAL behavior of the production modules,
not a mock. The matrix-level assertions regenerate their inputs through the
real classifiers/splitters rather than reading stale output trees.
"""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.math_reference import (  # noqa: E402
    MATH_0580_TOPICS, allowed_topics_for_paper, classify_0580_question,
    classify_9231_question, classify_9709_question,
)
from core.diagram_evidence import harvest_diagram_evidence  # noqa: E402


def _triangle_image(with_arc: bool = False) -> np.ndarray:
    import cv2
    img = np.full((400, 1000, 3), 255, np.uint8)
    cv2.line(img, (300, 300), (500, 100), 0, 3)
    cv2.line(img, (500, 100), (700, 300), 0, 3)
    cv2.line(img, (700, 300), (300, 300), 0, 3)
    if with_arc:
        cv2.ellipse(img, (500, 100), (60, 60), 55, 0, 70, 0, 3)
    return img


class TestOfficialTaxonomy(unittest.TestCase):
    """Spec Fixes 7/9: official names only — no numeric prefixes, no paper-name
    pseudo-topics, no old generic physics list."""

    def test_9709_reference_has_no_typo_and_official_names(self):
        for paper in range(1, 7):
            topics = allowed_topics_for_paper(paper)
            self.assertTrue(topics, f"P{paper} empty")
            for t in topics:
                self.assertNotRegex(t, r"^\d+_", f"numeric prefix: {t}")
                self.assertNotRegex(t, r"^P\d_", f"paper-name pseudo-topic: {t}")
        self.assertIn("Trigonometry", allowed_topics_for_paper(1))
        self.assertNotIn("Trignometry", allowed_topics_for_paper(1))

    def test_all_math_profile_identities(self):
        # 9709 P1..P6 all present with distinct sections
        sections = {p: allowed_topics_for_paper(p) for p in range(1, 7)}
        self.assertIn("Circular_measure", sections[1])
        self.assertIn("Vectors", sections[3])
        self.assertIn("Momentum", sections[4])
        self.assertIn("The_normal_distribution", sections[5])
        self.assertIn("The_Poisson_distribution", sections[6])
        # 9231 P1..P4
        from core.math_reference import load_9231_reference
        s9231 = load_9231_reference()
        self.assertEqual(set(s9231), {1, 2, 3, 4})
        self.assertIn("Hyperbolic_functions", s9231[2])
        # 0580: exactly the 9 official areas
        self.assertEqual(len(MATH_0580_TOPICS), 9)
        self.assertIn("Transformations_and_vectors", MATH_0580_TOPICS)

    def test_config_arrays_match_official_lists(self):
        import json as _json
        cfg = _json.loads((PROJ / "subjects/A-Level/Physics_9702/config.json").read_text())
        self.assertEqual(len(cfg["major_topics"]), 25)
        for spec_name in ("Physical_quantities_and_units", "Motion_in_a_circle",
                          "Medical_physics", "Astronomy_and_cosmology", "Capacitance"):
            self.assertIn(spec_name, cfg["major_topics"])
        # old generic list must be gone
        for old in ("Mechanics", "Thermal_Physics", "Modern_Physics", "Fields"):
            self.assertNotIn(old, cfg["major_topics"])
        cfg6 = _json.loads((PROJ / "subjects/IGCSE/Physics_0625/config.json").read_text())
        self.assertEqual(set(cfg6["major_topics"]),
                         {"Motion_forces_and_energy", "Thermal_physics", "Waves",
                          "Electricity_and_magnetism", "Nuclear_physics", "Space_physics"})
        cfgm = _json.loads((PROJ / "subjects/IGCSE/Mathematics_0580/config.json").read_text())
        self.assertNotRegex("".join(cfgm["major_topics"]), r"P\d_|Non_Calculator")


class TestMathRoutingEvidence(unittest.TestCase):
    """Spec Fix 8: multi-signal deterministic math routing."""

    def test_question_level_trigonometry_recognition(self):
        # 9709 P1: formula+keyword evidence
        self.assertEqual(
            classify_9709_question("Given that sin θ = 3 cos θ, use trigonometric "
                                   "identities to find tan θ and hence solve the equation", 1),
            "Trigonometry")
        # formula-only trig (no prose topic names)
        self.assertEqual(classify_0580_question("Show that sin x cos x tan x = 1 - cos x"),
                         "Trigonometry")

    def test_plain_triangle_is_not_trigonometry(self):
        d = harvest_diagram_evidence(_triangle_image(False), text="In the diagram,")
        self.assertGreaterEqual(d["triangles"], 1)
        self.assertEqual(d["angle_arcs"], 0)
        # no trig decision on a lone triangle: review, not a guess
        self.assertIsNone(classify_0580_question("In the diagram,", diagram=d))

    def test_triangle_plus_angle_evidence_is_trigonometry(self):
        d = harvest_diagram_evidence(_triangle_image(False), text="")
        d2 = dict(d); d2["angle_arcs"] = 2; d2["greek_labels"] = 1
        self.assertEqual(classify_0580_question("In the diagram, angle ABC = θ", diagram=d2),
                         "Trigonometry")
        self.assertEqual(classify_9709_question("The triangle has angle θ shown", 1, diagram=d2),
                         "Trigonometry")

    def test_vector_diagram_recognition(self):
        d = {"vector_arrows": 2, "force_arrows": 0}
        self.assertEqual(classify_9709_question("The points A and B have position vectors "
                                                "shown by the arrows", 3, diagram=d),
                         "Vectors")
        self.assertEqual(classify_0580_question("The vector is shown by the arrow", diagram=d),
                         "Transformations_and_vectors")

    def test_mechanics_diagram_recognition(self):
        d = {"vector_arrows": 3, "force_arrows": 3}
        self.assertEqual(classify_9709_question("A particle is held in equilibrium by three "
                                                "forces shown by the arrows", 4, diagram=d),
                         "Forces_and_equilibrium")

    def test_diagram_only_routes_to_review_not_a_guess(self):
        # text-empty question with only geometry pixels -> None (REVIEW_REQUIRED)
        d = harvest_diagram_evidence(_triangle_image(True), text="")
        self.assertIsNone(classify_0580_question("", diagram=d))
        self.assertIsNone(classify_9709_question("", 1, diagram=d))
        self.assertIsNone(classify_9231_question("", 1, diagram=d))

    def test_zero_evidence_never_picks_first_topic(self):
        # the old alphabetical_first fallback is forbidden by spec
        self.assertIsNone(classify_9709_question("zzzz qqqq xxxx", 1))
        self.assertIsNone(classify_0580_question("zzzz qqqq xxxx"))
        self.assertIsNone(classify_9231_question("zzzz qqqq xxxx", 1))

    def test_harvester_is_deterministic_and_safe(self):
        img = _triangle_image(True)
        a = harvest_diagram_evidence(img, text="θθ")
        b = harvest_diagram_evidence(img, text="θθ")
        self.assertEqual(a, b)
        self.assertEqual(a["greek_labels"], 2)
        tiny = harvest_diagram_evidence(np.full((10, 10, 3), 255, np.uint8), text="")
        self.assertIsInstance(tiny, dict)


class TestYearGate(unittest.TestCase):
    """Spec Fix 10: unsupported years fail loudly; nothing half-built."""

    def _tiny_pdf(self, path: Path, title: str):
        from reportlab.pdfgen import canvas
        c = canvas.Canvas(str(path))
        c.drawString(72, 770, title)
        c.showPage()
        c.save()

    def test_unsupported_year_rejected(self):
        tmp = Path(tempfile.mkdtemp(prefix="ygate_"))
        inp, out = tmp / "in", tmp / "out"
        inp.mkdir()
        # 9700 profile declares 2015/2025/2026 (+ era receipts) — 2019 is NOT declared.
        self._tiny_pdf(inp / "9700_s19_qp_22.pdf", "QP")
        self._tiny_pdf(inp / "9700_s19_ms_22.pdf", "MS")
        r = subprocess.run([sys.executable, "-u", str(PROJ / "run_guarded.py"),
                            "--input", str(inp), "--output", str(out), "--low-ram"],
                           capture_output=True, text=True, timeout=600, cwd=str(PROJ))
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("supported by profile", r.stdout)
        self.assertIn("STAGE S1", r.stdout)
        self.assertFalse(list(out.rglob("*.webp")), "no output on rejected years")
        self.assertFalse(list(out.rglob("metadata.json")))
        reports = list(out.rglob("failure_report.txt"))
        self.assertTrue(reports, "loud failure report for unsupported year")

    def test_declared_era_year_accepted(self):
        tmp = Path(tempfile.mkdtemp(prefix="ygate_ok_"))
        inp, out = tmp / "in", tmp / "out"
        inp.mkdir()
        self._tiny_pdf(inp / "9700_s15_qp_22.pdf", "QP — no question markers page")
        self._tiny_pdf(inp / "9700_s15_ms_22.pdf", "MS — no markers")
        r = subprocess.run([sys.executable, "-u", str(PROJ / "run_guarded.py"),
                            "--input", str(inp), "--output", str(out), "--low-ram"],
                           capture_output=True, text=True, timeout=600, cwd=str(PROJ))
        # passes S1 (year declared); fails later at the markerless-paper gate —
        # the year gate itself must not be the blocker.
        self.assertNotIn("[FAIL] 9700_s15_qp_22.pdf: year", r.stdout)
        self.assertIn("STAGE S1 OK", r.stdout)


class TestConfigValidationStillGreen(unittest.TestCase):
    def test_all_configs_validate(self):
        from core.config_loader import validate_all_configs
        ok, errs = validate_all_configs()
        self.assertTrue(ok, errs)


if __name__ == "__main__":
    unittest.main()
