#!/usr/bin/env python3
"""MS-fetcher round — regression suite (Overseer online missing-MS resolver).

V1-V4: the spec's own VALIDATION TEST cases (imports ported to the REAL
package — the spec's `cambridge_qb` does not exist).
T5: verifier ACCEPTS a real Cambridge MS (uploads/9700_m25_ms_22.pdf).
T6: verifier REJECTS a QP masquerading as an MS (wrong-identity PDF).
T7: HERMETIC end-to-end via a localhost http.server (no external network):
    real Preflight builds a DB with a QP-only bundle -> resolver fetches the
    real MS bytes off the local server -> verifies -> bundle.ms_file_id set
    -> get_pending_bundles() returns ms_path == cached file (the actual
    consumption-path premise), ms_fetch_log has url/sha256/timestamp (RULE 3).
T8: 404 on every candidate + wrong-identity payload -> resolved=0;
    review path: .unverified.pdf kept, bundle status review_required with the
    REAL verifier reasons (spec F3 fix) — never into the pipeline (RULE 2).
T9: RULE 7 — `requests` missing -> exact required error message.
T10: print_manifest_report works BEFORE any fetch (F5: ensure_fetch_log
     guard) and reclassifies a fetched bundle afterwards.

HERMETIC: no test touches the external network. REQUEST_DELAY is patched to
0 in tests only; the production constant stays 2.0 (RULE 5, mandatory).
"""
import hashlib
import http.server
import json
import shutil
import sqlite3
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core import ms_fetcher as mf                        # noqa: E402
from core.database import Database                       # noqa: E402
from core.preflight import Preflight                     # noqa: E402

UPLOADS = Path("/home/user/uploads")
REAL_MS = UPLOADS / "9700_m25_ms_22.pdf"
REAL_QP = UPLOADS / "9700_m25_qp_22.pdf"


class SpecValidationTests(unittest.TestCase):
    """The spec's four validation cases, verbatim intent."""

    def test_v1_url_builder_alevel(self):
        builder = mf.URLBuilder()
        urls = builder.build_pastpapers_co("9701", "s", "24", "22")
        self.assertEqual(len(urls), 4)
        self.assertIn("9701_s24_ms_22.pdf", urls[0])
        self.assertEqual(
            urls[0],
            "https://pastpapers.co/cie/a-level/9701/2024/9701_s24_ms_22.pdf")

    def test_v2_url_builder_igcse(self):
        builder = mf.URLBuilder()
        urls = builder.build_pastpapers_co("0620", "m", "25", "42")
        self.assertIn("0620_m25_ms_42.pdf", urls[0])
        self.assertIn("/cie/igcse/0620/", urls[0])

    def test_v3_verifier_rejects_html(self):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            f.write(b"<html><body>Not a PDF</body></html>")
            fake = Path(f.name)
        try:
            result = mf.PDFVerifier().verify(fake, "9701", "s", "24", "22")
            self.assertFalse(result.is_pdf)
            self.assertFalse(result.passed)
            self.assertIn("File is not a valid PDF", result.failure_reasons)
        finally:
            fake.unlink()

    def test_v4_dry_run_lists_urls_no_download_no_log(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            inp = td / "in"
            inp.mkdir()
            shutil.copy2(REAL_QP, inp / REAL_QP.name)  # QP present, MS missing
            db_path = td / "out" / "pipeline.sqlite"
            pf = Preflight(pdf_dir=inp, output_dir=td / "out", db=Database(db_path))
            self.assertEqual(pf.run(), 1)  # returns new-bundle count

            resolver = mf.MissingMSResolver(db_path=db_path,
                                            cache_dir=td / "cache",
                                            dry_run=True)
            import io, contextlib
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                summary = resolver.resolve_all()
            out = buf.getvalue()
            self.assertEqual(summary["found"], 1)
            self.assertEqual(summary["resolved"], 0)
            self.assertEqual(summary["review"], 0)
            self.assertIn("would try 4 URLs", out)
            self.assertIn("9700_m25_ms_22.pdf", out)
            self.assertEqual(list((td / "cache").glob("**/*.pdf")), [])
            # F6: dry runs are NOT written to the log
            conn = sqlite3.connect(str(db_path))
            self.assertEqual(
                conn.execute("SELECT COUNT(*) FROM ms_fetch_log").fetchone()[0], 0)
            conn.close()
            # bundle still has no ms
            self.assertTrue(Database(db_path).bundle_exists("9700_m25_22"))


class VerifierRealIdentity(unittest.TestCase):
    def test_v5_real_ms_passes(self):
        r = mf.PDFVerifier().verify(REAL_MS, "9700", "m", "25", "22")
        self.assertTrue(r.is_pdf and r.opens_cleanly)
        self.assertTrue(r.syllabus_matches, r.failure_reasons)
        self.assertTrue(r.component_matches, r.failure_reasons)
        self.assertTrue(r.session_matches, r.failure_reasons)
        self.assertTrue(r.is_markscheme, r.failure_reasons)
        self.assertTrue(r.passed, r.failure_reasons)

    def test_v6_qp_masquerading_as_ms_fails(self):
        r = mf.PDFVerifier().verify(REAL_QP, "9700", "m", "25", "22")
        self.assertFalse(r.passed)
        self.assertFalse(r.is_markscheme)   # QP signals, no MS signals
        self.assertTrue(any("mark scheme" in x for x in r.failure_reasons))

    def test_specimen_season_year_only(self):
        # F4: 'sp' has no month words -> year-only check
        v = mf.PDFVerifier()
        self.assertTrue(v._check_session("cambridge 9700 specimen 2025", "sp", "25"))
        self.assertFalse(v._check_session("cambridge 9700 specimen 1999", "sp", "25"))


# --------------------------------------------------------------------------- #
# Hermetic localhost server serving fixture bytes
# --------------------------------------------------------------------------- #

class _QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


class _LocalServer:
    def __init__(self, root: Path):
        self.root = root
        handler = lambda *a, **k: _QuietHandler(*a, directory=str(root), **k)
        self.httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *a):
        self.httpd.shutdown()
        self.httpd.server_close()


class _LocalBuilder(mf.URLBuilder):
    """Inject-locally: same 4-candidate shape, localhost host."""
    def __init__(self, port):
        self.port = port

    def build_all(self, syllabus_code, season, year_short, component):
        base = f"http://127.0.0.1:{self.port}"
        fn = f"{syllabus_code}_{season}{year_short}_ms_{component}.pdf"
        return [{"source": "test-local", "url": f"{base}/{fn}"},
                {"source": "test-local", "url": f"{base}/alt/{fn}"}]


def _make_db(td: Path, with_ms: bool) -> Path:
    inp = td / "in"
    inp.mkdir()
    shutil.copy2(REAL_QP, inp / REAL_QP.name)
    if with_ms:
        shutil.copy2(REAL_MS, inp / REAL_MS.name)
    db_path = td / "out" / "pipeline.sqlite"
    pf = Preflight(pdf_dir=inp, output_dir=td / "out", db=Database(db_path))
    assert pf.run() == 1  # returns new-bundle count
    return db_path


class HermeticEndToEnd(unittest.TestCase):
    def setUp(self):
        self._delay = mf.REQUEST_DELAY
        mf.REQUEST_DELAY = 0          # tests only; production stays 2.0 (RULE 5)

    def tearDown(self):
        mf.REQUEST_DELAY = self._delay

    def test_t7_fetch_verify_wire_consume(self):
        with tempfile.TemporaryDirectory() as td0:
            td = Path(td0)
            db_path = _make_db(td, with_ms=False)
            # local server serves the REAL MS under the expected filename
            srv_root = td / "srv"
            (srv_root / "alt").mkdir(parents=True)
            shutil.copy2(REAL_MS, srv_root / "9700_m25_ms_22.pdf")

            with _LocalServer(srv_root) as srv:
                resolver = mf.MissingMSResolver(db_path=db_path,
                                                cache_dir=td / "cache")
                resolver.url_builder = _LocalBuilder(srv.port)
                summary = resolver.resolve_all()

            self.assertEqual(summary, {"found": 1, "resolved": 1,
                                       "review": 0, "failed": 0})
            cached = td / "cache" / "9700" / "9700_m25_ms_22.pdf"
            self.assertTrue(cached.exists())
            self.assertEqual(hashlib.sha256(cached.read_bytes()).hexdigest(),
                             hashlib.sha256(REAL_MS.read_bytes()).hexdigest())

            db = Database(db_path)
            # RULE 3: log row has url, source, sha256, timestamp
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM ms_fetch_log").fetchall()
            conn.close()
            self.assertEqual(len(rows), 1)
            r = rows[0]
            self.assertEqual(r["bundle_key"], "9700_m25_22")
            self.assertEqual(r["source"], "test-local")
            self.assertTrue(r["url"].startswith("http://127.0.0.1:"))
            self.assertEqual(len(r["sha256"]), 64)
            self.assertGreater(r["retrieved_at"], 0)
            self.assertEqual(r["success"], 1)
            self.assertEqual(r["verified"], 1)

            # THE consumption premise: next run's pending row now has ms_path
            pend = db.get_pending_bundles()
            self.assertEqual(len(pend), 1)
            self.assertEqual(pend[0]["ms_path"], str(cached))

            # files row registered via id-preserving UPSERT with identity cols
            conn = sqlite3.connect(str(db_path))
            frow = conn.execute(
                "SELECT kind, syllabus_code, component FROM files WHERE path=?",
                (str(cached),)).fetchone()
            conn.close()
            self.assertEqual(tuple(frow), ("ms", "9700", "22"))

            # second resolve: cache hit, no second download
            with _LocalServer(srv_root) as srv:
                resolver2 = mf.MissingMSResolver(db_path=db_path,
                                                 cache_dir=td / "cache")
                resolver2.url_builder = _LocalBuilder(srv.port)
            # bundle now HAS ms -> not in missing set at all
            self.assertEqual(resolver2.resolve_all()["found"], 0)

    def test_t8_not_found_and_unverified_review(self):
        with tempfile.TemporaryDirectory() as td0:
            td = Path(td0)
            db_path = _make_db(td, with_ms=False)
            # server serves the REAL QP (wrong identity) under the MS name
            srv_root = td / "srv"
            srv_root.mkdir()
            shutil.copy2(REAL_QP, srv_root / "9700_m25_ms_22.pdf")
            # /alt/ path does not exist -> 404 for candidate 2

            with _LocalServer(srv_root) as srv:
                resolver = mf.MissingMSResolver(db_path=db_path,
                                                cache_dir=td / "cache")
                resolver.url_builder = _LocalBuilder(srv.port)
                summary = resolver.resolve_all()

            # candidate 1 downloads a QP -> verification fails -> REVIEW (RULE 2)
            self.assertEqual(summary["found"], 1)
            self.assertEqual(summary["review"], 1)
            self.assertEqual(summary["resolved"], 0)
            unv = td / "cache" / "9700" / "9700_m25_ms_22.unverified.pdf"
            self.assertTrue(unv.exists())          # bytes kept for a human
            self.assertFalse((td / "cache" / "9700" / "9700_m25_ms_22.pdf").exists())

            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            b = conn.execute(
                "SELECT status, error_message, ms_file_id FROM bundles").fetchone()
            log = conn.execute("SELECT * FROM ms_fetch_log").fetchall()
            conn.close()
            self.assertEqual(b["status"], "review_required")
            self.assertIsNone(b["ms_file_id"])     # NOT wired into pipeline
            # F3: the REAL verifier reasons reach the bundle, not an empty join
            self.assertIn("mark scheme", b["error_message"])
            self.assertEqual(len(log), 1)
            self.assertEqual(log[0]["verified"], 0)
            self.assertIn("mark scheme", log[0]["error"])

            # and a pure-404 run reports failed (fresh DB)
            with tempfile.TemporaryDirectory() as td2:
                db2 = _make_db(Path(td2), with_ms=False)
                with _LocalServer(Path(td2) / "srv2_missing") as srv2:
                    pass  # directory missing -> all 404
            # (server exited; rebuild serving an EMPTY dir)
            with tempfile.TemporaryDirectory() as td3:
                db3 = _make_db(Path(td3), with_ms=False)
                empty = Path(td3) / "srv3"
                empty.mkdir()
                with _LocalServer(empty) as srv3:
                    r3 = mf.MissingMSResolver(db_path=db3, cache_dir=Path(td3) / "c")
                    r3.url_builder = _LocalBuilder(srv3.port)
                    s3 = r3.resolve_all()
                self.assertEqual(s3["failed"], 1)
                self.assertEqual(s3["resolved"], 0)


class RulesCompliance(unittest.TestCase):
    def test_t9_requests_missing_exact_message(self):
        dl = mf.Downloader()
        with mock.patch.dict(sys.modules, {"requests": None}):
            ok, err = dl.download("http://127.0.0.1:1/x.pdf",
                                  Path(tempfile.gettempdir()) / "nope.pdf")
        self.assertFalse(ok)
        self.assertEqual(err, "Install requests: pip install requests>=2.31.0")

    def test_t10_report_before_and_after_fetch(self):
        with tempfile.TemporaryDirectory() as td0:
            td = Path(td0)
            db_path = _make_db(td, with_ms=False)
            pf = Preflight(pdf_dir=td / "in", output_dir=td / "out",
                           db=Database(db_path))
            import io, contextlib
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                pf.print_manifest_report(Database(db_path))
            out = buf.getvalue()
            self.assertIn("MS_MISSING", out)
            self.assertIn("Ready to process: 0/1", out)

            srv_root = td / "srv"
            srv_root.mkdir()
            shutil.copy2(REAL_MS, srv_root / "9700_m25_ms_22.pdf")
            with _LocalServer(srv_root) as srv:
                resolver = mf.MissingMSResolver(db_path=db_path,
                                                cache_dir=td / "cache")
                resolver.url_builder = _LocalBuilder(srv.port)
                with contextlib.redirect_stdout(io.StringIO()):
                    resolver.resolve_all()
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                pf.print_manifest_report(Database(db_path))
            self.assertIn("READY", buf.getvalue())


if __name__ == "__main__":
    unittest.main(verbosity=2)
