# Classification System Lock

The topic classifier is read-only except by maintainer-authorised amendment.
Folder routing and metadata must only consume its output.

## Baseline (Amendment CLS-1, 2026-08-10): Merged classifier v1.1 — authorised by the maintainer

The maintainer approved (`cls_approach=merge_into_core`) folding the five spec scoring
factors into the existing `core/classifier.py` point system **in place**, keeping the
routing contract (main.py integration unchanged). `original_reference/cambridge_qb/topics_enhanced.py`
and all `original_reference/topics/*/*_topics.json` remain byte-for-byte untouched.

Maintainer decisions folded into the merge:
- **Fallback = spec_forced**: paper-hint chain then alphabetical-first, loudly logged
  (`[classifier-fallback]` ERROR lines). No `Needs_Review` topic.
- **QP-only evidence**: MS corpus input and the `ms_hits * 0.8` bonus are retired.
- **No taxonomy JSON file**: taxonomy stays in the existing per-subject `config.json`
  (`major_topics` / `detailed_topics` / `classification_keywords` / `mapping` /
  `specialization_weights`, plus optional `paper_affinity`).

Engineering facts of the merged engine:
- `MAX_TOPICS = 4`, `FORMULA_BONUS = 3.0`, `COMMAND_MULTIPLIER = 1.5`,
  `COLLISION_THRESHOLD = 0.40`, `COLLISION_DAMPEN = 0.5`.
- Relative mark weight = `subpart_marks / mean_part_marks` (absolute mark weights
  break the calibrated 1.5/1.0 thresholds; `[Total: n]` excluded from extraction).
- `_CHEM_SYMBOL_MAP` includes the U+2212 minus fix; `_SUBSCRIPT_MAP` normalises
  Unicode subscripts; command-verb boost and sub-part parsing per spec.

Evidence: 21/21 exact-arithmetic factor checks
(`test-crops/cls-tests/test_factor_units.py`); 5/6 production baseline decisions
byte-identical (`test-crops/cls-tests/capture_classification.py` + `baseline.json`);
F5 intentionally DIFF (MS-isolation now QP-only, per the approved QP-only decision).

## Locked SHA-256

| File | SHA-256 |
|---|---|
| `core/classifier.py` | `3c92f8e772508ef7755be46abac5c7be3a21c84aac769202cd9ee3686464a3c3` |

Note: quality tooling may read classifier output via `metadata.json` only; the
metadata schema (single `topic` array, max 4 entries, no score sidecars) is part of
this lock.

## Amendment CLS-2 (2026-08-10): Subject-aware fallback paper hints — authorised by the maintainer

Final-upgrade Issue 2. `_FALLBACK_PAPER_HINTS` was a single Chemistry-shaped
map keyed by paper number; it is now keyed **per subject**
(`Chemistry_9701` content preserved verbatim; `Biology_9700` and `Physics_9702`
added from the directive; unlisted subjects keep the previous behaviour).
Resolution is guarded: `_resolve_hint_topic` maps a hint onto a CONFIGURED
detailed topic only (exact, then case/space-insensitive, then unique normalised
prefix/containment) and can never invent a topic. The forced-fallback chain
order (weak-keyword → paper hints → alphabetical-first, always loudly logged)
is unchanged, as are the 1.5 threshold, ≤4-topic cap, metadata schema and all
scoring factors.

Evidence: new suite `test-crops/final-fixes/test_final_fixes.py` 36/36 (I2
section: Chem hints fire only on Chemistry config; Biology paper 2 can never
receive `Atomic_structure`/`Bonding`; unlisted subjects keep the old chain);
real-paper classify regression `test-crops/final-fixes/classify_regression.py`
18/18 on 9700 m25 + w25 — m25 winners byte-identical to the CLS-1 approved set
(Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5 Genetics);
factor suite 21/21 re-run green.

### Updated SHA-256 (Amendment CLS-2)

| File | SHA-256 |
|---|---|
| `core/classifier.py` | `2936b7a63fa5de7a97320d1982710e72c5cbc74e68938784c0c67e6a72571d79` |

Data note (recorded, unwired): the maintainer-supplied 22-file taxonomy batch
now lives at `topics/A-Level/*.json` (9) and `topics/IGCSE/*.json` (13) as
shadow assets — 148 topics total, validated. Nothing in the pipeline reads
`topics/`; wiring any file into `subjects/*/config.json` requires a CLS
amendment with evidence.
