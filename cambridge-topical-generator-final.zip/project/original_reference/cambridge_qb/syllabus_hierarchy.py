"""
syllabus_hierarchy.py
=====================
Authoritative Single Source of Truth for Cambridge Official Syllabus Major Topics
and Detailed Subtopic Hierarchy across ALL Cambridge A-Level and IGCSE Subjects.

Enforces Sections 31–46 Requirements:
  1. LEVEL 1 (Detailed topics): Stored in JSON "topic" array.
  2. LEVEL 2 (Major topics): Determines physical folder names on disk.
  3. EXACT OFFICIAL NAMES: Folder names are derived directly from the official syllabus
     major topic configuration (e.g. Chemical_energetics, Organic_chemistry, Equilibria,
     Electrochemistry, Atomic_structure, Reaction_kinetics).
  4. ZERO GENERIC FOLDERS: No Topic_1, Category_1, General, Other, Uncategorized.
  5. ZERO SUBTOPIC FOLDERS: Detailed topics (Carbonyl_compounds, Hydrocarbons, Hess_law)
     are never created as folders; they resolve strictly to their parent Major Topic.
  6. SINGLE-FOLDER QUESTION ROUTING: Uses concept point scoring to select the single
     winning major topic folder for each question.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


@dataclass
class MajorTopicDef:
    id: str                                  # Filesystem-safe name (e.g., Chemical_energetics)
    display_name: str                        # Official human name (e.g., Chemical energetics)
    minor_topics: List[str]                  # Detailed syllabus topics belonging here
    keywords: List[str] = field(default_factory=list)
    syllabus_order: int = 99


# =============================================================================
# Comprehensive Official Syllabus Configurations for All Cambridge Subjects
# =============================================================================

SYLLABUS_CONFIGURATIONS: Dict[str, Dict[str, MajorTopicDef]] = {
    # -------------------------------------------------------------------------
    # Cambridge A-Level Chemistry (9701) & IGCSE/O-Level Chemistry (0620 / 5070)
    # -------------------------------------------------------------------------
    "9701": {
        "Atomic_structure": MajorTopicDef(
            id="Atomic_structure",
            display_name="Atomic structure",
            minor_topics=["Atomic_structure", "Subatomic_particles", "Electronic_configuration", "Ionisation_energies"],
            syllabus_order=1,
        ),
        "Amount_of_substance": MajorTopicDef(
            id="Amount_of_substance",
            display_name="Amount of substance",
            minor_topics=["Atoms,_molecules_and_stoichiometry", "Atoms_molecules_and_stoichiometry", "Stoichiometry", "Amount_of_Substance", "Mole_concept", "Empirical_formulae"],
            syllabus_order=2,
        ),
        "Chemical_bonding": MajorTopicDef(
            id="Chemical_bonding",
            display_name="Chemical bonding",
            minor_topics=["Chemical_bonding", "Bonding", "Intermolecular_forces", "VSEPR_molecular_shapes", "Dot_and_cross"],
            syllabus_order=3,
        ),
        "States_of_matter": MajorTopicDef(
            id="States_of_matter",
            display_name="States of matter",
            minor_topics=["States_of_matter", "Ideal_gases", "Kinetic_theory", "Lattice_structures"],
            syllabus_order=4,
        ),
        "Chemical_energetics": MajorTopicDef(
            id="Chemical_energetics",
            display_name="Chemical energetics",
            minor_topics=["Chemical_energetics", "Enthalpy_changes", "Hess_law", "Bond_energies", "Lattice_energy", "Born_Haber_cycle", "Entropy", "Gibbs_free_energy"],
            syllabus_order=5,
        ),
        "Electrochemistry": MajorTopicDef(
            id="Electrochemistry",
            display_name="Electrochemistry",
            minor_topics=["Electrochemistry", "Redox_processes", "Standard_electrode_potentials", "Electrolysis", "Cell_potentials", "Nernst_equation"],
            syllabus_order=6,
        ),
        "Equilibria": MajorTopicDef(
            id="Equilibria",
            display_name="Equilibria",
            minor_topics=["Equilibria", "Chemical_equilibria", "Le_Chatelier", "Kc", "Kp", "Ka", "Kb", "Kw", "pH", "Buffer_solutions", "Solubility_product", "Ksp", "Partition_coefficient"],
            syllabus_order=7,
        ),
        "Reaction_kinetics": MajorTopicDef(
            id="Reaction_kinetics",
            display_name="Reaction kinetics",
            minor_topics=["Reaction_kinetics", "Rate_of_reaction", "Rate_equations", "Order_of_reaction", "Arrhenius_equation", "Catalysis", "Half_life"],
            syllabus_order=8,
        ),
        "Periodicity": MajorTopicDef(
            id="Periodicity",
            display_name="Periodicity",
            minor_topics=["Periodicity", "The_Periodic_Table;_chemical_periodicity", "Period_3_elements"],
            syllabus_order=9,
        ),
        "Group_chemistry": MajorTopicDef(
            id="Group_chemistry",
            display_name="Group chemistry",
            minor_topics=["Group_2", "Group_17", "Nitrogen_and_sulfur", "Halogens", "Alkaline_earth_metals", "Inorganic_Chemistry"],
            syllabus_order=10,
        ),
        "Transition_elements": MajorTopicDef(
            id="Transition_elements",
            display_name="Transition elements",
            minor_topics=["Chemistry_of_transition_elements", "Transition_Elements", "Complex_ions", "Ligand_exchange", "Color_of_complexes"],
            syllabus_order=11,
        ),
        "Organic_chemistry": MajorTopicDef(
            id="Organic_chemistry",
            display_name="Organic chemistry",
            minor_topics=[
                "An_introduction_to_AS_Level_organic_chemistry",
                "Hydrocarbons",
                "Halogen_compounds",
                "Hydroxy_compounds",
                "Carbonyl_compounds",
                "Carboxylic_acids_and_derivatives",
                "Nitrogen_compounds",
                "Polymerisation",
                "Organic_synthesis",
                "Organic_Chemistry",
                "Alkanes",
                "Alkenes",
                "Arenes",
                "Alcohols",
                "Aldehydes_and_ketones",
                "Carboxylic_acids",
                "Esters",
                "Acyl_chlorides",
                "Amides",
                "Amines",
                "Amino_acids",
                "Polymers",
            ],
            syllabus_order=12,
        ),
        "Analytical_techniques": MajorTopicDef(
            id="Analytical_techniques",
            display_name="Analytical techniques",
            minor_topics=["Analytical_techniques", "Infrared_spectroscopy", "NMR_spectroscopy", "Mass_spectrometry", "Chromatography"],
            syllabus_order=13,
        ),
    },

    # -------------------------------------------------------------------------
    # Cambridge A-Level Physics (9702) & IGCSE Physics (0625 / 5054)
    # -------------------------------------------------------------------------
    "9702": {
        "Physical_quantities_and_units": MajorTopicDef(
            id="Physical_quantities_and_units",
            display_name="Physical quantities and units",
            minor_topics=["Physical_quantities_and_units", "SI_units", "Errors_and_uncertainties", "Vectors_and_scalars"],
            syllabus_order=1,
        ),
        "Kinematics_and_dynamics": MajorTopicDef(
            id="Kinematics_and_dynamics",
            display_name="Kinematics and dynamics",
            minor_topics=["Kinematics", "Dynamics", "Motion_graphs", "Equations_of_motion", "Newton_laws", "Momentum"],
            syllabus_order=2,
        ),
        "Forces_and_pressure": MajorTopicDef(
            id="Forces_and_pressure",
            display_name="Forces, density and pressure",
            minor_topics=["Forces,_density_and_pressure", "Turning_effects", "Equilibrium_of_forces", "Density_and_pressure"],
            syllabus_order=3,
        ),
        "Work_energy_and_power": MajorTopicDef(
            id="Work_energy_and_power",
            display_name="Work, energy and power",
            minor_topics=["Work,_energy_and_power", "Work_done", "Kinetic_and_potential_energy", "Efficiency"],
            syllabus_order=4,
        ),
        "Deformation_of_solids": MajorTopicDef(
            id="Deformation_of_solids",
            display_name="Deformation of solids",
            minor_topics=["Deformation_of_solids", "Stress_and_strain", "Hooke_law", "Young_modulus"],
            syllabus_order=5,
        ),
        "Waves_and_superposition": MajorTopicDef(
            id="Waves_and_superposition",
            display_name="Waves and superposition",
            minor_topics=["Waves", "Superposition", "Stationary_waves", "Diffraction", "Interference", "Doppler_effect"],
            syllabus_order=6,
        ),
        "Electricity_and_circuits": MajorTopicDef(
            id="Electricity_and_circuits",
            display_name="Electricity and circuits",
            minor_topics=["Electricity", "D.C._circuits", "Electric_current", "Potential_difference", "Kirchhoff_laws", "Potential_dividers"],
            syllabus_order=7,
        ),
        "Particle_and_nuclear_physics": MajorTopicDef(
            id="Particle_and_nuclear_physics",
            display_name="Particle and nuclear physics",
            minor_topics=["Particle_physics", "Nuclear_physics", "Radioactivity", "Nuclear_decay", "Mass_defect"],
            syllabus_order=8,
        ),
        "Circular_motion_and_gravitation": MajorTopicDef(
            id="Circular_motion_and_gravitation",
            display_name="Circular motion and gravitation",
            minor_topics=["Motion_in_a_circle", "Gravitational_fields", "Centripetal_force", "Gravitational_potential"],
            syllabus_order=9,
        ),
        "Thermal_physics": MajorTopicDef(
            id="Thermal_physics",
            display_name="Thermal physics",
            minor_topics=["Temperature", "Ideal_gases", "Thermodynamics", "Specific_heat_capacity", "First_law_of_thermodynamics"],
            syllabus_order=10,
        ),
        "Oscillations": MajorTopicDef(
            id="Oscillations",
            display_name="Oscillations",
            minor_topics=["Oscillations", "Simple_harmonic_motion", "Damped_and_forced_oscillations", "Resonance"],
            syllabus_order=11,
        ),
        "Fields_and_capacitance": MajorTopicDef(
            id="Fields_and_capacitance",
            display_name="Fields and capacitance",
            minor_topics=["Electric_fields", "Capacitance", "Magnetic_fields", "Electromagnetic_induction", "Alternating_currents"],
            syllabus_order=12,
        ),
        "Quantum_and_medical_physics": MajorTopicDef(
            id="Quantum_and_medical_physics",
            display_name="Quantum and medical physics",
            minor_topics=["Quantum_physics", "Photoelectric_effect", "Medical_physics", "Astronomy_and_cosmology", "X_rays", "Ultrasound"],
            syllabus_order=13,
        ),
    },

    # -------------------------------------------------------------------------
    # Cambridge A-Level Biology (9700) & IGCSE Biology (0610 / 5090)
    # -------------------------------------------------------------------------
    "9700": {
        "Cell_biology": MajorTopicDef(
            id="Cell_biology",
            display_name="Cell biology",
            minor_topics=["Cell_structure", "Cell_membranes_and_transport", "The_mitotic_cell_cycle", "Microscopy"],
            syllabus_order=1,
        ),
        "Biological_molecules_and_enzymes": MajorTopicDef(
            id="Biological_molecules_and_enzymes",
            display_name="Biological molecules and enzymes",
            minor_topics=["Biological_molecules", "Enzymes", "Carbohydrates", "Lipids", "Proteins", "Enzyme_kinetics"],
            syllabus_order=2,
        ),
        "Molecular_genetics": MajorTopicDef(
            id="Molecular_genetics",
            display_name="Molecular genetics",
            minor_topics=["Nucleic_acids_and_protein_synthesis", "DNA_replication", "Transcription_and_translation", "Genetic_code"],
            syllabus_order=3,
        ),
        "Transport_systems": MajorTopicDef(
            id="Transport_systems",
            display_name="Transport systems",
            minor_topics=["Transport_in_plants", "Transport_in_mammals", "Gas_exchange", "Cardiovascular_system", "Xylem_and_phloem"],
            syllabus_order=4,
        ),
        "Immunity_and_pathology": MajorTopicDef(
            id="Immunity_and_pathology",
            display_name="Immunity and pathology",
            minor_topics=["Infectious_diseases", "Immunity", "Antibodies", "Vaccination", "Phagocytosis"],
            syllabus_order=5,
        ),
        "Metabolism_and_energy": MajorTopicDef(
            id="Metabolism_and_energy",
            display_name="Metabolism and energy",
            minor_topics=["Energy_and_respiration", "Photosynthesis", "ATP_synthesis", "Calvin_cycle", "Krebs_cycle"],
            syllabus_order=6,
        ),
        "Homeostasis_and_coordination": MajorTopicDef(
            id="Homeostasis_and_coordination",
            display_name="Homeostasis and coordination",
            minor_topics=["Homeostasis", "Control_and_coordination", "Nervous_system", "Endocrine_system", "Kidneys"],
            syllabus_order=7,
        ),
        "Genetics_evolution_and_biotech": MajorTopicDef(
            id="Genetics_evolution_and_biotech",
            display_name="Genetics, evolution and biotechnology",
            minor_topics=["Inheritance", "Selection_and_evolution", "Classification,_biodiversity_and_conservation", "Genetic_technology", "Recombinant_DNA"],
            syllabus_order=8,
        ),
    },

    # -------------------------------------------------------------------------
    # Cambridge A-Level Computer Science (9618 / 9608) & IGCSE CS (0478)
    # -------------------------------------------------------------------------
    "9618": {
        "Data_representation": MajorTopicDef(
            id="Data_representation",
            display_name="Data representation",
            minor_topics=["Information_representation", "Data_Representation", "Binary_and_hexadecimal", "Multimedia_data"],
            syllabus_order=1,
        ),
        "Networks_and_communication": MajorTopicDef(
            id="Networks_and_communication",
            display_name="Networks and communication",
            minor_topics=["Communication_and_Internet_technologies", "Communication_and_Internet_Technologies", "Protocols", "Network_topologies"],
            syllabus_order=2,
        ),
        "Hardware_and_software": MajorTopicDef(
            id="Hardware_and_software",
            display_name="Hardware and software",
            minor_topics=["Hardware", "Processor_Fundamentals", "Hardware_and_Virtual_Machines", "System_Software", "System_Software_Advanced"],
            syllabus_order=3,
        ),
        "Security_and_ethics": MajorTopicDef(
            id="Security_and_ethics",
            display_name="Security and ethics",
            minor_topics=["Security,_privacy_and_data_integrity", "Ethics_and_Ownership", "Security"],
            syllabus_order=4,
        ),
        "Databases": MajorTopicDef(
            id="Databases",
            display_name="Databases",
            minor_topics=["Databases", "Relational_databases", "SQL", "Database_normalization"],
            syllabus_order=5,
        ),
        "Algorithms_and_data_structures": MajorTopicDef(
            id="Algorithms_and_data_structures",
            display_name="Algorithms and data structures",
            minor_topics=["Algorithm_Design_and_Problem-Solving", "Data_Types_and_Structures", "Computational_Thinking_and_Problem-Solving", "Stacks_queues_trees", "Sorting_and_searching"],
            syllabus_order=6,
        ),
        "Programming_and_software": MajorTopicDef(
            id="Programming_and_software",
            display_name="Programming and software",
            minor_topics=["Programming", "Software_Development", "Further_Programming", "Object_oriented_programming", "Recursion"],
            syllabus_order=7,
        ),
        "Artificial_intelligence": MajorTopicDef(
            id="Artificial_intelligence",
            display_name="Artificial intelligence",
            minor_topics=["Artificial_Intelligence", "Machine_learning", "Neural_networks", "Expert_systems"],
            syllabus_order=8,
        ),
    },

    # -------------------------------------------------------------------------
    # Cambridge A-Level Mathematics (9709) & IGCSE Maths (0580 / 4024)
    # -------------------------------------------------------------------------
    "9709": {
        "Pure_mathematics_algebra": MajorTopicDef(
            id="Pure_mathematics_algebra",
            display_name="Pure mathematics: algebra and functions",
            minor_topics=["Algebra", "Functions", "Coordinate_geometry", "Circular_measure", "Series"],
            syllabus_order=1,
        ),
        "Pure_mathematics_calculus": MajorTopicDef(
            id="Pure_mathematics_calculus",
            display_name="Pure mathematics: calculus and trigonometry",
            minor_topics=["Trigonometry", "Differentiation", "Integration", "Differential_equations", "Vectors", "Complex_numbers"],
            syllabus_order=2,
        ),
        "Mechanics": MajorTopicDef(
            id="Mechanics",
            display_name="Mechanics",
            minor_topics=["Kinematics_mechanics", "Forces_and_equilibrium", "Momentum_mechanics", "Newton_laws_mechanics", "Work_energy_power_mechanics"],
            syllabus_order=3,
        ),
        "Probability_and_statistics": MajorTopicDef(
            id="Probability_and_statistics",
            display_name="Probability and statistics",
            minor_topics=["Representation_of_data", "Permutations_and_combinations", "Probability", "Discrete_random_variables", "Normal_distribution", "Hypothesis_testing"],
            syllabus_order=4,
        ),
    },

    # -------------------------------------------------------------------------
    # Cambridge A-Level Economics (9708) & IGCSE Economics (0455)
    # -------------------------------------------------------------------------
    "9708": {
        "Basic_economic_ideas": MajorTopicDef(
            id="Basic_economic_ideas",
            display_name="Basic economic ideas and resource allocation",
            minor_topics=["Basic_economic_ideas", "Scarcity_choice_opportunity_cost", "Production_possibility_curves", "Classification_of_goods"],
            syllabus_order=1,
        ),
        "Price_system_and_microeconomy": MajorTopicDef(
            id="Price_system_and_microeconomy",
            display_name="The price system and the microeconomy",
            minor_topics=["The_price_system_and_the_microeconomy", "Demand_and_supply", "Price_elasticity", "Consumer_and_producer_surplus", "Market_equilibrium"],
            syllabus_order=2,
        ),
        "Government_micro_intervention": MajorTopicDef(
            id="Government_micro_intervention",
            display_name="Government microeconomic intervention",
            minor_topics=["Government_microeconomic_intervention", "Maximum_and_minimum_prices", "Taxes_and_subsidies", "Direct_provision", "Market_failure"],
            syllabus_order=3,
        ),
        "The_macroeconomy": MajorTopicDef(
            id="The_macroeconomy",
            display_name="The macroeconomy",
            minor_topics=["The_macroeconomy", "National_income", "Aggregate_demand_and_supply", "Inflation", "Balance_of_payments", "Exchange_rates"],
            syllabus_order=4,
        ),
        "Government_macro_intervention": MajorTopicDef(
            id="Government_macro_intervention",
            display_name="Government macroeconomic intervention",
            minor_topics=["Government_macroeconomic_intervention", "Fiscal_policy", "Monetary_policy", "Supply_side_policy", "International_trade_policies"],
            syllabus_order=5,
        ),
    },
}

# Alias subject codes (IGCSE & O-Level mappings to corresponding parent syllabus)
SYLLABUS_CODE_ALIASES: Dict[str, str] = {
    "0620": "9701", "5070": "9701",
    "0625": "9702", "5054": "9702",
    "0610": "9700", "5090": "9700",
    "0478": "9618", "0984": "9618", "9608": "9618",
    "0580": "9709", "4024": "9709", "9231": "9709",
    "0455": "9708",
    "0450": "9708", "9609": "9708",
    "0445": "9701", "9706": "9701",
}


def get_subject_config(syllabus_code: str = "") -> Dict[str, MajorTopicDef]:
    """Retrieve official Major Topic definitions for the syllabus."""
    code = str(syllabus_code or "").strip()
    target_code = SYLLABUS_CODE_ALIASES.get(code, code)
    return SYLLABUS_CONFIGURATIONS.get(target_code, SYLLABUS_CONFIGURATIONS["9701"])


def resolve_detailed_to_major_topic(detailed_topic: str, syllabus_code: str = "") -> str:
    """
    Authoritative resolution of a detailed syllabus subtopic to its official Major Topic ID.
    Never returns a subtopic name.
    """
    cleaned = str(detailed_topic).strip()
    if not cleaned or cleaned == "Uncategorized":
        return "Uncategorized"

    subject_cfg = get_subject_config(syllabus_code)

    # 1. Direct match with major topic ID
    if cleaned in subject_cfg:
        return subject_cfg[cleaned].id

    # 2. Match against minor topics of every major topic
    for major_id, major_def in subject_cfg.items():
        if cleaned in major_def.minor_topics:
            return major_id
        # Case-insensitive / whitespace match
        for minor in major_def.minor_topics:
            if cleaned.lower().replace(" ", "_") == minor.lower().replace(" ", "_"):
                return major_id

    # 3. Fallback: check 9701 Chemistry master map
    for major_id, major_def in SYLLABUS_CONFIGURATIONS["9701"].items():
        if cleaned in major_def.minor_topics:
            return major_id

    # 4. Universal clean format
    return cleaned.replace(" ", "_")


def get_major_topic_display_name(major_topic_id: str, syllabus_code: str = "") -> str:
    """Return the official human-readable display name for a Major Topic."""
    subject_cfg = get_subject_config(syllabus_code)
    if major_topic_id in subject_cfg:
        return subject_cfg[major_topic_id].display_name
    return major_topic_id.replace("_", " ")
