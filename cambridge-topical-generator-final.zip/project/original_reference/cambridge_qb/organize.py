"""
organize.py
===========
Authoritative question bank organization with single-folder question distribution (Sections 31–46):
  1. LEVEL 1 (Detailed Topics in JSON): Retains all detected specific topics in "topic" array.
  2. LEVEL 2 (Major Topics on Disk): Physical folders use ONLY official Major Topic names
     (e.g., Chemical_energetics, Organic_chemistry, Equilibria, Electrochemistry,
     Atomic_structure, Reaction_kinetics, Amount_of_substance, Chemical_bonding).
  3. POINT-BASED SINGLE FOLDER: Evaluates subparts, marks, and concept strength to route
     each question to EXACTLY ONE winning major-topic folder.
  4. ZERO SUBTOPIC FOLDERS: Detailed topics (Carbonyl_compounds, Hydrocarbons, Hess_law)
     are never created as folders.
  5. ZERO DUPLICATES: Every question ID exists in exactly one major-topic folder on disk.
  6. STRICT JSON METADATA: Zero "topic_details", "primary", "secondary", or "needs_review".
  7. EXACT 2280px WIDTH: All saved question images are exactly 2280 pixels wide.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Union

from PIL import Image

from .markscheme import _is_mcq_paper, lookup_mark_scheme
from .metadata import build_metadata, compute_topic_field, write_metadata
from .ms_crop import crop_to_mark_box  # PROTECTED - DO NOT MODIFY
from .multipage_optimizer import assemble_multipage_question, enforce_exact_width_2280
from .question_split import Question
from .reference import canonical_season
from .syllabus_hierarchy import (
    MajorTopicDef,
    get_subject_config,
    resolve_detailed_to_major_topic,
    get_major_topic_display_name,
)
from .webp_utils import save_webp

NEEDS_REVIEW = "Needs_Review"

_PAPER_FOLDER_BY_N = {
    2: "P2_AS_Structured",
    3: "P3_Practical_Skills",
    4: "P4_A2_Structured",
    5: "P5_Plan_Analysis",
    6: "P6_Alt_to_Practical",
}

_CS_9618_PAPER_FOLDERS = {
    1: "P1_Theory_Fundamentals",
    2: "P2_Problem_Solving_Programming",
    3: "P3_Advanced_Theory",
    4: "P4_Practical",
}


def select_winning_major_topic(q: Question, syllabus_code: str = "") -> str:
    """
    Concept-based point allocation to determine the single winning Major Topic folder:
      1. Resolves all detailed topics to official syllabus Major Topics.
      2. Sums concept points based on detailed scores and subpart-level attributions (+4.0 pts per testing subpart).
      3. Selects the single highest-scoring Major Topic.
      4. Deterministic tie-breaker uses official syllabus hierarchy order.
    """
    specific_topics = compute_topic_field(q)
    if not specific_topics or specific_topics == ["Uncategorized"]:
        return NEEDS_REVIEW

    subject_cfg = get_subject_config(syllabus_code)
    major_scores: Dict[str, float] = {}
    subpart_counts: Dict[str, int] = {}

    # 1. Base scores from detailed topic classification
    mr = getattr(q, "_multi_topic_result", None)
    for st in specific_topics:
        major_id = resolve_detailed_to_major_topic(st, syllabus_code=syllabus_code)
        if not major_id or major_id == "Uncategorized":
            continue

        base_score = 5.0
        if mr and hasattr(mr, "confidence_scores") and st in mr.confidence_scores:
            base_score = mr.confidence_scores[st] * 10.0
        elif getattr(q, "topic_scores", None) and st in q.topic_scores:
            base_score = q.topic_scores[st]

        major_scores[major_id] = major_scores.get(major_id, 0.0) + base_score

    # 2. Subpart-level attributions bonus
    if mr and hasattr(mr, "subpart_topics") and mr.subpart_topics:
        for sub_label, st in mr.subpart_topics.items():
            major_id = resolve_detailed_to_major_topic(st, syllabus_code=syllabus_code)
            if major_id and major_id != "Uncategorized":
                major_scores[major_id] = major_scores.get(major_id, 0.0) + 4.0
                subpart_counts[major_id] = subpart_counts.get(major_id, 0) + 1

    if not major_scores:
        first_major = resolve_detailed_to_major_topic(specific_topics[0], syllabus_code=syllabus_code)
        return first_major if first_major != "Uncategorized" else NEEDS_REVIEW

    # 3. Deterministic ranking & tie-breaker
    def rank_tuple(mt: str) -> Tuple[float, int, int]:
        score = major_scores.get(mt, 0.0)
        sub_cnt = subpart_counts.get(mt, 0)
        order_idx = subject_cfg[mt].syllabus_order if mt in subject_cfg else 999
        return (score, sub_cnt, -order_idx)

    ranked_majors = sorted(major_scores.keys(), key=rank_tuple, reverse=True)
    return ranked_majors[0]


def get_major_topics_for_question(q: Question, syllabus_code: str = "") -> List[str]:
    """
    Return the SINGLE winning major topic for physical folder destination (Sections 38–46).
    """
    winner = select_winning_major_topic(q, syllabus_code=syllabus_code)
    return [winner]


def _paper_type_folder(paper_code: str, syllabus: str | None = None) -> str:
    """Determine the paper type folder name."""
    code = str(paper_code or "").lstrip("0")
    try:
        n = int(code[0])
    except (TypeError, ValueError, IndexError):
        n = 2
    if syllabus == "9618":
        return _CS_9618_PAPER_FOLDERS.get(n, f"P{n}_Structured")
    if n == 1:
        return "MCQ_P1" if _is_mcq_paper(paper_code, syllabus=syllabus) else "P1_Structured"
    return _PAPER_FOLDER_BY_N.get(n, f"P{n}_Structured")


def _write_question_files(
    q: Question,
    folder: Path,
    base: str,
    ms_entry,
    *,
    is_mcq: bool = False,
    webp_quality: int = 88,
) -> None:
    """
    Write question image (exactly 2280px wide) + mark scheme sidecar.
    """
    folder.mkdir(parents=True, exist_ok=True)

    real_imgs = [im for im in q.images if im.height >= 17]
    if not real_imgs:
        real_imgs = q.images

    # Assemble with whitespace optimization and enforce exactly 2280px width
    if len(real_imgs) > 1:
        question_img = assemble_multipage_question(real_imgs, target_width=2280)
    else:
        question_img = enforce_exact_width_2280(real_imgs[0], target_width=2280)

    # Save the question image (guaranteed exactly 2280px wide)
    save_webp(question_img, folder / f"{base}.webp", quality=webp_quality)

    # Save mark scheme sidecar if available
    if ms_entry is None:
        return

    if isinstance(ms_entry, Image.Image):
        try:
            ms_entry = crop_to_mark_box(ms_entry)
            max_dimension = 16300
            if ms_entry.width > max_dimension or ms_entry.height > max_dimension:
                scale = min(max_dimension / ms_entry.width, max_dimension / ms_entry.height)
                new_size = (max(1, int(round(ms_entry.width * scale))), max(1, int(round(ms_entry.height * scale))))
                ms_entry = ms_entry.resize(new_size, Image.Resampling.LANCZOS)
            save_webp(ms_entry, folder / f"{base}_MS.webp", quality=webp_quality)
        except Exception as e:
            print(f"[organize] WARNING: could not write MS image for {base}: {e}")
        return

    if isinstance(ms_entry, str):
        ms_text = ms_entry.strip()
        if not ms_text:
            return
        is_mcq_letter = (len(ms_text) == 1 and ms_text.upper() in "ABCD" and "\n" not in ms_text)
        txt = (ms_text.upper() + "\n") if is_mcq_letter else (ms_text + "\n")
        ms_path = folder / f"{base}_MS.txt"
        try:
            ms_path.write_text(txt, encoding="utf-8")
        except OSError as e:
            print(f"[organize] WARNING: could not write {ms_path}: {e}")


def organize(
    questions: List[Question],
    ms_index: Dict[tuple, Union[str, Image.Image]],
    *,
    output_dir: str,
    subject: str,
    level: str,
    board: str,
    syllabus_code: str,
    webp_quality: int = 88,
    require_mark_scheme: bool = False,
    cross_folder_enabled: bool = False,
) -> List[dict]:
    """
    Organize questions into SINGLE winning major-topic folder (Sections 31–46):
      1. Evaluates all detailed topics and determines the single winning Major Topic.
      2. Saves QP/MS files into that ONE major-topic folder ONLY (zero subtopic folders, zero duplicate folders).
      3. Saves exact 2280px wide image and strict metadata JSON.
      4. Generates master cross-reference index mapping questions to topics and folder.
    """
    root = Path(output_dir)
    subject_dir = root / subject
    if subject_dir.exists():
        shutil.rmtree(subject_dir)

    written_meta: List[dict] = []
    all_folders: Dict[str, Path] = {}

    for q in questions:
        if q.is_duplicate or not q.images:
            continue

        q.paper_code = str(q.paper_code or "").lstrip("0") or str(q.paper_code or "")
        session_label = canonical_season(q.session_label or "Unknown")
        base = f"{q.paper_code}_{session_label}_{q.year}_Q{q.question_number}"
        folder_name = base

        meta = build_metadata(
            q,
            subject=subject,
            level=level,
            board=board,
            syllabus_code=syllabus_code,
        )

        is_mcq = _is_mcq_paper(q.paper_code, syllabus=syllabus_code)

        ms_entry = getattr(q, "ms_entry", None)
        if ms_entry is None:
            ms_entry = lookup_mark_scheme(
                ms_index,
                paper_code=q.paper_code,
                question_number=q.question_number,
                session_label=session_label,
                year=q.year,
            )
        if isinstance(ms_entry, str):
            t = ms_entry.strip()
            if is_mcq and len(t) == 1 and t.upper() in "ABCD" and "\n" not in t:
                pass
        elif not isinstance(ms_entry, Image.Image):
            ms_entry = None

        if require_mark_scheme and ms_entry is None:
            print(f"[organize] SKIP {base}: no exact matching mark scheme")
            continue

        # Single winning Major Topic folder derived from official syllabus config (Sections 31-46)
        winning_major_topic = select_winning_major_topic(q, syllabus_code=syllabus_code)
        pt_folder = _paper_type_folder(q.paper_code, syllabus=syllabus_code)

        # Store question in ONE major-topic folder ONLY
        target_folder = root / subject / pt_folder / winning_major_topic / folder_name
        _write_question_files(
            q,
            target_folder,
            base,
            ms_entry,
            is_mcq=is_mcq,
            webp_quality=webp_quality,
        )
        write_metadata(target_folder / "metadata.json", meta)
        all_folders[base] = target_folder
        written_meta.append(meta)

    # Generate master cross-reference index
    if all_folders:
        _write_cross_reference_index(root / subject, all_folders, questions, syllabus_code=syllabus_code)

    return written_meta


def _write_cross_reference_index(
    subject_dir: Path,
    folders: Dict[str, Path],
    questions: List[Question],
    syllabus_code: str = "",
) -> None:
    """Write master cross-reference index mapping questions to all topics and their single folder."""
    index = {"questions": []}

    for q in questions:
        if q.is_duplicate or not q.images:
            continue

        base = f"{q.paper_code}_{canonical_season(q.session_label or 'Unknown')}_{q.year}_Q{q.question_number}"
        if base in folders:
            topic_list = compute_topic_field(q)
            winning_folder = folders[base]

            index["questions"].append({
                "question_id": q.qid,
                "question_label": base,
                "topics": topic_list,
                "winning_major_topic": winning_folder.parent.name,
                "folder_path": str(winning_folder.relative_to(subject_dir)),
            })

    idx_path = subject_dir / "topic_cross_reference.json"
    idx_path.parent.mkdir(parents=True, exist_ok=True)
    idx_path.write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"[organize] Wrote master cross-reference index: {idx_path}")
