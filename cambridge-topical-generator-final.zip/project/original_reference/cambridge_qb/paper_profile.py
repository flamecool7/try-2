"""
paper_profile.py
=================
Per-paper-type profiles for Cambridge exam papers.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class PaperProfile:
    paper_no: int
    short_label: str
    long_label: str
    marker_style: str
    preserve_answer_space: bool
    preserve_graph_paper: bool
    never_trim_horizontally: bool
    ms_parser: str
    expected_questions_per_paper: tuple


PROFILES: Dict[int, PaperProfile] = {
    1: PaperProfile(
        paper_no=1, short_label="MCQ",
        long_label="Multiple Choice (Paper 1)",
        marker_style="inline",
        preserve_answer_space=False,
        preserve_graph_paper=False,
        never_trim_horizontally=False,
        ms_parser="mcq_letter_grid",
        expected_questions_per_paper=(30, 40),
    ),
    2: PaperProfile(
        paper_no=2, short_label="AS Structured",
        long_label="AS Level Structured Questions (Paper 2)",
        marker_style="both",
        preserve_answer_space=True,
        preserve_graph_paper=False,
        never_trim_horizontally=False,
        ms_parser="structured_prose_table",
        expected_questions_per_paper=(3, 7),
    ),
    3: PaperProfile(
        paper_no=3, short_label="Practical Skills",
        long_label="Advanced Practical Skills (Paper 3)",
        marker_style="standalone",
        preserve_answer_space=True,
        preserve_graph_paper=True,
        never_trim_horizontally=True,
        ms_parser="structured_prose_table",
        expected_questions_per_paper=(2, 2),
    ),
    4: PaperProfile(
        paper_no=4, short_label="A2 Structured",
        long_label="A Level Structured Questions (Paper 4)",
        marker_style="both",
        preserve_answer_space=True,
        preserve_graph_paper=False,
        never_trim_horizontally=False,
        ms_parser="structured_prose_table",
        expected_questions_per_paper=(6, 10),
    ),
    5: PaperProfile(
        paper_no=5, short_label="Plan/Analysis",
        long_label="Planning, Analysis & Evaluation (Paper 5)",
        marker_style="standalone",
        preserve_answer_space=True,
        preserve_graph_paper=True,
        never_trim_horizontally=False,
        ms_parser="structured_prose_table",
        expected_questions_per_paper=(2, 2),
    ),
    6: PaperProfile(
        paper_no=6, short_label="Alt-to-Practical",
        long_label="Alternative to Practical (Paper 6)",
        marker_style="standalone",
        preserve_answer_space=True,
        preserve_graph_paper=False,
        never_trim_horizontally=True,
        ms_parser="structured_prose_table",
        expected_questions_per_paper=(3, 5),
    ),
}


def profile_for_variant(variant_code: str) -> PaperProfile:
    try:
        n = int(str(variant_code)[0])
    except (TypeError, ValueError):
        n = 2
    return PROFILES.get(n, PROFILES[2])


def label_for_variant(variant_code: str) -> str:
    p = profile_for_variant(variant_code)
    return f"{p.short_label} (P{p.paper_no})"
