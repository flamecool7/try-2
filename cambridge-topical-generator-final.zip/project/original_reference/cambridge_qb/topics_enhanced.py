"""
topics_enhanced.py
==================
Advanced multi-topic classification system with semantic understanding,
subpart-level concept attribution, and cross-topic detection for Cambridge exams.

Key features:
  1. Multi-Topic Assignment: Automatically identifies all relevant topics tested in a question.
  2. Subpart-Level Scoring: Analyzes individual subparts (a), (b), (c), (i), (ii) to detect multi-topic exams.
  3. Semantic & Pattern Boost: Utilizes domain concepts and chemical formulas from chemical_concepts.py.
  4. Cross-Topic Detection: Identifies hybrid questions (e.g., redox titrations, buffer equilibria, energetics + equilibrium).
  5. Calibrated Confidence Scoring: Generates normalized confidence values for all primary and secondary topics.
  6. Learning & Corrections: Integrates with CorrectionTracker for continuous improvement.
"""

from __future__ import annotations

import json
import math
import re
import unicodedata
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .chemical_concepts import (
    CROSS_TOPIC_PATTERNS,
    TOPIC_RELATIONSHIPS,
    QuestionAnalysis,
    analyze_question,
    detect_chemical_patterns,
    detect_cross_topic_patterns,
    split_question_subparts,
)
from .correction_tracker import Correction, CorrectionTracker
from .question_split import Question

# =============================================================================
# Scoring Constants & Thresholds
# =============================================================================
WEIGHT_PRIMARY = 12.0
WEIGHT_SECONDARY = 5.0
WEIGHT_TERTIARY = 1.0
MIN_SCORE_THRESHOLD = 3.0

# Multi-topic qualification thresholds
PRIMARY_MIN_SCORE = 7.0           # Minimum score to assign a primary topic
SECONDARY_MIN_SCORE = 4.5         # Minimum absolute score for secondary topic
SECONDARY_RATIO_THRESHOLD = 0.28   # Secondary score must be at least 28% of primary score
SECONDARY_ABS_DIFF = 16.0         # OR within 16 points of primary

# Boosts
SEMANTIC_BOOST = 2.5              # Boost for domain pattern match
CROSS_TOPIC_BOOST = 5.0           # Boost for detected cross-topic pairs
SUBPART_TOP_BOOST = 4.0           # Boost when topic is #1 in a subpart

# Confidence & review thresholds
HIGH_CONFIDENCE = 0.85
MEDIUM_CONFIDENCE = 0.65
LOW_CONFIDENCE = 0.50
CLOSE_CONFLICT_MARGIN = 3.0

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "into", "their",
    "are", "was", "were", "been", "being", "have", "has", "had", "will",
    "would", "should", "can", "could", "may", "might", "must", "shall",
    "using", "used", "which", "what", "where", "when", "there", "then",
}


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class BoostRule:
    all_terms: List[str] = field(default_factory=list)
    any_terms: List[str] = field(default_factory=list)
    min_any: int = 1
    score: float = 8.0
    label: str = ""


@dataclass
class Topic:
    name: str
    section: str = ""
    level: str = ""
    allowed_papers: List[int] = field(default_factory=list)
    require_anchor: bool = False
    min_score: float = 8.0
    primary: List[str] = field(default_factory=list)
    secondary: List[str] = field(default_factory=list)
    tertiary: List[str] = field(default_factory=list)
    exclude_if: List[str] = field(default_factory=list)
    boost_if: List[BoostRule] = field(default_factory=list)
    conflicts_with: List[str] = field(default_factory=list)

    @property
    def all_keywords(self) -> List[Tuple[str, float, str]]:
        out = []
        for kw in self.primary:
            out.append((kw, WEIGHT_PRIMARY, "primary"))
        for kw in self.secondary:
            out.append((kw, WEIGHT_SECONDARY, "secondary"))
        for kw in self.tertiary:
            out.append((kw, WEIGHT_TERTIARY, "tertiary"))
        return out


@dataclass
class TopicEvidence:
    topic: Topic
    raw_score: float = 0.0
    adjusted_score: float = 0.0
    primary_hits: int = 0
    secondary_hits: int = 0
    tertiary_hits: int = 0
    diagnostic_secondary_hits: int = 0
    boost_hits: int = 0
    exclusion_hits: int = 0
    semantic_boost: float = 0.0
    cross_topic_boost: float = 0.0
    subpart_boost: float = 0.0
    dominance: float = 1.0
    matched_terms: List[str] = field(default_factory=list)
    positions: List[int] = field(default_factory=list)
    subpart_matches: List[str] = field(default_factory=list)

    @property
    def total_score(self) -> float:
        return (self.adjusted_score + self.semantic_boost +
                self.cross_topic_boost + self.subpart_boost)

    @property
    def has_anchor(self) -> bool:
        return bool(
            self.primary_hits > 0
            or self.diagnostic_secondary_hits > 0
            or self.boost_hits > 0
            or self.semantic_boost > 0
        )


@dataclass
class TopicAssignment:
    topic_name: str
    confidence: float
    is_primary: bool
    evidence_score: float
    matched_terms: List[str] = field(default_factory=list)
    subparts_tested: List[str] = field(default_factory=list)


@dataclass
class MultiTopicResult:
    primary_topic: str
    secondary_topics: List[str] = field(default_factory=list)
    all_topics: List[str] = field(default_factory=list)
    confidence_scores: Dict[str, float] = field(default_factory=dict)
    subpart_topics: Dict[str, str] = field(default_factory=dict)
    topic_assignments: List[TopicAssignment] = field(default_factory=list)
    needs_review: bool = False
    review_reasons: List[str] = field(default_factory=list)
    semantic_analysis: Optional[dict] = None


# =============================================================================
# Topic Loading & Text Normalization
# =============================================================================

def _clean_term(term: str) -> str:
    t = term.lower().strip()
    t = re.sub(r"[\u2010\u2011\u2012\u2013\u2014\u2015\-]+", " ", t)
    t = re.sub(r"[^\w\s\+\-\/\.]", " ", t)
    return " ".join(t.split())


def _normalise(text: str) -> str:
    t = unicodedata.normalize("NFKD", text or "")
    t = t.lower()
    t = re.sub(r"[\u2010\u2011\u2012\u2013\u2014\u2015\-]+", " ", t)
    t = re.sub(r"[^\w\s\+\-\/\.]", " ", t)
    return " ".join(t.split())


@lru_cache(maxsize=1024)
def _term_pattern(term: str) -> re.Pattern:
    cleaned = _clean_term(term)
    tokens = [re.escape(tok) for tok in cleaned.split() if tok]
    if not tokens:
        return re.compile(r"(?!x)x")
    body = r"\s+".join(tokens)
    return re.compile(r"(?<!\w)" + body + r"(?!\w)", re.IGNORECASE)


def _find_term(text: str, term: str) -> List[Tuple[int, int]]:
    return [m.span() for m in _term_pattern(term).finditer(text)]


def _term_token_count(term: str) -> int:
    return len([tok for tok in _clean_term(term).split() if tok not in STOPWORDS])


def load_topics(path: str | Path | None = None, syllabus_pdf: str | Path | None = None) -> List[Topic]:
    """Load topic taxonomy from JSON or extract from syllabus."""
    if path is None:
        return []
    p = Path(path)
    if not p.exists():
        return []

    data = json.loads(p.read_text(encoding="utf-8"))
    topics: List[Topic] = []

    def _parse_entry(name: str, raw: dict) -> Topic:
        boost_rules = []
        for br in raw.get("boost_if", []):
            boost_rules.append(BoostRule(
                all_terms=[_clean_term(x) for x in br.get("all", [])],
                any_terms=[_clean_term(x) for x in br.get("any", [])],
                min_any=int(br.get("min_any", 1) or 1),
                score=float(br.get("score", 8.0)),
                label=str(br.get("label", "")),
            ))

        return Topic(
            name=name,
            section=str(raw.get("section", "")),
            level=str(raw.get("level", "")),
            allowed_papers=[int(x) for x in raw.get("allowed_papers", []) if str(x).isdigit()],
            require_anchor=bool(raw.get("require_anchor", False)),
            min_score=float(raw.get("min_score", 8.0)),
            primary=[_clean_term(x) for x in raw.get("primary", [])],
            secondary=[_clean_term(x) for x in raw.get("secondary", [])],
            tertiary=[_clean_term(x) for x in raw.get("tertiary", [])],
            exclude_if=[_clean_term(x) for x in raw.get("exclude_if", [])],
            boost_if=boost_rules,
            conflicts_with=[str(x) for x in raw.get("conflicts_with", [])],
        )

    if isinstance(data, dict):
        for name, raw in data.items():
            if isinstance(raw, dict):
                topics.append(_parse_entry(name, raw))
    elif isinstance(data, list):
        for raw in data:
            if isinstance(raw, dict) and "name" in raw:
                topics.append(_parse_entry(raw["name"], raw))

    return topics


# =============================================================================
# Scoring & Multi-Topic Classification Engine
# =============================================================================

def paper_number_from_code(paper_code: str) -> int:
    code = str(paper_code or "").lstrip("0")
    if not code or not code[0].isdigit():
        return 0
    return int(code[0])


def _topic_allowed(topic: Topic, paper_code: str) -> bool:
    paper = paper_number_from_code(paper_code)
    if paper > 0 and topic.allowed_papers:
        return paper in topic.allowed_papers
    return True


def _score_topic(
    topic: Topic,
    text: str,
    semantic_boost_topics: Optional[Dict[str, float]] = None,
) -> TopicEvidence:
    """Score a topic against normalized question text."""
    evidence = TopicEvidence(topic=topic)
    consumed: List[Tuple[int, int]] = []
    tertiary_points = 0.0
    semantic_boost_topics = semantic_boost_topics or {}

    for term, weight, tier in topic.all_keywords:
        usable = []
        for span in _find_term(text, term):
            start, end = span
            if not any(start < old_end and end > old_start for old_start, old_end in consumed):
                usable.append(span)
        if not usable:
            continue

        multipliers = (1.0, 0.40, 0.20)
        points = 0.0
        for index, span in enumerate(usable[:3]):
            words = _term_token_count(term)
            spec_mult = 1.0 + min(0.35, max(0, words - 1) * 0.10) if tier != "tertiary" else 1.0
            points += weight * multipliers[index] * spec_mult
            consumed.append(span)
            evidence.positions.append(span[0])
        evidence.matched_terms.append(term)

        if tier == "primary":
            evidence.primary_hits += 1
            evidence.raw_score += points
        elif tier == "secondary":
            evidence.secondary_hits += 1
            evidence.raw_score += points
            if _term_token_count(term) >= 2:
                evidence.diagnostic_secondary_hits += 1
                evidence.raw_score += 3.0
        else:
            evidence.tertiary_hits += 1
            tertiary_points += points

    if evidence.primary_hits or evidence.secondary_hits >= 2:
        evidence.raw_score += min(5.0, tertiary_points)
    else:
        evidence.raw_score += min(2.0, tertiary_points)

    # Boost rules
    for rule in topic.boost_if:
        all_ok = all(_term_pattern(t).search(text) is not None for t in rule.all_terms)
        any_count = sum(1 for t in rule.any_terms if _term_pattern(t).search(text) is not None)
        any_ok = (not rule.any_terms) or any_count >= rule.min_any
        if all_ok and any_ok:
            evidence.raw_score += rule.score
            evidence.boost_hits += 1

    # Exclusion rules
    evidence.exclusion_hits = sum(
        1 for term in topic.exclude_if if _term_pattern(term).search(text) is not None
    )
    score = evidence.raw_score
    if evidence.exclusion_hits:
        if evidence.primary_hits == 0 and evidence.secondary_hits <= 1:
            score *= max(0.08, 0.40 ** evidence.exclusion_hits)
        else:
            score *= max(0.45, 1.0 - 0.10 * evidence.exclusion_hits)

    # Semantic concept boost
    if topic.name in semantic_boost_topics:
        evidence.semantic_boost = semantic_boost_topics[topic.name] * SEMANTIC_BOOST

    # Dominance factor
    if text and evidence.positions:
        n_bins = max(1, min(4, int(math.ceil(len(text) / 450.0))))
        bins = {min(n_bins - 1, int((pos / max(1, len(text))) * n_bins)) for pos in evidence.positions}
        coverage = len(bins) / n_bins
        evidence.dominance = max(0.85, min(1.25, 0.88 + 0.24 * coverage))
    else:
        evidence.dominance = 0.90

    evidence.adjusted_score = score * evidence.dominance
    return evidence


# =============================================================================
# MultiTopicClassifier Class
# =============================================================================

class MultiTopicClassifier:
    """
    Advanced multi-topic classifier with subpart attribution and semantic understanding.
    """

    def __init__(self, topics: List[Topic], corrections_path: Optional[str] = None):
        self.topics = topics
        self.topic_map = {t.name: t for t in topics}
        self.corrections: Optional[CorrectionTracker] = None
        if corrections_path:
            self.corrections = CorrectionTracker(corrections_path)
            self.corrections.load()

    def assign_topics(self, questions: List[Question]) -> None:
        """Assign primary and secondary topics to all questions in-place."""
        for question in questions:
            result = self.classify_question(question)

            question.topic = result.all_topics
            question.needs_review = result.needs_review
            question.topic_scores = result.confidence_scores
            question.topic_confidence = result.confidence_scores.get(result.primary_topic, 0.0)
            question._multi_topic_result = result
            question._semantic_analysis = result.semantic_analysis
            if result.review_reasons:
                question.review_reasons.extend(result.review_reasons)

    def classify_question(self, question: Question) -> MultiTopicResult:
        """Classify a single question into primary and secondary topics."""
        # 1. Check correction tracker first
        if self.corrections and self.corrections.has_correction(question.qid):
            corr = self.corrections.get_correction(question.qid)
            return MultiTopicResult(
                primary_topic=corr.corrected_primary,
                secondary_topics=[t for t in corr.corrected_topics if t != corr.corrected_primary],
                all_topics=corr.corrected_topics,
                confidence_scores={t: 1.0 for t in corr.corrected_topics},
                needs_review=False,
                review_reasons=[],
                semantic_analysis=None,
            )

        norm_text = _normalise(question.text)
        if not norm_text:
            return MultiTopicResult(
                primary_topic="Uncategorized",
                secondary_topics=[],
                all_topics=["Uncategorized"],
                confidence_scores={},
                needs_review=True,
                review_reasons=["Empty question text"],
            )

        # 2. Semantic and subpart analysis
        analysis = analyze_question(question.text)
        cross_topics = detect_cross_topic_patterns(question.text)

        # Semantic boost map
        semantic_boosts: Dict[str, float] = {}
        for topic_name, matches in analysis.chemical_patterns.items():
            if topic_name in self.topic_map:
                semantic_boosts[topic_name] = len(matches) * 0.60

        # Cross-topic target set
        cross_topic_set: Set[str] = set()
        for ctopics in cross_topics:
            for t in ctopics:
                if t in self.topic_map:
                    cross_topic_set.add(t)

        # Subpart-level analysis
        subparts = split_question_subparts(question.text)
        subpart_topic_map: Dict[str, str] = {}
        subpart_boosts: Dict[str, float] = {}

        if len(subparts) > 1:
            for label, sub_text in subparts:
                norm_sub = _normalise(sub_text)
                if len(norm_sub) < 15:
                    continue
                sub_evidences = []
                for topic in self.topics:
                    if not _topic_allowed(topic, question.paper_code):
                        continue
                    ev = _score_topic(topic, norm_sub)
                    if ev.adjusted_score > 0:
                        sub_evidences.append(ev)
                if sub_evidences:
                    sub_evidences.sort(key=lambda ev: ev.adjusted_score, reverse=True)
                    top_sub = sub_evidences[0]
                    if top_sub.adjusted_score >= 3.5:
                        subpart_topic_map[label] = top_sub.topic.name
                        subpart_boosts[top_sub.topic.name] = (
                            subpart_boosts.get(top_sub.topic.name, 0.0) + SUBPART_TOP_BOOST
                        )

        # 3. Score all topics across whole question
        scored: List[TopicEvidence] = []
        for topic in self.topics:
            if not _topic_allowed(topic, question.paper_code):
                continue
            ev = _score_topic(topic, norm_text, semantic_boosts)

            if topic.name in cross_topic_set:
                ev.cross_topic_boost = CROSS_TOPIC_BOOST
            if topic.name in subpart_boosts:
                ev.subpart_boost = subpart_boosts[topic.name]

            if topic.require_anchor and not ev.has_anchor:
                ev.adjusted_score = 0.0

            scored.append(ev)

        scored.sort(key=lambda ev: ev.total_score, reverse=True)
        positive = [ev for ev in scored if ev.total_score > 0]

        if not positive:
            return MultiTopicResult(
                primary_topic="Uncategorized",
                secondary_topics=[],
                all_topics=["Uncategorized"],
                confidence_scores={},
                needs_review=True,
                review_reasons=["No topic matched keywords"],
                semantic_analysis={"command_words": analysis.command_words},
            )

        # 4. Primary Topic Assignment
        primary = positive[0]
        primary_total = primary.total_score

        if primary_total < PRIMARY_MIN_SCORE:
            return MultiTopicResult(
                primary_topic="Uncategorized",
                secondary_topics=[],
                all_topics=["Uncategorized"],
                confidence_scores={ev.topic.name: round(ev.total_score / 20.0, 3) for ev in positive},
                needs_review=True,
                review_reasons=[f"Primary score {primary_total:.1f} below threshold {PRIMARY_MIN_SCORE}"],
            )

        # 5. Secondary Topic Qualification
        secondaries: List[TopicEvidence] = []
        review_reasons: List[str] = []

        for ev in positive[1:]:
            total = ev.total_score
            ratio_ok = total >= primary_total * SECONDARY_RATIO_THRESHOLD
            abs_diff_ok = (primary_total - total) <= SECONDARY_ABS_DIFF
            threshold_ok = total >= SECONDARY_MIN_SCORE
            subpart_match = ev.topic.name in subpart_topic_map.values()
            cross_topic_match = ev.topic.name in cross_topic_set

            if (threshold_ok and (ratio_ok or abs_diff_ok)) or subpart_match or cross_topic_match:
                if ev.topic.name != primary.topic.name and ev.topic.name not in [s.topic.name for s in secondaries]:
                    secondaries.append(ev)

        # 6. Build confidence scores & assignments (strictly capped at top 4 topics with most points)
        secondaries.sort(key=lambda ev: ev.total_score, reverse=True)
        secondaries = secondaries[:3]  # Primary + top 3 secondaries = max 4 topics
        all_topics = [primary.topic.name] + [ev.topic.name for ev in secondaries]
        confidence_scores: Dict[str, float] = {}

        # Primary confidence calculation
        primary_margin = (primary_total - secondaries[0].total_score) if secondaries else primary_total
        p_conf = min(1.0, 0.70 + 0.30 * min(1.0, primary_margin / 10.0))
        if primary.primary_hits >= 2 or primary.diagnostic_secondary_hits >= 1:
            p_conf = min(1.0, p_conf + 0.10)
        confidence_scores[primary.topic.name] = round(p_conf, 3)

        topic_assignments = [TopicAssignment(
            topic_name=primary.topic.name,
            confidence=round(p_conf, 3),
            is_primary=True,
            evidence_score=round(primary_total, 2),
            matched_terms=primary.matched_terms[:6],
            subparts_tested=[k for k, v in subpart_topic_map.items() if v == primary.topic.name],
        )]

        for ev in secondaries:
            ratio = min(1.0, ev.total_score / primary_total)
            s_conf = round(p_conf * ratio, 3)
            confidence_scores[ev.topic.name] = s_conf
            topic_assignments.append(TopicAssignment(
                topic_name=ev.topic.name,
                confidence=s_conf,
                is_primary=False,
                evidence_score=round(ev.total_score, 2),
                matched_terms=ev.matched_terms[:5],
                subparts_tested=[k for k, v in subpart_topic_map.items() if v == ev.topic.name],
            ))

        needs_review = (p_conf < 0.60) or (len(review_reasons) > 0)

        return MultiTopicResult(
            primary_topic=primary.topic.name,
            secondary_topics=[ev.topic.name for ev in secondaries],
            all_topics=all_topics,
            confidence_scores=confidence_scores,
            subpart_topics=subpart_topic_map,
            topic_assignments=topic_assignments,
            needs_review=needs_review,
            review_reasons=review_reasons,
            semantic_analysis={
                "command_words": analysis.command_words,
                "chemical_patterns": analysis.chemical_patterns,
                "cross_topic_hints": cross_topics,
                "subpart_topics": subpart_topic_map,
                "complexity_score": round(analysis.complexity_score, 2),
            },
        )


# =============================================================================
# Helper function
# =============================================================================

def assign_topics(
    questions: List[Question],
    topics: List[Topic],
    corrections_path: Optional[str] = None,
) -> None:
    """Standard entry point for topic classification."""
    if not topics:
        for q in questions:
            q.topic = ["Uncategorized"]
            q.needs_review = True
            q.topic_confidence = 0.0
        return

    classifier = MultiTopicClassifier(topics, corrections_path)
    classifier.assign_topics(questions)
