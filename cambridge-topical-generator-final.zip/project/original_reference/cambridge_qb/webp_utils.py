"""
webp_utils.py
=============
Lossy .webp conversion, vertical image merging, imposition barcode scrubbing,
trailing answer-space trimming, and whitespace trimming.

From the reference implementation with all the working cropping logic.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import numpy as np
from PIL import Image


_WEBP_MAX_DIM = 16383


def save_webp(img: Image.Image, path: str | Path, quality: int = 88) -> List[Path]:
    """Save ``img`` as WebP, tiling vertically if it exceeds the WebP size limit."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    w, h = img.size
    stride = _WEBP_MAX_DIM - 16

    if w <= _WEBP_MAX_DIM and h <= _WEBP_MAX_DIM:
        img.save(str(path), format="WEBP", quality=quality, method=4)
        return [path]

    parts: List[Path] = []
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    idx = 1
    y = 0
    while y < h:
        y1 = min(h, y + stride)
        tile = img.crop((0, y, w, y1))
        if idx == 1:
            out = path
        else:
            out = parent / f"{stem}_part{idx}{suffix}"
        if tile.width > _WEBP_MAX_DIM or tile.height > _WEBP_MAX_DIM:
            out = out.with_suffix(".jpg")
            tile.save(str(out), format="JPEG", quality=max(70, quality),
                      optimize=True)
        else:
            tile.save(str(out), format="WEBP", quality=quality, method=4)
        parts.append(out)
        idx += 1
        y = y1
    return parts


# ---------------------------------------------------------------------------
# Imposition-barcode scrubber
# ---------------------------------------------------------------------------

def _scrub_imposition_marks(img: Image.Image, scan_full_page: bool = False,
                            page_seams: Optional[List[int]] = None,
                            ) -> Image.Image:
    """Remove printer-imposition registration barcodes (raster stripe bands)."""
    import numpy as _np
    arr = _np.array(img.convert("L")).copy()
    h, w = arr.shape

    LEFT_SAFE = 70
    DARK_T = 50
    MIN_BW = 150
    MAX_BW = int(w * 0.98)
    MIN_T_PER_100 = 18
    MIN_TRANS = 30
    MIN_FILL = 0.05
    MAX_FILL = 0.65
    MAX_BAND_H = 80
    MIN_BAND_H = 6
    ROW_GAP = 2
    PAINT_PAD = 3
    MAX_WHITE_GAP = 12

    def _row_candidate_bands(row: _np.ndarray):
        dark_mask = row < DARK_T
        runs = []
        i = 0
        n = len(row)
        while i < n:
            if dark_mask[i]:
                j = i
                while j < n and dark_mask[j]:
                    j += 1
                runs.append((i, j))
                i = j
            else:
                i += 1
        if len(runs) < 8:
            return []
        MERGE_GAP = MAX_WHITE_GAP
        merged = []
        cs, ce = runs[0]
        for s, e in runs[1:]:
            if s - ce <= MERGE_GAP:
                ce = e
            else:
                merged.append((cs, ce))
                cs, ce = s, e
        merged.append((cs, ce))
        out = []
        for s, e in merged:
            bw = e - s
            if bw < MIN_BW or bw > MAX_BW:
                continue
            if e < LEFT_SAFE + 20:
                continue
            sub = dark_mask[s:e]
            fill = float(sub.mean())
            if fill < MIN_FILL or fill > MAX_FILL:
                continue
            trans = int(_np.abs(_np.diff(sub.astype(_np.int8))).sum())
            t100 = trans / (bw / 100.0)
            if trans < MIN_TRANS or t100 < MIN_T_PER_100:
                continue
            out.append((max(int(s), LEFT_SAFE), int(e)))
        return out

    def _vertical_coherent_hits(y_start: int, y_end: int):
        hits_by_y: dict = {}
        for y in range(max(0, y_start), min(h, y_end)):
            bands = _row_candidate_bands(arr[y])
            if bands:
                hits_by_y[y] = bands
        if not hits_by_y:
            return []
        ys = sorted(hits_by_y.keys())
        visited = set()
        rects = []
        for i, y in enumerate(ys):
            if y in visited:
                continue
            cluster_ys = [y]
            cur_bands = list(hits_by_y[y])
            for ny in range(y + 1, min(y + MAX_BAND_H + 5, min(h, y_end))):
                if ny not in hits_by_y:
                    if ny - cluster_ys[-1] > ROW_GAP:
                        break
                    continue
                nb = hits_by_y[ny]
                overlap = False
                for (cx0, cx1) in cur_bands:
                    for (nx0, nx1) in nb:
                        if nx0 < cx1 - 20 and nx1 > cx0 + 20:
                            overlap = True
                            break
                    if overlap:
                        break
                if overlap or ny - cluster_ys[-1] <= ROW_GAP:
                    cluster_ys.append(ny)
                    cur_bands = nb
                else:
                    break
            cluster_h = cluster_ys[-1] - cluster_ys[0] + 1
            if cluster_h < MIN_BAND_H:
                continue
            bx0 = min(b[0] for yy in cluster_ys for b in hits_by_y[yy])
            bx1 = max(b[1] for yy in cluster_ys for b in hits_by_y[yy])
            for yy in cluster_ys:
                visited.add(yy)
            by0, by1 = cluster_ys[0], cluster_ys[-1] + 1
            sub = arr[by0:by1, bx0:bx1] < DARK_T
            cluster_h = by1 - by0
            col_tall_dark = 0
            mid_y = cluster_h // 2
            for x in range(sub.shape[1]):
                col = sub[:, x]
                if col.any():
                    max_run = 0; run = 0
                    for v in col:
                        if v:
                            run += 1
                            if run > max_run: max_run = run
                        else:
                            run = 0
                    if max_run >= cluster_h * 0.40:
                        col_tall_dark += 1
            mid_dark = arr[by0 + mid_y, bx0:bx1] < DARK_T
            mid_row_trans = int(np.abs(np.diff(mid_dark.astype(np.int8))).sum())
            density = col_tall_dark / max(1, (bx1 - bx0))
            EDGE_PROX = 200 if scan_full_page else 130
            touches_left_edge = bx0 < EDGE_PROX
            touches_right_edge = bx1 > w - EDGE_PROX
            is_dense_tall = (col_tall_dark >= 25 and density >= 0.10)
            is_super_stripey = (mid_row_trans >= 180 and cluster_h >= 6)
            if not (is_dense_tall or is_super_stripey):
                continue
            if not (touches_left_edge or touches_right_edge):
                continue
            if touches_left_edge and touches_right_edge and (bx1 - bx0) > 0.92 * w and cluster_h <= 5:
                continue
            rects.append((by0, by1, bx0, bx1))
        return rects

    def _scrub_region(y_start: int, y_end: int) -> int:
        rects = _vertical_coherent_hits(y_start, y_end)
        for (by0, by1, bx0, bx1) in rects:
            x0 = max(LEFT_SAFE, bx0 - PAINT_PAD)
            x1 = min(w, bx1 + PAINT_PAD)
            y0 = max(0, by0 - PAINT_PAD)
            y1 = min(h, by1 + PAINT_PAD)
            if y1 - y0 > MAX_BAND_H + 10:
                y1 = y0 + MAX_BAND_H + 10
            arr[y0:y1, x0:x1] = 255
            for yy in range(max(0, y0 - 4), min(h, y1 + 4)):
                seg = arr[yy, x0:x1]
                dark_seg = seg < 100
                if 0 < dark_seg.sum() < (x1 - x0) * 0.15:
                    arr[yy, x0:x1] = _np.where(dark_seg, 255, seg)
        return len(rects)

    if scan_full_page:
        SEAM_WINDOW = 80
        regions: List[Tuple[int, int]] = []
        regions.append((0, min(h, SEAM_WINDOW)))
        regions.append((max(0, h - SEAM_WINDOW), h))
        if page_seams:
            for sy in page_seams:
                y0 = max(0, sy - SEAM_WINDOW)
                y1 = min(h, sy + SEAM_WINDOW)
                regions.append((y0, y1))
        regions.sort()
        merged: List[Tuple[int, int]] = []
        for y0, y1 in regions:
            if merged and y0 <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], y1))
            else:
                merged.append((y0, y1))
        for y0, y1 in merged:
            _scrub_region(y0, y1)
    else:
        edge = int(h * 0.12)
        _scrub_region(0, edge)
        _scrub_region(h - edge, h)

    if not scan_full_page:
        EDGE_STRIP = 110
        def _in_edge(x: int) -> bool:
            return x < EDGE_STRIP or x >= w - EDGE_STRIP
        import collections as _collections
        dark_edge = arr < 180
        visited = _np.zeros_like(dark_edge, dtype=bool)
        seed_xs = (list(range(0, EDGE_STRIP))
                   + list(range(max(EDGE_STRIP, w - EDGE_STRIP), w)))
        for sx in seed_xs:
            if sx < 0 or sx >= w:
                continue
            for sy in range(h):
                if visited[sy, sx] or not dark_edge[sy, sx]:
                    continue
                q = _collections.deque()
                q.append((sy, sx))
                visited[sy, sx] = True
                blob: list = []
                touches_interior = False
                min_x = max_x = sx
                min_y = max_y = sy
                while q:
                    cy, cx = q.popleft()
                    blob.append((cy, cx))
                    if cx < min_x: min_x = cx
                    if cx > max_x: max_x = cx
                    if cy < min_y: min_y = cy
                    if cy > max_y: max_y = cy
                    if not _in_edge(cx):
                        touches_interior = True
                    for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        ny, nx = cy + dy, cx + dx
                        if (0 <= ny < h and 0 <= nx < w
                                and not visited[ny, nx]
                                and dark_edge[ny, nx]):
                            visited[ny, nx] = True
                            q.append((ny, nx))
                if touches_interior:
                    continue
                bh = max_y - min_y + 1
                bw = max_x - min_x + 1
                area = len(blob)
                in_left_qzone = (max_x < LEFT_SAFE)
                if in_left_qzone and bh > 40:
                    continue
                if not in_left_qzone and bh > 150 and area > 200:
                    continue
                if area < 2500 and bh < 200 and bw < 200:
                    for (cy, cx) in blob:
                        arr[cy, cx] = 255

    if scan_full_page:
        edge_trim = 18
        if h > 2 * edge_trim + 50 and w > 2 * edge_trim + 50:
            arr = arr[edge_trim:h - edge_trim, edge_trim:w - edge_trim]

    return Image.fromarray(arr, mode="L").convert("RGB")


# ---------------------------------------------------------------------------
# Trailing answer-space trimming
# ---------------------------------------------------------------------------

def _row_fill(arr: np.ndarray) -> np.ndarray:
    return (arr < 230).sum(axis=1) / arr.shape[1]


def _is_barcode_row(rf: np.ndarray, y: int, h: int) -> bool:
    return 0 <= y < h and float(rf[y]) > 0.60


def _is_dotted_rule_row(rf: np.ndarray, y: int, h: int) -> bool:
    return 0 <= y < h and 0.25 <= float(rf[y]) <= 0.60


def _bands_bottom_up(arr: np.ndarray):
    h, w = arr.shape
    dark = arr < 230
    rf = _row_fill(arr)
    y = h - 1
    while y >= 0 and float(rf[y]) < 0.003:
        y -= 1
    if y < 0:
        return
    while y >= 0:
        while y >= 0 and float(rf[y]) < 0.003:
            y -= 1
        if y < 0:
            break
        y1 = y + 1
        kinds: set = set()
        while y >= 0 and float(rf[y]) >= 0.003:
            if _is_barcode_row(rf, y, h):
                kinds.add("barcode")
            elif _is_dotted_rule_row(rf, y, h):
                kinds.add("dotted")
            else:
                kinds.add("text")
            y -= 1
        y0 = y + 1
        sub = dark[y0:y1]
        cols = sub.any(axis=0)
        if cols.any():
            cx0 = int(np.argmax(cols))
            cx1 = w - int(np.argmax(cols[::-1]))
            bw = int(cx1 - cx0)
        else:
            bw = 0
        yield y0, y1, y1 - y0, bw, float(sub.mean()), kinds


def _band_rightmost_text_is_total_marker(arr: np.ndarray, y0: int, y1: int,
                                          w: int) -> bool:
    import numpy as _np
    band = arr[y0:y1, :]
    dark = band < 80
    if not dark.any():
        return False
    if (y1 - y0) > 50:
        return False
    all_cols = _np.where(dark.any(axis=0))[0]
    if len(all_cols) == 0:
        return False
    leftmost = int(all_cols[0])
    rightmost = int(all_cols[-1])
    content_width = rightmost - leftmost + 1

    if leftmost >= int(w * 0.60) and int(w * 0.08) <= content_width <= int(w * 0.30):
        dark_pixels = int(dark.sum())
        if dark_pixels >= (y1 - y0) * content_width * 0.10:
            return True

    band_h = y1 - y0
    if content_width > int(w * 0.70) and 12 <= band_h <= 50:
        right_start = int(w * 0.75)
        right_region = dark[:, right_start:]
        max_tall_run = 0
        for c in range(right_region.shape[1]):
            col = right_region[:, c]
            run = 0
            for v in col:
                if v:
                    run += 1
                    if run > max_tall_run:
                        max_tall_run = run
                else:
                    run = 0
        if max_tall_run >= max(10, band_h * 0.40):
            return True

    return False


def _find_trailing_answer_cut(arr: np.ndarray, floor_frac: float = 0.15):
    h, w = arr.shape
    bands = list(_bands_bottom_up(arr))

    def is_text_kind(kinds):
        return "text" in kinds
    def is_dotted_kind(kinds):
        return "dotted" in kinds

    content_cut_y = h
    total_band = None
    found_total = False
    for idx, (y0, y1, bh, bw, mean_f, kinds) in enumerate(bands):
        is_ws = (bw == 0)
        is_barcode = "barcode" in kinds
        is_dotted = "dotted" in kinds
        is_text = "text" in kinds
        is_total = _band_rightmost_text_is_total_marker(arr, y0, y1, w)
        is_mark = (bh <= 30 and bw < int(w * 0.22) and not is_total)

        if is_total and not found_total:
            total_band = (y0, y1)
            found_total = True
            content_cut_y = y0
            continue
        if not found_total:
            if is_ws or is_barcode or is_mark:
                content_cut_y = y0
                continue
            content_cut_y = y1
            break
        if is_ws or is_barcode or is_mark:
            content_cut_y = y0
            continue
        if is_dotted:
            content_cut_y = y0
            continue
        if bh < 15:
            content_cut_y = y0
            continue
        if is_text and not is_dotted and bh > 15 and bw > int(w * 0.25):
            content_cut_y = y1
            break
        content_cut_y = y1
        break

    content_cut_y = max(content_cut_y, int(h * floor_frac))
    content_cut_y = min(content_cut_y, h)
    if h - content_cut_y < 60:
        return None
    return content_cut_y, total_band


def _trim_working_space(img: Image.Image) -> Image.Image:
    """Trim trailing answer-space from the BOTTOM of a fully-merged question image."""
    import numpy as _np
    arr = _np.array(img.convert("L"))
    h, w = arr.shape
    if h < 200:
        return img
    result = _find_trailing_answer_cut(arr, floor_frac=0.20)
    if result is None:
        return img
    cut, total_band = result
    cut = max(int(h * 0.20), cut)
    cut = min(h - 80, cut)
    if h - cut < 60:
        return img

    cropped = img.crop((0, 0, img.width, cut))

    if total_band is None:
        return cropped

    t_y0, t_y1 = total_band
    t_band_h = t_y1 - t_y0
    gap = t_y0 - cut
    if gap < 0 or gap < 200:
        return cropped

    margin = 40
    new_h = cut + margin + t_band_h + 20
    canvas = Image.new("RGB", (img.width, new_h), "white")
    canvas.paste(cropped, (0, 0))
    band_img = img.crop((0, max(0, t_y0 - 2), img.width, min(h, t_y1 + 2)))
    canvas.paste(band_img, (0, cut + margin))
    return canvas


def trim_whitespace(img: Image.Image, dark_thresh: int = 252,
                    pad: int = 14,
                    trim_tail_answer_space: bool = True,
                    vertical_only: bool = False,
                    h_only_white_border: bool = False) -> Image.Image:
    """Crop excess white borders and vertical separator strips."""
    if img is None:
        return img
    from .pdf_io import trim_margin_warnings
    if not vertical_only and not h_only_white_border:
        img = trim_margin_warnings(img)
    arr = np.array(img.convert("L"))
    content = arr < dark_thresh
    if not content.any():
        return img
    rows = np.any(content, axis=1)
    r0, r1 = int(np.argmax(rows)), len(rows) - int(np.argmax(rows[::-1]))
    r0 = max(0, r0 - pad)
    r1 = min(img.height, r1 + pad)
    if vertical_only:
        c0, c1 = 0, img.width
    else:
        cols = np.any(content, axis=0)
        c0, c1 = int(np.argmax(cols)), len(cols) - int(np.argmax(cols[::-1]))
        c0 = max(0, c0 - pad)
        c1 = min(img.width, c1 + pad)
    if r1 - r0 < 17 or c1 - c0 < 17:
        return img
    cropped = img.crop((c0, r0, c1, r1))
    if trim_tail_answer_space:
        return _trim_working_space(cropped)
    return cropped


def merge_vertical(images: List[Image.Image],
                   trim_tail: bool = True) -> Image.Image:
    """Stack images vertically on a white canvas with barcode scrubbing."""
    real = [im for im in images if im.height >= 17]
    if not real:
        real = images
    if len(real) == 1:
        return trim_whitespace(real[0], h_only_white_border=True,
                               trim_tail_answer_space=trim_tail)
    w = max(im.width for im in real)
    h = sum(im.height for im in real)
    canvas = Image.new("RGB", (w, h), "white")
    y = 0
    seams: List[int] = []
    for im in real:
        canvas.paste(im, (0, y))
        y += im.height
        seams.append(y)
    canvas = _scrub_imposition_marks(canvas, scan_full_page=True,
                                     page_seams=seams)
    return trim_whitespace(canvas, h_only_white_border=True,
                           trim_tail_answer_space=trim_tail)
