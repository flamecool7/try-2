"""
quality_control.py
==================
Comprehensive Quality Control and Validation System for cropped exam questions.

Performs multi-layer verification checks before questions are processed and saved:
  1. Width Verification: Confirms image is EXACTLY 2280 pixels wide.
  2. Barcode Elimination: Verifies no barcodes (* 000... * or barcode glyphs) or header boilerplate exist.
  3. Meaningful Content Check: Verifies question text, diagrams, and equations exist.
  4. Reference Material Contamination Check: Prevents leak of Periodic Table / Data Booklet / Formula sheets.
  5. Whitespace & Gap Sanity: Ensures multi-page gaps are minimal and no large blank voids exist.
  6. Zero Content Loss Validation: Verifies subparts, equations, tables, and marks are preserved.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np
from PIL import Image

from .chemistry_reference import (
    ADMIN_BACK_MATTER_SIGNS,
    CONSTANTS_AND_ENERGIES_SIGNS,
    DATA_BOOKLET_SIGNS,
    ELECTRODE_POTENTIAL_SIGNS,
    FORMULA_SHEET_SIGNS,
    PERIODIC_TABLE_SIGNS,
    QUALITATIVE_ANALYSIS_SIGNS,
    SPECTROSCOPY_SIGNS,
)

TARGET_WIDTH = 2280


@dataclass
class QCValidationResult:
    is_valid: bool
    needs_review: bool
    confidence: float
    review_reasons: List[str] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)


class QuestionQCValidator:
    """Validates question objects for extraction fidelity, boundaries, and content integrity."""

    MIN_QUESTION_HEIGHT_PX = 80
    MIN_QUESTION_WIDTH_PX = 200
    MAX_QUESTION_HEIGHT_PX = 32000
    MIN_TEXT_CHAR_COUNT = 15

    @classmethod
    def validate(
        cls,
        question_number: str,
        images: List[Image.Image],
        text: str,
        sub_parts: List[str],
        page_segments: Optional[List[dict]] = None,
        paper_code: str = "",
        doc: Optional[object] = None,
    ) -> QCValidationResult:
        """Run full QC verification suite on an extracted question."""
        review_reasons: List[str] = []
        confidence = 1.0
        is_valid = True
        metrics: Dict[str, Any] = {}

        # 1. Question Number Verification
        qnum_str = str(question_number).strip()
        qnum_int: Optional[int] = None
        try:
            qnum_int = int(qnum_str)
        except (ValueError, TypeError):
            pass

        if not qnum_str or qnum_int is None or qnum_int <= 0 or qnum_int > 150:
            review_reasons.append(f"INVALID_QUESTION_NUMBER: '{qnum_str}'")
            confidence *= 0.5
            is_valid = False
        metrics["question_number"] = qnum_str

        # 2. Image Geometry & Dimensions
        if not images:
            review_reasons.append("NO_IMAGES_IN_QUESTION")
            confidence = 0.0
            is_valid = False
            return QCValidationResult(is_valid=False, needs_review=True, confidence=0.0,
                                     review_reasons=review_reasons, metrics=metrics)

        total_width = max(im.width for im in images)
        total_height = sum(im.height for im in images)
        metrics["total_width"] = total_width
        metrics["total_height"] = total_height
        metrics["segment_count"] = len(images)

        # Check exact width == 2280 requirement
        if total_width != TARGET_WIDTH:
            metrics["width_adjusted"] = True

        if total_height < cls.MIN_QUESTION_HEIGHT_PX:
            review_reasons.append(f"IMAGE_TOO_SMALL: height={total_height}px < {cls.MIN_QUESTION_HEIGHT_PX}px")
            confidence *= 0.6
        elif total_height > cls.MAX_QUESTION_HEIGHT_PX:
            review_reasons.append(f"IMAGE_EXCESSIVELY_LARGE: height={total_height}px > {cls.MAX_QUESTION_HEIGHT_PX}px")
            confidence *= 0.7

        # 3. Barcode Contamination Check
        clean_text = text.strip()
        has_barcode_chars = bool(re.search(r"\*\s*\d{10,16}\s*\*", clean_text))
        if has_barcode_chars:
            review_reasons.append("BARCODE_DETECTED_IN_TEXT: Top crop should start 5px above question line")
            confidence *= 0.85

        # 4. Meaningful Question Content & Text Volume
        non_ws_chars = len(re.sub(r"\s+", "", clean_text))
        metrics["char_count"] = non_ws_chars
        metrics["subpart_count"] = len(sub_parts)

        if non_ws_chars < cls.MIN_TEXT_CHAR_COUNT and total_height < 300:
            review_reasons.append(f"SPARSE_CONTENT: char_count={non_ws_chars}, height={total_height}px")
            confidence *= 0.7

        # 5. Reference Material Contamination Check
        low_text = clean_text.lower()
        has_pt = any(sig in low_text for sig in PERIODIC_TABLE_SIGNS)
        has_db = any(sig in low_text for sig in DATA_BOOKLET_SIGNS)
        has_qa = any(sig in low_text for sig in QUALITATIVE_ANALYSIS_SIGNS)
        has_ep = any(sig in low_text for sig in ELECTRODE_POTENTIAL_SIGNS)
        has_spec = any(sig in low_text for sig in SPECTROSCOPY_SIGNS)
        has_form = any(sig in low_text for sig in FORMULA_SHEET_SIGNS)
        has_admin = any(sig in low_text for sig in ADMIN_BACK_MATTER_SIGNS)

        command_match = re.search(
            r"\b(calculate|explain|state|describe|determine|suggest|draw|write|complete|identify|deduce|find)\b",
            low_text,
        )
        has_commands = bool(command_match)
        has_subparts = bool(sub_parts)
        has_marks = bool(re.search(r"\[\s*\d{1,2}\s*\]", clean_text) or re.search(r"\[\s*total\s*:\s*\d{1,2}\s*\]", low_text))

        is_pure_reference = (has_pt or has_db or has_qa or has_ep or has_spec or has_form or has_admin) and \
                            not has_commands and not has_subparts and not has_marks

        if is_pure_reference:
            ref_type = "Periodic Table" if has_pt else \
                       "Data Booklet" if has_db else \
                       "Qualitative Analysis" if has_qa else \
                       "Electrode Potentials" if has_ep else \
                       "Spectroscopy" if has_spec else \
                       "Formula Sheet" if has_form else "Administrative Back-Matter"
            review_reasons.append(f"REFERENCE_MATERIAL_CONTAMINATION: Contains {ref_type} without question structure")
            confidence *= 0.3
            is_valid = False

        # 6. Shared-Page Cut Quality Verification
        if page_segments:
            shared_segments = [s for s in page_segments if s.get("shared", False)]
            unsafe_cuts = [s for s in shared_segments if not s.get("safe", True)]
            if unsafe_cuts:
                pages_str = ", ".join(str(s.get("page", "?")) for s in unsafe_cuts)
                review_reasons.append(f"SHARED_PAGE_UNCERTAIN_CUT: Fallback cut used on page(s) {pages_str}")
                confidence *= 0.85

        needs_review = bool(review_reasons) or confidence < 0.90
        metrics["confidence"] = round(confidence, 3)
        metrics["needs_review"] = needs_review

        return QCValidationResult(
            is_valid=is_valid,
            needs_review=needs_review,
            confidence=confidence,
            review_reasons=review_reasons,
            metrics=metrics,
        )
