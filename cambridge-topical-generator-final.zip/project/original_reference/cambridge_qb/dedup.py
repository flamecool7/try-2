"""
dedup.py
========
Detect duplicate questions across paper variants using similarity-based
text comparison.

Cambridge frequently re-uses the *same* question across variants (e.g. Paper 11
vs Paper 13).  We treat two questions as duplicates when:

  * their normalised question text is **similar** above a configurable
    threshold (default 96%), OR
  * their perceptual image hashes are within ``hamming`` bits (catches
    image-only questions that have no extractable text).

The similarity approach is critical because text extraction from PDFs can
produce minor differences across variants — variant codes in running headers,
page numbers, OCR artefacts, whitespace inconsistencies, etc.  A single
missing character or extra space should not prevent two otherwise identical
questions from being recognised as duplicates.
"""

from __future__ import annotations

import re
from difflib import SequenceMatcher
from typing import Dict, List, Optional, Tuple

import imagehash
from PIL import Image

from .question_split import Question

# ---------------------------------------------------------------------------
# Text normalisation
# ---------------------------------------------------------------------------
_WS = re.compile(r"\s+")
_PUNCT = re.compile(r"[^\w\d]")

# ---------------------------------------------------------------------------
# Cambridge PDF header/footer lines that differ between variants.
# These are stripped before similarity comparison so the same question across
# variants produces a high similarity score.
# ---------------------------------------------------------------------------
_HEADER_FOOTER_PATTERNS = [
    # Variant codes: 9702/41/O/N/25, 9702/42, 9702/41/O/N, etc.
    # Also catches lines like "PHYSICS 9702/42 Paper 4"
    re.compile(r"\b\d{4}\s*/\s*\d{2,3}(?:\s*/\s*[A-Za-z]+)*\b"),
    # Page numbers: Page 3 of 12, page 3, etc.
    re.compile(r"\bpage\s+\d+\s*(of\s+\d+)?\b", re.IGNORECASE),
    # Bare page number on its own line
    re.compile(r"^\s*\d{1,3}\s*$"),
    # Bare subject code on its own line: "9702"
    re.compile(r"^\s*\d{4}\s*$"),
    # [Turn over]
    re.compile(r"\[turn\s+over\]", re.IGNORECASE),
    # Blank page
    re.compile(r"\bblank\s+page\b", re.IGNORECASE),
    # University / exam board
    re.compile(r"\buniversity\s+of\s+cambridge\b", re.IGNORECASE),
    re.compile(r"\bcambridge\s+international\b", re.IGNORECASE),
    re.compile(r"\binternational\s+examinations\b", re.IGNORECASE),
    # Certificate names
    re.compile(r"\bgeneral\s+certificate\s+of\s+education\b", re.IGNORECASE),
    re.compile(r"\badvanced\s+(subsidiary\s+)?level\b", re.IGNORECASE),
    # Subject name on its own line
    re.compile(r"^\s*physics\s*$", re.IGNORECASE),
    re.compile(r"^\s*chemistry\s*$", re.IGNORECASE),
    re.compile(r"^\s*biology\s*$", re.IGNORECASE),
    re.compile(r"^\s*mathematics\s*$", re.IGNORECASE),
    re.compile(r"^\s*economics\s*$", re.IGNORECASE),
    re.compile(r"^\s*computer\s+science\s*$", re.IGNORECASE),
    # Paper title lines
    re.compile(r"\bpaper\s+\d+\b", re.IGNORECASE),
    # Session / date lines
    re.compile(r"\b(january|february|march|april|may|june|july|august|september|october|november|december)"
               r"\s*/?\s*(january|february|march|april|may|june|july|august|september|october|november|december)?"
               r"\s*\d{4}\b", re.IGNORECASE),
    # Duration lines: 2 hours, 1 hour 15 minutes, etc.
    re.compile(r"\b\d+\s+hour(s)?\s*(\d+\s+minute(s)?)?\b", re.IGNORECASE),
    # Copyright / UCLES
    re.compile(r"\bucles\b", re.IGNORECASE),
    re.compile(r"©\s*\d{4}"),
    # DO NOT WRITE IN THIS MARGIN
    re.compile(r"\bdo\s+not\s+write\s+(in|on)\s+this\s+margin\b", re.IGNORECASE),
    # Permission / copyright
    re.compile(r"\bpermission\s+to\s+reproduce\b", re.IGNORECASE),
    re.compile(r"\bcopyright\s+acknowledgements?\b", re.IGNORECASE),
    re.compile(r"\bpublished\b", re.IGNORECASE),
    # "This document consists of X printed pages"
    re.compile(r"\bthis\s+document\s+consists\b", re.IGNORECASE),
    # Instruction lines
    re.compile(r"\bread\s+these\s+instructions\b", re.IGNORECASE),
    re.compile(r"\banswer\s+all\s+the\s+questions\b", re.IGNORECASE),
    re.compile(r"\belectronic\s+calculators\b", re.IGNORECASE),
    re.compile(r"\bat\s+the\s+end\s+of\s+the\s+examination\b", re.IGNORECASE),
    re.compile(r"\bthe\s+number\s+of\s+marks\b", re.IGNORECASE),
    re.compile(r"\bcandidates\s+answer\b", re.IGNORECASE),
    re.compile(r"\bwrite\s+your\s+centre\b", re.IGNORECASE),
    re.compile(r"\bwrite\s+your\s+center\b", re.IGNORECASE),
    # Data / formulae references
    re.compile(r"\bdata\s+book(let)?\b", re.IGNORECASE),
    re.compile(r"\blist\s+of\s+formulae?\b", re.IGNORECASE),
    re.compile(r"\bimportant\s+values\b", re.IGNORECASE),
    # "Additional materials" lines
    re.compile(r"\badditional\s+materials?\b", re.IGNORECASE),
]


def normalize_text(text: str) -> str:
    """Lower-case, collapse whitespace, strip punctuation — for comparison."""
    t = text.lower()
    t = _WS.sub(" ", t)  # collapse whitespace to single spaces
    t = t.strip()
    return t


def _clean_text_for_dedup(text: str) -> str:
    """Strip Cambridge header/footer lines from text before comparison.

    The pipeline extracts text from the full PDF page, which includes
    running headers, page numbers, [Turn over] indicators, copyright notices,
    paper title lines, etc.  These differ between variants and would make
    the text different for the same question across variants.
    By stripping them, the comparison reflects only the actual question
    content.
    """
    lines = text.split("\n")
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        skip = False
        for pat in _HEADER_FOOTER_PATTERNS:
            if pat.search(stripped):
                skip = True
                break
        if not skip:
            cleaned.append(stripped)
    return " ".join(cleaned)


def text_similarity(text_a: str, text_b: str) -> float:
    """Compute similarity between two question texts after cleaning & normalising.

    Returns a float in [0.0, 1.0] where 1.0 means identical.
    """
    clean_a = normalize_text(_clean_text_for_dedup(text_a))
    clean_b = normalize_text(_clean_text_for_dedup(text_b))

    # If either is too short, fall back to 0 (not enough text to compare)
    if len(clean_a) < 20 or len(clean_b) < 20:
        return 0.0

    return SequenceMatcher(None, clean_a, clean_b).ratio()


def perceptual_fingerprint(img: Image.Image) -> str:
    small = img.convert("L").resize((256, 256))
    return str(imagehash.phash(small))


def attach_fingerprints(questions: List[Question]) -> None:
    """Attach cleaned normalised text and perceptual hashes to each question.

    We store the cleaned normalised text on the question object so that
    similarity comparisons can be done without re-cleaning each time.
    """
    for q in questions:
        q._cleaned_norm = normalize_text(_clean_text_for_dedup(q.text))
        # perceptual hash of the merged image
        merged = _merge(q.images)
        q.perceptual_hash = perceptual_fingerprint(merged)


def _merge(images) -> Image.Image:
    if not images:
        raise ValueError("question has no images")
    if len(images) == 1:
        return images[0]
    widths = [im.width for im in images]
    w = max(widths)
    h = sum(im.height for im in images)
    canvas = Image.new("RGB", (w, h), "white")
    y = 0
    for im in images:
        canvas.paste(im, (0, y))
        y += im.height
    return canvas


# ---------------------------------------------------------------------------
# Pre-filtering: quick exact-match check + prefix buckets
# ---------------------------------------------------------------------------
def _quick_hash(text: str) -> str:
    """Fast hash for exact-match pre-filtering."""
    import hashlib
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _prefix_bucket(text: str, n: int = 40) -> str:
    """Return the first n characters of normalised text for bucketing.

    Questions that are similar will usually share the same prefix bucket.
    This reduces the number of pairwise comparisons needed.
    """
    return text[:n]


# ---------------------------------------------------------------------------
# Number-aware duplicate detection
# ---------------------------------------------------------------------------
# Cambridge reuses the *same* question across variants (identical text, same
# numbers, same diagrams).  Two questions that are structurally similar but
# have different data values (e.g. "mass 2.0 kg" vs "mass 5.0 kg") are
# DIFFERENT questions and must NOT be collapsed.
#
# We handle this with a two-layer check:
#   1. Text similarity must be >= SIMILARITY_THRESHOLD (default 0.96).
#   2. The extracted numbers from both texts must match.  If the numbers
#      differ, the questions are NOT duplicates regardless of text similarity.
#
# This prevents false positives where two questions share the same template
# structure but have different numerical values.
# ---------------------------------------------------------------------------

# Default similarity threshold — questions at or above this similarity are
# *candidates* for being duplicates.  0.96 means 96% of the cleaned,
# normalised text must match.
SIMILARITY_THRESHOLD = 0.94

# Regex for extracting numbers from text (for number-aware check).
# Matches integers, decimals, and scientific notation.
_NUMBER_RE = re.compile(
    r"(?<![.\w])"           # not preceded by a dot or word char
    r"\d+\.?\d*"            # integer or decimal
    r"(?:[eE][+-]?\d+)?"    # optional exponent
    r"(?![.\w])"            # not followed by a dot or word char
)


def _extract_numbers(text: str) -> List[float]:
    """Extract all numeric values from normalised text."""
    nums = []
    for m in _NUMBER_RE.finditer(text):
        try:
            nums.append(float(m.group()))
        except ValueError:
            pass
    return nums


def _numbers_match(nums_a: List[float], nums_b: List[float],
                   tolerance: float = 0.01) -> bool:
    """Check whether two extracted number lists are the same.

    Two questions are considered to have matching numbers if their sorted
    number lists are the same length and every corresponding pair differs
    by less than ``tolerance`` (relative).

    This is the key safety check: questions that are textually very similar
    but have different numerical values are DIFFERENT questions, not
    duplicates.
    """
    if not nums_a and not nums_b:
        # Both have no numbers — rely on text similarity alone
        return True
    if len(nums_a) != len(nums_b):
        return False
    sa = sorted(nums_a)
    sb = sorted(nums_b)
    for a, b in zip(sa, sb):
        if a == 0 and b == 0:
            continue
        if a == 0 or b == 0:
            return False
        if abs(a - b) / max(abs(a), abs(b)) > tolerance:
            return False
    return True


def deduplicate(
    questions: List[Question],
    hamming: int = 8,
    similarity_threshold: float = SIMILARITY_THRESHOLD,
) -> List[Question]:
    """
    Mark duplicates in-place using similarity-based text comparison
    with number-aware safety checks.

    Two questions are considered duplicates when:
      - Both have sufficient text (≥20 chars normalised) AND their cleaned
        normalised text similarity ≥ ``similarity_threshold`` AND their
        extracted numbers match, OR
      - Both have insufficient text (image-only) AND their perceptual image
        hashes are within ``hamming`` bits.

    The number-aware check prevents false positives where two questions
    share the same template structure but have different numerical values
    (e.g. "mass 2.0 kg" vs "mass 5.0 kg").

    The first occurrence (by paper_code then question_number) is kept;
    later matches get ``is_duplicate=True`` and ``duplicate_of`` points at
    the surviving question's qid.
    """
    attach_fingerprints(questions)

    # stable ordering: keep the lowest paper_code / question_number first
    def sort_key(q: Question):
        try:
            pc = int(q.paper_code)
        except Exception:
            pc = 9999
        try:
            qn = int(q.question_number)
        except Exception:
            qn = 9999
        return (pc, qn)

    ordered = sorted(questions, key=sort_key)

    # Build lists of "seen" questions for comparison
    seen_text_questions: List[Question] = []   # questions with sufficient text
    seen_img_questions: List[Tuple[str, str]] = []  # (perceptual_hash, qid)

    n_comparisons = 0
    n_similar = 0
    n_num_reject = 0

    for q in ordered:
        dup_of = None
        has_text = len(getattr(q, "_cleaned_norm", "")) >= 20

        if has_text:
            # --- Text-based similarity comparison ---
            q_text = q._cleaned_norm
            q_nums = _extract_numbers(q_text)

            # Quick exact-match check first (fast path)
            q_hash = _quick_hash(q_text)
            exact_match = None
            for sq in seen_text_questions:
                if getattr(sq, "_exact_hash", None) == q_hash:
                    exact_match = sq.qid
                    break

            if exact_match is not None:
                dup_of = exact_match
            else:
                # Similarity comparison against all seen text questions
                # Use prefix bucketing to reduce unnecessary comparisons
                q_prefix = _prefix_bucket(q_text)
                best_sim = 0.0
                best_qid = None
                best_nums_match = False

                for sq in seen_text_questions:
                    sq_text = sq._cleaned_norm
                    sq_prefix = _prefix_bucket(sq_text)

                    # Quick pre-filter: if prefixes are very different, skip
                    # but still check if the first 10 chars match (handles
                    # cases where the question number is the only prefix diff)
                    if q_prefix[:10] != sq_prefix[:10]:
                        # Do a quick check: compute similarity on just the
                        # first 80 chars. If that's below threshold, skip.
                        if len(q_text) > 80 and len(sq_text) > 80:
                            quick_sim = SequenceMatcher(
                                None, q_text[:80], sq_text[:80]
                            ).ratio()
                            if quick_sim < similarity_threshold - 0.05:
                                continue

                    n_comparisons += 1
                    sim = SequenceMatcher(None, q_text, sq_text).ratio()
                    if sim > best_sim:
                        best_sim = sim
                        best_qid = sq.qid
                        # Number-aware check: only accept if numbers match
                        sq_nums = _extract_numbers(sq_text)
                        best_nums_match = _numbers_match(q_nums, sq_nums)

                if best_sim >= similarity_threshold:
                    if best_nums_match:
                        dup_of = best_qid
                        n_similar += 1
                    else:
                        # Text is similar but numbers differ → different question
                        n_num_reject += 1

        else:
            # --- Image-only: perceptual hash comparison ---
            for ph, qid in seen_img_questions:
                if _hamming(q.perceptual_hash, ph) <= hamming:
                    dup_of = qid
                    break

        if dup_of is not None:
            q.is_duplicate = True
            q.duplicate_of = dup_of
        else:
            if has_text:
                q._exact_hash = _quick_hash(q._cleaned_norm)
                seen_text_questions.append(q)
            else:
                seen_img_questions.append((q.perceptual_hash, q.qid))

    print(f"[dedup] Similarity comparisons: {n_comparisons}, "
          f"similar pairs found: {n_similar}, "
          f"rejected by number check: {n_num_reject}, "
          f"threshold: {similarity_threshold:.2f}")

    return questions


def _hamming(a: str, b: str) -> int:
    # imagehash strings are hex; compare bit difference via ints
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except Exception:
        return 999
