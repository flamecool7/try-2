"""
chemical_concepts.py
====================
Comprehensive semantic understanding and cross-topic analysis module for Cambridge exams.

Provides:
  1. Detailed chemical entity, formula, and pattern recognition across all 22 A-Level Chemistry topics
  2. Cross-topic pattern detection for hybrid exam questions (e.g. redox titrations, buffer equilibria, energetics + Le Chatelier)
  3. Subpart-level text extraction and concept attribution (e.g. part (a) vs part (b))
  4. Command word classification & Bloom's cognitive taxonomy mapping
  5. Multi-subject conceptual analysis (Physics, Biology, Computer Science, Math, Economics)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


# =============================================================================
# Command Words & Cognitive Skills
# =============================================================================

COMMAND_WORD_PATTERNS = {
    # Knowledge & Recall (Tier 1)
    "state": {"skill": "recall", "tier": 1},
    "define": {"skill": "recall", "tier": 1},
    "write": {"skill": "recall", "tier": 1},
    "name": {"skill": "recall", "tier": 1},
    "give": {"skill": "recall", "tier": 1},
    "list": {"skill": "recall", "tier": 1},
    "label": {"skill": "recall", "tier": 1},
    "identify": {"skill": "recall", "tier": 1},

    # Understanding & Explanation (Tier 2)
    "explain": {"skill": "understanding", "tier": 2},
    "describe": {"skill": "understanding", "tier": 2},
    "outline": {"skill": "understanding", "tier": 2},
    "compare": {"skill": "understanding", "tier": 2},
    "contrast": {"skill": "understanding", "tier": 2},
    "distinguish": {"skill": "understanding", "tier": 2},
    "suggest": {"skill": "understanding", "tier": 2},
    "discuss": {"skill": "understanding", "tier": 2},

    # Application & Calculation (Tier 3)
    "calculate": {"skill": "application", "tier": 3},
    "determine": {"skill": "application", "tier": 3},
    "find": {"skill": "application", "tier": 3},
    "estimate": {"skill": "application", "tier": 3},
    "complete": {"skill": "application", "tier": 3},
    "show": {"skill": "application", "tier": 3},
    "convert": {"skill": "application", "tier": 3},

    # Synthesis & Drawing (Tier 4)
    "draw": {"skill": "drawing", "tier": 2},
    "sketch": {"skill": "drawing", "tier": 2},
    "construct": {"skill": "drawing", "tier": 3},
    "deduce": {"skill": "synthesis", "tier": 4},
    "predict": {"skill": "synthesis", "tier": 4},
    "evaluate": {"skill": "analysis", "tier": 4},
    "justify": {"skill": "analysis", "tier": 4},
    "derive": {"skill": "synthesis", "tier": 4},
}


# =============================================================================
# Chemistry Domain Pattern Mapping (Topic -> Regex Patterns)
# =============================================================================

CHEMICAL_PATTERNS: Dict[str, str] = {
    # 1. Atomic Structure
    r"\b(?:electronic\s+configuration|sub-shell|orbital|ground\s+state|principal\s+quantum\s+number|ionisation\s+energy|first\s+ionisation\s+energy|successive\s+ionisation|nucleon\s+number|proton\s+number)\b": "Atomic_structure",
    r"\b(?:1s\s*2|2s\s*2|2p\s*6|3s\s*2|3p\s*6|3d\s*\d+|4s\s*\d+)\b": "Atomic_structure",

    # 2. Atoms, Molecules and Stoichiometry
    r"\b(?:avogadro\s+constant|molar\s+mass|percentage\s+yield|limiting\s+reagent|excess\s+reagent|empirical\s+formula|molecular\s+formula|stoichiometric|reacting\s+masses|reacting\s+volumes|titration\s+calculation)\b": "Atoms,_molecules_and_stoichiometry",
    r"\b(?:mol\s*dm[–-]?3|concentration\s+of|moles\s+of|standard\s+solution|volumetric\s+flask|pipette|burette)\b": "Atoms,_molecules_and_stoichiometry",

    # 3. Chemical Bonding
    r"\b(?:ionic\s+bonding|covalent\s+bonding|metallic\s+bonding|coordinate\s+bond|dative\s+bond|electronegativity|bond\s+polarity|dipole|van\s+der\s+waals|hydrogen\s+bond|vsepr|bond\s+angle|tetrahedral|trigonal\s+planar|octahedral|dot-and-cross)\b": "Chemical_bonding",
    r"\b(?:lone\s+pair|bonding\s+pair|hybridisation|sp\s*3|sp\s*2|sp\s*hybrid|sigma\s+bond|pi\s+bond|polar\s+molecule)\b": "Chemical_bonding",

    # 4. States of Matter
    r"\b(?:ideal\s+gas|ideal\s+gas\s+equation|pV\s*=\s*nRT|kinetic\s+theory|real\s+gas|molar\s+gas\s+volume|vaporisation|vapour\s+pressure|lattice\s+structure|giant\s+molecular|simple\s+molecular)\b": "States_of_matter",

    # 5. Chemical Energetics
    r"\b(?:lattice\s+energy|born-haber\s+cycle|enthalpy\s+of\s+hydration|enthalpy\s+of\s+solution|standard\s+enthalpy\s+change|hess'?s\s+law|calorimetry|bond\s+energy|average\s+bond\s+energy|standard\s+entropy|gibbs\s+free\s+energy|entropy\s+change|\u0394H|\u0394S|\u0394G)\b": "Chemical_energetics",
    r"\b(?:exothermic|endothermic|activation\s+energy|enthalpy\s+profile\s+diagram|spontaneous\s+reaction|feasible\s+reaction)\b": "Chemical_energetics",

    # 6. Electrochemistry
    r"\b(?:electrode\s+potential|standard\s+electrode\s+potential|reduction\s+potential|standard\s+cell\s+potential|cell\s+diagram|nernst\s+equation|faraday\s+constant|electrolysis|anode|cathode|salt\s+bridge|half-cell|half-equation|E\u29b5|E\u00b0)\b": "Electrochemistry",
    r"\b(?:redox|oxidising\s+agent|reducing\s+agent|oxidation\s+number|oxidation\s+state|disproportionation)\b": "Electrochemistry",

    # 7. Equilibria
    r"\b(?:dynamic\s+equilibrium|le\s+chatelier|equilibrium\s+constant|Kc\b|Kp\b|Ka\b|Kb\b|Kw\b|Ksp\b|Kstab\b|pH\b|pKa\b|pKb\b|buffer|buffer\s+solution|buffer\s+action|common\s+ion\s+effect|solubility\s+product|weak\s+acid|weak\s+base|conjugate\s+acid-base)\b": "Equilibria",
    r"\b(?:henderson-hasselbalch|pH\s*=\s*-\s*log|\[H\+\]|\[OH-\]|titration\s+curve|end-point|indicator|methyl\s+orange|phenolphthalein)\b": "Equilibria",

    # 8. Reaction Kinetics
    r"\b(?:rate\s+of\s+reaction|rate\s+equation|rate\s+constant|order\s+of\s+reaction|overall\s+order|initial\s+rate|half-life|rate-determining\s+step|activation\s+energy|arrhenius\s+equation|homogeneous\s+catalyst|heterogeneous\s+catalyst|boltzmann\s+distribution)\b": "Reaction_kinetics",
    r"\b(?:first\s+order|second\s+order|zero\s+order|continuous\s+monitoring|colorimetry|clock\s+reaction)\b": "Reaction_kinetics",

    # 9. Group 2
    r"\b(?:group\s+2|alkaline\s+earth|magnesium|calcium|strontium|barium|thermal\s+decomposition\s+of\s+group\s+2|solubility\s+of\s+group\s+2\s+sulfates|solubility\s+of\s+group\s+2\s+hydroxides|flame\s+test|slaked\s+lime|limestone)\b": "Group_2",

    # 10. Group 17
    r"\b(?:group\s+17|halogens|chlorine|bromine|iodine|halide\s+ions|silver\s+nitrate\s+test|aqueous\s+ammonia\s+test|bleaching\s+action|disproportionation\s+of\s+chlorine|volatility\s+of\s+halogens|thermal\s+stability\s+of\s+hydrogen\s+halides)\b": "Group_17",

    # 11. Nitrogen and Sulfur
    r"\b(?:habber\s+process|contact\s+process|ammonia|nitrogen\s+oxides|nitric\s+acid|sulfur\s+dioxide|sulfuric\s+acid|acid\s+rain|eutrophication|ammonium\s+fertiliser)\b": "Nitrogen_and_sulfur",

    # 12. Organic Chemistry AS Introduction
    r"\b(?:functional\s+group|homologous\s+series|iupac\s+naming|structural\s+isomerism|chain\s+isomerism|positional\s+isomerism|functional\s+group\s+isomerism|stereoisomerism|geometrical\s+isomerism|cis-trans|optical\s+isomerism|chiral\s+centre|enantiomer|curly\s+arrow|homolytic\s+fission|heterolytic\s+fission|electrophile|nucleophile|free\s+radical)\b": "An_introduction_to_AS_Level_organic_chemistry",

    # 13. Hydrocarbons
    r"\b(?:alkane|alkene|benzene|arene|aromatic|cyclohexane|electrophilic\s+addition|free\s+radical\s+substitution|cracking|combustion\s+of\s+alkanes|hydration\s+of\s+ethene|hydrogenation\s+of\s+alkenes|markovnikov|carbocation\s+stability|electrophilic\s+aromatic\s+substitution|nitration\s+of\s+benzene|friedel-crafts)\b": "Hydrocarbons",

    # 14. Halogen Compounds
    r"\b(?:halogenoalkane|alkyl\s+halide|nucleophilic\s+substitution|SN1|SN2|fluoroalkane|chloroalkane|bromoalkane|iodoalkane|hydrolysis\s+of\s+halogenoalkanes|elimination\s+reaction|CFCs|ozone\s+depletion)\b": "Halogen_compounds",

    # 15. Hydroxy Compounds
    r"\b(?:alcohol|phenol|primary\s+alcohol|secondary\s+alcohol|tertiary\s+alcohol|oxidation\s+of\s+alcohols|acidified\s+dichromate|reflux|distillation|esterification|acidity\s+of\s+phenol|tri-iodomethane\s+reaction|iodoform\s+test)\b": "Hydroxy_compounds",

    # 16. Carbonyl Compounds
    r"\b(?:aldehyde|ketone|carbonyl|nucleophilic\s+addition|2,4-dinitrophenylhydrazine|2,4-DNPH|brady'?s\s+reagent|tollens'?\s+reagent|fehling'?s\s+solution|reduction\s+of\s+carbonyl|sodium\s+borohydride|NaBH4|LiAlH4|cyanohydrin)\b": "Carbonyl_compounds",

    # 17. Carboxylic Acids and Derivatives
    r"\b(?:carboxylic\s+acid|ester|acyl\s+chloride|acid\s+anhydride|amide|esterification|acid\s+hydrolysis\s+of\s+esters|base\s+hydrolysis\s+of\s+esters|saponification|relative\s+acidity\s+of\s+carboxylic\s+acids|ethanoic\s+acid|benzoic\s+acid|SOCl2|PCl5|PCl3)\b": "Carboxylic_acids_and_derivatives",

    # 18. Nitrogen Compounds
    r"\b(?:amine|primary\s+amine|phenylamine|aniline|amide|amino\s+acid|zwitterion|isoelectric\s+point|peptide\s+bond|diazotisation|azo\s+dye|coupling\s+reaction|basicity\s+of\s+amines)\b": "Nitrogen_compounds",

    # 19. Polymerisation
    r"\b(?:addition\s+polymerisation|condensation\s+polymerisation|monomer|repeat\s+unit|polyester|polyamide|t полиэфир|terylene|dacron|nylon\s*6,?6|nylon\s*6|kevlar|biodegradable\s+polymer|conducting\s+polymer)\b": "Polymerisation",

    # 20. Organic Synthesis
    r"\b(?:synthetic\s+pathway|synthesis\s+route|multi-step\s+synthesis|target\s+molecule|retrosynthesis|functional\s+group\s+interconversion|reagents\s+and\s+conditions)\b": "Organic_synthesis",

    # 21. Analytical Techniques
    r"\b(?:infrared\s+spectroscopy|IR\s+spectrum|absorption\s+frequency|nuclear\s+magnetic\s+resonance|NMR\s+spectroscopy|1H\s+NMR|13C\s+NMR|chemical\s+shift|\u03b4\s*ppm|splitting\s+pattern|singlet|doublet|triplet|quartet|multiplet|integration\s+trace|mass\s+spectrometry|molecular\s+ion\s+peak|M\+1\s+peak|fragmentation\s+pattern|chromatography|Rf\s+value|retention\s+time)\b": "Analytical_techniques",

    # 22. Chemistry of Transition Elements
    r"\b(?:transition\s+element|transition\s+metal|d-block|complex\s+ion|coordination\s+number|ligand|monodentate|bidentate|polydentate|EDTA|d-orbital\s+splitting|octahedral\s+complex|tetrahedral\s+complex|colour\s+of\s+complexes|ligand\s+substitution|stability\s+constant|Kstab|homogeneous\s+catalysis\s+by\s+transition|heterogeneous\s+catalysis|variable\s+oxidation\s+states)\b": "Chemistry_of_transition_elements",
}


# =============================================================================
# Cross-Topic Relationship Rules
# =============================================================================

CROSS_TOPIC_PATTERNS: List[Tuple[str, List[str]]] = [
    # Redox titrations -> Electrochemistry + Stoichiometry
    (r"(?:redox\s+titration|potassium\s+manganate|KMnO4|potassium\s+dichromate|K2Cr2O7|sodium\s+thiosulfate|Na2S2O3|iodometric|iodine-thiosulfate)",
     ["Electrochemistry", "Atoms,_molecules_and_stoichiometry"]),

    # Buffer equilibrium -> Equilibria + Stoichiometry
    (r"(?:calculate\s+pH\s+of\s+buffer|buffer\s+solution\s+containing|mixture\s+of\s+ethanoic\s+acid\s+and\s+sodium\s+ethanoate)",
     ["Equilibria", "Atoms,_molecules_and_stoichiometry"]),

    # Le Chatelier + Enthalpy / Energetics
    (r"(?:le\s+chatelier.*enthalpy|exothermic.*equilibrium|effect\s+of\s+temperature\s+on\s+Kc|effect\s+of\s+temperature\s+on\s+equilibrium)",
     ["Equilibria", "Chemical_energetics"]),

    # Transition metal complex + Equilibrium
    (r"(?:stability\s+constant|Kstab|ligand\s+substitution.*equilibrium|equilibrium.*complex\s+ion)",
     ["Chemistry_of_transition_elements", "Equilibria"]),

    # Kinetics + Reaction mechanism
    (r"(?:rate\s+determining\s+step.*mechanism|order\s+of\s+reaction.*mechanism|rate\s+equation.*SN1|rate\s+equation.*SN2)",
     ["Reaction_kinetics", "Halogen_compounds"]),

    # Spectroscopy + Structure deduction
    (r"(?:spectrum.*deduce\s+the\s+structure|NMR.*molecular\s+formula|infrared.*functional\s+group.*mass\s+spec)",
     ["Analytical_techniques", "An_introduction_to_AS_Level_organic_chemistry"]),

    # Group 2 thermal decomposition + Lattice energy / Energetics
    (r"(?:thermal\s+stability.*group\s+2.*lattice|decomposition.*carbonate.*polarising\s+power|lattice\s+energy.*hydration.*solubility)",
     ["Group_2", "Chemical_energetics"]),

    # Organic synthesis + Functional group interconversion
    (r"(?:reaction\s+scheme.*synthesise|synthetic\s+route.*yield|multi-step.*reagents\s+and\s+conditions)",
     ["Organic_synthesis", "An_introduction_to_AS_Level_organic_chemistry"]),

    # Electrochemistry + Gibbs Free Energy / Equilibrium
    (r"(?:E\u29b5.*gibbs\s+free\s+energy|\u0394G\u29b5\s*=\s*-\s*nFE|cell\s+potential.*equilibrium\s+constant)",
     ["Electrochemistry", "Chemical_energetics", "Equilibria"]),

    # Polymers + Carboxylic acids / Amides
    (r"(?:polyester.*dicarboxylic|polyamide.*diamine|condensation\s+polymer.*monomer)",
     ["Polymerisation", "Carboxylic_acids_and_derivatives"]),
]

TOPIC_RELATIONSHIPS: Dict[str, Dict[str, List[str]]] = {
    "Equilibria": {
        "related": ["Chemical_energetics", "Electrochemistry", "Atoms,_molecules_and_stoichiometry", "Reaction_kinetics", "Chemistry_of_transition_elements"],
        "shared_concepts": ["le chatelier", "equilibrium constant", "Kc", "Kp", "Ka", "buffer", "pH", "titration", "Kstab"],
    },
    "Chemical_energetics": {
        "related": ["Equilibria", "Atomic_structure", "Group_2", "Chemical_bonding", "Electrochemistry"],
        "shared_concepts": ["enthalpy", "lattice energy", "born-haber", "entropy", "gibbs", "hess", "bond energy"],
    },
    "Electrochemistry": {
        "related": ["Equilibria", "Chemical_energetics", "Atoms,_molecules_and_stoichiometry", "Group_17", "Chemistry_of_transition_elements"],
        "shared_concepts": ["redox", "electrode potential", "cell potential", "half-equation", "oxidation", "reduction", "titration"],
    },
    "Reaction_kinetics": {
        "related": ["Equilibria", "States_of_matter", "Chemical_energetics", "Halogen_compounds"],
        "shared_concepts": ["rate", "order", "activation energy", "catalyst", "half-life", "boltzmann", "mechanism"],
    },
    "Atomic_structure": {
        "related": ["Chemical_bonding", "Chemistry_of_transition_elements", "Group_2"],
        "shared_concepts": ["electronic configuration", "ionisation energy", "orbital", "sub-shell", "proton number"],
    },
    "Chemical_bonding": {
        "related": ["Atomic_structure", "States_of_matter", "An_introduction_to_AS_Level_organic_chemistry"],
        "shared_concepts": ["electronegativity", "covalent", "ionic", "hydrogen bond", "dipole", "vsepr", "molecular shape"],
    },
    "Analytical_techniques": {
        "related": ["Organic_synthesis", "Carbonyl_compounds", "Carboxylic_acids_and_derivatives", "Hydroxy_compounds", "Nitrogen_compounds"],
        "shared_concepts": ["NMR", "infrared", "mass spectrum", "chemical shift", "splitting", "molecular ion"],
    },
    "Chemistry_of_transition_elements": {
        "related": ["Equilibria", "Electrochemistry", "Chemical_bonding", "Analytical_techniques"],
        "shared_concepts": ["complex ion", "ligand", "stability constant", "d-orbital", "variable oxidation state", "colour"],
    },
}


# =============================================================================
# Question Subpart Parser & Semantic Analysis
# =============================================================================

@dataclass
class QuestionAnalysis:
    """Detailed semantic analysis of an exam question."""
    text: str
    command_words: List[Tuple[str, str]] = field(default_factory=list)
    chemical_patterns: Dict[str, List[str]] = field(default_factory=dict)
    cross_topic_hints: List[List[str]] = field(default_factory=list)
    subpart_analyses: Dict[str, Dict[str, float]] = field(default_factory=dict)
    detected_concepts: Dict[str, float] = field(default_factory=dict)
    skill_level: str = "unknown"
    complexity_score: float = 0.0


def extract_command_words(text: str) -> List[Tuple[str, str]]:
    """Extract command words and their Bloom's taxonomy skill level."""
    found: List[Tuple[str, str]] = []
    text_lower = text.lower()
    for word, info in COMMAND_WORD_PATTERNS.items():
        pattern = r"\b" + re.escape(word) + r"\b"
        if re.search(pattern, text_lower):
            found.append((word, info["skill"]))
    return found


def detect_chemical_patterns(text: str) -> Dict[str, List[str]]:
    """Match domain regex patterns against question text."""
    matches: Dict[str, List[str]] = {}
    text_lower = text.lower()
    for pattern, topic in CHEMICAL_PATTERNS.items():
        try:
            found = re.findall(pattern, text_lower, re.IGNORECASE)
            if found:
                matches.setdefault(topic, []).extend(
                    [f.strip() if isinstance(f, str) else str(f) for f in found]
                )
        except re.error:
            continue
    return matches


def detect_cross_topic_patterns(text: str) -> List[List[str]]:
    """Detect cross-topic hybrid question patterns."""
    detected: List[List[str]] = []
    text_lower = text.lower()
    for pattern, topics in CROSS_TOPIC_PATTERNS:
        try:
            if re.search(pattern, text_lower, re.IGNORECASE):
                detected.append(topics)
        except re.error:
            continue
    return detected


def split_question_subparts(text: str) -> List[Tuple[str, str]]:
    """
    Split question text into its subparts: e.g. (a), (b), (c), (i), (ii).
    Returns a list of (label, text) pairs.
    """
    lines = text.splitlines()
    subparts: List[Tuple[str, List[str]]] = []
    current_label = "intro"
    current_lines: List[str] = []

    sub_pattern = re.compile(
        r"^\s*(?:\(\s*([a-z]|[ivx]{1,4})\s*\)|([a-z]|[ivx]{1,4})\))\s*(?:\(\s*([a-z]|[ivx]{1,4})\s*\))?\s*(.*)",
        re.IGNORECASE,
    )

    for line in lines:
        m = sub_pattern.match(line)
        if m and len(line.strip()) > 2:
            if current_lines:
                subparts.append((current_label, current_lines))
            p1 = (m.group(1) or m.group(2) or "").lower()
            p2 = (m.group(3) or "").lower()
            current_label = f"({p1})" if not p2 else f"({p1})({p2})"
            current_lines = [m.group(4) or ""]
        else:
            current_lines.append(line)

    if current_lines:
        subparts.append((current_label, current_lines))

    return [(label, "\n".join(lns).strip()) for label, lns in subparts if "\n".join(lns).strip()]


def get_related_topics(topic: str) -> List[str]:
    """Retrieve related topics for cross-topic boosting."""
    if topic in TOPIC_RELATIONSHIPS:
        return TOPIC_RELATIONSHIPS[topic]["related"]
    return []


def analyze_question(text: str) -> QuestionAnalysis:
    """Comprehensive semantic analysis of question text and subparts."""
    if not text:
        return QuestionAnalysis(text="")

    command_words = extract_command_words(text)
    chemical_patterns = detect_chemical_patterns(text)
    cross_topic_hints = detect_cross_topic_patterns(text)

    # Subpart-level analysis
    subparts = split_question_subparts(text)
    subpart_analyses: Dict[str, Dict[str, float]] = {}
    for label, sub_text in subparts:
        if label == "intro" and len(sub_text) < 20:
            continue
        sub_patterns = detect_chemical_patterns(sub_text)
        sub_scores: Dict[str, float] = {}
        for topic, matches in sub_patterns.items():
            sub_scores[topic] = len(matches) * 2.0
        if sub_scores:
            subpart_analyses[label] = sub_scores

    # Cognitive skill level
    skill_types = [skill for _, skill in command_words]
    if "synthesis" in skill_types or "analysis" in skill_types:
        skill_level = "high"
    elif "application" in skill_types:
        skill_level = "medium"
    else:
        skill_level = "recall"

    complexity_score = (
        len(command_words) * 0.2 +
        len(chemical_patterns) * 0.4 +
        len(cross_topic_hints) * 0.6 +
        len(subpart_analyses) * 0.3
    )

    return QuestionAnalysis(
        text=text,
        command_words=command_words,
        chemical_patterns=chemical_patterns,
        cross_topic_hints=cross_topic_hints,
        subpart_analyses=subpart_analyses,
        detected_concepts={},
        skill_level=skill_level,
        complexity_score=complexity_score,
    )
