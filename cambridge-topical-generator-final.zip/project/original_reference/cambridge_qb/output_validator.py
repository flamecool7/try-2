"""
output_validator.py
===================
Automated end-to-end consistency validation and single-folder distribution validator
for Cambridge question bank generation (Sections 31–46).

Enforces Hard Invariants:
  1. OFFICIAL MAJOR-TOPIC FOLDERS ONLY: Folders are named strictly after official Major Topics
     (e.g., Chemical_energetics, Organic_chemistry, Equilibria, Electrochemistry,
     Atomic_structure, Reaction_kinetics, Amount_of_substance, Chemical_bonding).
  2. ZERO SUBTOPIC FOLDERS: Scans output tree and eliminates any folders created from
     detailed syllabus subtopics (e.g. Carbonyl_compounds, Hydrocarbons, Group_2, Group_17),
     moving contents to the appropriate Major Topic folder.
  3. SINGLE-FOLDER QUESTION DISTRIBUTION: Every question exists in EXACTLY ONE major-topic folder.
  4. NO METADATA-ONLY FOLDERS: Every folder is valid ONLY when physical question crop images
     (.webp) are present.
  5. STRICT JSON ADHERENCE: Confirms zero "topic_details", "primary", "secondary", or
     "needs_review" fields exist in any metadata.json.
  6. EXACT 2280px WIDTH: Confirms every question image is exactly 2280 pixels wide.
"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from PIL import Image

from .metadata import _META_FIELDS, compute_topic_field
from .multipage_optimizer import assemble_multipage_question, enforce_exact_width_2280
from .organize import _paper_type_folder, select_winning_major_topic
from .question_split import Question
from .reference import canonical_season
from .syllabus_hierarchy import (
    SYLLABUS_CONFIGURATIONS,
    get_subject_config,
    resolve_detailed_to_major_topic,
)
from .webp_utils import save_webp

TARGET_WIDTH = 2280


def validate_and_heal_output(
    output_dir: str | Path,
    questions: List[Question],
    subject: str,
    syllabus_code: str,
    *,
    webp_quality: int = 88,
) -> Tuple[bool, List[str]]:
    """
    Run complete end-to-end output validation enforcing official major-topic single-folder distribution:
      1. Major-Topic-Only validation: Eliminates any rogue subtopic folders.
      2. Single-Folder Invariant: Guarantees every question exists in EXACTLY ONE major-topic folder.
      3. Heals any missing crop image or metadata-only folders.
      4. Validates strict JSON metadata formatting (no topic_details).
      5. Validates image dimensions (width == 2280px) and readability.
      6. Cleans up any empty or invalid directories.
    """
    root = Path(output_dir)
    subject_dir = root / subject
    if not subject_dir.exists():
        return False, ["Subject output directory does not exist"]

    issues_found: List[str] = []
    healed_count = 0

    # Build question lookup map by base label and ID
    q_map_by_base: Dict[str, Question] = {}
    q_map_by_id: Dict[str, Question] = {}

    for q in questions:
        if q.is_duplicate or not q.images:
            continue
        p_code = str(q.paper_code or "").lstrip("0") or str(q.paper_code or "")
        season = canonical_season(q.session_label or "Unknown")
        base = f"{p_code}_{season}_{q.year}_Q{q.question_number}"
        q_map_by_base[base] = q
        if q.qid:
            q_map_by_id[q.qid] = q

    subject_cfg = get_subject_config(syllabus_code)
    valid_major_topic_ids = set(subject_cfg.keys())

    # ---------------------------------------------------------------------------
    # Step 1: Major-Topic-Only Folder Enforcement (Eliminate Subtopic Folders)
    # ---------------------------------------------------------------------------
    for pt_dir in subject_dir.iterdir():
        if not pt_dir.is_dir() or pt_dir.name.endswith(".json"):
            continue

        for topic_dir in list(pt_dir.iterdir()):
            if not topic_dir.is_dir():
                continue

            folder_topic = topic_dir.name

            # Check if this folder is a detailed subtopic rather than a major topic
            correct_major = resolve_detailed_to_major_topic(folder_topic, syllabus_code=syllabus_code)
            if folder_topic != correct_major and correct_major in valid_major_topic_ids:
                issues_found.append(f"SUBTOPIC_FOLDER_DETECTED: {folder_topic} -> moving to {correct_major}")
                target_major_dir = pt_dir / correct_major
                target_major_dir.mkdir(parents=True, exist_ok=True)

                for q_dir in topic_dir.iterdir():
                    if q_dir.is_dir():
                        dest_q_dir = target_major_dir / q_dir.name
                        dest_q_dir.mkdir(parents=True, exist_ok=True)
                        for item in q_dir.iterdir():
                            dest_file = dest_q_dir / item.name
                            if not dest_file.exists():
                                shutil.copy2(item, dest_file)

                shutil.rmtree(topic_dir)
                healed_count += 1
                print(f"  [major-topic-heal] Moved subtopic folder {folder_topic} contents into {correct_major} and deleted {folder_topic}")

    # ---------------------------------------------------------------------------
    # Step 2: Single-Folder Distribution Enforcement (Sections 38–46)
    # ---------------------------------------------------------------------------
    for q in questions:
        if q.is_duplicate or not q.images:
            continue

        p_code = str(q.paper_code or "").lstrip("0") or str(q.paper_code or "")
        season = canonical_season(q.session_label or "Unknown")
        base = f"{p_code}_{season}_{q.year}_Q{q.question_number}"
        pt_folder = _paper_type_folder(q.paper_code, syllabus=syllabus_code)
        winning_major = select_winning_major_topic(q, syllabus_code=syllabus_code)

        target_folder = subject_dir / pt_folder / winning_major / base
        img_path = target_folder / f"{base}.webp"
        meta_path = target_folder / "metadata.json"

        # Find all folders where this question currently exists
        found_folders: List[Path] = []
        for pt_d in subject_dir.iterdir():
            if not pt_d.is_dir() or pt_d.name.endswith(".json"):
                continue
            for major_d in pt_d.iterdir():
                if not major_d.is_dir():
                    continue
                q_d = major_d / base
                if q_d.exists() and any(q_d.glob("*.webp")):
                    found_folders.append(q_d)

        # Invariant check: count must be exactly 1
        if len(found_folders) > 1:
            issues_found.append(f"DUPLICATE_DISTRIBUTION_DETECTED: {base} found in {len(found_folders)} folders")
            for f in found_folders:
                if f != target_folder:
                    shutil.rmtree(f)
                    healed_count += 1
                    print(f"  [duplicate-heal] Removed duplicate question folder from {f.relative_to(root)}")

        # Ensure question exists in its winning folder
        if not target_folder.exists() or not img_path.exists():
            issues_found.append(f"MISSING_WINNING_CROP: {winning_major}/{base}.webp")
            target_folder.mkdir(parents=True, exist_ok=True)

            real_imgs = [im for im in q.images if im.height >= 17] or q.images
            if len(real_imgs) > 1:
                q_img = assemble_multipage_question(real_imgs, target_width=TARGET_WIDTH)
            else:
                q_img = enforce_exact_width_2280(real_imgs[0], target_width=TARGET_WIDTH)
            save_webp(q_img, img_path, quality=webp_quality)
            healed_count += 1
            print(f"  [heal-fix] Saved question crop into winning folder: {target_folder.relative_to(root)}")

        # Ensure strict metadata exists in winning folder
        if not meta_path.exists():
            from .metadata import build_metadata, write_metadata
            meta = build_metadata(
                q, subject=subject, level="A-Level", board="CIE", syllabus_code=syllabus_code
            )
            write_metadata(meta_path, meta)
            print(f"  [heal-fix] Created metadata.json in winning folder: {target_folder.relative_to(root)}")

    # ---------------------------------------------------------------------------
    # Step 3: Validate Strict JSON Metadata Schema Across All Files
    # ---------------------------------------------------------------------------
    meta_files = list(subject_dir.rglob("metadata.json"))
    for mf in meta_files:
        try:
            data = json.loads(mf.read_text(encoding="utf-8"))
        except Exception as e:
            issues_found.append(f"CORRUPTED_JSON: {mf} - {e}")
            continue

        forbidden = ["topic_details", "primary", "secondary", "needs_review"]
        found_forbidden = [k for k in forbidden if k in data]
        if found_forbidden:
            issues_found.append(f"FORBIDDEN_FIELDS_IN_JSON: {mf} has {found_forbidden}")
            cleaned = {k: data[k] for k in _META_FIELDS if k in data}
            mf.write_text(json.dumps(cleaned, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            print(f"  [heal-fix] Cleaned metadata.json schema at {mf.relative_to(root)}")

        if not isinstance(data.get("topic"), list) or not data.get("topic"):
            issues_found.append(f"INVALID_TOPIC_ARRAY: {mf}")

    # ---------------------------------------------------------------------------
    # Step 4: Validate Image Dimensions (Width == 2280px) and Readability
    # ---------------------------------------------------------------------------
    image_files = list(subject_dir.rglob("*.webp"))
    for img_path in image_files:
        if "_MS" in img_path.stem:
            continue
        try:
            with Image.open(img_path) as im:
                if im.width != TARGET_WIDTH:
                    issues_found.append(f"WIDTH_MISMATCH: {img_path} width={im.width} != 2280")
                    fixed_im = enforce_exact_width_2280(im, target_width=TARGET_WIDTH)
                    fixed_im.save(str(img_path), format="WEBP", quality=webp_quality, method=4)
                    print(f"  [heal-fix] Resized image to exactly 2280px at {img_path.relative_to(root)}")
        except Exception as e:
            issues_found.append(f"CORRUPTED_IMAGE: {img_path} - {e}")

    # ---------------------------------------------------------------------------
    # Step 5: Clean Up Any Empty Leftover Directories
    # ---------------------------------------------------------------------------
    for dirpath, dirnames, filenames in os.walk(subject_dir, topdown=False):
        current_dir = Path(dirpath)
        if current_dir != subject_dir:
            try:
                if not any(current_dir.iterdir()):
                    current_dir.rmdir()
            except OSError:
                pass

    success = len(issues_found) == 0 or healed_count > 0
    return success, issues_found
