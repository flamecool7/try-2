"""
correction_tracker.py
====================
Learning system for manual correction of topic classifications.

Features:
- Store corrections persistently
- Track classification accuracy
- Apply corrections automatically
- Learn from patterns in corrections
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set


@dataclass
class Correction:
    """A single correction entry."""
    question_id: str
    original_topics: List[str]
    corrected_topics: List[str]
    original_primary: str
    corrected_primary: str
    confidence: float
    paper_code: str
    question_number: str
    text_preview: str  # First 100 chars
    timestamp: str = ""
    source: str = "manual"  # manual, auto_learned, batch
    notes: str = ""
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
        if not self.text_preview:
            self.text_preview = ""


@dataclass
class CorrectionStats:
    """Statistics about corrections."""
    total_corrections: int = 0
    by_topic: Dict[str, int] = field(default_factory=dict)
    accuracy_improvement: float = 0.0
    corrections_per_topic: Dict[str, Dict[str, int]] = field(default_factory=dict)


class CorrectionTracker:
    """
    Tracks and applies corrections to topic classifications.
    
    Usage:
        tracker = CorrectionTracker("path/to/corrections.json")
        
        # Load existing corrections
        tracker.load()
        
        # Check if a question has a known correction
        if tracker.has_correction(q.qid):
            q.topic = tracker.get_correction(q.qid).corrected_topics
        
        # Record a new correction
        tracker.record(correction)
        
        # Save to disk
        tracker.save()
    """
    
    def __init__(self, corrections_path: str | Path):
        self.path = Path(corrections_path)
        self.corrections: Dict[str, Correction] = {}
        self.stats = CorrectionStats()
        self._loaded = False
        
    def load(self) -> None:
        """Load corrections from disk."""
        if self._loaded:
            return
            
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                self.corrections = {
                    qid: Correction(**corr) 
                    for qid, corr in data.get("corrections", {}).items()
                }
                self.stats = CorrectionStats(**data.get("stats", {}))
            except (json.JSONDecodeError, TypeError) as e:
                print(f"[correction-tracker] Warning: Could not load corrections: {e}")
                self.corrections = {}
                self.stats = CorrectionStats()
        
        self._loaded = True
    
    def save(self) -> None:
        """Save corrections to disk."""
        data = {
            "corrections": {
                qid: asdict(corr) 
                for qid, corr in self.corrections.items()
            },
            "stats": asdict(self.stats),
            "last_updated": datetime.now().isoformat(),
        }
        
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
    
    def has_correction(self, question_id: str) -> bool:
        """Check if a correction exists for this question."""
        if not self._loaded:
            self.load()
        return question_id in self.corrections
    
    def get_correction(self, question_id: str) -> Optional[Correction]:
        """Get the correction for a question."""
        if not self._loaded:
            self.load()
        return self.corrections.get(question_id)
    
    def record(self, correction: Correction) -> None:
        """Record a new correction."""
        if not self._loaded:
            self.load()
        
        qid = correction.question_id
        self.corrections[qid] = correction
        self._update_stats(correction)
    
    def _update_stats(self, correction: Correction) -> None:
        """Update statistics after a correction."""
        self.stats.total_corrections += 1
        
        # Track by topic
        for topic in correction.corrected_topics:
            self.stats.by_topic[topic] = self.stats.by_topic.get(topic, 0) + 1
            
            if topic not in self.stats.corrections_per_topic:
                self.stats.corrections_per_topic[topic] = {}
            
            orig = correction.original_primary
            self.stats.corrections_per_topic[topic][orig] = \
                self.stats.corrections_per_topic[topic].get(orig, 0) + 1
    
    def apply_corrections(self, questions: List) -> List[dict]:
        """
        Apply known corrections to questions.
        
        Returns a list of applied corrections for logging.
        """
        if not self._loaded:
            self.load()
        
        applied = []
        for q in questions:
            qid = getattr(q, 'qid', None) or getattr(q, 'qid', '')
            if not qid:
                continue
                
            if self.has_correction(qid):
                corr = self.get_correction(qid)
                q.topic = corr.corrected_topics
                q.needs_review = False
                q.topic_confidence = 1.0
                applied.append({
                    "question": f"{q.paper_code}_Q{q.question_number}",
                    "original": corr.original_topics,
                    "corrected": corr.corrected_topics,
                })
        
        return applied
    
    def get_uncertainty_log(self) -> List[dict]:
        """Get questions that were marked as needing review."""
        if not self._loaded:
            self.load()
        
        uncertain = []
        for qid, corr in self.corrections.items():
            if corr.notes == "uncertain":
                uncertain.append(asdict(corr))
        return uncertain
    
    def get_topic_patterns(self) -> Dict[str, List[str]]:
        """
        Extract patterns from corrections for auto-learning.
        
        Returns a dict mapping topics to common text patterns that
        should be classified under them.
        """
        if not self._loaded:
            self.load()
        
        patterns: Dict[str, List[str]] = {}
        
        for qid, corr in self.corrections.items():
            if corr.source != "manual":
                continue
                
            for topic in corr.corrected_topics:
                if topic not in patterns:
                    patterns[topic] = []
                
                # Store text snippets for pattern learning
                if corr.text_preview:
                    patterns[topic].append(corr.text_preview)
        
        return patterns
    
    def get_summary(self) -> dict:
        """Get a summary of the correction system."""
        if not self._loaded:
            self.load()
        
        return {
            "total_corrections": self.stats.total_corrections,
            "topics_with_corrections": len(self.stats.by_topic),
            "most_corrected_topics": sorted(
                self.stats.by_topic.items(),
                key=lambda x: x[1],
                reverse=True
            )[:10],
            "correction_rate": len(self.corrections),
        }
