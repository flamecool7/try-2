from __future__ import annotations
import json
from collections import Counter
from pathlib import Path
from typing import Dict, List

def build_log(*, papers_processed, missing_papers, questions_processed,
              duplicates_removed, topics_created, manual_review,
              questions_per_topic) -> dict:
    return {
        "papers_processed": sorted(set(papers_processed)),
        "missing_papers": sorted(set(missing_papers)),
        "questions_processed": questions_processed,
        "duplicates_removed": duplicates_removed,
        "topics_created": sorted(set(topics_created)),
        "questions_per_topic": dict(Counter(questions_per_topic)),
        "manual_review_required": sorted(set(manual_review)),
    }

def write_log(path: str | Path, log: dict) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")
