"""
Cambridge Past Paper Topical Screenshot Organizer (universal subject version).

Enhanced modules:
- topics_enhanced: Multi-topic classification with semantic understanding
- chemical_concepts: Chemistry-specific semantic analysis
- correction_tracker: Learning system for manual corrections
- chemistry_reference: Intelligent reference material & data sheet removal
- quality_control: Multi-layer quality control and validation system
"""

# Core modules (original)
from .config import Config
from .converter import convert_pdf_to_webp, render_pdf_local
from .dedup import deduplicate
from .logging_utils import build_log, write_log
from .markscheme import process_mark_schemes, lookup_mark_scheme, paper_type
from .metadata import build_metadata, primary_topic, secondary_topics, write_metadata
from .ms_crop import crop_to_mark_box
from .organize import organize
from .paper_scan import PaperInfo, scan_papers
from .pipeline import run as run_pipeline
from .question_split import Question, split_questions, fixed_crop_page, adaptive_crop_page
from .reference import canonical_season, detect_level, detect_subject, resolve_topics_file
from .topics import assign_topics, load_topics, Topic, TopicEvidence

# Chemistry reference removal & Quality Control
from .chemistry_reference import (
    PageClassification,
    classify_page,
    identify_removable_pages,
)
from .quality_control import (
    QuestionQCValidator,
    QCValidationResult,
)
from .output_validator import (
    validate_and_heal_output,
)
from .multipage_optimizer import (
    assemble_multipage_question,
    trim_page_section,
    find_content_bbox,
    validate_content_preservation,
)

# Enhanced modules (new)
try:
    from .topics_enhanced import (
        MultiTopicClassifier,
        assign_topics as assign_topics_enhanced,
        load_topics as load_topics_enhanced,
        Topic as EnhancedTopic,
        TopicEvidence as EnhancedTopicEvidence,
        TopicAssignment,
        MultiTopicResult,
    )
    from .chemical_concepts import (
        analyze_question,
        detect_cross_topic_patterns,
        detect_chemical_patterns,
        detect_command_words,
        QuestionAnalysis,
        CROSS_TOPIC_PATTERNS,
        TOPIC_RELATIONSHIPS,
    )
    from .correction_tracker import (
        CorrectionTracker,
        Correction,
        CorrectionStats,
    )
    ENHANCED_AVAILABLE = True
except ImportError:
    ENHANCED_AVAILABLE = False
    MultiTopicClassifier = None
    TopicAssignment = None
    MultiTopicResult = None
    CorrectionTracker = None
    Correction = None

__all__ = [
    # Core modules
    "Config",
    "convert_pdf_to_webp",
    "render_pdf_local",
    "deduplicate",
    "build_log",
    "write_log",
    "process_mark_schemes",
    "lookup_mark_scheme",
    "paper_type",
    "build_metadata",
    "primary_topic",
    "secondary_topics",
    "write_metadata",
    "crop_to_mark_box",
    "organize",
    "PaperInfo",
    "scan_papers",
    "run_pipeline",
    "Question",
    "split_questions",
    "fixed_crop_page",
    "adaptive_crop_page",
    "canonical_season",
    "detect_level",
    "detect_subject",
    "resolve_topics_file",
    "assign_topics",
    "load_topics",
    "Topic",
    "TopicEvidence",

    # Quality Control & Chemistry Reference & Multipage Optimizer & Output Validator
    "PageClassification",
    "classify_page",
    "identify_removable_pages",
    "QuestionQCValidator",
    "QCValidationResult",
    "validate_and_heal_output",
    "assemble_multipage_question",
    "trim_page_section",
    "find_content_bbox",
    "validate_content_preservation",

    # Enhanced modules (if available)
    "MultiTopicClassifier",
    "TopicAssignment",
    "MultiTopicResult",
    "QuestionAnalysis",
    "CorrectionTracker",
    "Correction",
    "ENHANCED_AVAILABLE",
]
