"""
pipeline.py (Enhanced)
=====================
End-to-end orchestration with multi-topic classification support.

Enhancements:
- Uses MultiTopicClassifier for better classification
- Supports correction tracker integration
- Enhanced logging of multi-topic assignments
- Cross-folder organization support
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PIL import Image

from . import question_split as qs
from .dedup import deduplicate
from .logging_utils import build_log, write_log
from .markscheme import process_mark_schemes, paper_type, lookup_mark_scheme
from .organize import organize
from .paper_scan import PaperInfo, scan_papers
from .reference import detect_level, detect_subject, resolve_topics_file

# Import the enhanced classifier
try:
    from .topics_enhanced import MultiTopicClassifier, assign_topics
    from .correction_tracker import CorrectionTracker, Correction
    ENHANCED_CLASSIFIER_AVAILABLE = True
except ImportError:
    ENHANCED_CLASSIFIER_AVAILABLE = False
    # Fall back to original
    from .topics import assign_topics


def _majority_identity(papers: List[PaperInfo]) -> Tuple[str, str, str, str]:
    qp = [p for p in papers if p.kind == "qp"]
    pool = qp or papers
    def _mode(key):
        return Counter(getattr(p, key) for p in pool).most_common(1)[0][0]
    syllabus = _mode("syllabus")
    subject = detect_subject(syllabus)
    level = detect_level(syllabus)
    return subject, level, syllabus, "CIE"


def _filter_papers(papers: List[PaperInfo], wanted: set
                   ) -> Tuple[List[PaperInfo], List[str]]:
    """Split papers into (accepted, skipped_warnings) according to paper type."""
    keep: List[PaperInfo] = []
    warnings: List[str] = []
    for p in papers:
        ptype = paper_type(p.paper_code, syllabus=p.syllabus)
        if ptype in wanted:
            keep.append(p)
        else:
            label = "/".join(sorted(wanted))
            try:
                pn = int(str(p.paper_code).lstrip("0")[0])
            except (TypeError, ValueError, IndexError):
                pn = "?"
            warnings.append(
                f"skipping_{ptype}_paper:{Path(p.path).name} "
                f"(variant {p.paper_code} -> paper {pn}); "
                f"this run is configured for {label} papers only")
    return keep, warnings


def run(config) -> dict:
    """Run the complete pipeline with enhanced multi-topic support."""
    input_dir = Path(config.input_dir)
    output_dir = Path(config.output_dir)

    print("=" * 60)
    print(" Cambridge Topical Question-Bank Generator")
    print(" [Enhanced Multi-Topic Classification System]")
    print("=" * 60)
    print(f" Input folder   : {input_dir.resolve()}")
    print(f" Output folder  : {output_dir.resolve()}")
    if ENHANCED_CLASSIFIER_AVAILABLE:
        print(f" Enhanced classifier: ENABLED")
    else:
        print(f" Enhanced classifier: NOT AVAILABLE (using fallback)")
    print()

    papers, unrecognized = scan_papers(input_dir)

    # Filter papers by type
    paper_types: set = getattr(config, "paper_types", None) or {"mcq", "structured"}
    if isinstance(paper_types, str):
        paper_types = {paper_types}
    else:
        paper_types = set(paper_types)

    all_qp = [p for p in papers if p.kind == "qp"]
    all_ms = [p for p in papers if p.kind == "ms"]
    qp_keep, skip_qp_warnings = _filter_papers(all_qp, paper_types)
    ms_keep, skip_ms_warnings = _filter_papers(all_ms, paper_types)
    skip_warnings = skip_qp_warnings + skip_ms_warnings

    if skip_warnings:
        print(f"[filter] Skipping {len(skip_warnings)} non-selected paper(s):")
        for w in skip_warnings[:20]:
            print(f"   - {w}")
        if len(skip_warnings) > 20:
            print(f"   - ...and {len(skip_warnings) - 20} more")
        print()

    qp_papers = qp_keep
    ms_papers = ms_keep

    if not qp_papers:
        out_root = Path(config.output_dir)
        note = (f"No recognised Cambridge question papers found in '{input_dir}'. "
                "Please upload PDFs and re-run.")
        print("!!", note)
        log = build_log(papers_processed=[], missing_papers=unrecognized + skip_warnings,
                        questions_processed=0, duplicates_removed=0,
                        topics_created=[], manual_review=unrecognized + skip_warnings,
                        questions_per_topic={})
        write_log(out_root / "Processing_Log.json", log)
        return {"subject": None, "level": None, "syllabus": None,
                "questions": 0, "unique": 0, "duplicates_removed": 0,
                "topics_created": [], "output_dir": str(out_root), "log": log}

    subject, level, syllabus, board = _majority_identity(papers)
    if config.syllabus_code:
        syllabus = config.syllabus_code
        subject = detect_subject(syllabus)
        level = detect_level(syllabus)
    if config.subject:
        subject = config.subject
    if config.level:
        level = config.level

    print(f" Detected       : {subject} ({syllabus}) - {level}")
    print(f" Question papers: {len(qp_papers)}    Mark schemes: {len(ms_papers)}")
    print()

    all_questions: List[qs.Question] = []
    papers_processed: List[str] = []
    manual_review: List[str] = []

    # Get the freeconvert.com API key if available
    api_key = getattr(config, "freeconvert_api_key", None)
    use_api = bool(api_key)

    for p in qp_papers:
        questions, confident = qs.split_questions(
            p.path, dpi=config.dpi, paper_code=p.paper_code,
            use_api=use_api, api_key=api_key, cfg=config,
        )
        for q in questions:
            q.session_label = p.session_label
            q.year = p.year
            if not confident:
                q.needs_review = True
        all_questions.extend(questions)
        papers_processed.append(p.path)
        if not confident:
            manual_review.append(f"LOW_CONFIDENCE_SPLIT:{Path(p.path).name}")

    # Mark schemes
    ms_index: Dict[tuple, object] = {}
    ms_diagnostics: List[dict] = []
    if config.include_mark_schemes and ms_papers:
        print(f"[mark-schemes] Processing {len(ms_papers)} mark scheme PDF(s)...")
        expected_ms_questions: Dict[tuple, set] = {}
        for question in all_questions:
            code = str(question.paper_code or "").lstrip("0") or str(question.paper_code)
            try:
                number = int(question.question_number)
            except (TypeError, ValueError):
                continue
            identity = (code, question.session_label, int(question.year or 0))
            expected_ms_questions.setdefault(identity, set()).add(number)

        ms_index = process_mark_schemes(
            [Path(p.path) for p in ms_papers],
            qp_paper_codes=[p.paper_code for p in qp_papers],
            dpi=config.dpi,
            syllabus=syllabus,
            expected_questions=expected_ms_questions,
            diagnostics_out=ms_diagnostics,
        )
        for diagnostic in ms_diagnostics:
            unsafe = bool(diagnostic.get("unsafe_boundaries"))
            if diagnostic.get("warnings") or unsafe:
                manual_review.append(
                    "MARK_SCHEME_REVIEW:"
                    f"{diagnostic.get('file')}"
                    f":missing={diagnostic.get('missing', [])}"
                    f":unexpected={diagnostic.get('unexpected', [])}"
                    f":unsafe_boundary={unsafe}"
                )
        ms_img_count = sum(1 for v in ms_index.values() if isinstance(v, Image.Image))
        ms_txt_count = sum(1 for v in ms_index.values() if isinstance(v, str))
        print(f"[mark-schemes] Found {ms_img_count} MS images and {ms_txt_count} MCQ answers")
        for p in ms_papers:
            papers_processed.append(p.path)

    # Missing mark schemes
    missing: List[str] = []
    qp_codes = {p.paper_code for p in qp_papers}
    ms_codes = {p.paper_code for p in ms_papers}
    for code in sorted(qp_codes - ms_codes):
        missing.append(f"mark_scheme_missing:paper_{code}")

    # Deduplicate
    deduplicate(all_questions, hamming=config.dedup_hamming)
    duplicates_removed = sum(1 for q in all_questions if q.is_duplicate)

    # Debug: show dedup info for verification
    from .dedup import _clean_text_for_dedup, SIMILARITY_THRESHOLD
    if all_questions:
        print(f"\n[dedup] Similarity threshold: {SIMILARITY_THRESHOLD:.2f}")

    # Topics - Load topics
    topics_path = config.topics_json
    topics_source_desc = None
    if topics_path:
        topics_source_desc = f"explicit --topics: {topics_path}"
    elif config.syllabus_pdf:
        topics_source_desc = f"explicit --syllabus: {config.syllabus_pdf}"
    else:
        auto = resolve_topics_file(syllabus)
        if auto is not None:
            topics_path = str(auto)
            topics_source_desc = f"auto-detected built-in topics: {auto.name} (syllabus {syllabus})"

    if topics_source_desc:
        print(f"[topics] Using {topics_source_desc}")
    else:
        print(f"[topics] WARNING: no topic map found for syllabus {syllabus}.")

    # Load topics
    if ENHANCED_CLASSIFIER_AVAILABLE:
        from .topics_enhanced import load_topics as load_topics_enhanced
        topics = load_topics_enhanced(topics_path, config.syllabus_pdf)
    else:
        from .topics import load_topics
        topics = load_topics(topics_path, config.syllabus_pdf)
    
    print(f"[topics] Loaded {len(topics)} topics")

    # Filter out blank/duplicate questions before topic assignment
    non_blank_questions = [q for q in all_questions if not q.is_duplicate and q.images]
    print(f"\n[topics] Assigning topics to {len(non_blank_questions)} questions...")

    # Get corrections path if configured
    corrections_path = getattr(config, "corrections_path", None)
    
    # Use enhanced classifier if available
    if ENHANCED_CLASSIFIER_AVAILABLE:
        print("[topics] Using ENHANCED multi-topic classifier")
        
        # Initialize correction tracker
        correction_tracker = None
        if corrections_path:
            correction_tracker = CorrectionTracker(corrections_path)
            correction_tracker.load()
            if correction_tracker.stats.total_corrections > 0:
                print(f"[topics] Loaded {correction_tracker.stats.total_corrections} corrections")
        
        # Create classifier and assign topics
        classifier = MultiTopicClassifier(topics, corrections_path)
        classifier.assign_topics(non_blank_questions)
        
        # Count corrections applied
        corrections_applied = 0
        if correction_tracker:
            for q in non_blank_questions:
                if correction_tracker.has_correction(q.qid):
                    corrections_applied += 1
        if corrections_applied > 0:
            print(f"[topics] Applied {corrections_applied} known corrections")
    else:
        print("[topics] Using standard single-topic classifier")
        assign_topics(non_blank_questions, topics)

    # Log topic assignment stats
    topic_counts = Counter()
    multi_topic_count = 0
    
    for q in non_blank_questions:
        topics_list = q.topic if q.topic else ["Uncategorized"]
        topic_counts[topics_list[0]] += 1
        
        # Check for multi-topic
        if hasattr(q, '_multi_topic_result') and q._multi_topic_result:
            if len(q._multi_topic_result.all_topics) > 1:
                multi_topic_count += 1
    
    print("\n[topics] Topic assignment results:")
    for topic, count in sorted(topic_counts.items()):
        print(f"  {topic}: {count} questions")
    
    if multi_topic_count > 0:
        print(f"\n[topics] Multi-topic questions: {multi_topic_count} "
              f"({100*multi_topic_count/len(non_blank_questions):.1f}%)")

    # Attach mark schemes
    for q in all_questions:
        if not hasattr(q, 'ms_entry') or q.ms_entry is None:
            q.ms_entry = lookup_mark_scheme(
                ms_index,
                paper_code=q.paper_code,
                question_number=q.question_number,
                session_label=q.session_label,
                year=q.year,
            )
        if q.ms_entry is None and not q.is_duplicate:
            manual_review.append(
                f"MARK_SCHEME_MISSING:{q.paper_code}_{q.session_label}_{q.year}_Q{q.question_number}"
            )

    # Organize - into major topic folders with single-folder question distribution
    cross_folder_enabled = getattr(config, "cross_folder_enabled", False)
    has_mark_schemes = bool(config.include_mark_schemes and ms_papers)
    print(f"\n[organize] Single-folder major topic distribution: ENABLED")
    
    written = organize(
        all_questions, ms_index, output_dir=config.output_dir,
        subject=subject, level=level, board=board, syllabus_code=syllabus,
        webp_quality=config.webp_quality,
        require_mark_scheme=has_mark_schemes,
        cross_folder_enabled=cross_folder_enabled,
    )

    # Output validation & automatic healing (Sections 21-25)
    from .output_validator import validate_and_heal_output
    print("\n[validate] Running end-to-end output validation & empty folder check...")
    val_ok, val_issues = validate_and_heal_output(
        config.output_dir, all_questions, subject=subject,
        syllabus_code=syllabus, webp_quality=config.webp_quality,
    )
    if val_ok:
        print("[validate] Output validation PASSED: 100% of major-topic folders populated with valid question crops & strict JSON metadata")
    else:
        print(f"[validate] Auto-healed {len(val_issues)} issue(s) during validation check")

    # Check mark scheme coverage
    _out_root = Path(config.output_dir)
    ms_files = list(_out_root.rglob("*_MS.webp")) + list(_out_root.rglob("*_MS.txt"))
    ms_coverage = len(ms_files)
    print(f"\n[mark-schemes] {ms_coverage} mark scheme files written to disk")

    # Collect review items
    for q in all_questions:
        if q.needs_review and not q.is_duplicate:
            review_entry = f"{q.paper_code}_{q.session_label}_{q.year}_Q{q.question_number}"
            
            # Add detailed review reasons if available
            if hasattr(q, '_multi_topic_result') and q._multi_topic_result:
                reasons = q._multi_topic_result.review_reasons
                if reasons:
                    review_entry += f": {'; '.join(reasons[:3])}"
            
            manual_review.append(review_entry)

    questions_processed = len(all_questions)
    topics_created = sorted(set(
        t for q in non_blank_questions 
        for t in (q.topic if q.topic else ["Uncategorized"])
    ))

    # Build enhanced log
    log = build_log(
        papers_processed=papers_processed,
        missing_papers=missing + unrecognized + skip_warnings,
        questions_processed=questions_processed,
        duplicates_removed=duplicates_removed,
        topics_created=topics_created,
        manual_review=manual_review,
        questions_per_topic=dict(topic_counts),
    )
    
    # Add enhanced statistics to log
    if ENHANCED_CLASSIFIER_AVAILABLE:
        log["enhancements"] = {
            "multi_topic_enabled": True,
            "multi_topic_questions": multi_topic_count,
            "multi_topic_percentage": round(100 * multi_topic_count / len(non_blank_questions), 2) if non_blank_questions else 0,
            "corrections_applied": corrections_applied if 'corrections_applied' in dir() else 0,
            "cross_folder_enabled": cross_folder_enabled,
        }
    
    out_root = Path(config.output_dir)
    write_log(out_root / "Processing_Log.json", log)
    (out_root / "Mark_Scheme_Diagnostics.json").write_text(
        json.dumps(ms_diagnostics, indent=2, ensure_ascii=False), encoding="utf-8")
    (out_root / "inventory.json").write_text(
        json.dumps(written, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "subject": subject, "level": level, "syllabus": syllabus,
        "questions": questions_processed, "unique": len(written),
        "duplicates_removed": duplicates_removed,
        "topics_created": topics_created,
        "output_dir": str(out_root), "log": log,
    }
