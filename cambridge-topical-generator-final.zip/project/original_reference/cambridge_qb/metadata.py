"""
metadata.py
===========
Strict metadata generation conforming to Cambridge Topical Question Bank specification.

Requirements Enforced:
  1. STRICT JSON FORMAT:
     - No "topic_details" object.
     - No "primary", "secondary", or "needs_review" in JSON.
     - Topic information exists ONLY in the "topic" array.
     - Array contains all topics that the question genuinely tests.
  2. STRICT CANONICAL FIELDS:
     - id, level, subject, board, topic, paper, question_number, variant, season, year.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Union

from .question_split import Question
from .reference import canonical_season

# Strict canonical metadata fields (in exact required order)
_META_FIELDS = [
    "id", "level", "subject", "board", "topic",
    "paper", "question_number", "variant", "season", "year",
]

# Season label -> single letter used inside the "paper" id (e.g. m26).
_SEASON_LETTER = {"Summer": "s", "Winter": "w", "Spring": "m", "Specimen": "z"}


def _criteria_subject(subject: str, syllabus_code: str) -> str:
    base = subject.removesuffix("_IGCSE").removesuffix("_O_Level").removesuffix("_A_Level")
    return f"{base}_{syllabus_code}"


def compute_topic_field(q: Question, max_topics: int = 4) -> List[str]:
    """
    Compute the canonical `topic` array containing at most 4 topics with the highest point scores.
    Uses the internal scoring system to sort topics and strictly caps at the top 4.
    """
    # 1. Enhanced multi-topic result with confidence/point scores
    mr = getattr(q, "_multi_topic_result", None)
    if mr:
        if hasattr(mr, "confidence_scores") and mr.confidence_scores:
            ranked = sorted(
                [(t, score) for t, score in mr.confidence_scores.items() if t and t != "Uncategorized"],
                key=lambda kv: kv[1],
                reverse=True,
            )
            if ranked:
                return [t for t, _ in ranked[:max_topics]]
        if hasattr(mr, "all_topics") and mr.all_topics:
            topics = [t for t in mr.all_topics if t and t != "Uncategorized"]
            if topics:
                return topics[:max_topics]

    # 2. Score-based fallback from topic_scores
    scores = {}
    if getattr(q, "topic_scores", None):
        scores = dict(q.topic_scores)
    elif getattr(q, "_topic_scores", None):
        scores = {name: score for name, score, *_ in q._topic_scores}

    if scores:
        ranked = sorted(
            [(t, score) for t, score in scores.items() if t and t != "Uncategorized"],
            key=lambda kv: kv[1],
            reverse=True,
        )
        if ranked:
            return [t for t, _ in ranked[:max_topics]]

    # 3. Existing topic list on Question
    if getattr(q, "topic", None):
        if isinstance(q.topic, list):
            topics = [t for t in q.topic if t and t != "Uncategorized"]
            if topics:
                return topics[:max_topics]
        elif isinstance(q.topic, str) and q.topic != "Uncategorized":
            return [q.topic]

    return ["Uncategorized"]


def primary_topic(q: Question) -> str:
    """Return the primary topic name for a question."""
    topics = compute_topic_field(q)
    return topics[0] if topics else "Uncategorized"


def secondary_topics(q: Question) -> List[str]:
    """Return the secondary topics for a question."""
    topics = compute_topic_field(q)
    return topics[1:] if len(topics) > 1 else []


def build_metadata(
    q: Question,
    *,
    subject: str,
    level: str,
    board: str,
    syllabus_code: str,
) -> dict:
    """
    Build strict metadata dictionary containing ONLY the required fields:
      id, level, subject, board, topic (array), paper, question_number, variant, season, year.
    """
    if not q.qid:
        q.qid = str(uuid.uuid4())

    session_label = canonical_season(q.session_label or "Unknown")
    year = int(q.year or 0)
    year2 = f"{year % 100:02d}"
    letter = _SEASON_LETTER.get(session_label, "s")
    paper_code = (str(q.paper_code or "").lstrip("0") or str(q.paper_code or ""))
    paper = f"{syllabus_code}_{letter}{year2}_qp_{paper_code}"

    # Strict metadata dictionary (NO topic_details, NO primary/secondary fields)
    meta = {
        "id": q.qid,
        "level": level,
        "subject": _criteria_subject(subject, syllabus_code),
        "board": board,
        "topic": compute_topic_field(q),
        "paper": paper,
        "question_number": f"Q{q.question_number}",
        "variant": paper_code,
        "season": session_label,
        "year": str(year),
    }

    return meta


def write_metadata(path: str | Path, meta: dict) -> None:
    """
    Write strict metadata JSON to disk.
    Strictly excludes 'topic_details' or any non-standard fields.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    # Strictly preserve the required fields in canonical order
    ordered = {k: meta[k] for k in _META_FIELDS if k in meta}
    p.write_text(json.dumps(ordered, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
