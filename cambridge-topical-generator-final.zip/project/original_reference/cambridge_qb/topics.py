
"""
Syllabus-aware topic classification for Cambridge question papers.

The classifier keeps the Physics system's single-topic, weighted-evidence
philosophy, but adds the controls needed by Computer Science 9618:

* paper-to-section gating (P1: 1-8, P2: 9-12, P3: 13-20, P4: 19-20)
* token-boundary matching (for example, ``RAM`` cannot match ``program``)
* longest-phrase-first matching within each topic
* diminishing returns for repeated terms
* co-occurrence boosts for concept clusters
* soft negative evidence rather than brittle one-word hard exclusions
* whole-question dominance/coverage scoring
* confidence and close-conflict review flags

The existing Physics JSON format remains supported. New fields are optional.
"""

from __future__ import annotations

import json
import math
import re
import unicodedata
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple

from .question_split import Question

WEIGHT_PRIMARY = 12.0
WEIGHT_SECONDARY = 5.0
WEIGHT_TERTIARY = 1.0
MIN_SCORE_THRESHOLD = 3.0
# A precise multi-word syllabus operation can be the only textual evidence in
# a very short calculation question (for example, an instruction to perform a
# named operation). Reward such diagnostic secondary phrases without lowering
# the threshold for generic one-word matches.
DIAGNOSTIC_SECONDARY_BONUS = 3.0

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "into", "their",
    "are", "was", "were", "been", "being", "have", "has", "had", "will",
    "would", "should", "can", "could", "may", "might", "must", "shall",
    "using", "used", "use", "than", "then", "them", "they", "such", "some",
    "other", "these", "those", "which", "what", "when", "where", "who",
    "how", "why", "not", "but", "also", "any", "all", "its", "his", "her",
    "our", "your", "about", "over", "under", "between", "within", "without",
    "during", "before", "after", "above", "below", "both", "each", "more",
    "most", "less", "least", "only", "very", "able", "including", "include",
    "students", "describe", "explain", "understand", "knowledge", "content",
    "notes", "cambridge", "international", "candidates",
}

_HEADING = re.compile(
    r"^\s*(\d+(?:\.\d+){0,3})\s+([A-Z][A-Za-z0-9 ,/\-&():]{3,90})$"
)


@dataclass
class BoostRule:
    """A context rule that rewards related evidence appearing together."""

    all_terms: List[str] = field(default_factory=list)
    any_terms: List[str] = field(default_factory=list)
    min_any: int = 1
    score: float = 0.0
    label: str = ""


@dataclass
class Topic:
    name: str
    level: str = ""
    section: str = ""
    allowed_papers: List[int] = field(default_factory=list)
    primary: List[str] = field(default_factory=list)
    secondary: List[str] = field(default_factory=list)
    tertiary: List[str] = field(default_factory=list)
    exclude_if: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    boost_if: List[BoostRule] = field(default_factory=list)
    conflicts_with: List[str] = field(default_factory=list)
    min_score: float = MIN_SCORE_THRESHOLD
    require_anchor: bool = False

    @property
    def all_keywords(self) -> List[Tuple[str, float, str]]:
        """Return distinct terms, most specific/longest first."""
        by_term: Dict[str, Tuple[float, str]] = {}
        for tier, weight, values in (
            ("primary", WEIGHT_PRIMARY, self.primary),
            ("secondary", WEIGHT_SECONDARY, self.secondary),
            ("tertiary", WEIGHT_TERTIARY, self.tertiary),
            ("secondary", WEIGHT_SECONDARY, self.keywords),
        ):
            for value in values:
                term = _normalise(value)
                if not term:
                    continue
                old = by_term.get(term)
                if old is None or weight > old[0]:
                    by_term[term] = (weight, tier)
        out = [(term, wt, tier) for term, (wt, tier) in by_term.items()]
        out.sort(key=lambda item: (_term_token_count(item[0]), len(item[0]), item[1]),
                 reverse=True)
        return out


@dataclass
class TopicEvidence:
    topic: Topic
    raw_score: float = 0.0
    adjusted_score: float = 0.0
    primary_hits: int = 0
    secondary_hits: int = 0
    diagnostic_secondary_hits: int = 0
    tertiary_hits: int = 0
    boost_hits: int = 0
    exclusion_hits: int = 0
    positions: List[int] = field(default_factory=list)
    matched_terms: List[str] = field(default_factory=list)
    dominance: float = 1.0

    @property
    def has_anchor(self) -> bool:
        return (
            self.primary_hits > 0
            or self.diagnostic_secondary_hits > 0
            or self.secondary_hits >= 2
            or self.boost_hits > 0
        )


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def _strip_chapter_number(name: str) -> str:
    """Remove a leading chapter-number prefix such as ``01_`` from a topic name.

    Topic JSON keys are conventionally ``01_Atomic_Structure``; the canonical
    topic name used in folders and metadata should be ``Atomic_Structure`` (no
    chapter number). Only a leading ``<digits>_`` prefix is stripped, so topic
    names that do not start with a chapter number are left unchanged.
    """
    m = re.match(r"^\d+_(.*)$", name, re.DOTALL)
    return m.group(1) if m else name


def _slug(name: str) -> str:
    return _strip_chapter_number(re.sub(r"[^\w]+", "_", name).strip("_"))


def load_topics(topics_json: str | None = None,
                syllabus_pdf: str | None = None) -> List[Topic]:
    if topics_json:
        path = Path(topics_json)
        if path.exists():
            return _parse_topics_json(json.loads(path.read_text(encoding="utf-8")))
    if syllabus_pdf:
        return _topics_from_syllabus(syllabus_pdf)
    return []


def _string_list(value) -> List[str]:
    if not isinstance(value, list):
        return []
    return [_normalise(str(v)) for v in value if str(v).strip()]


def _parse_boost_rules(value) -> List[BoostRule]:
    rules: List[BoostRule] = []
    if not isinstance(value, list):
        return rules
    for raw in value:
        if not isinstance(raw, dict):
            continue
        all_terms = _string_list(raw.get("all", []))
        any_terms = _string_list(raw.get("any", []))
        min_any = int(raw.get("min_any", 1) or 1)
        score = float(raw.get("score", 0.0) or 0.0)
        if score <= 0 or (not all_terms and not any_terms):
            continue
        rules.append(BoostRule(
            all_terms=all_terms,
            any_terms=any_terms,
            min_any=max(1, min_any),
            score=score,
            label=str(raw.get("label", "")),
        ))
    return rules


def _parse_topics_json(data: dict) -> List[Topic]:
    topics: List[Topic] = []
    for name, val in data.items():
        slug = _slug(name)
        if isinstance(val, list):
            topics.append(Topic(name=slug, keywords=_string_list(val)))
            continue
        if not isinstance(val, dict):
            continue
        allowed = []
        for p in val.get("allowed_papers", val.get("papers", [])) or []:
            try:
                allowed.append(int(p))
            except (TypeError, ValueError):
                pass
        topics.append(Topic(
            name=slug,
            level=str(val.get("level", "")),
            section=str(val.get("section", "")),
            allowed_papers=sorted(set(allowed)),
            primary=_string_list(val.get("primary", [])),
            secondary=_string_list(val.get("secondary", [])),
            tertiary=_string_list(val.get("tertiary", [])),
            exclude_if=_string_list(val.get("exclude_if", [])),
            keywords=_string_list(val.get("keywords", [])),
            boost_if=_parse_boost_rules(val.get("boost_if", [])),
            conflicts_with=[_slug(str(v)) for v in val.get("conflicts_with", [])],
            min_score=float(val.get("min_score", MIN_SCORE_THRESHOLD)),
            require_anchor=bool(val.get("require_anchor", False)),
        ))
    return topics


def _topics_from_syllabus(pdf_path: str | Path) -> List[Topic]:
    # Lazy import keeps classification tests independent of the PDF renderer.
    import fitz

    doc = fitz.open(str(pdf_path))
    topics: List[Topic] = []
    seen: set = set()
    try:
        for page in doc:
            for line in page.get_text("text").splitlines():
                match = _HEADING.match(line.strip())
                if not match:
                    continue
                section, title = match.group(1), match.group(2).strip()
                slug = _slug(title)
                if slug in seen or len(slug) < 3:
                    continue
                seen.add(slug)
                kws = [w.lower() for w in re.findall(r"[A-Za-z]{4,}", title)
                       if w.lower() not in STOPWORDS]
                topics.append(Topic(name=slug, section=section, secondary=kws))
    finally:
        doc.close()
    return topics


# ---------------------------------------------------------------------------
# Normalisation and boundary-safe matching
# ---------------------------------------------------------------------------
def _normalise(text: str) -> str:
    value = unicodedata.normalize("NFKC", text or "").lower()
    value = value.replace("’", "'").replace("‘", "'")
    value = value.replace("–", "-").replace("—", "-").replace("−", "-")
    return re.sub(r"\s+", " ", value).strip()


def _term_token_count(term: str) -> int:
    return len(re.findall(r"[a-z0-9]+", term))


@lru_cache(maxsize=8192)
def _term_pattern(term: str) -> re.Pattern:
    """Compile a punctuation/whitespace-tolerant whole-token phrase pattern."""
    term = _normalise(term)
    # Preserve the significant star in the named A* search algorithm; treating
    # it as the two tokens "a" and "algorithm" would create broad false hits.
    if term in {"a* algorithm", "a * algorithm"}:
        return re.compile(r"(?<![a-z0-9])a\s*\*\s*algorithm(?![a-z0-9])")
    tokens = re.findall(r"[a-z0-9]+", term)
    if not tokens:
        return re.compile(r"(?!x)x")
    # OCR and PDF extraction vary around hyphens, slashes and line wraps.
    body = r"[^a-z0-9]+".join(re.escape(token) for token in tokens)
    return re.compile(r"(?<![a-z0-9])" + body + r"(?![a-z0-9])")


def _find_term(text: str, term: str) -> List[Tuple[int, int]]:
    return [(m.start(), m.end()) for m in _term_pattern(term).finditer(text)]


def _has_term(text: str, term: str) -> bool:
    return _term_pattern(term).search(text) is not None


def _overlaps(span: Tuple[int, int], consumed: List[Tuple[int, int]]) -> bool:
    start, end = span
    return any(start < old_end and end > old_start for old_start, old_end in consumed)


# ---------------------------------------------------------------------------
# Paper gating
# ---------------------------------------------------------------------------
def paper_number_from_code(paper_code: str) -> int:
    code = str(paper_code or "").lstrip("0")
    if not code or not code[0].isdigit():
        return 0
    return int(code[0])


def paper_level_from_code(paper_code: str) -> str:
    """Legacy AS/A2 gating retained for Physics and older maps."""
    paper = paper_number_from_code(paper_code)
    if paper in (1, 2, 3):
        return "AS"
    if paper in (4, 5):
        return "A2"
    return ""


def _topic_allowed(topic: Topic, paper_code: str) -> bool:
    paper = paper_number_from_code(paper_code)
    if topic.allowed_papers:
        return paper in topic.allowed_papers
    # Old Physics maps have level but no explicit paper list.
    level = paper_level_from_code(paper_code)
    if level and topic.level:
        return level.upper() == topic.level.upper()
    return True


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------
def _specificity_multiplier(term: str, tier: str) -> float:
    if tier == "tertiary":
        return 1.0
    words = _term_token_count(term)
    return 1.0 + min(0.32, max(0, words - 1) * 0.08)


def _score_topic(topic: Topic, text: str) -> TopicEvidence:
    evidence = TopicEvidence(topic=topic)
    consumed: List[Tuple[int, int]] = []
    tertiary_points = 0.0

    for term, weight, tier in topic.all_keywords:
        usable = []
        for span in _find_term(text, term):
            if not _overlaps(span, consumed):
                usable.append(span)
        if not usable:
            continue

        # One repeated generic word must not overwhelm several distinct anchors.
        multipliers = (1.0, 0.35, 0.15)
        points = 0.0
        for index, span in enumerate(usable[:3]):
            points += weight * multipliers[index] * _specificity_multiplier(term, tier)
            consumed.append(span)
            evidence.positions.append(span[0])
        evidence.matched_terms.append(term)

        if tier == "primary":
            evidence.primary_hits += 1
            evidence.raw_score += points
        elif tier == "secondary":
            evidence.secondary_hits += 1
            evidence.raw_score += points
            # Short exam prompts frequently contain one exact, named syllabus
            # operation and little surrounding prose. A multi-token secondary
            # phrase is substantially safer than a generic isolated word and
            # is allowed to act as a standalone anchor.
            if _term_token_count(term) >= 2:
                evidence.diagnostic_secondary_hits += 1
                evidence.raw_score += DIAGNOSTIC_SECONDARY_BONUS
        else:
            evidence.tertiary_hits += 1
            tertiary_points += points

    # Tertiary words are weak corroboration. Without stronger context they are
    # capped, so isolated terms such as "file", "memory" or "data" cannot win.
    if evidence.primary_hits or evidence.secondary_hits >= 2:
        evidence.raw_score += min(4.0, tertiary_points)
    else:
        evidence.raw_score += min(1.5, tertiary_points)

    for rule in topic.boost_if:
        all_ok = all(_has_term(text, term) for term in rule.all_terms)
        any_count = sum(1 for term in rule.any_terms if _has_term(text, term))
        any_ok = (not rule.any_terms) or any_count >= rule.min_any
        if all_ok and any_ok:
            evidence.raw_score += rule.score
            evidence.boost_hits += 1

    evidence.exclusion_hits = sum(
        1 for term in topic.exclude_if if _has_term(text, term)
    )
    score = evidence.raw_score
    if evidence.exclusion_hits:
        # Strong positive anchors survive a mixed-topic question; weak matches
        # against several contrary anchors are suppressed aggressively.
        if evidence.primary_hits == 0 and evidence.secondary_hits <= 1:
            score *= max(0.08, 0.45 ** evidence.exclusion_hits)
        else:
            score *= max(0.40, 1.0 - 0.12 * evidence.exclusion_hits)

    evidence.dominance = _dominance_factor(text, evidence.positions)
    evidence.adjusted_score = score * evidence.dominance
    return evidence


def _dominance_factor(text: str, positions: List[int]) -> float:
    """Reward evidence distributed through the question, not one stray phrase."""
    if not text or not positions:
        return 0.90
    n_bins = max(1, min(4, int(math.ceil(len(text) / 450.0))))
    bins = {
        min(n_bins - 1, int((pos / max(1, len(text))) * n_bins))
        for pos in positions
    }
    coverage = len(bins) / n_bins
    spread = 0.0
    if len(positions) > 1:
        spread = (max(positions) - min(positions)) / max(1, len(text))
    return max(0.85, min(1.25, 0.88 + 0.24 * coverage + 0.12 * spread))


def _rank_key(evidence: TopicEvidence) -> Tuple[float, int, int, int]:
    return (
        evidence.adjusted_score,
        evidence.primary_hits,
        evidence.boost_hits,
        evidence.secondary_hits,
    )


def _confidence(best: TopicEvidence, second: Optional[TopicEvidence]) -> float:
    if second is None or second.adjusted_score <= 0:
        return 1.0
    total = best.adjusted_score + second.adjusted_score
    return best.adjusted_score / total if total else 0.0


# ---------------------------------------------------------------------------
# Assignment
# ---------------------------------------------------------------------------
def assign_topics(questions: List[Question], topics: List[Topic]) -> None:
    """Assign exactly one dominant topic to each question."""
    if not topics:
        for question in questions:
            question.topic = ["Uncategorized"]
            question.needs_review = True
            question.topic_confidence = 0.0
        return

    for question in questions:
        text = _normalise(question.text)
        if not text:
            question.topic = ["Uncategorized"]
            question.needs_review = True
            question.topic_confidence = 0.0
            continue

        scored: List[TopicEvidence] = []
        for topic in topics:
            if not _topic_allowed(topic, question.paper_code):
                continue
            evidence = _score_topic(topic, text)
            if topic.require_anchor and not evidence.has_anchor:
                evidence.adjusted_score = 0.0
            scored.append(evidence)

        scored.sort(key=_rank_key, reverse=True)
        positive = [ev for ev in scored if ev.adjusted_score > 0]
        best = positive[0] if positive else None
        second = positive[1] if len(positive) > 1 else None

        if best is None or best.adjusted_score < best.topic.min_score:
            question.topic = ["Uncategorized"]
            question.needs_review = True
            question.topic_confidence = 0.0
        else:
            question.topic = [best.topic.name]
            conf = _confidence(best, second)
            question.topic_confidence = round(conf, 4)

            # A close result is retained as the best topic, but explicitly
            # surfaced for review instead of silently pretending certainty.
            if second is not None:
                margin = best.adjusted_score - second.adjusted_score
                conflict = (
                    second.topic.name in best.topic.conflicts_with
                    or best.topic.name in second.topic.conflicts_with
                )
                if conf < 0.56 or margin < max(3.0, best.adjusted_score * 0.12):
                    question.needs_review = True
                if conflict and conf < 0.62:
                    question.needs_review = True

        question.topic_scores = {
            ev.topic.name: round(ev.adjusted_score, 3)
            for ev in positive
        }
        # Preserve the tuple shape consumed by organize.py.
        question._topic_scores = [
            (ev.topic.name, round(ev.adjusted_score, 3),
             ev.primary_hits, ev.secondary_hits)
            for ev in positive
        ]
        question._topic_evidence = [
            {
                "topic": ev.topic.name,
                "score": round(ev.adjusted_score, 3),
                "primary": ev.primary_hits,
                "secondary": ev.secondary_hits,
                "diagnostic_secondary": ev.diagnostic_secondary_hits,
                "boosts": ev.boost_hits,
                "negative": ev.exclusion_hits,
                "dominance": round(ev.dominance, 3),
                "terms": ev.matched_terms[:12],
            }
            for ev in positive[:5]
        ]
