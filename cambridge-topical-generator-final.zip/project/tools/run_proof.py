#!/usr/bin/env python3
"""run_proof.py — generate the single-file proof pack `proof_report.html`.

WHAT THIS IS
------------
A self-contained (inline CSS, zero external assets, zero JS) HTML report that
proves the state of the Cambridge Topical Question Bank Generator at the
moment it was generated: pipeline stages, live lock-ledger verification,
the RULE-6/triplet/multipage invariants recomputed from disk, the unittest
masthead (optional, live), the sha256-pinned fixture inventory WITH AGES
DISCLOSED, the deliverable zip status, and an honest limitations section.
Every number in the report is computed FROM DISK at build time — nothing is
hand-pasted, so a stale claim cannot silently survive a code change.

CLI:
  python3 tools/run_proof.py [--output PATH] [--suite] [--no-suite]
                             [--suite-modules tests.test_a tests.test_b ...]
                             [--stamp-now] [--check]

  --output     default <repo>/proof_report.html
  --suite      run the unittest masthead live and tabulate it (default ON;
               tests.test_proof_report is EXCLUDED from the default masthead
               so the suite can never recursively invoke this tool)
  --suite-modules  override the masthead list (used by the tool's own tests)
  --stamp-now  embed a UTC generation timestamp (default OFF so the report is
               byte-deterministic — pinned by tests)
  --check      exit 1 when any live check fails (ledger / invariants / suite)

Sources of truth (all read live):
  - run_guarded.py ALL_STAGES ............... stage names S0..S8
  - the 5 lock docs .......................... ledger table rows
  - tools/fixture_manifest.json ............. fixture names/roles/sha/bytes
  - /home/user/cambridge-topical-generator-final.zip (if present)
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import subprocess
import sys
import time
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
DELIVERABLE = REPO.parent / "cambridge-topical-generator-final.zip"

LOCK_DOCS = ["CROPPING_LOCK.md", "ROUTING_STATE_LOCK.md", "CLASSIFICATION_LOCK.md",
             "EXAMINER_REPORT_LOCK.md", "EFFICIENCY_AUDIT.md"]
LEDGER_PREFIXES = ("core/", "main.py", "run_guarded.py", "run_pipeline.py", "pipeline.py",
                   "tools/", "tests/", "engine/", "profiles/", "parsers/", "original_reference/")

MASTHEAD = [
    "tests.test_igcse_formats", "tests.test_batch_infra", "tests.test_batch_manifest",
    "tests.test_ms_fetcher", "tests.test_mcq_unified", "tests.test_page_classifier",
    "tests.test_state_mirror", "tests.test_letterless_mcq_routing",
    "tests.test_quarantine_tool", "tests.test_rotation_handling",
    "tests.test_proof_report",
    # RS-16/17/18 (2026-08-12): subject coverage, official-topic taxonomy,
    # strategy registry + spec build-out pins.
    "tests.test_math_taxonomy_rs17", "tests.test_rs16_subject_coverage",
    "tests.test_spec_buildout_rs18",
    # Recursion note: tests.test_proof_report only ever invokes this tool with
    # --no-suite or a narrow --suite-modules override (never the full default
    # masthead), so the suite can never recursively measure itself.
]

TRIPLET = ["core/question_split.py", "core/cropping_engine_reference.py",
           "original_reference/cambridge_qb/question_split.py"]
MULTIPAGE = ["core/multipage_optimizer.py", "core/multipage_optimizer_reference.py"]
RULE6 = {"core/ms_cropping_engine.py": "b69285ee", "core/converter.py": "d8bf74d8"}
CHEM_GOLD = "original_reference/cambridge_qb/chemistry_reference.py"

ERA_NOTE = ("9701 / 0620 / 9709 / 0580 remote sets are 2015–2016 Cambridge-authored papers "
            "(Cambridge's layout grammar is stable across eras, which is why these pin the "
            "locked splitters); 9618 material is 2023-era; uploads (…/_m25_/w25) are genuine "
            "2025 papers supplied directly by the maintainer.")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_ledger():
    """Re-parse every lock doc; LATEST row per path must equal disk."""
    row_re = re.compile(r"^\| `([^`]+)` \| `?([0-9a-f]{64})`?", re.M)
    latest, rows, per_doc = {}, 0, {}
    for doc in LOCK_DOCS:
        text = (REPO / doc).read_text(encoding="utf-8")
        found = [(p, h) for p, h in row_re.findall(text) if p.startswith(LEDGER_PREFIXES)]
        per_doc[doc] = len(found)
        rows += len(found)
        for p, h in found:
            latest[p] = (h, doc)
    bad = [(p, d) for p, (h, d) in latest.items()
           if not (REPO / p).exists() or sha256(REPO / p) != h]
    return latest, rows, per_doc, bad


def check_invariants():
    out = []
    th = {sha256(REPO / f) for f in TRIPLET}
    out.append(("locked triplet identical ×3 "
                "(core/question_split.py = cropping_engine_reference.py = original_reference)",
                len(th) == 1, f"{next(iter(th))[:12]}…"))
    mh = {sha256(REPO / f) for f in MULTIPAGE}
    out.append(("multipage pair identical ×2", len(mh) == 1 and next(iter(mh)).startswith("c384248b"),
                f"{next(iter(mh))[:12]}…"))
    for f, want in RULE6.items():
        got = sha256(REPO / f)
        out.append((f"RULE-6 pristine: {f}", got.startswith(want), f"{got[:12]}… (pin {want}…)"))
    got = sha256(REPO / CHEM_GOLD)
    out.append(("gold chemistry_reference.py pristine (RS-12 pin)", got.startswith("829b8fe8"),
                f"{got[:12]}…"))
    return out


def run_suite(modules):
    rows = []
    for mod in modules:
        t0 = time.time()
        proc = subprocess.run([sys.executable, "-m", "unittest", mod],
                              cwd=str(REPO), capture_output=True, text=True, timeout=900)
        dt = time.time() - t0
        tail = proc.stderr or proc.stdout
        ran = re.search(r"Ran (\d+) tests?", tail)
        skipped = re.search(r"skipped=(\d+)", tail)
        ok = "OK" in tail and proc.returncode == 0
        rows.append({
            "module": mod,
            "tests": int(ran.group(1)) if ran else -1,
            "skipped": int(skipped.group(1)) if skipped else 0,
            "ok": ok, "seconds": dt,
        })
    return rows


def fixture_rows():
    man = json.loads((REPO / "tools" / "fixture_manifest.json").read_text(encoding="utf-8"))
    rows = []
    for section in ("fixtures", "local"):
        for entry in man.get(section, []):
            name = Path(entry["file"]).name
            m = re.search(r"_([smw])(\d{2})[_\.]", name)
            era = f"20{m.group(2)}" if m else "—"
            disk = REPO.parent / "test-crops" / "fixtures" / entry["file"]
            present = disk.exists()
            digest = sha256(disk)[:16] if present else "(absent — re-downloadable)"
            pin_ok = present and sha256(disk) == entry.get("sha256")
            rows.append({"name": name, "roles": ", ".join(entry.get("roles", [])),
                         "era": era, "bytes": entry.get("bytes", "—"),
                         "sha": digest, "pin_ok": pin_ok if present else None})
    return rows


def zip_stats():
    if not DELIVERABLE.exists():
        return None
    with zipfile.ZipFile(DELIVERABLE) as z:
        names = z.namelist()
    return {"entries": len(names), "bytes": DELIVERABLE.stat().st_size,
            "sha": sha256(DELIVERABLE)[:16]}


def stage_rows():
    sys.path.insert(0, str(REPO))
    import run_guarded
    return list(run_guarded.ALL_STAGES)


LIMITATIONS = [
    ERA_NOTE,
    "Rotation handling (RS-14): Cambridge-style /Rotate pages are handled natively; "
    "home-rotated pages are normalized by clearing the hint only when word-geometry "
    "votes overwhelmingly sideways. Pages with mixed evidence (e.g. a Periodic-Table "
    "sheet with designed-rotated labels) are deliberately passed through — the page "
    "classifier already removes them. Pure-raster sideways scans (no text layer) "
    "abstain to the downstream QC fail-close.",
    "Two unittest tiers are opt-in heavy proofs (set BATCH_HEAVY=1): batch "
    "infrastructure E2E and the rotated-input byte-oracle E2E. They are excluded from "
    "the default masthead but are run and receipted at every lock round.",
    "MCQ mark schemes carry no crop-able structure: letters ride in metadata.json "
    "(ms_answer) + _MS.txt by design (RS-11/CLS-6); structured MS crop only.",
    "Letterless MCQ questions classify and route normally, keeping every loud "
    "surface (empty _MS.txt, missing ms_answer, audit error, paper NOT complete) "
    "(RS-13/CLS-7).",
    "Crop boundaries, render DPI and WebP quality are LOCKED (triplet 00cc779e… ×3, "
    "multipage c384248b… ×2, b69285ee…, d8bf74d8…); this report recomputes every pin "
    "from disk at build time.",
    "State dual-write: .pipeline_state.json remains the sole authority; the SQLite "
    "mirror (core/state_mirror.py) is advisory-only in phase 1 (RS-13). Phase-2 "
    "cutover awaits maintainer blessing after real-usage drift-freedom.",
]

REPRODUCE = """\
pip install PyMuPDF==1.24.14 pillow numpy opencv-python-headless imagehash PyWavelets scipy reportlab tqdm psutil requests
python3 tools/download_fixtures.py            # sha256-pinned fixture corpus
python3 -m unittest tests.test_igcse_formats tests.test_batch_infra tests.test_batch_manifest \
  tests.test_ms_fetcher tests.test_mcq_unified tests.test_page_classifier \
  tests.test_state_mirror tests.test_letterless_mcq_routing tests.test_quarantine_tool \
  tests.test_rotation_handling tests.test_proof_report
BATCH_HEAVY=1 python3 -m unittest tests.test_batch_infra tests.test_rotation_handling   # heavy oracles
python3 run_guarded.py --input <papers_dir> --output <out> --clean --low-ram
python3 tools/run_proof.py --check            # regenerate + verify this report"""


CSS = """
body{font:14px/1.5 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;color:#1a1f2b;background:#f6f7f9}
header{padding:28px 34px;background:#101828;color:#fff}
h1{font-size:21px;margin:0 0 2px}h2{font-size:16px;margin:30px 0 8px;color:#101828}
.sub{color:#98a2b3;font-size:12.5px}.wrap{max-width:1040px;margin:0 auto;padding:0 22px 60px}
.banner{margin:-18px 34px 0;display:inline-block;padding:8px 16px;border-radius:8px;font-weight:600;font-size:14px}
.pass{background:#067647;color:#fff}.fail{background:#b42318;color:#fff}
table{border-collapse:collapse;width:100%;background:#fff;border:1px solid #e4e7ec;border-radius:8px;overflow:hidden}
th{background:#f2f4f7;text-align:left}td,th{padding:7px 12px;font-size:12.8px;border-bottom:1px solid #eef0f3}
code,pre{font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;background:#f2f4f7;border-radius:5px;padding:1px 5px}
pre{padding:12px;overflow:auto}.ok{color:#067647;font-weight:600}.no{color:#b42318;font-weight:600}
details{margin:8px 0}summary{cursor:pointer;font-weight:600}ul{max-width:880px}
li{margin:5px 0}.card{background:#fff;border:1px solid #e4e7ec;border-radius:10px;padding:16px 18px;margin:10px 0}
"""


def esc(s):
    return html.escape(str(s), quote=True)


def passfail(ok, yes="PASS", no="FAIL"):
    cls = "ok" if ok else "no"
    return f"<td class='{cls}'>{yes if ok else no}</td>"


TARGET_PROFILES = [  # (code, level, representative variant for strategy plan)
    ("0610", "IGCSE", "22"), ("0620", "IGCSE", "22"), ("0625", "IGCSE", "22"),
    ("0580", "IGCSE", "22"), ("9700", "A-Level", "12"), ("9701", "A-Level", "12"),
    ("9702", "A-Level", "12"), ("9709", "A-Level", "12"),
    ("9231", "A-Level", "12"),
]


def coverage_rows():
    """Live per-profile proof row: config presence, era years, major-count,
    fixture presence in the pin manifest, and the registry-selected strategy."""
    import json as _json
    from core.config_loader import load_all_subject_configs
    from core.strategies import strategy_plan_for_paper
    cfg_all = load_all_subject_configs()
    man = _json.loads((REPO / "tools/fixture_manifest.json").read_text(encoding="utf-8"))
    fx_files = {f["file"] for f in man.get("fixtures", [])} | {f["file"] for f in man.get("local", [])}
    rows = []
    for code, level, variant in TARGET_PROFILES:
        cfg = next((c for c in cfg_all.values()
                    if str(getattr(c, "syllabus_code", "")) == code and getattr(c, "level", "") == level), None)
        class _Probe:
            syllabus_code = code
            pass
        probe = _Probe(); probe.variant = variant; probe.paper_format = None
        try:
            plan = strategy_plan_for_paper(probe)
            strat = plan.name
        except Exception as exc:  # pragma: no cover - defensive
            strat = f"unresolved: {exc}"
        has_fx = any(f"{code}_" in f for f in fx_files)
        rows.append({
            "code": code, "level": level,
            "subject": getattr(cfg, "subject", "?") if cfg else "MISSING",
            "years": "/".join(str(y) for y in getattr(cfg, "syllabus_years", []) or []),
            "majors": len(getattr(cfg, "major_topics", []) or []) if cfg else 0,
            "strategy": strat, "fixtures": has_fx,
        })
    return rows


def write_proof_manifest(out_html: Path, checks, stamp_now):
    """Mega-spec deliverable: machine-readable proof manifest next to the HTML.
    Deterministic by default (byte-stable); volatile measurements only with
    --stamp-now."""
    import json as _json
    latest, rows_n, per_doc, bad = verify_ledger()
    man = _json.loads((REPO / "tools/fixture_manifest.json").read_text(encoding="utf-8"))
    fixtures = [
        {"file": f["file"], "url": f.get("url"), "sha256": f.get("sha256"),
         "bytes": f.get("bytes"), "roles": f.get("roles", [])}
        for f in man.get("fixtures", [])
    ] + [
        {"file": f["file"], "url": None, "sha256": f.get("sha256"),
         "bytes": f.get("bytes"), "roles": f.get("roles", [])}
        for f in man.get("local", [])
    ]
    manifest = {
        "schema": "proof_manifest/1 (mega-spec 2026-08-12)",
        "ledger": {"files_verified": len(latest) - len(bad), "files_total": len(latest),
                   "rows": rows_n, "mismatches": [p for p, _d in bad]},
        "checks": [{"label": l, "ok": bool(ok), "detail": d} for l, ok, d in checks],
        "fixtures": fixtures,
        "profiles": coverage_rows(),
        "review_required": {
            "semantics": "fallback_tier=review_required questions land in "
                         "Uncategorized* with REASON.txt; paper-level review states "
                         "are PaperStatus.review_required in .pipeline_state.json",
        },
        "no_loading_dirs_contract": "validator check_no_forbidden_paths fails the "
                                    "run if any output path contains 'loading'",
        "measurements": None,
    }
    if stamp_now:
        import resource
        manifest["built_utc"] = time.strftime("%Y-%m-%d %H:%M:%SZ", time.gmtime())
        manifest["measurements"] = {
            "run_proof_peak_rss_mb": round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1),
        }
    out_dir = REPO / "proof_output"
    out_dir.mkdir(exist_ok=True)
    target = out_dir / "proof_manifest.json"
    target.write_text(_json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
                      encoding="utf-8")
    return target


def build_report(run_masthead, suite_modules, stamp_now):
    checks = []
    latest, rows_n, per_doc, bad = verify_ledger()
    checks.append(("lock ledger: latest rows == on-disk sha256", not bad,
                   f"{len(latest)}/{len(latest)} files verified across {rows_n} rows in 5 docs"))
    invariants = check_invariants()
    checks.extend(invariants)
    suite = run_suite(suite_modules) if run_masthead else None
    if suite:
        checks.append(("unittest masthead", all(r["ok"] for r in suite),
                       f"{sum(r['tests'] for r in suite)} tests, "
                       f"{sum(r['skipped'] for r in suite)} opt-in skips"))
    zi = zip_stats()
    overall = all(ok for _l, ok, _d in checks)

    banner_cls = "pass" if overall else "fail"
    banner_txt = "PASS — all live checks green" if overall else "FAIL — see red rows"
    parts = ["<!DOCTYPE html><html><head><meta charset='utf-8'>",
             "<title>Cambridge Topical Question Bank Generator — Proof Report</title>",
             f"<style>{CSS}</style></head><body>",
             "<header><h1>Cambridge Topical Question Bank Generator — Proof Report</h1>",
             "<div class='sub'>Generated by <code>tools/run_proof.py</code> — every figure "
             "computed live from disk at build time." +
             (f" Built {time.strftime('%Y-%m-%d %H:%M:%SZ', time.gmtime())} (UTC)." if stamp_now
              else " Deterministic build (no timestamp — regenerate for fresh figures).") +
             "</div></header>",
             f"<div class='wrap'><div class='banner {banner_cls}'>{banner_txt}</div>"]

    parts.append("<h2>1 · Pipeline (guarded stages)</h2><div class='card'><table>"
                 "<tr><th>Stage</th><th>Contract</th></tr>")
    for sid, name in stage_rows():
        parts.append(f"<tr><td><code>{esc(sid)}</code></td><td>{esc(name)}</td></tr>")
    parts.append("</table><p><small>A run aborts loudly at the first failed gate; "
                 "nothing half-built is treated as output. Per-paper isolation: worker "
                 "subprocess dies with its peak heap.</small></p></div>")

    parts.append("<h2>2 · Live checks</h2><div class='card'><table>"
                 "<tr><th>Check</th><th>Result</th><th>Detail</th></tr>")
    for label, ok, detail in checks:
        parts.append(f"<tr><td>{esc(label)}</td>{passfail(ok)}"
                     f"<td><code>{esc(detail)}</code></td></tr>")
    parts.append("</table>")
    if bad:
        parts.append("<p class='no'>Ledger mismatches: " +
                     ", ".join(f"{esc(p)} (in {esc(d)})" for p, d in bad) + "</p>")
    parts.append("<details><summary>Full ledger table (path → sha256)</summary><table>"
                 "<tr><th>File</th><th>sha256</th><th>Recorded in</th></tr>")
    for p, (h, d) in sorted(latest.items()):
        parts.append(f"<tr><td><code>{esc(p)}</code></td><td><code>{esc(h[:16])}…</code></td>"
                     f"<td>{esc(d)}</td></tr>")
    parts.append("</table></details>")
    parts.append("<p><small>Rows per doc: " + ", ".join(
        f"<code>{esc(d)}</code> {n}" for d, n in per_doc.items()) + "</small></p></div>")

    parts.append("<h2>3 · Test suite</h2><div class='card'>")
    if suite is None:
        parts.append("<p>Suite not run this pass (<code>--no-suite</code>). Standard masthead: "
                     + ", ".join(f"<code>{esc(m)}</code>" for m in MASTHEAD) + ".</p>")
    else:
        parts.append("<table><tr><th>Module</th><th>Tests</th><th>Skipped (opt-in)</th>"
                     "<th>Result</th><th>Seconds</th></tr>")
        for r in suite:
            parts.append(f"<tr><td><code>{esc(r['module'])}</code></td><td>{r['tests']}</td>"
                         f"<td>{r['skipped']}</td>{passfail(r['ok'], 'OK', 'FAIL')}"
                         f"<td>{r['seconds']:.1f}</td></tr>")
        parts.append(f"</table><p><small>Total {sum(r['tests'] for r in suite)} tests in "
                     f"{sum(r['seconds'] for r in suite):.1f}s. Heavy tiers "
                     f"(<code>BATCH_HEAVY=1</code>) are opt-in oracles, receipted per round.</small></p>")
    parts.append("</div>")

    parts.append("<h2>4 · Fixture corpus (sha256-pinned)</h2><div class='card'>")
    fx = fixture_rows()
    parts.append("<table><tr><th>File</th><th>Roles</th><th>Era</th><th>Bytes</th>"
                 "<th>sha256</th><th>Pin</th></tr>")
    for r in fx:
        pin = "—" if r["pin_ok"] is None else ("<span class='ok'>match</span>" if r["pin_ok"]
                                               else "<span class='no'>MISMATCH</span>")
        parts.append(f"<tr><td><code>{esc(r['name'])}</code></td><td>{esc(r['roles'])}</td>"
                     f"<td>{esc(r['era'])}</td><td>{esc(r['bytes'])}</td>"
                     f"<td><code>{esc(r['sha'])}</code></td><td>{pin}</td></tr>")
    parts.append(f"</table><p><small>{len(fx)} fixtures. {esc(ERA_NOTE)}</small></p></div>")

    parts.append("<h2>5 · Deliverable</h2><div class='card'>")
    if zi:
        parts.append(f"<p><code>{esc(DELIVERABLE.name)}</code> — {zi['entries']} entries, "
                     f"{zi['bytes']:,} bytes, sha256 <code>{esc(zi['sha'])}…</code>. Rebuilt "
                     f"only on maintainer approval; every rebuild is full-readback verified "
                     f"(added-set exact, removed-set empty).</p>")
    else:
        parts.append("<p class='no'>deliverable zip not found next to the repo — report "
                     "generated before a commit?</p>")
    parts.append("</div>")

    cov = coverage_rows()
    parts.append("<h2>6 · Subject coverage &amp; strategies (live)</h2><div class='card'>"
                 "<table><tr><th>Profile</th><th>Era years</th><th>Major topics</th>"
                 "<th>Strategy (registry)</th><th>Fixtures pinned</th></tr>")
    for r in cov:
        parts.append(f"<tr><td><code>{esc(r['level'] + '/' + r['subject'])}</code></td>"
                     f"<td>{esc(r['years'])}</td><td>{r['majors']}</td>"
                     f"<td><code>{esc(r['strategy'])}</code></td>"
                     + ("<td><span class='ok'>yes</span></td>" if r["fixtures"]
                        else "<td><span class='no'>no</span></td>")
                     + "</tr>")
    parts.append("</table><p><small>Strategies are selected from the syllabus profile + "
                 "component by <code>core/strategies.py</code> (spec Fix 4): no universal "
                 "structured-table parser; practical/essay components resolve to "
                 "REVIEW_REQUIRED instead of an inappropriate cropper. Topic arrays are the "
                 "official major-topic names (spec Fix 7/9) — verified live by "
                 "tests.test_math_taxonomy_rs17.</small></p></div>")

    parts.append("<h2>7 · Limitations &amp; honest notes</h2><div class='card'><ul>")
    for lim in LIMITATIONS:
        parts.append(f"<li>{esc(lim)}</li>")
    parts.append("</ul></div>")

    parts.append("<h2>8 · Reproduce</h2><div class='card'><pre>" + esc(REPRODUCE) + "</pre></div>")
    parts.append(f"<p class='sub'>End of proof report — {'PASS' if overall else 'FAIL'}. "
                 "Regenerate: <code>python3 tools/run_proof.py --check</code>.</p></div></body></html>")
    return "".join(parts), overall, checks


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--output", default=str(REPO / "proof_report.html"))
    ap.add_argument("--suite", dest="suite", action="store_true", default=True)
    ap.add_argument("--no-suite", dest="suite", action="store_false")
    ap.add_argument("--suite-modules", nargs="+", default=None)
    ap.add_argument("--stamp-now", action="store_true")
    ap.add_argument("--download", action="store_true",
                    help="re-fetch + re-pin the fixture corpus first "
                         "(tools/download_fixtures.py), then build the report")
    ap.add_argument("--check", action="store_true",
                    help="exit 1 if any live check fails")
    args = ap.parse_args(argv)
    if args.download:
        print("[proof] --download: refreshing fixture corpus (download_fixtures.py)…")
        r = subprocess.run([sys.executable, str(REPO / "tools" / "download_fixtures.py")],
                           capture_output=True, text=True, timeout=3000)
        for _ln in (r.stdout or "").strip().splitlines()[-3:]:
            print(f"[proof] download: {_ln}")
        if r.returncode != 0:
            print(f"[proof] --download FAILED (rc={r.returncode}); building with current corpus")
    modules = args.suite_modules or MASTHEAD
    markup, overall, checks_pass = build_report(args.suite, modules, args.stamp_now)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(markup, encoding="utf-8")
    _man = write_proof_manifest(out, checks_pass, args.stamp_now)
    print(f"[proof] wrote {out} ({len(markup):,} chars) + {_man.relative_to(REPO)}; overall "
          f"{'PASS' if overall else 'FAIL'}"
          + (f"; suite: {len(modules)} modules" if args.suite else "; suite skipped"))
    if args.check and not overall:
        print("[proof] --check: FAILING checks present → exit 1")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
