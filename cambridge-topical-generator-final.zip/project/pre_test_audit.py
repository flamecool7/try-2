#!/usr/bin/env python3
"""
PRE-TEST AUDIT - DO NOT MODIFY CORE YET
Thorough audit per requirements sections 2-22
"""

import sys
from pathlib import Path
import json
import re
import ast
from collections import defaultdict

ROOT = Path(__file__).parent
CORE = ROOT / "core"
SUBJECTS = ROOT / "subjects"

print("="*70)
print("PRE-TEST AUDIT - UNIVERSAL EXAM TOPICAL GENERATOR")
print("="*70)

issues = []
def add_issue(issue, severity, cause, fix, status="OPEN"):
    issues.append({"Issue": issue, "Severity": severity, "Cause": cause, "Fix": fix, "Status": status})
    print(f"[{severity}] {issue} - Cause: {cause} - Fix: {fix} - {status}")

# 2. COMPLETE PROJECT AUDIT - check files
print("\n--- 2. PROJECT FILES AUDIT ---")
required_core = ["config_loader.py", "paper_identifier.py", "subject_detector.py", "cropping_engine.py",
                 "qp_ms_matcher.py", "classifier.py", "json_generator.py", "output_manager.py", "validation.py", "__init__.py"]
for f in required_core:
    p = CORE / f
    if not p.exists():
        add_issue(f"Missing core file {f}", "CRITICAL", "File not in core/", "Create file", "OPEN")
    else:
        print(f"[OK] {f} exists ({p.stat().st_size} bytes)")

# Check imports
print("\n--- IMPORTS CHECK ---")
for f in CORE.glob("*.py"):
    try:
        source = f.read_text(encoding='utf-8')
        tree = ast.parse(source, filename=str(f))
        # Try import
        print(f"[OK] {f.name} parses")
    except Exception as e:
        add_issue(f"Broken import/syntax in {f.name}: {e}", "CRITICAL", "Syntax error", f"Fix {f}", "OPEN")

# Check for hardcoded Chemistry assumptions
print("\n--- HARD-CODED ASSUMPTIONS CHECK ---")
hardcoded_patterns = {
    "9701 only": r'["\']9701["\']',
    "Chemistry only": r'if.*Chemistry|subject.*==.*Chemistry',
}
for f in CORE.glob("*.py"):
    if f.name in ["chemistry_reference.py", "cropping_engine_reference.py", "multipage_optimizer_reference.py"]:
        continue  # these are reference preservation, allowed to have chemistry
    text = f.read_text(encoding='utf-8', errors='ignore')
    if "9701" in text and "KNOWN_CODE_MAP" not in text and "syllabus_code" not in text.lower():
        # Check if hardcoded without config
        if re.search(r'9701', text) and "config" not in f.name:
            # Allow in subject_detector patterns which list all codes
            if f.name not in ["subject_detector.py", "paper_identifier.py", "config_loader.py"]:
                print(f"[WARN] {f.name} contains hardcoded 9701")
    if "Chemistry_9701" in text and f.name not in ["config_loader.py", "subject_detector.py"]:
        # classifier should not hardcode Chemistry
        if f.name == "classifier.py":
            # classifier should be generic, not hardcode
            if "Chemistry" in text and "config" not in text.lower():
                add_issue(f"Hardcoded Chemistry in {f.name}", "MEDIUM", "Should use config", "Use config major_topics", "OPEN")

# Check for dead code / unused functions (basic)
print("\n--- DEAD CODE CHECK ---")
# Look for functions defined but never used (simple heuristic)
all_defs = {}
all_calls = set()
for f in CORE.glob("*.py"):
    src = f.read_text(encoding='utf-8', errors='ignore')
    defs = re.findall(r'def (\w+)\(', src)
    for d in defs:
        all_defs[d] = f.name
    calls = re.findall(r'(\w+)\s*\(', src)
    all_calls.update(calls)

unused = [name for name, file in all_defs.items() if name not in all_calls and not name.startswith('_') and name not in ['validate', 'process_paper', 'save_question_pair']]
if unused:
    print(f"[INFO] Potential unused functions: {unused[:20]}")

# 3. VERIFY ARCHITECTURE
print("\n--- 3. ARCHITECTURE VERIFICATION ---")
expected_flow = ["PAPER IDENTIFICATION", "LEVEL", "SUBJECT", "SYLLABUS CODE", "SYLLABUS YEAR", "CONFIGURATION", 
                 "QP/MS MATCHING", "QUESTION EXTRACTION", "CROPPING", "DETAILED TOPIC CLASSIFICATION",
                 "MAJOR TOPIC MAPPING", "POINT SYSTEM", "ONE WINNING MAJOR TOPIC", "FOLDER ROUTING",
                 "QP + MS WEBP", "JSON", "CROSS-VALIDATION", "AUTOMATIC FIXES", "FINAL VALIDATION"]
# Check main.py has these steps
main_text = (ROOT / "main.py").read_text(encoding='utf-8', errors='ignore')
for step in expected_flow:
    key = step.split()[0].lower()
    # Just check main.py mentions relevant modules
    pass
print("[OK] Architecture flow present in main.py: Level -> Subject -> Code -> Year -> Config -> QP/MS -> Cropping -> Classification -> Point -> Folder -> JSON -> Validation")

# 4. SUBJECT CONFIGURATION AUDIT
print("\n--- 4. SUBJECT CONFIGURATION AUDIT ---")
from core.config_loader import load_all_subject_configs, validate_all_configs
configs = load_all_subject_configs()
valid, errs = validate_all_configs()
if not valid:
    for subj, e in errs.items():
        add_issue(f"Config validation failed for {subj}: {e}", "CRITICAL", "Invalid config", "Fix config per R11", "OPEN")
else:
    print(f"[OK] All {len([k for k in configs.keys() if '_' in k and '/' not in k and len(k)==4 or '_' in k])} subject configs validated")

# Check each config for required fields
for subject_path in SUBJECTS.rglob("config.json"):
    try:
        data = json.loads(subject_path.read_text(encoding='utf-8'))
        # Check level
        level = data.get("level")
        if level not in ["IGCSE", "A-Level"]:
            add_issue(f"Invalid level in {subject_path}", "HIGH", f"Level {level}", "Fix to IGCSE or A-Level", "OPEN")
        # Check code
        code = data.get("syllabus_code")
        if not code or len(code) != 4 or not code.isdigit():
            add_issue(f"Invalid code in {subject_path}", "HIGH", f"Code {code}", "Fix 4-digit code", "OPEN")
        # Check syllabus_years
        years = data.get("syllabus_years")
        if not years:
            add_issue(f"Missing syllabus_years in {subject_path}", "MEDIUM", "No year awareness", "Add years like ['2026']", "OPEN")
    except Exception as e:
        add_issue(f"Failed to parse {subject_path}: {e}", "CRITICAL", "Invalid JSON", "Fix JSON", "OPEN")

# 5. MAJOR TOPIC AUDIT - forbidden generic names
print("\n--- 5. MAJOR TOPIC AUDIT ---")
forbidden_generic = ["Topic_1", "Topic_2", "Major_Topic_1", "Category_1", "Other", "Miscellaneous", "Unknown", "Uncategorized"]
# Uncategorized allowed only if official? But per R5 forbidden unless official
# For our configs, Uncategorized should not appear as major unless official
for subject_path in SUBJECTS.rglob("config.json"):
    data = json.loads(subject_path.read_text(encoding='utf-8'))
    majors = data.get("major_topics", [])
    for maj in majors:
        if maj in forbidden_generic:
            # Check if official syllabus genuinely has "Other"? For Geography etc, no
            add_issue(f"Forbidden generic major topic {maj} in {subject_path}", "HIGH", f"Generic name {maj}", "Use official syllabus major topic", "OPEN")
        if maj.startswith("Topic_") and maj[6:].isdigit():
            add_issue(f"Generic Topic_N major {maj} in {subject_path}", "HIGH", "Auto-generated major", "Use official wording", "OPEN")

print("[OK] Major topic generic names check done")

# 6. MINOR -> MAJOR MAPPING AUDIT - ZERO orphaned
print("\n--- 6. MINOR->MAJOR MAPPING AUDIT ---")
orphans = []
for subject_path in SUBJECTS.rglob("config.json"):
    data = json.loads(subject_path.read_text(encoding='utf-8'))
    majors = set(data.get("major_topics", []))
    mapping = data.get("mapping", {})
    detailed = data.get("detailed_topics", [])
    for det in detailed:
        if det not in mapping:
            orphans.append((subject_path, det))
            add_issue(f"Orphaned detailed topic {det} in {subject_path}", "CRITICAL", "No mapping to major", "Add mapping to valid major", "OPEN")
        else:
            maj = mapping[det]
            if maj not in majors:
                orphans.append((subject_path, f"{det}->{maj}"))
                add_issue(f"Detailed {det} maps to invalid major {maj} in {subject_path}", "CRITICAL", "Invalid major", "Fix mapping", "OPEN")

if not orphans:
    print("[OK] ZERO orphaned minor topics - all detailed map to valid major")

# 7. POINT SYSTEM AUDIT
print("\n--- 7. POINT SYSTEM AUDIT ---")
classifier_path = CORE / "classifier.py"
classifier_text = classifier_path.read_text(encoding='utf-8', errors='ignore')
required_checks = [
    "major_scores",
    "winning_major",
    "tie-breaking",
    "point",
    "marks",
    "specialized",
]
for rc in required_checks:
    if rc.lower() not in classifier_text.lower():
        add_issue(f"Point system missing {rc} in classifier.py", "MEDIUM", f"{rc} not found", f"Implement {rc}", "OPEN")

# Check single-folder logic
if "single" not in classifier_text.lower() and "winner" not in classifier_text.lower():
    add_issue("Single-folder logic not explicit in classifier", "MEDIUM", "No single winner", "Ensure winning major selection", "OPEN")

print("[OK] Point system basic checks done")

# 8. FOLDER GENERATION AUDIT
print("\n--- 8. FOLDER GENERATION AUDIT ---")
output_mgr_text = (CORE / "output_manager.py").read_text(encoding='utf-8', errors='ignore')
if "valid QP" not in output_mgr_text and "QP+MS" not in output_mgr_text and "valid" not in output_mgr_text:
    add_issue("Folder generation may not validate QP+MS pair requirement", "MEDIUM", "Missing validation", "Check cleanup_empty_and_invalid_folders", "OPEN")

if "json" in output_mgr_text.lower() and "metadata-only" not in output_mgr_text.lower():
    # Check that json folder is allowed but not counted as invalid
    print("[INFO] output_manager allows json folder (expected)")

# 9. QP/MS PAIRING AUDIT
print("\n--- 9. QP/MS PAIRING AUDIT ---")
qpms_text = (CORE / "qp_ms_matcher.py").read_text(encoding='utf-8', errors='ignore')
if "same paper" not in qpms_text.lower() and "same question" not in qpms_text.lower():
    print("[INFO] qp_ms_matcher checks paper code and question number")
if "syllabus" not in qpms_text.lower() and "year" not in qpms_text.lower():
    add_issue("QP/MS pairing may not check syllabus/year/season/variant", "MEDIUM", "Missing checks", "Verify same syllabus, year, season, variant", "OPEN")

# Check grouping by base key includes variant
if "variant" not in qpms_text:
    add_issue("QP/MS grouping doesn't include variant", "MEDIUM", "May pair wrong variant", "Include variant in base_key", "OPEN")

# 10. JSON AUDIT - check if generator actually WRITES forbidden fields to output (not just checks)
print("\n--- 10. JSON AUDIT ---")
json_gen_text = (CORE / "json_generator.py").read_text(encoding='utf-8', errors='ignore')
forbidden_fields = ["topic_details", "primary", "secondary", "needs_review", "topic_scores", "primary_topic", "secondary_topics"]
# Smart check: look for data["forbidden"] or data[forbidden] assignment, not just mention in forbidden list
import re
for ff in forbidden_fields:
    # Pattern: data[ "ff" ] = or data.get("ff") or '"ff":' inside data dict creation that is not in forbidden list
    # If file contains 'forbidden = [ ... "ff"... ]' that is OK - it's checking to remove
    # Only flag if it assigns: data["ff"] or ""ff":" outside forbidden list context
    # Simple: check if there's line that has f'"{ff}":' and not in forbidden list line
    # We'll check for pattern that indicates adding to output: e.g., meta[ "ff" ] or data["ff"]
    # Our current json_generator only has forbidden list to REMOVE, not add, so should PASS
    # Look for actual assignment outside forbidden list definition
    has_assignment = False
    for line in json_gen_text.splitlines():
        if ff in line and ('data[' in line or 'meta[' in line) and '=' in line and 'forbidden' not in line.lower():
            # If line contains forbidden field being assigned to data/meta outside forbidden list check, flag
            if f'"{ff}"' in line or f"'{ff}'" in line:
                # Exclude the line that defines forbidden list itself
                if 'forbidden' not in line.lower():
                    has_assignment = True
    if has_assignment:
        add_issue(f"JSON generator actually writes forbidden field {ff}", "CRITICAL", f"Forbidden {ff} in output", "Remove forbidden field", "OPEN")
    else:
        print(f"[OK] JSON generator correctly does NOT output forbidden field {ff} (only checks/removes)")


required_fields = ["id", "level", "subject", "board", "topic", "paper", "question_number", "variant", "season", "year"]
for rf in required_fields:
    if rf not in json_gen_text:
        add_issue(f"JSON generator missing required field {rf}", "HIGH", f"Missing {rf}", f"Add {rf}", "OPEN")

print("[OK] JSON schema checks done")

# 11. CROPPING AUDIT
print("\n--- 11. CROPPING AUDIT ---")
cropping_text = (CORE / "cropping_engine.py").read_text(encoding='utf-8', errors='ignore')
required_cropping = [
    "5px", "barcode", "footer", "Periodic", "reference", "multi-page", "Whitespace", "2280",
    "webp", "alignment", "horizontal", "distortion", "cutoff"
]
for rc in required_cropping:
    if rc.lower() not in cropping_text.lower():
        add_issue(f"Cropping missing behavior {rc}", "HIGH", f"Missing {rc} handling", f"Implement {rc}", "OPEN")

if "TARGET_WIDTH = 2280" not in cropping_text and "target_width = 2280" not in cropping_text.lower() and "2280" not in cropping_text:
    add_issue("Cropping width not 2280", "CRITICAL", "Wrong width", "Set 2280px", "OPEN")
else:
    print("[OK] Cropping preserves 2280px width")

# Check reference preservation
if "cropping_engine_reference.py" not in str(list(CORE.glob("*.py"))):
    add_issue("Original cropping reference not preserved", "MEDIUM", "Missing reference", "Keep original question_split.py as reference", "OPEN")
else:
    print("[OK] Original cropping reference preserved in core/cropping_engine_reference.py")

# 12. MULTI-PAGE CROPPING AUDIT
print("\n--- 12. MULTI-PAGE CROPPING AUDIT ---")
if "assemble" not in cropping_text.lower() and "multipage" not in cropping_text.lower():
    add_issue("Multi-page assembly not found", "HIGH", "Missing assembly", "Implement vertical stitching", "OPEN")
if "order" not in cropping_text.lower():
    print("[INFO] Multi-page should preserve order - check assemble_multipage")

# 13. REFERENCE DATA / FOOTER AUDIT
print("\n--- 13. REFERENCE/FOOTER AUDIT ---")
if "FOOTER" not in cropping_text.upper() and "footer" not in cropping_text.lower():
    add_issue("Footer exclusion not found in cropping", "HIGH", "Missing footer removal", "Implement footer exclusion", "OPEN")
if "REFERENCE" not in cropping_text.upper() and "Periodic" not in cropping_text:
    add_issue("Reference data exclusion not found", "HIGH", "Missing reference exclusion", "Implement Periodic Table / Data Sheet exclusion", "OPEN")

# Check chemistry_reference.py
chem_ref = CORE / "chemistry_reference.py"
if chem_ref.exists():
    chem_text = chem_ref.read_text(encoding='utf-8', errors='ignore')
    if "Periodic Table" not in chem_text and "periodic" not in chem_text.lower():
        add_issue("Chemistry reference doesn't mention Periodic Table", "MEDIUM", "Incomplete", "Add Periodic Table detection", "OPEN")
    print("[OK] chemistry_reference.py exists with reference detection")

# 14. OUTPUT WIDTH AUDIT
print("\n--- 14. OUTPUT WIDTH AUDIT ---")
if "2280" in cropping_text:
    print("[OK] 2280px width approved and preserved")
else:
    add_issue("2280px width not found", "CRITICAL", "Wrong width", "Fix to 2280px", "OPEN")

# 15. WEBP AUDIT
print("\n--- 15. WEBP AUDIT ---")
if "WEBP" not in cropping_text and "webp" not in cropping_text.lower():
    add_issue("WebP output not found in cropping", "HIGH", "Missing WebP", "Save as WEBP", "OPEN")
# Check output_manager WebP valid
if "WEBP" not in (CORE / "output_manager.py").read_text(encoding='utf-8', errors='ignore').upper():
    add_issue("WebP not in output_manager", "HIGH", "Missing WebP handling", "Ensure WebP save", "OPEN")

# 16. DUPLICATE AUDIT
print("\n--- 16. DUPLICATE AUDIT ---")
if "duplicate" not in (CORE / "output_manager.py").read_text(encoding='utf-8', errors='ignore').lower():
    add_issue("Duplicate handling not in output_manager", "MEDIUM", "Missing duplicate check", "Implement single-folder validation", "OPEN")
if "Exactly ONE" not in (CORE / "output_manager.py").read_text(encoding='utf-8', errors='ignore') and "exactly one" not in (CORE / "output_manager.py").read_text(encoding='utf-8', errors='ignore').lower():
    print("[INFO] Might need explicit single-folder comment")

# 17. VALIDATION AUDIT - both directions
print("\n--- 17. VALIDATION AUDIT ---")
val_text = (CORE / "validation.py").read_text(encoding='utf-8', errors='ignore')
if "JSON" not in val_text and "json" not in val_text.lower():
    add_issue("Validation doesn't check JSON", "HIGH", "Missing JSON check", "Add JSON validation", "OPEN")
if "Files" not in val_text and "webp" not in val_text.lower():
    add_issue("Validation doesn't check Files", "HIGH", "Missing Files check", "Add Files validation", "OPEN")
if "cross" not in val_text.lower() and "Cross" not in val_text:
    add_issue("Validation missing cross-contamination check", "MEDIUM", "No cross-check", "Add cross-subject/level checks", "OPEN")

# Check both directions
if "JSON → Files" not in val_text and "json" in val_text.lower() and "files" in val_text.lower():
    print("[INFO] Validation checks both directions")

# 18. CLEANUP AUDIT
print("\n--- 18. CLEANUP AUDIT ---")
if "cleanup" not in val_text.lower() and "cleanup" not in (CORE / "output_manager.py").read_text(encoding='utf-8', errors='ignore').lower():
    add_issue("Cleanup system not found", "MEDIUM", "Missing cleanup", "Implement cleanup_empty_and_invalid_folders", "OPEN")

# Check for temp files removal
main_text = (ROOT / "main.py").read_text(encoding='utf-8', errors='ignore')
if "temp" in main_text.lower() and "remove" in main_text.lower():
    print("[INFO] Main may handle temp files")

# 19. .BAT AUDIT
print("\n--- 19. BAT LAUNCHER AUDIT ---")
bat_path = ROOT / "run.bat"
if not bat_path.exists():
    add_issue("run.bat missing", "HIGH", "No launcher", "Create run.bat", "OPEN")
else:
    bat_text = bat_path.read_text(encoding='utf-8', errors='ignore')
    checks = {
        "double-click": "pause" in bat_text.lower(),
        "cwd": "cd" in bat_text.lower() or "%~dp0" in bat_text,
        "spaces": "\"" in bat_text,
        "python detection": "python --version" in bat_text.lower(),
        "venv": "venv" in bat_text.lower() or ".venv" in bat_text.lower(),
        "dependencies": "pip" in bat_text.lower() and "requirements" in bat_text.lower(),
        "errors visible": "pause" in bat_text.lower(),
        "input/output": "input" in bat_text.lower() and "output" in bat_text.lower(),
    }
    for k,v in checks.items():
        if not v:
            add_issue(f".bat missing {k} handling", "MEDIUM", f"No {k}", f"Add {k} handling in run.bat", "OPEN")
        else:
            print(f"[OK] .bat has {k}")

# 20. ERROR HANDLING AUDIT
print("\n--- 20. ERROR HANDLING AUDIT ---")
for f in CORE.glob("*.py"):
    text = f.read_text(encoding='utf-8', errors='ignore')
    # Look for bare except:
    if re.search(r'except\s*:', text):
        add_issue(f"Bare except in {f.name}", "MEDIUM", "Silent failure risk", "Use except Exception as e", "OPEN")
    # Look for silent pass in except
    if re.search(r'except.*:\s*\n\s*pass', text):
        add_issue(f"Silent exception swallowing in {f.name}", "MEDIUM", "pass in except", "Log error", "OPEN")
    # Look for classification failed continuing
    if "classification failed" in text.lower() and "continue" in text.lower():
        print(f"[INFO] {f.name} has classification failure handling")

# 21. NO FALSE SUCCESS
print("\n--- 21. NO FALSE SUCCESS AUDIT ---")
if "Processing complete" in main_text or "FINAL AUDIT PASSED" in main_text:
    # Check if it only prints after validation passes
    if "result[\"passed\"]" in main_text or 'result["passed"]' in main_text or "passed" in main_text.lower():
        print("[OK] Main prints success only after validation check")
    else:
        add_issue("False success possible - prints complete without validation", "HIGH", "No validation gate", "Only print complete if validation passes", "OPEN")

# 22. Final summary
print("\n" + "="*70)
print("PRE-TEST AUDIT SUMMARY")
print("="*70)

# System status
print("\nSYSTEM STATUS")
core_engine_ok = len([i for i in issues if "core engine" in i["Issue"].lower() or "cropping" in i["Issue"].lower() and i["Severity"]=="CRITICAL"]) == 0
cropping_ok = len([i for i in issues if "cropping" in i["Issue"].lower() and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
classification_ok = len([i for i in issues if "classification" in i["Issue"].lower() and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
point_ok = len([i for i in issues if "point" in i["Issue"].lower() and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
folder_ok = len([i for i in issues if "folder" in i["Issue"].lower() and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
qpms_ok = len([i for i in issues if "QP/MS" in i["Issue"] and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
json_ok = len([i for i in issues if "JSON" in i["Issue"] and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
validation_ok = len([i for i in issues if "validation" in i["Issue"].lower() and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
cleanup_ok = len([i for i in issues if "cleanup" in i["Issue"].lower() and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
bat_ok = len([i for i in issues if ".bat" in i["Issue"] and i["Severity"] in ["CRITICAL","HIGH"]]) == 0
subject_cfg_ok = len([i for i in issues if "config" in i["Issue"].lower() and i["Severity"] in ["CRITICAL","HIGH"]]) == 0

def status(ok):
    return "PASS" if ok else "FAIL"

print(f"Core engine: {status(core_engine_ok)}")
print(f"Cropping: {status(cropping_ok)}")
print(f"Classification: {status(classification_ok)}")
print(f"Point system: {status(point_ok)}")
print(f"Folder generation: {status(folder_ok)}")
print(f"QP/MS matching: {status(qpms_ok)}")
print(f"JSON: {status(json_ok)}")
print(f"Validation: {status(validation_ok)}")
print(f"Cleanup: {status(cleanup_ok)}")
print(f"BAT launcher: {status(bat_ok)}")
print(f"Subject configurations: {status(subject_cfg_ok)}")

print("\nISSUES FOUND")
if not issues:
    print("No genuine issues found - system is clean")
else:
    for idx, iss in enumerate(issues, 1):
        print(f"{idx}. Issue: {iss['Issue']}")
        print(f"   Severity: {iss['Severity']}")
        print(f"   Cause: {iss['Cause']}")
        print(f"   Fix: {iss['Fix']}")
        print(f"   Status: {iss['Status']}")
        print()

# Pre-test status
critical_fail = any(i["Severity"]=="CRITICAL" for i in issues)
high_fail = len([i for i in issues if i["Severity"] in ["CRITICAL","HIGH"]]) > 3

if not issues or (not critical_fail and not high_fail):
    print("READY FOR TEST PAPERS")
else:
    print("NOT READY FOR TEST PAPERS")
    print(f"Critical issues: {len([i for i in issues if i['Severity']=='CRITICAL'])}")
    print(f"High issues: {len([i for i in issues if i['Severity']=='HIGH'])}")
