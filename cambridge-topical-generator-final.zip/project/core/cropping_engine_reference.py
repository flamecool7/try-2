"""
question_split.py
=================
Split a Cambridge question-paper PDF into individual question images with
hard requirements:
  A. FINAL WIDTH: Every final crop is EXACTLY 2280 pixels wide (aspect ratio preserved).
  B. BARCODE ELIMINATION / ZERO TOP CLIPPING: Top crop boundary begins just above
     the actual question line with a proportional, raster-validated margin:
     recognised header junk (barcodes, page numbers, running headers) is
     excluded structurally, everything else is preserved with a font-size-
     proportional guard. Slight extra whitespace above a question is accepted;
     sliced text is not. Adapts to any layout/DPI (no hardcoded pixel padding).
  C. MULTI-PAGE WHITESPACE OPTIMIZATION: Tight-trims each page section (5–10px margin)
     and combines them with a minimal gap (5–15px separation).
  D. ZERO CONTENT LOSS: Protects all diagrams, chemical structures, reaction schemes,
     equations, tables, and marks allocations [Total: X].
  E. MULTI-PAGE RESIZING: Resizes final combined images to exactly 2280px wide with
     LANCZOS resampling and validation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Set, Tuple, Union

try:
    import fitz
except ImportError:
    import pymupdf as fitz

import numpy as np
from PIL import Image

from .chemistry_reference import (
    PageClassification,
    classify_page,
    identify_removable_pages,
)
from .config import Config
from .multipage_optimizer import (
    assemble_multipage_question,
    enforce_exact_width_2280,
    find_content_bbox,
    trim_page_section,
    validate_content_preservation,
)
from .pdf_io import (
    detect_footer_y,
    detect_header_y,
    is_blank_image,
    page_is_usable,
)
from .quality_control import QuestionQCValidator, QCValidationResult

# Standard dimensions
TARGET_WIDTH = 2280
EXPECTED_W = 2480
EXPECTED_H = 3508

# Question & Marker Patterns
_NUMBER_LINE = re.compile(r"^\s*(\d{1,3})\s*[.)]?\s*$")
_NUMBER_PREFIX = re.compile(r"^\s*(\d{1,3})(?:[.)]\s+|\s+)\S")
_QUESTION_WORD_PREFIX = re.compile(r"^\s*(?:question|q)\s*(\d{1,3})\s*[:.)]?\s*", re.IGNORECASE)
_NUMBER_WITH_SUBPART = re.compile(r"^\s*(\d{1,3})\s*\(\s*([a-z]|[ivx]{1,4})\s*\)", re.IGNORECASE)
_SUBPART = re.compile(r"\(([a-z]|[ivx]{1,4})\)")
_UNIT_OR_VALUE = re.compile(r"^\s*\d{1,3}\s*(?:mol|cm|dm|g|kg|pa|kpa|mpa|atm|v|mv|s|min|h|kj|j|w|k|°c|%)\b", re.IGNORECASE)

LEFT_MARGIN = 0.22
LEFT_MARGIN_STRICT = 0.15
Q_START_TOP_BAND_PT = 30.0
BOTTOM_SKIP = 0.90


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------
@dataclass
class Question:
    qid: str = ""
    source_pdf: str = ""
    paper_code: str = ""
    session_label: str = ""
    year: int = 0
    question_number: str = ""
    sub_parts: List[str] = field(default_factory=list)
    images: List[Image.Image] = field(default_factory=list)
    text: str = ""
    text_hash: Optional[str] = None
    perceptual_hash: Optional[str] = None
    topic: List[str] = field(default_factory=list)
    needs_review: bool = False
    is_duplicate: bool = False
    duplicate_of: Optional[str] = None
    folder_name: str = ""
    topic_scores: Dict[str, float] = field(default_factory=dict)
    topic_confidence: float = 0.0
    ms_entry: Optional[Union[str, Image.Image]] = None
    _topic_scores: list = field(default_factory=list)
    page_segments: List[dict] = field(default_factory=list)
    review_reasons: List[str] = field(default_factory=list)
    qc_metrics: Dict[str, object] = field(default_factory=dict)

    @property
    def is_multi_page(self) -> bool:
        return len(self.images) > 1 or (self.images and self.images[0].height > 4000)


@dataclass(frozen=True)
class PageSegment:
    """A vertical slice of one source page."""
    page_index: int
    y0: int
    y1: int
    shared_page: bool = False
    safe_whitespace_cut: bool = True


@dataclass
class PageCropInfo:
    page_index: int
    left: int
    top: int
    right: int
    bottom: int
    orig_w: int
    orig_h: int
    # Proportional top-guard margin (px) used for this page. Derived from the
    # page's own body font size and render scale, so it tracks layout & DPI
    # instead of being a blind hardcoded pixel value. Shared with the segment
    # splitter so question-start boundaries keep the same validated margin.
    top_guard_px: float = 8.0


# ---------------------------------------------------------------------------
# Question Boundary Detection: 5px Above Question Line (No Barcode)
# ---------------------------------------------------------------------------
def find_question_start_pdf(page: fitz.Page, qnum: int) -> float:
    """
    Find the exact upright PDF y-coordinate where the question begins,
    excluding top barcodes, page numbers, and running headers.
    """
    w, h = float(page.rect.width), float(page.rect.height)
    q_re = re.compile(rf"^\s*(?:question\s*)?{qnum}(?:$|\s+|[.)])", re.IGNORECASE)

    blocks = page.get_text("dict").get("blocks", [])
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                txt = s.get("text", "").strip()
                bbox = s.get("bbox", [0, 0, 0, 0])
                # Question start must be below top margin (y > 55pt) and near left margin
                if bbox[1] > 55.0 and bbox[0] < w * 0.22:
                    if q_re.match(txt):
                        return float(bbox[1])

    # Fallback to general text analysis
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                bbox = s.get("bbox", [0, 0, 0, 0])
                if bbox[1] > 58.0 and bbox[0] < w * 0.90:
                    return float(bbox[1])

    return 60.0


def find_continuation_start_pdf(page: fitz.Page) -> float:
    """
    Find top-most question content on a continuation page (below running header).
    """
    w, h = float(page.rect.width), float(page.rect.height)
    min_y = h

    blocks = page.get_text("dict").get("blocks", [])
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                txt = s.get("text", "").strip()
                bbox = s.get("bbox", [0, 0, 0, 0])
                if bbox[1] > 58.0 and bbox[3] < h * 0.92 and bbox[0] < w * 0.94:
                    if "DO NOT WRITE" not in txt and "Turn over" not in txt and "Assessment 2026" not in txt:
                        min_y = min(min_y, bbox[1])

    drawings = page.get_drawings()
    for d in drawings:
        r = d.get("rect")
        if r and r.y0 > 58.0 and r.y1 < h * 0.92 and r.x1 < w * 0.94:
            min_y = min(min_y, r.y0)

    if min_y >= h:
        min_y = 60.0
    return min_y


def find_question_bottom_pdf(page: fitz.Page) -> float:
    """
    Find the bottom-most question content on a page (above running footer & barcode).
    """
    w, h = float(page.rect.width), float(page.rect.height)
    max_y = 0.0

    blocks = page.get_text("dict").get("blocks", [])
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                txt = s.get("text", "").strip()
                bbox = s.get("bbox", [0, 0, 0, 0])
                if bbox[3] < h * 0.94 and bbox[0] < w * 0.94:
                    if "©" not in txt and "Assessment" not in txt and "Turn over" not in txt and "DO NOT WRITE" not in txt:
                        max_y = max(max_y, bbox[3])

    drawings = page.get_drawings()
    for d in drawings:
        r = d.get("rect")
        if r and r.y1 < h * 0.94 and r.x1 < w * 0.94:
            if r.width < w * 0.90 or r.height < h * 0.90:
                max_y = max(max_y, r.y1)

    if max_y <= 0:
        max_y = h * 0.90
    return max_y


# ---------------------------------------------------------------------------
# Adaptive Crop Page (validated, layout-adaptive safe top)
# ---------------------------------------------------------------------------
# Header-junk recognition for the page-top boundary. Junk is recognised
# structurally (typography + position + pattern), never by a fixed y-line,
# so the boundary adapts to different paper layouts and resolutions.
_PAGE_BARCODE_RE = re.compile(r"\*+\s*[\d\s]{5,}\s*\*+")
_PAGE_NUM_RE = re.compile(r"^\s*\d{1,3}\s*$")
_HEADER_BOILERPLATE = ("©", "ucles", "turn over", "do not write", "read these instructions")


def _analyse_page_top(page: fitz.Page) -> Tuple[float, float, float, List[Tuple[float, float, float, float]]]:
    """Analyse one page and return (header_floor_pdf, content_top_pdf, margin_pt, junk_boxes_pdf).

    header_floor_pdf : bottom y (PDF pts) of recognised header junk (page number,
        barcode, running-header boilerplate); 0 when nothing is recognised.
    content_top_pdf  : top y (PDF pts) of true question content - the first text
        span or vector drawing that is NOT recognised header junk. No artificial
        y-floor is applied, so compact layouts (content starting high on the
        page, e.g. a diagram above 55pt) are detected correctly.
    margin_pt        : proportional safety margin = 0.45 * median body font size,
        clamped to [3, 16] pt. Scales with the layout; multiplied by the page's
        own render scale downstream, so it also adapts to DPI automatically.
    junk_boxes_pdf   : PDF-space boxes of recognised header junk, used to mask
        junk during the raster validation pass and to white-out any recognised
        junk that could leak into the kept region (never content, see below).

    Recognition is deliberately conservative: a page number must be digits-only,
    centered, header-sized, AND vertically alone in the header band (no other
    text overlapping its rows) - otherwise a lone math digit in a fraction
    numerator could be misclassified and erased. When junk and content truly
    overlap, both are kept (whitespace/junk residue is acceptable, clipped or
    erased content is not).
    """
    w, h = float(page.rect.width), float(page.rect.height)
    spans: List[Tuple[str, float, float, float, float, float]] = []
    for block in page.get_text("dict").get("blocks", []):
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span.get("text", "").strip()
                if not text:
                    continue
                x0, y0, x1, y1 = span.get("bbox", [0, 0, 0, 0])
                size = float(span.get("size", 0.0) or 0.0)
                spans.append((text, x0, y0, x1, y1, size))

    junk_flags: List[bool] = []
    for i, (text, x0, y0, x1, y1, size) in enumerate(spans):
        lowered = text.lower()
        in_top_band = y1 < h * 0.15
        is_barcode = bool(_PAGE_BARCODE_RE.search(text))
        is_boilerplate = in_top_band and any(s in lowered for s in _HEADER_BOILERPLATE)
        # Page number: short digits-only string, centered, top of page, printed
        # in a header-sized font (>= 9pt excludes footnotes/superscripts), and
        # ALONE on its rows. The alone check is what protects a single digit in
        # a math fraction near the top from being treated as a page number.
        centered = abs((x0 + x1) / 2.0 - w / 2.0) < w * 0.18
        alone = True
        for j, (otext, ox0, oy0, ox1, oy1, osize) in enumerate(spans):
            if i == j:
                continue
            if oy1 < h * 0.15 and oy1 > y0 - 2.0 and oy0 < y1 + 2.0:
                alone = False
                break
        is_pagenum = (
            in_top_band and centered and size >= 9.0 and alone
            and bool(_PAGE_NUM_RE.match(text))
        )
        junk_flags.append(bool(is_barcode or is_pagenum or is_boilerplate))

    sizes: List[float] = [s[5] for s in spans if s[5] > 0]
    junk_boxes: List[Tuple[float, float, float, float]] = []
    header_floor = 0.0
    content_top: Optional[float] = None

    for (text, x0, y0, x1, y1, size), is_junk in zip(spans, junk_flags):
        if is_junk:
            junk_boxes.append((x0, y0, x1, y1))
            header_floor = max(header_floor, y1)
        else:
            content_top = y0 if content_top is None else min(content_top, y0)

    # Vector drawings (diagrams, rules, graphs) count as content wherever they
    # are; a compact page that starts with a figure must never be decapitated.
    for d in page.get_drawings():
        r = d.get("rect")
        if r and (r.width < w * 0.90 or r.height < h * 0.90):
            content_top = r.y0 if content_top is None else min(content_top, r.y0)

    if sizes:
        median_size = float(sorted(sizes)[len(sizes) // 2])
        margin_pt = max(3.0, min(16.0, 0.45 * median_size))
    else:
        margin_pt = 5.0  # textless page fallback (diagram-only): modest fixed margin

    if content_top is None:
        content_top = header_floor if header_floor > 0 else h * 0.07

    return header_floor, content_top, margin_pt, junk_boxes


def _validate_top_against_ink(
    img: Image.Image,
    top_px: int,
    guard_px: int,
    junk_boxes_px: List[Tuple[int, int, int, int]],
) -> int:
    """Raster validation pass for the page-top boundary.

    Scans the ACTUAL rendered pixels above the candidate boundary. Any ink found
    there that does not belong to recognised header junk is real content that
    would have been sliced (coordinate misalignment, ink above the PDF text
    bbox, or an unrecognised drawing), so the boundary is pulled UP above it
    with the same proportional guard. Validation-based safety instead of blind
    trust in PDF coordinates. Only ever raises the boundary (adds whitespace),
    never lowers it (never clips).
    """
    gray = np.asarray(img.convert("L"))
    height, width = gray.shape
    if height < 10 or width < 10:
        return top_px

    top_px = int(max(0, min(height, top_px)))
    if top_px <= 0:
        return 0

    masked = gray[:top_px, :].copy()
    for (x0, y0, x1, y1) in junk_boxes_px:
        x0 = max(0, min(width, x0)); x1 = max(0, min(width, x1))
        y0 = max(0, min(top_px, y0)); y1 = max(0, min(top_px, y1))
        if y1 > y0 and x1 > x0:
            masked[y0:y1, x0:x1] = 255

    # >= 2 faint pixels (< 250) per row: robust against speckle noise, still
    # catches light anti-aliased ink. Guaranteed no-clipping, not byte-tight.
    ink_rows = np.where((masked < 250).sum(axis=1) >= 2)[0]
    if ink_rows.size:
        return max(0, int(ink_rows.min()) - max(1, int(guard_px)))
    return top_px


def fixed_crop_page(img: Image.Image, cfg: Config) -> Image.Image:
    """Fallback fixed pixel crop."""
    w, h = img.size
    left = cfg.crop_left
    top = cfg.crop_top
    right = w - cfg.crop_right
    bottom = h - cfg.crop_bottom

    if bottom <= top or right <= left:
        return img
    return img.crop((left, top, right, bottom))


def adaptive_crop_page(
    img: Image.Image,
    page: fitz.Page,
    cfg: Config,
) -> Tuple[Image.Image, PageCropInfo]:
    """
    Context-aware crop boundary:
    Top boundary starts at a validated proportional margin above the page's
    first real question content, structurally excluding barcodes/page numbers/
    running headers and raster-validated so text is never clipped.
    """
    orig_w, orig_h = img.size
    page_w = float(page.rect.width) or 1.0
    page_h = float(page.rect.height) or 1.0
    scale_y = orig_h / page_h
    scale_x = orig_w / page_w

    # Content bounds on this page (bottom unchanged: detected content + slack)
    bottom_pdf = find_question_bottom_pdf(page)

    # Safe top boundary: structural detection + proportional margin + raster
    # validation (replaces the previous fixed 55pt constant, which sliced
    # question content that starts high on compact layouts).
    header_floor_pdf, content_top_pdf, margin_pt, junk_boxes_pdf = _analyse_page_top(page)
    guard_px = max(1, int(round(margin_pt * scale_y)))
    top_pdf = max(0.0, max(header_floor_pdf, content_top_pdf - margin_pt))
    top_px = max(0, min(orig_h, int(round(top_pdf * scale_y))))
    # Validate against actual pixels: unexpected non-junk ink above the
    # candidate boundary pulls it upward so nothing is ever clipped.
    junk_boxes_px = [
        (int(round(bx0 * scale_x)) - 3, int(round(by0 * scale_y)) - 3,
         int(round(bx1 * scale_x)) + 3, int(round(by1 * scale_y)) + 3)
        for (bx0, by0, bx1, by1) in junk_boxes_pdf
    ]
    top_px = _validate_top_against_ink(img, top_px, guard_px, junk_boxes_px)

    bottom_px = min(orig_h, int(round(bottom_pdf * scale_y)) + 5)

    # White-out recognised header junk that survives inside the kept region
    # (e.g. a page number passing through rows that must be preserved for the
    # question). ONLY conservatively recognised junk boxes are painted - real
    # content is never erased (same precedent as the existing watermark and
    # imposition-barcode scrubbing in pdf_io/webp_utils).
    if junk_boxes_px:
        painted = img if img.mode == "RGB" else img.convert("RGB")
        painted = painted.copy()
        pw, ph = painted.size
        for (jx0, jy0, jx1, jy1) in junk_boxes_px:
            cx0 = max(0, min(pw, jx0)); cx1 = max(0, min(pw, jx1))
            cy0 = max(top_px, max(0, min(ph, jy0)))
            cy1 = min(bottom_px + 1, max(0, min(ph, jy1)))
            if cx1 > cx0 and cy1 > cy0:
                painted.paste(Image.new("RGB", (cx1 - cx0, cy1 - cy0), "white"), (cx0, cy0))
        img = painted

    left_px = max(0, int(round(45.0 * scale_x)))
    right_px = min(orig_w, int(round((page_w - 45.0) * scale_x)))

    if bottom_px <= top_px or right_px <= left_px:
        cropped = img
        top_px, bottom_px, left_px, right_px = 0, orig_h, 0, orig_w
    else:
        cropped = img.crop((left_px, top_px, right_px, bottom_px))

    crop_info = PageCropInfo(
        page_index=page.number,
        left=left_px,
        top=top_px,
        right=right_px,
        bottom=bottom_px,
        orig_w=orig_w,
        orig_h=orig_h,
        top_guard_px=float(guard_px),
    )
    return cropped, crop_info


# ---------------------------------------------------------------------------
# Page Removal: Chemistry Reference Material
# ---------------------------------------------------------------------------
def remove_unnecessary_pages(
    doc: fitz.Document,
    images: List[Image.Image],
    cfg: Config,
) -> List[int]:
    """Identify and remove all reference pages, periodic tables, and data sheets."""
    total_pages = len(images)
    syllabus_code = str(getattr(cfg, "syllabus_code", "") or "")
    keep, remove, classifications = identify_removable_pages(
        doc, total_pages, syllabus_code=syllabus_code
    )

    for cls in classifications:
        p_num = cls.page_idx + 1
        if cls.is_reference or cls.is_blank or cls.is_candidate_info:
            print(f"  [page-remove] Page {p_num:2d}/{total_pages}: {cls.category} - {cls.reason} "
                  f"(conf={cls.confidence:.2f})")

    if not keep and total_pages > 1:
        keep = list(range(1, total_pages))

    return keep


# ---------------------------------------------------------------------------
# Marker Detection & Sequence Healing
# ---------------------------------------------------------------------------
def _lines_on_page(page: "fitz.Page"):
    """Extract text lines with bounding boxes and typography."""
    rect = page.rect
    out = []
    for block in page.get_text("dict").get("blocks", []):
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            if not spans:
                continue
            text = "".join(s.get("text", "") for s in spans).rstrip()
            if not text.strip():
                continue
            x0 = min(s.get("bbox", [1e9])[0] for s in spans)
            y0 = min(s.get("bbox", [0, 1e9])[1] for s in spans)
            y1 = max(s.get("bbox", [0, 0])[3] for s in spans)
            font_size = max(float(s.get("size", 0.0) or 0.0) for s in spans)
            is_bold = any("bold" in str(s.get("font", "")).lower() for s in spans)
            out.append((x0, y0, y1, text, font_size, is_bold))
    out.sort(key=lambda t: (t[1], t[0]))
    return out, rect


def _parse_candidate_number(text: str) -> Optional[int]:
    """Parse question number from text line."""
    st = text.strip()
    if not st or _UNIT_OR_VALUE.match(st):
        return None

    m = _NUMBER_LINE.match(st) or _QUESTION_WORD_PREFIX.match(st) or \
        _NUMBER_WITH_SUBPART.match(st) or _NUMBER_PREFIX.match(st)
    if m:
        val = int(m.group(1))
        if 1 <= val <= 120:
            return val
    return None


def _detect_markers(
    doc: fitz.Document,
    kept_indices: Optional[List[int]] = None,
) -> Tuple[List[Tuple[int, float, int]], bool]:
    """Detect question starts using multi-pattern matching and sequence healing."""
    kept_set = set(kept_indices) if kept_indices is not None else set(range(len(doc)))
    raw_candidates: List[Tuple[int, float, int, float, float, bool, float, str]] = []
    per_page_lines: Dict[int, list] = {}

    for p_idx in sorted(kept_set):
        page = doc[p_idx]
        lines, rect = _lines_on_page(page)
        per_page_lines[p_idx] = lines

        for line_idx, (x0, y0, y1, text, font_size, is_bold) in enumerate(lines):
            if x0 > LEFT_MARGIN * rect.width or y0 > BOTTOM_SKIP * rect.height or y0 < 0.04 * rect.height:
                continue

            num = _parse_candidate_number(text)
            if num is None:
                continue

            prev_bottom = 0.0
            for prior in lines[:line_idx]:
                if prior[2] <= y0 and prior[0] < rect.width * 0.92:
                    prev_bottom = max(prev_bottom, prior[2])
            gap_above = max(0.0, y0 - prev_bottom)

            raw_candidates.append((p_idx, y0, num, x0, font_size, is_bold, gap_above, text))

    if not raw_candidates:
        return [], False

    filtered = [
        c for c in raw_candidates
        if c[3] < LEFT_MARGIN_STRICT * doc[c[0]].rect.width or _QUESTION_WORD_PREFIX.match(c[7])
    ]
    if not filtered:
        filtered = raw_candidates

    starts = [c for c in filtered if c[2] == 1]
    if not starts:
        min_q = min(c[2] for c in filtered)
        starts = [c for c in filtered if c[2] == min_q]

    def marker_quality(c, anchor_x: float) -> float:
        p_idx, _y, _n, x0, font_size, is_bold, gap, _txt = c
        rect = doc[p_idx].rect
        score = 4.0 if x0 < rect.width * 0.10 else 2.0
        score += 2.0 if font_size >= 10.0 else 0.0
        score += 1.5 if is_bold else 0.0
        score += min(2.0, gap / 8.0)
        score -= abs(x0 - anchor_x) / 6.0
        return score

    best_chain: List[Tuple[int, float, int, float, float, bool, float, str]] = []
    best_value = float("-inf")

    for start in starts[:10]:
        anchor_x = start[3]
        chain = [start]
        curr_val = marker_quality(start, anchor_x)
        expected = start[2] + 1
        curr_page, curr_y = start[0], start[1]

        while expected <= 120:
            options = [
                c for c in filtered
                if c[2] == expected
                and (c[0] > curr_page or (c[0] == curr_page and c[1] > curr_y + 25.0))
            ]
            if not options:
                # Sequence gap healing
                healed = None
                for p in kept_set:
                    if p < curr_page:
                        continue
                    for lx0, ly0, ly1, ltext, lfs, lbold in per_page_lines.get(p, []):
                        if p == curr_page and ly0 <= curr_y + 20:
                            continue
                        n = _parse_candidate_number(ltext)
                        if n == expected and lx0 < LEFT_MARGIN * doc[p].rect.width:
                            healed = (p, ly0, n, lx0, lfs, lbold, 10.0, ltext)
                            break
                    if healed:
                        break
                if healed:
                    options = [healed]

            if not options:
                break

            chosen = max(options, key=lambda c: marker_quality(c, anchor_x))
            chain.append(chosen)
            curr_val += marker_quality(chosen, anchor_x)
            curr_page, curr_y = chosen[0], chosen[1]
            expected = chosen[2] + 1

        chain_score = len(chain) * 100.0 + curr_val
        if chain_score > best_value:
            best_value = chain_score
            best_chain = chain

    markers = [(c[0], c[1], c[2]) for c in best_chain]
    markers.sort(key=lambda c: (c[0], c[1]))
    if not markers:
        return [], False

    sequential = all(markers[i][2] == markers[i - 1][2] + 1 for i in range(1, len(markers)))
    confidence = len(markers) >= 1 and sequential
    return markers, confidence


# ---------------------------------------------------------------------------
# Whitespace Cut Finder (Shared Pages)
# ---------------------------------------------------------------------------
def _blank_runs(mask: np.ndarray) -> List[Tuple[int, int]]:
    runs: List[Tuple[int, int]] = []
    start = None
    for index, value in enumerate(mask):
        if bool(value) and start is None:
            start = index
        elif not bool(value) and start is not None:
            runs.append((start, index))
            start = None
    if start is not None:
        runs.append((start, len(mask)))
    return runs


def find_whitespace_cut(
    image: Image.Image,
    marker_y_px: int,
    *,
    min_band_px: Optional[int] = None,
    protected_bands: Optional[List[Tuple[int, int]]] = None,
) -> Tuple[Optional[int], bool, Optional[Tuple[int, int]]]:
    """Find safe whitespace cut above a question marker."""
    gray = np.asarray(image.convert("L"))
    height, width = gray.shape
    if height < 20 or width < 20:
        return None, False, None

    marker_y_px = max(1, min(height - 1, int(marker_y_px)))
    x0 = max(0, int(width * 0.03))
    x1 = min(width, int(width * 0.97))
    region = gray[:, x0:x1]
    dark = region < 242
    row_ink = dark.sum(axis=1)

    search_dist = max(240, int(height * 0.20))
    search_top = max(1, marker_y_px - search_dist)
    search_bottom = max(search_top + 1, marker_y_px - 2)
    if search_bottom <= search_top:
        return None, False, None

    min_band = min_band_px if min_band_px is not None else max(10, int(height * 0.0035))

    protected_mask = np.zeros(height, dtype=bool)
    if protected_bands:
        for py0, py1 in protected_bands:
            py0 = max(0, min(height - 1, py0))
            py1 = max(0, min(height, py1))
            if py1 > py0:
                protected_mask[py0:py1] = True

    def find_best_band(max_ink: int, required_len: int):
        local_mask = (row_ink[search_top:search_bottom] <= max_ink)
        candidates = []
        for local_start, local_end in _blank_runs(local_mask):
            start = search_top + local_start
            end = search_top + local_end
            if end - start < required_len or np.any(protected_mask[start:end]):
                continue
            distance = marker_y_px - end
            candidates.append((distance, -(end - start), start, end))

        if not candidates:
            return None
        _dist, _neg_len, start, end = min(candidates)
        return start, end

    band = find_best_band(0, min_band) or find_best_band(max(2, int((x1 - x0) * 0.001)), min_band)
    if band is not None:
        start, end = band
        return (start + end) // 2, True, band

    band = find_best_band(0, 1)
    if band is not None:
        start, end = band
        return (start + end) // 2, False, band

    return None, False, None


def _pdf_y_to_cropped_px(
    page: fitz.Page,
    y_pdf: float,
    orig_h: int,
    crop_info: PageCropInfo,
) -> int:
    page_h = float(page.rect.height) or 1.0
    y_full = (float(y_pdf) / page_h) * orig_h
    return max(0, int(round(y_full - crop_info.top)))


def _page_has_continuation_above(
    doc: fitz.Document,
    page_idx: int,
    marker_y_pdf: float,
) -> bool:
    page = doc[page_idx]
    w, h = float(page.rect.width), float(page.rect.height)
    header_h = h * 0.06
    if marker_y_pdf <= header_h + 35.0:
        return False

    body_clip = fitz.Rect(0, header_h, w, marker_y_pdf)
    text_above = page.get_text("text", clip=body_clip).strip()
    lines = [l.strip() for l in text_above.splitlines() if l.strip()]
    clean_lines = [l for l in lines if not re.match(r"^\d{1,4}/|\bturn over\b|^\d{1,3}$", l, re.I)]
    combined = " ".join(clean_lines)

    has_subpart = bool(re.search(r"\([a-zivx]+\)", combined, re.I))
    has_marks = bool(re.search(r"\[\s*\d+\s*\]|\[\s*total", combined, re.I))
    has_command = bool(re.search(r"\b(calculate|explain|state|describe|determine|suggest|draw|write|complete|identify)\b", combined, re.I))
    has_substantive_text = len(combined) > 40

    drawings_above = [
        d for d in page.get_drawings()
        if header_h < d.get("rect", fitz.Rect(0, 0, 0, 0)).y1 < marker_y_pdf
        and d.get("rect", fitz.Rect(0, 0, 0, 0)).height < h * 0.90
    ]
    return bool(has_subpart or has_marks or has_command or (has_substantive_text and len(drawings_above) > 0))


# ---------------------------------------------------------------------------
# Build Question Segments
# ---------------------------------------------------------------------------
def build_question_segments(
    markers: List[Tuple[int, float, int]],
    kept_indices: List[int],
    original_images: List[Image.Image],
    cropped_images: List[Image.Image],
    crop_infos: Dict[int, PageCropInfo],
    doc: fitz.Document,
    cfg: Config,
) -> Tuple[Dict[int, List[PageSegment]], bool, List[str]]:
    """Build question segments ensuring the top boundary sits at a validated
    proportional guard above each question start (no tight fixed-pixel clips)."""
    if not markers:
        return {}, False, ["No question markers detected"]

    kept = sorted(set(kept_indices))
    kept_set = set(kept)
    cuts: Dict[int, Tuple[int, bool]] = {}
    notes: List[str] = []
    all_safe = True

    for marker_idx in range(1, len(markers)):
        prev_m = markers[marker_idx - 1]
        curr_m = markers[marker_idx]
        p_idx, y_pdf, qnum = curr_m

        if p_idx not in kept_set:
            continue

        cinfo = crop_infos[p_idx]
        marker_px = _pdf_y_to_cropped_px(
            doc[p_idx], y_pdf, original_images[p_idx].height, cinfo
        )

        same_page = (prev_m[0] == curr_m[0])
        continuation_above = _page_has_continuation_above(doc, p_idx, y_pdf)
        should_split = same_page or continuation_above

        if not should_split:
            continue

        page = doc[p_idx]
        scale_y = original_images[p_idx].height / float(page.rect.height)
        drawings = page.get_drawings()
        protected_bands: List[Tuple[int, int]] = []
        for d in drawings:
            dr = d.get("rect")
            if dr and dr.height < page.rect.height * 0.90:
                py0 = int(round(dr.y0 * scale_y - cinfo.top))
                py1 = int(round(dr.y1 * scale_y - cinfo.top))
                protected_bands.append((py0, py1))

        cut, safe, band = find_whitespace_cut(
            cropped_images[p_idx], marker_px, protected_bands=protected_bands
        )

        if cut is None:
            # No whitespace band found: fall back to a proportional guard above
            # the question marker. The guard derives from the page's own body
            # font size (see adaptive_crop_page), NOT a hardcoded pixel count,
            # so tall first-line ink (fractions, superscripts) is never sliced
            # while the split still hugs the question start.
            guard = int(round(getattr(cinfo, "top_guard_px", 8) or 8))
            cut = max(1, min(cropped_images[p_idx].height - 1, marker_px - guard))
            safe = False
            notes.append(f"Page {p_idx + 1}, Q{qnum}: split {guard}px (adaptive guard) above question start at y={cut}")
        else:
            band_text = f"{band[0]}:{band[1]}" if band else "narrow"
            notes.append(f"Page {p_idx + 1}, Q{qnum}: split at y={cut} inside whitespace band {band_text}")

        cuts[marker_idx] = (cut, safe)
        all_safe = all_safe and safe

    by_question: Dict[int, List[PageSegment]] = {}
    for marker_idx, (start_page, start_y_pdf, qnum) in enumerate(markers):
        if marker_idx + 1 < len(markers):
            next_page = markers[marker_idx + 1][0]
            if marker_idx + 1 in cuts:
                end_page = next_page
            else:
                before_next = [p for p in kept if start_page <= p < next_page]
                end_page = before_next[-1] if before_next else start_page
        else:
            remaining = [p for p in kept if p >= start_page]
            end_page = remaining[-1] if remaining else start_page

        segments: List[PageSegment] = []
        for p_idx in kept:
            if p_idx < start_page or p_idx > end_page:
                continue
            image = cropped_images[p_idx]
            if not page_is_usable(image):
                continue

            y0 = 0
            y1 = image.height
            shared = False
            safe = True

            # If this is the start page of the question, set top crop 5px above the question line
            if p_idx == start_page:
                cinfo = crop_infos[p_idx]
                start_px = _pdf_y_to_cropped_px(
                    doc[p_idx], start_y_pdf, original_images[p_idx].height, cinfo
                )
                if marker_idx in cuts:
                    y0, safe = cuts[marker_idx]
                    shared = True
                else:
                    # For the first top-level question on a page, retain the
                    # page content from the safe post-page-number boundary.
                    # Later questions on a shared page still start at their
                    # own detected marker (with the same proportional guard,
                    # not a tight 5px), preventing unrelated content.
                    has_prior_question_on_page = any(m[0] == p_idx for m in markers[:marker_idx])
                    guard = int(round(getattr(cinfo, "top_guard_px", 8) or 8))
                    y0 = max(0, start_px - guard) if has_prior_question_on_page else 0

            if (marker_idx + 1 in cuts and markers[marker_idx + 1][0] == p_idx):
                y1, end_safe = cuts[marker_idx + 1]
                safe = safe and end_safe
                shared = True

            y0 = max(0, min(image.height, int(y0)))
            y1 = max(0, min(image.height, int(y1)))
            if y1 - y0 < 10:
                all_safe = False
                continue

            segments.append(PageSegment(
                page_index=p_idx, y0=y0, y1=y1,
                shared_page=shared, safe_whitespace_cut=safe,
            ))

        if segments:
            by_question[qnum] = segments

    return by_question, all_safe, notes


def crop_page_segments(
    cropped_images: List[Image.Image],
    segments: List[PageSegment],
) -> List[Image.Image]:
    """Materialize PageSegment slices and enforce whitespace optimization & 2280px width."""
    output: List[Image.Image] = []
    for segment in segments:
        if segment.page_index >= len(cropped_images):
            continue
        image = cropped_images[segment.page_index]
        if segment.y0 == 0 and segment.y1 == image.height:
            piece = image.copy()
        else:
            piece = image.crop((0, segment.y0, image.width, segment.y1)).copy()
        output.append(piece)

    if not output:
        return []

    # Assemble all segments with whitespace optimization into a single 2280px wide image
    assembled = assemble_multipage_question(output, target_width=TARGET_WIDTH)
    return [assembled]


def merge_question_pages(
    images: List[Image.Image],
    page_indices: List[int],
) -> Image.Image:
    """Merge multiple page images vertically into a single 2280px wide question canvas."""
    real = [images[idx] for idx in page_indices if idx < len(images) and page_is_usable(images[idx])]
    return assemble_multipage_question(real, target_width=TARGET_WIDTH)


def extract_question_text(
    doc: fitz.Document,
    question_pages: List[int],
    markers: List[Tuple[int, float, int]],
    qnum: int,
) -> str:
    """Extract exact question text from PDF for classification."""
    marker_idx = None
    for i, (p0, y0, qn) in enumerate(markers):
        if qn == qnum:
            marker_idx = i
            break

    if marker_idx is None:
        return ""

    p0, y0, _ = markers[marker_idx]
    relevant_pages = sorted(set(question_pages))
    if not relevant_pages:
        return ""

    if marker_idx + 1 < len(markers):
        next_page, next_y, _ = markers[marker_idx + 1]
        if next_page in relevant_pages:
            p1, y1 = next_page, next_y
        else:
            p1 = relevant_pages[-1]
            y1 = float(doc[p1].rect.height)
    else:
        p1 = relevant_pages[-1]
        y1 = float(doc[p1].rect.height)

    texts: List[str] = []
    for pg in relevant_pages:
        if pg < p0 or pg > p1:
            continue
        page = doc[pg]
        if pg == p0 and pg == p1:
            clip = fitz.Rect(0, y0, page.rect.width, y1)
        elif pg == p0:
            clip = fitz.Rect(0, y0, page.rect.width, page.rect.height)
        elif pg == p1:
            clip = fitz.Rect(0, 0, page.rect.width, y1)
        else:
            clip = page.rect
        text = page.get_text("text", clip=clip).strip()
        if text:
            # Clean header/footer/barcode artifacts from classification text
            text = re.sub(r"\*\s*\d{10,16}\s*\*", "", text)
            text = re.sub(r"DO NOT WRITE IN THIS MARGIN", "", text, flags=re.IGNORECASE)
            text = re.sub(r"\d{4}/\d{2}/[A-Z]/[A-Z]/\d{2}", "", text)
            text = re.sub(r"©.*?Assessment \d{4}", "", text)
            texts.append(text)

    return "\n".join(texts).strip()


# ---------------------------------------------------------------------------
# Main Entry Point: split_questions
# ---------------------------------------------------------------------------
def split_questions(
    pdf_path: str | Path,
    dpi: int = 200,
    paper_code: str = "",
    webp_dir: str | Path | None = None,
    use_api: bool = False,
    api_key: str | None = None,
    cfg: Optional[Config] = None,
) -> Tuple[List[Question], bool]:
    """
    Split question-paper PDF into Question objects:
      1. Renders PDF pages to images.
      2. Removes reference sheets (Periodic Table, Data Sheets, etc.).
      3. Sets top crop boundary at a validated proportional margin above the question line (eliminating barcodes without clipping content).
      4. Assembles multi-page questions with tight whitespace trimming (5–10px margin, 5–15px gap).
      5. Enforces EXACTLY 2280px width on every crop.
    """
    if cfg is None:
        cfg = Config()

    pdf_path = Path(pdf_path)
    doc = fitz.open(str(pdf_path))

    # --- Step 1: Render PDF pages to WebP ---
    if webp_dir is not None:
        webp_dir = Path(webp_dir)
    else:
        import tempfile
        webp_dir = Path(tempfile.mkdtemp(prefix="qp_pages_"))

    if use_api and api_key:
        from .converter import convert_pdf_to_webp, render_pdf_local
        try:
            webp_paths = convert_pdf_to_webp(pdf_path, webp_dir, api_key)
        except Exception as e:
            print(f"[split] API render failed ({e}). Falling back to local renderer...")
            webp_paths = render_pdf_local(pdf_path, webp_dir)
    else:
        from .converter import render_pdf_local
        webp_paths = render_pdf_local(pdf_path, webp_dir)

    images: List[Image.Image] = []
    for wp in webp_paths:
        img = Image.open(wp).convert("RGB")
        images.append(img)

    print(f"[split] Loaded {len(images)} page images from {pdf_path.name}")

    # --- Step 2: Chemistry Reference Material Removal ---
    print("[split] Detecting and removing reference sheets, data tables, and cover pages...")
    kept_indices = remove_unnecessary_pages(doc, images, cfg)
    print(f"[split] Kept {len(kept_indices)} of {len(images)} pages (removed {len(images) - len(kept_indices)} non-question pages)")

    # --- Step 3: Adaptive Page Cropping ---
    print("[split] Applying context-aware boundary detection to question pages...")
    cropped_images: List[Image.Image] = [Image.new("RGB", (1, 1), "white")] * len(images)
    crop_infos: Dict[int, PageCropInfo] = {}

    for idx in kept_indices:
        cropped, cinfo = adaptive_crop_page(images[idx], doc[idx], cfg)
        cropped_images[idx] = cropped
        crop_infos[idx] = cinfo

    # --- Step 4: Marker Detection ---
    markers, marker_confident = _detect_markers(doc, kept_indices=kept_indices)

    if not markers:
        print("[split] WARNING: No question markers detected!")
        doc.close()
        return [], False

    print(f"[split] Detected {len(markers)} question marker(s) (confident={marker_confident})")

    # --- Step 5: Shared-Page Segmentation ---
    question_segments, split_confident, split_notes = build_question_segments(
        markers, kept_indices, images, cropped_images, crop_infos, doc, cfg,
    )
    for note in split_notes:
        print(f"  [shared-page] {note}")

    overall_confident = marker_confident and split_confident

    # --- Step 6: Create Question Objects & Run QC Validation ---
    questions: List[Question] = []

    for qnum, segments in sorted(question_segments.items()):
        segment_images = crop_page_segments(cropped_images, segments)
        if not segment_images:
            continue
        page_indices = [segment.page_index for segment in segments]

        text = extract_question_text(doc, page_indices, markers, qnum)
        sub_parts = sorted(set(_SUBPART.findall(text)))

        segment_dicts = [
            {
                "page": s.page_index + 1,
                "y0": s.y0,
                "y1": s.y1,
                "shared": s.shared_page,
                "safe": s.safe_whitespace_cut,
            }
            for s in segments
        ]

        # Enforce exact 2280px width on the final image
        final_images = [enforce_exact_width_2280(im, target_width=TARGET_WIDTH) for im in segment_images]

        # Quality Control Validation
        qc_res = QuestionQCValidator.validate(
            question_number=str(qnum),
            images=final_images,
            text=text,
            sub_parts=sub_parts,
            page_segments=segment_dicts,
            paper_code=paper_code,
            doc=doc,
        )

        q = Question(
            source_pdf=str(pdf_path),
            paper_code=paper_code,
            question_number=str(qnum),
            sub_parts=sub_parts,
            images=final_images,
            text=text,
            needs_review=qc_res.needs_review,
            page_segments=segment_dicts,
            review_reasons=qc_res.review_reasons,
            qc_metrics=qc_res.metrics,
        )

        if not qc_res.is_valid:
            print(f"  [qc-warn] Q{qnum} failed QC validation: {', '.join(qc_res.review_reasons)}")
        elif qc_res.needs_review:
            print(f"  [qc-review] Q{qnum} flagged for review: {', '.join(qc_res.review_reasons)}")

        questions.append(q)

        assembled_w = max(im.width for im in final_images)
        assembled_h = sum(im.height for im in final_images)
        shared_count = sum(1 for s in segments if s.shared_page)
        print(f"  Q{qnum}: {len(segments)} page section(s), "
              f"final crop {assembled_w}×{assembled_h}px (width=2280 exactly), subparts={sub_parts}")

    doc.close()
    return questions, overall_confident
