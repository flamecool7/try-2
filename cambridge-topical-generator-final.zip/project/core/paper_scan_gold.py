"""
paper_scan.py
=============
Robust scanner and metadata extractor for Cambridge question papers and mark schemes.

Supports:
  1. Standard Cambridge naming: {syllabus}_{season}{year}_{kind}_{paper}.pdf (e.g. 9701_s24_qp_22.pdf)
  2. Two-letter seasons: mj (May/June), on (Oct/Nov), fm (Feb/March), sp (Specimen)
  3. Single-digit paper numbers: 9701_s24_qp_2.pdf
  4. 4-digit years: 9701_2024_qp_22.pdf, 9701_May_June_2024_qp_22.pdf
  5. Space/dash/underscore separators
  6. Content-based PDF cover inspection fallback (identifies paper from PDF text if filename is non-standard)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import fitz
except ImportError:
    import pymupdf as fitz

from .reference import (
    SESSION_FROM_LETTER,
    canonical_season,
    detect_level,
    detect_subject,
)

# Flexible multi-pattern filename parser
_PATTERNS = [
    # 1. Standard: 9701_s24_qp_22.pdf or 9701_mj24_qp_22.pdf or 9701_fm26_qp_22.pdf
    re.compile(r"(\d{4})[_ -]?(s|w|m|mj|on|fm|sp|z|y)(\d{2})[_ -]?(qp|ms|er|ir|gt|in|pm)[_ -]?(\d{1,3})", re.IGNORECASE),
    # 2. 4-digit year: 9701_2024_s_qp_22.pdf or 9701_2024_qp_22.pdf
    re.compile(r"(\d{4})[_ -]?(?:20)?(\d{2})[_ -]?(s|w|m|mj|on|fm|sp|z)?(?:[_ -]?(qp|ms|er|ir|gt))?[_ -]?(\d{1,3})", re.IGNORECASE),
    # 3. Simple prefix: 9701_qp_22.pdf or 9701_ms_22.pdf
    re.compile(r"(\d{4})[_ -]?(qp|ms)[_ -]?(\d{1,3})", re.IGNORECASE),
]

_SEASON_MAP = {
    "s": "s", "mj": "s", "m/j": "s", "summer": "s", "may": "s", "june": "s",
    "w": "w", "on": "w", "o/n": "w", "winter": "w", "oct": "w", "nov": "w",
    "m": "m", "fm": "m", "f/m": "m", "spring": "m", "feb": "m", "march": "m",
    "sp": "z", "z": "z", "y": "z", "specimen": "z",
}


@dataclass
class PaperInfo:
    path: str
    syllabus: str
    subject: str
    level: str
    season_letter: str
    session_label: str
    session_id: str
    year: int
    kind: str
    paper_code: str
    variant: str
    recognized: bool = True


def _inspect_pdf_cover(pdf_path: Path) -> Optional[PaperInfo]:
    """Inspect first page of PDF to extract paper metadata if filename is non-standard."""
    try:
        doc = fitz.open(str(pdf_path))
        if len(doc) == 0:
            doc.close()
            return None
        text = doc[0].get_text("text") or ""
        doc.close()

        # Extract syllabus and paper: e.g. 9701/22 or 9701 / 22
        m_code = re.search(r"\b(\d{4})\s*/\s*(\d{1,3})\b", text)
        if not m_code:
            return None

        syllabus = m_code.group(1)
        paper_code = m_code.group(2).lstrip("0") or m_code.group(2)

        # Detect kind: mark scheme vs question paper
        kind = "ms" if re.search(r"\b(?:mark\s*scheme|markscheme)\b", text, re.I) else "qp"

        # Detect season and year
        season_letter = "s"
        session_label = "Summer"
        session_id = "May/Jun"
        year = 2024

        m_year = re.search(r"\b(20\d{2})\b", text)
        if m_year:
            year = int(m_year.group(1))

        if re.search(r"\b(?:february|march|feb/mar|feb)\b", text, re.I):
            season_letter = "m"
            session_label = "Spring"
            session_id = "Feb/Mar"
        elif re.search(r"\b(?:october|november|oct/nov|nov)\b", text, re.I):
            season_letter = "w"
            session_label = "Winter"
            session_id = "Oct/Nov"
        elif re.search(r"\b(?:specimen)\b", text, re.I):
            season_letter = "z"
            session_label = "Specimen"
            session_id = "Specimen"

        return PaperInfo(
            path=str(pdf_path),
            syllabus=syllabus,
            subject=detect_subject(syllabus),
            level=detect_level(syllabus),
            season_letter=season_letter,
            session_label=canonical_season(session_label),
            session_id=session_id,
            year=year,
            kind=kind,
            paper_code=paper_code,
            variant=paper_code[-1] if paper_code else "1",
            recognized=True,
        )
    except Exception:
        return None


def scan_papers(input_dir: str | Path) -> Tuple[List[PaperInfo], List[str]]:
    """Scan directory and parse all Cambridge exam question papers and mark schemes."""
    input_dir = Path(input_dir)
    papers: List[PaperInfo] = []
    unrecognized: List[str] = []

    if not input_dir.exists():
        return papers, unrecognized

    pdf_files = sorted(input_dir.glob("*.pdf")) + sorted(input_dir.glob("*.PDF"))
    # Remove duplicates from case-insensitive filesystems
    seen_paths = set()
    unique_pdfs = []
    for p in pdf_files:
        if p.resolve() not in seen_paths:
            seen_paths.add(p.resolve())
            unique_pdfs.append(p)

    for pdf in unique_pdfs:
        stem = pdf.stem
        info: Optional[PaperInfo] = None

        # Pattern 1: 9701_s24_qp_22 or 9701_mj24_qp_22
        m = _PATTERNS[0].search(stem)
        if m:
            syllabus = m.group(1)
            raw_season = m.group(2).lower()
            season_letter = _SEASON_MAP.get(raw_season, "s")
            year2 = int(m.group(3))
            kind = m.group(4).lower()
            paper_code = m.group(5).lstrip("0") or m.group(5)
            session_label, session_id = SESSION_FROM_LETTER.get(season_letter, ("Summer", "May/Jun"))

            info = PaperInfo(
                path=str(pdf), syllabus=syllabus,
                subject=detect_subject(syllabus), level=detect_level(syllabus),
                season_letter=season_letter, session_label=canonical_season(session_label),
                session_id=session_id, year=2000 + year2, kind=kind,
                paper_code=paper_code, variant=paper_code[-1] if paper_code else "1",
                recognized=True,
            )

        # Fallback to cover text inspection if filename regex did not match
        if info is None:
            info = _inspect_pdf_cover(pdf)

        if info:
            papers.append(info)
        else:
            unrecognized.append(str(pdf))

    return papers, unrecognized
