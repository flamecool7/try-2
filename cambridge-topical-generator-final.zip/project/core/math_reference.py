"""Mathematics 9709 reference-topic loader (9709 only).

The text file is the source of truth.  Heading text selects a paper section;
only the exact non-heading topic strings below that heading are valid JSON and
folder identifiers.  No topic identifier is normalised or rewritten.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
import re
from typing import Dict, List, Sequence

REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Mathematics_9709 References.txt"
_HEADING = re.compile(r"\(P([1-6])\)\s*$")


@lru_cache(maxsize=1)
def load_9709_reference() -> Dict[int, List[str]]:
    """Load the uploaded reference file, preserving each topic string exactly."""
    if not REFERENCE_PATH.exists():
        raise FileNotFoundError(f"Mathematics 9709 reference missing: {REFERENCE_PATH}")
    sections: Dict[int, List[str]] = {}
    current_paper: int | None = None
    for raw_line in REFERENCE_PATH.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current_paper = int(heading.group(1))
            sections.setdefault(current_paper, [])
            continue
        if current_paper is None:
            raise ValueError(f"Topic before P1–P6 heading in {REFERENCE_PATH}: {line!r}")
        # The file's literal topic spelling is canonical; never title-case,
        # replace underscores, or otherwise transform it.
        sections[current_paper].append(line)
    if set(sections) != {1, 2, 3, 4, 5, 6}:
        raise ValueError("Mathematics 9709 reference must define exactly P1 through P6")
    if any(not topics for topics in sections.values()):
        raise ValueError("Every Mathematics 9709 paper section must contain topics")
    return sections


def allowed_topics_for_paper(paper_number: int) -> List[str]:
    return list(load_9709_reference().get(int(paper_number), []))


# Matching aliases are classification evidence only. Values always come from
# the reference file and are returned unchanged.
_TOPIC_KEYWORDS = {
    "Functions": ("function", "domain", "range", "composite", "inverse function"),
    "Coordinate_geometry": ("coordinate geometry", "coordinate", "gradient", "straight line", "circle"),
    "Trigonometry": ("trigonometry", "trigonometric", "sin ", "cos ", "tan ", "sine rule", "cosine rule"),
    "Series": ("series", "sequence", "arithmetic progression", "geometric progression"),
    "Differentiation": ("differentiation", "differentiate", "derivative", "calculus", "dy/dx"),
    "Integration": ("integration", "integrate", "integral", "area under"),
    "Circular_measure": ("circular measure", "radian", "arc length", "sector"),
    "Algebra": ("algebra", "quadratic", "polynomial", "factorise", "factorize", "inequality"),
    "Logarithmic_and_exponential_functions": ("logarithm", "log ", "exponential", "e^"),
    "Numerical_solution_of_equations": ("numerical", "iteration", "root", "solve equation"),
    "Vectors": ("vector", "vectors"),
    "Differential_equations": ("differential equation", "differential equations", "dy/dx"),
    "Complex_numbers": ("complex number", "complex numbers", "argand", "imaginary"),
    "Forces_and_equilibrium": ("force", "forces", "equilibrium", "resultant"),
    "Kinematics_of_motion_in_a_straight_line": ("kinematics", "kinematic", "velocity", "acceleration", "displacement"),
    "Momentum": ("momentum", "impulse", "collision"),
    "Newton's_laws_of_motion": ("newton", "newton's law", "newtons law"),
    "Energy,_work_and_power": ("energy", "work", "power"),
    "Representation_of_data": ("histogram", "box plot", "data", "scatter", "frequency"),
    "Permutations_and_combinations": ("permutation", "combination", "arrangement", "npr", "ncr"),
    "Probability": ("probability", "probabilities", "event", "venn"),
    "Discrete_random_variables": ("discrete random", "probability distribution", "expectation"),
    "The_normal_distribution": ("normal distribution", "normal", "standard deviation", "mean"),
    "Continuous_random_variables": ("continuous random", "density function", "probability density"),
    "Hypothesis_tests": ("hypothesis", "significance", "critical region"),
    "Linear_combinations_of_random_variables": ("linear combination", "random variables"),
    "Sampling_and_estimation": ("sampling", "estimate", "estimation"),
    "The_Poisson_distribution": ("poisson",),
}


# Distinctive terms outrank broad shared words such as "force" or "data".
# This affects only evidence scoring; returned names still come verbatim from
# the reference file.
_TOPIC_SPECIFICITY = {
    "Newton's_laws_of_motion": 3,
    "The_Poisson_distribution": 3,
    "The_normal_distribution": 3,
    "Differential_equations": 2,
    "Complex_numbers": 2,
    "Vectors": 2,
}


def _score_text_against(topics, keywords, specificity, haystack: str) -> dict:
    return {
        topic: sum(haystack.count(keyword) for keyword in keywords.get(topic, ()))
        * specificity.get(topic, 1)
        for topic in topics
    }


def _fuse_diagram(scores: dict, diagram: dict | None) -> dict:
    """Deterministic diagram-signal fusion (spec Fix 8). Signals only ever ADD
    evidence for official topics; they never invent unlisted topics.

    - angle arcs / sectors / greek letters        -> Trigonometry, Circular_measure
    - a lone plain triangle is NOT trigonometry evidence (spec: 'A plain
      triangle is not enough') — it only counts alongside arcs or trig text.
    - vector arrows                               -> Vectors (9709/9231) or
      Transformations_and_vectors (0580)
    - force arrows                                -> Forces / Mechanics topics
    - axes + plotted curve                        -> Coordinate_geometry /
      Algebra_and_graphs
    - histogram-style bar blocks                  -> Representation_of_data /
      Statistics
    """
    if not diagram:
        return scores
    scores = dict(scores)
    arcs = int(diagram.get("angle_arcs", 0))
    sectors = int(diagram.get("sectors", 0))
    triangles = int(diagram.get("triangles", 0))
    arrows = int(diagram.get("vector_arrows", 0))
    force = int(diagram.get("force_arrows", 0))
    axes_curve = int(diagram.get("axes_with_curve", 0))
    bars = int(diagram.get("bar_blocks", 0))
    greek = int(diagram.get("greek_labels", 0))
    normal = int(diagram.get("normal_curves", 0))
    trees = int(diagram.get("probability_trees", 0))

    def bump(names, weight):
        for name in names:
            for key in scores:
                # Exact match, or underscore-suffix ('vectors' -> 'Vectors' and
                # 'Transformations_and_vectors', but 'geometry' must NOT leak
                # into 'Coordinate_geometry').
                kl = key.lower()
                if kl == name.lower() or kl.endswith("_" + name.lower()):
                    scores[key] += weight
    if arcs or sectors:
        bump(["trigonometry", "circular_measure", "geometry"], 2 + arcs + sectors)
        if triangles:
            # triangle + angle evidence IS multi-signal trigonometry.
            bump(["trigonometry"], 2)
    if greek:
        bump(["trigonometry", "circular_measure"], 1)
    if arrows:
        bump(["vectors", "transformations_and_vectors"], 3 + arrows)
    if force:
        bump(["forces_and_equilibrium", "newton's_laws_of_motion",
              "kinematics_of_motion_in_a_straight_line", "mechanics"], 2 + force)
    if axes_curve:
        bump(["coordinate_geometry", "algebra_and_graphs"], 2 + axes_curve)
    if bars:
        bump(["representation_of_data", "statistics"], 2 + bars)
    if normal:
        bump(["the_normal_distribution"], 3)
    if trees:
        bump(["probability"], 2)
    return scores


_FORMULA_NOTATION_CHARS = "θπ°αβλφΔΣμ"


def _text_gate_open(raw_text: str, scores: dict) -> bool:
    """Spec Fix 8 multi-signal contract: a topic is only routable when the
    question TEXT / formula-notation layer carries at least one signal
    (keyword hit or math notation like θ/π/°). Pixel-diagram signals ALONE
    never route a question — diagram-only input is REVIEW_REQUIRED."""
    if any(v > 0 for v in scores.values()):
        return True
    return any(ch in raw_text for ch in _FORMULA_NOTATION_CHARS)


def _merge_text_notation(diagram: dict | None, raw_text: str) -> dict:
    d = dict(diagram or {})
    d["greek_labels"] = int(d.get("greek_labels", 0)) + sum(
        raw_text.count(ch) for ch in _FORMULA_NOTATION_CHARS)
    return d


def classify_9709_question(text: str, paper_number: int, diagram: dict | None = None) -> str | None:
    """Choose one valid topic from the filename-selected reference section.

    Returns None when there is NO deterministic evidence (spec: never fall back
    to an alphabetical/first topic — the caller routes to REVIEW_REQUIRED),
    and also when only pixels speak (diagram-only -> REVIEW_REQUIRED)."""
    allowed = allowed_topics_for_paper(paper_number)
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(allowed, _TOPIC_KEYWORDS, _TOPIC_SPECIFICITY, haystack)
    if not _text_gate_open(text, text_scores):
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    best_score = max(scores.values(), default=0)
    if best_score > 0:
        # Reference order resolves a tie deterministically without renaming.
        return next(topic for topic in allowed if scores[topic] == best_score)
    return None

FURTHER_9231_REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Further_Mathematics_9231 Reference.txt"


def _load_paper_reference(path: Path) -> Dict[int, List[str]]:
    if not path.exists():
        raise FileNotFoundError(f"Mathematics reference missing: {path}")
    sections: Dict[int, List[str]] = {}
    current: int | None = None
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current = int(heading.group(1)); sections.setdefault(current, [])
        elif current is None:
            raise ValueError(f"Topic before paper heading in {path}: {line!r}")
        else:
            sections[current].append(line)
    return sections


@lru_cache(maxsize=1)
def load_9231_reference() -> Dict[int, List[str]]:
    sections = _load_paper_reference(FURTHER_9231_REFERENCE_PATH)
    if set(sections) != {1, 2, 3, 4} or any(not values for values in sections.values()):
        raise ValueError("Further Mathematics 9231 reference must define P1 through P4")
    return sections


def reference_topics_for_subject_paper(syllabus_code: str, paper_number: int) -> List[str]:
    """Return exact, unmodified reference entries for a staging paper."""
    code = str(syllabus_code)
    if code == "9709":
        return allowed_topics_for_paper(paper_number)
    if code == "9231":
        return list(load_9231_reference().get(int(paper_number), []))
    return []
# ---------------------------------------------------------------------------
# IGCSE Mathematics 0580 — official topic areas (2025–2027 syllabus, topic
# names verbatim). Question-level routing per mega-spec Fix 8: text + formula
# evidence first, deterministic diagram fusion, REVIEW_REQUIRED on no-evidence.
MATH_0580_TOPICS: List[str] = [
    "Number",
    "Algebra_and_graphs",
    "Coordinate_geometry",
    "Geometry",
    "Mensuration",
    "Trigonometry",
    "Transformations_and_vectors",
    "Probability",
    "Statistics",
]

_0580_TOPIC_KEYWORDS = {
    "Number": ("number", "integer", "fraction", "percentage", "decimal", "ratio",
               "standard form", "prime", "factor", "interest", "estimat", "bound",
               "currency", "proportion"),
    "Algebra_and_graphs": ("algebra", "expand", "factorise", "factorize", "expression",
                           "simplify", "solve the equation", "quadratic", "sequence",
                           "nth term", "inequality", "formula", "equation", "graph of",
                           "sketch"),
    "Coordinate_geometry": ("gradient", "straight line", "coordinates", "coordinate",
                            "midpoint", "parallel to", "perpendicular", "equation of the line",
                            "y-intercept", "y ="),
    "Geometry": ("angle", "polygon", "congruent", "similar", "circle theorem",
                 "chord", "tangent", "construction", "bisector", "symmetry",
                 "interior angle", "exterior angle"),
    "Mensuration": ("area", "perimeter", "volume", "surface area", "circumference",
                    "radius", "diameter", "length of arc", "sector", "prism",
                    "cylinder", "cone", "sphere", "pyramid"),
    "Trigonometry": ("trigonometr", "sin ", "cos ", "tan ", "sine rule", "cosine rule",
                     "bearing", "angle of elevation", "angle of depression", "pythagoras"),
    "Transformations_and_vectors": ("transformation", "translation", "rotation", "reflection",
                                    "enlargement", "vector", "matrix", "matrices",
                                    "column vector"),
    "Probability": ("probability", "probabilities", "event", "outcome", "tree diagram",
                    "expected number", "without replacement"),
    "Statistics": ("mean", "median", "mode", "range of", "histogram", "cumulative frequency",
                   "scatter", "bar chart", "pie chart", "frequency table", "interquartile",
                   "box plot", "standard deviation"),
}

_0580_TOPIC_SPECIFICITY = {
    "Coordinate_geometry": 2,
    "Transformations_and_vectors": 2,
    "Trigonometry": 2,
}


def classify_0580_question(text: str, diagram: dict | None = None) -> str | None:
    """Question-level 0580 routing into the 9 official topic areas.

    Deterministic: keyword evidence x specificity, diagram fusion, ties resolve
    by official syllabus order. No evidence -> None (caller: REVIEW_REQUIRED).
    """
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(MATH_0580_TOPICS, _0580_TOPIC_KEYWORDS,
                                      _0580_TOPIC_SPECIFICITY, haystack)
    if not _text_gate_open(text, text_scores):
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    best = max(scores.values(), default=0)
    if best > 0:
        return next(t for t in MATH_0580_TOPICS if scores[t] == best)
    return None


# ---------------------------------------------------------------------------
# A-Level Further Mathematics 9231 — reference-file vocabulary, question-level
# routing (same contract as 9709).
_9231_TOPIC_KEYWORDS = {
    "Matrices": ("matrix", "matrices", "determinant", "inverse matrix"),
    "Polar_coordinates": ("polar", "r =", "pole", "initial line"),
    "Proof_by_induction": ("induction", "prove by induction", "inductive"),
    "Rational_functions_and_graphs": ("rational function", "asymptote", "oblique"),
    "Roots_of_polynomial_equations": ("roots of", "polynomial", "sum of the roots", "product of the roots"),
    "Summation_of_series": ("summation", "sum of the series", "sigma", "method of differences"),
    "Vectors": ("vector", "vectors", "cross product", "scalar product", "plane"),
    "Complex_numbers": ("complex", "argand", "modulus", "argument", "de moivre"),
    "Differential_equations": ("differential equation", "particular integral", "complementary function"),
    "Differentiation": ("differentiat", "derivative", "dy/dx", "implicit"),
    "Hyperbolic_functions": ("hyperbolic", "sinh", "cosh", "tanh"),
    "Integration": ("integrat", "integral", "reduction formula", "arc length", "surface of revolution"),
    "Circular_motion": ("circular motion", "angular speed", "angular velocity", "centripetal"),
    "Equilibrium_of_a_rigid_body": ("rigid body", "equilibrium", "moment", "centre of mass", "laminar"),
    "Linear_motion_under_a_variable_force": ("variable force", "simple harmonic", "shm", "oscillat"),
    "Momentum": ("momentum", "impulse", "collision", "restitution"),
    "Motion_of_a_projectile": ("projectile", "trajectory", "greatest height", "range on"),
    "Continuous_random_variables": ("continuous random", "density function", "cumulative distribution"),
    "Inference_using_normal_and_t-distributions": ("t-distribution", "confidence interval", "normal distribution", "pooled"),
    "Non-parametric_tests": ("non-parametric", "sign test", "wilcoxon", "rank"),
    "Probability_generating_functions": ("probability generating", "pgf", "generating function"),
    "x²_tests": ("chi-squared", "chi squared", "goodness of fit", "contingency"),
}


def classify_9231_question(text: str, paper_number: int, diagram: dict | None = None) -> str | None:
    """Question-level 9231 routing within the filename-selected paper section."""
    allowed = list(load_9231_reference().get(int(paper_number), []))
    if not allowed:
        return None
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(allowed, _9231_TOPIC_KEYWORDS, {}, haystack)
    if not _text_gate_open(text, text_scores):
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    best = max(scores.values(), default=0)
    if best > 0:
        return next(t for t in allowed if scores[t] == best)
    return None
