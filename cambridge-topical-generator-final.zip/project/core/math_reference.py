"""Mathematics 9709 reference-topic loader (9709 only).

The text file is the source of truth.  Heading text selects a paper section;
only the exact non-heading topic strings below that heading are valid JSON and
folder identifiers.  No topic identifier is normalised or rewritten.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
import re
from typing import Dict, List, Sequence

REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Mathematics_9709 References.txt"
_HEADING = re.compile(r"\(P([1-6])\)\s*$")


@lru_cache(maxsize=1)
def load_9709_reference() -> Dict[int, List[str]]:
    """Load the uploaded reference file, preserving each topic string exactly."""
    if not REFERENCE_PATH.exists():
        raise FileNotFoundError(f"Mathematics 9709 reference missing: {REFERENCE_PATH}")
    sections: Dict[int, List[str]] = {}
    current_paper: int | None = None
    for raw_line in REFERENCE_PATH.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current_paper = int(heading.group(1))
            sections.setdefault(current_paper, [])
            continue
        if current_paper is None:
            raise ValueError(f"Topic before P1–P6 heading in {REFERENCE_PATH}: {line!r}")
        # The file's literal topic spelling is canonical; never title-case,
        # replace underscores, or otherwise transform it.
        sections[current_paper].append(line)
    if set(sections) != {1, 2, 3, 4, 5, 6}:
        raise ValueError("Mathematics 9709 reference must define exactly P1 through P6")
    if any(not topics for topics in sections.values()):
        raise ValueError("Every Mathematics 9709 paper section must contain topics")
    return sections


def allowed_topics_for_paper(paper_number: int) -> List[str]:
    return list(load_9709_reference().get(int(paper_number), []))


# Matching aliases are classification evidence only. Values always come from
# the reference file and are returned unchanged.
_TOPIC_KEYWORDS = {
    "Functions": ("function", "domain", "range", "composite", "inverse function"),
    "Coordinate_geometry": ("coordinate geometry", "coordinate", "gradient", "straight line", "circle"),
    "Trignometry": ("trignometry", "trigonometry", "trigonometric", "sin ", "cos ", "tan "),
    "Trigonometry": ("trignometry", "trigonometry", "trigonometric", "sin ", "cos ", "tan "),
    "Series": ("series", "sequence", "arithmetic progression", "geometric progression"),
    "Differentiation": ("differentiation", "differentiate", "derivative", "calculus", "dy/dx"),
    "Integration": ("integration", "integrate", "integral", "area under"),
    "Circular_measure": ("circular measure", "radian", "arc length", "sector"),
    "Algebra": ("algebra", "quadratic", "polynomial", "factorise", "factorize", "inequality"),
    "Logarithmic_and_exponential_functions": ("logarithm", "log ", "exponential", "e^"),
    "Numerical_solution_of_equations": ("numerical", "iteration", "root", "solve equation"),
    "Vectors": ("vector", "vectors"),
    "Differential_equations": ("differential equation", "differential equations", "dy/dx"),
    "Complex_numbers": ("complex number", "complex numbers", "argand", "imaginary"),
    "Forces_and_equilibrium": ("force", "forces", "equilibrium", "resultant"),
    "Kinematics_of_motion_in_a_straight_line": ("kinematics", "kinematic", "velocity", "acceleration", "displacement"),
    "Momentum": ("momentum", "impulse", "collision"),
    "Newton's_laws_of_motion": ("newton", "newton's law", "newtons law"),
    "Energy,_work_and_power": ("energy", "work", "power"),
    "Representation_of_data": ("histogram", "box plot", "data", "scatter", "frequency"),
    "Permutations_and_combinations": ("permutation", "combination", "arrangement", "npr", "ncr"),
    "Probability": ("probability", "probabilities", "event", "venn"),
    "Discrete_random_variables": ("discrete random", "probability distribution", "expectation"),
    "The_normal_distribution": ("normal distribution", "normal", "standard deviation", "mean"),
    "Continuous_random_variables": ("continuous random", "density function", "probability density"),
    "Hypothesis_tests": ("hypothesis", "significance", "critical region"),
    "Linear_combinations_of_random_variables": ("linear combination", "random variables"),
    "Sampling_and_estimation": ("sampling", "estimate", "estimation"),
    "The_Poisson_distribution": ("poisson",),
}


# Distinctive terms outrank broad shared words such as "force" or "data".
# This affects only evidence scoring; returned names still come verbatim from
# the reference file.
_TOPIC_SPECIFICITY = {
    "Newton's_laws_of_motion": 3,
    "The_Poisson_distribution": 3,
    "The_normal_distribution": 3,
    "Differential_equations": 2,
    "Complex_numbers": 2,
    "Vectors": 2,
}


def classify_9709_question(text: str, paper_number: int) -> str:
    """Choose one valid topic from the filename-selected reference section."""
    allowed = allowed_topics_for_paper(paper_number)
    haystack = f" {text.lower()} "
    scores = {
        topic: sum(haystack.count(keyword) for keyword in _TOPIC_KEYWORDS.get(topic, ()))
        * _TOPIC_SPECIFICITY.get(topic, 1)
        for topic in allowed
    }
    best_score = max(scores.values(), default=0)
    if best_score > 0:
        # Reference order resolves a tie deterministically without renaming.
        return next(topic for topic in allowed if scores[topic] == best_score)
    # A valid reference topic is required even for extraction/OCR-poor questions.
    return allowed[0]

FURTHER_9231_REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Further_Mathematics_9231 Reference.txt"


def _load_paper_reference(path: Path) -> Dict[int, List[str]]:
    if not path.exists():
        raise FileNotFoundError(f"Mathematics reference missing: {path}")
    sections: Dict[int, List[str]] = {}
    current: int | None = None
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current = int(heading.group(1)); sections.setdefault(current, [])
        elif current is None:
            raise ValueError(f"Topic before paper heading in {path}: {line!r}")
        else:
            sections[current].append(line)
    return sections


@lru_cache(maxsize=1)
def load_9231_reference() -> Dict[int, List[str]]:
    sections = _load_paper_reference(FURTHER_9231_REFERENCE_PATH)
    if set(sections) != {1, 2, 3, 4} or any(not values for values in sections.values()):
        raise ValueError("Further Mathematics 9231 reference must define P1 through P4")
    return sections


def reference_topics_for_subject_paper(syllabus_code: str, paper_number: int) -> List[str]:
    """Return exact, unmodified reference entries for a staging paper."""
    code = str(syllabus_code)
    if code == "9709":
        return allowed_topics_for_paper(paper_number)
    if code == "9231":
        return list(load_9231_reference().get(int(paper_number), []))
    return []
