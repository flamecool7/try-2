"""extractor.py — NEW MODULE (Upgrade 1, spec engine v1.0)

Intelligent layered text extraction that adapts to page layout.

STATUS: standalone utility module. It is NOT consumed by the locked cropping
pipeline (question_split / multipage_optimizer / ms_cropping_engine), the ER
module, or the classifier. Its first consumer is the shadow-mode
boundary_detector (Upgrade 2, maintainer-approved shadow integration).

Spec-reconstruction fixes (documented per maintainer convention):
  FIX-E1  Paste linkification/corruption reconstructed (`__future__`,
          private method names, fitz symbols, comparison operators).
  FIX-E2  Hyphen healing restricted to lowercase letters on BOTH sides of the
          line break. The spec's `(\\w)-\\n(\\w) -> \\1\\2` corrupts numeric
          ranges that straddle a line break (e.g. "10-\\n20" -> "1020") and
          eats genuine end-of-line hyphens. `(?<=[a-z])-\\n(?=[a-z])` heals
          split words only — same convention as the ER module (FIX-5 there).
  FIX-E3  `_extract_tables`: `find_tables()` failures degrade to [] — the
          spec only caught AttributeError, but MuPDF can raise on malformed
          content streams too; table extraction is best-effort, never fatal.
  FIX-E4  `_extract_table_layout` row-grouping loop reconstructed from
          mangled paste (row key = round(y0/10)*10; tolerance 8pt) so word
          order within a row is preserved left-to-right.
  FIX-E5  Spaced-formula fixer restricted to HORIZONTAL whitespace. The
          spec's `([A-Z][a-z]?)\\s+(\\d)` lets `\\s+` match NEWLINES, so any
          line ending in a capital letter fused with a following line
          starting with a digit ("1 A\\n2 B\\n3 C" -> "1 A2 B3 C") — it
          destroyed every row boundary in the MCQ table mode this module
          exists to serve. Now `[ \\t]+`: "H 2" -> "H2", line breaks intact.
  NOTE    `_has_equations` keeps the spec's deliberately broad heuristics
          (e.g. `[A-Z][a-z]?\\d+` also matches "Q1"); conversely real math
          pages using typographic minus (U+2212) or vector-rendered equations
          may NOT trip it (observed on 9709_s22_qp_11 Q4). It is an advisory
          flag, not a gate — documented both directions at v1.0.
"""

from __future__ import annotations

import fitz
import re
import logging
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class PageLayout(Enum):
    SINGLE_COLUMN = "single_column"
    TWO_COLUMN = "two_column"  # rare but exists in some ER PDFs
    TABLE_DOMINANT = "table"   # MCQ mark scheme grids
    MIXED = "mixed"


@dataclass
class ExtractedPage:
    page_num: int
    layout: PageLayout
    raw_text: str          # Full text, reading-order corrected
    blocks: List[dict]     # Structured block data
    tables: List[List]     # Detected table structures
    drawings: List[dict]   # Vector drawing metadata
    has_diagrams: bool
    has_equations: bool
    word_count: int


class IntelligentExtractor:
    """
    Multi-mode PDF extractor that detects page layout and applies the optimal
    extraction strategy per page.
    """

    # Reading order sort: top-to-bottom, left-to-right
    # with column detection for two-column layouts
    COLUMN_SPLIT_THRESHOLD = 0.45  # fraction of page width

    @classmethod
    def extract_page(
        cls,
        page: fitz.Page,
        scale_x: float = 1.0,
        scale_y: float = 1.0,
    ) -> ExtractedPage:
        """Extract all content from a page using the optimal strategy."""
        # Layer 1: Detect layout
        layout = cls._detect_layout(page)

        # Layer 2: Extract based on layout
        if layout == PageLayout.TABLE_DOMINANT:
            raw_text, blocks = cls._extract_table_layout(page)
        elif layout == PageLayout.TWO_COLUMN:
            raw_text, blocks = cls._extract_two_column(page)
        else:
            raw_text, blocks = cls._extract_single_column(page)

        # Layer 3: Extract drawings metadata
        drawings = page.get_drawings()

        # Layer 4: Detect content types
        has_diagrams = cls._has_diagrams(drawings, page)
        has_equations = cls._has_equations(raw_text)

        # Layer 5: Fix common extraction errors
        raw_text = cls._fix_extraction_errors(raw_text)

        return ExtractedPage(
            page_num=page.number,
            layout=layout,
            raw_text=raw_text,
            blocks=blocks,
            tables=cls._extract_tables(page),
            drawings=drawings,
            has_diagrams=has_diagrams,
            has_equations=has_equations,
            word_count=len(raw_text.split()),
        )

    @classmethod
    def _detect_layout(cls, page: fitz.Page) -> PageLayout:
        """Detect page layout by analyzing text block x-positions."""
        blocks = page.get_text("blocks")
        if not blocks:
            return PageLayout.SINGLE_COLUMN

        page_width = page.rect.width

        # Check for table (MCQ mark scheme grid)
        text = page.get_text("text")
        mcq_grid = re.findall(r"\b[1-9]\d?\s+[ABCD]\b", text)
        if len(mcq_grid) >= 5:
            return PageLayout.TABLE_DOMINANT

        # Check for two-column layout
        x_centers = []
        for b in blocks:
            if b[6] == 0:  # text block
                x_center = (b[0] + b[2]) / 2
                x_centers.append(x_center / page_width)

        if not x_centers:
            return PageLayout.SINGLE_COLUMN

        left_blocks = sum(1 for x in x_centers if x < cls.COLUMN_SPLIT_THRESHOLD)
        right_blocks = sum(1 for x in x_centers if x > (1 - cls.COLUMN_SPLIT_THRESHOLD))

        if left_blocks >= 3 and right_blocks >= 3:
            return PageLayout.TWO_COLUMN

        return PageLayout.SINGLE_COLUMN

    @classmethod
    def _extract_single_column(
        cls, page: fitz.Page
    ) -> Tuple[str, List[dict]]:
        """
        Standard single-column extraction with reading order correction.
        Uses 'dict' mode for maximum structure preservation.
        """
        data = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)
        blocks = data.get("blocks", [])

        # Sort blocks top-to-bottom
        text_blocks = [b for b in blocks if b.get("type") == 0]
        text_blocks.sort(key=lambda b: (b["bbox"][1], b["bbox"][0]))

        lines_out = []
        for block in text_blocks:
            for line in block.get("lines", []):
                line_text = ""
                for span in line.get("spans", []):
                    line_text += span.get("text", "")
                if line_text.strip():
                    lines_out.append(line_text)

        return "\n".join(lines_out), blocks

    @classmethod
    def _extract_two_column(
        cls, page: fitz.Page
    ) -> Tuple[str, List[dict]]:
        """Two-column extraction: sort left column first, then right."""
        data = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)
        blocks = data.get("blocks", [])

        page_width = page.rect.width
        mid = page_width * cls.COLUMN_SPLIT_THRESHOLD

        left_blocks = []
        right_blocks = []
        for b in blocks:
            if b.get("type") != 0:
                continue
            x_center = (b["bbox"][0] + b["bbox"][2]) / 2
            if x_center < mid:
                left_blocks.append(b)
            else:
                right_blocks.append(b)

        # Sort each column top-to-bottom
        left_blocks.sort(key=lambda b: b["bbox"][1])
        right_blocks.sort(key=lambda b: b["bbox"][1])

        all_blocks = left_blocks + right_blocks

        lines_out = []
        for block in all_blocks:
            for line in block.get("lines", []):
                line_text = "".join(
                    span.get("text", "") for span in line.get("spans", [])
                )
                if line_text.strip():
                    lines_out.append(line_text)

        return "\n".join(lines_out), blocks

    @classmethod
    def _extract_table_layout(
        cls, page: fitz.Page
    ) -> Tuple[str, List[dict]]:
        """
        Table-dominant extraction (MCQ mark scheme grids).
        Uses 'words' mode to preserve column alignment.
        FIX-E4: row key = round(y0/10)*10, new row when |y - current| > 8,
        words inside a row stay left-to-right (pre-sorted by x0).
        """
        words = page.get_text("words")
        # Sort by row then column
        words.sort(key=lambda w: (round(w[1] / 10), w[0]))

        lines_out = []
        current_y = None
        current_line = []
        for word in words:
            y = round(word[1] / 10) * 10
            if current_y is None:
                current_y = y
            if abs(y - current_y) > 8:
                if current_line:
                    lines_out.append(" ".join(current_line))
                current_line = [word[4]]
                current_y = y
            else:
                current_line.append(word[4])
        if current_line:
            lines_out.append(" ".join(current_line))

        data = page.get_text("dict")
        blocks = data.get("blocks", [])
        return "\n".join(lines_out), blocks

    @classmethod
    def _extract_tables(cls, page: fitz.Page) -> List[List]:
        """
        Attempt structured table extraction using PyMuPDF's find_tables()
        method (available in PyMuPDF >= 1.23.0).
        FIX-E3: degrade to [] on ANY failure, not just AttributeError.
        """
        try:
            tabs = page.find_tables()
            return [tab.extract() for tab in tabs.tables]
        except Exception:
            # find_tables unavailable or content stream too irregular;
            # table extraction is best-effort, never fatal.
            return []

    @classmethod
    def _has_diagrams(
        cls,
        drawings: List[dict],
        page: fitz.Page,
    ) -> bool:
        """
        Detect if a page contains significant diagrams (not just table lines
        or borders).
        """
        if len(drawings) > 20:
            return True

        # Check for image objects embedded in page
        image_list = page.get_images(full=True)
        if image_list:
            return True

        return False

    @classmethod
    def _has_equations(cls, text: str) -> bool:
        """Detect mathematical/chemical equations in text (advisory, broad)."""
        equation_signals = [
            r"\d+\s*[+\-×÷=]\s*\d+",   # arithmetic
            r"[A-Z][a-z]?\d+",          # chemical formula
            r"d[A-Z]/d[a-z]",           # calculus
            r"∫|∑|√|≈|≠|≤|≥",      # math symbols
            r"mol\s*dm",                # concentration units
            r"kJ\s*mol",                # energy units
        ]
        for pattern in equation_signals:
            if re.search(pattern, text):
                return True
        return False

    @classmethod
    def _fix_extraction_errors(cls, text: str) -> str:
        """Fix common PyMuPDF extraction artifacts."""
        # Fix ligatures (explicit codepoints — never rely on source encoding)
        ligatures = {
            "ﬁ": "fi",
            "ﬂ": "fl",
            "ﬀ": "ff",
            "ﬃ": "ffi",
            "ﬄ": "ffl",
            " ": " ",
        }
        for lig, rep in ligatures.items():
            text = text.replace(lig, rep)

        # FIX-E2: heal hyphenated line breaks for lowercase word splits only.
        # The spec's (\w)-\n(\w) corrupted numeric ranges ("10-\n20" -> "1020")
        # and genuine end-of-line hyphens. Same convention as the ER module.
        text = re.sub(r"(?<=[a-z])-\n(?=[a-z])", "", text)

        # Fix spaced chemical formulas (FIX-E5: horizontal whitespace only —
        # a generic \s+ here eats newlines and fuses adjacent lines, e.g.
        # "1 A\n2 B" -> "1 A2 B" in MCQ grids).
        text = re.sub(r"([A-Z][a-z]?)[ \t]+(\d)", r"\1\2", text)

        # Fix unicode subscripts
        sub_map = str.maketrans(
            "₀₁₂₃₄₅₆₇₈₉",
            "0123456789",
        )
        text = text.translate(sub_map)

        # Collapse excessive whitespace
        text = re.sub(r"[ \t]{2,}", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)

        return text
