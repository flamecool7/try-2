from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

@dataclass
class Config:
    input_dir: str = "papers"
    output_dir: str = "Cambridge_Question_Bank"
    subject: Optional[str] = None
    syllabus_code: Optional[str] = None
    level: Optional[str] = None
    board: str = "CIE"
    session: Optional[str] = None
    year: Optional[int] = None
    dpi: int = 200
    webp_quality: int = 88
    dedup_hamming: int = 8
    mode: str = "auto"
    syllabus_pdf: Optional[str] = None
    topics_json: Optional[str] = None
    include_mark_schemes: bool = True
    paper_types: Optional[list] = None
    freeconvert_api_key: Optional[str] = None

    # --- Configurable crop values (pixels) ---
    # Applied to every question-paper page after conversion (2480×3508 input)
    crop_top: int = 251
    crop_bottom: int = 231
    crop_left: int = 100
    crop_right: int = 100

    # Formula / data sheet position safeguard
    formula_sheet_max_page: int = 3   # only consider formula/data sheets valid if within first N pages (0-indexed)

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def load(path: str | Path) -> "Config":
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Config not found: {p}")
        data = json.loads(p.read_text(encoding="utf-8"))
        known = {f for f in Config.__dataclass_fields__}
        return Config(**{k: v for k, v in data.items() if k in known})

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(self.to_dict(), indent=2), encoding="utf-8")
