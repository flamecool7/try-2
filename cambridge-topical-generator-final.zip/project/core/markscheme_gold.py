"""Mark-scheme processing and exact question pairing.

Structured papers use :mod:`cambridge_qb.markscheme_split`, an independent
pipeline that renders mark-scheme pages without the question-paper fixed crop,
detects top-level question labels, segments shared/continuation pages and
returns exactly one assembled image per question number.

The compact MCQ answer-grid parser is retained for subjects whose Paper 1 is
actually multiple choice. Cambridge Computer Science 9618 Paper 1 is not MCQ.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, Iterable, Tuple, Union

from PIL import Image

from .pdf_io import (
    _upright_bbox,
    detect_footer_y,
    detect_header_y,
    page_is_usable,
    render_pdf_with_rotation_info,
)
from .reference import canonical_season

_ANSWER_LETTER = re.compile(r"^[A-D]$")

# 9618 is intentionally absent: Paper 1 is structured Theory Fundamentals.
_MCQ_P1_SYLLABI = frozenset({
    "9701", "9702", "9700", "9708", "9608", "9696",
})


def mark_scheme_key(paper_code: str, question_number: str | int,
                    session_label: str = "", year: int = 0) -> tuple:
    """Build a collision-safe mark-scheme key.

    Variant and question alone collide across exam sessions. Recognised files
    therefore use ``(variant, session, year, question)``. The two-part form is
    retained only as a fallback for unrecognised filenames.
    """
    code = str(paper_code or "").lstrip("0") or str(paper_code or "")
    question = str(question_number)
    if session_label and year:
        return (code, str(session_label), int(year), question)
    return (code, question)


def lookup_mark_scheme(index: dict, *, paper_code: str,
                       question_number: str | int,
                       session_label: str = "", year: int = 0):
    """Look up the exact paper identity, then a legacy key if one exists."""
    exact = mark_scheme_key(paper_code, question_number, session_label, year)
    if exact in index:
        return index[exact]
    return index.get(mark_scheme_key(paper_code, question_number))


def _is_mcq_paper(paper_code: str, syllabus: str | None = None) -> bool:
    code = str(paper_code or "").lstrip("0")
    if not code or code[0] != "1":
        return False
    return syllabus in _MCQ_P1_SYLLABI if syllabus is not None else True


def _parse_mcq_answers(doc, images) -> Dict[int, str]:
    """Read number/letter pairs from a conventional Cambridge MCQ grid."""
    answers: Dict[int, str] = {}
    for page_index, page in enumerate(doc):
        if not page_is_usable(images[page_index]):
            continue
        top = detect_header_y(page)
        bottom = detect_footer_y(page)
        words = []
        for raw in page.get_text("words"):
            x0, y0, x1, y1, text, *_ = raw
            (ux0, uy0), (ux1, uy1) = _upright_bbox(x0, y0, x1, y1, page)
            value = (text or "").strip()
            if not value or uy1 < top - 2 or uy0 > bottom + 2:
                continue
            words.append((value, ux0, uy0, ux1, uy1))
        words.sort(key=lambda item: (round(item[2] / 3.0), item[1]))

        for index, number_word in enumerate(words):
            if not number_word[0].isdigit():
                continue
            number = int(number_word[0])
            if not 1 <= number <= 99:
                continue
            ncy = (number_word[2] + number_word[4]) / 2.0
            line_height = max(6.0, number_word[4] - number_word[2])
            options = []
            for letter_word in words[index + 1:index + 14]:
                letter = letter_word[0].upper()
                if not _ANSWER_LETTER.match(letter):
                    continue
                lcy = (letter_word[2] + letter_word[4]) / 2.0
                dx = letter_word[1] - number_word[3]
                if abs(lcy - ncy) <= line_height * 1.5 and -3 <= dx <= 100:
                    options.append((dx, letter))
            if options:
                answers.setdefault(number, min(options)[1])
    return answers


def _paper_identity_from_filename(path: Path):
    match = re.search(
        r"(\d{4})[_ -]?([swm])(\d{2})[_ -]?"
        r"(qp|ms|er|ir|gt)[_ -]?0?(\d{1,3})",
        path.stem, re.IGNORECASE,
    )
    if match:
        paper_code = match.group(5).lstrip("0") or match.group(5)
        session_label = canonical_season({
            "s": "Summer", "w": "Winter", "m": "March",
        }.get(match.group(2).lower(), ""))
        year = 2000 + int(match.group(3))
        return paper_code, session_label, year
    parts = path.stem.split("_")
    paper_code = (parts[-1].lstrip("0") or parts[-1]) if parts else path.stem
    return paper_code, "", 0


def process_mark_schemes(ms_pdfs, qp_paper_codes=(), dpi: int = 200,
                         syllabus: str | None = None,
                         expected_questions=None,
                         diagnostics_out: list | None = None,
                         ) -> Dict[tuple, Union[str, Image.Image]]:
    """Generate one mark-scheme entry per top-level question.

    ``expected_questions`` should map ``(variant, session, year)`` to the
    top-level numbers detected in the matching question paper. Structured
    segmentation is rejected if any expected marker is missing, preventing the
    legacy failure where Q1-Q7 became one large image assigned to Q1.
    """
    from .markscheme_split import split_structured_mark_scheme

    index: Dict[tuple, Union[str, Image.Image]] = {}
    expected_questions = expected_questions or {}

    for source in ms_pdfs:
        pdf = Path(source)
        paper_code, session_label, year = _paper_identity_from_filename(pdf)
        identity = (str(paper_code).lstrip("0"), session_label, year)
        expected = expected_questions.get(identity)
        if expected is None:
            expected = expected_questions.get(paper_code)
        if expected is None:
            expected = expected_questions.get(str(paper_code).lstrip("0"))

        if _is_mcq_paper(paper_code, syllabus=syllabus):
            images, _scale, _rotations, doc = render_pdf_with_rotation_info(pdf, dpi=dpi)
            try:
                answers = _parse_mcq_answers(doc, images)
            finally:
                doc.close()
            for number, letter in answers.items():
                index[mark_scheme_key(
                    paper_code, number, session_label, year
                )] = letter.upper()
            print(f"[ms] {pdf.name}: parsed {len(answers)} MCQ answers")
            continue

        images_by_question, diagnostics = split_structured_mark_scheme(
            pdf,
            dpi=dpi,
            expected_question_numbers=expected,
        )
        if diagnostics_out is not None:
            diagnostics_out.append({
                "file": pdf.name,
                "paper_code": paper_code,
                "session": session_label,
                "year": year,
                "found": list(diagnostics.markers_found),
                "expected": list(diagnostics.expected_questions),
                "missing": list(diagnostics.missing_questions),
                "unexpected": list(diagnostics.unexpected_questions),
                "warnings": list(diagnostics.warnings),
                "unsafe_boundaries": list(diagnostics.unsafe_boundaries),
                "header_bands_removed": diagnostics.header_bands,
                "content_blocks": diagnostics.content_blocks,
                "split_notes": list(diagnostics.split_notes),
                "generated": sorted(images_by_question),
            })
        for note in diagnostics.split_notes:
            print(f"  [ms-split] {note}")
        for warning in diagnostics.warnings:
            print(f"[ms] WARNING: {pdf.name}: {warning}")

        if not images_by_question:
            print(
                f"[ms] ERROR: {pdf.name}: no structured mark schemes written "
                f"(found={diagnostics.markers_found}, "
                f"missing={diagnostics.missing_questions}, "
                f"unexpected={diagnostics.unexpected_questions}, "
                f"unsafe={diagnostics.unsafe_boundaries})"
            )
            continue

        for number, image in sorted(images_by_question.items()):
            index[mark_scheme_key(
                paper_code, number, session_label, year
            )] = image
        print(
            f"[ms] {pdf.name}: generated {len(images_by_question)} independent "
            f"question images: {sorted(images_by_question)}"
        )

    return index


def paper_type(paper_code: str, syllabus: str | None = None) -> str:
    return "mcq" if _is_mcq_paper(paper_code, syllabus=syllabus) else "structured"


PAPER_LABELS = {
    1: "MCQ (Paper 1)",
    2: "AS Structured (Paper 2)",
    3: "Advanced Practical Skills (Paper 3)",
    4: "A Level Structured (Paper 4)",
    5: "Planning, Analysis & Evaluation (Paper 5)",
    6: "Alternative to Practical (Paper 6)",
}

CS_9618_PAPER_LABELS = {
    1: "Theory Fundamentals (Paper 1)",
    2: "Fundamental Problem-solving and Programming Skills (Paper 2)",
    3: "Advanced Theory (Paper 3)",
    4: "Practical (Paper 4)",
}


def paper_label(paper_code: str, syllabus: str | None = None) -> str:
    code = str(paper_code or "").lstrip("0")
    if not code or not code[0].isdigit():
        return "Unknown"
    number = int(code[0])
    if syllabus == "9618":
        return CS_9618_PAPER_LABELS.get(number, f"Paper {number}")
    return PAPER_LABELS.get(number, f"Paper {number}")
