"""boundary_detector.py — NEW MODULE (Upgrade 2, SHADOW MODE — maintainer-approved)

Detects question boundaries using 5 independent signals, then votes on the
most reliable answer.

STATUS: SHADOW ONLY. This module is imported by NOTHING in production. The
locked cropping pipeline (question_split triplet) keeps its own approved
marker detection; this detector runs beside it in the test harness and a
disagreement report decides whether an Amendment (replacement of locked
detection) is ever proposed. See test-crops/bnd-shadow/.

Spec-reconstruction fixes (documented per maintainer convention):
  FIX-B1  Phantom unnumbered boundaries. The spec confirmed any cluster with
          total confidence >= 1.5 — a [Total] bracket (0.70) + whitespace gap
          (0.55) + ink gap (0.60) = 1.85 would confirm a boundary with
          question_num "?" MID-QUESTION (every question end followed by a gap
          qualifies). Fix: a cluster only CONFIRMS a boundary when it contains
          at least one NUMBERED signal (text_pattern or font/bold jump with a
          parsed number); unnumbered clusters are reported separately as
          end-of-question hints, never as confirmed boundaries. This matches
          the locked pipeline's philosophy: a split needs a question number.
  FIX-B2  Font-jump detector. Cambridge question numbers are typically BOLD
          at body size, not larger: the spec's size-ratio signal barely fires
          on real papers. Added the bold-flag variant
          (span flags & 16, bare number at/near left margin, size >= body).
  FIX-B3  Paste linkification/corruption reconstructed (`__future__`,
          private method names, fitz symbols, comparison operators).
  FIX-B4  `_find_y_for_text` anchored to LINE START. The spec's substring
          search (`target in line_text`, dict iteration order) hijacked bare
          numbers to the first line CONTAINING the digit — e.g. Bio 9700 page
          6 returned y=798.8 (a "2" inside body text near the [Total] line)
          instead of y=64.1 for the "2 …" marker line, producing DRIFT+EXTRA
          split errors in the shadow report. A question number can only head
          a line, so matching now requires the target to start the stripped
          line (longest-prefix-first tie-break), and falls back to substring
          only when nothing anchored exists.
  NOTE    End-of-last-question (`rect.height - 80`) and confidence capping
          kept per spec; shadow report only — these values feed no crop.
"""

from __future__ import annotations

import re
import logging
import numpy as np
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict
from PIL import Image
import fitz

logger = logging.getLogger(__name__)


@dataclass
class BoundarySignal:
    """A single piece of evidence for a question boundary."""
    y_pdf: float            # PDF coordinate of boundary
    page_idx: int           # Page index
    confidence: float       # 0.0 - 1.0
    source: str             # Which detector found this
    question_num: Optional[str]  # Detected question number if any


@dataclass
class QuestionBoundary:
    """Confirmed question boundary after signal voting."""
    question_num: str
    start_page: int
    start_y_pdf: float
    end_page: int
    end_y_pdf: float
    confidence: float
    signals_used: List[str]


class MultisignalBoundaryDetector:
    """
    Detects question start/end boundaries using 5 independent signals:

    Signal 1: TEXT PATTERN — "1", "2(a)", "Question 1" etc in text
    Signal 2: FONT SIZE JUMP / BOLD FLAG — Question numbers are bold/larger than body (FIX-B2)
    Signal 3: WHITESPACE GAP — Large vertical gap before new question
    Signal 4: MARKS BRACKET — [Total: N] marks bracket ends a question
    Signal 5: INK DENSITY — Raster scan for horizontal white bands
    """

    # Question number text patterns (ordered: most specific first)
    Q_NUM_PATTERNS = [
        # "1 (a)" or "1(a)" at line start
        re.compile(r"^(\d{1,2})\s*\([a-z]\)", re.MULTILINE),
        # Bare "1" at line start followed by text/bracket
        re.compile(r"^(\d{1,2})\s+(?=[A-Z(])", re.MULTILINE),
        # "Question 1" format
        re.compile(r"^Question\s+(\d{1,2})\s*$", re.MULTILINE | re.IGNORECASE),
    ]

    # Marks total pattern
    TOTAL_MARKS_PATTERN = re.compile(
        r"\[Total\s*:\s*\d+\s*\]", re.IGNORECASE
    )

    # Minimum whitespace gap to signal new question (PDF points)
    MIN_WHITESPACE_GAP_PT = 18.0

    # Font size ratio: question number font / body font
    # Cambridge uses ~14pt for Q numbers, ~11pt for body = ratio ~1.27
    FONT_SIZE_RATIO_THRESHOLD = 1.2

    def __init__(
        self,
        pages: List[fitz.Page],
        page_images: List[Image.Image],
        scale_y: float,
    ):
        self.pages = pages
        self.page_images = page_images
        self.scale_y = scale_y
        self._body_font_size = self._detect_body_font_size()

    def detect_all_boundaries(self) -> Tuple[List[QuestionBoundary], List[BoundarySignal]]:
        """
        Run all 5 detectors, vote, and return:
          (confirmed boundaries sorted by page and y-position,
           ALL raw signals — including unconfirmed clusters — for shadow reporting).
        """
        all_signals: List[BoundarySignal] = []

        for page_idx, page in enumerate(self.pages):
            # Signal 1: Text patterns
            all_signals += self._detect_text_patterns(page, page_idx)
            # Signal 2: Font size jumps / bold flags
            all_signals += self._detect_font_jumps(page, page_idx)
            # Signal 3: Marks brackets (end-of-question signal)
            all_signals += self._detect_marks_brackets(page, page_idx)
            # Signal 4: Whitespace gaps
            all_signals += self._detect_whitespace_gaps(page, page_idx)

        # Signal 5: Ink density scan (raster-based)
        all_signals += self._detect_ink_density_gaps()

        # Vote and consolidate
        boundaries = self._vote_and_consolidate(all_signals)

        logger.info(
            f"Detected {len(boundaries)} question boundaries "
            f"from {len(all_signals)} signals"
        )
        return boundaries, all_signals

    def _detect_text_patterns(
        self,
        page: fitz.Page,
        page_idx: int,
    ) -> List[BoundarySignal]:
        """Signal 1: Find question numbers via text pattern matching."""
        signals = []
        text = page.get_text("text")
        blocks = page.get_text("dict").get("blocks", [])

        # Build a map of text → y position
        text_y_map = {}
        for block in blocks:
            if block.get("type") != 0:
                continue
            for line in block.get("lines", []):
                line_text = "".join(
                    s.get("text", "") for s in line.get("spans", [])
                ).strip()
                if line_text:
                    y = line["bbox"][1]
                    text_y_map[line_text] = y

        for pattern in self.Q_NUM_PATTERNS:
            for match in pattern.finditer(text):
                qnum = match.group(1)
                # Find the y-position of this match
                matched_text = match.group(0).strip()
                y_pdf = self._find_y_for_text(
                    matched_text, text_y_map, blocks
                )
                if y_pdf is not None:
                    signals.append(BoundarySignal(
                        y_pdf=y_pdf,
                        page_idx=page_idx,
                        confidence=0.85,
                        source="text_pattern",
                        question_num=qnum,
                    ))

        return signals

    def _detect_font_jumps(
        self,
        page: fitz.Page,
        page_idx: int,
    ) -> List[BoundarySignal]:
        """
        Signal 2: Detect lines where font size is significantly larger than
        body text (question numbers are typically bold/larger).
        FIX-B2: also accept BOLD flag at body-ish size for bare numbers at
        the left margin — Cambridge markers are often bold, same size.
        """
        signals = []
        blocks = page.get_text("dict").get("blocks", [])
        body_fs = self._body_font_size
        page_width = page.rect.width or 1.0

        for block in blocks:
            if block.get("type") != 0:
                continue
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    fs = span.get("size", 0)
                    flags = span.get("flags", 0)
                    text = span.get("text", "").strip()

                    if not re.match(r"^\d{1,2}$", text):
                        continue

                    near_left_margin = span["bbox"][0] < 0.20 * page_width
                    is_larger = fs > body_fs * self.FONT_SIZE_RATIO_THRESHOLD
                    is_bold = bool(flags & 16) and fs >= body_fs - 0.5

                    if is_larger or (is_bold and near_left_margin):
                        signals.append(BoundarySignal(
                            y_pdf=line["bbox"][1],
                            page_idx=page_idx,
                            confidence=0.75 if is_larger else 0.70,
                            source="font_size_jump",
                            question_num=text,
                        ))

        return signals

    def _detect_marks_brackets(
        self,
        page: fitz.Page,
        page_idx: int,
    ) -> List[BoundarySignal]:
        """
        Signal 3: [Total: N] bracket marks the END of a question.
        The next question starts shortly after.
        """
        signals = []
        blocks = page.get_text("dict").get("blocks", [])

        for block in blocks:
            if block.get("type") != 0:
                continue
            for line in block.get("lines", []):
                line_text = "".join(
                    s.get("text", "") for s in line.get("spans", [])
                )

                if self.TOTAL_MARKS_PATTERN.search(line_text):
                    # End of question is at this y + line height
                    y_end = line["bbox"][3]
                    signals.append(BoundarySignal(
                        y_pdf=y_end + self.MIN_WHITESPACE_GAP_PT,
                        page_idx=page_idx,
                        confidence=0.70,
                        source="marks_bracket_end",
                        question_num=None,  # We know end, not start number
                    ))

        return signals

    def _detect_whitespace_gaps(
        self,
        page: fitz.Page,
        page_idx: int,
    ) -> List[BoundarySignal]:
        """
        Signal 4: Large vertical whitespace gaps between text blocks
        indicate question boundaries.
        """
        signals = []
        blocks = page.get_text("dict").get("blocks", [])
        text_blocks = [b for b in blocks if b.get("type") == 0]
        text_blocks.sort(key=lambda b: b["bbox"][1])

        for i in range(1, len(text_blocks)):
            prev_bottom = text_blocks[i-1]["bbox"][3]
            curr_top = text_blocks[i]["bbox"][1]
            gap = curr_top - prev_bottom

            if gap >= self.MIN_WHITESPACE_GAP_PT:
                signals.append(BoundarySignal(
                    y_pdf=curr_top,
                    page_idx=page_idx,
                    confidence=0.55,
                    source="whitespace_gap",
                    question_num=None,
                ))

        return signals

    def _detect_ink_density_gaps(self) -> List[BoundarySignal]:
        """
        Signal 5: Raster scan of rendered images for horizontal
        bands with very low ink density (white gaps = question boundaries).
        """
        signals = []
        INK_DARK = 200  # pixel value below this = ink
        MIN_GAP = 15    # px of whitespace to qualify as gap

        for page_idx, img in enumerate(self.page_images):
            if img is None:
                continue
            arr = np.array(img.convert("L"))
            if arr.shape[0] < 300 or arr.shape[1] < 300:
                continue

            # Only scan content area (exclude header/footer zones)
            content = arr[120:-80, 100:-100]

            # Row-wise ink density
            ink_per_row = np.sum(content < INK_DARK, axis=1)
            white_rows = ink_per_row < 3  # nearly empty rows

            # Find runs of white rows
            in_gap = False
            gap_start = 0
            for row_idx, is_white in enumerate(white_rows):
                if is_white and not in_gap:
                    in_gap = True
                    gap_start = row_idx
                elif not is_white and in_gap:
                    gap_len = row_idx - gap_start
                    if gap_len >= MIN_GAP:
                        # Convert pixel row back to PDF y coordinate
                        pixel_row = gap_start + gap_len // 2 + 120  # re-add header offset
                        y_pdf = pixel_row / self.scale_y
                        signals.append(BoundarySignal(
                            y_pdf=y_pdf,
                            page_idx=page_idx,
                            confidence=0.60,
                            source="ink_density_gap",
                            question_num=None,
                        ))
                    in_gap = False

        return signals

    def _vote_and_consolidate(
        self,
        signals: List[BoundarySignal],
    ) -> List[QuestionBoundary]:
        """
        Group signals that are close together (within 20 PDF points)
        and vote on the best boundary position and question number.

        A boundary is CONFIRMED if its cluster contains at least one NUMBERED
        signal (FIX-B1: unnumbered clusters — e.g. [Total] bracket + gap +
        ink gap = 1.85 total — would otherwise manufacture mid-question
        boundaries with question_num "?"; they are reported as end-of-question
        hints instead, never confirmed).
        """
        if not signals:
            return []

        # Sort by page then y position
        signals.sort(key=lambda s: (s.page_idx, s.y_pdf))

        CLUSTER_TOLERANCE = 20.0  # PDF points

        # Cluster nearby signals
        clusters: List[List[BoundarySignal]] = []
        current_cluster = [signals[0]]

        for sig in signals[1:]:
            prev = current_cluster[-1]
            same_page = sig.page_idx == prev.page_idx
            close_y = abs(sig.y_pdf - prev.y_pdf) <= CLUSTER_TOLERANCE

            if same_page and close_y:
                current_cluster.append(sig)
            else:
                clusters.append(current_cluster)
                current_cluster = [sig]

        clusters.append(current_cluster)

        # Convert clusters to confirmed boundaries
        confirmed: List[QuestionBoundary] = []

        for cluster in clusters:
            total_confidence = sum(s.confidence for s in cluster)
            sources = [s.source for s in cluster]

            # Get the best y estimate (weighted average by confidence)
            y_weighted = sum(
                s.y_pdf * s.confidence for s in cluster
            ) / total_confidence

            # Get question number (from highest confidence signal that has one)
            numbered = [s for s in cluster if s.question_num is not None]
            numbered.sort(key=lambda s: s.confidence, reverse=True)
            qnum = numbered[0].question_num if numbered else None

            # FIX-B1: confirm only numbered clusters; single numbered signal
            # must be a text_pattern (spec rule), multi-signal clusters must
            # clear 1.5 total confidence AND contain a number.
            has_text_pattern = any(
                s.source == "text_pattern" for s in cluster
            )
            sufficient_confidence = total_confidence >= 1.5
            numbered_present = qnum is not None

            if numbered_present and (has_text_pattern or sufficient_confidence):
                confirmed.append(QuestionBoundary(
                    question_num=qnum,
                    start_page=cluster[0].page_idx,
                    start_y_pdf=y_weighted,
                    end_page=cluster[0].page_idx,  # filled in next pass
                    end_y_pdf=0.0,                 # filled in next pass
                    confidence=min(total_confidence, 1.0),
                    signals_used=sources,
                ))
            elif not numbered_present and sufficient_confidence:
                logger.debug(
                    f"[shadow] unnumbered cluster (p{cluster[0].page_idx + 1}, "
                    f"y={y_weighted:.1f}, conf={total_confidence:.2f}, "
                    f"{sources}) — reported as end-hint, NOT confirmed (FIX-B1)"
                )

        # Fill in end boundaries (each question ends where next starts)
        for i in range(len(confirmed) - 1):
            confirmed[i].end_page = confirmed[i+1].start_page
            confirmed[i].end_y_pdf = confirmed[i+1].start_y_pdf

        # Last question ends at bottom of last page (shadow-report value only)
        if confirmed:
            last_page = self.pages[-1]
            confirmed[-1].end_page = len(self.pages) - 1
            confirmed[-1].end_y_pdf = last_page.rect.height - 80

        return confirmed

    def _find_y_for_text(
        self,
        target_text: str,
        text_y_map: Dict[str, float],
        blocks: List[dict],
    ) -> Optional[float]:
        """Find the y-coordinate of a specific text string.

        FIX-B4: anchored matching — question numbers head their line, so a
        target must START a stripped line (longest-prefix tie-break). The
        spec's bare substring search hijacked bare numbers to any line that
        merely contained the digit (mid-body "2" near a [Total] bracket),
        corrupting the boundary y. Substring is kept only as a last resort.
        """
        target = target_text.strip()

        # Pass 1 (anchored): line starts with the target; prefer the longest
        # anchored prefix, then the topmost occurrence on the page.
        anchored: List[Tuple[int, float]] = []
        for text, y in text_y_map.items():
            stripped = text.strip()
            if stripped.startswith(target):
                anchored.append((len(stripped), y))
        if anchored:
            anchored.sort(key=lambda t: (-t[0], t[1]))
            return anchored[0][1]

        # Pass 2 (last resort, spec behavior): substring containment.
        for block in blocks:
            if block.get("type") != 0:
                continue
            for line in block.get("lines", []):
                line_text = "".join(
                    s.get("text", "") for s in line.get("spans", [])
                )
                if target in line_text:
                    return line["bbox"][1]

        return None

    def _detect_body_font_size(self) -> float:
        """Detect the median body font size across all pages."""
        sizes = []
        for page in self.pages:
            for block in page.get_text("dict").get("blocks", []):
                if block.get("type") != 0:
                    continue
                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        fs = span.get("size", 0)
                        if 7.0 <= fs <= 16.0:
                            sizes.append(fs)
        if not sizes:
            return 11.0  # Cambridge default body font
        return float(np.median(sizes))
