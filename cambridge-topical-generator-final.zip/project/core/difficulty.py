"""Difficulty scoring for matched questions (final-upgrade Issue 4).

Approved design (2026-08-10): replaces the spec's hard 10-mark cap with a
logarithmic scale that plateaus naturally — a 20-mark question is longer,
not necessarily harder, so marks must not map linearly onto difficulty.

Formula (directive-specified):

    score = 1.0 + (log2(total_marks) / log2(30)) * 4.0, capped at 5.0

Reference points (actual computed values):
    1 mark  -> 1.00     5 marks  -> 2.89     10 marks -> 3.71
    20 marks -> 4.52    30 marks -> 5.00     >30 marks -> 5.00 (cap)
    <= 0    -> 1.00 (defensive floor)

This module is intentionally standalone: the quality scorer (Upgrade 5)
will consume `mark_to_difficulty`. Upgrade-5 design notes recorded here on
maintainer instruction:
  - subject-path normalisation (final-upgrade Issue 8): the future scorer
    must normalise subject strings ("Chemistry" / "Chemistry_9701" /
    "Chemistry 9701") against existing output directories with a loud
    fuzzy-match log, and error loudly instead of silently returning {}.
  - ER dimension is N/A when no ER PDF was supplied; its weight is
    redistributed across the remaining dimensions.
"""
import math

MIN_SCORE = 1.0
MAX_SCORE = 5.0
# Marks value at which the log scale reaches MAX_SCORE: 1+4=5 at 30 marks.
_PLATEAU_MARKS = 30


def mark_to_difficulty(total_marks: int) -> float:
    """Map a question's total marks onto a 1.0–5.0 difficulty score.

    Logarithmic; equal ratios of marks produce equal score increments, so
    long-but-standard questions stop gaining difficulty past ~30 marks
    instead of being jammed against a hard cap.
    """
    try:
        marks = int(total_marks)
    except (TypeError, ValueError):
        return MIN_SCORE
    if marks <= 0:
        return MIN_SCORE
    score = MIN_SCORE + (math.log(marks, 2) / math.log(_PLATEAU_MARKS, 2)) * (
        MAX_SCORE - MIN_SCORE
    )
    return round(min(score, MAX_SCORE), 2)
