"""
pdf_io.py
=========
High-fidelity PDF -> image rendering using PyMuPDF (fitz).

Key features (from the working reference implementation):
  1. **Watermark redaction** — removes exam-mate/papacambridge watermarks
     via PyMuPDF redactions BEFORE rendering, so watermarks never appear
     in output images and real content is never damaged.
  2. **Imposition barcode scrubbing** — removes printer-imposition registration
     stripe bands at page edges/joins.
  3. **PDF-text-assisted margin trimming** — detects "DO NOT WRITE IN THIS
     MARGIN" warning text columns using PDF coordinates AND pixel analysis,
     combining both for reliable cropping.
  4. **Accurate footer/header detection** — finds running footers and headers
     using UCLES/copyright signatures, page numbers, and [Turn over] indicators.
  5. **Blank page detection** — both text-based and pixel-based.
  6. **Rotation-aware coordinate conversion** — handles /Rotate=90/180/270
     mark scheme pages correctly.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Tuple

import fitz  # PyMuPDF
from PIL import Image

PTS_PER_INCH = 72.0


# ---------------------------------------------------------------------------
# Watermark signs (third-party redistributor watermarks)
# ---------------------------------------------------------------------------
_WATERMARK_SIGNS = ("exam-mate", "exammate", "www.exam", "exam mate",
                    "gceguide", "papacambridge", "xtremepapers",
                    "savemyexams", "physicsandmathstutor", "pmt.",
                    "chemsheets", "chemrevise", "a-levelnotes",
                    "s-cool", "getrevising")


def _erase_watermarks_in_pdf(page: "fitz.Page") -> int:
    """
    Erase third-party redistributor watermarks (exam-mate, papacambridge,
    gceguide, ...) from ``page`` IN-PLACE using PyMuPDF redaction
    annotations. This removes the text BEFORE rendering so we never have
    to guess at rotated-glyph padding on the rasterized image.
    """
    import fitz as _fitz
    redacted = 0
    for wd in page.get_text("words"):
        mx0, my0, mx1, my1, txt, *_ = wd
        t = (txt or "").strip().lower()
        if not t:
            continue
        if not any(s in t for s in _WATERMARK_SIGNS):
            continue
        pad = 2.0
        rect = _fitz.Rect(mx0 - pad, my0 - pad, mx1 + pad, my1 + pad)
        try:
            page.add_redact_annot(rect, fill=(1, 1, 1))
            redacted += 1
        except Exception:
            pass
    if redacted:
        try:
            page.apply_redactions(images=_fitz.PDF_REDACT_IMAGE_NONE)
        except Exception:
            pass
    return redacted


def _erase_watermarks_on_image(img: Image.Image, page: "fitz.Page",
                               scale: float) -> Image.Image:
    """Pixel-level watermark fallback is now a NO-OP — PDF redactions handle it."""
    return img


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------
def render_pdf(path: str | Path, dpi: int = 200) -> Tuple[List[Image.Image], float]:
    """
    Render every page of a PDF to an upright PIL image.

    Third-party watermark text is redacted from the PDF *before* rendering.
    Imposition registration barcodes are scrubbed from the rendered pixel data.
    """
    from .webp_utils import _scrub_imposition_marks as _scrub
    path = str(path)
    doc = fitz.open(path)
    scale = dpi / PTS_PER_INCH
    zoom = fitz.Matrix(scale, scale)
    images: List[Image.Image] = []
    for page in doc:
        _erase_watermarks_in_pdf(page)
        pix = page.get_pixmap(matrix=zoom, alpha=False)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        if is_blank_page(page):
            img = Image.new("RGB", (max(1, pix.width), 1), "white")
        else:
            img = _erase_watermarks_on_image(img, page, scale)
            img = _scrub(img)
        images.append(img)
    doc.close()
    return images, scale


def render_pdf_with_rotation_info(path: str | Path, dpi: int = 200
                                  ) -> Tuple[List[Image.Image], float, List[int], "fitz.Document"]:
    """
    Render every page to an upright PIL image AND keep the fitz Document open
    so callers can map pixel rectangles back to PDF clip rectangles for
    text extraction.  The caller MUST close the returned Document.
    """
    from .webp_utils import _scrub_imposition_marks as _scrub
    path = str(path)
    doc = fitz.open(path)
    scale = dpi / PTS_PER_INCH
    zoom = fitz.Matrix(scale, scale)
    images: List[Image.Image] = []
    rotations: List[int] = []
    for page in doc:
        _erase_watermarks_in_pdf(page)
        rot = page.rotation
        rotations.append(rot)
        pix = page.get_pixmap(matrix=zoom, alpha=False)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        if is_blank_page(page):
            img = Image.new("RGB", (max(1, pix.width), 1), "white")
        else:
            img = _erase_watermarks_on_image(img, page, scale)
            img = _scrub(img)
        images.append(img)
    return images, scale, rotations, doc


def page_is_usable(img: Image.Image) -> bool:
    """Return False if the rendered image is the 1-px BLANK PAGE placeholder."""
    return img.height > 2 and img.width > 2


# ---------------------------------------------------------------------------
# Coordinate conversion
# ---------------------------------------------------------------------------
def pixel_rect_to_pdf_clip(x0_px: float, y0_px: float, x1_px: float, y1_px: float,
                           page: "fitz.Page", scale: float) -> fitz.Rect:
    """Convert a pixel rectangle on the rendered (upright) image to a PDF clip
    rectangle suitable for ``page.get_text(clip=...)``."""
    ux0, uy0 = x0_px / scale, y0_px / scale
    ux1, uy1 = x1_px / scale, y1_px / scale

    rot = page.rotation
    mw = page.mediabox.width
    mh = page.mediabox.height

    def to_media(ux: float, uy: float) -> Tuple[float, float]:
        if rot == 0:
            return (ux, uy)
        if rot == 90:
            return (uy, mh - ux)
        if rot == 180:
            return (mw - ux, mh - uy)
        if rot == 270:
            return (mw - uy, ux)
        return (ux, uy)

    px0, py0 = to_media(ux0, uy0)
    px1, py1 = to_media(ux1, uy1)
    rx0, rx1 = sorted((px0, px1))
    ry0, ry1 = sorted((py0, py1))
    return fitz.Rect(rx0, ry0, rx1, ry1)


def crop_page(img: Image.Image, y0_pdf: float, y1_pdf: float, scale: float) -> Image.Image:
    """Crop a rendered page between two PDF y-coordinates (points)."""
    h = img.height
    w = img.width
    y0 = max(0, int(round(y0_pdf * scale)))
    y1 = min(h, int(round(y1_pdf * scale)))
    if y1 <= y0:
        return Image.new("RGB", (w, 1), "white")
    return img.crop((0, y0, w, y1))


def page_text_between(
    doc: fitz.Document, page_idx: int, y0_pdf: float, y1_pdf: float
) -> str:
    page = doc[page_idx]
    rect = page.rect
    clip = fitz.Rect(0, y0_pdf, rect.width, y1_pdf)
    return page.get_text("text", clip=clip)


def page_text_in_rect(doc: fitz.Document, page_idx: int, clip: fitz.Rect) -> str:
    return doc[page_idx].get_text("text", clip=clip)


def full_page_text(doc: fitz.Document, page_idx: int) -> str:
    return doc[page_idx].get_text("text")


# ---------------------------------------------------------------------------
# Upright bbox conversion
# ---------------------------------------------------------------------------
def _upright_bbox(x0: float, y0: float, x1: float, y1: float,
                 page: "fitz.Page") -> Tuple[Tuple[float, float], Tuple[float, float]]:
    """
    Convert a mediabox-coordinate bbox (as returned by page.get_text("words"))
    into upright (page.rect) coordinates.
    """
    rot = page.rotation
    mw = float(page.mediabox.width)
    mh = float(page.mediabox.height)

    def to_up(px: float, py: float) -> Tuple[float, float]:
        if rot == 0:
            return (px, py)
        if rot == 90:
            return (mh - py, px)
        if rot == 180:
            return (mw - px, mh - py)
        if rot == 270:
            return (py, mw - px)
        return (px, py)

    u0 = to_up(x0, y0)
    u1 = to_up(x1, y1)
    ux0, ux1 = sorted((u0[0], u1[0]))
    uy0, uy1 = sorted((u0[1], u1[1]))
    return (ux0, uy0), (ux1, uy1)


# ---------------------------------------------------------------------------
# Footer / header detection
# ---------------------------------------------------------------------------
_OFFICIAL_FOOTER_SIGNS = ("ucles", "©", "copyright")
_PRINTER_SLUG_SIGNS = ("ib", "_", "/4rp", "/3rp", "/2rp", "rp ", " indd",
                       "adobe", "publisher", "prinergy")
_FOOTER_SIGNS = _OFFICIAL_FOOTER_SIGNS + _WATERMARK_SIGNS
_PAGENUM_RE = __import__("re").compile(r"^\s*\d{1,3}\s*$")


def detect_footer_y(page: "fitz.Page") -> float:
    return _detect_margin_y(page, region="bottom")


def detect_header_y(page: "fitz.Page") -> float:
    return _detect_margin_y(page, region="top")


def _detect_margin_y(page: "fitz.Page", region: str = "bottom") -> float:
    rect = page.rect
    h = float(rect.height)
    w = float(rect.width)

    if region == "bottom":
        search_y0 = h * 0.85
        def in_region(uy0: float) -> bool:
            return uy0 >= search_y0
        no_margin = h
        margin_top: Optional[float] = None
        def consider(uy: float) -> None:
            nonlocal margin_top
            if margin_top is None or uy < margin_top:
                margin_top = uy
    else:
        search_y1 = h * 0.15
        def in_region(uy0: float) -> bool:
            return uy0 <= search_y1
        no_margin = 0.0
        margin_bottom: Optional[float] = None
        def consider(uy: float) -> None:
            nonlocal margin_bottom
            if margin_bottom is None or uy > margin_bottom:
                margin_bottom = uy

    page_num_y: Optional[float] = None
    page_num_bottom: Optional[float] = None

    for wd in page.get_text("words"):
        mx0, my0, mx1, my1, txt, *_ = wd
        (ux0, uy0), (ux1, uy1) = _upright_bbox(mx0, my0, mx1, my1, page)
        if not in_region(uy0):
            continue
        t = txt.strip().lower()
        if not t:
            continue
        if any(s in t for s in _PRINTER_SLUG_SIGNS):
            continue
        if any(s in t for s in _OFFICIAL_FOOTER_SIGNS):
            consider(uy0)
        if any(s in t for s in _WATERMARK_SIGNS):
            if uy0 > h * 0.95:
                consider(uy0)
        if "blank page" in t or t == "blank":
            consider(uy0)
        if "turn over" in t or t == "[turn" or t == "over]":
            consider(uy0)
        if _PAGENUM_RE.match(t):
            cx = (ux0 + ux1) / 2.0
            fsize = uy1 - uy0
            top_ok = (region == "top" and uy1 < h * 0.15)
            bot_ok = (region == "bottom" and uy0 > h * 0.90
                      and ux0 > w * 0.25 and ux1 < w * 0.75)
            if fsize >= 11.0 and abs(cx - w / 2.0) < w * 0.20 and (top_ok or bot_ok):
                try:
                    val = int(t.strip())
                except ValueError:
                    val = -1
                if 0 < val < 1000:
                    if region == "bottom":
                        if page_num_y is None or uy0 < page_num_y:
                            page_num_y = uy0
                    else:
                        if page_num_bottom is None or uy1 > page_num_bottom:
                            page_num_bottom = uy1

    if region == "bottom":
        if page_num_y is not None:
            consider(page_num_y)
        if margin_top is None:
            return no_margin
        return max(0.0, margin_top - 6.0)
    else:
        if page_num_bottom is not None:
            consider(page_num_bottom)
        if margin_bottom is None:
            return no_margin
        return min(h, margin_bottom + 6.0)


# ---------------------------------------------------------------------------
# Blank-page detection
# ---------------------------------------------------------------------------
_BLANK_PAGE_RE = __import__("re").compile(
    r"\bblank\s+page\b", __import__("re").IGNORECASE)


def is_blank_page(page: "fitz.Page") -> bool:
    text = page.get_text("text") or ""
    if not _BLANK_PAGE_RE.search(text):
        return False
    non_ws = sum(1 for c in text if not c.isspace())
    return non_ws < 250


def is_blank_image(img: Image.Image, threshold: int = 5) -> bool:
    """Detect if a rendered image is effectively blank (all white or nearly all white)."""
    if img.height < 17 or img.width < 17:
        return True
    import numpy as np
    arr = np.array(img.convert("L"))
    white_frac = np.sum(arr > 250) / arr.size
    return white_frac > 0.99


# ---------------------------------------------------------------------------
# Margin warning detection and removal
# ---------------------------------------------------------------------------
_MARGIN_WARN_RE = __import__("re").compile(
    r"do\s+not\s+write\s+(in|on)\s+this\s+margin",
    __import__("re").IGNORECASE)


def _page_has_margin_warning(page: "fitz.Page") -> bool:
    return bool(_MARGIN_WARN_RE.search(page.get_text("text") or ""))


def _trim_edge_watermark(arr, side: str, dark_thresh: int = 200,
                         max_search_frac: float = 0.06,
                         corner_frac: float = 0.20) -> int:
    """Trim only pure edge watermark/barcode fragments at page joins."""
    import numpy as _np
    h, w = arr.shape
    dark = arr < dark_thresh
    mid0 = int(h * corner_frac)
    mid1 = int(h * (1 - corner_frac))

    def col_is_edge_noise(x: int) -> bool:
        total = int(dark[:, x].sum())
        if total < 5:
            return False
        mid = int(dark[mid0:mid1, x].sum())
        return mid == 0

    strip = 0
    if side == "left":
        for x in range(min(int(w * max_search_frac), w)):
            if col_is_edge_noise(x):
                strip = x + 1
            else:
                break
    else:
        for x in range(w - 1, max(int(w * (1 - max_search_frac)) - 1, -1), -1):
            if col_is_edge_noise(x):
                strip = w - x
            else:
                break
    return min(strip, int(w * max_search_frac))


def _trim_left_margin(arr, dark_thresh: int = 80,
                      min_run_frac: float = 0.60,
                      max_search_frac: float = 0.22) -> int:
    """Return number of columns to trim from the left edge, or 0."""
    import numpy as _np
    h, w = arr.shape
    dark = arr < dark_thresh
    search_end = int(w * max_search_frac)
    best_x = 0
    best_run = 0
    min_run = max(int(h * min_run_frac * 0.40), int(h * 0.20))
    for x in range(search_end):
        run = int(dark[:, x].sum())
        if run > int(h * min_run_frac) and run > best_run:
            best_run = run
            best_x = x
        if best_x == 0 and run >= min_run and run > best_run:
            adj = dark[:, max(0, x-2):min(w, x+3)].sum()
            if adj > h * 0.60:
                best_run = run
                best_x = x
    if best_x > 4:
        return best_x + 2
    # Soft-margin (watermark) fallback
    mean_col = arr.mean(axis=0)
    soft = (dark.sum(axis=0) > h * 0.03) & (mean_col < 250)
    end = 0
    for x in range(min(search_end, w)):
        if soft[x]:
            end = x + 1
        else:
            if end > 8 and dark[:, max(0, end - 5):end].sum() > h * 0.20:
                return min(end + 6, w)
            if end > 8:
                break
            end = 0
    if end > 30 and dark[:, max(0, end - 10):end].sum() > h * 0.30:
        return min(end + 6, w)
    cw = _trim_edge_watermark(arr, "left")
    return cw


def _trim_right_margin(arr, dark_thresh: int = 80,
                       min_run_frac: float = 0.60,
                       max_search_frac: float = 0.22) -> int:
    """Return number of columns to trim from the right edge, or 0."""
    import numpy as _np
    h, w = arr.shape
    dark = arr < dark_thresh
    search_start = int(w * (1 - max_search_frac))
    best_x = w
    best_run = 0
    min_run = max(int(h * min_run_frac * 0.40), int(h * 0.20))
    for x in range(search_start, w):
        run = int(dark[:, x].sum())
        if run > int(h * min_run_frac) and run >= best_run:
            best_run = run
            best_x = x
        if best_x == w and run >= min_run:
            adj = dark[:, max(0, x-2):min(w, x+3)].sum()
            if adj > h * 0.60:
                best_run = run
                best_x = x
    if (w - best_x) > 4:
        return w - best_x + 2
    mean_col = arr.mean(axis=0)
    soft = (dark.sum(axis=0) > h * 0.03) & (mean_col < 250)
    start = w
    for x in range(w - 1, max(search_start - 1, -1), -1):
        if soft[x]:
            start = x
        else:
            if w - start > 8 and dark[:, start:min(w, start + 5)].sum() > h * 0.20:
                return min(w - start + 6, w)
            if w - start > 8:
                break
            start = w
    if w - start > 30 and dark[:, start:min(w, start + 10)].sum() > h * 0.30:
        return min(w - start + 6, w)
    cw = _trim_edge_watermark(arr, "right")
    return cw


def trim_margin_warnings(img: Image.Image, page: "fitz.Page | None" = None) -> Image.Image:
    """
    Remove "DO NOT WRITE IN/ON THIS MARGIN" strips from the left and/or right
    edges of a rendered page image.

    Uses BOTH PDF-text-assisted detection (when page is provided) AND
    pixel-based analysis for maximum reliability.
    """
    import numpy as _np
    arr = _np.array(img.convert("L"))
    l_px = 0
    r_px = 0

    # --- PDF-text assisted trim (most reliable when page object available) ---
    if page is not None:
        try:
            scale = img.height / float(page.rect.height) if page.rect.height else 1.0
            warn_xs_left: List[float] = []
            warn_xs_right: List[float] = []
            for wd in page.get_text("words"):
                wx0, wy0, wx1, wy1, wtxt, *_ = wd
                if not wtxt.strip():
                    continue
                (ux0, _), (ux1, _) = _upright_bbox(wx0, wy0, wx1, wy1, page)
                tl = wtxt.strip().lower()
                if "margin" in tl or "write" in tl or "this" == tl:
                    cx = (ux0 + ux1) / 2.0
                    if cx < page.rect.width * 0.30:
                        warn_xs_left.append(ux1)
                    elif cx > page.rect.width * 0.70:
                        warn_xs_right.append(ux0)
            if warn_xs_left:
                text_right = max(warn_xs_left)
                sep_x = int((text_right + 6) * scale)
                if 0 < sep_x < int(img.width * 0.30):
                    l_px = max(l_px, sep_x)
            if warn_xs_right:
                text_left = min(warn_xs_right)
                sep_x = int((text_left - 6) * scale)
                w_px = img.width
                if int(w_px * 0.70) < sep_x < w_px:
                    r_px = max(r_px, w_px - sep_x)
        except Exception:
            pass

    # --- Pixel-based trim (always applied, supplements the text pass) ---
    l = _trim_left_margin(arr)
    r = _trim_right_margin(arr)
    l_px = max(l_px, l)
    r_px = max(r_px, r)

    if l_px == 0 and r_px == 0:
        return img
    w, h = img.size
    return img.crop((l_px, 0, w - r_px, h))
