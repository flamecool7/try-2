"""Deterministic structured mark-scheme segmentation for Cambridge 9618.

The splitter is based on the structure observed across nine official 2025
mark schemes (89 top-level questions, 99 answer pages and 130 table headers):

* Answer content is organised into tables headed ``Question | Answer | Marks``.
* A header can occur at the page top or in the middle of a page.
* The full header band is bounded by two long horizontal rules.
* The previous question ends at the header's top rule.
* The following block starts at the header's bottom rule.
* A direct question transition without a new header is separated by a long
  horizontal table rule immediately above the new question label.

No question-paper fixed crop is used. No automatic cut is made through
whitespace or at an arbitrary coordinate. Automatic output is produced only
when all required boundaries are structural table rules and the top-level
question sequence is complete.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import fitz
import numpy as np
from PIL import Image

from .pdf_io import (
    _upright_bbox,
    detect_footer_y,
    page_is_usable,
    render_pdf_with_rotation_info,
)


@dataclass(frozen=True)
class MSWord:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float


@dataclass(frozen=True)
class MSHeaderBand:
    page_index: int
    text_top: float
    text_bottom: float
    top_rule: float
    bottom_rule: float
    question_column_right: float


@dataclass(frozen=True)
class MSLabel:
    page_index: int
    y0: float
    y1: float
    question_number: int
    text: str
    x0: float


@dataclass(frozen=True)
class MSBlock:
    page_index: int
    y0: float
    y1: float
    header: MSHeaderBand
    labels: Tuple[MSLabel, ...]


@dataclass(frozen=True)
class MSSegment:
    page_index: int
    question_number: int
    y0_px: int
    y1_px: int
    start_reason: str
    end_reason: str


@dataclass
class MSSplitDiagnostics:
    markers_found: List[int] = field(default_factory=list)
    expected_questions: List[int] = field(default_factory=list)
    missing_questions: List[int] = field(default_factory=list)
    unexpected_questions: List[int] = field(default_factory=list)
    duplicate_markers: Dict[int, int] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    split_notes: List[str] = field(default_factory=list)
    header_bands: int = 0
    content_blocks: int = 0
    unsafe_boundaries: List[str] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        if not self.markers_found or self.unsafe_boundaries:
            return False
        # A QP-only trailing number is non-fatal: it is commonly caused by a
        # back-matter page being mistaken for a final question. Interior gaps
        # remain fatal because they can bundle unrelated mark-scheme blocks.
        highest_found = max(self.markers_found)
        fatal_missing = [number for number in self.missing_questions
                         if number <= highest_found]
        return not fatal_missing


_TOP_LABEL = re.compile(r"^\s*(\d{1,2})(?=$|\()")


# ---------------------------------------------------------------------------
# Coordinate and text helpers
# ---------------------------------------------------------------------------
def _pdf_y_to_px(page: "fitz.Page", image: Image.Image, y_pdf: float) -> int:
    return max(0, min(
        image.height,
        int(round((float(y_pdf) / max(1.0, float(page.rect.height))) * image.height)),
    ))


def _px_y_to_pdf(page: "fitz.Page", image: Image.Image, y_px: int) -> float:
    return (float(y_px) / max(1, image.height)) * float(page.rect.height)


def _pdf_x_to_px(page: "fitz.Page", image: Image.Image, x_pdf: float) -> int:
    return max(0, min(
        image.width,
        int(round((float(x_pdf) / max(1.0, float(page.rect.width))) * image.width)),
    ))


def _px_x_to_pdf(page: "fitz.Page", image: Image.Image, x_px: int) -> float:
    return (float(x_px) / max(1, image.width)) * float(page.rect.width)


def _words_upright(page: "fitz.Page") -> List[MSWord]:
    words: List[MSWord] = []
    for raw in page.get_text("words"):
        x0, y0, x1, y1, text, *_ = raw
        value = (text or "").strip()
        if not value:
            continue
        (ux0, uy0), (ux1, uy1) = _upright_bbox(x0, y0, x1, y1, page)
        words.append(MSWord(value, ux0, uy0, ux1, uy1))
    words.sort(key=lambda word: (word.y0, word.x0))
    return words


def _cluster_lines(words: Sequence[MSWord], tolerance: float = 3.5) -> List[List[MSWord]]:
    lines: List[List[MSWord]] = []
    for word in sorted(words, key=lambda item: ((item.y0 + item.y1) / 2.0, item.x0)):
        cy = (word.y0 + word.y1) / 2.0
        target = None
        for line in reversed(lines[-6:]):
            line_cy = sum((w.y0 + w.y1) / 2.0 for w in line) / len(line)
            if abs(cy - line_cy) <= tolerance:
                target = line
                break
        if target is None:
            lines.append([word])
        else:
            target.append(word)
    for line in lines:
        line.sort(key=lambda item: item.x0)
    lines.sort(key=lambda line: min(word.y0 for word in line))
    return lines


# ---------------------------------------------------------------------------
# Raster/vector table-rule detection
# ---------------------------------------------------------------------------
def _clusters(values: Sequence[int], gap: int = 2) -> List[List[int]]:
    output: List[List[int]] = []
    for value in values:
        if not output or value - output[-1][-1] > gap:
            output.append([value])
        else:
            output[-1].append(value)
    return output


def _raster_horizontal_rules(
    image: Image.Image,
    y0: int = 0,
    y1: Optional[int] = None,
) -> List[int]:
    """Return centres of long, nearly continuous black horizontal rules."""
    gray = np.asarray(image.convert("L"))
    height, width = gray.shape
    y0 = max(0, int(y0))
    y1 = min(height, int(height if y1 is None else y1))
    if y1 <= y0:
        return []

    candidates: List[int] = []
    minimum_span = int(width * 0.45)
    for y in range(y0, y1):
        xs = np.flatnonzero(gray[y] < 175)
        if len(xs) < minimum_span * 0.35:
            continue
        breaks = np.where(np.diff(xs) > 4)[0]
        starts = np.r_[0, breaks + 1]
        ends = np.r_[breaks, len(xs) - 1]
        longest = max(
            (int(xs[end] - xs[start] + 1) for start, end in zip(starts, ends)),
            default=0,
        )
        if longest >= minimum_span:
            candidates.append(y)
    return [int(round(sum(group) / len(group)))
            for group in _clusters(candidates, gap=2)]


def _raster_vertical_rules(
    image: Image.Image,
    y0: int,
    y1: int,
) -> List[int]:
    gray = np.asarray(image.convert("L"))
    height, _width = gray.shape
    y0, y1 = max(0, int(y0)), min(height, int(y1))
    if y1 <= y0:
        return []
    dark = gray[y0:y1] < 175
    xs = np.where(dark.sum(axis=0) >= max(5, int((y1 - y0) * 0.42)))[0]
    return [int(round(sum(group) / len(group)))
            for group in _clusters(xs.tolist(), gap=2)]


def _vector_horizontal_rules(page: "fitz.Page") -> List[float]:
    page_width = float(page.rect.width)
    found: List[float] = []

    def add(x0: float, y0: float, x1: float, y1: float) -> None:
        (ux0, uy0), (ux1, uy1) = _upright_bbox(x0, y0, x1, y1, page)
        if abs(uy1 - uy0) <= 2.0 and abs(ux1 - ux0) >= page_width * 0.42:
            found.append((uy0 + uy1) / 2.0)

    try:
        drawings = page.get_drawings()
    except Exception:
        drawings = []
    for drawing in drawings:
        for item in drawing.get("items", []):
            if not item:
                continue
            if item[0] == "l" and len(item) >= 3:
                p0, p1 = item[1], item[2]
                add(float(p0.x), float(p0.y), float(p1.x), float(p1.y))
            elif item[0] == "re" and len(item) >= 2:
                rect = item[1]
                add(float(rect.x0), float(rect.y0), float(rect.x1), float(rect.y0))
                add(float(rect.x0), float(rect.y1), float(rect.x1), float(rect.y1))

    found.sort()
    merged: List[float] = []
    for value in found:
        if merged and abs(value - merged[-1]) <= 1.8:
            merged[-1] = (merged[-1] + value) / 2.0
        else:
            merged.append(value)
    return merged


def _all_horizontal_rules(page: "fitz.Page", image: Image.Image) -> List[float]:
    raster = [_px_y_to_pdf(page, image, value)
              for value in _raster_horizontal_rules(image)]
    combined = sorted(raster + _vector_horizontal_rules(page))
    merged: List[float] = []
    for value in combined:
        if merged and abs(value - merged[-1]) <= 1.5:
            merged[-1] = (merged[-1] + value) / 2.0
        else:
            merged.append(value)
    return merged


# ---------------------------------------------------------------------------
# Header, column and label analysis
# ---------------------------------------------------------------------------
def _header_text_rows(words: Sequence[MSWord]) -> List[Tuple[float, float, MSWord]]:
    output = []
    for line in _cluster_lines(words, tolerance=4.0):
        normalized = [word.text.strip(" :").lower() for word in line]
        if "question" not in normalized or "answer" not in normalized:
            continue
        if not any(value in {"mark", "marks"} for value in normalized):
            continue
        qword = next(word for word in line
                     if word.text.strip(" :").lower() == "question")
        output.append((min(word.y0 for word in line),
                       max(word.y1 for word in line), qword))
    return output


def _rule_above(rules: Sequence[float], y: float,
                maximum_distance: float = 45.0) -> Optional[float]:
    options = [rule for rule in rules if y - maximum_distance <= rule <= y + 1.5]
    return max(options) if options else None


def _rule_below(rules: Sequence[float], y: float,
                maximum_distance: float = 55.0) -> Optional[float]:
    options = [rule for rule in rules if y - 1.5 <= rule <= y + maximum_distance]
    return min(options) if options else None


def _question_column_boundary(
    page: "fitz.Page",
    image: Image.Image,
    qword: MSWord,
    top_rule: float,
    bottom_rule: float,
) -> Optional[float]:
    y0 = _pdf_y_to_px(page, image, max(0.0, top_rule - 2.0))
    y1 = _pdf_y_to_px(page, image, min(float(page.rect.height), bottom_rule + 55.0))
    verticals = _raster_vertical_rules(image, y0, y1)
    qword_right = _pdf_x_to_px(page, image, qword.x1)
    options = [x for x in verticals
               if qword_right + 2 <= x <= image.width * 0.32]
    if options:
        return _px_x_to_pdf(page, image, min(options))
    return None


def _analyse_headers(
    doc: "fitz.Document",
    images: Sequence[Image.Image],
) -> Tuple[List[List[MSHeaderBand]], List[List[float]], List[List[MSWord]], List[str]]:
    headers_by_page: List[List[MSHeaderBand]] = []
    rules_by_page: List[List[float]] = []
    words_by_page: List[List[MSWord]] = []
    warnings: List[str] = []
    provisional = []

    for page_index, page in enumerate(doc):
        words = _words_upright(page)
        rules = _all_horizontal_rules(page, images[page_index])
        words_by_page.append(words)
        rules_by_page.append(rules)
        page_headers = []
        for text_top, text_bottom, qword in _header_text_rows(words):
            top = _rule_above(rules, text_top, 35.0)
            bottom = _rule_below(rules, text_bottom, 45.0)
            if top is None or bottom is None or bottom <= top + 3.0:
                warnings.append(
                    f"page {page_index + 1}: could not pair header text at "
                    f"y={text_top:.2f}:{text_bottom:.2f} with two table rules"
                )
                continue
            qright = _question_column_boundary(
                page, images[page_index], qword, top, bottom
            )
            page_headers.append((text_top, text_bottom, top, bottom, qright))
            if qright is not None:
                provisional.append((float(page.rect.width), qright))
        provisional_page = page_headers
        headers_by_page.append(provisional_page)  # converted below

    # Column geometry is fixed for a given page width/orientation. Fill rare
    # detection gaps from the median of matching pages, never from Answer text.
    medians: Dict[float, float] = {}
    for width in {round(item[0], 1) for item in provisional}:
        values = [qright for page_width, qright in provisional
                  if round(page_width, 1) == width]
        if values:
            medians[width] = float(np.median(values))

    converted: List[List[MSHeaderBand]] = []
    for page_index, page_headers in enumerate(headers_by_page):
        width_key = round(float(doc[page_index].rect.width), 1)
        page_output: List[MSHeaderBand] = []
        for text_top, text_bottom, top, bottom, qright in page_headers:
            if qright is None:
                qright = medians.get(width_key)
            if qright is None:
                warnings.append(
                    f"page {page_index + 1}: no reliable Question-column divider"
                )
                continue
            page_output.append(MSHeaderBand(
                page_index=page_index,
                text_top=text_top,
                text_bottom=text_bottom,
                top_rule=top,
                bottom_rule=bottom,
                question_column_right=qright,
            ))
        page_output.sort(key=lambda header: header.top_rule)
        converted.append(page_output)
    return converted, rules_by_page, words_by_page, warnings


def _labels_for_page(
    page_index: int,
    words: Sequence[MSWord],
    qright: float,
    first_header_top: float,
    content_bottom: float,
) -> List[MSLabel]:
    labels = []
    for word in words:
        if word.x0 >= qright - 0.5:
            continue
        if word.y1 < first_header_top or word.y0 > content_bottom:
            continue
        match = _TOP_LABEL.match(word.text)
        if not match:
            continue
        number = int(match.group(1))
        if 1 <= number <= 99:
            labels.append(MSLabel(
                page_index=page_index,
                y0=word.y0,
                y1=word.y1,
                question_number=number,
                text=word.text,
                x0=word.x0,
            ))
    labels.sort(key=lambda label: (label.y0, label.x0))
    return labels


# ---------------------------------------------------------------------------
# Build header-free blocks
# ---------------------------------------------------------------------------
def _build_blocks(
    doc: "fitz.Document",
    headers_by_page: Sequence[Sequence[MSHeaderBand]],
    rules_by_page: Sequence[Sequence[float]],
    words_by_page: Sequence[Sequence[MSWord]],
    diagnostics: MSSplitDiagnostics,
) -> List[MSBlock]:
    answer_pages = [index for index, headers in enumerate(headers_by_page) if headers]
    if not answer_pages:
        diagnostics.unsafe_boundaries.append("no Question/Answer/Marks table headers found")
        return []

    first_answer_page = min(answer_pages)
    last_answer_page = max(answer_pages)
    blocks: List[MSBlock] = []

    for page_index in range(first_answer_page, last_answer_page + 1):
        page_headers = list(headers_by_page[page_index])
        if not page_headers:
            diagnostics.unsafe_boundaries.append(
                f"page {page_index + 1}: answer-table sequence has no header"
            )
            continue
        page = doc[page_index]
        footer = float(detect_footer_y(page))
        if footer <= 0 or footer > float(page.rect.height):
            footer = float(page.rect.height)
        rules = [rule for rule in rules_by_page[page_index] if rule <= footer + 1.0]
        final_rules = [rule for rule in rules
                       if rule > page_headers[-1].bottom_rule + 3.0]
        page_table_bottom = max(final_rules) if final_rules else None
        if page_table_bottom is None:
            diagnostics.unsafe_boundaries.append(
                f"page {page_index + 1}: no final horizontal table rule"
            )
            continue

        qright = float(np.median([header.question_column_right
                                  for header in page_headers]))
        page_labels = _labels_for_page(
            page_index,
            words_by_page[page_index],
            qright,
            page_headers[0].top_rule,
            page_table_bottom,
        )

        for header_index, header in enumerate(page_headers):
            start = header.bottom_rule
            end = (page_headers[header_index + 1].top_rule
                   if header_index + 1 < len(page_headers)
                   else page_table_bottom)
            if end <= start + 3.0:
                diagnostics.unsafe_boundaries.append(
                    f"page {page_index + 1}: invalid block {start:.2f}:{end:.2f}"
                )
                continue
            labels = tuple(label for label in page_labels
                           if start - 0.5 <= label.y0 < end - 0.5)
            blocks.append(MSBlock(
                page_index=page_index,
                y0=start,
                y1=end,
                header=header,
                labels=labels,
            ))
            diagnostics.split_notes.append(
                f"page {page_index + 1}: removed header "
                f"{header.top_rule:.2f}:{header.bottom_rule:.2f}; "
                f"content block {start:.2f}:{end:.2f}"
            )

    blocks.sort(key=lambda block: (block.page_index, block.y0))
    diagnostics.header_bands = sum(len(headers) for headers in headers_by_page)
    diagnostics.content_blocks = len(blocks)
    return blocks


# ---------------------------------------------------------------------------
# State-machine assignment
# ---------------------------------------------------------------------------
def _direct_boundary(
    rules: Sequence[float],
    label: MSLabel,
    block_start: float,
) -> Optional[float]:
    # Strictly above the label: never permit a line below the question number.
    candidates = [rule for rule in rules
                  if max(block_start, label.y0 - 90.0) <= rule <= label.y0 - 1.0]
    return max(candidates) if candidates else None


def _append_pdf_segment(
    target: Dict[int, List[Tuple[int, float, float, str, str]]],
    question: Optional[int],
    page_index: int,
    y0: float,
    y1: float,
    start_reason: str,
    end_reason: str,
) -> None:
    if question is None or y1 <= y0 + 2.0:
        return
    target.setdefault(question, []).append(
        (page_index, y0, y1, start_reason, end_reason)
    )


def _assign_blocks(
    blocks: Sequence[MSBlock],
    rules_by_page: Sequence[Sequence[float]],
    diagnostics: MSSplitDiagnostics,
) -> Dict[int, List[Tuple[int, float, float, str, str]]]:
    assigned: Dict[int, List[Tuple[int, float, float, str, str]]] = {}
    current: Optional[int] = None
    seen: List[int] = []

    for block in blocks:
        cursor = block.y0
        start_reason = "header bottom rule"
        labels = list(block.labels)

        for label_index, label in enumerate(labels):
            number = label.question_number
            if current is None:
                if number != 1:
                    diagnostics.unsafe_boundaries.append(
                        f"page {block.page_index + 1}: first top-level label is "
                        f"{label.text}, expected Q1"
                    )
                    break
                current = number
                seen.append(number)
                diagnostics.split_notes.append(
                    f"Q{number} starts page {block.page_index + 1} at "
                    f"header bottom rule y={block.y0:.2f}"
                )
                continue

            if number == current:
                continue
            if number < current:
                # A lower number in the true Question column is structurally
                # suspicious; do not silently reinterpret it as answer text.
                diagnostics.warnings.append(
                    f"page {block.page_index + 1}: ignored out-of-order label "
                    f"{label.text} while assigning Q{current}"
                )
                continue
            if number > current + 1:
                diagnostics.unsafe_boundaries.append(
                    f"page {block.page_index + 1}: question jump Q{current} -> "
                    f"Q{number} at y={label.y0:.2f}"
                )
                break

            # number == current + 1
            near_block_start = label.y0 - block.y0 <= 35.0
            if near_block_start and label_index == 0:
                # A header band already removed the previous question. This
                # whole block belongs to the next question.
                current = number
                seen.append(number)
                cursor = block.y0
                start_reason = "header bottom rule"
                diagnostics.split_notes.append(
                    f"Q{number} starts page {block.page_index + 1} at "
                    f"header bottom rule y={block.y0:.2f}"
                )
                continue

            boundary = _direct_boundary(
                rules_by_page[block.page_index], label, block.y0
            )
            if boundary is None:
                diagnostics.unsafe_boundaries.append(
                    f"page {block.page_index + 1}: no horizontal rule above "
                    f"direct transition to Q{number} at y={label.y0:.2f}"
                )
                break
            _append_pdf_segment(
                assigned, current, block.page_index, cursor, boundary,
                start_reason, "direct horizontal rule",
            )
            current = number
            seen.append(number)
            cursor = boundary
            start_reason = "direct horizontal rule"
            diagnostics.split_notes.append(
                f"Q{number} starts page {block.page_index + 1} at direct "
                f"horizontal rule y={boundary:.2f}"
            )

        if diagnostics.unsafe_boundaries:
            break
        _append_pdf_segment(
            assigned, current, block.page_index, cursor, block.y1,
            start_reason, "next header top rule or page table bottom",
        )

    diagnostics.markers_found = seen
    counts: Dict[int, int] = {}
    for number in seen:
        counts[number] = counts.get(number, 0) + 1
    diagnostics.duplicate_markers = {
        number: count for number, count in counts.items() if count > 1
    }
    return assigned


# ---------------------------------------------------------------------------
# Validation and image assembly
# ---------------------------------------------------------------------------
def _validate_expected(
    diagnostics: MSSplitDiagnostics,
    expected_question_numbers: Optional[Iterable[int]],
) -> None:
    found = set(diagnostics.markers_found)
    expected = sorted({int(value) for value in (expected_question_numbers or [])})
    if not expected and found:
        expected = list(range(1, max(found) + 1))
    diagnostics.expected_questions = expected
    diagnostics.missing_questions = sorted(set(expected) - found)
    diagnostics.unexpected_questions = sorted(found - set(expected)) if expected else []
    if diagnostics.missing_questions:
        highest_found = max(found) if found else 0
        interior = [number for number in diagnostics.missing_questions
                    if number <= highest_found]
        if interior:
            diagnostics.warnings.append(
                "incomplete top-level sequence; refusing bundled output; "
                f"missing interior questions {interior}"
            )
        else:
            diagnostics.warnings.append(
                "question paper reported trailing question number(s) not "
                "present in the complete mark-scheme sequence: "
                f"{diagnostics.missing_questions}; generating the verified "
                "mark-scheme questions and quarantining the unmatched QP item"
            )
    if diagnostics.unexpected_questions:
        diagnostics.warnings.append(
            "mark scheme contains additional safe question boundaries not seen "
            f"by the question-paper detector: {diagnostics.unexpected_questions}"
        )


def _materialise_segments(
    doc: "fitz.Document",
    images: Sequence[Image.Image],
    assigned: Dict[int, List[Tuple[int, float, float, str, str]]],
) -> Dict[int, List[Image.Image]]:
    output: Dict[int, List[Image.Image]] = {}
    for question, segments in assigned.items():
        pieces = []
        for page_index, y0, y1, _start_reason, _end_reason in segments:
            image = images[page_index]
            top = _pdf_y_to_px(doc[page_index], image, y0)
            bottom = _pdf_y_to_px(doc[page_index], image, y1)
            if bottom - top < 4:
                continue
            pieces.append(image.crop((0, top, image.width, bottom)).copy())
        if pieces:
            output[question] = pieces
    return output


def _merge(images: Sequence[Image.Image]) -> Image.Image:
    if not images:
        raise ValueError("cannot merge empty mark-scheme image list")
    if len(images) == 1:
        return images[0]
    width = max(image.width for image in images)
    height = sum(image.height for image in images)
    canvas = Image.new("RGB", (width, height), "white")
    y = 0
    for image in images:
        canvas.paste(image, (0, y))
        y += image.height
    return canvas


def split_structured_mark_scheme(
    pdf_path: str | Path,
    *,
    dpi: int = 200,
    expected_question_numbers: Optional[Iterable[int]] = None,
) -> Tuple[Dict[int, Image.Image], MSSplitDiagnostics]:
    """Return exactly one header-free image for each top-level MS question."""
    images, _scale, _rotations, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    diagnostics = MSSplitDiagnostics()
    try:
        images = [image.convert("RGB") for image in images]
        headers, rules, words, warnings = _analyse_headers(doc, images)
        diagnostics.warnings.extend(warnings)
        blocks = _build_blocks(doc, headers, rules, words, diagnostics)
        assigned = _assign_blocks(blocks, rules, diagnostics) if blocks else {}
        _validate_expected(diagnostics, expected_question_numbers)

        if not diagnostics.valid:
            return {}, diagnostics

        pieces = _materialise_segments(doc, images, assigned)
        required = set(diagnostics.markers_found)
        missing_images = sorted(required - set(pieces))
        if missing_images:
            diagnostics.missing_questions = missing_images
            diagnostics.warnings.append(
                f"no image segments assembled for questions {missing_images}"
            )
            return {}, diagnostics

        return {
            question: _merge(pieces[question])
            for question in sorted(required)
        }, diagnostics
    finally:
        doc.close()
