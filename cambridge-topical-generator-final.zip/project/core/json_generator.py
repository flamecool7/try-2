"""
JSON Generator - Universal component supporting IGCSE + A-Level

JSON format must remain consistent for both levels:
{
    "id": "f2329504-3d63-4dd7-95cb-e862fd34b66e",
    "level": "A-Level", // or "IGCSE"
    "subject": "Chemistry_9701", // or Chemistry_0620
    "board": "CIE",
    "topic": ["Equilibria","Electrochemistry"],
    "paper": "9701_m26_qp_22",
    "question_number": "Q3",
    "variant": "22",
    "season": "Spring",
    "year": "2026"
}

Do NOT add:
topic_details, primary, secondary, needs_review, topic_scores, primary_topic, secondary_topics
The first topic is the assigned routing topic.  It is copied byte-for-byte to the
physical topic-folder name.  Any additional entries preserve legitimate
multi-topic classification and are never renamed.

Same schema for IGCSE and A-Level, only values change.
"""

import json
import logging
import uuid
from pathlib import Path
from typing import List

logger = logging.getLogger(__name__)

# Audit fix-group 5 C4: canonical fields warned about (never fatal) before write.
REQUIRED_CANONICAL_FIELDS = [
    "id", "level", "subject", "board", "topic",
    "paper", "question_number", "variant", "season", "year",
]
from .qp_ms_matcher import MatchedQuestion
from .classifier import ClassificationResult
from .config_loader import SubjectConfig

class JSONGenerator:
    def __init__(self):
        pass

    def generate_json(self, matched: MatchedQuestion, classification: ClassificationResult, 
                      config: SubjectConfig) -> dict:
        """Generate JSON for a question - consistent format for IGCSE and A-Level"""
        unique_str = f"{matched.paper_code}_{matched.question_number}_{config.subject}"
        q_id = str(uuid.uuid4())

        data = {
            "id": q_id,
            "level": config.level,  # "IGCSE" or "A-Level" - crucial for distinction
            "subject": config.subject,  # e.g., Chemistry_0620 or Chemistry_9701
            "board": config.board,
            # Index 0 is the distribution winner.  It is the canonical topic
            # identifier and must be used verbatim as the physical folder name.
            # Keep other genuine classifications for multi-topic metadata without
            # changing their strings.
            "topic": self.canonical_topic_list(classification),
            "paper": matched.full_qp_code,  # e.g., 0620_m26_qp_42 or 9701_m26_qp_22
            "question_number": matched.question_number,
            "variant": matched.variant,
            "season": matched.season,
            "year": matched.year
        }

        # Ensure no forbidden fields
        forbidden = ["topic_details", "primary", "secondary", "needs_review", "topic_scores", "primary_topic", "secondary_topics"]
        for f in forbidden:
            if f in data:
                del data[f]

        # Level validation
        if data["level"] not in ["IGCSE", "A-Level"]:
            raise ValueError(f"Invalid level {data['level']} - must be IGCSE or A-Level")

        return data

    @staticmethod
    def canonical_topic_list(classification: ClassificationResult) -> List[str]:
        """Return topics with the assigned routing topic first, without renaming.

        ``winning_major`` is the result selected by the existing point-based
        distribution system.  It is already an identifier from the reference
        configuration.  Do not title-case, sanitize, replace underscores, or
        otherwise transform it.  The first item is deliberately the folder topic.
        """
        assigned = classification.winning_major
        if not isinstance(assigned, str) or not assigned:
            raise ValueError("Classification has no valid assigned topic")
        # dict.fromkeys preserves order while avoiding a duplicate when the winner
        # also appears in detailed_topics (the usual one-topic case).
        return list(dict.fromkeys([assigned, *classification.detailed_topics]))[:4]

    def save_json(self, json_data: dict, output_path: Path):
        """Save JSON to file.

        Audit fix-group 5 additions (maintainer-approved additives):
        - C1: standard json.dump only — no .jsonc, no comments.
        - C4: warn (never fail) on any missing canonical field before write.
        - C3: legacy metadata.jsonc cleanup — delete a sibling .jsonc after
          writing the canonical metadata.json.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        for key in REQUIRED_CANONICAL_FIELDS:
            if key not in json_data:
                logger.warning("Missing canonical field: %s (%s)", key, output_path)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, indent=4)

        old = output_path.with_suffix(".jsonc")
        if old.exists():
            old.unlink()
            logger.info("Removed legacy sidecar %s", old)

    def generate_and_save_batch(self, matched_questions, classifications, configs, output_dir: Path) -> List[Path]:
        """Write metadata only to its canonical JSON-driven topic path.

        Production image output uses :class:`OutputManager`, which writes the
        complete question bundle. This compatibility helper must nevertheless
        obey the same naming invariant and never create a separate ``json/``
        naming tree.
        """
        from .output_manager import _paper_type_folder

        saved = []
        output_dir = Path(output_dir)
        for matched, classification, config in zip(matched_questions, classifications, configs):
            json_data = self.generate_json(matched, classification, config)
            assigned_topic = json_data["topic"][0]  # exact string; never transform
            paper_type = _paper_type_folder(matched.variant, syllabus_code=config.syllabus_code)
            question_folder_name = f"{matched.variant}_{matched.season}_{matched.year}_{matched.question_number}"
            json_path = (
                output_dir / config.level / config.subject / paper_type /
                assigned_topic / question_folder_name / "metadata.json"
            )
            self.save_json(json_data, json_path)
            saved.append(json_path)
        return saved
