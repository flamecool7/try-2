from __future__ import annotations
from pathlib import Path

SUBJECT_NAMES = {
    "9700": "Biology", "9701": "Chemistry", "9702": "Physics",
    "9708": "Economics", "9709": "Mathematics", "9706": "Accounting",
    "9608": "Computer_Science", "9618": "Computer_Science", "9609": "Business", "9698": "Psychology",
    "9231": "Further_Mathematics",
    "0580": "Mathematics", "0980": "Mathematics",
    "0620": "Chemistry", "0610": "Biology", "0625": "Physics",
    "0478": "Computer_Science", "0984": "Computer_Science",
    "0500": "English_First_Language", "0455": "Economics",
    "0450": "Business_Studies", "0417": "ICT",
    "0460": "Geography", "0445": "Accounting",
    "5054": "Physics", "5070": "Chemistry", "5090": "Biology", "4024": "Mathematics",
}

TOPICS_FILE_FOR_CODE = {
    "9701": "A-Level/Chemistry_9701_topics.json",
    "9702": "A-Level/Physics_9702_topics.json",
    "9709": "A-Level/Mathematics_9709_topics.json",
    "9700": "A-Level/Biology_9700_topics.json",
    "9708": "A-Level/Economics_9708_topics.json",
    "9231": "A-Level/Further_Mathematics_9231_topics.json",
    "9698": "A-Level/Psychology_9698_topics.json",
    "9609": "A-Level/Business_9609_topics.json",
    "9608": "A-Level/Computer_Science_9608_topics.json",
    "9618": "A-Level/Computer_Science_9618_topics.json",
    "9706": "A-Level/Accounting_9706_topics.json",
    "0580": "IGCSE/Mathematics_0580_topics.json",
    "0625": "IGCSE/Physics_0625_topics.json",
    "0620": "IGCSE/Chemistry_0620_topics.json",
    "0610": "IGCSE/Biology_0610_topics.json",
    "0455": "IGCSE/Economics_0455_topics.json",
    "0500": "IGCSE/English_0500_topics.json",
    "0478": "IGCSE/ComputerScience_0478_topics.json",
    "0450": "IGCSE/Business_Studies_0450_topics.json",
    "0460": "IGCSE/Geography_0460_topics.json",
    "0445": "IGCSE/Accounting_0445_topics.json",
    "0417": "IGCSE/ICT_0417_topics.json",
}

def detect_level(syllabus_code: str) -> str:
    code = syllabus_code.strip()
    if code.startswith("97") or code.startswith("93") or code.startswith("92") or code.startswith("96"):
        return "A-Level"
    if code.startswith("0") or code.startswith("7"):
        return "IGCSE"
    if code.startswith("4") or code.startswith("5"):
        return "O-Level"
    return "Unknown"

SESSION_FROM_LETTER = {
    "s": ("Summer", "May/Jun"), "w": ("Winter", "Oct/Nov"), "m": ("Spring", "Feb/Mar"),
}
SESSION_LABEL_TO_ID = {"Summer": "May/Jun", "Winter": "Oct/Nov", "Spring": "Feb/Mar"}

# Canonical exam-session labels used everywhere in the output (folder names,
# image filenames and the metadata "season" field). "March" is never allowed —
# the February/March session is always "Spring".
CANONICAL_SEASONS = {"Summer", "Winter", "Spring"}


def canonical_season(label: str) -> str:
    """Return the canonical season label, correcting "March" -> "Spring".

    Any legacy/rogue label that is not one of the canonical seasons is mapped
    onto its closest canonical form so no instance of "March" survives in any
    folder name, image filename or metadata season field.
    """
    if label is None:
        return "Unknown"
    label = str(label).strip()
    low = label.lower()
    if low == "march":
        return "Spring"
    if low in ("summer", "may/june", "may-jun", "may"):
        return "Summer"
    if low in ("winter", "oct/nov", "october/november", "october"):
        return "Winter"
    if low in ("spring", "feb/mar", "february/march", "february"):
        return "Spring"
    if low == "specimen":
        return "Specimen"
    return label

def detect_subject(syllabus_code: str) -> str:
    name = SUBJECT_NAMES.get(syllabus_code.strip())
    if name:
        return name
    return f"Subject_{syllabus_code}"

def resolve_topics_file(syllabus_code: str, topics_root: Path | str | None = None) -> Path | None:
    code = syllabus_code.strip()
    rel = TOPICS_FILE_FOR_CODE.get(code)
    if not rel:
        return None
    if topics_root is None:
        topics_root = Path(__file__).resolve().parent.parent / "topics"
    else:
        topics_root = Path(topics_root)
    candidate = topics_root / rel
    return candidate if candidate.exists() else None
