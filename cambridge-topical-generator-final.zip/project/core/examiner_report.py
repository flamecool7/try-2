"""
examiner_report.py
==================
Modular extraction, strict verification, and question-level association engine
for Cambridge Examiner Reports (Principal Examiner Report for Teachers).

Merged implementation v1.1 — Overseer spec v1.0 capabilities integrated into the
locked strict-verification architecture (overseer decisions: MERGE approach,
"if there is no ER continue process" fallback policy, text + WebP artifacts).

Key Requirements Retained (from the locked baseline):
  1. Strict Multi-Signal Matching:
     - Verifies Subject, Syllabus Code, Level, Board, Component/Paper, Variant, Season, Year.
     - Never guesses or accepts weak matches.
     - Prevents wrong-series (e.g. Summer vs Winter) or wrong-variant (e.g. 41 vs 42) attachments.
  2. Non-Destructive Integration:
     - Does NOT modify existing cropping, classification, folder naming, or metadata systems.
  3. Fallback policy (overseer directive): if there is no ER, the process
     continues without writing placeholder report files. Placeholder/fake
     content is never created.
  4. Automated Verification & UTF-8 Integrity.

Spec v1.0 Capabilities Added:
  - Multi-format question headers (A: "Question 1", B: "Question No. 1"/"Q1"/"Q.1",
    C: bare numbers, D: "Questions 1-10" grouped ranges, E: "Question 4 (a)(i)").
  - Section title variants (Comments on specific/individual questions, any case;
    "Question responses"; "Section A"/"Section B"), line-anchored first.
  - Sub-part commentary concatenated into the parent question block.
  - Ligature/quote/dash normalisation applied BEFORE any regex matching.
  - Running page headers/footers stripped BEFORE section splitting
    (page-junk patterns incl. © lines, "Turn over", "Page N of M",
    "NNNN Title Month YYYY" running titles, bare page numbers at page edges).
  - Hyphenated line breaks rejoined ("identi-\\nfied" -> "identified").
  - Back-matter (copyright/permission text) trimmed from question parsing.
  - examiner_report_full.txt written to the component folder.
  - status_map returned so the pipeline can log success rates.

Spec-code corrections applied during reconstruction (faithful to intent, the
literal pasted regexes were self-defeating; each fix noted in code comments):
  FIX-1: "Question 1" (Format A) now actually matches — "No." made optional:
         (?:Question\\s+(?:No\\.?\\s*)?|Q\\.?\\s*)(\\d+)
  FIX-2: bare-page-number stripping restricted to page-edge lines — the spec's
         global ^\\d+$ strip would have deleted Format C bare-number headers.
  FIX-3: spaces tolerated between sub-part groups ("Question 4 (a) (i)").
  FIX-4: section titles matched line-anchored first, loose search as fallback,
         so cross-references inside General Comments cannot set false boundaries.
  FIX-5: hyphen rejoin tolerates one blank line left by stripped page headers.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

try:
    import fitz
except ImportError:
    import pymupdf as fitz

from .reference import canonical_season, detect_subject


# =============================================================================
# CONSTANTS & COMPILED PATTERNS  (spec Layer: cleaner/splitter/parser engine)
# =============================================================================

# --- Ligature & special-character normalisation (applied BEFORE any regex) ---
LIGATURE_MAP = {
    "\ufb01": "fi",   # fi
    "\ufb02": "fl",   # fl
    "\ufb00": "ff",   # ff
    "\ufb03": "ffi",  # ffi
    "\ufb04": "ffl",  # ffl
    "\u2019": "'",    # right single quote
    "\u2018": "'",    # left single quote
    "\u201c": '"',    # left double quote
    "\u201d": '"',    # right double quote
    "\u2013": "-",    # en dash
    "\u2014": "--",   # em dash
    "\u00a0": " ",    # non-breaking space
}

# --- Running page header/footer junk (matched per-line, stripped before
#     section splitting). Grounded in real PERTs: running header block is
#     "Cambridge International Advanced Subsidiary and Advanced Level" /
#     "9709 Mathematics June 2022" / "Principal Examiner Report for Teachers" /
#     "© 2022" on every page. ---
PAGE_JUNK_LINE_PATTERNS = [
    # spec: "9701/22  Cambridge International ..." running headers
    re.compile(r"^\s*\d{4}/\d{1,2}\s+Cambridge\s+International.*$", re.IGNORECASE),
    # "Cambridge International AS & A Level ..." / "Cambridge International
    #  Advanced Subsidiary and Advanced Level" running headers/cover lines.
    # Trailing whitespace tolerated: real PERTs pad these lines ("Level \n").
    re.compile(r"^\s*Cambridge\s+International\s+(?:AS\s*&\s*A\s+Level"
               r"|Advanced\s+Subsidiary\s+and\s+Advanced\s+Level"
               r"|International\s+General\s+Certificate)[^\n]*$", re.IGNORECASE),
    # "Cambridge Assessment International Education 2022" (QP/ER footer line)
    re.compile(r"^\s*Cambridge\s+Assessment\s+International\s+Education\s*20\d{2}?\s*$",
               re.IGNORECASE),
    # "9709 Mathematics June 2022" style running title (syllabus + month + year)
    re.compile(r"^\s*\d{4}[_ ]\S[^\n]*\b(?:January|February|March|April|May|June|July"
               r"|August|September|October|November|December)\s+20\d{2}\s*$",
               re.IGNORECASE),
    # "Principal Examiner Report for Teachers ..."
    re.compile(r"^\s*Principal\s+Examiner\s+Report\s+for\s+Teachers.*$", re.IGNORECASE),
    # "© UCLES 2024" and "© 2022" (UCLES optional — newer PERTs omit it)
    re.compile(r"^\s*©\s*(?:UCLES\s+)?20\d{2}\s*$", re.IGNORECASE),
    # "Turn over" / "[Turn over]"
    re.compile(r"^\s*\[?Turn\s+over\]?\s*$", re.IGNORECASE),
    # "Page 3" / "Page 3 of 12"
    re.compile(r"^\s*Page\s+\d+(?:\s+of\s+\d+)?\s*$", re.IGNORECASE),
]

# FIX-2: bare page numbers are stripped ONLY at page edges (first/last 2 lines
# of a page), never globally — a global strip would destroy Format C question
# headers ("1" alone on a line).
_BARE_PAGE_NUM_RE = re.compile(r"^\s*\d{1,3}\s*$")

# --- Section boundary detection (all observed Cambridge title variants) ---
# Line-anchored forms tried first (FIX-4: prevents a cross-reference sentence
# inside General Comments from setting a false boundary); loose forms fallback.
SPECIFIC_SECTION_LINE = re.compile(
    r"^\s*(?:comments?\s+on\s+(?:specific|individual)\s+questions?"
    r"|question\s+responses?"
    r"|section\s+[AB])\s*$",
    re.IGNORECASE | re.MULTILINE,
)
SPECIFIC_SECTION_PATTERN = re.compile(
    r"(?:comments?\s+on\s+(?:specific|individual)\s+questions?"
    r"|question\s+responses?"
    r"|section\s+[AB]\b(?!\w))",
    re.IGNORECASE,
)
GENERAL_SECTION_LINE = re.compile(r"^\s*general\s+comments?\s*$", re.IGNORECASE | re.MULTILINE)
GENERAL_SECTION_PATTERN = re.compile(r"general\s+comments?", re.IGNORECASE)

# --- Question header detection (priority order; group 1 = question NUMBER) ---
# FIX-1: "No." optional so Format A "Question 1" matches (the literal spec
# regex only matched "Question No. 1"/"Q1"/"Q.1" and would have missed the
# most common format).
# FIX-3: "(?:\s*\([a-z]+\))*" tolerates spaces: "Question 4 (a) (i)".
_QUESTION_PREFIX = r"(?:Question\s+(?:No\.?\s*)?|Q\.?\s*)"
QUESTION_HEADER_PATTERNS: List[Tuple[str, re.Pattern]] = [
    # "Question 4 (a)(i)" / "Question 4(a)" / "Question No. 2 (b)" / "Q3(a)"
    # Sub-part groups are consumed ONLY on the header line itself ([ \t]*, not
    # \s*): in modern PERTs the "(a)" label sits on the NEXT line and is
    # commentary content that must be preserved, not header noise.
    (
        "full_with_sub",
        re.compile(
            r"^" + _QUESTION_PREFIX + r"(\d+)(?:[ \t]*\([a-z]+\))*[ \t]*$",
            re.IGNORECASE | re.MULTILINE,
        ),
    ),
    # "Question 1" bare
    (
        "full_bare",
        re.compile(
            r"^" + _QUESTION_PREFIX + r"(\d+)\s*$",
            re.IGNORECASE | re.MULTILINE,
        ),
    ),
    # "Questions 1-10" grouped range — MCQ papers
    (
        "grouped_range",
        re.compile(
            r"^Questions?\s+(\d+)\s*[-\u2013]\s*\d+\s*$",
            re.IGNORECASE | re.MULTILINE,
        ),
    ),
    # Bare number on its own line "1" — lowest priority, only inside the
    # specific-questions section (Format C)
    (
        "bare_number",
        re.compile(
            r"^(\d{1,2})\s*$",
            re.MULTILINE,
        ),
    ),
]

# --- Back-matter detection (copyright/permission text after the commentary) ---
BACKMATTER_PATTERN = re.compile(
    r"permission\s+to\s+reproduce|copyright\s+acknowledgements?"
    r"|to\s+avoid\s+the\s+issue\s+of\s+disclosure",
    re.IGNORECASE,
)


# =============================================================================
# SPEC LAYER 1: PDF LOADER
# =============================================================================

def load_er_pdf(er_path: str | Path) -> List[str]:
    """
    Extract raw text from every page of an Examiner Report PDF.
    Page-edge bare page numbers are stripped here (page-local operation).
    Returns list of page strings (one per page).
    """
    er_path = Path(er_path)
    if not er_path.exists():
        raise FileNotFoundError(f"ER PDF not found: {er_path}")

    doc = fitz.open(str(er_path))
    pages: List[str] = []
    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text("text", flags=fitz.TEXT_PRESERVE_WHITESPACE)
        lines = text.splitlines()
        # FIX-2: strip bare page numbers only at page edges
        for idx in list(range(min(2, len(lines)))) + list(range(max(2, len(lines) - 2), len(lines))):
            if 0 <= idx < len(lines) and _BARE_PAGE_NUM_RE.match(lines[idx]):
                lines[idx] = ""
        pages.append("\n".join(lines))
    doc.close()
    return pages


# =============================================================================
# SPEC LAYER 2: TEXT CLEANER
# =============================================================================

def clean_er_text(raw_pages: List[str]) -> str:
    """
    Join pages, fix ligatures, strip running headers/footers, rejoin hyphenated
    line breaks, and normalise whitespace. Junk stripping happens BEFORE any
    section splitting or question parsing (spec ordering requirement).
    """
    joined = "\n\n".join(raw_pages)

    # 1. Ligatures and special characters — before ANY regex matching
    for char, replacement in LIGATURE_MAP.items():
        joined = joined.replace(char, replacement)

    # 2. Legacy self-defence: strip our own report banner if a generated
    #    examiner_report.txt is ever re-parsed
    joined = re.sub(
        r"={10,}\s*\n(?:CAMBRIDGE\s+EXAMINER\s+REPORT[^\n]*\n"
        r"|CAMBRIDGE\s+PRINCIPAL\s+EXAMINER\s+REPORT[^\n]*\n"
        r"|Subject:[^\n]*\n|={1,}\n)+",
        "",
        joined,
        flags=re.IGNORECASE,
    )

    # 3. Running header/footer junk lines (before section splitting)
    lines = joined.splitlines()
    kept = [ln for ln in lines if not any(p.match(ln) for p in PAGE_JUNK_LINE_PATTERNS)]
    joined = "\n".join(kept)

    # 4. Rejoin hyphenated line breaks ("identi-\nfied" -> "identified").
    #    FIX-5: also heal hyphenation split across a page break — stripped
    #    running headers leave blank/whitespace-only lines in between. Only
    #    lowercase->lowercase joins are allowed, so legitimate dash usage
    #    ("...word -\nNext sentence") can never be fused.
    joined = re.sub(r"([a-z])-\n(?:[ \t]*\n)*([a-z])", r"\1\2", joined)

    # 5. Collapse runs of blank lines to max 2; trim trailing whitespace
    joined = re.sub(r"\n{3,}", "\n\n", joined)
    joined = "\n".join(ln.rstrip() for ln in joined.splitlines())
    return joined


# =============================================================================
# SPEC LAYER 3: SECTION SPLITTER
# =============================================================================

def split_er_sections(cleaned_text: str) -> Tuple[str, str, str]:
    """
    Split full ER text into (general, specific, backmatter).
    The 'specific' block (Comments on Specific Questions) is the primary target.
    Section titles matched line-anchored first (FIX-4), loose pattern as
    fallback; final fallback: the first question header.
    """
    text = cleaned_text

    # Back-matter: trim from the end
    bm_match = BACKMATTER_PATTERN.search(text)
    if bm_match:
        backmatter = text[bm_match.start():]
        text = text[:bm_match.start()]
    else:
        backmatter = ""

    # Specific-questions boundary: line-anchored first, loose fallback
    specific_match = SPECIFIC_SECTION_LINE.search(text)
    if not specific_match:
        specific_match = SPECIFIC_SECTION_PATTERN.search(text)

    if specific_match:
        general_text = text[:specific_match.start()].strip()
        specific_text = text[specific_match.end():].strip()
    else:
        q1_match = re.search(
            r"^" + _QUESTION_PREFIX + r"1(?:[ \t]*\([a-z]+\))*[ \t]*$",
            text,
            re.IGNORECASE | re.MULTILINE,
        )
        if q1_match:
            general_text = text[:q1_match.start()].strip()
            specific_text = text[q1_match.start():].strip()
        else:
            general_text = ""
            specific_text = text.strip()

    # General block: when an explicit "General Comments" header exists, start
    # there so cover/component title lines are not included.
    g_match = GENERAL_SECTION_LINE.search(general_text)
    if not g_match:
        g_match = GENERAL_SECTION_PATTERN.search(general_text)
    if g_match:
        general_text = general_text[g_match.end():].strip()

    return general_text, specific_text, backmatter


# =============================================================================
# SPEC LAYER 4: QUESTION PARSER
# =============================================================================

def _split_by_pattern(text: str, pattern: re.Pattern) -> List[Tuple[str, str]]:
    """Split text into [(qnum, commentary), ...] using a header pattern whose
    group 1 is the question number. The header line itself is excluded from
    the commentary. Empty list when nothing matches."""
    matches = list(pattern.finditer(text))
    if not matches:
        return []
    segments: List[Tuple[str, str]] = []
    for i, match in enumerate(matches):
        qnum = match.group(1)
        content_start = match.end()
        content_end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        commentary = text[content_start:content_end].strip()
        segments.append((qnum, commentary))
    return segments


def parse_question_commentaries(
    specific_text: str,
    use_bare_number_fallback: bool = True,
) -> Dict[str, str]:
    """
    Parse the specific-questions section into { "1": "...", "2": "...", ... }.
    Sub-part headers (Formats E) and repeated headers for the same number are
    concatenated into the parent question's single block. High-confidence
    patterns are tried first; bare numbers are the documented last resort.
    """
    splits = _split_by_pattern(specific_text, QUESTION_HEADER_PATTERNS[0][1])
    if not splits:
        splits = _split_by_pattern(specific_text, QUESTION_HEADER_PATTERNS[1][1])
    if not splits:
        splits = _split_by_pattern(specific_text, QUESTION_HEADER_PATTERNS[2][1])
    if not splits and use_bare_number_fallback:
        print("  [examiner-report] WARNING: bare-number fallback used for question "
              "detection; verify output for this ER manually.")
        splits = _split_by_pattern(specific_text, QUESTION_HEADER_PATTERNS[3][1])
    if not splits:
        print("  [examiner-report] ERROR: no question boundaries detected in the "
              "specific section; storing block as Q_UNKNOWN.")
        return {"UNKNOWN": specific_text.strip()} if specific_text.strip() else {}

    # Concatenate every occurrence of the same number (sub-part headers,
    # repeated headers) into ONE block per question number
    result: Dict[str, str] = {}
    for raw_qnum, commentary in splits:
        qnum = str(int(raw_qnum))
        existing = result.get(qnum, "")
        result[qnum] = (existing + "\n\n" + commentary.strip()) if existing else commentary.strip()
    return result


# =============================================================================
# SPEC LAYER 6: ER WRITER
# =============================================================================

REPORT_HEADER_TEMPLATE = """\
================================================================================
CAMBRIDGE EXAMINER REPORT - QUESTION ANALYSIS
Subject: {subject} ({syllabus_code}) | Series: {season} {year} | Paper: {paper_code} | Question: Q{qnum}
================================================================================

{commentary}
"""

REPORT_FULL_TEMPLATE = """\
================================================================================
CAMBRIDGE EXAMINER REPORT - GENERAL COMMENTS
Subject: {subject} ({syllabus_code}) | Series: {season} {year} | Paper: {paper_code}
================================================================================

{general_text}
"""

FALLBACK_NO_QCOMMENT_TEMPLATE = """\
================================================================================
CAMBRIDGE EXAMINER REPORT - QUESTION-SPECIFIC COMMENTARY NOT FOUND
Subject: {subject} ({syllabus_code}) | Series: {season} {year} | Paper: {paper_code} | Question: Q{qnum}
================================================================================

An Examiner Report was found for this paper, but no specific commentary
was identified for Question {qnum}.

--- GENERAL COMMENTS (Full Paper) ---

{general_text}
"""

# NOTE: the spec's FALLBACK_NO_ER_TEMPLATE is deliberately NOT implemented:
# the overseer directive ("if there is no ER continue process") supersedes
# spec Invariant 6. When no ER exists or no verified match is found, the
# pipeline continues and writes no placeholder file.


def write_question_er(
    question_folder: Path,
    qnum: str,
    commentary: Optional[str],
    general_text: str,
    paper_meta: dict,
) -> str:
    """
    Write examiner_report.txt into a single question folder.
    Chain: full commentary -> general-comments fallback -> skip (no placeholder).
    Returns status: "written" | "general_fallback" | "skipped_no_content".
    """
    question_folder = Path(question_folder)
    dest = question_folder / "examiner_report.txt"

    meta = {
        "subject": paper_meta.get("subject", "Unknown"),
        "syllabus_code": paper_meta.get("syllabus_code", ""),
        "season": paper_meta.get("season", ""),
        "year": paper_meta.get("year", ""),
        "paper_code": paper_meta.get("paper_code", ""),
        "qnum": qnum,
    }

    if commentary and commentary.strip():
        content = REPORT_HEADER_TEMPLATE.format(commentary=commentary.strip(), **meta)
        status = "written"
    elif general_text and general_text.strip():
        content = FALLBACK_NO_QCOMMENT_TEMPLATE.format(
            general_text=general_text.strip(), **meta
        )
        status = "general_fallback"
    else:
        # Overseer directive: continue process, never write placeholders.
        return "skipped_no_content"

    dest.write_text(content, encoding="utf-8")
    return status


def write_full_er(
    component_folder: Path,
    general_text: str,
    paper_meta: dict,
) -> None:
    """Write examiner_report_full.txt into the paper component folder
    (General Comments for the whole paper)."""
    component_folder = Path(component_folder)
    component_folder.mkdir(parents=True, exist_ok=True)
    dest = component_folder / "examiner_report_full.txt"
    content = REPORT_FULL_TEMPLATE.format(
        general_text=general_text.strip() if general_text else "No general comments extracted.",
        subject=paper_meta.get("subject", "Unknown"),
        syllabus_code=paper_meta.get("syllabus_code", ""),
        season=paper_meta.get("season", ""),
        year=paper_meta.get("year", ""),
        paper_code=paper_meta.get("paper_code", ""),
    )
    dest.write_text(content, encoding="utf-8")


# =============================================================================
# LOCKED DATACLASSES (extended additively only)
# =============================================================================

@dataclass
class ComponentReport:
    """Extracted examiner report for a single paper/component (e.g. Paper 9701/22)."""
    syllabus_code: str
    paper_code: str
    season: str
    year: int
    subject: str
    general_comments: str = ""
    question_comments: Dict[str, str] = field(default_factory=dict)  # "1" -> text, "2" -> text...
    raw_text: str = ""
    backmatter_text: str = ""  # additive (spec): trimmed copyright/permission block


@dataclass
class ParsedExaminerReportDoc:
    """Full parsed Examiner Report PDF, which may cover multiple paper components."""
    file_path: str
    syllabus_code: str
    season: str
    year: int
    subject: str
    component_reports: Dict[str, ComponentReport] = field(default_factory=dict)  # "22" -> ComponentReport


# =============================================================================
# PARSER  (locked public API; internals now delegate to the spec engine)
# =============================================================================

class ExaminerReportParser:
    """Parses Cambridge Principal Examiner Reports and segments them into component and question sections."""

    @classmethod
    def parse_pdf(cls, pdf_path: str | Path) -> Optional[ParsedExaminerReportDoc]:
        pdf_path = Path(pdf_path)
        if not pdf_path.exists():
            return None

        try:
            raw_pages = load_er_pdf(pdf_path)   # spec Layer 1 (incl. page-edge numbers)
            if not raw_pages:
                return None
        except Exception as e:
            print(f"[examiner-report] WARNING: Could not read PDF {pdf_path.name}: {e}")
            return None

        # Ligature normalisation precedes ALL matching (spec requirement)
        combined_text = "\n".join(raw_pages)
        for char, replacement in LIGATURE_MAP.items():
            combined_text = combined_text.replace(char, replacement)

        # 1. Detect Syllabus Code, Subject, Year, and Season (unchanged logic)
        syllabus_code = ""
        year = 2024
        season = "Summer"
        stem = pdf_path.stem

        # Try matching standard Cambridge filename pattern (e.g. 9701_m26_er_22 or 9701_s24_er)
        m_std = re.search(r"(\d{4})[_ -]?(s|w|m|mj|on|fm|sp|z|y)(\d{2})[_ -]?(?:er|examiner)", stem, re.I)
        if m_std:
            syllabus_code = m_std.group(1)
            raw_s = m_std.group(2).lower()
            year = 2000 + int(m_std.group(3))
            if raw_s in {"w", "on"}:
                season = "Winter"
            elif raw_s in {"m", "fm"}:
                season = "Spring"
            elif raw_s in {"sp", "z", "y"}:
                season = "Specimen"
            else:
                season = "Summer"
        else:
            m_syl = re.search(r"\b(\d{4})\b", stem)
            if m_syl:
                syllabus_code = m_syl.group(1)
            else:
                m_syl_text = re.search(r"\b(?:Syllabus|Paper)\s*(\d{4})\b", combined_text, re.I)
                if m_syl_text:
                    syllabus_code = m_syl_text.group(1)

            # Detect Year from stem or text
            m_yr4 = re.search(r"\b(20\d{2})\b", stem)
            if m_yr4:
                year = int(m_yr4.group(1))
            else:
                m_yr_text = re.search(r"\b(?:June|November|March|Summer|Winter|Spring|Series)\s*(20\d{2})\b", combined_text, re.I)
                if m_yr_text:
                    year = int(m_yr_text.group(1))

            # Detect Season
            stem_low = stem.lower()
            if "_w" in stem_low or "_on" in stem_low or "nov" in stem_low or "winter" in stem_low:
                season = "Winter"
            elif "_m" in stem_low or "_fm" in stem_low or "mar" in stem_low or "spring" in stem_low or "feb" in stem_low:
                season = "Spring"
            elif re.search(r"\b(?:November|October|Winter|Oct/Nov)\b", combined_text, re.I):
                season = "Winter"
            elif re.search(r"\b(?:March|February|Spring|Feb/Mar)\b", combined_text, re.I):
                season = "Spring"

        subject = detect_subject(syllabus_code) if syllabus_code else "Unknown"
        season = canonical_season(season)

        doc_report = ParsedExaminerReportDoc(
            file_path=str(pdf_path),
            syllabus_code=syllabus_code,
            season=season,
            year=year,
            subject=subject,
        )

        # 2. Segment text by Paper / Component headers (unchanged anchors)
        # Cambridge ER format: "CHEMISTRY Paper 9701/22 AS Level Structured Questions" or "Paper 9701/42"
        comp_pattern = re.compile(
            r"(?:(?:CAMBRIDGE\s+INTERNATIONAL|PRINCIPAL\s+EXAMINER\s+REPORT)[^\n]*\n+)?"
            r"(?:[A-Z\s]{3,30}\n+)?"
            r"Paper\s*(?:" + re.escape(syllabus_code or r"\d{4}") + r")?\s*/\s*(\d{1,3})[^\n]*\n",
            re.IGNORECASE,
        )

        matches = list(comp_pattern.finditer(combined_text))
        if not matches:
            # Fallback: check if the entire PDF is a single paper report
            m_paper_stem = re.search(r"_(?:qp|ms|er|in)_(\d{1,3})\b", pdf_path.stem)
            paper_code = m_paper_stem.group(1) if m_paper_stem else "22"
            comp_rep = cls._parse_component_text(combined_text, syllabus_code, paper_code, season, year, subject)
            doc_report.component_reports[paper_code] = comp_rep
            return doc_report

        for i, match in enumerate(matches):
            p_code = match.group(1).lstrip("0") or match.group(1)
            start_pos = match.start()
            end_pos = matches[i + 1].start() if i + 1 < len(matches) else len(combined_text)
            comp_text = combined_text[start_pos:end_pos]

            comp_rep = cls._parse_component_text(comp_text, syllabus_code, p_code, season, year, subject)
            doc_report.component_reports[p_code] = comp_rep

        return doc_report

    @classmethod
    def _parse_component_text(
        cls,
        text: str,
        syllabus: str,
        paper_code: str,
        season: str,
        year: int,
        subject: str,
    ) -> ComponentReport:
        """Parse individual component text into General comments and Question comments."""
        clean = cls._clean_text(text)

        general_text, specific_text, backmatter = split_er_sections(clean)
        question_comments = parse_question_commentaries(specific_text) if specific_text else {}

        return ComponentReport(
            syllabus_code=syllabus,
            paper_code=paper_code,
            season=season,
            year=year,
            subject=subject,
            general_comments=general_text,
            question_comments=question_comments,
            raw_text=clean,
            backmatter_text=backmatter,
        )

    @staticmethod
    def _clean_text(text: str) -> str:
        """Clean PDF text extraction artifacts, running headers, and line breaks.

        Delegates to the spec engine (clean_er_text) so the same cleaning is
        used by the class API and the functional API."""
        return clean_er_text([text])


# =============================================================================
# MATCHER  (locked strict multi-signal verification — retained unchanged)
# =============================================================================

class ExaminerReportMatcher:
    """Strict multi-step matching engine for Question Papers, Mark Schemes, and Examiner Reports."""

    @classmethod
    def match_report(
        cls,
        parsed_docs: List[ParsedExaminerReportDoc],
        syllabus_code: str,
        paper_code: str,
        season: str,
        year: int,
        expected_questions: Optional[Set[str]] = None,
    ) -> Tuple[Optional[ComponentReport], float, List[str]]:
        """
        Evaluate candidate reports against the Question Paper metadata.
        Returns (winning_component_report, confidence_score, verification_logs).
        """
        p_code = str(paper_code or "").lstrip("0") or str(paper_code or "")
        canon_season = canonical_season(season)
        logs: List[str] = []

        best_report: Optional[ComponentReport] = None
        best_score = 0.0

        for doc in parsed_docs:
            # 1. Syllabus Match (+20)
            score = 0.0
            if doc.syllabus_code == syllabus_code:
                score += 20.0
            else:
                continue

            # 2. Subject Match (+20)
            if doc.subject and doc.subject != "Unknown":
                score += 20.0

            # 3. Year Match (+15)
            if doc.year == year:
                score += 15.0
            else:
                logs.append(f"Year mismatch: doc={doc.year} vs qp={year}")
                continue

            # 4. Season / Series Match (+15)
            if doc.season == canon_season:
                score += 15.0
            else:
                logs.append(f"Series mismatch: doc={doc.season} vs qp={canon_season}")
                continue

            # 5. Component / Paper Code Match (+15)
            comp_rep = doc.component_reports.get(p_code)
            if comp_rep:
                score += 15.0
            else:
                # Check single-digit or zero-padded variant match
                for alt_code, rep in doc.component_reports.items():
                    if alt_code.lstrip("0") == p_code.lstrip("0"):
                        comp_rep = rep
                        score += 15.0
                        break

            if not comp_rep:
                logs.append(f"Component {p_code} not found in {Path(doc.file_path).name}")
                continue

            # 6. Variant Match (+10)
            if comp_rep.paper_code == p_code:
                score += 10.0

            # 7. Content / Question Alignment (+5)
            if expected_questions and comp_rep.question_comments:
                q_intersect = expected_questions.intersection(set(comp_rep.question_comments.keys()))
                if q_intersect:
                    score += 5.0

            if score > best_score:
                best_score = score
                best_report = comp_rep

        # Confidence is score / 100.0
        confidence = min(1.0, best_score / 100.0)
        is_verified = (confidence >= 0.80) and (best_report is not None)

        if is_verified:
            logs.append(f"Verified Examiner Report match: {syllabus_code}_{p_code}_{canon_season}_{year} (conf={confidence:.2f})")
            return best_report, confidence, logs
        else:
            return None, confidence, logs


# =============================================================================
# DOTACLASS -> SOURCE DOC BACKREF
# =============================================================================

def _source_doc_for(comp_report: ComponentReport,
                    parsed_docs: List[ParsedExaminerReportDoc]) -> Optional[ParsedExaminerReportDoc]:
    """Find the parsed doc that produced a component report (identity scan),
    so the visual WebP is always rendered from the ER that actually matched —
    not blindly from parsed_docs[0] as the locked baseline did."""
    for doc in parsed_docs:
        for rep in doc.component_reports.values():
            if rep is comp_report:
                return doc
    return None


# =============================================================================
# LEGACY ATTACH PATH  (kept for API compatibility; import bug fixed)
# =============================================================================

def attach_examiner_reports(
    questions: List["Question"],
    er_papers: List["PaperInfo"],
    output_dir: str | Path,
    subject: str,
    syllabus_code: str,
) -> Dict[str, int]:
    """
    Process verified Examiner Reports and attach question-specific report text
    into every corresponding question folder. (Legacy path — production uses
    attach_examiner_reports_to_output; kept for API compatibility.)
    """
    from .paper_scan import PaperInfo  # noqa: F401  (type context, legacy path)
    from .question_split import Question  # noqa: F401  (type context, legacy path)

    root = Path(output_dir)
    subject_dir = root / subject
    stats = {"reports_parsed": 0, "questions_attached": 0, "general_reports_written": 0}

    if not er_papers:
        print("[examiner-report] No Examiner Report PDFs found in input papers.")
        return stats

    print(f"[examiner-report] Parsing {len(er_papers)} Examiner Report PDF(s)...")

    # 1. Parse all Examiner Report PDFs
    parsed_docs: List[ParsedExaminerReportDoc] = []
    for er_p in er_papers:
        pdoc = ExaminerReportParser.parse_pdf(er_p.path)
        if pdoc:
            parsed_docs.append(pdoc)
            stats["reports_parsed"] += 1

    if not parsed_docs:
        print("[examiner-report] Could not extract text from Examiner Report PDFs.")
        return stats

    # 2. Group questions by examination identity (paper_code, season, year)
    grouped_questions: Dict[Tuple[str, str, int], List["Question"]] = {}
    for q in questions:
        if q.is_duplicate or not q.images:
            continue
        p_code = str(q.paper_code or "").lstrip("0") or str(q.paper_code or "")
        season = canonical_season(q.session_label or "Unknown")
        year = int(q.year or 0)
        grouped_questions.setdefault((p_code, season, year), []).append(q)

    # 3. Match and attach for each examination series
    from .output_manager import _paper_type_folder  # FIXED: was .organize (module does not exist in core/)

    for (p_code, season, year), q_list in grouped_questions.items():
        expected_qnums = {str(q.question_number) for q in q_list}
        comp_report, confidence, match_logs = ExaminerReportMatcher.match_report(
            parsed_docs=parsed_docs,
            syllabus_code=syllabus_code,
            paper_code=p_code,
            season=season,
            year=year,
            expected_questions=expected_qnums,
        )

        for log in match_logs:
            print(f"  [er-match] {log}")

        if not comp_report:
            print(f"  [er-skip] No verified Examiner Report match for {syllabus_code}_{p_code}_{season}_{year}")
            continue

        pt_folder = _paper_type_folder(p_code, syllabus_code=syllabus_code)

        # 4. Write component-level general report if available
        paper_meta = {
            "subject": subject,
            "syllabus_code": syllabus_code,
            "paper_code": p_code,
            "season": season,
            "year": year,
        }
        if comp_report.general_comments and len(comp_report.general_comments) > 40:
            comp_folder_path = subject_dir / pt_folder
            write_full_er(comp_folder_path, comp_report.general_comments, paper_meta)
            stats["general_reports_written"] += 1
            print(f"  [er-write] Wrote component summary: "
                  f"{(comp_folder_path / 'examiner_report_full.txt').relative_to(root)}")

        # 5. Write question-specific reports into each question's folder
        # NOTE: title header preserved from the locked baseline ("PRINCIPAL
        # EXAMINER REPORT - QUESTION ANALYSIS" wording family retained by the
        # spec templates; body chain identical to write_question_er).
        separator = "=" * 80
        for q in q_list:
            qnum = str(q.question_number)
            q_comments = comp_report.question_comments.get(qnum)

            # Locate question's physical folder
            base = f"{p_code}_{season}_{year}_Q{q.question_number}"
            winning_topic = q.topic[0] if q.topic and q.topic != ["Uncategorized"] else "Needs_Review"
            q_folder = subject_dir / pt_folder / winning_topic / base

            if not q_folder.exists():
                # Search by folder name
                matched_dirs = list(subject_dir.rglob(base))
                if matched_dirs:
                    q_folder = matched_dirs[0]

            if q_folder.exists():
                er_out_path = q_folder / "examiner_report.txt"
                report_header = (
                    f"{separator}\n"
                    f"CAMBRIDGE EXAMINER REPORT - QUESTION ANALYSIS\n"
                    f"Subject: {subject} ({syllabus_code}) | Series: {season} {year} | Paper: {p_code} | Question: Q{qnum}\n"
                    f"{separator}\n\n"
                )
                if q_comments and len(q_comments.strip()) >= 10:
                    er_body = q_comments.strip()
                elif comp_report.general_comments and len(comp_report.general_comments.strip()) >= 10:
                    er_body = (
                        f"General Component Comments & Overview:\n\n"
                        f"{comp_report.general_comments.strip()}\n\n"
                        f"[Note: No individual per-question commentary was provided for Q{qnum} in this Examiner Report.]"
                    )
                else:
                    # overseer directive: no placeholder content
                    print(f"  [er-skip] Verified ER has no usable content for {p_code} Q{qnum}")
                    continue

                er_out_path.write_text(report_header + er_body + "\n", encoding="utf-8")
                stats["questions_attached"] += 1
                print(f"  [er-attach] Attached examiner report to {q_folder.relative_to(root)}/examiner_report.txt")

    print(f"[examiner-report] Completed: {stats['questions_attached']} question report(s) attached.")
    return stats


def _render_examiner_report_webp(report_path: str | Path, destination: Path) -> None:
    """Render the original ER PDF pages as one visual WebP document."""
    from PIL import Image
    doc = fitz.open(str(report_path))
    pages = []
    for page in doc:
        pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
        pages.append(Image.frombytes("RGB", (pix.width, pix.height), pix.samples))
    doc.close()
    if not pages:
        raise ValueError("Examiner Report has no pages")
    width = max(im.width for im in pages)
    height = sum(im.height for im in pages)
    canvas = Image.new("RGB", (width, height), "white")
    y = 0
    for im in pages:
        canvas.paste(im, (0, y))
        y += im.height
    if canvas.width != 2280:
        canvas = canvas.resize((2280, max(1, round(canvas.height * 2280 / canvas.width))), Image.LANCZOS)
    destination.parent.mkdir(parents=True, exist_ok=True)
    # ER-2 (2026-08-10): route through the tiling saver — a long ER stacked to
    # 2280px width exceeds the WebP 16383px dimension limit (first caught on
    # the real 16-page 9700_m25_er.pdf: ~51600px canvas -> encoder refused).
    # save_webp keeps the destination filename as tile 1 and writes _part2...
    # only when needed; short ERs still produce exactly one file, as before.
    from .webp_utils import save_webp
    save_webp(canvas, destination, quality=95)


# =============================================================================
# PRODUCTION ATTACH PATH  (main.py) — extended with spec artifacts
# =============================================================================

def attach_examiner_reports_to_output(er_papers, output_root: str | Path) -> Dict[str, object]:
    """Attach verified ``examiner_report.txt`` files to existing question bundles.

    This is the production integration for files already identified as ``er`` by
    the filename parser.  It does not crop, classify, move, or rename question
    files.  It reads each question's metadata and uses strict syllabus, season,
    year, component, variant and question-number matching before writing the
    fixed report filename in that same question folder.

    Spec extensions (overseer-approved merge):
      * parses ERs with the spec v1.0 engine (multi-format headers, section
        variants, ligature/junk/hyphenation cleanup, sub-part concatenation),
      * additionally writes per-question ``examiner_report.txt`` (commentary,
        falling back to the paper's General Comments with an explicit note),
      * writes ``examiner_report_full.txt`` into each verified component folder,
      * returns a per-question ``status_map`` for pipeline logging.

    Overseer fallback directive: when no ER exists or no match verifies, the
    process CONTINUES and no placeholder files are written.
    """
    import json

    root = Path(output_root)
    stats: Dict[str, object] = {
        "reports_detected": len(er_papers),
        "reports_parsed": 0,
        "questions_attached": 0,
        "text_reports_written": 0,
        "full_reports_written": 0,
        "status_map": {},
        "skipped": [],
        "errors": [],
    }
    if not er_papers:
        return stats

    parsed_docs: List[ParsedExaminerReportDoc] = []
    for paper in er_papers:
        # This guard ensures only files explicitly identified as ERs are ever
        # handed to this path.
        if getattr(paper, "paper_type", None) != "er":
            stats["skipped"].append(f"Not an ER file: {getattr(paper, 'file_path', paper)}")
            continue
        report_path = Path(getattr(paper, "file_path", paper))
        parsed = ExaminerReportParser.parse_pdf(report_path)
        if not parsed or not parsed.syllabus_code or not parsed.component_reports:
            stats["errors"].append(f"Could not parse Examiner Report: {report_path.name}")
            continue
        parsed_docs.append(parsed)
        stats["reports_parsed"] += 1

    # Verified component folders awaiting examiner_report_full.txt:
    # identity -> {"report": ComponentReport, "pt_folder": Path, "meta": dict}
    verified_components: Dict[Tuple[str, str, int, str], Dict[str, object]] = {}

    from .output_manager import _paper_type_folder

    for json_path in root.rglob("metadata.json"):
        try:
            with json_path.open("r", encoding="utf-8") as fh:
                metadata = json.load(fh)
            paper = str(metadata.get("paper", ""))
            match = re.fullmatch(r"(\d{4})_([msw])(\d{2})_qp_(\d{1,3})", paper, re.I)
            if not match:
                continue
            syllabus, season_letter, year_short, component = match.groups()
            season = {"m": "Spring", "s": "Summer", "w": "Winter"}[season_letter.lower()]
            year = 2000 + int(year_short)
            qnum = str(metadata.get("question_number", "")).lstrip("Q")
            if not qnum:
                stats["errors"].append(f"Missing question number: {json_path}")
                continue

            report, confidence, logs = ExaminerReportMatcher.match_report(
                parsed_docs=parsed_docs,
                syllabus_code=syllabus,
                paper_code=component,
                season=season,
                year=year,
                expected_questions={qnum},
            )
            if not report:
                stats["skipped"].append(
                    f"No verified ER match for {paper} Q{qnum}: {'; '.join(logs)}"
                )
                stats["status_map"][f"{paper}:Q{qnum}"] = "no_verified_er"
                continue

            paper_meta = {
                "subject": detect_subject(syllabus),
                "syllabus_code": syllabus,
                "paper_code": paper,
                "season": season,
                "year": str(year),
            }

            # Question sections retain their original sub-question text such as
            # (a), (b), (i), and (ii). If the report gives component-level
            # comments only, preserve those verbatim with an explicit note.
            question_comment = report.question_comments.get(qnum)
            txt_status = write_question_er(
                question_folder=json_path.parent,
                qnum=qnum,
                commentary=question_comment,
                general_text=report.general_comments or "",
                paper_meta=paper_meta,
            )
            if txt_status in ("written", "general_fallback"):
                stats["text_reports_written"] += 1
            stats["status_map"][f"{paper}:Q{qnum}"] = txt_status

            er_name = f"{metadata['variant']}_{metadata['season']}_{metadata['year']}_ER.webp"
            out_path = json_path.parent / er_name
            # Preserve the original visual report document; do not summarize or
            # convert it to text output. The strict match above selects the ER.
            src_doc = _source_doc_for(report, parsed_docs)
            if src_doc is None:
                raise ValueError("Matched component report has no source document")
            _render_examiner_report_webp(src_doc.file_path, out_path)
            if out_path.name != er_name or not out_path.exists() or out_path.stat().st_size == 0:
                raise ValueError("ER visual WebP output validation failed")
            stats["questions_attached"] += 1

            # Register the verified component for the full (general) report
            identity = (syllabus, season, year, component)
            if identity not in verified_components:
                expected_pt = _paper_type_folder(component, syllabus_code=syllabus)
                pt_path: Optional[Path] = None
                for ancestor in [json_path.parent, *json_path.parents]:
                    if ancestor.name == expected_pt:
                        pt_path = ancestor
                        break
                verified_components[identity] = {
                    "report": report,
                    "pt_folder": pt_path,
                    "meta": paper_meta,
                }
        except Exception as exc:
            stats["errors"].append(f"ER attachment failed for {json_path}: {exc}")

    # Component-level examiner_report_full.txt — one per verified paper identity
    for (syllabus, season, year, component), info in verified_components.items():
        try:
            pt_path = info["pt_folder"]
            if pt_path is None:
                stats["errors"].append(
                    f"Could not locate component folder for {syllabus}_{component} "
                    f"{season} {year}; examiner_report_full.txt not written"
                )
                continue
            report = info["report"]
            write_full_er(pt_path, report.general_comments or "", info["meta"])
            stats["full_reports_written"] += 1
            print(f"  [er-write] Wrote component summary: {pt_path / 'examiner_report_full.txt'}")
        except Exception as exc:
            stats["errors"].append(f"examiner_report_full.txt failed for {syllabus}_{component}: {exc}")

    return stats
