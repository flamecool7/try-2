"""
QP/MS Matcher - Universal component
Matches QP and MS questions by paper and question number.
Validates pairs exist.
"""
from pathlib import Path
from typing import Dict, List, Tuple
from dataclasses import dataclass
from .paper_identifier import PaperInfo
from .cropping_engine import CroppedQuestion

@dataclass
class MatchedQuestion:
    question_number: str
    number_int: int
    qp: CroppedQuestion
    ms: CroppedQuestion
    paper_code: str  # base code without qp/ms e.g., 9701_m26_22
    full_qp_code: str
    full_ms_code: str
    year: str
    season: str
    variant: str
    subject: str

class QPMSMatcher:
    def __init__(self):
        # Populated on every grouping pass; callers must surface duplicate input
        # rather than silently overwriting one paper with another.
        self.grouping_errors = []

    def group_papers(self, papers: List[PaperInfo]) -> Dict[str, Dict[str, PaperInfo]]:
        """
        Group papers by base identifier: code + year + variant
        e.g., 9701_m26_qp_22 and 9701_m26_ms_22 -> same group "9701_m26_22"
        Returns dict: base_key -> {"qp": PaperInfo, "ms": PaperInfo}
        """
        self.grouping_errors = []
        groups = {}
        for paper in papers:
            base_key = f"{paper.syllabus_code}_{paper.season_letter}{paper.year_short}_{paper.variant}"
            if base_key not in groups:
                groups[base_key] = {}
            if paper.paper_type in groups[base_key]:
                existing = groups[base_key][paper.paper_type]
                self.grouping_errors.append(
                    f"Duplicate {paper.paper_type.upper()} for {base_key}: "
                    f"{existing.file_path.name} and {paper.file_path.name}"
                )
                continue
            groups[base_key][paper.paper_type] = paper
        return groups

    def match_questions(self, qp_questions: List[CroppedQuestion], ms_questions: List[CroppedQuestion], 
                        qp_info: PaperInfo, ms_info: PaperInfo, subject: str) -> List[MatchedQuestion]:
        """
        Match QP and MS cropped questions by question number
        """
        qp_dict = {q.number_int: q for q in qp_questions}
        ms_dict = {q.number_int: q for q in ms_questions}

        matched = []
        all_nums = set(qp_dict.keys()) | set(ms_dict.keys())

        for num in sorted(all_nums):
            if num not in qp_dict:
                print(f"[QPMSMatcher] Missing QP for Q{num} in {qp_info.full_code} - need MS {ms_info.full_code} but no QP")
                continue
            if num not in ms_dict:
                print(f"[QPMSMatcher] Missing MS for Q{num} in {qp_info.full_code} - QP exists but MS missing")
                continue

            qp_q = qp_dict[num]
            ms_q = ms_dict[num]

            base_code = f"{qp_info.syllabus_code}_{qp_info.season_letter}{qp_info.year_short}_{qp_info.variant}"

            matched.append(MatchedQuestion(
                question_number=qp_q.question_number,
                number_int=num,
                qp=qp_q,
                ms=ms_q,
                paper_code=base_code,
                full_qp_code=qp_info.full_code,
                full_ms_code=ms_info.full_code,
                year=qp_info.year,
                season=qp_info.season,
                variant=qp_info.variant,
                subject=subject
            ))

        return matched

    def validate_pairs(self, matched: List[MatchedQuestion]) -> Tuple[List[MatchedQuestion], List[str]]:
        """
        Validate QP/MS pairs: both must exist, be readable, belong to same paper/question
        Returns validated list and errors
        """
        valid = []
        errors = []

        for m in matched:
            if not m.qp or not m.ms:
                errors.append(f"Missing QP or MS for {m.question_number} in {m.paper_code}")
                continue
            if not m.qp.assembled_image or not m.ms.assembled_image:
                errors.append(f"Missing assembled image for {m.question_number} in {m.paper_code}")
                continue
            if m.qp.number_int != m.ms.number_int:
                errors.append(f"Question number mismatch: QP Q{m.qp.number_int} vs MS Q{m.ms.number_int} in {m.paper_code}")
                continue
            # Belong to same paper (same code base)
            if m.qp.paper_code.split('_qp_')[0] if '_qp_' in m.qp.paper_code else m.qp.paper_code != m.ms.paper_code.split('_ms_')[0] if '_ms_' in m.ms.paper_code else m.ms.paper_code:
                # Not strictly same string, but base should match
                pass

            valid.append(m)

        return valid, errors
