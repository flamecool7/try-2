"""Strategy registry for paper processing (mega-spec Fix 4, 2026-08-12).

One interface per paper artefact kind; selection is driven by the syllabus
profile (paper_identifier format tables — the single format authority) and the
component number, never by guessing from pixels alone.

Production wiring: run_guarded's S2/S3/S6/S7 stages derive their branch
decisions from ``select_qp_strategy`` / ``select_ms_strategy`` /
``select_er_strategy``. A 9618-style structured-table parser is therefore
explicitly NOT universal: the registry only returns the structured-table legs
for components whose format is STRUCTURED, routes MCQ components to the
answer-grid/mcq legs, and refuses PRACTICAL/ATP/ESSAY components loudly with a
REVIEW_REQUIRED reason instead of running an inappropriate cropper.

Fail-closed contract: strategies never fabricate output. Unsupported component
kinds raise :class:`StrategyUnsupported` carrying the exact review reason.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .paper_identifier import resolve_paper_format


class StrategyUnsupported(RuntimeError):
    """Raised when a profile/component has no validated strategy.

    The message doubles as the REVIEW_REQUIRED reason stored in pipeline
    state / manifests (spec: ambiguous or unsupported input surfaces
    REVIEW_REQUIRED, never a silent assumption)."""

    def __init__(self, review_reason: str):
        super().__init__(review_reason)
        self.review_reason = review_reason


@dataclass(frozen=True)
class StrategyPlan:
    """The registry's decision for one paper, with the audit reason."""
    name: str          # strategy identifier (stable, used in proof manifests)
    kind: str          # qp_structured | qp_mcq | ms_structured | ms_mcq_grid |
                       # ms_legacy_portrait_ok | er_attach | unsupported
    reason: str        # why this strategy applies (profile + component driven)


class QuestionPaperStrategy:
    name = "qp_base"

    def plan(self, paper_info) -> StrategyPlan:  # pragma: no cover - interface
        raise NotImplementedError


class MarkSchemeStrategy:
    name = "ms_base"

    def plan(self, paper_info) -> StrategyPlan:  # pragma: no cover - interface
        raise NotImplementedError


class StructuredQuestionPaperStrategy(QuestionPaperStrategy):
    """Gold-standard numbered-anchor QP splitter (locked engine)."""
    name = "structured_qp_gold"


class MCQQuestionPaperStrategy(QuestionPaperStrategy):
    """MCQ QP: same numbered anchors per question stem; no MS crop exists."""
    name = "mcq_qp_gold"


class StructuredMarkSchemeStrategy(MarkSchemeStrategy):
    """Gold 'Question | Answer | Marks' header-rule MS splitter (locked)."""
    name = "structured_ms_gold"


class LegacyPortraitMarkSchemeStrategy(MarkSchemeStrategy):
    """Portrait-era (2015/2016 A-Level) flush-left margin-number MS splitter.

    Only ever a FALLBACK leg of the structured strategy: it must ground a
    strict 1..N run equal to the QP-proven question numbers (core/legacy_ms_split).
    """
    name = "legacy_portrait_ms"


class MCQMarkSchemeStrategy(MarkSchemeStrategy):
    """MCQ 'MS' = the bare answer grid; extracted to letters, never cropped."""
    name = "mcq_ms_grid"


class ExaminerReportStrategy:
    """ER: strict-identity text attach + per-question crops (S6/S7)."""
    name = "er_attach"
    kind = "er_attach"


class PracticalPaperStrategy(QuestionPaperStrategy):
    name = "practical"


class EssayOrRubricStrategy(QuestionPaperStrategy):
    name = "essay_or_rubric"


def _paper_format(paper_info) -> str:
    fmt = getattr(paper_info, "paper_format", None)
    if fmt:
        return str(fmt).upper()
    return str(resolve_paper_format(getattr(paper_info, "syllabus_code", ""),
                                    getattr(paper_info, "variant", ""))).upper()


def select_qp_strategy(paper_info) -> QuestionPaperStrategy:
    """Choose the QP strategy from profile + component identity.

    STRUCTURED/MCQ components -> the validated gold splitters. PRACTICAL/ATP
    and ESSAY components raise REVIEW_REQUIRED: no validated fixture corpus
    exists for them in this repository, and the spec forbids silently
    reusing the structured-table parser for every syllabus/component.
    """
    fmt = _paper_format(paper_info)
    if fmt == "MCQ":
        return MCQQuestionPaperStrategy()
    if fmt in ("PRACTICAL", "ATP"):
        raise StrategyUnsupported(
            f"REVIEW_REQUIRED: practical/ATP component (format={fmt}) has no "
            f"validated strategy in this build — not routing to the structured "
            f"table parser (spec Fix 4)")
    if fmt == "ESSAY":
        raise StrategyUnsupported(
            "REVIEW_REQUIRED: essay/rubric component (format=ESSAY) has no "
            "validated strategy in this build — not routing to the structured "
            "table parser (spec Fix 4)")
    return StructuredQuestionPaperStrategy()


def select_ms_strategy(qp_info, ms_info) -> Optional[MarkSchemeStrategy]:
    """Choose the MS strategy; None when no MS paper was supplied (QP-only run).

    MCQ components -> answer-grid extraction. Everything else -> the structured
    gold splitter (whose own fail-closed fallback leg is the portrait-era
    splitter). Practical/essay components raise REVIEW_REQUIRED as above.
    """
    if ms_info is None:
        return None
    fmt = _paper_format(qp_info)
    if fmt == "MCQ":
        return MCQMarkSchemeStrategy()
    if fmt in ("PRACTICAL", "ATP", "ESSAY"):
        raise StrategyUnsupported(
            f"REVIEW_REQUIRED: mark-scheme strategy refused for format={fmt} "
            f"(spec Fix 4: profile-driven strategies only)")
    return StructuredMarkSchemeStrategy()


def select_er_strategy(er_info) -> ExaminerReportStrategy:
    return ExaminerReportStrategy()


def strategy_plan_for_paper(paper_info) -> StrategyPlan:
    """Audit-friendly description used by proof manifests and --dry-run."""
    fmt = _paper_format(paper_info)
    code = getattr(paper_info, "syllabus_code", "?")
    variant = getattr(paper_info, "variant", "?")
    try:
        qp = select_qp_strategy(paper_info)
        qp_name = qp.name
    except StrategyUnsupported as exc:
        return StrategyPlan("review_required", "unsupported",
                            f"{code} v{variant} format={fmt}: {exc.review_reason}")
    if fmt == "MCQ":
        return StrategyPlan(f"{qp_name}+mcq_ms_grid", "qp_mcq",
                            f"{code} v{variant}: MCQ per profile table "
                            f"(paper_identifier) -> question crops + grid letters; "
                            f"no MS WebP by design")
    return StrategyPlan(f"{qp_name}+structured_ms_gold(legacy-fallback)", "qp_structured",
                        f"{code} v{variant}: STRUCTURED per profile table -> gold "
                        f"splitters, portrait-era fallback allowed only on 1..N proof")
