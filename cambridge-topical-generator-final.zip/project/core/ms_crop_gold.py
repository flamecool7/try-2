"""
ms_crop.py
==========
Tight, general-purpose cropping for Cambridge mark-scheme images.

Problem it solves
-----------------
The topical generator stitches each question's mark scheme into a full-page-width
canvas (e.g. 1654 px wide). The black marking box therefore sits in the middle of
that canvas with ~100 px of white canvas margin on the left and right. In a few
cases (multi-page answers) the canvas can also contain a stray fragment and/or a
blank band below the box.

This module automatically finds the outer black border rectangle of the marking
box and crops the image as tightly as possible to it, removing every unnecessary
white margin (and any disconnected stray fragment) while never clipping the box
or its contents.

How it works (completely data-driven -- no fixed crop values)
--------------------------------------------------------------
1. Find the box's LEFT and RIGHT borders:
   The left/right borders of a Cambridge marking box are near-solid vertical
   black lines that run the full height of the box. We measure, for every
   column, the fraction of rows that contain a dark pixel. The left border is the
   *outermost* such "strong" column and the right border the *outermost* strong
   column. All internal vertical rules (e.g. the Question | Answer | Marks
   separators) are further in and therefore ignored automatically.

2. Find the box's TOP and BOTTOM borders:
   The left and right border columns are present wherever the box exists. We walk
   every row and mark it "inside" when a dark pixel is present in the left or
   right border column. Contiguous runs of such rows are the vertical extent of
   the box. Runs separated only by a small gap (anti-aliasing / a thin rule) are
   merged. The *longest* merged run is the box -- this cleanly discards any
   disconnected stray fragment separated by a real blank band.

3. Crop:
   The crop rectangle is the box extent expanded by a small `margin` (default
   1 px) on every side, clamped to the image edges. The small margin keeps a thin,
   clean white frame around the border (matching a manual GIMP crop) and avoids
   ever clipping the anti-aliased border.

It generalises to any Cambridge mark scheme: it keys only off the presence of the
outer black box border, not off any particular dimensions, syllabus or subject.
"""

from __future__ import annotations

import numpy as np
from PIL import Image

__all__ = ["crop_to_mark_box"]


def _row_and_col_profiles(img: Image.Image, dark_threshold: int):
    """Return (dark_mask, col_density, border_present).

    dark_mask      : boolean HxW array, True where a pixel is "dark".
    col_density    : per-column fraction of dark pixels (float[W]).
    border_present : per-row True when the eventual left or right border col is dark.
    """
    arr = np.asarray(img.convert("RGB")).astype(np.float32)
    gray = arr.mean(axis=2)
    dark = gray < dark_threshold
    col_density = dark.mean(axis=0)
    return dark, col_density


def _find_left_right_borders(col_density, col_threshold: float):
    """Return (left, right) outermost columns that look like a solid vertical line."""
    strong = np.where(col_density >= col_threshold)[0]
    if strong.size == 0:
        return None, None
    return int(strong.min()), int(strong.max())


def _largest_vertical_run(border_present: np.ndarray, gap_tol: int):
    """Return (top, bottom) of the longest row-run of True, merging small gaps.

    True rows are grouped into runs; runs whose separating gap is <= gap_tol rows
    are merged (this bridges thin rules / anti-aliasing but NOT a real blank band).
    The longest merged run is returned.
    """
    idx = np.where(border_present)[0]
    if idx.size == 0:
        return None, None
    runs = []
    start = prev = int(idx[0])
    for i in idx[1:]:
        if i - prev > 1:
            runs.append([start, prev])
            start = i
        prev = i
    runs.append([start, prev])

    merged = []
    for r in runs:
        if merged and (r[0] - merged[-1][1] - 1) <= gap_tol:
            merged[-1][1] = r[1]
        else:
            merged.append(list(r))

    top, bottom = max(merged, key=lambda r: r[1] - r[0])
    return top, bottom


def crop_to_mark_box(
    img: Image.Image,
    *,
    dark_threshold: int = 150,
    col_threshold: float = 0.45,
    gap_tol: int = 12,
    margin: int = 1,
) -> Image.Image:
    """Crop `img` tightly to the outer black border of the marking box.

    Returns the input image unchanged if no reliable box border is detected.
    """
    if img.mode != "RGB":
        img = img.convert("RGB")
    w, h = img.size

    dark, col_density = _row_and_col_profiles(img, dark_threshold)

    # ---- horizontal: outermost strong vertical lines = box borders ----
    left, right = _find_left_right_borders(col_density, col_threshold)
    if left is None or right is None:
        return img  # no vertical borders found -> give up safely
    if right - left < 20:  # too narrow to be a marking box
        return img

    # ---- vertical: rows where a border column is present ----
    border_present = dark[:, left] | dark[:, right]
    top, bottom = _largest_vertical_run(border_present, gap_tol)
    if top is None:
        return img

    # ---- expand by a small margin, clamped to the image ----
    x0 = max(0, left - margin)
    x1 = min(w - 1, right + margin)
    y0 = max(0, top - margin)
    y1 = min(h - 1, bottom + margin)

    return img.crop((x0, y0, x1 + 1, y1 + 1))


def crop_to_mark_box_path(src: str, dst: str, **kwargs) -> None:
    """Convenience: load `src`, crop, save to `dst` (same format/quality retained)."""
    img = Image.open(src)
    out = crop_to_mark_box(img, **kwargs)
    out.save(dst)


if __name__ == "__main__":
    import glob
    import os
    import sys

    target_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    margin = int(sys.argv[2]) if len(sys.argv) > 2 else 1

    files = sorted(glob.glob(os.path.join(target_dir, "*beforemanuallcrop.webp")))
    if not files:
        print("No *beforemanuallcrop.webp files found; nothing to crop.")
        sys.exit(1)

    os.makedirs(os.path.join(target_dir, "auto_cropped"), exist_ok=True)
    for f in files:
        out_path = os.path.join(
            target_dir, "auto_cropped",
            os.path.basename(f).replace("-beforemanuallcrop", "_auto"),
        )
        crop_to_mark_box_path(f, out_path, margin=margin)
        im = Image.open(out_path)
        print(f"{os.path.basename(f):44s} -> {im.width}x{im.height}")
