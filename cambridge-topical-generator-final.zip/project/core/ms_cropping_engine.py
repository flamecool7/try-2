"""
MS Cropping Engine - LOCKED Gold-Standard Exact Copy from GitHub

ABSOLUTE RULE: COPY AND USE THE MARK SCHEME CROPPING MECHANISM EXACTLY AS IT EXISTS IN THE GITHUB REPOSITORY.

GitHub source: Topical_Generation_Final.zip / cambridge_qb/ms_crop.py + markscheme_split.py + markscheme.py

This file is MINIMAL INTEGRATION layer - no enhancements, no optimization, no refactoring, no redesign.

QP cropper and MS cropper MUST remain separate:
- QP -> existing approved QP cropper (question_split.py -> CroppingEngine)
- MS -> exact GitHub MS cropper (this file)

Only permitted changes: import paths, file paths, dependency handling, I/O connections.
NO changes to crop boundaries, whitespace handling, padding, page detection, question detection, etc.

Original GitHub implementation preserved exactly in:
- core/ms_crop_gold.py (exact copy of ms_crop.py)
- core/markscheme_split_gold.py (exact copy of markscheme_split.py)
- core/markscheme_gold.py (exact copy of markscheme.py)
- core/pdf_io_gold.py, converter_gold.py (dependencies)

This wrapper only adapts I/O to universal generator's CroppedQuestion format.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Dict
from dataclasses import dataclass
from PIL import Image

# Ensure original_reference and core gold files are importable
sys.path.insert(0, str(Path(__file__).parent.parent / "original_reference"))
sys.path.insert(0, str(Path(__file__).parent))

try:
    # Import EXACT gold-standard MS cropping implementation - no modifications
    from core.ms_crop_gold import crop_to_mark_box as gold_crop_to_mark_box
    from core.markscheme_split_gold import split_structured_mark_scheme as gold_split_structured
    from core.markscheme_gold import process_mark_schemes as gold_process_mark_schemes, lookup_mark_scheme as gold_lookup
    GOLD_MS_AVAILABLE = True
except Exception as e:
    print(f"[MSCroppingEngine] Gold-standard MS import failed: {e}")
    GOLD_MS_AVAILABLE = False

# Also try original_reference path
try:
    if not GOLD_MS_AVAILABLE:
        sys.path.insert(0, str(Path(__file__).parent.parent / "original_reference"))
        from cambridge_qb.ms_crop import crop_to_mark_box as gold_crop_to_mark_box
        from cambridge_qb.markscheme_split import split_structured_mark_scheme as gold_split_structured
        from cambridge_qb.markscheme import process_mark_schemes as gold_process_mark_schemes
        GOLD_MS_AVAILABLE = True
except Exception as e:
    print(f"[MSCroppingEngine] Fallback gold MS import failed: {e}")

try:
    import fitz
    HAS_FITZ = True
except ImportError:
    try:
        import pymupdf as fitz
        HAS_FITZ = True
    except ImportError:
        HAS_FITZ = False

@dataclass
class MSCroppedQuestion:
    question_number: str
    number_int: int
    paper_code: str
    images: List[Image.Image]
    assembled_image: Image.Image = None
    text: str = ""
    marks: int = 0
    pages: List[int] = None

class MSCroppingEngine:
    """
    MS Cropping Engine - EXACT GitHub implementation, no enhancements
    Uses gold-standard ms_crop + markscheme_split exactly as in GitHub repo
    """

    def __init__(self, target_width=2280, quality=95, dpi=200):
        # Use same target width as QP for consistency, but MS cropper crops tightly to black border
        # per gold-standard ms_crop.py: it finds outer black border rectangle and crops tightly
        # with small margin 1px, no fixed crop values
        self.target_width = target_width
        self.quality = quality
        self.dpi = dpi

    def process_paper(self, pdf_path: Path, expected_questions=None) -> List[MSCroppedQuestion]:
        """
        Process MS paper using EXACT GitHub implementation
        No enhancements, no optimization, no refactoring
        """
        pdf_path = Path(pdf_path)
        print(f"[MSCroppingEngine] Processing {pdf_path.name} with GOLD-STANDARD MS engine (LOCKED)")

        if not GOLD_MS_AVAILABLE:
            print("[MSCroppingEngine] Gold MS not available, using dummy")
            return []

        try:
            # Use gold-standard split_structured_mark_scheme - EXACT COPY from GitHub
            # This is based on structure observed across nine official 2025 mark schemes
            # - Answer content organised into tables headed Question | Answer | Marks
            # - Header band bounded by two long horizontal rules
            # - Previous question ends at header's top rule, following starts at bottom rule
            # - Direct transition without header separated by long horizontal rule above new label
            # - No question-paper fixed crop, no automatic cut through whitespace at arbitrary coordinate
            # - Output only when all required boundaries are structural table rules and sequence complete

            images_by_question, diagnostics = gold_split_structured(
                pdf_path,
                dpi=self.dpi,
                expected_question_numbers=expected_questions,
            )

            print(f"[MSCroppingEngine] Gold-standard MS extracted {len(images_by_question)} questions from {pdf_path.name}")
            if diagnostics:
                print(f"  Diagnostics: found={diagnostics.markers_found}, missing={diagnostics.missing_questions}, unexpected={diagnostics.unexpected_questions}")
                for note in diagnostics.split_notes[:10]:
                    print(f"  [ms-split] {note}")
                for warning in diagnostics.warnings[:10]:
                    print(f"  [ms-warning] {warning}")

            if not images_by_question:
                # The original structured MS cropper found no structural boxes.
                # Do not substitute QP cropping or fabricate question numbers.
                return []

            results = []
            for qnum, img in sorted(images_by_question.items()):
                # Apply tight crop to black border per gold-standard ms_crop.py - EXACT COPY
                try:
                    cropped = gold_crop_to_mark_box(
                        img,
                        dark_threshold=150,
                        col_threshold=0.45,
                        gap_tol=12,
                        margin=1,
                    )
                except Exception as e:
                    print(f"[MSCroppingEngine] crop_to_mark_box failed for Q{qnum}: {e}, using original")
                    cropped = img

                try:
                    number_int = int(qnum)
                except Exception as e:
                    number_int = int(''.join(filter(str.isdigit, str(qnum))) or 0)

                results.append(MSCroppedQuestion(
                    question_number=f"Q{number_int}" if number_int else f"Q{qnum}",
                    number_int=number_int,
                    paper_code=pdf_path.stem,
                    images=[cropped],
                    assembled_image=cropped,
                    text=f"Mark scheme for question {qnum}",
                    marks=0,
                    pages=[],
                ))

            return results

        except Exception as e:
            print(f"[MSCroppingEngine] Gold-standard MS processing failed for {pdf_path.name}: {e}")
            import traceback
            traceback.print_exc()
            return []

    def _dummy_process(self, pdf_path: Path) -> List[MSCroppedQuestion]:
        results = []
        for i in range(1, 4):
            img = Image.new('RGB', (self.target_width, 800), 'white')
            from PIL import ImageDraw
            draw = ImageDraw.Draw(img)
            draw.text((50, 50), f"MS Question {i} from {pdf_path.name}\nGold-standard MS fallback", fill='black')
            results.append(MSCroppedQuestion(
                question_number=f"Q{i}",
                number_int=i,
                paper_code=pdf_path.stem,
                images=[img],
                assembled_image=img,
                text=f"MS Question {i} dummy",
                marks=5,
                pages=[0]
            ))
        return results
