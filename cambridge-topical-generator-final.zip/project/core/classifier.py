"""
Subject-Specific Classifier - Handles detailed topic classification

Flow:
Paper
↓
Identify subject
↓
Load subject configuration
↓
Load correct syllabus
↓
Extract question
↓
Classify detailed topics
↓
Map detailed topics → major topics
↓
Calculate major-topic scores
↓
Select winning major topic
↓
Place QP/MS there

CRITICAL RULES:
- Chemistry must ONLY use Chemistry mappings
- Physics must ONLY use Physics mappings
- Mathematics must ONLY use Mathematics mappings
- Never mix mappings between subjects
- JSON contains detailed topics
- Folders contain ONLY major topics
- Point-based classification
- Single-folder distribution

Point allocation considered:
- Marks allocated
- Number of subquestions
- Central purpose
- Required knowledge
- Calculations
- Reasoning
- Mark-scheme dependency
- Specialized knowledge
- Number of syllabus objectives
Do NOT award points merely because keyword appears.

Tie-breaking:
1. Topic responsible for most marks
2. Central purpose
3. Most specialized knowledge
4. Strongest mark-scheme dependency
5. Official syllabus hierarchy/order
"""

import re
from typing import List, Dict, Tuple
from dataclasses import dataclass
from .config_loader import SubjectConfig
from .cropping_engine import CroppedQuestion
from .qp_ms_matcher import MatchedQuestion

@dataclass
class ClassificationResult:
    detailed_topics: List[str]  # For JSON
    major_topic_scores: Dict[str, float]  # major -> score
    winning_major: str
    topic_marks_breakdown: Dict[str, int]  # detailed -> marks estimate
    reasoning: str

class TopicClassifier:
    def __init__(self, subject_config: SubjectConfig):
        self.config = subject_config
        # Preprocess keywords to lower
        self.keywords_lower = {}
        for detailed, kws in self.config.classification_keywords.items():
            self.keywords_lower[detailed] = [kw.lower() for kw in kws]

    def classify_question(self, matched_question: MatchedQuestion) -> ClassificationResult:
        """
        Classify a matched QP/MS question into detailed topics and major topic winner
        For Mathematics/Further Mathematics: Uses paper/component based categorization, NOT detailed question-level
        For other subjects: Uses detailed topic classification as before
        """
        # SPECIAL HANDLING FOR MATHEMATICS-RELATED SUBJECTS (Part 1)
        # Per requirement: For Mathematics and Further Mathematics, do NOT attempt detailed question-level classification
        # Category determined by paper/component identity
        try:
            from .math_category import is_mathematics_subject, get_canonical_math_category, is_paper_7, verify_paper7_mapping, get_paper_number_from_variant
            import os

            # Check if this is Mathematics-related subject
            is_math = is_mathematics_subject(self.config.subject, self.config.syllabus_code)

            if is_math:
                # Get paper number from variant
                variant = matched_question.variant
                paper_number = get_paper_number_from_variant(variant)
                year = matched_question.year
                season = matched_question.season
                subject = self.config.subject
                syllabus_code = self.config.syllabus_code

                # Mathematics 9709 only: the filename selects P1–P6 and the
                # uploaded reference file limits question classification to that
                # paper's exact subtopic strings. Other Mathematics syllabuses
                # retain their existing component-category behavior below.
                if str(syllabus_code) == "9709" and paper_number in range(1, 7):
                    from .math_reference import classify_9709_question
                    reference_topic = classify_9709_question(
                        f"{matched_question.qp.text} {matched_question.ms.text}",
                        paper_number,
                    )
                    return ClassificationResult(
                        detailed_topics=[reference_topic],
                        major_topic_scores={reference_topic: 10.0},
                        winning_major=reference_topic,
                        topic_marks_breakdown={reference_topic: matched_question.qp.marks or 5},
                        reasoning=(
                            f"Mathematics 9709 filename component {variant}: P{paper_number}; "
                            f"classified only within that paper's reference topics -> {reference_topic}"
                        ),
                    )

                # Check for Paper 7 special handling
                if is_paper_7(variant, paper_number):
                    print(f"[MathCategory] Paper 7 detected: variant {variant}, paper {paper_number} for {self.config.subject} {self.config.syllabus_code}")

                    # Online verification should trigger ONLY for Paper 7 per requirement 7
                    # Extract metadata for verification
                    year = matched_question.year
                    season = matched_question.season
                    subject = self.config.subject
                    syllabus_code = self.config.syllabus_code

                    # Try to get cached mapping first
                    from .math_category import get_cached_paper7_mapping
                    cached = get_cached_paper7_mapping(syllabus_code, year, season, subject, paper_number, variant)

                    if cached:
                        canonical = cached["verified_mapping"]
                        print(f"[MathCategory] Using cached Paper 7 mapping: {canonical}")
                    else:
                        # Perform verification - for Mathematics, variant like 17,27,37,47 are actually Paper 1,2,3,4 variant 7
                        # So Paper 7 detection for variant 17,27,37,47 should map to existing component
                        verified_mapping, source, is_verified = verify_paper7_mapping(
                            syllabus_code, year, season, subject, paper_number, variant,
                            pdf_path=str(matched_question.qp.paper_code) if hasattr(matched_question.qp, 'paper_code') else ""
                        )

                        if is_verified:
                            canonical = verified_mapping
                            print(f"[MathCategory] Paper 7 verified: {canonical} from {source}")
                        else:
                            # If not verified, try to determine if it's actually variant 7 of existing paper
                            # For Mathematics, 17 = Paper 1 variant 7, 27 = Paper 2 variant 7, etc.
                            try:
                                v_str = str(variant).lstrip("0")
                                if len(v_str) == 2 and v_str[1] == "7":
                                    actual_paper = int(v_str[0])
                                    canonical = get_canonical_math_category(syllabus_code, actual_paper, variant)
                                    print(f"[MathCategory] Paper 7 variant {variant} -> Paper {actual_paper} variant 7 -> {canonical} (fallback)")
                                    # Cache it
                                    from .math_category import cache_paper7_mapping
                                    cache_paper7_mapping(syllabus_code, year, season, subject, paper_number, variant, canonical, source)
                                else:
                                    # Independent Paper 7
                                    canonical = f"P7_Paper_7_Variant_{variant}"
                                    print(f"[MathCategory] Paper 7 independent: {canonical} (needs online verification)")
                            except Exception as e:
                                canonical = get_canonical_math_category(syllabus_code, paper_number, variant)
                                print(f"[MathCategory] Paper 7 fallback to direct: {canonical} due to {e}")

                    # For Mathematics, category is determined by paper, NOT question content
                    # Return canonical category as both detailed and winning major
                    # No duplication, one category only per requirement 5

                    # Ensure canonical category is in config major_topics, if not, add to detailed?
                    # For Mathematics, major_topics are like P1_Pure_Mathematics_1 etc., which should include canonical

                    # If canonical not in major_topics, we need to check if it's close to existing
                    # For now, use canonical as winning major, and detailed as [canonical]

                    # For JSON, topic should be [canonical] per Part 7 example
                    return ClassificationResult(
                        detailed_topics=[canonical],
                        major_topic_scores={canonical: 10.0},
                        winning_major=canonical,
                        topic_marks_breakdown={canonical: matched_question.qp.marks or 5},
                        reasoning=f"Mathematics paper-based categorization: Paper {paper_number} Variant {variant} -> {canonical} (paper/component identity, not question content per requirement)"
                    )

                # Normal Mathematics papers 1-6 - no online verification needed
                else:
                    canonical = get_canonical_math_category(syllabus_code, paper_number, variant)
                    print(f"[MathCategory] Mathematics paper-based: Paper {paper_number} Variant {variant} -> {canonical}")

                    return ClassificationResult(
                        detailed_topics=[canonical],
                        major_topic_scores={canonical: 10.0},
                        winning_major=canonical,
                        topic_marks_breakdown={canonical: matched_question.qp.marks or 5},
                        reasoning=f"Mathematics paper-based categorization: Paper {paper_number} -> {canonical} (official component, not question content)"
                    )

        except Exception as e:
            # If math_category handling fails, fall back to normal classification
            # Do not break existing non-Mathematics classification
            print(f"[Classifier] Mathematics categorization failed for {self.config.subject}, falling back to detailed classification: {e}")
            import traceback
            traceback.print_exc()

        # For non-Mathematics subjects, continue with existing detailed classification (preserved)
        qp_text = matched_question.qp.text
        ms_text = matched_question.ms.text
        combined_text = (qp_text + " " + ms_text).lower()

        # Step 1: Identify every genuine detailed topic
        detailed_scores: Dict[str, float] = {}  # detailed -> raw score
        detailed_marks: Dict[str, int] = {}  # estimate marks per detailed
        subquestion_count: Dict[str, int] = {}

        # Count subquestions: patterns like (a), (b), (i), (ii)
        subq_pattern = re.compile(r'\(([a-z]|[ivx]+)\)', re.IGNORECASE)
        total_subquestions = len(subq_pattern.findall(qp_text))

        for detailed in self.config.detailed_topics:
            keywords = self.keywords_lower.get(detailed, [])
            if not keywords:
                continue

            score = 0
            hit_count = 0
            specialized_weight = self.config.specialization_weights.get(detailed, 1.0)

            for kw in keywords:
                # Count occurrences, but weight to avoid keyword spam
                # Use word boundaries for better precision
                pattern = re.compile(r'\b' + re.escape(kw) + r'\b', re.IGNORECASE)
                matches = pattern.findall(combined_text)
                if matches:
                    hit_count += len(matches)
                    # Score per hit: diminishing returns to avoid keyword stuffing
                    # First hit = 2 points, second = 1, rest = 0.5
                    for idx, _ in enumerate(matches):
                        if idx == 0:
                            score += 2 * specialized_weight
                        elif idx == 1:
                            score += 1 * specialized_weight
                        else:
                            score += 0.5 * specialized_weight

            # Additional scoring factors:
            # - If detailed topic keywords appear in MS, that indicates mark-scheme dependency
            ms_hits = 0
            for kw in keywords:
                if kw.lower() in ms_text.lower():
                    ms_hits += 1
            if ms_hits > 0:
                score += ms_hits * 0.8  # MS dependency bonus

            # - Central purpose: if keyword appears in first 300 chars, bonus
            first_part = combined_text[:500]
            central_hits = sum(1 for kw in keywords if kw.lower() in first_part)
            if central_hits > 0:
                score += central_hits * 1.2

            # - Marks allocated: estimate marks for this topic based on subquestions that contain keyword
            # Simplistic: if question has many marks and this topic scores high, give marks proportionally
            # We'll calculate after getting total

            # Threshold: need at least 1.5 points to be considered genuine (not just keyword appearance)
            if score >= 1.5:
                detailed_scores[detailed] = score
                # Estimate marks: proportional to score if overall marks known
                subquestion_count[detailed] = hit_count

        # If no detailed topics identified, try fallback: most frequent major mapping?
        # But per spec: do NOT guess? However we need some classification.
        # Use at least one: take highest scoring even if below threshold, but flag
        if not detailed_scores:
            # Fallback - find best via any keyword match
            best_detailed = None
            best_score = 0
            for detailed in self.config.detailed_topics:
                keywords = self.keywords_lower.get(detailed, [])
                score = sum(1 for kw in keywords if kw.lower() in combined_text)
                if score > best_score:
                    best_score = score
                    best_detailed = detailed
            if best_detailed:
                detailed_scores[best_detailed] = 1.0
            else:
                # Ultimate fallback: first detailed topic (should not happen in production with real data)
                # Use first major's first detailed
                if self.config.detailed_topics:
                    detailed_scores[self.config.detailed_topics[0]] = 0.5

        # Step 2: Map to major topics and calculate major scores
        major_scores: Dict[str, float] = {}
        major_marks: Dict[str, int] = {}
        major_specialization: Dict[str, float] = {}

        for detailed, score in detailed_scores.items():
            major = self.config.mapping.get(detailed)
            if not major:
                continue
            if major not in major_scores:
                major_scores[major] = 0
                major_marks[major] = 0
                major_specialization[major] = 0

            # Point allocation based on:
            # - marks (we have qp.marks)
            # - subquestion count
            # - specialized knowledge
            # - reasoning etc approximated via score

            # Base: detailed score
            major_scores[major] += score

            # Specialization bonus
            spec_w = self.config.specialization_weights.get(detailed, 1.0)
            major_specialization[major] = max(major_specialization[major], spec_w)

            # Marks: distribute total marks proportionally to detailed scores
            # We'll calculate after loop

        # Distribute marks for point calculation
        total_marks = matched_question.qp.marks or 5  # default
        total_detailed_score = sum(detailed_scores.values()) or 1
        for detailed, score in detailed_scores.items():
            major = self.config.mapping.get(detailed)
            if not major:
                continue
            proportion = score / total_detailed_score
            estimated_marks = int(round(proportion * total_marks))
            detailed_marks[detailed] = estimated_marks
            major_marks[major] += estimated_marks

        # Enhance major scores with marks factor
        for major in major_scores:
            # Marks allocated is major factor
            major_scores[major] += major_marks.get(major, 0) * 0.5
            # Specialized knowledge
            major_scores[major] += major_specialization.get(major, 0) * 0.3

        # Step 3: Select winning major topic (single-folder requirement)
        winning_major = self._select_winner(major_scores, major_marks, major_specialization)

        # Step 4: Detailed topics list for JSON (all genuine detailed topics, not just winner's)
        genuine_detailed = [d for d, s in detailed_scores.items() if s >= 1.0]
        if not genuine_detailed:
            genuine_detailed = list(detailed_scores.keys())

        # Ensure at least 1 detailed topic
        if not genuine_detailed and self.config.detailed_topics:
            genuine_detailed = [self.config.detailed_topics[0]]

        # Sort detailed topics by score descending for JSON? Keep stable
        genuine_detailed.sort(key=lambda d: detailed_scores.get(d, 0), reverse=True)

        reasoning = f"Detailed scores: {detailed_scores}, Major scores: {major_scores}, Marks: {major_marks}, Winner: {winning_major} by point system"

        return ClassificationResult(
            detailed_topics=genuine_detailed,
            major_topic_scores=major_scores,
            winning_major=winning_major,
            topic_marks_breakdown=detailed_marks,
            reasoning=reasoning
        )

    def _select_winner(self, major_scores: Dict[str, float], major_marks: Dict[str, int], major_spec: Dict[str, float]) -> str:
        """
        Select winning major topic with tie-breaking
        Never duplicate question because of tie - always ONE winner
        Tie-breaking order:
        1. Topic responsible for most marks
        2. Central purpose (already in scores)
        3. Most specialized knowledge
        4. Strongest mark-scheme dependency (already in scores)
        5. Official syllabus hierarchy/order
        """
        if not major_scores:
            # Fallback: first major topic
            return self.config.major_topics[0] if self.config.major_topics else "General"

        # Sort by score descending
        sorted_majors = sorted(major_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Check tie
        max_score = sorted_majors[0][1]
        tied = [m for m, s in sorted_majors if abs(s - max_score) < 0.01]

        if len(tied) == 1:
            return tied[0]

        # Tie-breaking 1: Most marks
        tied_marks = [(m, major_marks.get(m, 0)) for m in tied]
        tied_marks_sorted = sorted(tied_marks, key=lambda x: x[1], reverse=True)
        max_marks = tied_marks_sorted[0][1]
        tied_after_marks = [m for m, mk in tied_marks_sorted if mk == max_marks]
        if len(tied_after_marks) == 1:
            return tied_after_marks[0]

        # Tie-breaking 2: Central purpose already considered, but we try specialized knowledge
        tied_spec = [(m, major_spec.get(m, 0)) for m in tied_after_marks]
        tied_spec_sorted = sorted(tied_spec, key=lambda x: x[1], reverse=True)
        max_spec = tied_spec_sorted[0][1]
        tied_after_spec = [m for m, sp in tied_spec_sorted if sp == max_spec]
        if len(tied_after_spec) == 1:
            return tied_after_spec[0]

        # Tie-breaking 5: Official syllabus hierarchy/order
        # Lower order number wins (earlier in syllabus is often foundational)
        order = self.config.syllabus_order
        if order:
            tied_ordered = sorted(tied_after_spec, key=lambda m: order.get(m, 999))
            return tied_ordered[0]

        # Final fallback: alphabetical or first in major_topics list order
        # Use order in major_topics list as official hierarchy
        if self.config.major_topics:
            for major in self.config.major_topics:
                if major in tied_after_spec:
                    return major

        return tied_after_spec[0]
