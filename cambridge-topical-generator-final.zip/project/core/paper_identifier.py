"""
Paper Identifier - Universal component
Identifies paper metadata from filename and header.
Now supports IGCSE + A-Level levels.
Supports BOTH naming conventions:
- Standard: 9701_m26_qp_22.pdf , 0620_m26_qp_42.pdf
- Real-world 2026: 9701 Chemistry March 2026 Question Paper 12.pdf,
               9706 Accounting March 2026 Question Paper 12.pdf,
               9701 Chemistry March 2026 Mark Scheme 12.pdf (if present)

Level inference:
- 05xx, 06xx -> IGCSE
- 97xx -> A-Level
"""

import re
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

# Pattern 1: Standard short format: 9701_m26_qp_22, 0620_s23_ms_42, 9701_m26_er_22
# Examiner Reports are compilation documents and commonly have no component
# suffix (for example, 9709_s22_er.pdf).  Detect this definitive ``_er`` file
# type before the component-paper pattern below so it can never be treated as
# a QP or mark scheme.
EXAMINER_REPORT_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<season_letter>[msw])?(?P<year>\d{2})[_-]?(?P<type>er)(?:[_-]?(?P<variant>\d{1,2}))?$',
    re.IGNORECASE
)

PAPER_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<season_letter>[msw])?(?P<year>\d{2})[_-]?(?P<type>qp|ms|er|ir|gt)[_-]?(?P<variant>\d{1,2})',
    re.IGNORECASE
)

# Pattern 2: Real-world long format: "9701 Chemistry March 2026 Question Paper 12.pdf"
# Also handles: "9706 Accounting March 2026 Insert 32.pdf", "9700 Biology March 2026 Confidential Instructions 33.pdf", "9701 Chemistry March 2026 Examiner Report 22.pdf"
LONG_PATTERN = re.compile(
    r'(?P<code>\d{4})'                     # 9701
    r'[^0-9]*?'                            # any non-digit between code and month
    r'(?P<month>January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov)'  # Month
    r'\s+(?P<year_full>\d{4})'             # 2026
    r'[^A-Za-z]*?'                         # separator
    r'(?P<type_long>Question Paper|Mark Scheme|Insert|Confidential Instructions|Supporting File|Paper|Examiner Report|Principal Examiner Report)'  # Type
    r'\s*(?P<variant>\d{1,2})?',           # Variant e.g., 12, 22, 42
    re.IGNORECASE
)

# Month to season letter mapping
MONTH_TO_SEASON = {
    'january': 'm', 'jan': 'm',
    'february': 'm', 'feb': 'm',
    'march': 'm', 'mar': 'm',
    'april': 'm',  # rare, treat as spring
    'may': 's',
    'june': 's', 'jun': 's',
    'july': 's', 'jul': 's',
    'august': 's', 'aug': 's',
    'september': 's', 'sep': 's',
    'october': 'w', 'oct': 'w',
    'november': 'w', 'nov': 'w',
    'december': 'w', 'dec': 'w',
}

SEASON_MAP = {
    'm': 'Spring',  # Feb/March
    's': 'Summer',  # May/June
    'w': 'Winter',  # Oct/Nov
    'f': 'Spring',
    'j': 'Summer',
    'n': 'Winter',
}

LEVEL_BY_PREFIX = {
    '04': 'IGCSE',
    '05': 'IGCSE',
    '06': 'IGCSE',
    '09': 'A-Level',
    '96': 'A-Level',
    '97': 'A-Level',
    '92': 'A-Level',
}

def infer_level_from_code(syllabus_code: str) -> str:
    code = str(syllabus_code)
    for prefix, level in LEVEL_BY_PREFIX.items():
        if code.startswith(prefix):
            return level
    if code.startswith('9'):
        return 'A-Level'
    return 'IGCSE'

@dataclass
class PaperInfo:
    file_path: Path
    syllabus_code: str
    year: str  # "2026"
    year_short: str  # "26"
    season: str  # "Spring", "Summer", "Winter"
    season_letter: str  # "m", "s", "w"
    paper_type: str  # "qp" or "ms" or "insert"
    variant: str  # "22" or "42"
    full_code: str  # "9701_m26_qp_22" or "0620_m26_qp_42"
    level: str  # "IGCSE" or "A-Level"
    subject_guess: Optional[str] = None
    original_name: str = ""  # Store original filename for debugging

    def to_dict(self):
        return {
            "syllabus_code": self.syllabus_code,
            "year": self.year,
            "season": self.season,
            "type": self.paper_type,
            "variant": self.variant,
            "full_code": self.full_code,
            "level": self.level,
            "original_name": self.original_name,
        }

def parse_paper_filename(file_path: str | Path) -> Optional[PaperInfo]:
    """Parse paper info from filename including level - supports both short and long formats"""
    path = Path(file_path)
    name = path.stem
    name_lower = name.lower()
    original_name = path.name

    # Examiner Report priority: a filename ending in _er (with an optional
    # component) is always an ER.  It is intentionally parsed before QP/MS
    # patterns; the suffix identifies only the file type, while normal ER
    # matching later verifies its applicable paper/component.
    er_match = EXAMINER_REPORT_PATTERN.search(name_lower)
    if er_match:
        code = er_match.group('code')
        season_letter = (er_match.group('season_letter') or 'm').lower()
        year_short = er_match.group('year')
        variant = er_match.group('variant') or ""
        full_year = 2000 + int(year_short) if int(year_short) < 50 else 1900 + int(year_short)
        from .config_loader import KNOWN_CODE_MAP
        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=SEASON_MAP.get(season_letter, 'Summer'),
            season_letter=season_letter,
            paper_type="er",
            variant=variant,
            full_code=f"{code}_{season_letter}{year_short}_er" + (f"_{variant}" if variant else ""),
            level=infer_level_from_code(code),
            subject_guess=KNOWN_CODE_MAP.get(code),
            original_name=original_name,
        )

    # Try Pattern 1 first (standard component papers)
    m = PAPER_PATTERN.search(name_lower)
    if m:
        code = m.group('code')
        season_letter = (m.group('season_letter') or 'm').lower()
        year_short = m.group('year')
        ptype = m.group('type').lower()
        variant = m.group('variant')

        try:
            y_int = int(year_short)
            full_year = 2000 + y_int if y_int < 50 else 1900 + y_int
        except Exception as e:
            full_year = 2000 + int(year_short) if year_short.isdigit() else 2024

        season = SEASON_MAP.get(season_letter, 'Summer')
        full_code = f"{code}_{season_letter}{year_short}_{ptype}_{variant}"
        level = infer_level_from_code(code)

        from .config_loader import KNOWN_CODE_MAP
        subject_guess = KNOWN_CODE_MAP.get(code)

        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=season,
            season_letter=season_letter,
            paper_type=ptype,
            variant=variant,
            full_code=full_code,
            level=level,
            subject_guess=subject_guess,
            original_name=original_name,
        )

    # Try Pattern 2: Long real-world format
    m2 = LONG_PATTERN.search(name)
    if m2:
        code = m2.group('code')
        month_raw = m2.group('month').lower()
        year_full_str = m2.group('year_full')
        type_long = m2.group('type_long').lower()
        variant = m2.group('variant') or "12"  # default if missing

        # Map month to season letter
        season_letter = MONTH_TO_SEASON.get(month_raw, 'm')
        season = SEASON_MAP.get(season_letter, 'Spring')

        # Map type_long to qp/ms
        if "question paper" in type_long:
            ptype = "qp"
        elif "mark scheme" in type_long or "marking scheme" in type_long:
            ptype = "ms"
        elif "examiner report" in type_long or "principal examiner" in type_long:
            ptype = "er"
        elif "insert" in type_long:
            ptype = "qp"  # Insert is part of QP, treat as qp for grouping but will be filtered? Keep as insert
            # Actually keep as insert to avoid mixing with main QP
            ptype = "insert"
        elif "confidential" in type_long:
            ptype = "ci"  # confidential instructions
        elif "supporting" in type_long:
            ptype = "sf"  # supporting file
        else:
            ptype = "qp"  # default

        try:
            full_year = int(year_full_str)
            year_short = f"{full_year % 100:02d}"
        except Exception as e:
            full_year = 2026
            year_short = "26"

        full_code = f"{code}_{season_letter}{year_short}_{ptype}_{variant}"
        level = infer_level_from_code(code)

        from .config_loader import KNOWN_CODE_MAP
        subject_guess = KNOWN_CODE_MAP.get(code)

        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=season,
            season_letter=season_letter,
            paper_type=ptype,
            variant=variant,
            full_code=full_code,
            level=level,
            subject_guess=subject_guess,
            original_name=original_name,
        )

    return None

def identify_papers_in_dir(input_dir: str | Path) -> list[PaperInfo]:
    """Scan directory for papers - supports both formats"""
    input_dir = Path(input_dir)
    papers = []
    for file in input_dir.rglob("*.pdf"):
        info = parse_paper_filename(file)
        if info:
            # Only include qp and ms for main processing, but keep insert/ci as separate?
            # For now include all that parsed, but main.py will filter
            papers.append(info)
        else:
            print(f"[PaperIdentifier] Could not parse filename: {file.name} - flag for review")
    return papers
