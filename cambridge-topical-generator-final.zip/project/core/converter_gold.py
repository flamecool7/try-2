"""
converter.py
============

Convert PDF pages to WebP images using the FreeConvert.com API.

Uses the JOBS endpoint to create all tasks in one request:
  POST /process/jobs  with tasks dict containing import, convert, and export.

The FreeConvert.com API always outputs every page at 2480 × 3508 pixels,
which allows us to apply a fixed, deterministic crop to every page.

API Workflow (JOBS endpoint):
  1. POST /process/jobs  — create a job with import/upload, convert, and
     export/url tasks in a single request.
  2. Get the signed upload URL from the import task's result.form.
  3. Upload the PDF file to the signed URL.
  4. Poll /process/jobs/{id} until all tasks complete.
  5. Download the ZIP from the export task's result.url.
  6. Extract the individual WebP pages from the ZIP.

Fallback: render locally with PyMuPDF at the same 2480 × 3508 dimensions.
"""

from __future__ import annotations

import io
import re
import time
import zipfile
from pathlib import Path
from typing import List, Optional

import requests
from PIL import Image

# ---------------------------------------------------------------------------
# API constants
# ---------------------------------------------------------------------------
API_BASE = "https://api.freeconvert.com/v1"
POLL_INTERVAL = 5       # seconds between status checks
MAX_POLL_TIME = 300     # 5 minutes max wait

# Expected output dimensions from freeconvert.com
EXPECTED_W = 2480
EXPECTED_H = 3508


def _headers(api_key: str) -> dict:
    return {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }


# ---------------------------------------------------------------------------
# JOBS endpoint approach — create all tasks in one request
# ---------------------------------------------------------------------------

def _create_job(api_key: str, filename: str = "pages.zip") -> dict:
    """Step 1: Create a FreeConvert job with import/upload, convert, and
    export/url tasks in a single POST request.

    Returns the full job JSON response.
    """
    payload = {
        "tasks": {
            "PDF input": {
                "operation": "import/upload"
            },
            "Conversion": {
                "operation": "convert",
                "input": "PDF input",
                "input_format": "pdf",
                "output_format": "webp",
                "options": {
                    "resize_type_image": "keep_original",
                    "webp_lossless": True
                }
            },
            "WebP Output": {
                "operation": "export/url",
                "input": ["Conversion"],
                "archive_multiple_files": True,
                "filename": filename
            }
        }
    }

    resp = requests.post(
        f"{API_BASE}/process/jobs",
        json=payload,
        headers=_headers(api_key),
    )
    resp.raise_for_status()
    return resp.json()


def _upload_file_to_job(api_key: str, job: dict, file_path: Path) -> None:
    """Step 2–3: Upload the PDF file to the import task's signed URL.

    Finds the import/upload task in the job response, extracts the signed
    URL and form parameters, and uploads the file.
    """
    # Find the import/upload task
    import_task = None
    for task in job.get("tasks", []):
        if task.get("operation") == "import/upload":
            import_task = task
            break

    if import_task is None:
        raise RuntimeError(
            "No import/upload task found in job response. "
            f"Job keys: {list(job.keys())}"
        )

    result = import_task.get("result", {})
    form = result.get("form", {})
    upload_url = form.get("url")

    if not upload_url:
        raise RuntimeError(
            f"No upload URL in import task. "
            f"Task status: {import_task.get('status')}, "
            f"result keys: {list(result.keys())}"
        )

    # Build the multipart form data with the file and all parameters
    parameters = form.get("parameters", {})

    with open(file_path, "rb") as f:
        files = {"file": (file_path.name, f, "application/pdf")}
        data = dict(parameters)
        upload_resp = requests.post(
            upload_url,
            headers={"Authorization": f"Bearer {api_key}"},
            data=data,
            files=files,
        )
        upload_resp.raise_for_status()

    print(f"[converter] File uploaded to FreeConvert")


def _wait_for_job(api_key: str, job_id: str,
                  timeout: int = MAX_POLL_TIME) -> dict:
    """Step 4: Poll the job status until all tasks are completed."""
    start_time = time.time()

    while True:
        elapsed = time.time() - start_time
        if elapsed > timeout:
            raise TimeoutError(
                f"FreeConvert job {job_id} timed out after {timeout}s"
            )

        resp = requests.get(
            f"{API_BASE}/process/jobs/{job_id}",
            headers=_headers(api_key),
        )
        resp.raise_for_status()
        job_data = resp.json()
        job_status = job_data.get("status", "unknown")

        if job_status == "completed":
            return job_data

        if job_status in ("failed", "error"):
            # Check individual tasks for error details
            errors = []
            for task in job_data.get("tasks", []):
                if task.get("status") in ("failed", "error"):
                    errors.append(
                        f"  {task.get('name', '?')} ({task.get('operation', '?')}): "
                        f"{task.get('message', 'unknown error')}"
                    )
            err_str = "\n".join(errors) if errors else "unknown error"
            raise RuntimeError(
                f"FreeConvert job {job_id} failed:\n{err_str}"
            )

        # Still processing — show progress
        tasks = job_data.get("tasks", [])
        task_summary = ", ".join(
            f"{t.get('name', '?')}={t.get('status', '?')}" for t in tasks
        )
        print(f"  [converter] Status: {job_status} — {task_summary}")
        time.sleep(POLL_INTERVAL)


def _download_export(api_key: str, job: dict) -> bytes:
    """Step 5: Download the ZIP file from the export task's result URL."""
    # Find the export/url task
    export_task = None
    for task in job.get("tasks", []):
        if task.get("operation") == "export/url":
            export_task = task
            break

    if export_task is None:
        raise RuntimeError(
            "No export/url task found in completed job. "
            f"Tasks: {[t.get('name') for t in job.get('tasks', [])]}"
        )

    result = export_task.get("result", {})
    download_url = result.get("url")

    if not download_url:
        raise RuntimeError(
            f"No download URL in export task. "
            f"Status: {export_task.get('status')}, "
            f"result keys: {list(result.keys())}"
        )

    resp = requests.get(download_url, stream=True)
    resp.raise_for_status()
    return resp.content


def _extract_webp_from_zip(zip_bytes: bytes, output_dir: Path) -> List[Path]:
    """Step 6: Extract individual WebP files from the downloaded ZIP."""
    webp_paths: List[Path] = []

    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        # Sort entries to maintain page order
        entries = sorted(
            [n for n in zf.namelist() if n.lower().endswith(".webp")],
            key=_page_sort_key,
        )
        for entry in entries:
            img_data = zf.read(entry)
            out_path = output_dir / Path(entry).name
            out_path.write_bytes(img_data)
            webp_paths.append(out_path)

    webp_paths.sort(key=lambda p: _page_sort_key(p.name))
    return webp_paths


def _page_sort_key(name: str) -> str:
    """Sort filename so that page-1, page-2, ..., page-10 are in order."""
    m = re.search(r"(\d+)", Path(name).stem)
    if m:
        return f"{int(m.group(1)):08d}"
    return name


# ---------------------------------------------------------------------------
# Main entry point: convert PDF to WebP pages via FreeConvert API
# ---------------------------------------------------------------------------

def convert_pdf_to_webp(
    pdf_path: str | Path,
    output_dir: str | Path,
    api_key: str,
    timeout: int = MAX_POLL_TIME,
) -> List[Path]:
    """
    Convert every page of a PDF into individual WebP images using
    the FreeConvert.com JOBS endpoint.

    The API always outputs pages at 2480 × 3508 pixels.

    Returns a list of WebP file paths in page order.
    """
    pdf_path = Path(pdf_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"[converter] Uploading {pdf_path.name} to FreeConvert ...")

    # Step 1: Create the job with all tasks
    zip_filename = f"{pdf_path.stem}_pages.zip"
    job = _create_job(api_key, filename=zip_filename)
    job_id = job.get("id")
    print(f"[converter] Job created: {job_id}")

    # Step 2–3: Upload the PDF file
    _upload_file_to_job(api_key, job, pdf_path)

    # Step 4: Wait for all tasks to complete
    print(f"[converter] Waiting for conversion ...")
    completed_job = _wait_for_job(api_key, job_id, timeout=timeout)

    # Step 5: Download the ZIP
    print(f"[converter] Conversion complete. Downloading ...")
    zip_bytes = _download_export(api_key, completed_job)

    # Step 6: Extract the WebP files
    webp_paths = _extract_webp_from_zip(zip_bytes, output_dir)
    print(f"[converter] Extracted {len(webp_paths)} WebP pages to {output_dir}")

    return webp_paths


# ---------------------------------------------------------------------------
# Fallback: local rendering with PyMuPDF
# ---------------------------------------------------------------------------

def render_pdf_local(
    pdf_path: str | Path,
    output_dir: str | Path,
    target_width: int = EXPECTED_W,
    target_height: int = EXPECTED_H,
) -> List[Path]:
    """
    Fallback: render PDF pages locally using PyMuPDF, resizing to the
    same dimensions as FreeConvert.com output (2480 × 3508).

    This is used when the FreeConvert.com API is not available or
    the user prefers local rendering.
    """
    import fitz

    pdf_path = Path(pdf_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    doc = fitz.open(str(pdf_path))
    webp_paths: List[Path] = []

    for p_idx, page in enumerate(doc):
        # Calculate the scale to get the target dimensions
        rect = page.rect
        scale_x = target_width / rect.width
        scale_y = target_height / rect.height
        # Use the average scale to maintain aspect ratio, then resize
        scale = max(scale_x, scale_y)

        zoom = fitz.Matrix(scale, scale)
        pix = page.get_pixmap(matrix=zoom, alpha=False)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)

        # Resize to exact target dimensions
        if img.size != (target_width, target_height):
            img = img.resize((target_width, target_height), Image.LANCZOS)

        out_path = output_dir / f"page-{p_idx + 1:04d}.webp"
        img.save(str(out_path), format="WEBP", quality=95, method=4)
        webp_paths.append(out_path)

    doc.close()
    print(f"[converter] Rendered {len(webp_paths)} pages locally to {output_dir}")
    return webp_paths
