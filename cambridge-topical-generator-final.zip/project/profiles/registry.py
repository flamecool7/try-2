"""Maps syllabus codes to profile instances.

This is the ONLY place that knows which subject profiles exist. (Per-file
subject knowledge itself stays in the locked ``subjects/*/config.json`` —
see ``profiles/base_profile.py``.)

Spec repair (documented): the Overseer spec imports every profile module
inside ``load_all_profiles()`` — that ImportErrors the moment the codebase is
between steps. The authoritative list is ``_PROFILE_MODULES`` below; Step 1
ships it EMPTY (no profiles exist yet — the spec's own Step-1 confirm is
``ProfileRegistry.get("9999") is None``). Step 4+ appends one line per
profile. Adding a subject = adding its profile file + one line here.
"""
from __future__ import annotations

import importlib
from typing import Dict, List, Optional

from .base_profile import SubjectProfile


class ProfileRegistry:
    _profiles: Dict[str, SubjectProfile] = {}

    # One entry per implemented profile module, added as Steps 4-8 land.
    # Each module self-registers at import time (spec pattern).
    _PROFILE_MODULES: List[str] = [
        # "profiles.chemistry_9701",      # Step 4
        # "profiles.biology_9700",        # Step 8
        # "profiles.physics_9702",        # Step 8
        # "profiles.mathematics_9709",    # Step 8
        # "profiles.chemistry_0620",      # Step 8 (IGCSE)
    ]

    @classmethod
    def reset(cls) -> None:
        """Test hook: clear all registrations."""
        cls._profiles = {}

    @classmethod
    def register(cls, profile: SubjectProfile) -> None:
        cls._profiles[profile.syllabus_code] = profile

    @classmethod
    def get(cls, syllabus_code: str) -> Optional[SubjectProfile]:
        return cls._profiles.get(str(syllabus_code))

    @classmethod
    def is_supported(cls, syllabus_code: str) -> bool:
        return str(syllabus_code) in cls._profiles

    @classmethod
    def all_codes(cls) -> List[str]:
        return list(cls._profiles.keys())

    @classmethod
    def load_all_profiles(cls) -> int:
        """Import (and thereby register) every listed profile module.

        Returns the number of profile modules loaded. Tolerates an empty
        list (Steps 1-3); a LISTED module that fails to import is a loud
        hard error — silent subject loss is exactly what this redesign
        exists to kill.
        """
        loaded = 0
        for name in cls._PROFILE_MODULES:
            importlib.import_module(name)
            loaded += 1
            print(f"[profiles] loaded {name}")
        if not loaded:
            print("[profiles] no profile modules registered yet "
                  "(build Step 1-3 state)")
        return loaded
