# Routing & Pipeline State Lock

This lock covers the output-routing, JSON-generation and pipeline-state layer of
the generator, plus `main.py` wiring. The cropping engines and examiner-report
subsystem are covered by `CROPPING_LOCK.md` and `EXAMINER_REPORT_LOCK.md`; topic
classification by `CLASSIFICATION_LOCK.md`. The locked MS engine and gold files
remain byte-untouched.

## Baseline decisions recorded (2026-08-10, all authorised by the maintainer)

1. **G3 — grouped topics adopted**: a question may carry up to 4 grouped topic
   entries in `metadata.json` (`topic` array); placeholder topics rejected;
   bare-"D"-style low-signal assignments rejected.
2. **G4 — relative weights kept**: classifier relative weighting left as-is
   (no renormalisation).
3. **G7 — ER presence warning**: warning emitted only when an ER PDF was actually
   supplied; math papers matching `paper-\d+` keep their pruning exception.
4. **G8 — pipeline state integrated**: `core/pipeline_state.py` is the single
   checkpoint/resume store used by `main.py`.
5. **MS render resolution**: `main.py` constructs the (locked) MS engine at
   **150 dpi** (was 75); the QP engine line is untouched. Measured with Amendment
   4 scrub guards: zero content erasure at 150 dpi on real 9700 MS rasters.
6. **ER question crops wiring**: after `attach_examiner_reports_to_output`,
   `main.py` calls `core.er_question_crops.attach_question_er_crops` inside
   try/except — ER-crop failure is never fatal to a run.
7. **Boundary detector**: `core/boundary_detector.py` runs in **shadow mode**
   (question-signal veto first; never imports reference data; 8/8 matched on the
   shadow suite, zero extras) and does not alter output.

Evidence: `test-crops/audit-fixes/test_routing_fixes.py` 17/17,
`test-crops/bnd-shadow/run_shadow.py` 8/8 matched, extractor suite 32/32,
full regression battery green after every amendment wave (m25 v3 full pipeline:
validator 0 issues / 55 files).

## Rules

- No routing/state/json change may alter the folder taxonomy, the question-pair
  file naming, or the metadata schema guarded by `CLASSIFICATION_LOCK.md`.
- Any change to a file below requires a recorded amendment with evidence.

## Baseline SHA-256 (2026-08-10)

| File | SHA-256 |
|---|---|
| `core/json_generator.py` | `4b905aec3433a6d5f8fc3f02e03e15d9690af07451bcca70b4b9d11c7f5d241a` |
| `core/output_manager.py` | `3aa13d813d8cf503cefaa859cec07f691e6d4e46fb4b0f161e9011d964563936` |
| `core/pipeline_state.py` | `73832bed29e1e4daa32c5a0c35950f880df998d03fbd79912668aeea2487942f` |
| `core/boundary_detector.py` | `841ec231b1684d89b1bb218f620defe1fd6826613bbfea7c6d7a8b0e3c1facdb` |
| `main.py` | `5f1b06072c2f8a984cc346b0371e1f1e1fa3911e3b6d0b9e704ff943e9899731` |

Unchanged reference points (locked elsewhere, recorded for cross-checking):
`core/ms_cropping_engine.py` `9a1dc1e8…`, `core/ms_crop_gold.py` `8a55e3db…`,
`core/markscheme_split_gold.py` `a3213e2f…`, `core/markscheme_gold.py`
`c74496a9…` (all byte-untouched).

## Amendment RS-1 (2026-08-10): Final-upgrade small fixes — authorised by the maintainer

Three parts:

1. **Atomic state saves** (Issue 6): `core/pipeline_state.py::save` now dumps to
   `<STATE_FILE>.tmp` then `replace()`s it into place — a crash mid-save can no
   longer corrupt the resume state. Evidence: crash-injection test leaves the
   pre-crash state byte-identical; no `.tmp` survives a successful save
   (`test-crops/final-fixes/test_final_fixes.py` I6 ×3; routing suite 17/17).
2. **Extended season tokens in filename parsing** (Issue 7): new module record
   `core/paper_identifier.py` — the season group grows from single letters
   `[msw]` to a shared token set (`mj, on, fm, sp, m_j, m-j, o_n, o-n, f_m, f-m,
   summer, winter, spring, march, may, june, specimen, spec`) applied to both
   `EXAMINER_REPORT_PATTERN` and `PAPER_PATTERN`, plus two additive ER
   arrangements (year-first `9701_2024_s_er.pdf`, type-first
   `9701_er_s24.pdf`); a `_norm_season_letter` helper maps every token onto the
   canonical letter (so downstream season labels/folder names are unchanged);
   `SEASON_MAP` gains `'sp': 'Specimen'`. Evidence: all four directive failing
   names now parse (`m-j`, `summer24`, `2024_s`, `er_s24`), 12 filename cases +
   3 standard-format regressions + long-format intact (I7 ×16; ER suite 56/56,
   extractor suite 32/32).
3. **New module record** `core/difficulty.py` (Issue 4, built per maintainer
   decision): log-scale marks→difficulty (1→1.00, 5→2.89, 10→3.71, 20→4.52,
   30→5.00, cap 5.0, defensive floor 1.0). Standalone; consumed by the future
   quality scorer (Upgrade 5 notes recorded in its docstring, incl. the
   subject-path normalisation requirement from Issue 8). Evidence: I4 ×3.

Full regression battery after all edits: 36/36 final-fixes, 18/18 real-paper
classify regression (both uploaded papers), 21/21 classifier factors, 17/17
routing, 56/56 ER, 32/32 extractor, 9/9 anchor, 9/9 scrub, 8/8 boundary shadow,
31/31 w25 spot.

### Updated SHA-256 (Amendment RS-1)

| File | SHA-256 |
|---|---|
| `core/pipeline_state.py` | `d317ac21eab84c32c096f514d853dce8f78b6b0c929851a527bfff37c457cf54` |
| `core/paper_identifier.py` | `083c6bd50006fb3202ed4fd543c3644b33198dabf10ca4db53d1799e0282192f` (newly recorded) |
| `core/difficulty.py` | `a30986196496e8f0e9709b9518b56a283b1d3372859b9bbe2ec48d6e6f24c96d` (new module) |
| `core/json_generator.py` | `4b905aec3433a6d5f8fc3f02e03e15d9690af07451bcca70b4b9d11c7f5d241a` (unchanged) |
| `core/output_manager.py` | `3aa13d813d8cf503cefaa859cec07f691e6d4e46fb4b0f161e9011d964563936` (unchanged) |
| `core/boundary_detector.py` | `841ec231b1684d89b1bb218f620defe1fd6826613bbfea7c6d7a8b0e3c1facdb` (unchanged) |
| `main.py` | `5f1b06072c2f8a984cc346b0371e1f1e1fa3911e3b6d0b9e704ff943e9899731` (unchanged) |

## Amendment RS-2 (2026-08-10): Guarded-runner audit findings — authorised by the maintainer

Background: the new self-checking runner (`run_guarded.py`, "check itself
every step" mode) ran the locked FinalValidator against a REAL output tree
containing ER content — the first run ever to do so (previous proofs validated
via `OutputManager.validate_qp_ms_pairs` only). Its S8 gate surfaced three
pre-existing production bugs:

1. **validation.py V1 — R9 QP counting excludes `_ER`** (`check_question_folders`):
   the `"_MS" not in f.name` filter counted full-report tiles and per-question
   ER crops as QP files ("must have exactly 1 QP webp, found 6"), so the final
   production audit could NEVER pass with ER attached. Filter now mirrors the
   locked OutputManager semantics exactly (`"_MS" not in … and "_ER" not in …`).
2. **validation.py V2 + output_manager.py V2b — dotfile state protection**:
   both orphan-JSON scans flagged `.pipeline_state.json`; validation.py's
   auto-heal then DELETED it on every audited run — silently killing the RS-1
   crash-resume file right after PipelineState wrote it. Both scanners now skip
   dotfiles loudly ("kept dotfile state JSON (not an orphan)"), never flag or
   delete them.
3. **validation.py V3 — package-relative `subjects_root`**: the default
   `"subjects"` was CWD-relative, so any caller outside the project root got
   `known_subjects=[]` and every subject folder flagged "Unknown subject
   folder". Default resolves package-relative; an explicit missing path falls
   back package-relatively, loudly.
4. **New module record `run_guarded.py`**: stage-gated self-checking
   orchestrator (S0–S8) driving the exact locked engines (main.py constructor
   args); per-paper subprocess isolation (worker crash/OOM surfaces as a loud
   failed gate); `--low-ram` streaming QP mode for ~2GB machines using the
   approved locked-triplet harness; loud ❌ banners + `failure_report.txt`;
   exit 1 on any failed check, never greenwashes.

Evidence: full real-paper run (9700 m25+w25 QP/MS + m25 ER, --low-ram): exit 0,
288 PASS / 0 FAIL; classifications exact match to approved baselines (12/12:
m25 Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5
Genetics; w25 Q1/Q2 Cell_Structure, Q3/Q5 Genetics, Q4 Cell_Membranes, Q6
Physiology); `.pipeline_state.json` survives the final audit; regression suite
`test-crops/guarded-run/test_validator_amendments.py` 10/10 (real orphan JSON
still flagged + auto-deleted; duplicate QP still caught; foreign-cwd subject
resolution); two organic loud aborts demonstrated during the build.

### Updated SHA-256 (Amendment RS-2)

| File | SHA-256 |
|---|---|
| `core/output_manager.py` | `1ae25f9dc0e6ce922f8b2595dadc454331f9c1ff499161d9bdb9141478745554` (was `3aa13d81…`; V2b) |
| `core/validation.py` | `2a62f1ce53f852cd60bf6e9a3efd5a1030780d9e6d9203c0c3570f2952998fac` (newly recorded; V1+V2+V3) |
| `run_guarded.py` | `240f4a3f1ca072305d06b1c94276ee0f8b185b1e92274c0d0dc9d52b0624e972` (new module) |
| `core/pipeline_state.py` | `d317ac21eab84c32c096f514d853dce8f78b6b0c929851a527bfff37c457cf54` (unchanged) |
| `core/paper_identifier.py` | `083c6bd50006fb3202ed4fd543c3644b33198dabf10ca4db53d1799e0282192f` (unchanged) |
| `core/difficulty.py` | `a30986196496e8f0e9709b9518b56a283b1d3372859b9bbe2ec48d6e6f24c96d` (unchanged) |
| `core/json_generator.py` | `4b905aec3433a6d5f8fc3f02e03e15d9690af07451bcca70b4b9d11c7f5d241a` (unchanged) |
| `core/boundary_detector.py` | `841ec231b1684d89b1bb218f620defe1fd6826613bbfea7c6d7a8b0e3c1facdb` (unchanged) |
| `main.py` | `5f1b06072c2f8a984cc346b0371e1f1e1fa3911e3b6d0b9e704ff943e9899731` (unchanged) |
