# Cropping System Lock

The question-paper and mark-scheme crop/extraction/rendering code is read-only.
Topic classification, JSON metadata, folder routing, and validation must only consume
its output and must not change its behavior.

## Baseline verification

These SHA-256 values were verified against the originally downloaded project archive
`workspace-019fe775-86df-7d2b-ab07-2899f1093d24.zip`. Each current file is byte-for-byte
identical to that baseline.

| Locked file | SHA-256 |
|---|---|
| `core/cropping_engine.py` | `6a7ae3bb65012176cd6095d021e671418d9814986d15a63108367562073a9a01` |
| `core/cropping_engine_reference.py` | `9b88d3effa522e618fd631b44056602cc533aa5f151faef2cdd56999b0ba5c32` |
| `core/ms_cropping_engine.py` | `2f4c7aee5239cc99018a3fca9becaed1ccb5f9dc895e1d1be2463b9bdd006583` |
| `core/ms_crop_gold.py` | `8a55e3dbc790c4850cce44e3b324705a5652741ed8462f4794ebe3fa433641d6` |
| `core/question_split.py` | `2f8721d097f9302c3e13aa2ddda8c5d762e63d2a4195114b7198d1d9eb9f83ee` |
| `core/multipage_optimizer.py` | `17276c801666b72971fdae8aa2844d2e0feb5e2b2a75de5bdc052af01fb584ca` |
| `core/multipage_optimizer_reference.py` | `17276c801666b72971fdae8aa2844d2e0feb5e2b2a75de5bdc052af01fb584ca` |
| `core/mcq_support.py` | `76582bf541d1ef10cf3b5c4168338a66d0ed3feb5be84aaf71221f5a0c942d72` |
| `core/webp_utils.py` | `770e3ba06fb86517250c19ec6cfc620ae70eca8a147f7d559cb767210e1e4994` |
| `core/pdf_io.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` |
| `core/pdf_io_gold.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` |
| `core/markscheme_split_gold.py` | `a3213e2fe574c81b5a4a5c051638173816000c170d8fc80f733daaa251a02087` |

## Immutable behavior

Do not modify crop boundaries, dimensions, padding, page/question detection, QP/MS
cropping, multi-page assembly, image processing, WebP output, or crop quality. The
routing layer may call these components and route their already-generated outputs only.

## Amendment 1 (2026-08-10): Anti top-clipping fix — authorised by the maintainer

The maintainer explicitly ordered a fix for top-clipped question crops
("full question text always preserved; slight extra whitespace acceptable; text
clipping never acceptable; no blind hardcoded pixel padding; proportional or
validation-based adjustments"). The following controlled changes were made to the
QP cropping path only (MS path byte-identical, untouched):

- `question_split.adaptive_crop_page` (all three copies: `core/question_split.py`,
  `core/cropping_engine_reference.py`, `original_reference/cambridge_qb/question_split.py`):
  - REPLACED the blind fixed page-top constants (`QP_SAFE_TOP_PDF = 55.0`, and legacy
    `top_pdf - 5px` in the mirrors) with:
    1. structural header-junk recognition (page number = digits-only, centred,
       >= 9pt, vertically alone in the top band; `* 00008... *` barcode; running-header
       boilerplate) -> `header_floor` + `junk_boxes`;
    2. content-top detection with NO artificial y-floor (text spans + vector drawings),
       so question content starting high on the page is never destroyed;
    3. a proportional margin `0.45 * median body font size`, clamped [3, 16] pt,
       converted through the page's own render scale (adapts to layout and DPI);
    4. a raster validation pass (`_validate_top_against_ink`) that pulls the boundary
       UP over any unexpected non-junk ink (only ever adds whitespace, never clips);
    5. white-out of recognised junk boxes that survive inside the kept region
       (recognition is conservative; real content is never erased — same precedent as
       the existing watermark/imposition scrubbing).
  - `build_question_segments`: shared-page fallback split and prior-question `y0` now
    use this per-page proportional guard (`PageCropInfo.top_guard_px`) instead of the
    tight fixed 5 px.
- `multipage_optimizer.find_content_bbox` (all three copies): validation-based top
  extension absorbs faint anti-aliased rows just above the detected content top,
  bounded to one padding band (24 px). Purely additive.
- `core/cropping_engine.py`: docstring/comment updates only (no behavior change).
- Locked-output guarantees retained: final width EXACTLY 2280 px (LANCZOS, aspect
  preserved), bottom/left/right crop logic unchanged, marker detection unchanged,
  whitespace-cut algorithm unchanged, WebP output unchanged, MS cropping untouched.

Verified on the regression pack in `test-crops/fix-repro/` (7709/9709 real pages +
adversarial synthetic with content above the old 55pt cliff): zero clipping,
page numbers still excluded, outputs remain 2280-px-wide `.webp`.

### Updated baseline SHA-256

| Locked file | SHA-256 |
|---|---|
| `core/cropping_engine.py` | `01576fde63cfb005e7c71672842b1453392a5f51e7dc7dc846fa385e2c16b2a0` |
| `core/cropping_engine_reference.py` | `17e8917c759d100c498a8c5b191808d6ef61c3e8009330794af562fb49132924` |
| `core/ms_cropping_engine.py` | `9a1dc1e828f1e45e16686a8f8fcd0aaccd1dc543d68ca93468fe01832610d760` (unchanged by this amendment; already drifted from the original lock baseline before it) |
| `core/ms_crop_gold.py` | `8a55e3dbc790c4850cce44e3b324705a5652741ed8462f4794ebe3fa433641d6` (unchanged) |
| `core/question_split.py` | `17e8917c759d100c498a8c5b191808d6ef61c3e8009330794af562fb49132924` |
| `core/multipage_optimizer.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` |
| `core/multipage_optimizer_reference.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` |
| `core/mcq_support.py` | `76582bf541d1ef10cf3b5c4168338a66d0ed3feb5be84aaf71221f5a0c942d72` (unchanged) |
| `core/webp_utils.py` | `770e3ba06fb86517250c19ec6cfc620ae70eca8a147f7d559cb767210e1e4994` (unchanged) |
| `core/pdf_io.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` (unchanged) |
| `core/pdf_io_gold.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` (unchanged) |
| `core/markscheme_split_gold.py` | `a3213e2fe574c81b5a4a5c051638173816000c170d8fc80f733daaa251a02087` (unchanged) |

Also kept in sync (not locked, same fixed content): `original_reference/cambridge_qb/question_split.py`
(= `core/question_split.py`) and `original_reference/cambridge_qb/multipage_optimizer.py`
(= `core/multipage_optimizer.py`).
