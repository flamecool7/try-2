# Examiner Report System Lock

The Examiner Report implementation is read-only. Topic and folder routing must not
change report discovery, exact-paper verification, parsing, question matching, report
content, report naming, report placement, or report validation.

## Baseline verification

`core/examiner_report_gold.py` remains byte-for-byte identical to the original
downloaded project archive. `core/examiner_report.py` contains the approved ER-only
integration addition: strict metadata-to-report matching and validated creation of
`examiner_report.txt` for files identified by the `_er` suffix.

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `7fa54fbd8242139b0a58c60fedf45dc674ba4ed530f1453f0d45080503fab528` |
| `core/examiner_report_gold.py` | `7750c213d4b1ce71225d44d13d77f7dcd19274c6a1f787c4855db599d9782b08` |

## Routing compatibility verification

The existing main-pipeline integration locates each processed question through its
own `metadata.json` and writes `examiner_report.txt` to `json_path.parent`. Therefore
an exact-topic-folder rename or routing change does not change the report's question
association: the report remains in that question's actual folder. No examiner-report
code was changed.

An end-to-end extraction test requires a real matching Examiner Report PDF; no such
PDF is present in the supplied workspace. When one is supplied, the existing strict
matching pipeline remains responsible for accepting or rejecting it.
