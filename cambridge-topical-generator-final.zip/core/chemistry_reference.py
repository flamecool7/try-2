"""
chemistry_reference.py
======================
Comprehensive detection and removal of chemistry reference materials,
data sheets, periodic tables, and non-question back-matter from Cambridge exam papers.

Reference materials excluded by this module:
  1. The Periodic Table of Elements (A-Level & IGCSE formats)
  2. Data Booklet / Data Sheets / Chemical Data Tables
  3. Qualitative Analysis Notes (Tests for anions, aqueous cations, gases, flame tests)
  4. Standard Electrode (Reduction) Potentials (E⦵ tables and series)
  5. Spectroscopy reference tables (1H NMR, 13C NMR, Infrared absorption frequencies)
  6. Bond energies, bond enthalpies, and ionisation energies
  7. Important values, constants and physical standards
  8. Mathematical Formulae & Statistical Tables (MF19, MF9, MF20, physics/math formula sheets)
  9. Administrative back-matter: copyright acknowledgements, lined continuation pages, blank pages
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Set, Tuple

import fitz  # PyMuPDF


# ---------------------------------------------------------------------------
# Comprehensive Keyword & Heading Signatures
# ---------------------------------------------------------------------------

PERIODIC_TABLE_SIGNS = (
    "the periodic table of elements",
    "periodic table of elements",
    "the periodic table",
    "periodic table of the elements",
    "periodic table",
    "relative atomic masses",
    "relative atomic mass",
    "atomic numbers",
    "atomic number",
    "lanthanoids",
    "actinoids",
    "group 1",
    "group 18",
    "group viii",
)

DATA_BOOKLET_SIGNS = (
    "data booklet",
    "data sheet",
    "data section",
    "tables of chemical data",
    "chemical data sheet",
    "contents: tables of chemical data",
    "important values, constants and standards",
    "important values, constants",
    "list of data",
)

QUALITATIVE_ANALYSIS_SIGNS = (
    "qualitative analysis notes",
    "notes for use in qualitative analysis",
    "tests for anions",
    "tests for aqueous cations",
    "tests for gases",
    "flame tests for metal ions",
    "flame tests",
    "effect of aqueous sodium hydroxide",
    "effect of aqueous ammonia",
    "test and test result",
    "test for anions",
    "test for aqueous cations",
    "test for gases",
)

ELECTRODE_POTENTIAL_SIGNS = (
    "standard electrode (reduction) potentials",
    "standard electrode potentials",
    "standard reduction potentials",
    "electrode potentials",
    "e⦵ in alphabetical order",
    "e⦵ at 298 k",
    "electrode reaction",
    "e⦵ / v",
    "e⦵/v",
)

SPECTROSCOPY_SIGNS = (
    "characteristic infrared absorption frequencies",
    "characteristic infrared absorption range",
    "infrared absorption frequencies",
    "infrared absorption range",
    "typical proton (1h) nmr chemical shift values",
    "typical proton nmr chemical shift",
    "typical carbon-13 (13c) nmr chemical shift values",
    "typical carbon-13 nmr chemical shift",
    "1h nmr chemical shift",
    "13c nmr chemical shift",
    "chemical shift range δ / ppm",
    "chemical shift range",
    "absorption range in wavenumbers",
)

CONSTANTS_AND_ENERGIES_SIGNS = (
    "bond energies in diatomic molecules",
    "bond energies in polyatomic molecules",
    "bond energies",
    "bond enthalpies",
    "ionisation energies (1st, 2nd, 3rd and 4th)",
    "ionisation energies of selected elements",
    "ionisation energies",
    "molar gas constant",
    "avogadro constant",
    "faraday constant",
    "planck constant",
    "speed of light in free space",
    "rest mass of electron",
    "rest mass of proton",
    "elementary charge",
    "specific heat capacity",
    "acceleration of free fall",
)

FORMULA_SHEET_SIGNS = (
    "mathematical formulae",
    "list of formulae and statistical tables",
    "list of formulae",
    "formulae and statistical tables",
    "formulae list",
    "formula sheet",
    "formulae and tables",
    "mathematical formulae and statistical tables",
    "mf19",
    "mf9",
    "mf20",
)

ADMIN_BACK_MATTER_SIGNS = (
    "permission to reproduce items",
    "copyright acknowledgements",
    "to avoid the issue of disclosure of answer-related information",
    "additional page",
    "additional lined page",
    "if you use the following lined pages",
    "if you use the following lined page",
    "continuation sheet",
    "continuation page",
    "blank page",
    "do not write on this page",
)

CANDIDATE_INFO_SIGNS = (
    "centre number",
    "center number",
    "candidate number",
    "candidate name",
    "candidate details",
    "write your name",
    "write your centre",
    "personal details",
    "answer sheet",
    "additional answer",
    "instructions to candidates",
    "read these instructions first",
)

# Set of chemical element symbols (for Periodic Table layout detection)
CHEMICAL_ELEMENT_SYMBOLS: Set[str] = {
    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
    "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
    "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
    "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
    "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
    "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
    "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
    "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
    "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
    "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
    "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
    "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
}


@dataclass
class PageClassification:
    page_idx: int
    is_reference: bool
    is_blank: bool
    is_candidate_info: bool
    category: str
    confidence: float
    reason: str
    has_question_content: bool


# ---------------------------------------------------------------------------
# Core Detection Functions
# ---------------------------------------------------------------------------

def _page_has_question_structure(doc: fitz.Document, page_idx: int) -> bool:
    """
    Check if a page has genuine exam question structure.
    
    Examines:
      - Left-margin question markers (e.g. 1, 2, Question 1)
      - Subpart markers (a), (b), (i), (ii)
      - Mark allocations in brackets [1], [2], [Total: 10]
      - Exam command language (Calculate, Explain, State, Describe, Determine, Draw)
    
    Filters out margin warnings, barcodes, copyright notices, and page numbers.
    """
    page = doc[page_idx]
    width, height = float(page.rect.width), float(page.rect.height)
    
    # Body area excludes running header (top 6%) and running footer (bottom 8%)
    body_clip = fitz.Rect(0, height * 0.06, width, height * 0.92)
    body_text = page.get_text("text", clip=body_clip) or ""

    # Remove margin warning text and boilerplate variations
    clean_body = re.sub(r"(?:do\s+not\s+)?write\s+in\s+this\s+mar(?:gin)?", "", body_text, flags=re.IGNORECASE)
    clean_body = re.sub(r"©.*?Assessment \d{4}", "", clean_body, flags=re.IGNORECASE)
    clean_body = re.sub(r"Permission to reproduce items.*", "", clean_body, flags=re.DOTALL)
    clean_body = re.sub(r"\[?Turn over\]?", "", clean_body, flags=re.IGNORECASE)

    command_re = re.compile(
        r"\b(complete|calculate|state|explain|describe|draw|show|give|"
        r"identify|determine|evaluate|discuss|compare|justify|outline|"
        r"define|construct|convert|suggest|deduce|sketch|predict|"
        r"which|what|where|when|why|how|statement|correct|true|false)\b",
        re.IGNORECASE,
    )
    mark_re = re.compile(r"\[\s*\d{1,2}\s*\]")
    total_mark_re = re.compile(r"\[\s*total\s*:\s*\d{1,2}\s*\]", re.IGNORECASE)
    subpart_re = re.compile(r"\(\s*(?:[a-z]|[ivx]{1,4})\s*\)", re.I)
    mcq_option_re = re.compile(r"^\s*[A-D]\s+[a-zA-Z0-9]", re.MULTILINE)
    top_re = re.compile(r"^\s*(\d{1,2})(?:$|\s+|[.)])")

    has_command = bool(command_re.search(clean_body))
    has_marks = bool(mark_re.search(clean_body))
    has_total = bool(total_mark_re.search(clean_body))
    has_subpart = bool(subpart_re.search(clean_body))
    has_mcq_options = len(mcq_option_re.findall(clean_body)) >= 2

    has_top = False
    for line in clean_body.splitlines():
        st = line.strip()
        if top_re.match(st) and not st.startswith("[") and not st.startswith("(") and not st.startswith("*"):
            has_top = True
            break

    is_q = (has_top and (has_command or has_marks or has_subpart or has_mcq_options)) or \
           ((has_subpart or has_command) and (has_marks or has_total)) or \
           (has_subpart and has_marks) or \
           (has_top and has_mcq_options)

    return bool(is_q)


def _detect_periodic_table_grid(text: str, words: List[Tuple]) -> Tuple[bool, float]:
    """Detect if the page is a Periodic Table grid based on element symbols."""
    raw_tokens = set(re.findall(r"\b[A-Z][a-z]?\b", text))
    matching_elements = raw_tokens.intersection(CHEMICAL_ELEMENT_SYMBOLS)
    
    # Check for Periodic table header or high element symbol density
    has_pt_title = any(s in text.lower() for s in ("periodic table", "atomic number", "lanthanoids", "actinoids"))
    
    if len(matching_elements) >= 25:
        return True, 1.0
    if has_pt_title and len(matching_elements) >= 8:
        return True, 0.95
    if len(matching_elements) >= 15 and "group" in text.lower():
        return True, 0.90
    return False, 0.0


def _detect_electrode_potentials_table(text: str) -> Tuple[bool, float]:
    """Detect Standard Electrode Potentials tables."""
    low = text.lower()
    has_title = any(s in low for s in ELECTRODE_POTENTIAL_SIGNS)
    # Check for electrochemical equations pattern (e.g. + e- ⇌ or + 2e- ⇌)
    has_redox_eqs = len(re.findall(r"[⇌=]\s*(?:\+|\d|[A-Z])", text)) >= 3 or \
                    len(re.findall(r"\+\s*\d*e[–-]", text, re.I)) >= 3
    has_voltages = len(re.findall(r"[+\-–]\s*\d+\.\d{2}\b", text)) >= 3
    
    if has_title and (has_redox_eqs or has_voltages):
        return True, 1.0
    if has_title:
        return True, 0.85
    if has_redox_eqs and has_voltages and len(re.findall(r"[A-Z][a-z]?\s*\d*\+", text)) >= 4:
        return True, 0.80
    return False, 0.0


def _detect_qualitative_analysis_notes(text: str) -> Tuple[bool, float]:
    """Detect Qualitative Analysis Notes pages."""
    low = text.lower()
    matches = sum(1 for s in QUALITATIVE_ANALYSIS_SIGNS if s in low)
    if matches >= 2:
        return True, 1.0
    if matches == 1 and any(k in low for k in ("effervescence", "precipitate", "litmus", "limewater", "splint")):
        return True, 0.90
    return False, 0.0


def _detect_spectroscopy_table(text: str) -> Tuple[bool, float]:
    """Detect NMR and IR spectroscopy correlation reference tables."""
    low = text.lower()
    matches = sum(1 for s in SPECTROSCOPY_SIGNS if s in low)
    has_shift_ppm = "ppm" in low and ("δ" in text or "shift" in low)
    has_ir_cm = "cm–1" in text or "cm-1" in low or "wavenumber" in low
    
    if matches >= 1 and (has_shift_ppm or has_ir_cm):
        return True, 1.0
    if matches >= 2:
        return True, 0.95
    return False, 0.0


def _detect_data_booklet_or_constants(text: str) -> Tuple[bool, float]:
    """Detect Data Booklet, Constants, Bond Energies, Ionisation Energies tables."""
    low = text.lower()
    matches_db = sum(1 for s in DATA_BOOKLET_SIGNS if s in low)
    matches_const = sum(1 for s in CONSTANTS_AND_ENERGIES_SIGNS if s in low)
    
    if matches_db >= 1:
        return True, 0.95
    if matches_const >= 2:
        return True, 0.95
    if matches_const >= 1 and any(k in low for k in ("avogadro", "faraday", "molar gas", "planck", "kj mol", "kj mol–1")):
        return True, 0.90
    return False, 0.0


def _detect_formula_sheet(text: str) -> Tuple[bool, float]:
    """Detect Mathematical Formulae and Statistical Tables."""
    low = text.lower()
    matches = sum(1 for s in FORMULA_SHEET_SIGNS if s in low)
    if matches >= 1 and any(k in low for k in ("formulae", "mf19", "mf9", "mf20", "statistical tables", "differentiation", "integration")):
        return True, 0.95
    return False, 0.0


def _detect_admin_back_matter(text: str) -> Tuple[bool, float]:
    """Detect copyright acknowledgements, lined continuation pages, blank pages."""
    low = text.lower()
    for s in ADMIN_BACK_MATTER_SIGNS:
        if s in low:
            return True, 0.90
    return False, 0.0


_RESCUE_QSTART_RE = re.compile(r"^\s*(\d{1,2})\s+[A-Z(]", re.MULTILINE)
_RESCUE_OPTION_RE = re.compile(r"^\s*[A-D]\s+[A-Za-z0-9(]", re.MULTILINE)
_RESCUE_MARK_RE = re.compile(r"\[\s*\d{1,2}\s*\]")


def _first_admin_sign_pos(text: str) -> int:
    """Position of the earliest admin back-matter sign (len(text) if none)."""
    low = text.lower()
    positions = [low.find(s) for s in ADMIN_BACK_MATTER_SIGNS if s in low]
    return min(positions) if positions else len(text)


def _has_question_start_beyond(text: str, pos: int) -> bool:
    """True when the text BEYOND position ``pos`` starts a real question:
    a margin-style question number (1-2 digits at line start, followed by a
    capital/parenthesis) together with answer-option lines or mark tokens.
    Guards the poison layout where Cambridge prints the copyright
    acknowledgement ABOVE the final questions on the same page
    (0620_s16_qp_22 p15: Q38-40 verified)."""
    tail = text[pos:]
    if len(_RESCUE_OPTION_RE.findall(tail)) < 2 and not _RESCUE_MARK_RE.search(tail):
        return False
    return bool(_RESCUE_QSTART_RE.search(tail))


def classify_page(
    doc: fitz.Document,
    page_idx: int,
    total_pages: int,
    syllabus_code: str = "",
) -> PageClassification:
    """
    Perform deep classification of a page to determine if it is reference material,
    candidate info, blank, or an actual exam question page.
    """
    page = doc[page_idx]
    w, h = float(page.rect.width), float(page.rect.height)
    text = page.get_text("text").strip()
    low_text = text.lower()
    words = page.get_text("words")
    
    # 1. Blank page & Turn over page detection
    body_clip = fitz.Rect(0, h * 0.06, w, h * 0.92)
    body_text = page.get_text("text", clip=body_clip) or ""
    clean_body = re.sub(r"(?:do\s+not\s+)?write\s+in\s+this\s+mar(?:gin)?", "", body_text, flags=re.IGNORECASE)
    clean_body = re.sub(r"©.*?Assessment \d{4}", "", clean_body, flags=re.IGNORECASE)
    clean_body = re.sub(r"\[?Turn over\]?", "", clean_body, flags=re.IGNORECASE)
    clean_body = re.sub(r"\b(?:BLANK PAGE|Turn over|DFD)\b", "", clean_body, flags=re.IGNORECASE)
    clean_body = re.sub(r"\d{4}/\d{2}/[A-Z]/[A-Z]/\d{2}", "", clean_body, flags=re.IGNORECASE)
    clean_body = re.sub(r"[\x00-\x1f\x7f-\x9f]", "", clean_body)
    meaningful_alpha = len(re.findall(r"[a-zA-Z]", clean_body))

    if meaningful_alpha < 20 and len(page.get_drawings()) < 15:
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=True, is_candidate_info=False,
            category="blank_page", confidence=1.0, reason="Blank or Turn Over transition page",
            has_question_content=False,
        )

    # 2. Candidate info / cover page (page 0 or 1)
    if page_idx <= 1:
        info_hits = sum(1 for sig in CANDIDATE_INFO_SIGNS if sig in low_text)
        if info_hits >= 2:
            return PageClassification(
                page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=True,
                category="candidate_info", confidence=1.0, reason="Candidate cover / instructions page",
                has_question_content=False,
            )

    # 3. Structural reference veto BEFORE the question-structure short-circuit
    # (RS-12, ordered-veto decision): the Periodic Table grid detector is
    # structural (word-geometry), but its element-symbol rows (e.g. "5 B boron")
    # satisfy the MCQ-broadened question probe's option-line pattern — so the
    # PT check must run FIRST and must win. Corpus-verified on 3 PT pages.
    is_pt, pt_conf = _detect_periodic_table_grid(text, words)
    if is_pt:
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=False,
            category="periodic_table", confidence=pt_conf, reason="Periodic Table of Elements",
            has_question_content=False,
        )

    # 4. Check for genuine question structure
    has_q = _page_has_question_structure(doc, page_idx)

    # If the page contains genuine question content, it is ALWAYS question content
    if has_q:
        return PageClassification(
            page_idx=page_idx, is_reference=False, is_blank=False, is_candidate_info=False,
            category="question_content", confidence=1.0, reason="Exam question content",
            has_question_content=True,
        )

    # Positional context for non-question pages
    is_terminal = (page_idx >= max(0, total_pages - 6))
    is_front = (page_idx <= 3)

    # (Periodic Table veto intentionally relocated above the question-structure
    #  short-circuit — RS-12 ordered-veto decision. Content-sign detectors
    #  below stay AFTER the question check: they must not veto question pages
    #  whose TEXT merely mentions e.g. the Data Booklet — 9701_s15_qp_12 proof.)

    # 5. Qualitative Analysis Notes
    is_qa, qa_conf = _detect_qualitative_analysis_notes(text)
    if is_qa:
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=False,
            category="qualitative_analysis", confidence=qa_conf, reason="Qualitative Analysis Notes",
            has_question_content=False,
        )

    # 6. Standard Electrode Potentials
    is_ep, ep_conf = _detect_electrode_potentials_table(text)
    if is_ep:
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=False,
            category="electrode_potentials", confidence=ep_conf, reason="Standard Electrode Potentials table",
            has_question_content=False,
        )

    # 7. Spectroscopy Reference Tables
    is_spec, spec_conf = _detect_spectroscopy_table(text)
    if is_spec:
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=False,
            category="spectroscopy_data", confidence=spec_conf, reason="NMR/IR spectroscopy correlation table",
            has_question_content=False,
        )

    # 8. Data Booklet / Physical Constants / Energetics
    is_db, db_conf = _detect_data_booklet_or_constants(text)
    if is_db:
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=False,
            category="data_booklet_constants", confidence=db_conf, reason="Data Booklet / Constants / Energetics",
            has_question_content=False,
        )

    # 9. Formula Sheet
    is_form, form_conf = _detect_formula_sheet(text)
    if is_form:
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=False,
            category="formula_sheet", confidence=form_conf, reason="Mathematical / Physics Formula Sheet",
            has_question_content=False,
        )

    # 10. Admin Back-Matter / Lined Continuation Pages. RS-12 poison-page
    # rescue: a back-matter SIGN alone does not disqualify the page when a real
    # question start exists BEYOND the sign (the question-structure probe
    # strips everything after "Permission to reproduce items" via a DOTALL
    # regex, so mixed pages must be re-checked on the raw text).
    is_adm, adm_conf = _detect_admin_back_matter(text)
    if is_adm and not _has_question_start_beyond(text, _first_admin_sign_pos(text)):
        return PageClassification(
            page_idx=page_idx, is_reference=True, is_blank=False, is_candidate_info=False,
            category="admin_back_matter", confidence=adm_conf,
            reason="Continuation page / copyright back-matter",
            has_question_content=False,
        )
    if is_adm:
        print(f"  [page-rescue] Page {page_idx + 1}: question start beyond "
              f"back-matter sign - kept as question content")

    # Normal exam question page
    return PageClassification(
        page_idx=page_idx, is_reference=False, is_blank=False, is_candidate_info=False,
        category="question_content", confidence=1.0, reason="Exam question content",
        has_question_content=has_q,
    )


def identify_removable_pages(
    doc: fitz.Document,
    total_pages: int,
    syllabus_code: str = "",
) -> Tuple[List[int], List[int], List[PageClassification]]:
    """
    Classify all pages in a document and return (pages_to_keep, pages_to_remove, classifications).
    """
    keep: List[int] = []
    remove: List[int] = []
    classifications: List[PageClassification] = []

    for idx in range(total_pages):
        cls = classify_page(doc, idx, total_pages, syllabus_code=syllabus_code)
        classifications.append(cls)
        if cls.is_reference or cls.is_blank or cls.is_candidate_info:
            remove.append(idx)
        else:
            keep.append(idx)

    return keep, remove, classifications
