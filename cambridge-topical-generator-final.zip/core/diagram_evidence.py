"""Deterministic diagram-evidence harvester (mega-spec Fix 8).

Given a question crop raster (numpy array) and its extracted text, produce a
small dict of *counts* of geometric diagram classes. These signals only ever
SUPPLEMENT text/formula evidence in the math classifiers — a question with no
supporting text and only an ambiguous drawing (e.g. one plain triangle) yields
no confident topic and is routed by the caller to REVIEW_REQUIRED.

Recognised classes (per spec Fix 8 enumeration):
  triangles            - closed 3-vertex polygons
  angle_arcs           - open arc contours (not full circles), arc-radius 6..120px
  sectors              - arc with two bounding radii nearby (pie/sector shapes)
  circles              - closed near-circular contours
  vector_arrows        - straight segments with an arrowhead fan at one endpoint
  force_arrows         - vector_arrows when the question text mentions force,
                         weight, tension, friction or thrust (documented heuristic)
  axes_with_curve      - long orthogonal axis pair plus a free curve contour
  bar_blocks           - >=3 adjacent equal-width filled bars (histogram/frequency)
  greek_labels         - theta/pi/degree/alpha/beta/lambda symbols in the text
  normal_curves        - 0 from raster (text layer owns this; kept for schema)
  probability_trees    - 0 from raster (text layer owns this; kept for schema)

Everything is plain cv2/numpy geometry — no network, no model download, fully
deterministic for a fixed input raster.
"""
from __future__ import annotations

from typing import Dict

import math
import numpy as np

_GREEK_CHARS = "θπ°αβλφΔΣμ"


def _to_gray(arr: np.ndarray) -> np.ndarray:
    if arr.ndim == 3:
        arr = arr[..., :3]
        gray = (0.299 * arr[..., 0] + 0.587 * arr[..., 1] + 0.114 * arr[..., 2]).astype(np.uint8)
    else:
        gray = arr.astype(np.uint8)
    return gray


def harvest_diagram_evidence(image: np.ndarray, text: str = "") -> Dict[str, int]:
    """Return the diagram-signal counts for one question crop. Never raises."""
    import cv2

    gray = _to_gray(image)
    # Ink mask: dark pixels on light paper.
    ink = (gray < 128).astype(np.uint8) * 255
    # Ignore tiny rasters — nothing trustworthy at thumbnail scale.
    h, w = gray.shape
    if h < 40 or w < 40:
        return _zero(text)

    signals = _zero(text)

    contours, _hier = cv2.findContours(ink, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    triangles = circles = arcs = 0
    curve_contours = 0
    arc_items = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < 60:
            continue
        peri = cv2.arcLength(cnt, True)
        if peri <= 0:
            continue
        approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
        if cv2.isContourConvex(approx) and len(approx) == 3 and area > 150:
            triangles += 1
            continue
        circularity = 4.0 * math.pi * area / (peri * peri)
        closed = cv2.isContourConvex(approx) or circularity > 0.95
        if circularity >= 0.80 and len(approx) >= 5:
            (_x, _y), radius = cv2.minEnclosingCircle(cnt)
            if 6 <= radius <= 300:
                circles += 1
                continue
        # Arc-like: fits a circle of sane radius but is visibly open/short.
        if len(cnt) >= 5:
            (_x, _y), radius = cv2.minEnclosingCircle(cnt)
            if 6 <= radius <= 120:
                # extent = contour area vs its bounding circle sector area
                chord = cv2.arcLength(cnt, False)
                frac = chord / (2.0 * math.pi * radius)
                if 0.05 <= frac <= 0.75 and area < 0.6 * math.pi * radius * radius:
                    arcs += 1
                    arc_items.append((float(_x), float(_y), float(radius)))
                    continue
        # Free curve heuristic: long non-convex open contour.
        hull = cv2.convexHull(cnt)
        hull_area = cv2.contourArea(hull)
        if hull_area > 0 and area / hull_area < 0.75 and peri > 120:
            curve_contours += 1

    # Sector: an arc whose fitted circle centre has two straight radii nearby —
    # approximated cheaply as 'arc with above-average straight-line spokes'.
    lines = cv2.HoughLinesP(ink, 1, np.pi / 180, threshold=max(20, min(h, w) // 12),
                            minLineLength=max(15, min(h, w) // 20), maxLineGap=4)
    segs = []
    if lines is not None:
        for ln in np.asarray(lines).reshape(-1, 4)[:600]:
            x1, y1, x2, y2 = (int(v) for v in ln)
            length = math.hypot(x2 - x1, y2 - y1)
            angle = math.degrees(math.atan2(y2 - y1, x2 - x1)) % 180.0
            segs.append((x1, y1, x2, y2, length, angle))

    sectors = 0
    for (cx, cy, r) in arc_items:
        spokes = sum(
            1 for (x1, y1, x2, y2, length, _a) in segs
            if length >= 0.6 * r and min(math.hypot(x1 - cx, y1 - cy),
                                          math.hypot(x2 - cx, y2 - cy)) <= 0.5 * r
        )
        if spokes >= 2:
            sectors += 1

    # Arrows: a long-ish segment whose endpoint collects 2+ short fan segments
    # at 15..75 degrees (arrowhead barbs).
    arrows = 0
    long_segs = [s for s in segs if s[4] >= max(30, min(h, w) // 10)]
    short_segs = [s for s in segs if 6 <= s[4] < max(30, min(h, w) // 10)]
    for (x1, y1, x2, y2, length, angle) in long_segs:
        for (ex, ey) in ((x1, y1), (x2, y2)):
            barbs = 0
            for (a1, b1, a2, b2, slen, sang) in short_segs:
                mx, my = (a1 + a2) / 2.0, (b1 + b2) / 2.0
                if math.hypot(mx - ex, my - ey) <= max(10, slen):
                    d = abs((sang - angle + 90) % 180 - 90)
                    if 15 <= d <= 75:
                        barbs += 1
            if barbs >= 2:
                arrows += 1
                break

    # Axes + curve: one near-horizontal and one near-vertical long segment plus
    # at least one free curve contour.
    horiz = any(s[4] >= 0.35 * w and (s[5] < 8 or s[5] > 172) for s in segs)
    vert = any(s[4] >= 0.30 * h and 82 <= s[5] <= 98 for s in segs)
    axes_curve = 1 if (horiz and vert and curve_contours >= 1) else 0

    # Histogram bars: >=3 rectangular filled blocks of similar width side by side.
    rect_count = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < 120:
            continue
        peri = cv2.arcLength(cnt, True)
        if peri <= 0:
            continue
        approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
        x, y, bw, bh = cv2.boundingRect(approx)
        if len(approx) == 4 and bh > 1.6 * max(bw, 1) and (area / float(bw * bh)) > 0.7:
            rect_count += 1
    bar_blocks = rect_count if rect_count >= 3 else 0

    signals["triangles"] = triangles
    signals["circles"] = circles
    signals["angle_arcs"] = max(0, arcs - sectors)
    signals["sectors"] = sectors
    signals["vector_arrows"] = arrows
    lowered = text.lower() if text else ""
    if arrows and any(k in lowered for k in ("force", "weight", "tension", "friction", "thrust", "newton")):
        signals["force_arrows"] = arrows
    signals["axes_with_curve"] = axes_curve
    signals["bar_blocks"] = bar_blocks
    return signals


def _zero(text: str) -> Dict[str, int]:
    greek = sum(text.count(ch) for ch in _GREEK_CHARS) if text else 0
    return {
        "triangles": 0,
        "circles": 0,
        "angle_arcs": 0,
        "sectors": 0,
        "vector_arrows": 0,
        "force_arrows": 0,
        "axes_with_curve": 0,
        "bar_blocks": 0,
        "greek_labels": greek,
        "normal_curves": 0,
        "probability_trees": 0,
    }
