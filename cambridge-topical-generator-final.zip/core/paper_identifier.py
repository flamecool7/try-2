"""
Paper Identifier - Universal component
Identifies paper metadata from filename and header.
Now supports IGCSE + A-Level levels.
Supports BOTH naming conventions:
- Standard: 9701_m26_qp_22.pdf , 0620_m26_qp_42.pdf
- Real-world 2026: 9701 Chemistry March 2026 Question Paper 12.pdf,
               9706 Accounting March 2026 Question Paper 12.pdf,
               9701 Chemistry March 2026 Mark Scheme 12.pdf (if present)

Level inference:
- 05xx, 06xx -> IGCSE
- 97xx -> A-Level
"""

import re
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

# Pattern 1: Standard short format: 9701_m26_qp_22, 0620_s23_ms_42, 9701_m26_er_22
# Examiner Reports are compilation documents and commonly have no component
# suffix (for example, 9709_s22_er.pdf).  Detect this definitive ``_er`` file
# type before the component-paper pattern below so it can never be treated as
# a QP or mark scheme.
# Extended season tokens (final-upgrade Issue 7, 2026-08-10, approved):
# single letters PLUS the compound/full-word forms found in real-world
# filenames (m-j, summer, spring, specimen, ...). Longest-first alternation
# so 'm' never eats the head of 'mj' or 'march'.
_SEASON_TOKEN = (
    r'(?:specimen|spec|summer|winter|spring|march|may|june'
    r'|m_j|m-j|o_n|o-n|f_m|f-m|mj|on|fm|sp|[msw])'
)
# Normalise any extended token onto the canonical single letter.
_SEASON_TOKEN_NORM = {
    'mj': 's', 'summer': 's', 'may': 's', 'june': 's',
    'on': 'w', 'o_n': 'w', 'o-n': 'w', 'winter': 'w',
    'fm': 'm', 'f_m': 'm', 'f-m': 'm', 'spring': 'm', 'march': 'm',
    'sp': 'sp', 'spec': 'sp', 'specimen': 'sp',
}

def _norm_season_letter(token) -> str:
    """Map a (possibly extended) season token to the canonical letter."""
    if not token:
        return 'm'
    t = str(token).lower()
    if t in _SEASON_TOKEN_NORM:
        return _SEASON_TOKEN_NORM[t]
    return t if t in ('m', 's', 'w', 'f', 'j', 'n', 'sp') else 'm'

EXAMINER_REPORT_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')?[_-]?(?P<year>\d{2})[_-]?(?P<type>er)(?:[_-]?(?P<variant>\d{1,2}))?$',
    re.IGNORECASE
)

# Issue 7 additive patterns: year-first ("9701_2024_s_er.pdf") and
# type-first ("9701_er_s24.pdf") real-world ER arrangements.
EXAMINER_REPORT_YEAR_FIRST_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<year_full>20\d{2})[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')[_-]?(?P<type>er)(?:[_-]?(?P<variant>\d{1,2}))?$',
    re.IGNORECASE
)
EXAMINER_REPORT_TYPE_FIRST_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<type>er)[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')(?P<year>\d{2})$',
    re.IGNORECASE
)

PAPER_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')?[_-]?(?P<year>\d{2})[_-]?(?P<type>qp|ms|er|ir|gt)[_-]?(?P<variant>\d{1,2})',
    re.IGNORECASE
)

# Pattern 2: Real-world long format: "9701 Chemistry March 2026 Question Paper 12.pdf"
# Also handles: "9706 Accounting March 2026 Insert 32.pdf", "9700 Biology March 2026 Confidential Instructions 33.pdf", "9701 Chemistry March 2026 Examiner Report 22.pdf"
LONG_PATTERN = re.compile(
    r'(?P<code>\d{4})'                     # 9701
    r'[^0-9]*?'                            # any non-digit between code and month
    r'(?P<month>January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov)'  # Month
    r'\s+(?P<year_full>\d{4})'             # 2026
    r'[^A-Za-z]*?'                         # separator
    r'(?P<type_long>Question Paper|Mark Scheme|Insert|Confidential Instructions|Supporting File|Paper|Examiner Report|Principal Examiner Report)'  # Type
    r'\s*(?P<variant>\d{1,2})?',           # Variant e.g., 12, 22, 42
    re.IGNORECASE
)

# Month to season letter mapping
MONTH_TO_SEASON = {
    'january': 'm', 'jan': 'm',
    'february': 'm', 'feb': 'm',
    'march': 'm', 'mar': 'm',
    'april': 'm',  # rare, treat as spring
    'may': 's',
    'june': 's', 'jun': 's',
    'july': 's', 'jul': 's',
    'august': 's', 'aug': 's',
    'september': 's', 'sep': 's',
    'october': 'w', 'oct': 'w',
    'november': 'w', 'nov': 'w',
    'december': 'w', 'dec': 'w',
}

SEASON_MAP = {
    'm': 'Spring',  # Feb/March
    's': 'Summer',  # May/June
    'w': 'Winter',  # Oct/Nov
    'f': 'Spring',
    'j': 'Summer',
    'n': 'Winter',
    'sp': 'Specimen',  # extended tokens (final-upgrade Issue 7)
}

LEVEL_BY_PREFIX = {
    '04': 'IGCSE',
    '05': 'IGCSE',
    '06': 'IGCSE',
    '09': 'A-Level',
    '96': 'A-Level',
    '97': 'A-Level',
    '92': 'A-Level',
}

def infer_level_from_code(syllabus_code: str) -> str:
    code = str(syllabus_code)
    for prefix, level in LEVEL_BY_PREFIX.items():
        if code.startswith(prefix):
            return level
    if code.startswith('9'):
        return 'A-Level'
    return 'IGCSE'



# ---------------------------------------------------------------------------
# Overseer IGCSE-format spec (approved). Component map verbatim from the spec;
# validated against the real fixture corpus (0620_s16 / 9701_s15 / 0580_s15).
# ---------------------------------------------------------------------------
IGCSE_COMPONENT_MAP = {
    # Sciences 0610/0620/0625: Papers 1 AND 2 are MCQ (core / extended)
    "0610": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "MCQ", "22": "MCQ", "23": "MCQ",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED",
             "51": "PRACTICAL", "52": "PRACTICAL", "53": "PRACTICAL",
             "61": "ATP", "62": "ATP", "63": "ATP"},
    "0620": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "MCQ", "22": "MCQ", "23": "MCQ",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED",
             "51": "PRACTICAL", "52": "PRACTICAL", "53": "PRACTICAL",
             "61": "ATP", "62": "ATP", "63": "ATP"},
    "0625": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "MCQ", "22": "MCQ", "23": "MCQ",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED",
             "51": "PRACTICAL", "52": "PRACTICAL", "53": "PRACTICAL",
             "61": "ATP", "62": "ATP", "63": "ATP"},
    # Mathematics 0580 / Additional 0606: NO MCQ papers
    "0580": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED"},
    "0606": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    # Economics 0455: Paper 1 only is MCQ
    "0455": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    # Business / Accounting / CS / Geography: NO MCQ papers
    "0450": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0452": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0478": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0460": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED"},
    # History: essay / source-based
    "0470": {"11": "ESSAY", "12": "ESSAY", "13": "ESSAY",
             "21": "ESSAY", "22": "ESSAY", "23": "ESSAY",
             "41": "ESSAY", "42": "ESSAY", "43": "ESSAY"},
    # English Language
    "0500": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0522": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    # Sociology
    "0495": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
}

# Expected question counts — ADVISORY ONLY (approved: never a gate).
# Evidence status recorded per entry:
#   40 MCQ: MEASURED from real MS answer grids (0620_s16_ms_21/22, 9701_s15_ms_12
#           all parse exactly 40 rows).
#   30 (0455 MCQ): Cambridge-published fixed structure; no fixture this round.
#   Structured/essay/practical counts: VARY BY SESSION — the spec's table
#   claimed e.g. 0580=10 but the real 0580_s15_qp_22 shows ~21-24 question
#   anchors. Honest value: None (not asserted).
# (IGCSE_QUESTION_COUNT retired — see mcq_registry receipt D4)

# Unified-MCQ round: _ALEVEL_MCQ_P1_SYLLABI / ALEVEL_MCQ_QUESTION_COUNT /
# IGCSE_QUESTION_COUNT are RETIRED — the registry is the single authority
# (RULE 1). Measured-count provenance lives in core/mcq_registry.py (D4).


def resolve_paper_format(syllabus_code: str, variant: str) -> str:
    """Unified-MCQ round (approved Q1=adopt_hybrid): mcq_registry.is_mcq is
    the SINGLE MCQ authority (RULE 1). IGCSE_COMPONENT_MAP is now consulted
    ONLY for non-MCQ formats (STRUCTURED/PRACTICAL/ATP/ESSAY — truthful
    folder names). The legacy A-Level variant-first-digit rule is RETIRED:
    identical for 9701/9702/9700/9708 P1; deltas 9608/9696 only, both inert
    (no configs/fixtures) — receipts in core/mcq_registry.py."""
    from .mcq_registry import is_mcq
    code = str(syllabus_code or "")
    var = str(variant or "")
    if is_mcq(code, var):
        return "MCQ"
    cmap = IGCSE_COMPONENT_MAP.get(code)
    if cmap is not None:
        return cmap.get(var, "STRUCTURED")
    return "STRUCTURED"


def expected_question_count(syllabus_code: str, paper_format: str,
                            variant: str = ""):
    """Advisory oracle. None = not asserted (never a gate).
    Unified-MCQ round: MCQ counts come from mcq_registry (RULE 1)."""
    if paper_format == "MCQ":
        from .mcq_registry import get_expected_question_count
        return get_expected_question_count(str(syllabus_code or ""),
                                           str(variant or ""))
    return None

@dataclass
class PaperInfo:
    file_path: Path
    syllabus_code: str
    year: str  # "2026"
    year_short: str  # "26"
    season: str  # "Spring", "Summer", "Winter"
    season_letter: str  # "m", "s", "w"
    paper_type: str  # "qp" or "ms" or "insert"
    variant: str  # "22" or "42"
    full_code: str  # "9701_m26_qp_22" or "0620_m26_qp_42"
    level: str  # "IGCSE" or "A-Level"
    subject_guess: Optional[str] = None
    original_name: str = ""  # Store original filename for debugging
    # Overseer IGCSE-format spec: filled by __post_init__ (covers every
    # construction site: standard / long-format / year-first / ER).
    paper_format: Optional[str] = None       # MCQ / STRUCTURED / ESSAY / PRACTICAL / ATP
    is_mcq: Optional[bool] = None
    expected_question_count: Optional[int] = None  # advisory; None = not asserted

    def __post_init__(self):
        if self.paper_type == "er":
            self.paper_format = "ER"
            self.is_mcq = False
            return
        fmt = resolve_paper_format(self.syllabus_code, self.variant)
        self.paper_format = fmt
        self.is_mcq = (fmt == "MCQ")
        self.expected_question_count = expected_question_count(
            self.syllabus_code, fmt, self.variant)

    def to_dict(self):
        return {
            "syllabus_code": self.syllabus_code,
            "year": self.year,
            "season": self.season,
            "type": self.paper_type,
            "variant": self.variant,
            "paper_format": self.paper_format,
            "is_mcq": self.is_mcq,
            "expected_question_count": self.expected_question_count,
            "full_code": self.full_code,
            "level": self.level,
            "original_name": self.original_name,
        }

def parse_paper_filename(file_path: str | Path) -> Optional[PaperInfo]:
    """Parse paper info from filename including level - supports both short and long formats"""
    path = Path(file_path)
    name = path.stem
    name_lower = name.lower()
    original_name = path.name

    # Examiner Report priority: a filename ending in _er (with an optional
    # component) is always an ER.  It is intentionally parsed before QP/MS
    # patterns; the suffix identifies only the file type, while normal ER
    # matching later verifies its applicable paper/component.
    er_match = EXAMINER_REPORT_PATTERN.search(name_lower)
    er_code = er_season_raw = er_year_short = er_variant = None
    if er_match:
        er_code = er_match.group('code')
        er_season_raw = er_match.group('season_letter')
        er_year_short = er_match.group('year')
        er_variant = er_match.group('variant') or ""
    else:
        # Additive arrangements (final-upgrade Issue 7): year-first then type-first
        my = EXAMINER_REPORT_YEAR_FIRST_PATTERN.search(name_lower)
        if my:
            er_code = my.group('code')
            er_season_raw = my.group('season_letter')
            er_year_short = my.group('year_full')[-2:]
            er_variant = my.group('variant') or ""
        else:
            mt = EXAMINER_REPORT_TYPE_FIRST_PATTERN.search(name_lower)
            if mt:
                er_code = mt.group('code')
                er_season_raw = mt.group('season_letter')
                er_year_short = mt.group('year')
                er_variant = ""
    if er_code is not None:
        code = er_code
        season_letter = _norm_season_letter(er_season_raw)
        year_short = er_year_short
        variant = er_variant
        full_year = 2000 + int(year_short) if int(year_short) < 50 else 1900 + int(year_short)
        from .config_loader import KNOWN_CODE_MAP
        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=SEASON_MAP.get(season_letter, 'Summer'),
            season_letter=season_letter,
            paper_type="er",
            variant=variant,
            full_code=f"{code}_{season_letter}{year_short}_er" + (f"_{variant}" if variant else ""),
            level=infer_level_from_code(code),
            subject_guess=KNOWN_CODE_MAP.get(code),
            original_name=original_name,
        )

    # Try Pattern 1 first (standard component papers)
    m = PAPER_PATTERN.search(name_lower)
    if m:
        code = m.group('code')
        season_letter = _norm_season_letter(m.group('season_letter'))
        year_short = m.group('year')
        ptype = m.group('type').lower()
        variant = m.group('variant')

        try:
            y_int = int(year_short)
            full_year = 2000 + y_int if y_int < 50 else 1900 + y_int
        except Exception as e:
            full_year = 2000 + int(year_short) if year_short.isdigit() else 2024

        season = SEASON_MAP.get(season_letter, 'Summer')
        full_code = f"{code}_{season_letter}{year_short}_{ptype}_{variant}"
        level = infer_level_from_code(code)

        from .config_loader import KNOWN_CODE_MAP
        subject_guess = KNOWN_CODE_MAP.get(code)

        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=season,
            season_letter=season_letter,
            paper_type=ptype,
            variant=variant,
            full_code=full_code,
            level=level,
            subject_guess=subject_guess,
            original_name=original_name,
        )

    # Try Pattern 2: Long real-world format
    m2 = LONG_PATTERN.search(name)
    if m2:
        code = m2.group('code')
        month_raw = m2.group('month').lower()
        year_full_str = m2.group('year_full')
        type_long = m2.group('type_long').lower()
        variant = m2.group('variant') or "12"  # default if missing

        # Map month to season letter
        season_letter = MONTH_TO_SEASON.get(month_raw, 'm')
        season = SEASON_MAP.get(season_letter, 'Spring')

        # Map type_long to qp/ms
        if "question paper" in type_long:
            ptype = "qp"
        elif "mark scheme" in type_long or "marking scheme" in type_long:
            ptype = "ms"
        elif "examiner report" in type_long or "principal examiner" in type_long:
            ptype = "er"
        elif "insert" in type_long:
            ptype = "qp"  # Insert is part of QP, treat as qp for grouping but will be filtered? Keep as insert
            # Actually keep as insert to avoid mixing with main QP
            ptype = "insert"
        elif "confidential" in type_long:
            ptype = "ci"  # confidential instructions
        elif "supporting" in type_long:
            ptype = "sf"  # supporting file
        else:
            ptype = "qp"  # default

        try:
            full_year = int(year_full_str)
            year_short = f"{full_year % 100:02d}"
        except Exception as e:
            full_year = 2026
            year_short = "26"

        full_code = f"{code}_{season_letter}{year_short}_{ptype}_{variant}"
        level = infer_level_from_code(code)

        from .config_loader import KNOWN_CODE_MAP
        subject_guess = KNOWN_CODE_MAP.get(code)

        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=season,
            season_letter=season_letter,
            paper_type=ptype,
            variant=variant,
            full_code=full_code,
            level=level,
            subject_guess=subject_guess,
            original_name=original_name,
        )

    return None

def identify_papers_in_dir(input_dir: str | Path) -> list[PaperInfo]:
    """Scan directory for papers - supports both formats"""
    input_dir = Path(input_dir)
    papers = []
    for file in input_dir.rglob("*.pdf"):
        info = parse_paper_filename(file)
        if info:
            # Only include qp and ms for main processing, but keep insert/ci as separate?
            # For now include all that parsed, but main.py will filter
            papers.append(info)
        else:
            print(f"[PaperIdentifier] Could not parse filename: {file.name} - flag for review")
    return papers
