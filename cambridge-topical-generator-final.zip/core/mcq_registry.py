"""mcq_registry.py — single authoritative MCQ-component registry (Overseer
unified-MCQ spec, STEP 1).

is_mcq(syllabus_code, component) is the ONLY MCQ-status authority anywhere
in the tree (RULE 1). paper_identifier.resolve_paper_format consults this
registry first and consults IGCSE_COMPONENT_MAP only for the non-MCQ formats
(STRUCTURED/PRACTICAL/ATP/ESSAY) that drive truthful folder names — the
registry cannot express those, so the map is retained for them (approved
decision Q1: adopt_hybrid).

PREMISE / DELTA RECEIPTS (audited against locked code before writing):
  D1  vs the RS-7 locked `_ALEVEL_MCQ_P1_SYLLABI = {9701,9702,9700,9708,
      9608,9696}` (variant-first-digit "1"): the registry is IDENTICAL for
      9701/9702/9700/9708 P1 ({11,12,13} — the only P1 variants Cambridge
      uses), and DIFFERS for 9608/9696 (locked: P1 MCQ; registry: no MCQ —
      the registry is considered more accurate here; A-Level CS/Geography
      Paper 1 are not MCQ papers). INERT: no subject configs or fixtures
      exist for 9608/9696, so no produced output changes.
  D2  +9990 (Psychology) was spec-asserted, flagged dubious, inert at
      lock time. RS-13 RESOLUTION (2026-08-11): Cambridge's own 9990
      syllabus (2021-2023 and from-2024) defines exactly four WRITTEN
      components (P1 Approaches/issues/debates, P2 Research methods,
      P3/P4 Specialist options) — short-answer/extended-response/essay
      only, NO multiple-choice component. The spec assertion was FALSE;
      the row is REMOVED so a future 9990 config's structured P1 can
      never be treated as MCQ. Test pins updated (36 -> 35 codes).
  D3  O-Level rows (4024/4037/5054/5070/5090/2281/2210/7110): INERT — no
      O-Level configs, and `infer_level_from_code` can't even classify them
      today ("5070" mis-infers IGCSE). Carried as data; real O-Level support
      is its own round.
  D4  Question counts provenance: sciences/IGCSE 40 = MEASURED on real grids
      (0620_s16_ms_21/22, 9701_s15_ms_12 — 40 rows each, RS-7 receipts);
      0455=30 Cambridge-published (RS-7 receipt); 9708=30, O-Level
      counts = SPEC-ASSERTED (no fixture). Advisory only — never a gate.
  D5  Spec corruption receipts: `-&gt;`, `&gt;`, `[mcq_registry.py](http://…)`
      family de-linkified on write (family 16 in the running ledger).
"""

from typing import Dict, Set

# ── MCQ COMPONENT REGISTRY ────────────────────────────
# A component is MCQ if and only if it appears here (verbatim spec rows).
MCQ_COMPONENTS: Dict[str, Set[str]] = {
    # ── A-LEVEL ───────────────────────────────────────
    "9700": {"11", "12", "13"},       # Biology: Paper 1 only — 40 questions
    "9701": {"11", "12", "13"},       # Chemistry: Paper 1 only — 40 questions
    "9702": {"11", "12", "13"},       # Physics: Paper 1 only — 40 questions
    "9709": set(),                    # Mathematics: no MCQ papers
    "9231": set(),                    # Further Mathematics: no MCQ
    "9708": {"11", "12", "13"},       # Economics: Paper 1 only — 30 questions
    "9609": set(),                    # Business: no MCQ
    "9706": set(),                    # Accounting: no MCQ
    "9618": set(),                    # Computer Science: no MCQ
    "9696": set(),                    # Geography: no MCQ (delta D1)
    "9489": set(),                    # History: no MCQ
    "9093": set(),                    # English Language: no MCQ
    "9699": set(),                    # Sociology: no MCQ
    # 9990 REMOVED (RS-13, Cambridge-verified: no MCQ component in Psychology).
    # ── IGCSE ─────────────────────────────────────────
    "0610": {"11", "12", "13", "21", "22", "23"},   # Biology: P1 AND P2 MCQ
    "0620": {"11", "12", "13", "21", "22", "23"},   # Chemistry: P1 AND P2
    "0625": {"11", "12", "13", "21", "22", "23"},   # Physics: P1 AND P2
    "0580": set(),                    # Mathematics: no MCQ
    "0606": set(),                    # Additional Mathematics: no MCQ
    "0455": {"11", "12", "13"},       # Economics: Paper 1 only — 30 questions
    "0450": set(),                    # Business: no MCQ
    "0452": set(),                    # Accounting: no MCQ
    "0478": set(),                    # Computer Science: no MCQ
    "0460": set(),                    # Geography: no MCQ
    "0470": set(),                    # History: no MCQ
    "0500": set(),                    # English Language: no MCQ
    "0522": set(),                    # English Language: no MCQ
    "0495": set(),                    # Sociology: no MCQ
    # ── O-LEVEL (inert: no configs/level-inference yet — delta D3) ──
    "4024": set(),                    # Mathematics: no MCQ
    "4037": set(),                    # Additional Mathematics: no MCQ
    "5054": {"11", "12", "13"},       # Physics: Paper 1 only
    "5070": {"11", "12", "13"},       # Chemistry: Paper 1 only
    "5090": {"11", "12", "13"},       # Biology: Paper 1 only
    "2281": {"11", "12", "13"},       # Economics: Paper 1 only — 30 questions
    "2210": set(),                    # Computer Science: no MCQ
    "7110": set(),                    # Principles of Accounts: no MCQ
}

# ── MCQ QUESTION COUNT (advisory; provenance receipt D4) ──
MCQ_QUESTION_COUNT: Dict[str, Dict[str, int]] = {
    "9700": {"11": 40, "12": 40, "13": 40},
    "9701": {"11": 40, "12": 40, "13": 40},
    "9702": {"11": 40, "12": 40, "13": 40},
    "9708": {"11": 30, "12": 30, "13": 30},
    # 9990 intentionally absent (RS-13 resolution receipt).
    "0610": {"11": 40, "12": 40, "13": 40, "21": 40, "22": 40, "23": 40},
    "0620": {"11": 40, "12": 40, "13": 40, "21": 40, "22": 40, "23": 40},
    "0625": {"11": 40, "12": 40, "13": 40, "21": 40, "22": 40, "23": 40},
    "0455": {"11": 30, "12": 30, "13": 30},
    "5054": {"11": 40, "12": 40, "13": 40},
    "5070": {"11": 40, "12": 40, "13": 40},
    "5090": {"11": 40, "12": 40, "13": 40},
    "2281": {"11": 30, "12": 30, "13": 30},
}


def is_mcq(syllabus_code: str, component: str) -> bool:
    """Single authoritative MCQ check (RULE 1). The ONLY function that
    determines MCQ status anywhere in the codebase."""
    components = MCQ_COMPONENTS.get(str(syllabus_code), set())
    return str(component) in components


def get_expected_question_count(syllabus_code: str, component: str) -> int:
    """Expected MCQ question count (advisory — see receipt D4).
    Returns 40 as default if not specified. Only meaningful for MCQ
    components."""
    counts = MCQ_QUESTION_COUNT.get(str(syllabus_code), {})
    return counts.get(str(component), 40)


def get_all_mcq_codes() -> Dict[str, Set[str]]:
    """Return full MCQ registry for inspection (codes that have MCQ papers)."""
    return {code: comps for code, comps in MCQ_COMPONENTS.items() if comps}
