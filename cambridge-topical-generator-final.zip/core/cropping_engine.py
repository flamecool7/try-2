"""
Cropping Engine - SHARED UNIVERSAL COMPONENT - GOLD-STANDARD COPY

ABSOLUTE RULE: DO NOT BREAK CROPPING - This is EXACT COPY of updated Chemistry generator
Reference: original_reference/cambridge_qb/question_split.py + multipage_optimizer.py + chemistry_reference.py

This engine preserves ALL improvements from updated Chemistry generator:
- Question boundary detection (multi-pattern + typography/margin + sequence gap healing)
- Question-number detection (1, 1., 1 (a), Question 1, Q1, with LEFT_MARGIN check)
- Multi-page question handling (continuation detection, page ordering, stitching)
- Page ordering (sorted by page and Y, continuation segments)
- Question continuation detection (_page_has_continuation_above)
- Empty-space reduction (find_whitespace_cut with protected bands, dark ink profile)
- Horizontal alignment preservation (original paper alignment, no reflow, no centering)
- Original paper alignment preservation (exact horizontal positions, indentation)
- Width handling (TARGET_WIDTH = 2280 EXACT, LANCZOS, aspect preserved, validation)
- Horizontal padding (crop_left=100, crop_right=100 approved, plus 100px generous breathing room)
- Barcode exclusion (top boundary at a validated proportional margin above the question line,
  superseding the legacy fixed 5px offset; completely excludes barcodes/headers without clipping text)
- Footer exclusion (bottom 90%+ detection, signature exclusion, administrative info)
- Signature exclusion (copyright, Assessment, Turn over, DO NOT WRITE)
- Back-matter detection (chemistry_reference.py comprehensive: Periodic Table, Data Booklets, Qualitative Analysis, Electrode Potentials, NMR/IR, Bond energies, MF19)
- Periodic-table exclusion (PageClassification is_reference, confidence)
- Data-sheet/reference-information exclusion (identify_removable_pages)
- End-of-paper information exclusion (formula sheets, lined continuation, copyright)
- Question-line boundary handling (page top via structural header/junk recognition + proportional
  font-size margin + raster validation; find_question_bottom_pdf 94% above footer; no tight 5px offsets)
- Multi-page whitespace reduction (trim_page_section 5-10px margin, assemble_multipage_question gap 5-15px)
- Image stitching (assemble_multipage_question vertical stitch with white background, max width normalization)
- WebP conversion (save_webp quality 88-95 method 6, RGB conversion)
- Image quality settings (webp_quality 88, LANCZOS resampling)
- Dimension handling (enforce_exact_width_2280 validation)
- Error detection (QuestionQCValidator: content sufficiency, diagram completeness, reference contamination, boundary sanity)
- Crop validation (validate_content_preservation, find_content_bbox, is_blank_image)
- Crop retry logic (fallback fixed_crop_page, adaptive_crop_page with protected bands)
- Automatic correction mechanisms (sequence gap healing, safe whitespace cut fallback with
  adaptive top guard, replacing the legacy 5px fallback)

Gold-standard values (from original_reference/cambridge_qb/config.py):
- crop_top = 251, crop_bottom = 231, crop_left = 100, crop_right = 100
- TARGET_WIDTH = 2280 (EXACT)
- FORMULA_SHEET_MAX_PAGE = 3
- LEFT_MARGIN = 0.22, LEFT_MARGIN_STRICT = 0.15, Q_START_TOP_BAND_PT = 30.0, BOTTOM_SKIP = 0.90

This is universal component used by every subject (IGCSE + A-Level).
Chemistry-specific classification NOT copied - only cropping mechanism.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass
from PIL import Image
import io
import os
import shutil
import tempfile

# Import gold-standard components from original_reference
# Add original_reference to path
sys.path.insert(0, str(Path(__file__).parent.parent / "original_reference"))

# --- RS-12 (2026-08-11): page-classifier wire-up (APPROVED decision D1) -------
# The gold package's question_split/quality_control do
# `from .chemistry_reference import ...`; unshimmed that binds the PRISTINE
# original copy, which silently discards sparse question pages in the last six
# pages of a paper (`or is_terminal` fallback, conf=0.80) and knows nothing of
# MCQ option-line structure — 14 real questions of 0620_s16_qp_22 were lost
# this way. Pre-seed sys.modules so every cambridge_qb relative import of
# chemistry_reference resolves to the MAINTAINED core classifier instead.
# original_reference/ stays byte-pristine. MUST precede every cambridge_qb
# import in this process.
try:
    from core import chemistry_reference as _core_chemistry_reference
except ImportError:  # pragma: no cover - defensive file-path fallback
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location(
        "core.chemistry_reference", Path(__file__).parent / "chemistry_reference.py")
    _core_chemistry_reference = _ilu.module_from_spec(_spec)
    sys.modules.setdefault("core.chemistry_reference", _core_chemistry_reference)
    _spec.loader.exec_module(_core_chemistry_reference)
sys.modules["cambridge_qb.chemistry_reference"] = _core_chemistry_reference

try:
    from cambridge_qb.config import Config as GoldConfig
    from cambridge_qb import question_split as gold_question_split
    from cambridge_qb.chemistry_reference import identify_removable_pages
    from cambridge_qb.multipage_optimizer import (
        assemble_multipage_question as gold_assemble,
        enforce_exact_width_2280 as gold_enforce_2280,
        find_content_bbox as gold_find_bbox,
        trim_page_section as gold_trim,
    )
    from cambridge_qb.pdf_io import detect_footer_y, detect_header_y, is_blank_image, page_is_usable
    from cambridge_qb.quality_control import QuestionQCValidator
    GOLD_AVAILABLE = True
except Exception as e:
    # Fallback if gold standard not available (should not happen after integration)
    print(f"[CroppingEngine] Gold-standard import failed: {e}, using fallback")
    GOLD_AVAILABLE = False
    try:
        import fitz
        HAS_FITZ = True
    except ImportError:
        HAS_FITZ = False

# Fallback fitz check
try:
    import fitz
    HAS_FITZ = True
except ImportError:
    try:
        import pymupdf as fitz
        HAS_FITZ = True
    except ImportError:
        HAS_FITZ = False

@dataclass
class QuestionBoundary:
    question_number: str
    number_int: int
    page_num: int
    y_start: float
    y_end: Optional[float]
    x_start: float
    x_end: float
    text_snippet: str
    is_continued: bool = False
    continues_from_previous: bool = False

@dataclass
class CroppedQuestion:
    question_number: str
    number_int: int
    paper_code: str
    images: List[Image.Image]
    assembled_image: Optional[Image.Image] = None
    text: str = ""
    marks: int = 0
    pages: List[int] = None
    # F4 (defect 4): gold QC verdict propagated, never dropped by the adapter.
    needs_review: bool = False
    qc_reasons: List[str] = None

def _page_scratch_root():
    """Preferred base for per-paper page-render scratch dirs (U2).

    /dev/shm when usable -> intermediate page webps live on RAM-backed tmpfs =
    zero real disk I/O. Falls back to system temp (previous behavior) elsewhere.
    Returns None to let tempfile use the default location.
    """
    shm = Path("/dev/shm")
    try:
        if shm.is_dir() and os.access(shm, os.W_OK):
            with tempfile.NamedTemporaryFile(prefix=".qp_probe_", dir=str(shm)):
                pass
            return shm
    except Exception:
        pass
    return None


class CroppingEngine:
    """
    Universal cropping engine - EXACT COPY of gold-standard Chemistry generator
    Adapted generically for all subjects per requirement 14-15: no hard-coded Chemistry assumptions,
    subject-specific rules come from configuration, not hard-coded.

    Gold-standard behavior preserved:
    - Question detection via _detect_markers with multi-pattern + typography/margin + gap healing
    - Adaptive guard above question line (adaptive_crop_page: validated proportional top margin,
      ~0.45x median font size, replacing the legacy top_pdf - 5px tight offset)
    - Barcode/page-number exclusion via structural junk recognition + raster-validated top boundary
      (no blind 55pt constant, no 58pt floor, no ink slicing)
    - Footer exclusion via find_question_bottom_pdf y<0.94*h and footer keywords
    - Back-matter exclusion via chemistry_reference.identify_removable_pages (Periodic Table, Data Sheets, etc.)
    - Multi-page via build_question_segments with whitespace cut finder
    - Whitespace reduction via trim_page_section 5-10px margin
    - Assembly via assemble_multipage_question gap 5-15px
    - Width 2280 exact via enforce_exact_width_2280 LANCZOS
    - WebP via save_webp quality 88-95
    """

    def __init__(self, target_width=2280, quality=95, dpi=300):
        # Use gold-standard approved values
        self.target_width = 2280  # EXACT per gold-standard
        self.quality = quality  # Will use 88 per gold-standard config but allow override
        self.dpi = min(dpi, 150)
        self.last_confident = None   # F4: paper-level gold verdict (None = not run)
        self.last_error = None       # F5: fail-closed reason when set

        # Gold-standard config values (from original_reference/cambridge_qb/config.py)
        self.GOLD_CROP_TOP = 251
        self.GOLD_CROP_BOTTOM = 231
        self.GOLD_CROP_LEFT = 100
        self.GOLD_CROP_RIGHT = 100
        self.GOLD_FORMULA_SHEET_MAX_PAGE = 3

        # Additional approved values
        self.BARCODE_TOP_FRACTION = 0.08
        self.FOOTER_BOTTOM_FRACTION = 0.10
        self.HORIZONTAL_EXPANSION_PX = 18  # For fallback, but gold uses 100px
        self.PX_ADJUSTMENT_ABOVE = 5  # legacy constant retained for API compat; superseded by the
        # proportional raster-validated top guard inside question_split.adaptive_crop_page
        self.WHITESPACE_THRESHOLD = 240

        # Patterns (gold-standard uses LEFT_MARGIN 0.22, STRICT 0.15)
        self.QUESTION_START_PATTERN = re.compile(
            r'^\s*(?:Question\s*)?(?:Q\s*)?(\d{1,2})\s*(?:[.\(\[]|(?:\s+\())?',
            re.IGNORECASE | re.MULTILINE
        )
        self.MAIN_QUESTION_PATTERN = re.compile(
            r'^\s*(?:Q\s*)?(\d{1,2})\s+',
            re.MULTILINE
        )

        self.FOOTER_KEYWORDS = [
            "©", "UCLES", "Turn over", "TURN OVER", "Page",
            "DO NOT WRITE", "Electronic calculators", "READ THESE INSTRUCTIONS",
        ]
        self.REFERENCE_KEYWORDS = [
            "Periodic Table", "PERIODIC TABLE", "Data Sheet", "DATA SHEET",
            "Atomic masses", "Atomic number", "relative atomic mass",
        ]

    def is_reference_page(self, page_text: str) -> bool:
        """Reference detection - delegates to gold-standard chemistry_reference if available - No content cutoffs"""
        if GOLD_AVAILABLE:
            # Gold-standard has comprehensive detection via identify_removable_pages
            # For fallback, we use simple keyword check below - preserves no cutoff behavior
            # Zero content loss, no cutoffs - preserves original exam content
            pass  # Intentional: gold-standard handles reference removal in split_questions, fallback uses keyword check below - no cutoff
        text = page_text[:2000]
        for kw in self.REFERENCE_KEYWORDS:
            if kw.lower() in text.lower():
                if any(x in text for x in ["Periodic Table", "DATA SHEET", "Atomic"]):
                    if not self.QUESTION_START_PATTERN.search(text):
                        return True
        return False

    def _extract_marks(self, text: str) -> int:
        pattern = re.compile(r'\[(\d+)\s*(?:marks?)?\]', re.IGNORECASE)
        marks = pattern.findall(text)
        total = sum(int(m) for m in marks) if marks else 0
        return total

    def process_paper(self, pdf_path: Path) -> List[CroppedQuestion]:
        """
        Full pipeline - GOLD-STANDARD EXACT COPY adapted generically
        Uses original_reference/cambridge_qb/question_split.split_questions directly
        This ensures 100% same cropping logic, algorithms, measurements, boundaries
        """
        pdf_path = Path(pdf_path)
        print(f"[CroppingEngine] Processing {pdf_path.name} with GOLD-STANDARD engine")

        if not HAS_FITZ:
            # FAIL-CLOSED (Overseer confidence-gate spec, defect 5): fabricating
            # questions is forbidden; no crops + loud error state instead.
            self.last_error = "PyMuPDF unavailable — cannot crop (fail-closed)"
            print(f"[CroppingEngine] ❌ {self.last_error} ({pdf_path.name})")
            return []

        # Use gold-standard if available - EXACT COPY, no redesign
        if GOLD_AVAILABLE:
            try:
                # Gold-standard config with approved crop values
                gold_cfg = GoldConfig()
                gold_cfg.dpi = self.dpi
                gold_cfg.webp_quality = self.quality
                # Use approved crop values from gold-standard config.py
                gold_cfg.crop_top = self.GOLD_CROP_TOP
                gold_cfg.crop_bottom = self.GOLD_CROP_BOTTOM
                gold_cfg.crop_left = self.GOLD_CROP_LEFT
                gold_cfg.crop_right = self.GOLD_CROP_RIGHT
                gold_cfg.formula_sheet_max_page = self.GOLD_FORMULA_SHEET_MAX_PAGE
                # Syllabus code for reference detection (generic, not hard-coded Chemistry)
                # Use code from filename to allow subject-specific reference handling via config
                # For Chemistry, chemistry_reference will detect Periodic Table etc.
                # For other subjects, it will not detect chemistry reference, so no removal (correct)
                try:
                    from core.paper_identifier import parse_paper_filename
                    info = parse_paper_filename(pdf_path)
                    if info:
                        gold_cfg.syllabus_code = info.syllabus_code
                except Exception as e:
                    gold_cfg.syllabus_code = ""

                # Call gold-standard split_questions - EXACT COPY of Chemistry generator's cropping mechanism
                # This includes ALL improvements: boundary detection, number detection, multi-page handling,
                # page ordering, continuation detection, empty-space reduction, alignment preservation,
                # width handling, horizontal padding, barcode/footer/signature/back-matter exclusion, etc.
                # U2 (efficiency overhaul): the LOCKED gold-standard splitter renders
                # every page to a webp scratch dir and NEVER deletes it (no rmtree
                # exists in question_split.py). Supply an owned scratch dir -- RAM
                # backed when possible -- and always remove it here. Splitter byte
                # untouched; crop logic, DPI and webp quality/settings untouched.
                scratch_root = _page_scratch_root()
                webp_dir = Path(tempfile.mkdtemp(prefix="qp_pages_", dir=scratch_root))
                print(f"[CroppingEngine] page-render scratch: {webp_dir}"
                      f" (ramdisk={'yes' if scratch_root is not None else 'no'})")
                try:
                    questions, confident = gold_question_split.split_questions(
                        pdf_path,
                        dpi=gold_cfg.dpi,
                        paper_code=pdf_path.stem,
                        cfg=gold_cfg,
                        webp_dir=webp_dir,
                    )
                finally:
                    shutil.rmtree(webp_dir, ignore_errors=True)

                print(f"[CroppingEngine] Gold-standard extracted {len(questions)} questions (confident={confident}) from {pdf_path.name}")
                self.last_confident = confident
                if not confident:
                    print(f"[CroppingEngine] ⚠️ LOW-CONFIDENCE split for {pdf_path.name} — flagged for REVIEW; runner gate decides completion")

                # Convert gold-standard Question objects to our CroppedQuestion
                results = []
                for q in questions:
                    # Gold-standard Question has images already 2280px wide via enforce_exact_width_2280
                    # per gold-standard multipage_optimizer
                    if not q.images:
                        continue

                    # Ensure exactly 2280px width (gold-standard already does enforce_exact_width_2280, but verify)
                    # Use gold-standard enforce_exact_width_2280 for consistency
                    try:
                        final_images = [gold_enforce_2280(im, target_width=self.target_width) for im in q.images]
                    except Exception as e:
                        # Fallback to our resize if gold enforce fails
                        final_images = [self.resize_to_target_width(im) for im in q.images]

                    # Gold ALWAYS returns ONE fully-stitched image per question
                    # (its crop_page_segments assembles ALL page segments via
                    # assemble_multipage_question + the 20px raster re-anchor) —
                    # defect-3 claim of dropped continuation pages was audited
                    # FALSE (approved artifacts e.g. 2280x12422 4-page Q1).
                    # Defensive: len>1 means a future gold change — stitch
                    # loudly with the LOCKED assembler, never drop a segment.
                    if len(final_images) == 1:
                        assembled = final_images[0]
                    else:
                        print(f"[CroppingEngine] NOTE: Q{q.question_number} has {len(final_images)} unstitched segments — assembling via locked gold assembler (no segment dropped)")
                        assembled = gold_assemble(final_images, target_width=self.target_width)

                    try:
                        number_int = int(q.question_number)
                    except Exception as e:
                        try:
                            number_int = int(''.join(filter(str.isdigit, str(q.question_number))) or 0)
                        except Exception as e:
                            number_int = 0

                    text = q.text if hasattr(q, 'text') else ""
                    marks = self._extract_marks(text)

                    # Pages from page_segments if available
                    pages = []
                    if hasattr(q, 'page_segments') and q.page_segments:
                        pages = [seg.get('page', 0) - 1 for seg in q.page_segments if isinstance(seg, dict)]

                    results.append(CroppedQuestion(
                        question_number=f"Q{number_int}" if number_int else f"Q{q.question_number}",
                        number_int=number_int,
                        paper_code=pdf_path.stem,
                        images=final_images,
                        assembled_image=assembled,
                        text=text,
                        marks=marks,
                        pages=pages,
                        needs_review=bool(getattr(q, "needs_review", False)),
                        qc_reasons=list(getattr(q, "review_reasons", []) or []),
                    ))

                print(f"[CroppingEngine] Converted {len(results)} questions to universal format")
                return results

            except Exception as e:
                # FAIL-CLOSED (defect 5): never fabricate; surface and stop.
                print(f"[CroppingEngine] ❌ Gold-standard processing failed for {pdf_path.name}: {e}")
                import traceback
                traceback.print_exc()
                self.last_error = f"gold-standard crop failed: {e}"
                print("[CroppingEngine] fail-closed: returning 0 questions; paper must NOT be marked complete")
                return []

        # Gold engine not importable: fail closed, never fabricate (defect 5).
        self.last_error = "gold engine not importable — fail-closed"
        print(f"[CroppingEngine] ❌ {self.last_error} ({pdf_path.name})")
        return []

    def resize_to_target_width(self, image: Image.Image) -> Image.Image:
        """2280px final width requirement - no distortion - EXACT COPY of gold-standard enforce_exact_width_2280 logic - No cutoff"""
        if GOLD_AVAILABLE:
            try:
                return gold_enforce_2280(image, target_width=self.target_width)
            except Exception as e:
                print(f"[CroppingEngine] Resize via gold-standard failed: {e}, using LANCZOS fallback - no cutoff")
        # Fallback LANCZOS - preserves no cutoff, no distortion
        w, h = image.size
        if w == self.target_width:
            return image
        aspect = h / w
        new_h = int(self.target_width * aspect)
        return image.resize((self.target_width, new_h), Image.LANCZOS)

