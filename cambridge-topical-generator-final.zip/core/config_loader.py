"""
Config Loader - Universal component supporting IGCSE + A-Level with syllabus-year awareness

Architecture:
Level → Subject → Syllabus Code → Syllabus Year → Topic Configuration

Supports:
- Official Cambridge syllabus as source of truth
- Major topics = high-level official structure
- Detailed topics = sub-topics
- Mapping detailed -> major preserved from official hierarchy
- Syllabus year awareness (2025, 2026, 2027, etc.)
- Validation before allowing config to be used
- No mixing IGCSE/A-Level

Structure:
subjects/
├── IGCSE/
│   ├── Chemistry_0620/
│   ├── Computer_Science_0478/
│   └── ...
└── A-Level/
    ├── Chemistry_9701/
    ├── Computer_Science_9618/
    └── ...

And year-aware:
subjects/A-Level/Chemistry_9701/
├── config.json (default, latest)
├── 2025/config.json (if syllabus differs)
├── 2026/config.json
└── 2027+/config.json

If paper year matches historical config, use it.
"""

import copy
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

SUBJECTS_ROOT = Path(__file__).parent.parent / "subjects"

# Complete code map including all required subjects per prompt
KNOWN_CODE_MAP = {
    # IGCSE Required per prompt
    "0620": "Chemistry_0620",
    "0625": "Physics_0625",
    "0610": "Biology_0610",
    "0580": "Mathematics_0580",
    "0606": "Additional_Mathematics_0606",
    "0478": "Computer_Science_0478",
    "0455": "Economics_0455",
    "0450": "Business_Studies_0450",
    "0475": "Literature_in_English_0475",
    "0470": "History_0470",
    "0417": "ICT_0417",
    "0460": "Geography_0460",
    # A-Level Required per prompt
    "9701": "Chemistry_9701",
    "9702": "Physics_9702",
    "9709": "Mathematics_9709",
    "9231": "Further_Mathematics_9231",
    "9618": "Computer_Science_9618",
    "9708": "Economics_9708",
    "9609": "Business_9609",
    "9695": "English_Literature_9695",
    "9489": "History_9489",
    "9626": "Information_Technology_9626",
    "9696": "Geography_9696",
    # Extra
    "9700": "Biology_9700",
}

LEVEL_BY_CODE_PREFIX = {
    "04": "IGCSE",
    "05": "IGCSE",
    "06": "IGCSE",
    "09": "A-Level",
    "96": "A-Level",
    "97": "A-Level",
    "92": "A-Level",
}

def infer_level_from_code(syllabus_code: str) -> str:
    code = str(syllabus_code)
    for prefix, level in LEVEL_BY_CODE_PREFIX.items():
        if code.startswith(prefix):
            return level
    return "A-Level" if code.startswith("9") else "IGCSE"

class SubjectConfig:
    def __init__(self, data: dict, config_path: Optional[Path] = None):
        self.data = data
        self.config_path = config_path
        self.subject: str = data["subject"]
        self.syllabus_code: str = data["syllabus_code"]
        self.board: str = data.get("board", "CIE")
        self.level: str = data.get("level", infer_level_from_code(self.syllabus_code))
        self.major_topics: List[str] = data["major_topics"]
        self.detailed_topics: List[str] = data["detailed_topics"]
        self.mapping: Dict[str, str] = data["mapping"]
        self.classification_keywords: Dict[str, List[str]] = data.get("classification_keywords", {})
        self.specialization_weights: Dict[str, float] = data.get("specialization_weights", {})
        self.syllabus_order: Dict[str, int] = data.get("syllabus_order", {})
        self.folder_naming: str = data.get("folder_naming", "Pascal_Snake")
        # New: syllabus year awareness
        self.syllabus_years: List[str] = data.get("syllabus_years", ["2026"])
        self.official_source: str = data.get("official_source", "")
        self.version: str = data.get("version", "2026")
        self.year: Optional[str] = data.get("year")  # For year-specific configs
        # A syllabus edition is verified when the paper year is declared in
        # syllabus_years.  Unknown historical/future years may still be
        # processed in the explicit review-required mode requested by the
        # maintainer: crops and evidence are preserved, but the bundle cannot
        # be marked complete against an unverified syllabus edition.
        self.historical_year_policy: str = data.get(
            "historical_year_policy", "review_required"
        )
        self.requested_year: Optional[str] = None
        self.year_verified: bool = True
        self.year_review_required: bool = False

        if self.level not in ["IGCSE", "A-Level"]:
            self.level = infer_level_from_code(self.syllabus_code)

    def get_major_for_detailed(self, detailed: str) -> str:
        return self.mapping.get(detailed)

    def validate(self) -> Tuple[bool, List[str]]:
        """
        Configuration validation per requirement 11:
        ✓ Syllabus code exists
        ✓ Level is correct
        ✓ Subject name is correct
        ✓ Major topics exist
        ✓ Every minor topic maps to a major topic
        ✓ No minor topic maps to an invalid major topic
        ✓ No duplicate topic identifiers
        ✓ Folder-safe names exist
        ✓ Syllabus year is defined
        ✓ Configuration is internally consistent
        """
        errors = []

        if not self.syllabus_code or len(self.syllabus_code) != 4:
            errors.append(f"Syllabus code invalid: {self.syllabus_code}")

        if self.level not in ["IGCSE", "A-Level"]:
            errors.append(f"Level invalid: {self.level} must be IGCSE or A-Level")

        if not self.subject or "_" not in self.subject:
            errors.append(f"Subject name invalid: {self.subject} should be like Chemistry_0620")

        # Subject name should contain code
        if self.syllabus_code not in self.subject:
            errors.append(f"Subject {self.subject} does not contain syllabus code {self.syllabus_code}")

        if not self.major_topics or len(self.major_topics) == 0:
            errors.append("Major topics missing")

        if not self.detailed_topics or len(self.detailed_topics) == 0:
            errors.append("Detailed topics missing")

        # Every minor maps to major
        major_set = set(self.major_topics)
        for det in self.detailed_topics:
            if det not in self.mapping:
                errors.append(f"Detailed topic {det} not in mapping")
            else:
                maj = self.mapping[det]
                if maj not in major_set:
                    errors.append(f"Detailed {det} maps to invalid major {maj}")

        # No duplicates
        if len(self.major_topics) != len(set(self.major_topics)):
            errors.append("Duplicate major topics")
        if len(self.detailed_topics) != len(set(self.detailed_topics)):
            errors.append("Duplicate detailed topics")

        # Folder-safe names (no spaces, special chars). Production routing
        # uses major-topic names only: numeric prefixes and decimal syllabus
        # identifiers belong in diagnostics/profile metadata, never folders.
        for name in self.major_topics + self.detailed_topics:
            if " " in name:
                errors.append(f"Space in folder-safe name: {name}")
            if any(c in name for c in ["/", "\\", ":", "*", "?", "\"", "<", ">", "|"]):
                errors.append(f"Invalid char in name: {name}")
            if re.match(r"^\d", name) or re.search(r"\d+\.\d+", name):
                errors.append(f"Numeric/decimal topic identifier not allowed in routing name: {name}")

        # Syllabus year defined
        if not self.syllabus_years or len(self.syllabus_years) == 0:
            errors.append("Syllabus year not defined")
        if self.historical_year_policy not in {"reject", "review_required"}:
            errors.append(
                "historical_year_policy must be 'reject' or 'review_required'"
            )

        # Code vs Level consistency is a hard gate. A profile must not claim
        # A-Level for an IGCSE code or vice versa.
        inferred = infer_level_from_code(self.syllabus_code)
        if inferred != self.level:
            errors.append(
                f"Code/level mismatch: {self.syllabus_code} infers {inferred} "
                f"but config declares {self.level}"
            )

        return len(errors) == 0, errors

# U4 (Overseer efficiency): process-session cache for the whole config tree.
# load_subject_config_by_code_and_level() re-parsed + re-validated EVERY
# config.json on each call. Keyed on (path, mtime_ns, size) fingerprints, so
# on-disk edits invalidate automatically within the session.
_CONFIG_TREE_CACHE: Dict[tuple, Dict[str, 'SubjectConfig']] = {}


def load_all_subject_configs() -> Dict[str, 'SubjectConfig']:
    try:
        key = tuple(sorted(
            (str(p), p.stat().st_mtime_ns, p.stat().st_size)
            for p in SUBJECTS_ROOT.rglob("config.json")
        ))
    except FileNotFoundError:
        key = None
    if key is not None and key in _CONFIG_TREE_CACHE:
        return _CONFIG_TREE_CACHE[key]

    configs: Dict[str, SubjectConfig] = {}
    if not SUBJECTS_ROOT.exists():
        return configs

    for config_path in SUBJECTS_ROOT.rglob("config.json"):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            cfg = SubjectConfig(data, config_path=config_path)

            # Validate before allowing use
            valid, errs = cfg.validate()
            if not valid:
                print(f"[ConfigLoader] Validation FAILED for {config_path}: {errs} - Do not process papers using this config")
                continue

            configs[cfg.subject] = cfg
            configs[cfg.syllabus_code] = cfg

            # Handle year-specific configs: path like subjects/A-Level/Chemistry_9701/2025/config.json
            try:
                relative = config_path.relative_to(SUBJECTS_ROOT)
                parts = relative.parts
                # parts: [Level, Subject, config.json] or [Level, Subject, Year, config.json]
                if len(parts) >= 2:
                    level_folder = parts[0]
                    if level_folder in ["IGCSE", "A-Level"]:
                        configs[f"{level_folder}/{cfg.subject}"] = cfg
                        configs[f"{level_folder}/{cfg.syllabus_code}"] = cfg
                        # If year specific: Level/Subject/Year/config.json
                        if len(parts) >= 3 and parts[2] != "config.json":
                            year_folder = parts[2]
                            # e.g., 2025, 2026
                            if year_folder.isdigit() or year_folder.endswith("+"):
                                configs[f"{level_folder}/{cfg.subject}/{year_folder}"] = cfg
                                configs[f"{level_folder}/{cfg.syllabus_code}/{year_folder}"] = cfg
                                configs[f"{cfg.syllabus_code}/{year_folder}"] = cfg
                # Also handle year in filename: config_2026.json
                if "config_" in config_path.name:
                    year_part = config_path.stem.replace("config_", "")
                    configs[f"{cfg.syllabus_code}/{year_part}"] = cfg

            except Exception as e:
                print(f"[ConfigLoader] Path handling warning for {config_path}: {e}")

        except Exception as e:
            print(f"[ConfigLoader] Failed to load {config_path}: {e}")
            continue

    if key is not None:
        _CONFIG_TREE_CACHE.clear()
        _CONFIG_TREE_CACHE[key] = configs
    return configs

def _normalise_year(year: Optional[str]) -> Optional[str]:
    if year is None or str(year).strip() == "":
        return None
    value = str(year).strip()
    if len(value) == 2 and value.isdigit():
        return "20" + value
    return value


def _bind_requested_year(cfg: SubjectConfig, year: Optional[str]) -> SubjectConfig:
    """Return a per-request config view without mutating the cached config.

    Unknown years are deliberately loud and review-bound.  This lets the
    engine crop/process every available paper year while preventing an
    unverified historical syllabus from being reported as a clean completion.
    """
    bound = copy.copy(cfg)
    requested = _normalise_year(year)
    bound.requested_year = requested
    bound.year = requested
    bound.year_verified = True
    bound.year_review_required = False
    if requested is not None and requested not in [str(y) for y in cfg.syllabus_years]:
        if cfg.historical_year_policy == "review_required":
            bound.year_verified = False
            bound.year_review_required = True
            print(
                f"[ConfigLoader] YEAR UNVERIFIED: {cfg.syllabus_code} exam year "
                f"{requested} is outside declared syllabus editions "
                f"{cfg.syllabus_years}; processing is allowed but the bundle "
                "will remain REVIEW_REQUIRED"
            )
        else:
            return None
    return bound


def load_subject_config_by_name(subject_name: str) -> 'SubjectConfig':
    configs = load_all_subject_configs()
    if subject_name in configs:
        return configs[subject_name]
    if subject_name in KNOWN_CODE_MAP:
        code_name = KNOWN_CODE_MAP[subject_name]
        if code_name in configs:
            return configs[code_name]
    raise ValueError(f"Subject config not found: {subject_name}")

def load_subject_config_by_code_and_level(syllabus_code: str, level: Optional[str] = None, year: Optional[str] = None) -> Optional['SubjectConfig']:
    """Load the profile for a code/level and bind the requested paper year.

    Declared syllabus editions are clean.  Any other four-digit paper year is
    still processable in historical review mode: the engine can crop and
    preserve the paper, but its bundle is forced to REVIEW_REQUIRED until a
    matching official syllabus profile is added.  This is the only safe way to
    support every available historical year without silently claiming that a
    modern taxonomy is identical to an old syllabus.
    """
    configs = load_all_subject_configs()
    requested_year = _normalise_year(year)

    # Exact year-specific config first, if a future profile is supplied.
    if requested_year:
        for key in [
            f"{syllabus_code}/{requested_year}",
            f"{level}/{syllabus_code}/{requested_year}" if level else None,
        ]:
            if key and key in configs:
                cfg = configs[key]
                valid, _ = cfg.validate()
                if valid:
                    return _bind_requested_year(cfg, requested_year)

    cfg = None
    if level:
        key = f"{level}/{syllabus_code}"
        if key in configs:
            cfg = configs[key]

    if cfg is None and syllabus_code in configs:
        cfg = configs[syllabus_code]
        if level and cfg.level != level:
            print(
                f"[ConfigLoader] Level mismatch: requested {level} but code "
                f"{syllabus_code} maps to {cfg.level} - STOP"
            )
            return None

    if cfg is None:
        inferred_level = level or infer_level_from_code(syllabus_code)
        key = f"{inferred_level}/{syllabus_code}"
        cfg = configs.get(key)

    if cfg is None:
        return None
    return _bind_requested_year(cfg, requested_year)

def get_subject_folders():
    configs = load_all_subject_configs()
    subjects = set()
    for key, cfg in configs.items():
        if isinstance(cfg, SubjectConfig) and key == cfg.subject:
            subjects.add(cfg.subject)
    return list(subjects)

def get_configs_by_level(level: str) -> Dict[str, 'SubjectConfig']:
    all_configs = load_all_subject_configs()
    result = {}
    seen_subjects = set()
    for key, cfg in all_configs.items():
        if not isinstance(cfg, SubjectConfig):
            continue
        if cfg.level == level and cfg.subject not in seen_subjects:
            result[cfg.subject] = cfg
            seen_subjects.add(cfg.subject)
    return result

def validate_all_configs() -> Tuple[bool, Dict[str, List[str]]]:
    """Validate all configs per requirement 11"""
    all_configs = load_all_subject_configs()
    seen = set()
    errors_by_subject = {}
    overall_valid = True

    for key, cfg in all_configs.items():
        if not isinstance(cfg, SubjectConfig):
            continue
        # Only validate once per subject
        if cfg.subject in seen:
            continue
        seen.add(cfg.subject)

        valid, errs = cfg.validate()
        if not valid:
            errors_by_subject[cfg.subject] = errs
            overall_valid = False
            print(f"[ConfigLoader] {cfg.subject} validation FAILED: {errs}")
        else:
            print(f"[ConfigLoader] {cfg.subject} validated OK - {len(cfg.major_topics)} majors, {len(cfg.detailed_topics)} detailed, years {cfg.syllabus_years}")

    return overall_valid, errors_by_subject
