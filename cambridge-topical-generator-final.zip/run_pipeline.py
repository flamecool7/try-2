#!/usr/bin/env python3
"""CLI entry point for the batch runner (Overseer batch-infrastructure spec,
Phase 6 — honest port; imports the real core.batch_runner)."""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.batch_runner import run_pipeline


def main():
    parser = argparse.ArgumentParser(
        description="Cambridge Topical Question Bank Generator — batch mode"
    )
    parser.add_argument(
        "--input", required=True,
        help="Input directory containing PDF files"
    )
    parser.add_argument(
        "--output", required=True,
        help="Output directory for question bank"
    )
    parser.add_argument(
        "--topics", default="topics",
        help="(compat) Path to taxonomy JSON files"
    )
    parser.add_argument(
        "--workers", type=int, default=None,
        help="Number of parallel workers (default: cpu//2, RAM-guard clamped)"
    )
    parser.add_argument(
        "--resume", action="store_true", default=True,
        help="Skip already-complete bundles (default: on)"
    )
    parser.add_argument(
        "--retry-failed", action="store_true",
        help="Retry previously failed bundles"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Run preflight only, no processing"
    )
    parser.add_argument(
        "--fetch-missing-ms",
        action="store_true",
        default=False,
        help=(
            "Attempt to fetch missing mark schemes "
            "from pastpapers.co before processing. "
            "Opt-in only. All downloads are verified."
        )
    )
    parser.add_argument(
        "--ms-cache-dir",
        default="ms_cache",
        help=(
            "Directory for cached downloaded MS PDFs. "
            "Default: ms_cache/"
        )
    )
    parser.add_argument(
        "--fetch-dry-run",
        action="store_true",
        default=False,
        help=(
            "Show which MS files would be fetched "
            "without actually downloading anything."
        )
    )
    parser.add_argument(
        "--full-ram", dest="low_ram", action="store_false", default=True,
        help="Use the full production CroppingEngine path (needs a big machine)"
    )

    args = parser.parse_args()

    # MS-fetcher spec (opt-in only, RULE 1: never the default). Runs BEFORE
    # processing so fetched+verified MS files are picked up by this run's
    # get_pending_bundles() files-JOIN. Real module home: core/ms_fetcher.py
    # (the spec's cambridge_qb package does not exist).
    if args.fetch_missing_ms or args.fetch_dry_run:
        from core.ms_fetcher import MissingMSResolver

        db_path = Path(args.output) / "pipeline.sqlite"
        cache_dir = Path(args.ms_cache_dir)

        # Explicit MS retrieval is allowed to bootstrap and refresh its own
        # preflight.  This registers newly supplied QP-only bundles before the
        # resolver queries SQLite, while still doing zero processing.
        print("Refreshing the preflight manifest before resolving missing "
              "mark schemes.")
        run_pipeline(
            pdf_dir=args.input,
            output_dir=args.output,
            topics_dir=args.topics,
            workers=args.workers,
            resume=args.resume,
            retry_failed=args.retry_failed,
            dry_run=True,
            low_ram=args.low_ram,
        )
        if not db_path.exists():
            print("Preflight did not create pipeline.sqlite; mark-scheme "
                  "retrieval is REVIEW_REQUIRED and processing is stopped.")
            return 1

        resolver = MissingMSResolver(
            db_path=db_path,
            cache_dir=cache_dir,
            dry_run=args.fetch_dry_run,
        )
        resolver.resolve_all()

        if args.fetch_dry_run:
            print("Dry run complete. No files downloaded.")
            return

    result = run_pipeline(
        pdf_dir=args.input,
        output_dir=args.output,
        topics_dir=args.topics,
        workers=args.workers,
        resume=args.resume,
        retry_failed=args.retry_failed,
        dry_run=args.dry_run,
        low_ram=args.low_ram,
    )
    if result.get("failed", 0):
        return 1
    if result.get("review_required", 0):
        return 2
    if result.get("audit_passed") is False:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
