# Drive Bulk PDF Extractor - with Document Preview Exporter Integration

Bulk extract/download all PDF files from Google Drive folders while preserving original filenames and folder structure. Works with normal PDFs and **view-only / download-blocked PDFs** using Document Preview Exporter logic.

## Features

- 🔍 **Auto-scan current folder** for PDFs (DOM-based detection)
- 📂 **Recursive scan** via Drive API (uses gapi token from logged-in session) - maintains folder structure
- ⬇️ **Bulk Original Download**: Preserves searchable text, original quality, original filenames
- 🖼️ **Preview Export Mode**: Fallback for view-only blocked files - captures blob: images / canvas previews like [Document Preview Exporter](https://chromewebstore.google.com/detail/document-preview-exporter/npapjbliocdhineglcjkmmmaddpgeono)
- Batch processing (8 files at a time to avoid rate limits)
- Retry failed downloads with alternative URL
- Skips duplicates, maintains `DrivePDFs/` subfolder structure
- Overlay button on Drive UI showing PDF count

## Installation

1. Download this folder, open `chrome://extensions/`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked** and select `google-drive-pdf-extractor-extension` folder
4. Pin the extension for quick access

**Required permissions explained:**
- `activeTab` + `scripting`: Scan Drive folder pages
- `downloads`: Save PDFs to your Downloads folder
- `storage`: Track progress & file lists
- `host_permissions` for `drive.google.com`, `clients6.google.com`, `googleapis.com`: Use Drive APIs with your existing login session. No credentials leave browser.

## How to Use

### Prerequisites
- Open Google Chrome
- Log in to Google Drive if prompted - if authentication required, STOP and let user login (as per instructions)
- Install **Document Preview Exporter** (optional but recommended for blocked files): https://chromewebstore.google.com/detail/document-preview-exporter/npapjbliocdhineglcjkmmmaddpgeono

### Step-by-Step

1. **Navigate** to your Google Drive folder: `https://drive.google.com/drive/folders/FOLDER_ID`
2. **Wait** for folder contents to fully load (scroll to bottom if hundreds of files)
3. Click the extension icon -> **🔍 Scan Current Folder for PDFs**
   - For subfolders: **📂 Scan Recursively**
4. Check counts: extension shows found PDFs & folders
5. **Choose download mode:**

   **Option A - Original Quality (Recommended):**
   - Preserves original filenames exactly, searchable text
   - Click **⬇️ Bulk Download Original PDFs**
   - Files saved to `~/Downloads/DrivePDFs/` with structure preserved if checked
   - If folder structure enabled, paths like `SubfolderA/document.pdf` are preserved

   **Option B - Preview Export (for view-only blocked PDFs):**
   - Use when download is blocked / view-only
   - Either:
     - Scan folder first then click **🖼️ Export via Preview** (opens each PDF in background tab and captures)
     - OR open a single PDF preview (`/file/d/ID/view`), scroll to load all pages fully, then click extension's preview export OR use Document Preview Exporter icon directly
   - Output is image-based PDF (no selectable text) but works when original is blocked
   - Based on Document Preview Exporter logic: captures `blob:https://drive.google.com/` images and canvas elements

6. **Monitor** log in popup, and Chrome's download shelf
7. **Handle failures:** If a download fails, it retries automatically via `drive.usercontent.google.com`. Check popup's failed count. Manually retry failed files listed.

### Tips for Hundreds/Thousands of PDFs

- The extension processes in batches of 8 to avoid rate limiting (as per your instruction: process in batches)
- For very large folders (>500 files), scroll slowly to bottom to force Drive to load all files before scanning
- Recursive scan uses Drive API v3 with gapi token - if token not available (rare), fallback is DOM scanning: navigate into each subfolder manually and scan
- Do not attempt everything simultaneously - the extension already batches

### Preserving Filenames & Structure

- `Preserve folder structure` checked (default): saves as `DrivePDFs/ParentFolder/Subfolder/file.pdf`
- `Preserve original filenames` checked (default): keeps exact name from Drive, no renaming
- No compression, no conversion (except preview mode which is image-based by necessity for blocked files)
- Duplicate check: `conflictAction: uniquify` - if file already exists, Chrome adds `(1)` instead of overwriting; to avoid duplicates, clear Downloads/DrivePDFs first

### About Document Preview Exporter Integration

This extension **includes** the same core logic as Document Preview Exporter:
- Scans for `blob:https://drive.google.com/` images (Google's PDF page renderer)
- Supports new canvas-based rendering (Drive's recent UI)
- Uses jsPDF to assemble PNGs into PDF
- Also respects `zoom level` tip: zoom Drive preview to 100%+ before export for higher resolution (Original Size mode)

You can still use Document Preview Exporter separately for single files - our extension adds bulk folder handling around it.

## Files Included

- `manifest.json`: MV3 config
- `popup.html/js`: UI & batch controls
- `content.js`: Core scanner + preview exporter (like Document Preview Exporter)
- `background.js`: Download queue manager
- `lib/jspdf.umd.min.js`: PDF generation for preview mode
- `console-scripts/`: Standalone console/bookmarklet alternatives
- `python-alternative/`: gdown-based bulk downloader if you have folder ID

## Troubleshooting

**No PDFs found but folder has PDFs:**
- Wait longer for Drive to load, scroll down, list view vs grid view, retry scan
- Try API recursive scan
- Check if files are actually Google Docs? Convert to PDF first if needed

**Download blocked / 403 / virus scan warning:**
- Use Preview Export mode
- Or right-click file in Drive -> Make a copy -> Download copy

**Authentication:**
- If Drive asks for login, stop automation and login manually, then reload extension

**Extension requires permissions:**
- Chrome will ask for `downloads` permission on first bulk download - Allow
- If download blocked as multiple files, click download shelf -> Allow multiple downloads from drive.google.com

## Privacy

No data leaves your browser. No external server. Uses your existing Google session cookie/token to call Drive API. Downloads go directly to your computer.

## Final Report (generated by extension after run)

The popup tracks:
- Total PDFs found
- Total successfully extracted/downloaded
- Total failed + names
- Local location: `Downloads/DrivePDFs/`

For compliance with your instructions, the extension logs all failed filenames and never claims success without actual download start.

---

### Alternative: If you cannot install extension, use console script

See `console-scripts/bulk-drive-pdf-downloader.js` - paste into DevTools console on Drive folder page.

### Alternative: Python gdown script

See `python-alternative/` for bulk download via ID list if folder is publicly shared.
