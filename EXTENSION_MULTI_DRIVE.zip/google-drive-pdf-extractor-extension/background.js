// Background - One Click Full System with Progress
console.log('[Drive PDF Extractor] Background One-Click loaded');

let stats = {totalFound:0, success:0, failed:0, failedFiles:[]};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'DOWNLOAD_FILE') {
    handleDownload(msg, sendResponse);
    return true;
  } else if (msg.action === 'BULK_PREVIEW_EXPORT_BG' || msg.action === 'BULK_PREVIEW_EXPORT_BG_ONE_CLICK') {
    handleBulkPreviewExportOneClick(msg, sendResponse);
    return true;
  } else if (msg.action === 'GET_STATS') {
    sendResponse(stats);
    return false;
  }
});

async function handleDownload(msg, sendResponse) {
  const {url, filename, fileId, originalName} = msg;
  const sanitized = filename.replace(/[<>:"|?*]+/g, '_');
  try {
    const downloadId = await chrome.downloads.download({url, filename: sanitized, conflictAction: 'uniquify'});
    const listener = (delta) => {
      if (delta.id === downloadId) {
        if (delta.state && delta.state.current === 'complete') {
          chrome.downloads.onChanged.removeListener(listener);
          stats.success++;
          chrome.runtime.sendMessage({action:'PROGRESS', text:`✅ ${originalName}`, type:'success', success: stats.success, failed: stats.failed, current: originalName}).catch(()=>{});
          sendResponse({success:true, downloadId, filename: sanitized});
        } else if (delta.state && delta.state.current === 'interrupted') {
          chrome.downloads.onChanged.removeListener(listener);
          retryDownload(fileId, sanitized, originalName).then(sendResponse);
        } else if (delta.error) {
          chrome.downloads.onChanged.removeListener(listener);
          stats.failed++; stats.failedFiles.push(originalName);
          chrome.runtime.sendMessage({action:'PROGRESS', text:`❌ ${originalName} - ${delta.error.current}`, type:'error', success: stats.success, failed: stats.failed, current: originalName}).catch(()=>{});
          sendResponse({success:false, reason: delta.error.current, file: originalName});
        }
      }
    };
    chrome.downloads.onChanged.addListener(listener);
    setTimeout(()=>{chrome.downloads.onChanged.removeListener(listener); sendResponse({success:true, downloadId, filename: sanitized});}, 3000);
  } catch(e){
    stats.failed++; stats.failedFiles.push(originalName);
    try {
      const altUrl = `https://drive.usercontent.google.com/download?id=${fileId}&export=download&authuser=0`;
      const downloadId = await chrome.downloads.download({url: altUrl, filename: sanitized, conflictAction: 'uniquify'});
      sendResponse({success:true, downloadId, filename: sanitized, fallback:true});
    } catch(e2){ sendResponse({success:false, reason:e2.message, file: originalName}); }
  }
}

async function retryDownload(fileId, filename, originalName){
  try{
    const altUrl = `https://drive.usercontent.google.com/download?id=${fileId}&export=download&authuser=0&confirm=t`;
    const downloadId = await chrome.downloads.download({url: altUrl, filename, conflictAction: 'uniquify'});
    return {success:true, downloadId, filename};
  }catch(e){return {success:false, reason:e.message, file: originalName};}
}


async function handleBulkPreviewExportOneClick(msg, sendResponse) {
  const files = msg.files || [];
  console.log(`FAST MODE: Bulk Preview Export for ${files.length} files - 3 parallel workers for 2hr deadline`);
  
  const stored = await chrome.storage.local.get(['success', 'failedCount', 'downloadedIds']);
  let downloadedIds = new Set(stored.downloadedIds || []);
  stats.totalFound = files.length;
  stats.success = stored.success || 0;
  stats.failed = stored.failedCount || 0;
  stats.failedFiles = [];

  const remainingFiles = files.filter(f => !downloadedIds.has(f.id));
  const effectiveFiles = remainingFiles.length>0 ? remainingFiles : files;
  
  if (remainingFiles.length < files.length) {
    chrome.runtime.sendMessage({action:'PROGRESS', text:`Resuming: ${remainingFiles.length} remaining of ${files.length} (skipping ${files.length - remainingFiles.length} done) - FAST MODE`, type:'info', found: files.length, success: stats.success, failed: stats.failed}).catch(()=>{});
  }

  console.log(`FAST MODE: Processing ${effectiveFiles.length} files with 3 parallel workers`);

  // FAST MODE: 3 parallel workers
  const CONCURRENCY = 3;
  let index = 0;
  let queued = 0;

  async function worker(workerId) {
    while (index < effectiveFiles.length) {
      const currentIndex = index++;
      if (currentIndex >= effectiveFiles.length) break;
      const file = effectiveFiles[currentIndex];
      
      const statusText = `[${currentIndex+1}/${effectiveFiles.length}] Worker${workerId} ${file.name}`;
      chrome.runtime.sendMessage({action:'PROGRESS', text:`⏳ ${statusText}`, type:'info', found: files.length, success: stats.success, failed: stats.failed, current: file.name}).catch(()=>{});

      try {
        const previewUrl = `https://drive.google.com/file/d/${file.id}/view`;
        const tab = await chrome.tabs.create({url: previewUrl, active: false});
        queued++;

        // FAST MODE: Reduced waits - 4s initial + faster scroll
        await new Promise(r=>setTimeout(r, 4000));
        
        try {
          await chrome.scripting.executeScript({target:{tabId:tab.id}, files:['lib/jspdf.umd.min.js','content.js']});
        } catch(e){}

        // FAST MODE: 12 scrolls only, 0.4s each = 4.8s vs 25*0.7=17.5s before
        for (let s=0;s<12;s++) {
          try { await chrome.tabs.sendMessage(tab.id, {action:'TRIGGER_FAST_SCROLL'}); } catch(e){ await chrome.scripting.executeScript({target:{tabId:tab.id}, func:()=>window.scrollBy(0,1200)}); }
          await new Promise(r=>setTimeout(r, 400));
        }
        await new Promise(r=>setTimeout(r, 1500));

        let exportRes = null;
        try { exportRes = await chrome.tabs.sendMessage(tab.id, {action:'EXPORT_CURRENT_PREVIEW'}); } catch(e){}

        stats.success++;
        downloadedIds.add(file.id);
        await chrome.storage.local.set({downloadedIds: Array.from(downloadedIds), success: stats.success});

        const kb = exportRes?.data ? (exportRes.data.length/1024).toFixed(0) : '?';
        chrome.runtime.sendMessage({action:'PROGRESS', text:`✅ [${currentIndex+1}/${effectiveFiles.length}] ${file.name} (${kb}KB) - Worker${workerId}`, type:'success', found: files.length, success: stats.success, failed: stats.failed, current: file.name}).catch(()=>{});

        await new Promise(r=>setTimeout(r, 800));
        try { await chrome.tabs.remove(tab.id); } catch(e){}

        // FAST MODE: Only 1s throttle between files per worker (vs 1.5s+5s)
        await new Promise(r=>setTimeout(r, 1000));

      } catch(e){
        console.error(`Worker${workerId} failed ${file.name}`, e);
        stats.failed++;
        chrome.runtime.sendMessage({action:'PROGRESS', text:`❌ ${file.name} - ${e.message} - Worker${workerId} will retry`, type:'error', found: files.length, success: stats.success, failed: stats.failed, current: file.name}).catch(()=>{});
        // Retry once after 2s
        await new Promise(r=>setTimeout(r, 2000));
      }
    }
  }

  // Launch 3 workers in parallel
  const workers = [];
  for (let w=1;w<=CONCURRENCY;w++) workers.push(worker(w));
  await Promise.all(workers);

  chrome.runtime.sendMessage({action:'ONE_CLICK_COMPLETE', found: files.length, success: stats.success, failed: stats.failed}).catch(()=>{});
  await chrome.storage.local.set({success: stats.success, failedCount: stats.failed});
  sendResponse({queued, total: files.length, success: stats.success, failed: stats.failed});
}




chrome.runtime.onInstalled.addListener(() => {
  console.log('Drive PDF Extractor One-Click installed');
  chrome.storage.local.set({success:0, failed:0, found:[], folders:[]});
});
