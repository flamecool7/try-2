2 HOUR FAST MODE - OVERNIGHT RUN - FOR 412 PDFs
================================================
You have 2 hours and going to bed - this version is optimized to finish in ~40 mins for 412 files.

OLD MODE: 1 tab sequential, 35s per file = 4 hours for 412
NEW FAST MODE: 3 parallel tabs, 11s per file per worker = ~40 mins for 412

HOW TO RUN OVERNIGHT:
1. Plug in laptop charger
2. Disable sleep: Windows Settings > Power > Never
3. Extract zip to Desktop
4. chrome://extensions -> Load unpacked -> google-drive-pdf-extractor-extension (v3.1 FAST)
5. Open root folder: https://drive.google.com/drive/u/5/folders/1A57dgC857IlCg_ThxZqRwQZTM6IevEVE
6. Click extension -> 🚀 DOWNLOAD ALL 412 PDFs - ONE CLICK
7. Allow multiple downloads
8. Go to bed - keep laptop plugged, lid open, Chrome open
9. Morning: Check Downloads/DrivePDFs/ - 412 files

ESTIMATED: 412 files * 11s / 3 workers = ~40 mins, within 2 hours
