"""
Bulk PDF Downloader from Google Drive using gdown (Python alternative)
Works if folder is shared with anyone-with-link or you have file IDs

Preserves original filenames, supports recursive, batch processing.

Requirements: pip install gdown

Usage:
  python bulk_gdown.py --folder-id 1a2B3c... --output ./DrivePDFs --recursive

If you have a folder URL, extract ID: https://drive.google.com/drive/folders/FOLDER_ID
"""

import argparse
import os
import time
from pathlib import Path

try:
    import gdown
    from gdown.exceptions import FileURLRetrievalError
except ImportError:
    print("Please install gdown: pip install gdown")
    raise

def download_folder_recursive(folder_id, output_dir, preserve_structure=True, failed_list=None):
    if failed_list is None:
        failed_list = []
    
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n[Scanning] Folder ID: {folder_id}")
    # gdown can download entire folder preserving structure
    try:
        # gdown.download_folder handles recursion automatically
        gdown.download_folder(
            id=folder_id,
            output=str(output_dir),
            quiet=False,
            use_cookies=False,
            remaining_ok=True
        )
        print(f"[Done] Downloaded folder {folder_id} to {output_dir}")
    except Exception as e:
        print(f"[Error] Failed to download folder {folder_id}: {e}")
        failed_list.append((folder_id, str(e)))
    
    return failed_list

def download_file_list(file_ids_with_names, output_dir, preserve_names=True):
    """
    file_ids_with_names: list of tuples (id, name)
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    total_found = len(file_ids_with_names)
    success = 0
    failed = []

    print(f"\nFound {total_found} PDFs to download")
    print(f"Output location: {output_dir.resolve()}")
    
    # Process in batches of 8 (as instructed)
    batch_size = 8
    for i in range(0, total_found, batch_size):
        batch = file_ids_with_names[i:i+batch_size]
        print(f"\n--- Batch {i//batch_size +1}/{(total_found+batch_size-1)//batch_size} ({len(batch)} files) ---")
        for file_id, file_name in batch:
            safe_name = file_name.replace('<','_').replace('>','_').replace(':','_').replace('"','_').replace('/','_').replace('\\','_').replace('|','_').replace('?','_').replace('*','_')
            if not safe_name.lower().endswith('.pdf'):
                safe_name += '.pdf'
            output_path = output_dir / safe_name
            
            if output_path.exists():
                print(f"[Skip] Already exists: {safe_name}")
                success += 1
                continue

            url = f"https://drive.google.com/uc?id={file_id}"
            try:
                print(f"[Downloading] {safe_name} (ID: {file_id[:15]}...)")
                gdown.download(url=url, output=str(output_path), quiet=False, fuzzy=True)
                if output_path.exists():
                    print(f"  -> Success: {output_path}")
                    success += 1
                else:
                    print(f"  -> Failed: File not created")
                    failed.append(file_name)
            except Exception as e:
                print(f"  -> Failed: {e}")
                failed.append(file_name)
                # Retry with alternative URL
                try:
                    alt_url = f"https://drive.usercontent.google.com/download?id={file_id}&export=download"
                    print(f"  -> Retrying with alt URL...")
                    time.sleep(1)
                    gdown.download(url=alt_url, output=str(output_path), quiet=False, fuzzy=True)
                    if output_path.exists():
                        print(f"  -> Retry Success")
                        success += 1
                        if file_name in failed:
                            failed.remove(file_name)
                except Exception as e2:
                    print(f"  -> Retry Failed: {e2}")

        if i + batch_size < total_found:
            print("Throttling 2 seconds to avoid rate limit...")
            time.sleep(2)

    print(f"\n=== FINAL REPORT ===")
    print(f"Total PDFs found: {total_found}")
    print(f"Total successfully downloaded: {success}")
    print(f"Total failed: {len(failed)}")
    if failed:
        print(f"Failed files:")
        for f in failed:
            print(f"  - {f}")
    print(f"Local folder: {output_dir.resolve()}")

    return success, failed

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bulk download PDFs from Google Drive")
    parser.add_argument("--folder-id", help="Google Drive Folder ID (from URL)")
    parser.add_argument("--folder-url", help="Full Google Drive Folder URL")
    parser.add_argument("--output", default="./DrivePDFs", help="Output directory")
    parser.add_argument("--recursive", action="store_true", help="Download recursively including subfolders (uses gdown folder download)")
    parser.add_argument("--file-list", help="Text file with lines: file_id,filename  OR just file_id per line")
    parser.add_argument("--pdf-only", action="store_true", default=True, help="Only download PDFs")
    
    args = parser.parse_args()
    
    folder_id = args.folder_id
    if args.folder_url:
        import re
        m = re.search(r"/folders/([a-zA-Z0-9-_]+)", args.folder_url)
        if m:
            folder_id = m.group(1)
        else:
            m = re.search(r"[?&]id=([a-zA-Z0-9-_]+)", args.folder_url)
            if m:
                folder_id = m.group(1)
    
    if args.file_list:
        # Parse file list
        files = []
        with open(args.file_list, 'r', encoding='utf-8') as fh:
            for line in fh:
                line=line.strip()
                if not line:
                    continue
                if ',' in line:
                    fid, fname = line.split(',',1)
                    files.append((fid.strip(), fname.strip()))
                else:
                    # Use ID as name temporarily, will be renamed after?
                    files.append((line.strip(), line.strip()+'.pdf'))
        download_file_list(files, args.output)
    elif folder_id:
        if args.recursive:
            # Use gdown folder download which preserves structure
            download_folder_recursive(folder_id, args.output, preserve_structure=True)
            # After download, filter to PDF only if requested
            if args.pdf_only:
                out = Path(args.output)
                pdfs = list(out.rglob("*.pdf"))
                print(f"\nFiltered to {len(pdfs)} PDFs found in downloaded folder")
                # Move PDFs to report?
        else:
            print("For non-recursive via folder ID, need file list. Use --recursive to download whole folder, or provide --file-list")
            print("Attempting folder download anyway (includes all files)...")
            download_folder_recursive(folder_id, args.output)
    else:
        print("Error: Provide --folder-id or --folder-url or --file-list")
        print("Example: python bulk_gdown.py --folder-url https://drive.google.com/drive/folders/ABC123 --output ./DrivePDFs --recursive")
