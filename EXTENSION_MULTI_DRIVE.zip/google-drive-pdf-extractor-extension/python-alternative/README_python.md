# Python Alternative (if you cannot use Chrome extension)

If you have a Google Drive folder link that is publicly shared (anyone with link), you can use gdown.

## Install
pip install gdown

## For entire folder (preserves structure, includes subfolders)
python bulk_gdown.py --folder-url "https://drive.google.com/drive/folders/YOUR_FOLDER_ID" --output ./DrivePDFs --recursive

Then filter only PDFs:
- On Windows: dir /s /b *.pdf
- On Mac/Linux: find ./DrivePDFs -name "*.pdf"

The output folder is ./DrivePDFs but you can specify any path.

This method respects your instructions:
- Preserves original filenames
- Preserves folder structure if --recursive (gdown does)
- Processes in batches (code batches 8)
- Reports total found, success, failed + names
- Does not modify Drive

## For specific PDF list

If you extracted file IDs via the extension's scan (it saves to storage), you can create a file list:

Create file pdf_list.txt:
```
1a2b3c...,Report_Q1_2024.pdf
2b3c4d...,Invoice_123.pdf
...
```

Then:
python bulk_gdown.py --file-list pdf_list.txt --output ./DrivePDFs
