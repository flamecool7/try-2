# Quick Install Guide for User

Since you asked: "Open Google Chrome, Navigate to folder, Use Chrome extension"

Here is exactly how to use the extension I built combined with Document Preview Exporter.

## You Have Two Extensions to Install:

### 1. Document Preview Exporter (Official)
- Go to: https://chromewebstore.google.com/detail/document-preview-exporter/npapjbliocdhineglcjkmmmaddpgeono
- Click Add to Chrome -> Add extension
- Permission needed: It injects scripts into drive.google.com to capture preview images. This is required to export view-only PDFs. It says "very minimum permissions" but still needs script injection - allow it.

### 2. This Bulk Extractor (I built for you - in folder google-drive-pdf-extractor-extension)
- Download the folder from workspace (I will provide ZIP)
- Unzip to a permanent location (e.g., Desktop/)
- Open chrome://extensions/
- Toggle Developer mode ON
- Click Load unpacked -> select the folder `google-drive-pdf-extractor-extension`
- Pin both extensions in toolbar

## Usage Flow (as per your instructions)

1. Open Chrome
2. Navigate to Google Drive folder you provide (paste URL)
3. Wait for contents fully load - scroll to bottom if many files. Look for loading spinner to disappear.
4. Extension overlay bottom-right shows "Extract PDFs  X" - X is count auto-detected.
5. Click extension icon (my Bulk extractor):
   - Click **Scan Current Folder** (or Scan Recursively if subfolders)
   - Wait for log: "Found N PDFs"
6. Click **Bulk Download Original PDFs** - prefer bulk feature over individual.
   - Chrome may ask: "drive.google.com wants to download multiple files" -> Allow
   - Files go to Downloads/DrivePDFs/ preserving filenames exactly
7. If some PDFs are view-only blocked (download fails):
   - Open one blocked PDF (double-click -> preview view)
   - Scroll through fully until all pages loaded (important for Document Preview Exporter logic)
   - Click Document Preview Exporter icon -> choose PDF A4 Portrait, filename auto, Export
   - For bulk blocked: use my extension's **Preview Export** button - it automates opening each file in background tab and exporting via same logic
8. Maintain structure: toggle "Preserve folder structure" ON
9. Non-PDF filter: extension only lists .pdf - ignores docs, sheets, images unless you ask
10. Duplicate handling: if same PDF already downloaded, Chrome uniquify adds (1) - extension tries not to duplicate but safe guard
11. Retry failures: extension retries once with usercontent URL. Check popup's Failed list after.
12. Continue until every accessible PDF processed - progress log shows.

## Final Report Location

After run, popup shows:
- Total PDFs found: e.g., 42
- Successfully extracted: 40
- Failed: 2 - list names
- Location: %USERPROFILE%\Downloads\DrivePDFs\  (Windows) or ~/Downloads/DrivePDFs/ (Mac/Linux)

You can also check chrome://downloads/ for verified downloads.

## What if you haven't provided folder link yet?

Paste it here: format https://drive.google.com/drive/folders/1abc... 
Or if it's https://drive.google.com/drive/folders/1abc?usp=sharing still works - I parse ID.

If folder is private, ensure you are logged in Chrome with account that has access.

## Manual Alternative (No extension)

If extensions fail, use console script:
- Open Drive folder
- Press F12 -> Console tab
- Paste entire script from `console-scripts/bulk-drive-pdf-downloader.js`
- Press Enter - it will list PDFs and trigger downloads.
