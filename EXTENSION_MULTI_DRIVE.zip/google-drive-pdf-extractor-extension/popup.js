const logBox = document.getElementById('logBox');
const foundCountEl = document.getElementById('foundCount');
const successCountEl = document.getElementById('successCount');
const failCountEl = document.getElementById('failCount');
const progressFill = document.getElementById('progressFill');
const progressText = document.getElementById('progressText');
const progressPct = document.getElementById('progressPct');
const currentFileEl = document.getElementById('currentFile');

function log(msg, type='info') {
  const div = document.createElement('div');
  const time = new Date().toLocaleTimeString();
  div.textContent = `[${time}] ${msg}`;
  if (type === 'error') div.style.color = '#f28b82';
  if (type === 'success') div.style.color = '#81c995';
  logBox.appendChild(div);
  logBox.scrollTop = logBox.scrollHeight;
}

function updateProgress(found, success, failed, current, text) {
  if (typeof found === 'number') foundCountEl.textContent = found;
  if (typeof success === 'number') successCountEl.textContent = success;
  if (typeof failed === 'number') failCountEl.textContent = failed;
  if (current) currentFileEl.textContent = current;
  if (text) progressText.textContent = text;
  
  const total = found || 412;
  const done = success + failed;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  progressFill.style.width = pct + '%';
  progressPct.textContent = pct + '%';
  if (pct === 100) progressFill.style.background = '#137333';
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  return tab;
}

async function sendToContent(action, data={}) {
  const tab = await getActiveTab();
  if (!tab?.id) { log('No active tab', 'error'); return null; }
  if (!tab.url.includes('drive.google.com')) {
    log('Please open Google Drive folder first!', 'error');
    return null;
  }
  try {
    const res = await chrome.tabs.sendMessage(tab.id, {action, ...data});
    return res;
  } catch (e) {
    log(`Injecting content script...`, 'info');
    try {
      await chrome.scripting.executeScript({
        target: {tabId: tab.id},
        files: ['lib/jspdf.umd.min.js', 'content.js']
      });
      await new Promise(r => setTimeout(r, 1500));
      const res2 = await chrome.tabs.sendMessage(tab.id, {action, ...data});
      return res2;
    } catch (e2) {
      log(`Failed: ${e2.message}`, 'error');
      return null;
    }
  }
}

// Load stored stats
chrome.storage.local.get(['found', 'success', 'failed', 'progress'], (data) => {
  if (data.found) foundCountEl.textContent = data.found.length || 0;
  if (typeof data.success === 'number') successCountEl.textContent = data.success;
  if (typeof data.failed === 'number') failCountEl.textContent = data.failed;
  if (data.progress) {
    updateProgress(data.progress.found, data.progress.success, data.progress.failed, data.progress.current, data.progress.text);
  }
});

// ONE CLICK BUTTON - MAIN FEATURE
document.getElementById('oneClickBtn').addEventListener('click', async () => {
  const btn = document.getElementById('oneClickBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Running in background... Do not close Drive tab';
  
  log('🚀 ONE CLICK STARTED - Full background extraction', 'success');
  log('Step 1: Scanning root folder + 18 subjects recursively...', 'info');
  updateProgress(0, 0, 0, 'Scanning...', 'Scanning folders...');

  // First scan recursively to get all PDFs
  const scanRes = await sendToContent('SCAN_RECURSIVE_ONE_CLICK', {});
  if (!scanRes || !scanRes.pdfs) {
    log('Scan failed - try manual Scan Recursively first, then One Click again', 'error');
    btn.disabled = false;
    btn.textContent = '🚀 DOWNLOAD ALL 412 PDFs - ONE CLICK';
    return;
  }

  const total = scanRes.pdfs.length;
  log(`Found ${total} PDFs total. Starting background download via Preview Exporter logic...`, 'success');
  updateProgress(total, 0, 0, scanRes.pdfs[0]?.name || '-', `Found ${total} PDFs`);

  chrome.storage.local.set({found: scanRes.pdfs, progress: {found: total, success: 0, failed: 0, current: '-', text: `Downloading 0/${total}`}});

  // Start bulk preview export in background - content script will handle opening tabs sequentially
  // and report progress via runtime messages
  const res = await sendToContent('BULK_PREVIEW_EXPORT_ONE_CLICK', {files: scanRes.pdfs, preserveStructure: true});
  
  if (res && res.queued) {
    log(`Queued ${res.queued} files for background export. You will see progress updates here. Keep this popup open for live logs, and keep Drive tab open.`, 'success');
  }

  // Note: Actual download happens in background tabs, progress will be reported via messages
  // Keep button disabled until done, but allow to re-enable after timeout if needed
  setTimeout(() => {
    btn.disabled = false;
    btn.textContent = '🚀 DOWNLOAD ALL 412 PDFs - ONE CLICK (Re-run to resume skipped existing)';
  }, 5000);
});

// Manual scan buttons
document.getElementById('scanBtn').addEventListener('click', async () => {
  log('Scanning current folder...');
  const res = await sendToContent('SCAN_CURRENT', {});
  if (res?.pdfs) {
    foundCountEl.textContent = res.pdfs.length;
    log(`Found ${res.pdfs.length} PDFs`, 'success');
  }
});

document.getElementById('scanRecBtn').addEventListener('click', async () => {
  log('Recursive scan via live API... may take 30s...');
  const res = await sendToContent('SCAN_RECURSIVE', {});
  if (res?.pdfs) {
    foundCountEl.textContent = res.pdfs.length;
    log(`Recursive: ${res.pdfs.length} PDFs`, 'success');
  }
});

document.getElementById('scanGenericBtn').addEventListener('click', async () => {
  const btn = document.getElementById('scanGenericBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Scanning EVERY embedded folder...';
  log('🌐 GENERIC SCAN + AUTO-DOWNLOAD for ANY folder (A Levels + IGCSE) - Crawling embedded folders...', 'info');
  updateProgress(0,0,0,'Generic scanning...','Scanning every embedded folder first...');
  
  const res = await sendToContent('SCAN_GENERIC', {});
  if (!res?.pdfs || res.pdfs.length===0) {
    log('Generic scan returned no result - trying fallback One Click...', 'error');
    btn.disabled = false;
    btn.textContent = '🌐 Scan ANY Folder - Generic (A Levels + IGCSE) - Guaranteed Full Scan';
    // Try One Click which uses manifest fallback
    document.getElementById('oneClickBtn').click();
    return;
  }

  foundCountEl.textContent = res.pdfs.length;
  log(`🌐 Scan complete: Found ${res.pdfs.length} PDFs across ${res.folders?.length||0} folders - EVERY pdf in each embedded folder`, 'success');
  log(`Starting AUTO-DOWNLOAD of all ${res.pdfs.length} PDFs via Preview Exporter logic (works for view-only blocked)...`, 'success');
  updateProgress(res.pdfs.length, 0, 0, res.pdfs[0]?.name || '-', `Found ${res.pdfs.length}, starting download...`);

  // AUTO-DOWNLOAD immediately after scan - no second click needed
  const dlRes = await sendToContent('BULK_PREVIEW_EXPORT_ONE_CLICK', {files: res.pdfs, preserveStructure: true});
  if (dlRes?.queued) {
    log(`✅ Auto-download queued ${dlRes.queued} files in background. Watch progress bar - you can close this popup, keep Drive tab open.`, 'success');
  }
  btn.disabled = false;
  btn.textContent = '🌐 Scan ANY Folder - Generic (A Levels + IGCSE) - Guaranteed Full Scan';
  updateProgress(res.pdfs.length, 0, 0, res.pdfs[0]?.name, `Downloading ${res.pdfs.length} PDFs...`);
});


// MULTI-DRIVE SIMULTANEOUS
document.getElementById('multiDriveBtn').addEventListener('click', async () => {
  const btn = document.getElementById('multiDriveBtn');
  const input = document.getElementById('multiFolderInput').value.trim();
  btn.disabled = true;
  btn.textContent = '⏳ Scanning both drives simultaneously...';
  
  let folderIds = [];
  if (input) {
    // Parse URLs
    const lines = input.split('\n').map(l=>l.trim()).filter(l=>l);
    for (let line of lines) {
      const m = line.match(/folders\/([a-zA-Z0-9-_]+)/) || line.match(/[?&]id=([a-zA-Z0-9-_]+)/);
      if (m) folderIds.push(m[1]);
      else if (/^1[A-Za-z0-9_-]{20,}$/.test(line)) folderIds.push(line); // direct ID
    }
  }
  
  if (folderIds.length===0) {
    // Use current folder + try to use prebuilt manifest for A Levels as Drive1
    const tab = await getActiveTab();
    const currentId = tab.url.match(/\/folders\/([a-zA-Z0-9-_]+)/)?.[1];
    if (currentId) folderIds.push(currentId);
    log(`No URLs pasted, using current folder: ${currentId}`, 'info');
  }
  
  if (folderIds.length===0) {
    log('Paste at least one Drive folder URL', 'error');
    btn.disabled = false;
    btn.textContent = '🚀 SCAN + DOWNLOAD BOTH DRIVES SIMULTANEOUSLY';
    return;
  }
  
  log(`🌐 Multi-drive scan: ${folderIds.length} drives: ${folderIds.join(', ')}`, 'success');
  document.getElementById('multiProgress').style.display = 'block';
  
  // For A Levels folder ID 1A57dgC..., we know it has 412 files via manifest, use fast path
  // For other IDs (IGCSE), use generic crawler
  let allPdfs = [];
  let driveStats = [];
  
  for (let idx=0; idx<folderIds.length; idx++) {
    const fid = folderIds[idx];
    log(`Scanning Drive ${idx+1}/${folderIds.length}: ${fid}...`, 'info');
    updateProgress(0,0,0,`Scanning Drive ${idx+1}...`, `Scanning drive ${idx+1}/${folderIds.length}`);
    
    // Try to scan via content script generic crawler for this specific ID
    // We need to navigate to that folder first or use background fetch
    // Simplest: use prebuilt manifest for A Levels, and for others use generic via background
    if (fid === '1A57dgC857IlCg_ThxZqRwQZTM6IevEVE') {
      // A Levels - use manifest
      try {
        const resp = await fetch(chrome.runtime.getURL('A_Levels_MayJune_2026_manifest.json'));
        const manifest = await resp.json();
        log(`Drive ${idx+1} (A Levels): Using prebuilt manifest ${manifest.length} PDFs`, 'success');
        manifest.forEach(m => m.driveIndex = idx);
        allPdfs.push(...manifest.map(m=>({id:m.id, name:m.name, path:`Drive${idx+1}_${fid.slice(0,5)}/${m.path}`, originalPath:m.path, drive:idx})));
        driveStats.push({id:fid, count:manifest.length, name:`Drive${idx+1} (A Levels)`});
        document.getElementById(`drive${idx+1}Progress`).textContent = `0/${manifest.length}`;
      } catch(e){ log(`Failed to load A Levels manifest: ${e.message}`, 'error'); }
    } else {
      // IGCSE or other - try generic scan via background
      log(`Drive ${idx+1}: Attempting generic live scan for ${fid} (may take 1-2 mins)...`, 'info');
      // For generic, we will open that folder in background tab and scan
      const tab = await chrome.tabs.create({url:`https://drive.google.com/drive/folders/${fid}`, active:false});
      await new Promise(r=>setTimeout(r, 8000));
      try { await chrome.scripting.executeScript({target:{tabId:tab.id}, files:['lib/jspdf.umd.min.js','content.js']}); } catch(e){}
      await new Promise(r=>setTimeout(r, 2000));
      let scanRes = null;
      try { scanRes = await chrome.tabs.sendMessage(tab.id, {action:'SCAN_GENERIC'}); } catch(e){ log(`Generic scan failed for ${fid}: ${e.message}`, 'error'); }
      if (scanRes && scanRes.pdfs && scanRes.pdfs.length>0) {
        log(`Drive ${idx+1}: Found ${scanRes.pdfs.length} PDFs via generic scan`, 'success');
        scanRes.pdfs.forEach(p=>{p.driveIndex=idx; p.path=`Drive${idx+1}_${fid.slice(0,5)}/${p.path}`;});
        allPdfs.push(...scanRes.pdfs);
        driveStats.push({id:fid, count:scanRes.pdfs.length, name:`Drive${idx+1}`});
        document.getElementById(`drive${idx+1}Progress`).textContent = `0/${scanRes.pdfs.length}`;
      } else {
        log(`Drive ${idx+1}: Generic scan found 0, will try manifest fallback if available`, 'error');
      }
      try { await chrome.tabs.remove(tab.id); } catch(e){}
    }
  }
  
  log(`🌐 TOTAL: Found ${allPdfs.length} PDFs across ${folderIds.length} drives - Starting simultaneous background download with 3 workers per drive (6 total parallel)...`, 'success');
  updateProgress(allPdfs.length, 0, 0, allPdfs[0]?.name || '-', `Found ${allPdfs.length} total, downloading...`);
  
  // Start bulk download for all drives combined - background will handle 3 parallel workers
  const res = await sendToContent('BULK_PREVIEW_EXPORT_ONE_CLICK', {files: allPdfs, preserveStructure: true, multiDrive: true, driveStats});
  
  btn.disabled = false;
  btn.textContent = '🚀 SCAN + DOWNLOAD BOTH DRIVES SIMULTANEOUSLY';
});


// Listen for progress from content/background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'PROGRESS') {
    log(msg.text, msg.type || 'info');
    if (typeof msg.found === 'number' || typeof msg.success === 'number' || typeof msg.failed === 'number') {
      updateProgress(msg.found, msg.success, msg.failed, msg.current, msg.text);
    }
    // Save progress
    chrome.storage.local.get(['found'], (data) => {
      const found = data.found?.length || msg.found || 0;
      chrome.storage.local.set({
        progress: {
          found: found,
          success: msg.success,
          failed: msg.failed,
          current: msg.current,
          text: msg.text
        },
        success: msg.success,
        failed: msg.failed
      });
    });
  }
  if (msg.action === 'ONE_CLICK_COMPLETE') {
    log(`🎉 COMPLETE! Success: ${msg.success}, Failed: ${msg.failed}`, msg.failed>0?'error':'success');
    log(`Files saved to Downloads/DrivePDFs/ preserving structure`, 'success');
    updateProgress(msg.found, msg.success, msg.failed, 'Done', 'Complete!');
    const btn = document.getElementById('oneClickBtn');
    btn.disabled = false;
    btn.textContent = '✅ Done! Click to re-run (skips existing)';
  }
});
