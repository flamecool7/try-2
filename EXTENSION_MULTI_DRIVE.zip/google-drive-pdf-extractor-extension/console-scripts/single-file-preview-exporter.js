/**
 * Single File Preview Exporter - View-Only PDF Fallback
 * This is the core logic used by Document Preview Exporter extension.
 * Use when normal download is blocked.
 *
 * Instructions:
 * 1. Open the PDF in Google Drive preview: https://drive.google.com/file/d/FILE_ID/view
 * 2. Scroll through ENTIRE document top to bottom, slowly, until all pages loaded (you'll see blurry to clear)
 * 3. Open Console (F12)
 * 4. Paste this script, press Enter
 * 5. It will generate PDF from blob images
 */

(function () {
  console.log("Loading jsPDF for preview export...");

  let script = document.createElement("script");
  script.onload = function () {
    const { jsPDF } = window.jspdf;

    let pdf = null;
    let imgElements = document.getElementsByTagName("img");
    let validImgs = [];

    console.log("Scanning for blob preview images...");
    for (let i = 0; i < imgElements.length; i++) {
      let img = imgElements[i];
      let checkURLString = "blob:https://drive.google.com/";
      if (img.src.substring(0, checkURLString.length) !== checkURLString) continue;
      validImgs.push(img);
    }

    // Also include canvas rendering (new Drive UI)
    let canvasEls = document.querySelectorAll('canvas');
    let validCanvases = [];
    canvasEls.forEach(c => {
      if (c.width > 300 && c.height > 300 && c.getBoundingClientRect().width > 0) {
        // Heuristic: canvas inside doc preview
        validCanvases.push(c);
      }
    });

    console.log(`${validImgs.length} blob images, ${validCanvases.length} canvas elements found`);

    if (validImgs.length === 0 && validCanvases.length === 0) {
      alert("No preview images found. Please scroll through the PDF fully until all pages load, then try again.");
      return;
    }

    console.log("Generating PDF file...");

    // Process images
    for (let i = 0; i < validImgs.length; i++) {
      let img = validImgs[i];
      let canvasElement = document.createElement("canvas");
      let con = canvasElement.getContext("2d");
      canvasElement.width = img.naturalWidth;
      canvasElement.height = img.naturalHeight;
      con.drawImage(img, 0, 0, img.naturalWidth, img.naturalHeight);
      let imgData = canvasElement.toDataURL();

      let orientation = img.naturalWidth > img.naturalHeight ? "l" : "p";
      let pageWidth = img.naturalWidth;
      let pageHeight = img.naturalHeight;

      if (i === 0 && validCanvases.length === 0 && !pdf) {
        pdf = new jsPDF({ orientation, unit: "px", format: [pageWidth, pageHeight] });
      } else if (i === 0) {
        pdf = new jsPDF({ orientation, unit: "px", format: [pageWidth, pageHeight] });
      } else {
        pdf.addPage([pageWidth, pageHeight], orientation);
      }

      pdf.addImage(imgData, "PNG", 0, 0, pageWidth, pageHeight, "", "SLOW");
      console.log(`Processing ${Math.floor(((i + 1) / (validImgs.length+validCanvases.length)) * 100)}%`);
    }

    // Process canvases
    for (let j=0;j<validCanvases.length;j++) {
      let c = validCanvases[j];
      let imgData = c.toDataURL("image/png");
      let orientation = c.width > c.height ? "l" : "p";
      if (!pdf) pdf = new jsPDF({orientation, unit: "px", format: [c.width, c.height]});
      else pdf.addPage([c.width, c.height], orientation);
      pdf.addImage(imgData, "PNG", 0,0,c.width,c.height,"","SLOW");
      console.log(`Canvas page ${validImgs.length+j+1}/${validImgs.length+validCanvases.length}`);
    }

    let title = document.querySelector('meta[itemprop="name"]')?.content || document.title || 'download.pdf';
    if ((title.split(".").pop() || "").toLowerCase() !== "pdf") title = title + ".pdf";
    title = title.replace(/[<>:"/\\|?*]+/g, "_");

    console.log(`Downloading ${title}...`);
    pdf.save(title, { returnPromise: true }).then(() => {
      document.body.removeChild(script);
      console.log("PDF downloaded! Check Downloads folder.");
    });
  };

  let scriptURL = "https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js";
  let trustedURL;
  if (window.trustedTypes && trustedTypes.createPolicy) {
    const policy = trustedTypes.createPolicy("myPolicy", { createScriptURL: (input) => input });
    trustedURL = policy.createScriptURL(scriptURL);
  } else {
    trustedURL = scriptURL;
  }
  script.src = trustedURL;
  document.body.appendChild(script);
})();
