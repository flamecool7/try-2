/**
 * Bulk Drive PDF Downloader - Console Script
 * Paste into DevTools console on Google Drive folder page.
 * Does NOT require extension install.
 * Combines DOM scan + Original download + Preview Exporter logic.
 * 
 * Usage:
 * 1. Open Drive folder (https://drive.google.com/drive/folders/...)
 * 2. Wait for files to load, scroll to bottom
 * 3. Open Console (F12 > Console)
 * 4. Paste entire script and press Enter
 * 5. It will list PDFs, then trigger downloads
 */

(async function DriveBulkPDF() {
  console.log("%c📄 Drive Bulk PDF Downloader - Starting", "font-size:16px; font-weight:bold; color:#1a73e8");

  function getFolderId() {
    const url = location.href;
    let m = url.match(/\/folders\/([a-zA-Z0-9-_]+)/);
    if (m) return m[1];
    m = url.match(/[?&]id=([a-zA-Z0-9-_]+)/);
    if (m) return m[1];
    return null;
  }

  function scanDOM() {
    const pdfs = [];
    const seen = new Set();
    document.querySelectorAll('[data-id]').forEach(el => {
      const id = el.getAttribute('data-id');
      if (!id || seen.has(id) || id.length < 10) return;
      let name = el.getAttribute('aria-label') || '';
      if (!name.toLowerCase().endsWith('.pdf')) {
        const spans = el.querySelectorAll('span, div');
        for (const s of spans) {
          const txt = s.textContent?.trim();
          if (txt && txt.toLowerCase().endsWith('.pdf') && txt.length < 200) { name = txt; break; }
        }
      }
      if (name && name.toLowerCase().endsWith('.pdf')) {
        seen.add(id);
        pdfs.push({id, name: name.trim()});
      }
    });
    return pdfs;
  }

  async function waitLoad(ms=8000) {
    console.log(`Waiting ${ms/1000}s for Drive to fully load... scroll to bottom if needed`);
    await new Promise(r => setTimeout(r, ms));
  }

  await waitLoad(3000);
  const folderId = getFolderId();
  console.log(`Folder ID: ${folderId || 'unknown (might still work via DOM)'}`);

  let pdfs = scanDOM();
  console.log(`Found ${pdfs.length} PDFs via DOM:`);
  pdfs.forEach(f => console.log(` - ${f.name} | ID: ${f.id}`));

  if (pdfs.length === 0) {
    console.warn("No PDFs found. Try switching to List view, scrolling, then run again.");
    return;
  }

  const batchSize = 5;
  const preserveNames = confirm(`Found ${pdfs.length} PDFs. Click OK to preserve original filenames (Recommended). Cancel to use IDs.`);
  const usePreviewFallback = confirm(`If original download is blocked, should we fallback to Preview Export (image-based PDF) logic like Document Preview Exporter? OK=Yes, Cancel=Only original`);

  let success = 0, failed = [];

  for (let i=0;i<pdfs.length;i+=batchSize) {
    const batch = pdfs.slice(i, i+batchSize);
    console.log(`\nDownloading batch ${Math.floor(i/batchSize)+1}/${Math.ceil(pdfs.length/batchSize)}...`);
    for (const file of batch) {
      try {
        // Try original download URL
        const url = `https://drive.google.com/uc?export=download&id=${file.id}`;
        const a = document.createElement('a');
        a.href = url;
        a.download = file.name;
        a.style.display='none';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        console.log(`✅ Triggered download: ${file.name}`);
        success++;
        await new Promise(r => setTimeout(r, 800));
      } catch (e) {
        console.error(`❌ Failed ${file.name}: ${e.message}`);
        failed.push(file.name);
      }
    }
    if (i+batchSize < pdfs.length) {
      console.log("Throttling 2s to avoid rate limit...");
      await new Promise(r => setTimeout(r, 2000));
    }
  }

  console.log(`\n=== FINAL REPORT ===`);
  console.log(`Total found: ${pdfs.length}`);
  console.log(`Successfully triggered: ${success}`);
  console.log(`Failed: ${failed.length}`);
  if (failed.length) console.log(`Failed files:`, failed);
  console.log(`Saved to default Downloads folder. Verify in chrome://downloads/`);
  
  if (usePreviewFallback && failed.length>0) {
    console.log(`\nFor failed files, open each PDF preview individually and use Document Preview Exporter extension or run the single-file preview exporter script below.`);
  }

  // Provide single-file preview exporter function for view-only
  window.exportCurrentPreviewPDF = async function() {
    console.log("Starting Preview Export (like Document Preview Exporter) - ensure you scrolled through all pages!");
    const script = document.createElement('script');
    script.src = "https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js";
    await new Promise((res,rej)=>{script.onload=res; script.onerror=rej; document.body.appendChild(script);});
    const { jsPDF } = window.jspdf;
    let imgs = [];
    document.querySelectorAll('img').forEach(img=>{ if (img.src.startsWith('blob:https://drive.google.com/')) imgs.push(img); });
    console.log(`Found ${imgs.length} preview pages`);
    if (imgs.length===0) { console.error("No preview images found. Scroll fully then retry."); return; }
    let pdf=null;
    for (let i=0;i<imgs.length;i++) {
      let img=imgs[i];
      let canvas=document.createElement('canvas');
      let ctx=canvas.getContext('2d');
      canvas.width=img.naturalWidth; canvas.height=img.naturalHeight;
      ctx.drawImage(img,0,0,canvas.width,canvas.height);
      let data=canvas.toDataURL();
      let orient=canvas.width>canvas.height?'l':'p';
      if (i===0) pdf=new jsPDF({orientation:orient, unit:'px', format:[canvas.width,canvas.height]});
      else pdf.addPage([canvas.width,canvas.height], orient);
      pdf.addImage(data,'PNG',0,0,canvas.width,canvas.height,'','SLOW');
      console.log(`Page ${i+1}/${imgs.length} ${Math.floor((i+1)/imgs.length*100)}%`);
    }
    let title=document.querySelector('meta[itemprop="name"]')?.content || document.title || 'exported.pdf';
    if (!title.toLowerCase().endsWith('.pdf')) title+='.pdf';
    pdf.save(title);
    console.log(`Saved ${title}`);
  };
  console.log("To export a view-only PDF opened in preview, run: exportCurrentPreviewPDF()");
})();
