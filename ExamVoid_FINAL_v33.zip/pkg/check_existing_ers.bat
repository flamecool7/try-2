@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title ExamVoid Examiner Report Checker

rem ---------------------------------------------------------------------------
rem Offline recursive ER inventory.
rem
rem With no arguments this scans the entire pkg folder recursively, including
rem input\ and any examiner-report archive placed beneath it. It never downloads
rem anything. Pass custom roots when the archive lives elsewhere, for example:
rem   check_existing_ers.bat --root input --root "D:\Examiner Reports"
rem ---------------------------------------------------------------------------

set "PYTHON_CMD="
where py.exe >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
    where python.exe >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo ERROR: Python 3 was not found.
    pause
    exit /b 1
)

if not exist "%~dp0check_existing_ers.py" (
    echo ERROR: check_existing_ers.py was not found beside this launcher.
    pause
    exit /b 1
)

if "%~1"=="" (
    "%PYTHON_CMD%" "%~dp0check_existing_ers.py" --root "%~dp0" --out-dir "%~dp0"
) else (
    "%PYTHON_CMD%" "%~dp0check_existing_ers.py" %*
)
set "RC=%ERRORLEVEL%"

echo.
echo Reports are in:
echo   %~dp0missing_examiner_reports.txt
echo   %~dp0examiner_report_inventory.csv
echo   %~dp0examiner_report_inventory.json
pause
exit /b %RC%
