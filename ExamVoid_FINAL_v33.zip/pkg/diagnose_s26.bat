@echo off
setlocal EnableExtensions DisableDelayedExpansion
title ExamVoid S26 Diagnostic
cd /d "%~dp0"

set "REPORT=%~dp0s26_diagnosis.txt"
set "PYTHON_EXE="
set "PYTHON_ARGS="

if exist "%~dp0.venv\Scripts\python.exe" set "PYTHON_EXE=%~dp0.venv\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0venv\Scripts\python.exe" set "PYTHON_EXE=%~dp0venv\Scripts\python.exe"

if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where py.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
    if defined PYTHON_EXE set "PYTHON_ARGS=-3"
)
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)

if not defined PYTHON_EXE (
    >"%REPORT%" echo ERROR: Python 3 was not found on this computer.
    start "" notepad.exe "%REPORT%"
    pause
    exit /b 1
)

if not exist "%~dp0run_guarded.py" (
    >"%REPORT%" echo ERROR: run_guarded.py was not found beside this diagnostic file.
    start "" notepad.exe "%REPORT%"
    pause
    exit /b 1
)

>"%REPORT%" echo ExamVoid S26 diagnostic
>>"%REPORT%" echo Project: %~dp0
>>"%REPORT%" echo Started: %DATE% %TIME%
>>"%REPORT%" echo.

"%PYTHON_EXE%" %PYTHON_ARGS% -u "%~dp0run_guarded.py" --input "%~dp0input" --output "%~dp0output" --trust-self --dry-run --no-manifest >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
>>"%REPORT%" echo.
>>"%REPORT%" echo Diagnostic exit code: %RC%
>>"%REPORT%" echo Finished: %DATE% %TIME%

start "" notepad.exe "%REPORT%"
echo.
echo Created diagnostic report:
echo %REPORT%
echo.
pause
exit /b %RC%
