from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import fitz
import sys
PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.output_manager import OutputManager  # noqa: E402
from run_guarded import (_copy_confidential_instructions,
                         _render_confidential_pages_to_questions)  # noqa: E402


class TestConfidentialInstructionsSidecar(unittest.TestCase):
    def test_ci_is_copied_intact_to_paper_sidecar(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            ci = root / "9706_s25_qp_12_ci.pdf"
            ci.write_bytes(b"%PDF-confidential-instructions")
            out = root / "output"
            manager = OutputManager(out)
            qp_info = SimpleNamespace(
                variant="12", full_code="9706_s25_qp_12",
                paper_format="MCQ",
            )
            ci_info = SimpleNamespace(file_path=ci)
            config = SimpleNamespace(
                level="A-Level", subject="Accounting_9706",
                syllabus_code="9706",
            )
            target = _copy_confidential_instructions(ci_info, qp_info, config, manager)
            self.assertEqual(
                target.relative_to(out).as_posix(),
                "A-Level/Accounting_9706/paper-1/_confidential/9706_s25_qp_12_CI.pdf",
            )
            self.assertEqual(target.read_bytes(), ci.read_bytes())

    def test_ci_page_is_attached_as_non_qp_webp(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            ci = root / "9706_s25_ci_12.pdf"
            doc = fitz.open()
            page = doc.new_page(width=400, height=500)
            page.insert_text((40, 60), "CONFIDENTIAL INSTRUCTIONS\nPaper 1")
            doc.save(ci)
            doc.close()
            out = root / "output"
            manager = OutputManager(out)
            qfolder = out / "A-Level" / "Accounting_9706" / "paper-1" / "Topic" / "12_Summer_2025_Q1"
            qfolder.mkdir(parents=True)
            (qfolder / "12_Summer_2025_Q1.webp").write_bytes(b"placeholder")
            count = _render_confidential_pages_to_questions(
                SimpleNamespace(file_path=ci), [(str(qfolder), "")], manager
            )
            self.assertEqual(count, 1)
            ci_page = qfolder / "12_Summer_2025_Q1_CI.webp"
            self.assertTrue(ci_page.exists())
            from PIL import Image
            with Image.open(ci_page) as image:
                self.assertEqual(image.width, 2280)


if __name__ == "__main__":
    unittest.main()
