import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
TOOL = PROJ / "tools" / "topic_accuracy_workflow.py"


class TestTopicAccuracyWorkflow(unittest.TestCase):
    def test_template_and_evaluate_subcommands(self):
        tmp = Path(tempfile.mkdtemp(prefix="topic_workflow_"))
        out = tmp / "output"
        out.mkdir()
        meta = out / "IGCSE" / "Mathematics_0580" / "paper-4" / "Trigonometry" / "42_Summer_2024_Q1" / "metadata.json"
        meta.parent.mkdir(parents=True, exist_ok=True)
        meta.write_text(json.dumps({
            "subject": "Mathematics_0580",
            "level": "IGCSE",
            "paper": "0580_s24_qp_42",
            "question_number": "Q1",
            "topic": ["Trigonometry"],
            "variant": "42",
            "season": "Summer",
            "year": "2024",
        }), encoding="utf-8")

        labels = tmp / "labels.csv"
        p1 = subprocess.run([
            sys.executable, str(TOOL), "template", "--output-root", str(out), "--csv", str(labels)
        ], cwd=str(PROJ), capture_output=True, text=True, timeout=120)
        self.assertEqual(p1.returncode, 0, p1.stdout + p1.stderr)
        with labels.open(newline="", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["predicted_topic"], "Trigonometry")
        rows[0]["expected_topic"] = "Trigonometry"
        with labels.open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=rows[0].keys())
            w.writeheader()
            w.writerows(rows)

        report = tmp / "report.json"
        dash = tmp / "dashboard.html"
        summaries = tmp / "csvs"
        p2 = subprocess.run([
            sys.executable, str(TOOL), "evaluate", "--output-root", str(out),
            "--labels", str(labels), "--report-json", str(report),
            "--dashboard-html", str(dash), "--summary-dir", str(summaries)
        ], cwd=str(PROJ), capture_output=True, text=True, timeout=120)
        self.assertEqual(p2.returncode, 0, p2.stdout + p2.stderr)
        data = json.loads(report.read_text(encoding="utf-8"))
        self.assertEqual(data["summary"]["accuracy_percent"], 100.0)
        self.assertTrue(dash.exists())
        self.assertIn("Topic Accuracy Dashboard", dash.read_text(encoding="utf-8"))
        self.assertTrue((summaries / "subject_ranking.csv").exists())


if __name__ == "__main__":
    unittest.main()
