#!/usr/bin/env python3
"""RS-13 quarantine tool tests — parse accuracy, dry-run purity, apply idempotency."""
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

_spec = importlib.util.spec_from_file_location(
    "quarantine_reviewed_crops", PROJ / "tools" / "quarantine_reviewed_crops.py")
qt = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(qt)

LOG = """  Q39: 1 page section(s), assembled (2280, 733), QC: OK
  Q40: 1 page section(s), assembled (2280, 1887), QC: review: REFERENCE_MATERIAL_CONTAMINATION: Contains Administrative Back-Matter without question structure
    [low-ram] Q40: (2280, 1887), QC review: REFERENCE_MATERIAL_CONTAMINATION: Contains Administrative Back-Matter without question structure
    [low-ram] Q8: (2280, 900), QC review: IMAGE_TOO_SMALL: suspicious
"""


def _tree(root: Path):
    q40 = root / "IGCSE/Chemistry_0620/paper-2/Topic/22_Summer_2016_Q40"
    q8 = root / "IGCSE/Chemistry_0620/paper-2/Topic/22_Summer_2016_Q8"
    for q in (q40, q8):
        q.mkdir(parents=True)
        (q / (q.name + ".webp")).write_bytes(b"fake-webp")


class TestQuarantineTool(unittest.TestCase):
    def test_parse_handles_both_line_shapes_and_dedupes(self):
        with tempfile.TemporaryDirectory() as td:
            log = Path(td) / "run.log"
            log.write_text(LOG)
            v = qt.parse_review_verdicts(log)
            self.assertEqual(set(v), {8, 40})
            self.assertTrue(v[40].startswith("REFERENCE_MATERIAL_CONTAMINATION"))
            self.assertTrue(v[8].startswith("IMAGE_TOO_SMALL"))

    def test_dry_run_moves_nothing_and_defaults_to_contamination_only(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "out"
            _tree(root)
            log = Path(td) / "run.log"
            log.write_text(LOG)
            plan = qt.quarantine(root, qt.parse_review_verdicts(log), ("REFERENCE_MATERIAL_CONTAMINATION",))
            self.assertEqual(len(plan), 1)
            self.assertEqual(plan[0][0], 40)
            self.assertTrue((root / "IGCSE/Chemistry_0620/paper-2/Topic/22_Summer_2016_Q40").exists(),
                            "dry-run must not move")
            self.assertFalse((root / "_Review").exists())

    def test_apply_moves_and_writes_readme_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "out"
            _tree(root)
            log = Path(td) / "run.log"
            log.write_text(LOG)
            v = qt.parse_review_verdicts(log)
            plan1 = qt.quarantine(root, v, ("REFERENCE_MATERIAL_CONTAMINATION",), apply=True)
            self.assertEqual(plan1[0][5], "moved")
            self.assertFalse((root / "IGCSE/Chemistry_0620/paper-2/Topic/22_Summer_2016_Q40").exists())
            moved = list(root.rglob("*_Q40"))
            self.assertEqual(len(moved), 1)
            self.assertTrue("_Review" in moved[0].parts)
            # second apply: no folder on disk anymore -> clean no-op
            plan2 = qt.quarantine(root, v, ("REFERENCE_MATERIAL_CONTAMINATION",), apply=True)
            self.assertEqual(plan2[0][5], "no folder on disk")
            q8 = root / "IGCSE/Chemistry_0620/paper-2/Topic/22_Summer_2016_Q8"
            self.assertTrue(q8.exists(), "non-contamination reasons stay put by default")

    def test_all_review_mode_catches_other_reasons(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "out"
            _tree(root)
            log = Path(td) / "run.log"
            log.write_text(LOG)
            plan = qt.quarantine(root, qt.parse_review_verdicts(log), None, apply=True)
            self.assertEqual({p[0] for p in plan}, {8, 40})

    def test_main_dry_run_and_empty_log_rc(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "out"
            _tree(root)
            log = Path(td) / "run.log"
            log.write_text(LOG)
            rc = qt.main(["--output", str(root), "--log", str(log)])
            self.assertEqual(rc, 0)
            bad = Path(td) / "empty.log"
            bad.write_text("nothing here\n")
            self.assertEqual(qt.main(["--output", str(root), "--log", str(bad)]), 2)


if __name__ == "__main__":
    unittest.main()
