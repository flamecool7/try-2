#!/usr/bin/env python3
"""Regression suite: missing-paper review routing + insert booklet cropping
+ previously-unconfigured subject (Psychology 9990) — 2026-08-15.

Covers the maintainer's requirements:
  1. A missing QP no longer drops the bundle — the MS is cropped and preserved
     in review_required/missing_qp.
  2. A missing MS (QP-only) routes to review_required/no_markscheme.
  3. Psychology 9990 / Sociology 9699 / Accounting 9706 now have valid configs.
  4. Insert booklets are cropped (whole pages + per-question referenced
     sections) at 2280px, with reference-data inserts skipped.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from PIL import Image

try:
    import fitz  # PyMuPDF
except ImportError:
    import pymupdf as fitz

from core.config_loader import (load_subject_config_by_code_and_level,  # noqa: E402
                                KNOWN_CODE_MAP)
from core.output_manager import OutputManager, _is_review_required_no_qp  # noqa: E402
from core.insert_engine import InsertEngine, referenced_sections, _detect_reference_data, _classify_page  # noqa: E402
from core.validation import FinalValidator  # noqa: E402


class TestMissingSubjectConfigs(unittest.TestCase):
    def test_9990_config_loads(self):
        cfg = load_subject_config_by_code_and_level("9990", "A-Level")
        self.assertIsNotNone(cfg)
        self.assertEqual(cfg.subject, "Psychology_9990")
        self.assertGreaterEqual(len(cfg.major_topics), 1)

    def test_9699_and_9706(self):
        for code, subj in (("9699", "Sociology_9699"), ("9706", "Accounting_9706")):
            cfg = load_subject_config_by_code_and_level(code, "A-Level")
            self.assertIsNotNone(cfg, f"{code} config missing")
            self.assertEqual(cfg.subject, subj)

    def test_known_code_map_has_new_codes(self):
        for code in ("9990", "9699", "9706"):
            self.assertIn(code, KNOWN_CODE_MAP)


class TestMissingPaperReviewRouting(unittest.TestCase):
    def test_missing_qp_folder(self):
        cfg = load_subject_config_by_code_and_level("9990", "A-Level")
        with tempfile.TemporaryDirectory() as td:
            om = OutputManager(output_root=Path(td) / "out")
            img = Image.new("RGB", (2280, 200), "white")
            crop = SimpleNamespace(question_number="Q1", number_int=1,
                                   assembled_image=img)
            r = om.save_missing_qp_question(crop, "21", "Summer", "2024",
                                            "9990_s24_ms_21", cfg)
            qf = Path(r["question_folder"])
            self.assertTrue(_is_review_required_no_qp(qf))
            self.assertTrue((qf / "21_Summer_2024_Q1_MS.webp").exists())
            self.assertFalse((qf / "REASON.txt").exists())
            self.assertTrue((qf / "metadata.json").exists())
            # validator accepts the MS-only review folder
            fv = FinalValidator(output_root=Path(td) / "out")
            self.assertTrue(fv.validate_all()["passed"], getattr(fv, "errors", []))

    def test_no_markscheme_folder(self):
        cfg = load_subject_config_by_code_and_level("9990", "A-Level")
        with tempfile.TemporaryDirectory() as td:
            om = OutputManager(output_root=Path(td) / "out")
            img = Image.new("RGB", (2280, 200), "white")
            m = SimpleNamespace(qp=SimpleNamespace(assembled_image=img), ms=None,
                                ms_answer=None, variant="21", season="Summer",
                                year="2024", question_number="Q2",
                                full_qp_code="9990_s24_qp_21")
            r = om.save_review_required_question(m, "no_markscheme", cfg)
            qf = Path(r["question_folder"])
            self.assertTrue((qf / "21_Summer_2024_Q2.webp").exists())
            self.assertFalse((qf / "REASON.txt").exists())
            fv = FinalValidator(output_root=Path(td) / "out")
            self.assertTrue(fv.validate_all()["passed"], getattr(fv, "errors", []))


def _make_insert(pdf_path: Path):
    doc = fitz.open()
    pg = doc.new_page(width=595, height=842)
    pg.insert_text((40, 40), "This document has 2 pages. DC (LK) 1234")
    pg.insert_text((40, 80), "Source A")
    pg.insert_text((40, 100), "Alpha Ltd manufactures widgets in three countries.")
    pg.insert_text((40, 160), "Source B")
    pg.insert_text((40, 180), "Beta Co expanded into emerging markets in 2023.")
    pg.insert_text((300, 820), "3")
    doc.save(str(pdf_path))
    doc.close()


class TestInsertEngine(unittest.TestCase):
    def test_process_and_sections(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "9609_s24_in_21.pdf"
            _make_insert(p)
            eng = InsertEngine(dpi=150)
            res = eng.process_insert(p)
            self.assertIsNotNone(res)
            self.assertFalse(res.is_reference_data)
            self.assertEqual(res.pages[0].width, 2280)
            ids = [s.id for s in res.sections]
            self.assertIn("Source A", ids)
            self.assertIn("Source B", ids)

    def test_reference_matching(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "9609_s24_in_21.pdf"
            _make_insert(p)
            eng = InsertEngine(dpi=150)
            res = eng.process_insert(p)
            refs = referenced_sections("Refer to Source A to answer the question.",
                                       res.sections)
            self.assertEqual([s.id for s in refs], ["Source A"])

    def test_reference_data_detection(self):
        txt = ("Periodic Table of the Elements\nHydrogen Helium Lithium Beryllium "
               "Boron Carbon Nitrogen Oxygen Fluorine Neon Sodium Magnesium "
               "Aluminium Silicon Phosphorus Sulfur Chlorine Argon Potassium "
               "Calcium Iron Copper Zinc Bromine Iodine Silver Lead Uranium")
        self.assertTrue(_detect_reference_data(txt))
        self.assertFalse(_detect_reference_data("Alpha Ltd manufactures widgets."))

    def test_cover_and_backmatter_classification(self):
        cover = ("This document has 4 pages. Any blank pages are indicated.\n"
                 "INFORMATION\nThis insert contains the case study.\n"
                 "You may annotate this insert and use the blank spaces for planning. "
                 "Do not write your answers on the insert.")
        self.assertEqual(_classify_page(cover), "cover")
        back = ("Permission to reproduce items where third-party owned material "
                "protected by copyright is included has been sought.\n"
                "To avoid the issue of disclosure of answer-related information...")
        self.assertEqual(_classify_page(back), "backmatter")
        content = "Gordy Building Supplies (GBS)\nGBS sells sand, gravel and other building materials."
        self.assertEqual(_classify_page(content), "content")

    def test_insert_named_qid_IN_webp(self):
        # per-question insert attachment must be {QID}_IN.webp (2280px)
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            ins = td / "9609_s24_in_21.pdf"
            _make_insert(ins)
            eng = InsertEngine(dpi=150)
            res = eng.process_insert(ins)
            out = td / "output"
            qf = out / "A-Level" / "Business_9609" / "paper-2" / \
                 "Business_and_its_environment" / "22_Winter_2025_Q5"
            qf.mkdir(parents=True, exist_ok=True)
            from core.insert_engine import write_insert_outputs
            write_insert_outputs(
                eng, res, ins, out, "A-Level", "Business_9609",
                "paper-2", "9609_s24_in_21",
                question_refs=[(str(qf), "Refer to Source A and Source B to answer.")])
            insert_files = list(qf.glob("*_IN.webp"))
            self.assertEqual([f.name for f in insert_files],
                             ["22_Winter_2025_Q5_IN.webp"])
            with Image.open(insert_files[0]) as im:
                self.assertEqual(im.width, 2280)


if __name__ == "__main__":
    unittest.main()
