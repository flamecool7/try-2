from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

import fitz

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.mcq_registry import get_expected_question_count, is_mcq  # noqa: E402
from core.paper_identifier import parse_paper_filename  # noqa: E402


class TestAccountingMCQFormats(unittest.TestCase):
    def test_accounting_registry_rows(self):
        self.assertTrue(is_mcq("9706", "12"))
        self.assertTrue(is_mcq("0452", "13"))
        self.assertEqual(get_expected_question_count("9706", "12"), 30)
        self.assertEqual(get_expected_question_count("0452", "13"), 35)

    def test_insert_name_variants_are_recognized(self):
        with tempfile.TemporaryDirectory() as td:
            variants = [
                "9706_s25_insert_12.pdf",
                "9706_s25_in_12.pdf",
                "9706_s25_qp_12_insert.pdf",
                "9706_s25_qp_12_in.pdf",
                "9706 Accounting May 2025 Source Booklet 12.pdf",
            ]
            for name in variants:
                info = parse_paper_filename(Path(td) / name)
                self.assertIsNotNone(info, name)
                self.assertEqual(info.paper_type, "insert", name)
                self.assertEqual(info.variant, "12", name)

    def test_future_s26_and_compound_session_names_are_recognized(self):
        cases = [
            ("9706_s27_qp_12.pdf", "qp", "s", "2027"),
            ("9706_may_june_2027_question_paper_12.pdf", "qp", "s", "2027"),
            ("9706_may-june-2028-mark-scheme-12.PDF", "ms", "s", "2028"),
            ("9706_s50_qp_12.pdf", "qp", "s", "2050"),
        ]
        for name, kind, season, year in cases:
            info = parse_paper_filename(Path("/tmp") / name)
            self.assertIsNotNone(info, name)
            self.assertEqual((info.paper_type, info.season_letter, info.year),
                             (kind, season, year), name)

    def test_content_fallback_catches_unenumerated_mcq_profile(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "9998_s25_qp_12.pdf"
            doc = fitz.open()
            page = doc.new_page()
            page.insert_text(
                (40, 60),
                "ACCOUNTING 9998/12 Paper 1 Multiple Choice\n"
                "There are thirty questions. Record your choice on the answer sheet.\n"
                "For each question there are four possible answers A, B, C and D.",
            )
            doc.save(path)
            doc.close()
            info = parse_paper_filename(path)
            self.assertIsNotNone(info)
            self.assertEqual(info.paper_format, "MCQ")
            self.assertTrue(info.is_mcq)


if __name__ == "__main__":
    unittest.main()
