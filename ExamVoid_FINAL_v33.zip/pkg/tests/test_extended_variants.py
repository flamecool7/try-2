#!/usr/bin/env python3
"""Extended-variant resolution — Cambridge-added component digits (2026-08-15).

Cambridge has been adding variant digits beyond the classic 1-3 (components
like 14, 15, 19, 24, 34, 44, 54, 64, ...).  Format/MCQ status must be decided
by the PAPER NUMBER (second-to-last digit), never by an exact enumerated
component code, so these variants route to the correct format instead of
silently defaulting to STRUCTURED.
"""
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.mcq_registry import (is_mcq, component_paper_number,     # noqa: E402
                               get_expected_question_count)
from core.paper_identifier import resolve_paper_format              # noqa: E402
from core.output_manager import _paper_type_folder                  # noqa: E402


class TestComponentPaperNumber(unittest.TestCase):
    def test_paper_number_from_component(self):
        cases = {"11": 1, "15": 1, "19": 1, "21": 2, "24": 2,
                 "34": 3, "45": 4, "54": 5, "64": 6, "7": 7, "": 0}
        for comp, want in cases.items():
            self.assertEqual(component_paper_number(comp), want, comp)

    def test_never_more_than_two_digits_in_component(self):
        # a 3-digit "110" is not a real component; paper number is still the
        # second-to-last digit but the filename parser caps variants at 2 digits.
        self.assertEqual(component_paper_number("110"), 1)


class TestExtendedVariantMCQ(unittest.TestCase):
    def test_mcq_extended_variants(self):
        true_cases = [("0620", "15"), ("0620", "19"), ("0620", "24"),
                      ("9701", "19"), ("9702", "16"), ("9700", "14"),
                      ("0455", "14"), ("0610", "25"), ("0654", "25"),
                      ("0653", "14"), ("5070", "15")]
        for code, comp in true_cases:
            self.assertTrue(is_mcq(code, comp), f"{code}/{comp} should be MCQ")

    def test_non_mcq_extended_variants(self):
        false_cases = [("0620", "34"), ("0620", "44"), ("0620", "54"),
                       ("0620", "64"), ("9701", "21"), ("9701", "41"),
                       ("0580", "15"), ("9990", "11"), ("9709", "11"),
                       ("0653", "21"), ("0455", "24")]
        for code, comp in false_cases:
            self.assertFalse(is_mcq(code, comp), f"{code}/{comp} should NOT be MCQ")


class TestExtendedVariantFormat(unittest.TestCase):
    def test_resolve_paper_format(self):
        cases = [("0620", "15", "MCQ"), ("0620", "24", "MCQ"),
                 ("0620", "34", "STRUCTURED"), ("0620", "44", "STRUCTURED"),
                 ("0620", "54", "PRACTICAL"), ("0620", "64", "ATP"),
                 ("0470", "45", "ESSAY"), ("0455", "14", "MCQ"),
                 ("0455", "24", "STRUCTURED")]
        for code, comp, want in cases:
            self.assertEqual(resolve_paper_format(code, comp), want,
                             f"{code}/{comp}")

    def test_paper_type_folder(self):
        cases = [("0620", "15", "paper-1"), ("0620", "24", "paper-2"),
                 ("0620", "54", "paper-5"), ("0620", "64", "paper-6"),
                 ("0470", "45", "paper-4"), ("9701", "19", "paper-1")]
        for code, comp, want in cases:
            self.assertEqual(_paper_type_folder(comp, code), want,
                             f"{code}/{comp}")

    def test_expected_count_fallback(self):
        self.assertEqual(get_expected_question_count("9701", "19"), 40)
        self.assertEqual(get_expected_question_count("0620", "25"), 40)
        self.assertEqual(get_expected_question_count("0455", "14"), 30)


if __name__ == "__main__":
    unittest.main()
