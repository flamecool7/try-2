from __future__ import annotations

import io
import os
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.progress_ui import PlainProgress, format_postfix, paint  # noqa: E402


class TestProgressUI(unittest.TestCase):
    def test_plain_progress_contract(self):
        p = PlainProgress(3, "ExamVoid")
        with p:
            p.update()
            p.set_postfix_str("OK 1")
        self.assertEqual(p.done, 1)

    def test_postfix_contains_all_statuses(self):
        text = format_postfix(4, 1, 2, "9701_s24_22", enabled=False)
        self.assertIn("OK 4", text)
        self.assertIn("FAIL 1", text)
        self.assertIn("REVIEW 2", text)
        self.assertIn("LAST 9701_s24_22", text)

    def test_color_can_be_disabled(self):
        self.assertEqual(paint("OK", "\\x1b[92m", False), "OK")


if __name__ == "__main__":
    unittest.main()
