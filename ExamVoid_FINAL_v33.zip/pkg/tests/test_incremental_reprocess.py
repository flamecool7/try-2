"""Incremental-input and trust-self control-plane regressions.

These tests intentionally inspect SQLite/state/staging only.  They do not add
anything to the canonical question metadata schema.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))


class TestDatabaseInputSync(unittest.TestCase):
    def test_new_ms_requeues_completed_qp_only_bundle(self):
        from core.database import Database

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            qp = root / "9701_s24_qp_22.pdf"
            ms = root / "9701_s24_ms_22.pdf"
            qp.write_bytes(b"qp-v1")
            db = Database(root / "pipeline.sqlite")
            qid = db.register_file(qp, "qp", "9701", "s", "24", "22", "STRUCTURED")
            bid, changed, reason = db.sync_bundle_inputs(
                "9701_s24_22", "9701", "Chemistry_9701", "A-Level",
                "s", "24", "22", "STRUCTURED", qid, None, None,
            )
            self.assertTrue(changed)
            self.assertEqual(reason, "new bundle")
            db.mark_bundle_complete(bid, 40, 40)

            # The MS is pasted later; preflight registers it and refreshes the
            # existing logical bundle instead of skipping it by bundle_key.
            ms.write_bytes(b"ms-v1")
            mid = db.register_file(ms, "ms", "9701", "s", "24", "22", "STRUCTURED")
            bid2, changed2, reason2 = db.sync_bundle_inputs(
                "9701_s24_22", "9701", "Chemistry_9701", "A-Level",
                "s", "24", "22", "STRUCTURED", qid, mid, None,
            )
            self.assertEqual(bid2, bid)
            self.assertTrue(changed2)
            self.assertIn("MS", reason2)
            self.assertEqual(db.bundle_status("9701_s24_22"), "pending")

            # No input change means no second requeue.
            _, changed3, reason3 = db.sync_bundle_inputs(
                "9701_s24_22", "9701", "Chemistry_9701", "A-Level",
                "s", "24", "22", "STRUCTURED", qid, mid, None,
            )
            self.assertFalse(changed3)
            self.assertEqual(reason3, "unchanged inputs")


class TestStateInputSync(unittest.TestCase):
    def test_json_state_requeues_when_ms_appears(self):
        from core.pipeline_state import PaperStatus, PipelineState

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            qp = root / "qp.pdf"
            ms = root / "ms.pdf"
            qp.write_bytes(b"qp-v1")
            state = PipelineState.load_or_create(root, "Chemistry_9701", "9701", "A-Level")
            state.register_paper("9701_s24_22", str(qp), None, None)
            state.mark_complete("9701_s24_22", 40, 40)
            state.save(root)

            ms.write_bytes(b"ms-v1")
            state2 = PipelineState.load_or_create(root, "Chemistry_9701", "9701", "A-Level")
            state2.register_paper("9701_s24_22", str(qp), str(ms), None)
            self.assertEqual(state2.papers["9701_s24_22"].status, PaperStatus.PENDING)
            self.assertFalse(state2.should_skip("9701_s24_22"))
            self.assertEqual(len(state2.papers["9701_s24_22"].input_fingerprints["ms"]), 64)


class TestReplaceCommit(unittest.TestCase):
    def test_requeued_bundle_can_replace_changed_outputs(self):
        from core.staged_writer import StagedWriter

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            writer = StagedWriter(root)
            old = root / "A-Level" / "Chemistry_9701" / "P2" / "Topic" / "Q1.txt"
            old.parent.mkdir(parents=True)
            old.write_text("old")

            staging = writer.get_staging_path("9701_s24_22")
            (staging / "A-Level" / "Chemistry_9701" / "P2" / "Topic" ).mkdir(parents=True)
            src = staging / "A-Level" / "Chemistry_9701" / "P2" / "Topic" / "Q1.txt"
            src.write_text("new")
            self.assertTrue(writer.commit(
                "9701_s24_22", staging,
                [(str(src.relative_to(staging)), str(old))],
                replace_existing=True,
            ))
            self.assertEqual(old.read_text(), "new")


if __name__ == "__main__":
    unittest.main()
