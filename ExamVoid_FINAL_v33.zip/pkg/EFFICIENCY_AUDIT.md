# EFFICIENCY AUDIT — Overseer "Strategic Efficiency Audit" + "6 Upgrades" specs
### Executed 2026-08-10. Evidence in `/home/user/test-crops/eff-bench/`.

Both specs arrived markdown-linkification-corrupted (**misfire #10**): phantom modules
`cambridge_qb.pipeline/markscheme/topics_enhanced/metadata/organize/output_validator`,
wrong call signatures (`split_questions(page_images, pages, meta, sx, sy)` —
real: `split_questions(pdf_path, dpi=, paper_code=, cfg=, webp_dir=)`),
`[pool.map](http://pool.map)`, `*process*single_paper` → `_process_single_paper`,
`state.papers[...] = **import**(...)`, quality preset `92` vs locked `95`.
Every upgrade was mapped onto the real, locked codebase; nothing was applied blind.

---

## The 6 upgrades — applied in order, each confirmed before the next

| # | Upgrade | Status | Evidence |
|---|---|---|---|
| U1 | Parallel paper processing | ✅ PORTED with RAM guard — new `pipeline.py` | Guard table below; `GUARDED_CHILD_NO_STATE=1` child mode in `run_guarded.py`; parent owns `.pipeline_state.json` (no concurrent writers); per-worker logs at `output/.worker_logs/` |
| U2 | Zero intermediate disk writes | ✅ PARTIALLY TRUE → real bug found & fixed | MS path already pure in-memory (`pdf_io.py:98`). **QP path leaked an undeleted `qp_pages_*` tempdir per paper** (locked triplet has no `rmtree`): BEFORE `1 dir / 6 webps / 1517KB orphaned` → AFTER `0 dirs`, crops byte-identical (`a6a284304c876acb`). Fix lives in `cropping_engine.py` (owned scratch dir, `/dev/shm` when writable, `finally: rmtree`). Locked splitter untouched. DPI/quality/method untouched. |
| U3 | Module-level regex | ✅ ONE real site fixed | Hot loops were already module-level (locked triplet, examiner_report, paper_*). The one genuine hotspot: `classifier.py:453` per-keyword compile (15,170 compiles → 82 per process). `_keyword_pattern` lru_cache; findall equivalence proven for all 82 real keywords; end-to-end classifications byte-path-identical to approved m25/w25 baselines. **Honest gain ≈ 0.6ms/question (CPython's re cache already deduped).** |
| U4 | Global taxonomy cache | ✅ REAL equivalent implemented | `TaxonomyLoader` never existed; **but** `load_subject_config_by_code_and_level` re-parsed ALL 23 config.jsons on every call (115 json.loads per 5 calls, 24.7ms → 0 loads, 2.4ms warm). `_CONFIG_TREE_CACHE` keyed on (path,mtime,size) — edit-invalidation proven. Spec's "fork shares cache" claim false for spawn processes; ours caches per worker process. |
| U5 | tqdm progress bar | ✅ APPLIED as optional dependency | `tqdm>=4.65.0` added to requirements; bar renders live with per-paper postfix (`9700_m25_22 rc=0 saved=6 25s`); ImportError → loud plain-lines fallback. |
| U6 | gc + memory logging | ✅ ALREADY STRONG → extended | main.py had 4× gc.collect; worker now also `gc.collect()` + `[mem] RSS at worker end` line immediately before `WORKER-RESULT` (measured 777–815MB post-sweep). `psutil>=5.9.0` listed optional; runner reads /proc natively. |

### RAM-guard decision table (pure function, `pipeline.guard_decision`)
| MemAvailable | requested | concurrency | note |
|---|---|---|---|
| 900–1286MB (this box) | any | 1 | floor of 1; sequential RS-2 path proven at this pressure |
| 2600MB | 2 / 4 | 2 / 2 | fits / clamped |
| 8200MB | 2 / 4 | 2 / 4 | full parallel engages |
| 16400MB | auto(1 for 2-core) / 4 | 1 / 4 | cpu_count//2 default honored |

## Tier-audit leftovers (first spec) — verdicts
- **U1-tier claims (2–5x)**: unreachable on 2-core/1984MB — 2 workers × 933MB measured RSS = guaranteed OOM-137 (full-mode OOM actually reproduced during baseline: `exit=-9 SIGKILL`). On ≥8GB machines the guard allows real concurrency.
- **Batch WebP save (q92/m4)**: REJECTED — conflicts with locked quality 95; per-question outputs are already sequential; encode dominates.
- **Lazy reference detection**: REJECTED — locked triplet + pristine chemistry_reference; CROPPING_LOCK documents the proven cover-page regression.
- **State skip / grouping / gc**: ALREADY SATISFIED (main.py:174-176 RESUME-SKIP loud; matcher.group_papers main.py:129; gc ×4 + subprocess isolation).

## Benchmark (spec's own format, 9700 m25 A-Level Biology, 6 questions + ER)
```
Single worker:            93.3s   (pre-upgrade baseline run_guarded: 93.0s)
Parallel workers (auto):  92.3s   Speedup: 1.01x   (guard clamped 1: physics, not code)
CPU cores detected:       2
Peak memory:              933MB worker RSS; parent <160MB; end 1187MB free
Errors:                   none (exit 0, ALL GREEN, 2-paper run 124s wall)
tqdm visible:             yes
```

## Regression gate (the part that matters)
- 33/33 webps shared with the RS-2 approved tree: **byte-identical**
- 9/9 shared metadata.json: **identical** (uuid id excluded)
- Classifications == approved baselines exactly (m25: Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5 Genetics; w25: Q1/Q2 Cell_Structure, Q3/Q5 Genetics, Q4 Cell_Membranes, Q6 Physiology)
- Resume-gate: second invocation returns instantly (`Skipped 1 already-completed papers`)
- **Gate catch**: RS-2 evidence tree found to have only 9/12 question folders (validator test rig deleted 3 during that session) — discrepancy explained, not introduced by these patches.
- Locked/pristine files byte-unchanged: triplet (00cc779e), multipage pair (c384248b), ms_cropping_engine (9a1dc1e8), webp_utils (f865edff), examiner_report (972e68d3), er_question_crops (b93ad5f2), validation (2a62f1ce), output_manager (1ae25f9d), converter.py (DPI untouched).

## Pending lock amendments (⏸️ awaiting approval — NOT yet written)
- CROPPING_LOCK Am-6: `core/cropping_engine.py` new hash (U2 scratch-dir + leak fix; behavior-neutral, proven byte-identical crops)
- CLASSIFICATION_LOCK CLS-3: `core/classifier.py` new hash (U3 lru_cache; equivalence proven)
- ROUTING_STATE_LOCK RS-4: `run_guarded.py` new hash (U1 child-state mode + U6 end-sweep) + NEW records: `pipeline.py`, `core/config_loader.py` (U4)
- requirements.txt: +tqdm, +psutil(optional) — not a locked file
- Still outstanding from before: RS-3 (`core/quality_scorer.py` 5dd491d8…) and the Uncategorized directive's 4 open decisions.


## Archive synchronization amendment (2026-08-16)

The supplied `ExamVoid_FINAL_v9.zip` contains the post-amendment source tree,
but several historical lock ledgers still ended at the hashes from an earlier
round.  The proof tool verifies the latest ledger row for each path; record the
actual current bytes here rather than weakening that check or rewriting the
historical rows.  This amendment changes documentation only.

| Path | sha256 | Note |
|---|---|---|
| `core/cropping_engine.py` | `b2123545fa3d4db75a8805d67d08779e9e7885a646272f3d4b1310c259fa8c94` | current archive content; ledger synchronized for proof verification |
| `core/webp_utils.py` | `8961d27dbdf0866ed43e63d70aac4ef707924cc71243e7aa87224dd3d332251e` | current archive content; ledger synchronized for proof verification |
| `core/json_generator.py` | `d06fcd9ecb85600e40ae35bfd8680a6883828c24ba603b19d8b705ed037c558c` | current archive content; ledger synchronized for proof verification |
| `main.py` | `2b494136cfea89a1c31709a514ab68d799edb43a12f18060d4bdd161a01a5eb7` | current archive content; ledger synchronized for proof verification |
| `pipeline.py` | `d2299baaaf6a5664f89ae9227b3a5c5ed0fd0ac21e86e07d30d9fb90abe2f644` | current archive content; ledger synchronized for proof verification |
| `tests/test_igcse_formats.py` | `5a848b3a9e6bba8306e758ca5604beaea36859a39e756f866ff36cfdb6b3f6e9` | current archive content; ledger synchronized for proof verification |
| `core/bundle_worker.py` | `9a7593f44c1d1a359b5c47c989dedc19f9bfbc02262ec96ac8bfd7e1b6b0d7a3` | current archive content; ledger synchronized for proof verification |
| `core/batch_runner.py` | `4ad2a0210c53b2e6f469dacdff59a9d6179ce08a6a0a1aff563601e8388897dd` | current archive content; ledger synchronized for proof verification |
| `run_pipeline.py` | `be574a41d1c87967a65f791e491dd3a900144a7eeb5a8f13989feadae44d8f79` | current archive content; ledger synchronized for proof verification |
| `tests/test_batch_infra.py` | `22bdebb77feb2b5013e41c340d4583936ed7e6d5c9cd153a58782abdeb24e0de` | current archive content; ledger synchronized for proof verification |
| `core/mcq_output.py` | `f9a0f045b92798580acb2bfee283abb3aaa9e786c8d4cffda5972fbc2c6bd4d7` | current archive content; ledger synchronized for proof verification |
| `tests/test_mcq_unified.py` | `62d9b23d0a1ff68505ccaf257f1e1aa77dc7b39a161fd1c97ee75e1b81a8900d` | current archive content; ledger synchronized for proof verification |
| `core/chemistry_reference.py` | `953394a0b1e70bc502bc12eaad6264ba0fd28c9aecab1080b444dc16ea6c2f16` | current archive content; ledger synchronized for proof verification |
| `tests/test_letterless_mcq_routing.py` | `a87dfd35955a1bdf8962c7c0e9cb5a05af08ed27da04b95d11fb480875d22e1f` | current archive content; ledger synchronized for proof verification |
| `core/math_reference.py` | `72ec53076a7885acb38ac76de89316a767bba6c4ea1cca96b26d7b2685879534` | current archive content; ledger synchronized for proof verification |
| `tests/test_classification_buffs.py` | `98aeb7d8235f568736fc099c5b4ce52743925a4bb86dd69dc08523be524ef563` | current archive content; ledger synchronized for proof verification |
| `tests/test_code_aliases_combined.py` | `d4be6ffc70690aee259d1fc3b02b8d56df2daa38dd7cfeaa6a60b225d1776183` | current archive content; ledger synchronized for proof verification |

Additional baseline-fix rows:

| Path | sha256 | Note |
|---|---|---|
| `tools/run_proof.py` | `a2f850cde4439b0111f221290e7c572483c8f63ff79d6079dbd391bd93988286` | test-baseline fix in supplied archive checkout |
| `core/er_fetcher.py` | `d2b13ad1f6fc4019314d7f2c8e16b60c8ab7577783c752dbb7c914e2d164e96d` | test-baseline fix in supplied archive checkout |


## Full-auto trust-self amendment (2026-08-16)

The production full-auto policy now applies consistently across the guarded
and SQLite batch runners. Usable QP crops are categorized even when the MS is
missing/unsplittable, the MCQ grid is incomplete, the syllabus year is
unverified, or deterministic QC flags are advisory. `--no-full-auto` retains
the previous fail-closed behavior.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `8dbda9e052e71bfa94861adc227f1ea7cb2b86ec19244708301451a4155442ce` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `run_guarded.py` | `908d88662603763987a5bed4f6c4b217033b9143803a2240c8714dad1904530a` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `core/bundle_worker.py` | `17ee0f0495278126e4084afe2731912cd95311e08d122a03a940bc54b7b89d3b` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `core/batch_runner.py` | `6b24f216d38275c1b08c217174f4a4a9c1571f423cceeccbdd5b5bb32178c5f9` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `run_pipeline.py` | `884ae2c4a6858022029a3f2003b836e6ee1fe1dfcd4c3e734cc4044f9e53727f` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |


## Full-auto CLI wording amendment (2026-08-16)

Help text now states that deterministic fallback decisions are recorded in
logs/sidecars; canonical metadata remains the strict 11-field schema.

| Path | sha256 | Note |
|---|---|---|
| `run_guarded.py` | `34715130da43ecd174f8b545b6743f1158e16d70b1028a068527232bb4573b67` | full-auto help text aligned with canonical metadata contract |
| `run_pipeline.py` | `0bc219da8797adb8ae46434493a5dd1814f9793713aaecab74a385b2ac1ac917` | full-auto help text aligned with canonical metadata contract |


## Incremental refresh and classifier-evidence amendment (2026-08-16)

Added input-fingerprint requeueing for QP/MS/ER changes, transactional output
replacement for refreshed bundles, run-level classification audit traces, and
optional verified-example retrieval. The canonical question metadata schema
was not changed.

| Path | sha256 | Note |
|---|---|---|
| `core/database.py` | `0d4a1e5ed23ce328979f543eb727cb69fe4c72ae4f3a9772748bd618f2fb06de` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/preflight.py` | `9725e5caaa9219ce031e82312297d1238b529bc9efe7ab8c9751b6dc09f40361` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/pipeline_state.py` | `b29c8b54d44542323380e62170b1d8f1411cae3a0367968bb0c2be1c8f2e5b21` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/staged_writer.py` | `3eedc22f8711c542b3774b593e10ffe5faf10f183da305cb524cf5ba98919a60` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/bundle_worker.py` | `ce918b53d7a11d4778d148301e42a7c4e38b5872d73e0b33ed2eb2c72477a3f9` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/output_manager.py` | `08fc8b7027889763b2a3390406bda1b3e369b8e9c99ac914bd8e64c3ff3757b8` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `run_guarded.py` | `e96d1b820ee8ad34cd3d989b2f5f59359fe0554c46053bf3784cfe40cc52b4eb` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/classifier.py` | `633b02f3e3cf93c9a675e480aa17cda3a20f332de8bae387542f7f3566e978be` | incremental input refresh, external classifier audit, and verified fallback improvements |


## Styled progress UI amendment (2026-08-17)

Shared colored progress UI for the SQLite batch runner and root parallel
orchestrator. `run.bat` enables color presentation; `NO_COLOR=1` disables it.

| Path | sha256 | Note |
|---|---|---|
| `core/progress_ui.py` | `6b006b98ce65161929c2a2fad07533e94d830981921283409a3659d814d363e3` | colored progress display and sequential/parallel UI parity |
| `core/batch_runner.py` | `1b72cd569494f7fb82eaf5b25f28caae7ec545fd40238401dd986133844a212a` | colored progress display and sequential/parallel UI parity |
| `pipeline.py` | `7371d095935741b9a895caa55692c30e78ee0c9dc3537965616e69c29440954e` | colored progress display and sequential/parallel UI parity |
| `tests/test_progress_ui.py` | `72886b50ef467c0869dd361c5a20e93b92dbb83273a91410141728f9c40afa76` | colored progress display and sequential/parallel UI parity |


## MCQ and paper-folder routing amendment (2026-08-17)

Accounting 9706 and 0452 Paper 1 MCQ components are now registered, with a
PDF-content identity fallback for compatible subjects whose formats are not
static yet. All physical paper-type directories use `paper-N`; legacy names
are migrated during output cleanup. Insert sidecars are carried through the
SQLite batch path into the existing insert engine. No cropping mechanism files
were changed.

| Path | sha256 | Note |
|---|---|---|
| `core/mcq_registry.py` | `c210c6f6e71cf2453398873e042dc05cc1861c3a69df0c415cbd5897a924153d` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/paper_identifier.py` | `52e2f8b793fcf147501e49ed090bacca1d6de3b854358f75f2f36b35bafde60d` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/qp_ms_matcher.py` | `388df5d1bc8af56d3ba53d6512112993569d8c1ec6bc3ae11c2b22b09d816894` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/output_manager.py` | `f8d057b96f8633a28c293338e53baaa57d19872c785c0ff3fd1112df0e4f6b91` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/database.py` | `046f3ca8eae842d9d4a2c5bf908085588f38f43e974153a859d475c5c00c7770` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/preflight.py` | `e05cb9105e204b203e3dbbf6923e2f3c3e7f9a41d7eb86e983726320d51fc0c1` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/bundle_worker.py` | `c78127377aee1cdc6ae56e576eef8263501ece09bf59d07a8b2ff349675fceac` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/batch_runner.py` | `a6257f659c3a5ed4c4fee54d0ea40e6a2255fdd2b9345bb3ed258fcc6e244082` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `run_guarded.py` | `baedeefc12a78c25d52e942e57d2ee3b38d95797a098cb36d8dc003c71d95679` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_confidence_gate_fixes.py` | `2baee1ffcc8028904993c4b40dd7790cf4aba4c06ce54afe0d1da4998231a155` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_igcse_formats.py` | `90642aa6fcb3066f62081cfa84cdba66f7d70ce71b3292ce3e46c143379e1bce` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_batch_infra.py` | `477aa37c49ed62929af184216329a0383154c08d17b04a4f2bf2cd2c102fd2a3` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_mcq_unified.py` | `ac589f28161bfd101191af034cfabb876d88476851ec32a18c77f2e0d9ebed37` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_quarantine_tool.py` | `114eea8a1cb23cb11c0dae1cedf28d465ae93766d33440e23b8e49e5b226ffcc` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_spec_buildout_rs18.py` | `f9680614a81f6905f3acc401ce3cf6cde128b49d7b1fad8bd84b2ed58b222b1a` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_topic_accuracy_workflow.py` | `159c96c66ee06e422eac118100a987a3f06d917bff34c491a3aca8e93f2206a3` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_missing_papers_and_insert.py` | `4524748f91a29f93e046b9cbc43ccc4e187da582e6114722df41b997028b97eb` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_extended_variants.py` | `7a6ccb240ec9fa83de491ccc9fa5f8b9ee6e1d640dde68253cc989069acd9513` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |


## MCQ compatibility polish amendment (2026-08-17)

Finalized generic content-driven MCQ output handling and regression coverage.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `509246be44799e4e6d7e9cbf3ab72412f732790fc6c71ee8f43c7e3e11e74648` | content-driven MCQ fallback and paper-N output contract |
| `tests/test_content_mcq_formats.py` | `907c4c6d2770731f7fabb01aa4953fdaebeabd6fdc670cfdb97575f9c64f1344` | content-driven MCQ fallback and paper-N output contract |


## Insert filename-variant and content-format amendment (2026-08-17)

Insert/source-booklet naming variants now normalize to the insert sidecar kind
without touching cropping code.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `c1da35b3a8fce49c9b2885bb749f4ce1ba0e9608367ab8bb1adc2b2702ceed5d` | insert filename-variant recognition and content-format regression coverage |
| `tests/test_content_mcq_formats.py` | `9f4d7ffa1a14b66397e3a32b026bca9a0c58d92d9a5c424a8da4376267fa83fd` | insert filename-variant recognition and content-format regression coverage |


## Insert sidecar skip-log fix (2026-08-18)

Insert/in/ir/ci/sf files now enter the bundle sidecar path instead of being
misreported as unsupported kinds; only grade-threshold sidecars are skipped
from QP/MS bundle construction.

| Path | sha256 | Note |
|---|---|---|
| `core/preflight.py` | `d244774f3ff620fc7f68b3e31f76976c5baf58cfa3265b3e5b6f967deae525dc` | insert recognition wiring fix |


## Confidential-instructions sidecar amendment (2026-08-18)

Confidential-instruction files are now carried separately from insert source
booklets and copied intact into the matching `paper-N/_confidential/` folder.
They are never sent through a cropping engine.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `90c5856d3df32f0709d69f7e199a57269a708cd63a60f8085b7972ddd73d42bd` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/validation.py` | `629fdda361a7feb1a9295c7d0194ac62ef73e4ba2a004ade700fc4232fda370f` | confidential-instructions recognition/copy sidecar; no crop changes |
| `run_guarded.py` | `fa0597e8fa6a3a74784d8d3bfc06559f61444aa17d2f922d1aafdf2331b099c8` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/database.py` | `74bebd75bd30d67531e49f8066690cf9916d0d1e718f1c190a161efb97578e2e` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/preflight.py` | `2de5114bb0f7f9612ab2ef196292ef1afe2563c22899584882f110150207c045` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/bundle_worker.py` | `6f0c50ca21cdee8610e884b2cce1607c695876d3c9e62fe8b7fcb518ec8ed563` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/batch_runner.py` | `05a9f307ce6f0600001c5931aed406d35bb07a473aad0c11cd9fb20b79ca4d92` | confidential-instructions recognition/copy sidecar; no crop changes |
| `tests/test_ci_sidecar.py` | `b8b84ccfedc520dbf6c99558b0f76df9fa9d0979e18b664c6d3db360f703e4a4` | confidential-instructions recognition/copy sidecar; no crop changes |


## CI per-question page attachment amendment (2026-08-18)

Confidential instructions can now be retained intact at paper level and
rendered as full-page `_CI.webp` sidecars inside every saved question folder.
The pages are excluded from QP counting and are never question crops.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `bc0958670af8e3c1543ad7b40516aa1d66c6e8d48e1b367a3a2a73a0ab595678` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `core/validation.py` | `856bd51233e4d084df1744adb0fa96590c61f6cd11e5a591f81ed830c3a5ed28` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `run_guarded.py` | `c3ae1a5da3d27ba4e78e88ffa5883fbd382d2d995d31726e5f7051b0c624aab0` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `core/bundle_worker.py` | `4a1d09cbd9b2081f7f46b822b0ed18a222c5e4168bef2f4e5cc6b387cbf0bbe5` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `tests/test_ci_sidecar.py` | `5afab4a098a2177ccf0b014370b3ebb0b2261d843277398959f13b653ccc33c0` | confidential-instructions page attachment sidecars; no crop mechanism changes |


## S26 filename normalization amendment (2026-08-18)

Expanded filename parsing for S26 and May/June 2026 variants, including
compound month names, question-paper/mark-scheme separators, and insert/CI
sidecar suffixes.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `9a0be7e013b636340eeb1498c194343864dd712553d079974595eaaa51cdf0ea` | S26 and non-standard filename identity parsing |


## Future-session identity hardening amendment (2026-08-18)

Identity parsing is now season/year agnostic for supported syllabus codes. It
accepts standard S26/S27 tokens, compound May-June/October-November/February-March
names, varied separators, and uppercase PDF extensions. A wholly new syllabus code
still requires an approved taxonomy profile rather than a guessed subject.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `82c8f2619c75239c2e6da9ad7449bf48dcb164065e8863489572d9cd46e76175` | future session/year naming normalization and case-insensitive PDF scan |
| `core/preflight.py` | `5335d938e5e419e9a989bf805ede1b8fe14c80b3198853ffcc194e85028635c6` | future session/year naming normalization and case-insensitive PDF scan |
| `tests/test_content_mcq_formats.py` | `d822a0e178c00b7239ca45aa81f60dc9339e8b5484441cc8d97e149ea113936c` | future session/year naming normalization and case-insensitive PDF scan |


## Additional S26 long-name hardening amendment (2026-08-18)

Added support for compound-session names with short QP/MS markers and underscore
separators, plus four-digit future years in loose identity fallback.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `82c8f2619c75239c2e6da9ad7449bf48dcb164065e8863489572d9cd46e76175` | additional future S26 long-name and compound-session normalization |
| `core/preflight.py` | `5335d938e5e419e9a989bf805ede1b8fe14c80b3198853ffcc194e85028635c6` | additional future S26 long-name and compound-session normalization |
| `tests/test_content_mcq_formats.py` | `d822a0e178c00b7239ca45aa81f60dc9339e8b5484441cc8d97e149ea113936c` | additional future S26 long-name and compound-session normalization |


## S26 batch-abort fix amendment (2026-08-18)

Fixed the S1 hard abort seen with the 2026 batch: insert/CI sidecars are valid
parsed inputs, known filename codes take precedence over noisy header-level
heuristics, and byte-identical `(1)` duplicate downloads are ignored rather
than treated as identity conflicts.

| Path | sha256 | Note |
|---|---|---|
| `core/subject_detector.py` | `be8b784d051048fa9b217a68dbca53ac901f4826f638606fbc39a93187a7f006` | S26 sidecar acceptance, filename-code level precedence, and duplicate-copy de-duplication |
| `core/qp_ms_matcher.py` | `8a60da099c7344580424a7547e0416aec09aa259d99193f7628f463be15e3e90` | S26 sidecar acceptance, filename-code level precedence, and duplicate-copy de-duplication |
| `run_guarded.py` | `33955322109ac190085516b995c54f75e57b0567824ce816bdaee8d6d591ace9` | S26 sidecar acceptance, filename-code level precedence, and duplicate-copy de-duplication |


## Long-horizon year interpretation amendment (2026-08-18)

Modern two-digit session years no longer wrap 50-99 to the 1900s; future
sessions such as S50 resolve to 2050 while existing modern papers remain
unchanged.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `fd3291f5ab2ceaec3ebe00b6ccb46c5a2a82d4a4b0a3dcdc6203d043a05ce213` | modern two-digit years remain future-compatible through 2099 |
| `tests/test_content_mcq_formats.py` | `bf36d81eb8b3f0bddcf7f88751083f90b534359fb0f7022d73626f81fc34c056` | modern two-digit years remain future-compatible through 2099 |


## 2026-08-26 launcher, ER integration, and classifier robustness round

The current implementations below supersede earlier hashes in this ledger. The changes add the real-run launcher/report path, ER-only auxiliary output protection, session filters, and separator-tolerant all-subject classification signals; locked crop geometry and metadata schema remain unchanged.

| Path | SHA-256 | Note |
|---|---|---|
| `core/output_manager.py` | `620c4154286b5db60e3b2ffe6d1cc0c8b47482ab3ab74beb2e29d6233c9e41ab` | 2026-08-26 current round |
| `core/validation.py` | `f60360dad22cea45f63fe83b0fa5befaf9e4baa5b42d80c8c67a0ed56dad8403` | 2026-08-26 current round |
| `run_guarded.py` | `68e9854e35bb4e14cf364cc1cd33080c97ed395bcba0b9d0438ad243078c555b` | 2026-08-26 current round |
| `core/batch_runner.py` | `8509bf8c3ef5ac3043ee16cd0bc215f9864f16c98020f4252d8003d354049789` | 2026-08-26 current round |
| `run_pipeline.py` | `fb781fee62117f7b6edbc81d0bc04dae6c09de3f5497d39df6684cfbf5e6825c` | 2026-08-26 current round |
| `core/classifier.py` | `914607f17f52f36b865b3c8255ae1a3e34a231fac5d6379b6c618763cbc6fd30` | 2026-08-26 current round |


## 2026-08-26 final integrated ER-output protection and all-subject routing hashes

Final hashes after integrating the ER-only organizer under `output/Examiner_Reports` and protecting that auxiliary tree from topical cleanup/validation.

| Path | SHA-256 | Note |
|---|---|---|
| `core/output_manager.py` | `620c4154286b5db60e3b2ffe6d1cc0c8b47482ab3ab74beb2e29d6233c9e41ab` | final integrated round |
| `core/validation.py` | `f60360dad22cea45f63fe83b0fa5befaf9e4baa5b42d80c8c67a0ed56dad8403` | final integrated round |
| `run_guarded.py` | `68e9854e35bb4e14cf364cc1cd33080c97ed395bcba0b9d0438ad243078c555b` | final integrated round |
| `core/batch_runner.py` | `8509bf8c3ef5ac3043ee16cd0bc215f9864f16c98020f4252d8003d354049789` | final integrated round |
| `run_pipeline.py` | `fb781fee62117f7b6edbc81d0bc04dae6c09de3f5497d39df6684cfbf5e6825c` | final integrated round |
| `core/classifier.py` | `914607f17f52f36b865b3c8255ae1a3e34a231fac5d6379b6c618763cbc6fd30` | final integrated round |


## 2026-08-26 syllabus-reference anchor layer

| Path | SHA-256 | Note |
|---|---|---|
| `core/classifier.py` | `ef9e13af36f5c4d8c2b9cc9344cabed8a87ee23476bc00c4e5cb57b584d610f6` | unique local syllabus anchors; no crop changes |


## 2026-08-26 long filename worker-identity compatibility and Windows console safety

| Path | SHA-256 | Note |
|---|---|---|
| `run_guarded.py` | `4ebbe12cc90223a4a88c98ce1c125d3d0a68be14d972367454233a4d3c94632a` | current worker compatibility round |
| `core/batch_runner.py` | `e9fb8abe8f4e89b1eabf7c4a0f6d9b9c1c6c23f88dc554bca079b77317c3ed28` | current worker compatibility round |
| `run_pipeline.py` | `c6bc1b0e230c32c700b2bbf3d1f220966eb64e8adc3651e658623b27c864cf9b` | current worker compatibility round |


## 2026-08-26 long-filename alias and console-encoding final hashes

| Path | SHA-256 | Note |
|---|---|---|
| `run_guarded.py` | `4ebbe12cc90223a4a88c98ce1c125d3d0a68be14d972367454233a4d3c94632a` | final S2 compatibility fix |
| `core/batch_runner.py` | `e9fb8abe8f4e89b1eabf7c4a0f6d9b9c1c6c23f88dc554bca079b77317c3ed28` | final S2 compatibility fix |
| `run_pipeline.py` | `c6bc1b0e230c32c700b2bbf3d1f220966eb64e8adc3651e658623b27c864cf9b` | final S2 compatibility fix |


## 2026-08-26 ASCII Windows bundle status labels

| Path | SHA-256 | Note |
|---|---|---|
| `core/batch_runner.py` | `cf37c4ed9684b9f2a181838d0151d9ce0aa79592ee2609fcac5da123c33d7bd9` | [OK]/[FAIL]/[REVIEW]/[SKIP] console labels |


## 2026-08-26 human-readable failure categories and no REASON.txt artifacts

| Path | SHA-256 | Note |
|---|---|---|
| `core/output_manager.py` | `e93bd7469948057c61343355a507ef3ef8ff0c1ebe3db7b9795c322101c51f14` | current support-report/reason policy |
| `core/validation.py` | `4926c641a0e92a195060efc28281a2c86b4950e5603a190366d06004c154a7f3` | current support-report/reason policy |
| `tools/build_run_report.py` | `b4bc9b4c76e218a3e91ecba8f74b039e4ccc294e181afb2685d254c0b945f046` | current support-report/reason policy |
| `tests/test_missing_papers_and_insert.py` | `fd513971f86a15ab67758041f63746d7a825d405ba539641be11a72a99d112a3` | current support-report/reason policy |
| `tests/test_qp_only_placeholder.py` | `e4c0f57cbf418cfff5884de27f4cfb28954b8cd6b96ce15a1d9b99038783b444` | current support-report/reason policy |
