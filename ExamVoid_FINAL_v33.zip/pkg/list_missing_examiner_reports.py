#!/usr/bin/env python3
"""Write a plain-text report of examiner reports that were not downloaded.

Run from the downloader folder after the archive downloader finishes:

    python list_missing_examiner_reports.py

It reads examiner_reports_2020_2025/MANIFEST.json and writes:

    missing_examiner_reports.txt

If only a dry-run was performed, it reads CANDIDATES.json and reports that the
slots have not been attempted yet. No network access is used.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

SENTINEL_STATUSES = {"missing", "rejected", "error", "unavailable"}


def _candidate_source_lines(row: dict) -> list[str]:
    lines = []
    for candidate in row.get("candidates", []) or []:
        source = candidate.get("source", "unknown")
        url = candidate.get("url", "")
        if url:
            lines.append(f"      - {source}: {url}")
    return lines


def _format_missing(row: dict, index: int) -> list[str]:
    return [
        f"{index}. {row.get('path', '(unknown filename)')}",
        f"   status:     {row.get('status', 'missing')}",
        f"   source:     {row.get('source') or '(none verified)'}",
        f"   validation: {row.get('validation') or '(no validation details)'}",
        *(_candidate_source_lines(row)),
        "",
    ]


def write_report(folder: Path, output_path: Path) -> tuple[int, int]:
    manifest_path = folder / "MANIFEST.json"
    candidates_path = folder / "CANDIDATES.json"
    lines = [
        "ExamVoid — Missing Examiner Reports",
        "====================================",
        f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
    ]

    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        files = list(manifest.get("files", []))
        missing = [row for row in files if str(row.get("status", "")).lower() in SENTINEL_STATUSES]
        # Also verify the archive on disk. This catches reports that the
        # downloader recorded as successful but that were later moved, deleted,
        # or extracted into the wrong folder.
        for row in files:
            if str(row.get("status", "")).lower() != "downloaded":
                continue
            relative = row.get("path")
            actual = folder / relative if relative else None
            if actual is None or not actual.is_file() or actual.stat().st_size < 10_000:
                missing.append({
                    **row,
                    "status": "missing_on_disk",
                    "validation": "Manifest says downloaded, but the PDF is absent or too small on disk.",
                })
        summary = manifest.get("summary", {})
        lines.extend([
            "The following report slots were not downloaded and verified, or are missing from disk.",
            "",
            f"Profiles scanned : {summary.get('profiles', 'unknown')}",
            f"Slots attempted  : {summary.get('slots', len(files))}",
            f"Downloaded       : {summary.get('downloaded', 'unknown')}",
            f"Missing          : {len(missing)}",
            "",
        ])
        if not missing:
            lines.append("SUCCESS: No missing examiner reports were recorded and all downloaded files exist.")
        else:
            lines.append("MISSING REPORTS")
            lines.append("----------------")
            for index, row in enumerate(sorted(missing, key=lambda r: r.get("path", "")), 1):
                lines.extend(_format_missing(row, index))
        count = len(missing)
        attempted = len(files)
    elif candidates_path.exists():
        candidates = json.loads(candidates_path.read_text(encoding="utf-8"))
        lines.extend([
            "Only a dry-run candidate manifest was found.",
            "No downloads have been attempted yet.",
            "",
            f"Candidate report slots: {len(candidates)}",
            "",
            "CANDIDATES NOT YET ATTEMPTED",
            "---------------------------",
        ])
        for index, row in enumerate(sorted(candidates, key=lambda r: r.get("filename", "")), 1):
            lines.extend(_format_missing({**row, "status": "not_attempted"}, index))
        count = len(candidates)
        attempted = 0
    else:
        lines.extend([
            "ERROR: Neither MANIFEST.json nor CANDIDATES.json was found.",
            "Run the examiner report downloader first, then run this script.",
        ])
        count = attempted = 0

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return count, attempted


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--archive-folder",
        default="examiner_reports_2020_2025",
        help="Downloader output folder containing MANIFEST.json",
    )
    parser.add_argument(
        "--output",
        default="missing_examiner_reports.txt",
        help="Text report path",
    )
    args = parser.parse_args(argv)
    count, attempted = write_report(Path(args.archive_folder), Path(args.output))
    print(f"Wrote {args.output}: {count} missing/not-attempted report(s) "
          f"from {attempted} completed attempts.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
