@echo off
setlocal EnableExtensions

rem ExamVoid Examiner Report Downloader
rem Scope: configured ExamVoid subjects, 2020-2025, public Cambridge/PapaCambridge
rem sources. Missing or inaccessible reports are recorded in MANIFEST.json.

cd /d "%~dp0"
set "PYTHON_CMD="

where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"

if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo.
    echo ERROR: Python 3 was not found.
    echo Install Python 3.10 or newer from https://www.python.org/downloads/
    echo Make sure the Python launcher or python.exe is on PATH.
    pause
    exit /b 1
)

if not exist "tools\download_examiner_reports.py" (
    echo.
    echo ERROR: tools\download_examiner_reports.py was not found.
    echo This batch file must stay in the ExamVoid project root.
    pause
    exit /b 1
)

%PYTHON_CMD% -c "import requests, fitz" >nul 2>nul
if errorlevel 1 (
    echo Required Python packages are missing. Installing them now...
    %PYTHON_CMD% -m pip install -r "requirements-er-downloader.txt"
    if errorlevel 1 (
        echo.
        echo ERROR: Could not install the downloader dependencies.
        echo Run: %PYTHON_CMD% -m pip install -r requirements-er-downloader.txt
        pause
        exit /b 1
    )
)

echo.
echo ================================================================
echo ExamVoid Examiner Report Downloader
echo ================================================================
echo.
echo This will scan the configured ExamVoid subjects for examiner reports
 echo from 2020 through 2025 and create one ZIP archive.
echo Public PDF sources only. No login, CAPTCHA, or access-control bypass
 echo is attempted.
echo.
echo Output folder: examiner_reports_2020_2025
echo ZIP file:     Examiner_Reports_2020-2025_ExamVoid.zip
echo.

if not exist "examiner_reports_2020_2025" mkdir "examiner_reports_2020_2025"

%PYTHON_CMD% "tools\download_examiner_reports.py" ^
  --output-root "examiner_reports_2020_2025" ^
  --zip "Examiner_Reports_2020-2025_ExamVoid.zip" ^
  --workers 4 %*

set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
    echo ================================================================
    echo COMPLETE: examiner report archive created successfully.
    echo Check MANIFEST.json for downloaded and unavailable reports.
    echo ================================================================
) else (
    echo ================================================================
    echo DOWNLOAD FINISHED WITH ERRORS OR NO VERIFIED REPORTS.
    echo Check examiner_reports_2020_2025\MANIFEST.json for details.
    echo ================================================================
)

echo.
pause
exit /b %RC%
