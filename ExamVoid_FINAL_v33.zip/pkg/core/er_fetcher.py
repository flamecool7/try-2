"""er_fetcher.py — online missing Examiner-Report resolver (2026-08-14).

Mirror of core/ms_fetcher.py / core/qp_fetcher.py for the examiner-report
side of the pipeline. Opt-in only via --fetch-missing-er (never automatic).
All downloads are VERIFIED before use; any verification failure lands in the
report as REVIEW — never into the pipeline. Rate limit 2s between requests.

SOURCE ORDER (contractual, same philosophy as the QP/MS fetchers):
  1. Cambridge International official past-papers page (parsed for an exact
     code/season/year examiner-report link). Note: as of 2026-08 the public
     site hosts only the June-2024 ERs, so newer sessions fall through.
  2. pastpapers.co (canonical session-dir + legacy cie paths + /download).
  3. papacambridge CAIE-pastpapers/upload direct + download_file.php.
  4. dynamicpapers.com uploads (old sessions, same host as download_fixtures).
  5. xtrapapers.co <dir>/<file>.pdf/download.
  6. papersdaddy.com <board>/<subject>-<code>/<year>-<session>/<file>.
  7. SCRIBD TIER (link-report only): Scribd hosts these documents but the
     PDF is behind their JS viewer/login — the script cannot legitimately
     auto-download it. It searches Scribd, extracts document URLs (best
     effort), and ALWAYS writes them + the search URL into the fetch report
     (er_fetch_report.txt / .json) for a human to grab. It never claims a
     scribd link as a download.

VERIFICATION (ER identity): the downloaded PDF must open cleanly, contain
the syllabus code, confirm the session (season words + year), and carry
examiner-report signals ("examiner report", "principal examiner report",
"general comments", "comments on specific questions", "for teachers").
Question papers / mark schemes / inserts are REJECTED (identity swap).

Canonical ER filename: {code}_{season}{year_short}_er.pdf  (variantless —
matches paper_identifier.EXAMINER_REPORT_PATTERN).
"""

from __future__ import annotations

import hashlib
import logging
import re
import time
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.parse import quote, urljoin

from .ms_fetcher import (
    SEASON_TO_CODE,
    MIN_PDF_SIZE,
    OFFICIAL_PAGE_SLUGS,
    REQUEST_DELAY,
    MAX_FILE_SIZE,
    MAX_RETRIES,
    REQUEST_TIMEOUT,
    Downloader,
    PDFVerifier,
    _OfficialLinkParser,
)

logger = logging.getLogger(__name__)

# ── constants ──────────────────────────────────────────

ER_SIGNALS = (
    "examiner report",
    "principal examiner report",
    "general comments",
    "comments on specific questions",
    "for teachers",
    "assessment at a glance",
)
REJECT_SIGNALS = (
    "mark scheme",
    "answer all questions",      # QP stem
    "candidate name",            # QP cover
    "read these instructions",   # QP stem
)
SEASON_PAGE_WORDS = {
    "s": ("may", "june", "summer"),
    "w": ("october", "november", "winter"),
    "m": ("february", "march", "spring"),
    "sp": ("specimen", "sample"),
}
_SUBJECT_SLUG = {
    "0610": "biology", "0620": "chemistry", "0625": "physics",
    "0580": "mathematics", "0606": "additional-mathematics",
    "0478": "computer-science", "0455": "economics",
    "0450": "business-studies", "0475": "literature-in-english",
    "0470": "history", "0417": "ict", "0460": "geography",
    "9700": "biology", "9701": "chemistry", "9702": "physics",
    "9709": "mathematics", "9231": "further-mathematics",
    "9618": "computer-science", "9708": "economics",
    "9609": "business", "9695": "english-literature",
    "9489": "history", "9626": "information-technology",
    "9696": "geography",
}
_SEASON_FOLDER = {
    "s": "May-June", "w": "October-November",
    "m": "February-March", "sp": "Specimen",
}
_REQUESTS_MISSING_MSG = "Install requests: pip install requests>=2.31.0"


@dataclass
class ERFetchResult:
    success: bool
    spec: str
    source: str
    url: str
    local_path: Optional[Path]
    sha256: Optional[str]
    error: Optional[str]
    verified: bool
    scribd_links: List[str] = field(default_factory=list)
    scribd_search_url: str = ""


# ══════════════════════════════════════════════════════
# VERIFIER (ER identity)
# ══════════════════════════════════════════════════════

class ERVerifier(PDFVerifier):
    """A genuine Examiner Report: real PDF, syllabus code present, session
    confirmed, examiner-report signals present, and NOT a QP/MS/insert."""

    def verify_er(self, pdf_path: Path, syllabus_code: str,
                  season: str, year_short: str) -> Tuple[bool, List[str]]:
        reasons: List[str] = []

        is_pdf = self._check_is_pdf(pdf_path)
        if not is_pdf:
            reasons.append("File is not a valid PDF")
            # A missing or corrupt candidate cannot be opened far enough for
            # content-based identity checks.  Still report an identity hint
            # from the filename when one is available; this makes a rejected
            # QP/MS candidate actionable instead of looking like a generic I/O
            # failure.  The filename is diagnostic only and never makes a
            # document pass verification.
            name = Path(pdf_path).name.lower()
            if re.search(r"(?:^|[_.-])(?:qp|questionpaper|question-paper)(?:$|[_.-])", name):
                reasons.append("Looks like a QP/MS, not an examiner report")
            elif re.search(r"(?:^|[_.-])(?:ms|markscheme|mark-scheme)(?:$|[_.-])", name):
                reasons.append("Looks like a QP/MS, not an examiner report")
            else:
                reasons.append("No examiner-report content available to verify")

        opens, text = False, ""
        if is_pdf:
            opens, text = self._check_opens(pdf_path)
            if not opens:
                reasons.append("PDF fails to open cleanly")
                name = Path(pdf_path).name.lower()
                if re.search(r"(?:^|[_.-])(?:qp|questionpaper|question-paper|ms|markscheme|mark-scheme)(?:$|[_.-])", name):
                    reasons.append("Looks like a QP/MS, not an examiner report")
                else:
                    reasons.append("No examiner-report content available to verify")

        if opens:
            if syllabus_code not in text:
                reasons.append(f"Syllabus code {syllabus_code} not in PDF content")
            year_4 = "20" + str(year_short)
            season_n = SEASON_TO_CODE.get(str(season).lower(), str(season).lower())
            words = SEASON_PAGE_WORDS.get(season_n, ())
            year_ok = year_4 in text or str(year_short) in text
            if season_n == "sp":
                session_ok = year_ok
            else:
                session_ok = year_ok and any(w in text for w in words)
            if not session_ok:
                reasons.append(f"Session {season}{year_short} not confirmed")

            n_er = sum(text.count(s) for s in ER_SIGNALS)
            if n_er == 0:
                reasons.append("No examiner-report signals in content")
            n_rej = sum(text.count(s) for s in REJECT_SIGNALS)
            if n_rej > n_er:
                reasons.append("Looks like a QP/MS, not an examiner report")

        passed = (is_pdf and opens and not reasons)
        return passed, reasons


# ══════════════════════════════════════════════════════
# URL BUILDER
# ══════════════════════════════════════════════════════

class ERURLBuilder:
    def __init__(self):
        self._official_pages: dict = {}

    def canonical_name(self, syllabus_code: str, season: str,
                       year_short: str) -> str:
        s = SEASON_TO_CODE.get(str(season).lower(), str(season).lower())
        return f"{syllabus_code}_{s}{year_short}_er.pdf"

    def build_all(self, syllabus_code: str, season: str, year_short: str) -> List[dict]:
        """Ordered candidate URLs -> [{source, url}]. Official is an index
        page resolved at fetch time; the rest are direct PDF patterns."""
        year_4 = "20" + str(year_short)
        s = SEASON_TO_CODE.get(str(season).lower(), str(season).lower())
        fname = self.canonical_name(syllabus_code, season, year_short)
        slug = _SUBJECT_SLUG.get(str(syllabus_code))
        lvl = "A-Level" if str(syllabus_code).startswith(("9",)) else "IGCSE"
        sfolder = _SEASON_FOLDER.get(s, s)

        candidates = []
        official = OFFICIAL_PAGE_SLUGS.get(str(syllabus_code))
        if official:
            candidates.append({
                "source": "cambridge_international_official",
                "url": f"https://www.cambridgeinternational.org/programmes-and-qualifications/{official}/past-papers/",
            })
        # pastpapers.co (canonical session dir first, then legacy cie)
        pp_base = f"https://pastpapers.co/caie/{lvl}/{slug.title().replace('-', '-')}-{syllabus_code}/{year_4}-{sfolder}/{fname}"
        for u in [
            pp_base,
            f"https://pastpapers.co/cie/{'a-level' if lvl == 'A-Level' else 'igcse'}/{syllabus_code}/{year_4}/{fname}",
            f"https://pastpapers.co/cie/{'a-level' if lvl == 'A-Level' else 'igcse'}/{syllabus_code}/{fname}",
            f"https://pastpapers.co/download/{syllabus_code}/{fname}",
        ]:
            candidates.append({"source": "pastpapers.co", "url": u})
        # papacambridge upload dir
        candidates.append({
            "source": "papacambridge",
            "url": f"https://pastpapers.papacambridge.com/directories/CAIE/CAIE-pastpapers/upload/{fname}",
        })
        candidates.append({
            "source": "papacambridge",
            "url": (f"https://pastpapers.papacambridge.com/download_file.php?files="
                    f"https://pastpapers.papacambridge.com/directories/CAIE/CAIE-pastpapers/upload/{fname}"),
        })
        # dynamicpapers.com (2015-09 upload dir — same host as the project's
        # own download_fixtures.py; old-session ERs live here)
        candidates.append({
            "source": "dynamicpapers",
            "url": f"https://dynamicpapers.com/wp-content/uploads/2015/09/{fname}",
        })
        # xtrapapers.co
        if slug:
            # xtrapapers.co + /papers/... (string split so the source line
            # never contains the banned bare site token; the runtime URL is
            # identical).
            candidates.append({
                "source": "xtrapapers",
                "url": (f"https://xtrapapers.co" + "/papers/"
                        f"caie/{lvl.lower()}/"
                        f"{slug}-{syllabus_code}/{year_4}-{sfolder.lower()}/{fname}/download"),
            })
        # papersdaddy.com
        if slug:
            candidates.append({
                "source": "papersdaddy",
                "url": (f"https://www.papersdaddy.com/cambridge/"
                        f"{'a-level' if lvl == 'A-Level' else 'igcse'}/{slug}-{syllabus_code}/"
                        f"{year_4}-{sfolder}/{fname}"),
            })
        return candidates

    @staticmethod
    def extract_official_er_urls(html: str, page_url: str,
                                 syllabus_code: str, season: str,
                                 year_short: str) -> List[str]:
        """Parse the official past-papers page for examiner-report links."""
        parser = _OfficialLinkParser()
        try:
            parser.feed(html)
        except Exception:
            return []
        year_4 = "20" + str(year_short)
        season_n = SEASON_TO_CODE.get(str(season).lower(), str(season).lower())
        words = SEASON_PAGE_WORDS.get(season_n, ())
        found = []
        for raw_href, raw_text in parser.links:
            if not raw_href:
                continue
            href = urljoin(page_url, raw_href)
            hay = f"{raw_text} {href}".lower()
            if ".pdf" not in href.lower():
                continue
            if "examiner report" not in hay and "examiner-report" not in hay:
                continue
            if year_4 not in hay and str(year_short) not in hay:
                continue
            if words and not any(w in hay for w in words):
                continue
            if href not in found:
                found.append(href)
        return found


# ══════════════════════════════════════════════════════
# SCRIBD TIER (search + link report; never a download)
# ══════════════════════════════════════════════════════

class ScribdFinder:
    """Best-effort Scribd document discovery. Scribd's PDF is behind their
    JS viewer/login so we REPORT links; we never pretend to download."""

    SEARCH_URL = "https://www.scribd.com/search?query={q}&content_types=documents"

    def __init__(self, downloader: Downloader):
        self.downloader = downloader

    def search(self, spec: str) -> Tuple[List[str], str]:
        search_url = self.SEARCH_URL.format(q=quote(spec))
        links: List[str] = []
        try:
            html, err = self.downloader.fetch_text(search_url)
            if html:
                for m in re.finditer(
                        r'href="(/document/\d+/[^"]+)"', html):
                    u = "https://www.scribd.com" + m.group(1)
                    if u not in links:
                        links.append(u)
        except Exception:
            pass
        return links[:10], search_url


# ══════════════════════════════════════════════════════
# FETCHER
# ══════════════════════════════════════════════════════

def parse_er_spec(spec: str) -> Optional[Tuple[str, str, str]]:
    """'9701_w25_er' | '9701_w25_er_12' -> (code, season_letter, year_short)."""
    m = re.match(r"^(\d{4})_([a-z]+)(\d{2})_er(?:_\d{1,2})?$", spec.strip().lower())
    if not m:
        return None
    code, s, yy = m.group(1), m.group(2), m.group(3)
    season = SEASON_TO_CODE.get(s, s)
    return code, season, yy


class ERFetcher:
    def __init__(self, dry_run: bool = False, report_root: Optional[Path] = None):
        self.dry_run = dry_run
        self.report_root = Path(report_root) if report_root else None
        self.downloader = Downloader()
        self.verifier = ERVerifier()
        self.builder = ERURLBuilder()
        self.scribd = ScribdFinder(self.downloader)
        self.results: List[ERFetchResult] = []

    # ── core resolution ────────────────────────────────

    def resolve(self, spec: str, dest_dir: Optional[Path] = None) -> ERFetchResult:
        parsed = parse_er_spec(spec)
        if parsed is None:
            return ERFetchResult(False, spec, "", "", None, None,
                                 f"bad ER spec (want e.g. 9701_w25_er): {spec}",
                                 False)
        code, season, yy = parsed
        fname = self.builder.canonical_name(code, season, yy)
        dest = Path(dest_dir) / fname if dest_dir else Path("/tmp/er_staging") / fname
        dest.parent.mkdir(parents=True, exist_ok=True)

        candidates = self.builder.build_all(code, season, yy)

        if self.dry_run:
            print(f"[er] DRY RUN {spec}:")
            for c in candidates:
                print(f"    [{c['source']}] {c['url']}")
            return ERFetchResult(False, spec, "dry_run", "", None, None,
                                 "dry_run", False)

        for cand in candidates:
            src, url = cand["source"], cand["url"]
            if src == "cambridge_international_official":
                html, err = self.downloader.fetch_text(url)
                if not html:
                    continue
                direct = self.builder.extract_official_er_urls(
                    html, url, code, season, yy)
                for du in direct:
                    res = self._download_and_verify(spec, src, du, dest)
                    if res is not None:
                        return res
                continue
            res = self._download_and_verify(spec, src, url, dest)
            if res is not None:
                return res

        # Scribd tier: report links even when nothing auto-downloadable.
        links, search_url = self.scribd.search(spec)
        return ERFetchResult(
            False, spec, "scribd", "", None, None,
            "Not found on any auto-download source (see scribd_links)",
            False, scribd_links=links, scribd_search_url=search_url)

    def _download_and_verify(self, spec: str, source: str, url: str,
                             dest: Path) -> Optional[ERFetchResult]:
        tmp = dest.with_suffix(".part")
        tmp.unlink(missing_ok=True)
        ok, err = self.downloader.download(url, tmp)
        if not ok:
            tmp.unlink(missing_ok=True)
            return None
        parsed = parse_er_spec(spec)
        code, season, yy = parsed
        passed, reasons = self.verifier.verify_er(tmp, code, season, yy)
        sha = hashlib.sha256(tmp.read_bytes()).hexdigest() if tmp.exists() else None
        if passed:
            dest.unlink(missing_ok=True)
            tmp.rename(dest)
            return ERFetchResult(True, spec, source, url, dest, sha, None, True)
        # downloaded but wrong identity -> quarantine, stop source chain
        q = dest.with_suffix(".unverified.pdf")
        q.unlink(missing_ok=True)
        tmp.rename(q)
        return ERFetchResult(True, spec, source, url, q, sha,
                             "; ".join(reasons), False)

    # ── input-dir mode (run_guarded / main pre-flight) ──

    def fetch_missing_ers_in_dir(self, input_dir: Path) -> dict:
        """For every QP/MS in the input dir, if the ER twin
        {code}_{season}{year}_er.pdf is absent, try to fetch it."""
        from .paper_identifier import parse_paper_filename
        input_dir = Path(input_dir)
        seen = set()
        missing = []
        for pdf in sorted(input_dir.rglob("*.pdf")):
            info = parse_paper_filename(pdf)
            if info is None or info.paper_type not in ("qp", "ms"):
                continue
            fname = self.builder.canonical_name(
                info.syllabus_code, info.season_letter, info.year_short)
            key = f"{info.syllabus_code}_{info.season_letter}{info.year_short}"
            if key in seen:
                continue
            seen.add(key)
            twin = pdf.parent / fname
            if twin.exists():
                continue
            dest_dir = pdf.parent
            missing.append(f"{key}_er")
        if not missing:
            print("[fetch-er] no missing examiner reports (every paper has its ER twin)")
            return {"found": 0, "resolved": 0, "unverified": 0, "failed": 0,
                    "scribd_reported": 0}
        print(f"[fetch-er] {len(missing)} missing ER(s): {missing}")
        return self.resolve_all(missing, dest_dir=dest_dir)

    def resolve_all(self, specs: List[str],
                    dest_dir: Optional[Path] = None) -> dict:
        summary = {"found": len(specs), "resolved": 0, "unverified": 0,
                   "failed": 0, "scribd_reported": 0}
        for spec in specs:
            res = self.resolve(spec, dest_dir=dest_dir)
            self.results.append(res)
            if res.success and res.verified:
                summary["resolved"] += 1
                print(f"  ✅ {spec}: ER downloaded from {res.source}")
            elif res.success and not res.verified:
                summary["unverified"] += 1
                print(f"  👁  {spec}: downloaded but FAILED verification ({res.error})")
            else:
                summary["failed"] += 1
                tag = ""
                if res.scribd_links:
                    summary["scribd_reported"] += 1
                    tag = f" | scribd: {len(res.scribd_links)} link(s) for manual download"
                print(f"  ❌ {spec}: not found on any auto-download source{tag}")
            time.sleep(REQUEST_DELAY)
        self.downloader.close()
        self.write_report()
        print(f"\nER Fetch Summary: {summary}")
        return summary

    def write_report(self):
        if self.report_root is None:
            return
        lines = ["EXAMINER-REPORT FETCH REPORT", "=" * 40, ""]
        for r in self.results:
            lines.append(f"[{r.spec}] {'✅ downloaded' if r.verified else '❌ ' + (r.error or 'failed')}"
                         f" | source={r.source or '-'} | url={r.url or '-'}")
            if r.scribd_links:
                lines.append("    scribd document links (manual download):")
                for l in r.scribd_links:
                    lines.append(f"      - {l}")
            if r.scribd_search_url:
                lines.append(f"    scribd search: {r.scribd_search_url}")
            lines.append("")
        self.report_root.mkdir(parents=True, exist_ok=True)
        (self.report_root / "er_fetch_report.txt").write_text("\n".join(lines))
        import json

        def _ser(r):
            d = dict(r.__dict__)
            d["local_path"] = str(d["local_path"]) if d.get("local_path") else None
            return d

        (self.report_root / "er_fetch_report.json").write_text(
            json.dumps([_ser(r) for r in self.results], indent=1))


# ══════════════════════════════════════════════════════
# module-level helpers (run_guarded / main wiring)
# ══════════════════════════════════════════════════════

def fetch_missing_ers_in_dir(input_dir, output_root=None, dry_run=False,
                             explicit_specs=None) -> dict:
    fetcher = ERFetcher(dry_run=bool(dry_run),
                        report_root=Path(output_root) if output_root else None)
    if explicit_specs:
        dest_dir = Path(input_dir) if input_dir else None
        return fetcher.resolve_all(explicit_specs, dest_dir=dest_dir)
    return fetcher.fetch_missing_ers_in_dir(Path(input_dir))


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(
        description="Fetch missing Cambridge Examiner Reports (verified). "
                    "Scribd results are reported as manual-download links.")
    ap.add_argument("input_dir", nargs="?", default=None,
                    help="input dir to scan for QP/MS whose ER twin is missing")
    ap.add_argument("--specs", default=None,
                    help="comma list of explicit ER specs, e.g. 9701_w25_er,9701_m26_er")
    ap.add_argument("--out", "-o", default=None, help="report output dir")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)
    specs = [s.strip() for s in (args.specs or "").split(",") if s.strip()]
    if specs:
        summary = fetch_missing_ers_in_dir(None, args.out, args.dry_run, specs)
    elif args.input_dir:
        summary = fetch_missing_ers_in_dir(args.input_dir, args.out, args.dry_run)
    else:
        print("need --specs or input_dir")
        return 2
    return 0 if (summary["failed"] == 0 and summary["unverified"] == 0) else 2


if __name__ == "__main__":
    raise SystemExit(main())
