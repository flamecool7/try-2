"""Small cross-platform progress UI for ExamVoid batch runs.

The UI is intentionally optional: when tqdm is unavailable or output is not a
terminal, callers receive a plain-text progress object. ANSI colors are enabled
on modern Windows consoles when possible and can be controlled with:

  EXAMVOID_COLOR=always
  EXAMVOID_COLOR=never
  NO_COLOR=1
"""
from __future__ import annotations

import ctypes
import os
import sys
from typing import Callable


_RESET = "\x1b[0m"
_BOLD = "\x1b[1m"
_DIM = "\x1b[2m"
_GREEN = "\x1b[92m"
_RED = "\x1b[91m"
_YELLOW = "\x1b[93m"
_CYAN = "\x1b[96m"
_BLUE = "\x1b[94m"


def _enable_windows_ansi() -> bool:
    if os.name != "nt":
        return True
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_ulong()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        return bool(kernel32.SetConsoleMode(handle, mode.value | 0x0004))
    except Exception:
        return False


def colors_enabled(stream=None) -> bool:
    stream = stream or sys.stderr
    setting = os.environ.get("EXAMVOID_COLOR", "auto").lower()
    if setting in {"never", "0", "false", "off"} or os.environ.get("NO_COLOR"):
        return False
    if setting in {"always", "1", "true", "on"}:
        return True
    return bool(getattr(stream, "isatty", lambda: False)()) and _enable_windows_ansi()


def paint(text: str, code: str, enabled: bool) -> str:
    return f"{code}{text}{_RESET}" if enabled else str(text)


def format_postfix(ok: int, failed: int, review: int,
                   last: str = "", *, enabled: bool = False) -> str:
    parts = [
        paint("OK", _GREEN + _BOLD, enabled) + f" {ok}",
        paint("FAIL", _RED + _BOLD, enabled) + f" {failed}",
        paint("REVIEW", _YELLOW + _BOLD, enabled) + f" {review}",
    ]
    if last:
        parts.append(paint("LAST", _BLUE + _BOLD, enabled) + f" {last}")
    return "  ".join(parts)


class PlainProgress:
    """Fallback used when tqdm is unavailable or output is redirected."""
    def __init__(self, total: int, desc: str = "ExamVoid"):
        self.total = total
        self.done = 0
        self.desc = desc

    def __enter__(self):
        print(f"[{self.desc}] 0/{self.total} bundles complete")
        return self

    def __exit__(self, *args):
        return False

    def update(self, n: int = 1):
        self.done += n
        print(f"[{self.desc}] {self.done}/{self.total} bundles complete")

    def set_postfix_str(self, text: str):
        print(f"[{self.desc}] {text}")

    def close(self):
        return None


def make_progress(tqdm_factory: Callable, total: int,
                  desc: str = "ExamVoid"):
    """Build the styled tqdm bar, with a plain fallback handled by callers."""
    enabled = colors_enabled()
    kwargs = {
        "total": total,
        "desc": paint(desc, _CYAN + _BOLD, enabled),
        "unit": "bundle",
        "dynamic_ncols": True,
        "mininterval": 0.2,
        "bar_format": "{desc} {percentage:3.0f}%|{bar:30}| {n_fmt}/{total_fmt} | {elapsed} | {rate_fmt}",
        "leave": True,
    }
    if enabled:
        kwargs["colour"] = "cyan"
    return tqdm_factory(**kwargs), enabled
