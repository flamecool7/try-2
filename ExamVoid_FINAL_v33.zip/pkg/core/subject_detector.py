"""
Subject Detector - Universal component now supporting IGCSE + A-Level
with full 23-subject matrix and robust Further Mathematics detection

Level + Subject + Syllabus architecture:
Level → Exam Board → Subject → Syllabus Code → Correct Configuration

For example:
IGCSE → Chemistry → 0620
A-Level → Chemistry → 9701
A-Level → Further Mathematics → 9231

Automatically identifies subject using:
- Syllabus code (most reliable)
- Paper filename
- Paper header
- Subject name
- Exam-board metadata
- Level (IGCSE vs A-Level)

Rules:
- If reliable information conflicts: STOP processing that paper and report conflict.
- If subject cannot be identified confidently: Do NOT guess. Flag for review.
- Level validation: verify Level, Board, Subject, Syllabus Code, Correct Configuration
- For Further Mathematics vs Mathematics: prioritize code and specific "further" keyword
"""

import re
from pathlib import Path
from typing import Optional, Tuple
from .paper_identifier import PaperInfo, infer_level_from_code
from .config_loader import load_all_subject_configs, KNOWN_CODE_MAP

# Comprehensive patterns for all 23 subjects - specific patterns first
SUBJECT_NAME_PATTERNS = {
    # A-Level - Further Mathematics must be checked before Mathematics to avoid false positive
    "Further_Mathematics_9231": [r"further mathematics", r"9231", r"further pure mathematics"],
    "Computer_Science_9618": [r"computer science.*9618", r"9618", r"igcse computer science.*9618", r"a level computer science"],
    "Mathematics_9709": [r"mathematics.*9709", r"\b9709\b", r"(?<!further )pure mathematics"],  # Negative lookbehind to avoid matching further pure
    "Chemistry_9701": [r"chemistry.*9701", r"\b9701\b", r"igcse chemistry.*9701"],
    "Physics_9702": [r"physics.*9702", r"\b9702\b"],
    "Biology_9700": [r"biology.*9700", r"\b9700\b"],
    "Economics_9708": [r"economics.*9708", r"\b9708\b", r"a level economics"],
    "Business_9609": [r"business.*9609", r"\b9609\b", r"a level business"],
    "English_Literature_9695": [r"english literature.*9695", r"\b9695\b", r"literature.*9695"],
    "History_9489": [r"history.*9489", r"\b9489\b"],
    "Information_Technology_9626": [r"information technology.*9626", r"\b9626\b", r"it.*9626"],
    "Geography_9696": [r"geography.*9696", r"\b9696\b"],
    "Accounting_9706": [r"accounting.*9706", r"\b9706\b"],
    "Psychology_9990": [r"psychology.*9990", r"\b9990\b"],
    "Sociology_9699": [r"sociology.*9699", r"\b9699\b"],

    # IGCSE
    "Computer_Science_0478": [r"computer science.*0478", r"\b0478\b", r"igcse computer science"],
    "Mathematics_0580": [r"mathematics.*0580", r"\b0580\b", r"igcse mathematics"],
    "Chemistry_0620": [r"chemistry.*0620", r"\b0620\b", r"igcse chemistry"],
    "Physics_0625": [r"physics.*0625", r"\b0625\b", r"igcse physics"],
    "Biology_0610": [r"biology.*0610", r"\b0610\b", r"igcse biology"],
    "Economics_0455": [r"economics.*0455", r"\b0455\b"],
    "Business_Studies_0450": [r"business studies.*0450", r"\b0450\b", r"business.*0450"],
    "Literature_in_English_0475": [r"literature.*0475", r"\b0475\b"],
    "History_0470": [r"history.*0470", r"\b0470\b"],
    "ICT_0417": [r"information.*communication.*0417", r"\b0417\b", r"ict.*0417"],
    "Geography_0460": [r"geography.*0460", r"\b0460\b"],
}

LEVEL_PATTERNS = {
    "IGCSE": [r"\bigcse\b", r"international general certificate", r"\b0620\b", r"\b0625\b", r"\b0610\b", r"\b0580\b", r"\b0478\b", r"\b0455\b", r"\b0450\b"],
    "A-Level": [r"\ba-level\b", r"a level", r"advanced level", r"\b9701\b", r"\b9702\b", r"\b9709\b", r"\b9231\b", r"\b9618\b", r"\b9708\b", r"\b9609\b", r"\b9700\b", r"cambridge international.*a level", r"as & a level"],
}

def extract_header_text(pdf_path: Path, max_pages=2) -> str:
    try:
        import fitz
        doc = fitz.open(str(pdf_path))
        text = ""
        for i in range(min(max_pages, len(doc))):
            page = doc[i]
            text += page.get_text("text")[:4000] + "\n"
        doc.close()
        return text.lower()
    except Exception as e:
        try:
            import pdfplumber
            with pdfplumber.open(str(pdf_path)) as pdf:
                txt = ""
                for i in range(min(max_pages, len(pdf.pages))):
                    txt += (pdf.pages[i].extract_text() or "")[:4000] + "\n"
                return txt.lower()
        except Exception as e:
            return ""

def detect_level_from_header(header_text: str) -> Optional[str]:
    header_lower = header_text.lower()
    igcse_score = sum(1 for pat in LEVEL_PATTERNS["IGCSE"] if re.search(pat, header_lower))
    alevel_score = sum(1 for pat in LEVEL_PATTERNS["A-Level"] if re.search(pat, header_lower))

    if igcse_score > alevel_score and igcse_score > 0:
        return "IGCSE"
    if alevel_score > igcse_score and alevel_score > 0:
        return "A-Level"
    return None

def detect_subject_from_header(header_text: str) -> Optional[str]:
    header_lower = header_text.lower()
    scores = {}

    # Special handling: if header contains "further mathematics" or "9231", it is Further Mathematics, not Mathematics
    # This prevents false positive where Mathematics pattern "pure mathematics" matches "further pure mathematics"
    if re.search(r"further mathematics|9231", header_lower):
        # Boost Further Mathematics
        if "further" in header_lower and "mathematics" in header_lower:
            scores["Further_Mathematics_9231"] = 10  # High score to prioritize

    for subject, patterns in SUBJECT_NAME_PATTERNS.items():
        score = 0
        for pat in patterns:
            try:
                if re.search(pat, header_lower):
                    # Longer, more specific patterns get higher weight
                    # e.g., "further mathematics" (2 words) > "mathematics"
                    # "chemistry.*9701" more specific than "9701" alone
                    weight = 2 if " " in pat or ".* " in pat or len(pat) > 10 else 1
                    # Bonus for code-specific patterns
                    if any(code in pat for code in ["9231", "9701", "9702", "9709", "9609", "9708", "9626", "9696", "9489", "9695"]):
                        weight += 1
                    score += weight
            except Exception as e:
                continue
        if score > 0:
            # Don't overwrite high score from special handling
            if subject not in scores or score > scores[subject]:
                if subject not in scores or scores[subject] < 10:  # Don't overwrite special high score
                    scores[subject] = scores.get(subject, 0) + score

    if not scores:
        return None

    # Sort by score descending, and prioritize more specific subjects
    # Further Mathematics should win over Mathematics if both have matches and header has "further"
    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    
    # If Further Mathematics is in top candidates and header contains "further", choose it
    if "further" in header_lower and any("further" in subj.lower() for subj, _ in sorted_scores[:2]):
        for subj, score in sorted_scores:
            if "further" in subj.lower():
                return subj

    best = sorted_scores[0]
    return best[0] if best[1] >= 1 else None

def detect_subject(paper_info: PaperInfo) -> Tuple[Optional[str], Optional[str], str]:
    configs = load_all_subject_configs()
    
    code = paper_info.syllabus_code
    code_subject = None
    code_level = paper_info.level

    if code in configs:
        cfg = configs[code]
        code_subject = cfg.subject
        if cfg.level != code_level:
            print(f"[SubjectDetector] Note: code {code} prefix suggests {code_level} but config says {cfg.level}, using config")
            code_level = cfg.level
    elif code in KNOWN_CODE_MAP:
        code_subject = KNOWN_CODE_MAP[code]
        if code_subject in configs:
            code_level = configs[code_subject].level

    header_text = extract_header_text(paper_info.file_path)
    header_subject = detect_subject_from_header(header_text) if header_text else None
    header_level = detect_level_from_header(header_text) if header_text else None

    # Level validation: only conflict if both are confident and clearly different
    # For Further Mathematics (9231) and Mathematics (9709), both are A-Level, so no level conflict
    if header_level and code_level and header_level != code_level:
        # The four-digit filename code is the authoritative identity. Some
        # 2026 long-form papers have noisy headers (for example an AS-level
        # header being heuristically read as IGCSE). Known syllabus codes must
        # not make the whole batch abort because of that secondary heuristic.
        if code in KNOWN_CODE_MAP:
            print(
                f"[SubjectDetector] Level header mismatch for {paper_info.file_path.name}: "
                f"code={code_level}, header={header_level}; trusting filename code"
            )
            header_level = code_level
        elif (header_level == "IGCSE" and code_level == "A-Level") or (header_level == "A-Level" and code_level == "IGCSE"):
            msg = f"LEVEL CONFLICT: file {paper_info.file_path.name} code indicates {code_level} but header indicates {header_level}. STOP processing."
            print(f"[SubjectDetector] {msg}")
            return None, None, "conflict"

    # Subject validation: improved logic to avoid false conflicts for related subjects
    if code_subject and header_subject:
        if code_subject != header_subject:
            # Check if same discipline (e.g., Mathematics vs Further Mathematics both contain Mathematics)
            # Extract base: first part before _ or full discipline
            # For Further_Mathematics_9231 vs Mathematics_9709, they share "Mathematics" but are different
            # We should NOT treat as conflict if code is Further and header is Mathematics, because header detection may have matched "pure mathematics" substring
            # Instead, trust code (more reliable) when code is confident (in KNOWN_CODE_MAP) and header is less specific

            # If code is in KNOWN_CODE_MAP (high confidence from filename), trust code over header
            # Especially for Further Mathematics where header detection previously failed
            if code in KNOWN_CODE_MAP:
                # Code is high confidence from filename pattern like 9231_w25_qp_11.pdf
                # Header detection is heuristic and may have false positive (e.g., "pure mathematics" matching Mathematics when it's actually Further)
                # So trust code, don't treat as conflict, just log
                print(f"[SubjectDetector] Code {code_subject} (from filename {code}) and header {header_subject} differ, but trusting code (filename is more reliable than header heuristic)")
                header_subject = code_subject  # Override header to match code to avoid conflict
            else:
                # Both from heuristic, check base discipline
                base_code = code_subject.split('_')[0] if '_' in code_subject else code_subject
                base_header = header_subject.split('_')[0] if '_' in header_subject else header_subject

                # For Mathematics vs Further_Mathematics, base differs (Mathematics vs Further), but they are related
                # Check if one contains the other or shares discipline word
                code_lower = code_subject.lower()
                header_lower = header_subject.lower()

                # If both contain "mathematics" but one is further, trust code if code is Further
                if "mathematics" in code_lower and "mathematics" in header_lower:
                    # Both math-related, trust code (more specific from filename)
                    print(f"[SubjectDetector] Both {code_subject} and {header_subject} are Mathematics-related, trusting code {code_subject}")
                    header_subject = code_subject
                elif base_code != base_header:
                    # Truly different disciplines like Chemistry vs Physics - conflict
                    # But also check if one is subset of other? e.g., Business vs Business_Studies
                    if base_code not in base_header and base_header not in base_code and "business" not in code_lower and "business" not in header_lower:
                        msg = f"CONFLICT: file {paper_info.file_path.name} code indicates {code_subject} but header indicates {header_subject}. STOP processing."
                        print(f"[SubjectDetector] {msg}")
                        return None, None, "conflict"

    final_level = code_level or header_level or "A-Level"
    final_subject = code_subject or header_subject

    if final_subject:
        if final_subject not in configs and code in configs:
            final_subject = configs[code].subject

        if final_subject in configs:
            cfg = configs[final_subject]
            if cfg.level != final_level:
                from .config_loader import load_subject_config_by_code_and_level
                correct_cfg = load_subject_config_by_code_and_level(code, final_level)
                if correct_cfg:
                    final_subject = correct_cfg.subject
                else:
                    # If level mismatch but code is confident, trust code's level
                    if code in KNOWN_CODE_MAP:
                        final_level = cfg.level
                    else:
                        msg = f"LEVEL VALIDATION FAILED: {paper_info.file_path.name} level {final_level} vs config {cfg.level}"
                        print(f"[SubjectDetector] {msg}")
                        return None, None, "conflict"

            if cfg.syllabus_code != code:
                # Code mismatch - but if code is in KNOWN_CODE_MAP, it's high confidence, so header must be wrong? Actually config's code should match file's code
                # For Further Mathematics 9231, config code is 9231, file code is 9231, so should match
                # If mismatch, it's because final_subject came from header, not code
                # So we should prioritize code's config
                if code in configs:
                    cfg2 = configs[code]
                    return cfg2.subject, cfg2.level, "ok"
                print(f"[SubjectDetector] Syllabus code mismatch: file {code} vs config {cfg.syllabus_code} for {final_subject} - STOP")
                return None, None, "conflict"

            return final_subject, cfg.level, "ok"
        else:
            if code in configs:
                cfg = configs[code]
                return cfg.subject, cfg.level, "ok"

    msg = f"REVIEW: Could not identify subject/level for {paper_info.file_path.name}. Code={code}, subject guess={code_subject}, header subject={header_subject}, level={final_level}. Flag for review."
    print(f"[SubjectDetector] {msg}")
    return None, None, "review"

def separate_papers_by_subject(papers: list[PaperInfo]) -> dict:
    by_level_subject = {}
    by_subject_flat = {}
    conflicts = []
    needs_review = []

    for paper in papers:
        subject, level, status = detect_subject(paper)
        if status == "conflict":
            conflicts.append(paper)
        elif status == "review":
            needs_review.append(paper)
        else:
            if level not in by_level_subject:
                by_level_subject[level] = {}
            if subject not in by_level_subject[level]:
                by_level_subject[level][subject] = []
            by_level_subject[level][subject].append(paper)

            if subject not in by_subject_flat:
                by_subject_flat[subject] = []
            by_subject_flat[subject].append(paper)

    if conflicts:
        print(f"[SubjectDetector] Found {len(conflicts)} conflict(s) - STOP processing those papers")
    if needs_review:
        print(f"[SubjectDetector] Found {len(needs_review)} paper(s) needing review")

    for lvl, subj_dict in by_level_subject.items():
        for subj, plist in subj_dict.items():
            print(f"[SubjectDetector] Level {lvl} - {subj}: {len(plist)} papers")

    return {
        "by_level_subject": by_level_subject,
        "by_subject": by_subject_flat,
        "conflicts": conflicts,
        "review": needs_review
    }
