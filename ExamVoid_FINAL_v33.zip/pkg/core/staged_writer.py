"""Staged output writer (Overseer batch-infrastructure spec, Phase 3 —
honest port; mechanics verbatim from the spec).

All output for one bundle is written to a staging directory FIRST
(`<output>/.staging/bundle_<key>/`). Only after every question passes
validation is the bundle moved to the final location — atomic per file,
either all planned moves succeed or the commit reports failure and NOTHING
new is treated as complete. On failure the staging directory is PRESERVED
for debugging (spec rule 8) and the bundle is marked FAILED or
REVIEW_REQUIRED. A bundle is never marked complete after saving only some
of its questions (spec rule 7).

Audited addition over the spec's text (receipt in the round evidence log):
collisions at the destination are handled fail-closed — an identical file
already at the destination is skipped (idempotent re-commit), a DIFFERENT
file aborts the commit loudly instead of silently overwriting prior output.
"""

import hashlib
import shutil
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def _digest(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class StagedWriter:
    """
    Writes all output for one bundle to a staging
    directory first. Only moves to final location
    after all questions pass validation.
    """

    STAGING_ROOT = ".staging"

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.staging_dir = self.output_dir / self.STAGING_ROOT
        self.staging_dir.mkdir(parents=True, exist_ok=True)

    def get_staging_path(self, bundle_key: str) -> Path:
        """Get the staging directory for a bundle."""
        path = self.staging_dir / f"bundle_{bundle_key}"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def commit(
        self,
        bundle_key: str,
        staging_path: Path,
        final_paths: list,
        replace_existing: bool = False,
    ) -> bool:
        """Move all files from staging to final location.

        Identical destinations remain idempotent.  When ``replace_existing``
        is true, differing files are transactionally backed up inside the
        staging directory and replaced; a later failure restores the previous
        bytes.  This is used for an explicitly requeued bundle whose QP, MS,
        ER, or insert input changed.  The default remains fail-closed.
        """
        backups: list[tuple[Path, Path]] = []
        moved_new: list[Path] = []
        backup_root = staging_path / ".previous_output"
        try:
            # Preflight all collisions before moving anything.
            for src_rel, dest_abs in final_paths:
                src = staging_path / src_rel
                dest = Path(dest_abs)
                if not dest.exists():
                    continue
                if _digest(dest) == _digest(src):
                    continue
                if not replace_existing:
                    logger.error(
                        f"Commit aborted for {bundle_key}: destination "
                        f"conflict at {dest} (existing file differs)"
                    )
                    return False

            if replace_existing:
                for src_rel, dest_abs in final_paths:
                    src = staging_path / src_rel
                    dest = Path(dest_abs)
                    if not dest.exists() or _digest(dest) == _digest(src):
                        continue
                    backup = backup_root / Path(src_rel)
                    backup.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(dest), str(backup))
                    backups.append((dest, backup))

            for src_rel, dest_abs in final_paths:
                src = staging_path / src_rel
                dest = Path(dest_abs)
                if dest.exists():
                    # Remaining existing destinations are byte-identical.
                    src.unlink()
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dest))
                moved_new.append(dest)

            if backup_root.exists():
                shutil.rmtree(backup_root, ignore_errors=True)
            if staging_path.exists():
                shutil.rmtree(staging_path, ignore_errors=True)
            logger.info(f"Committed bundle {bundle_key}"
                        + (" with replacement" if replace_existing else ""))
            return True

        except Exception as e:
            # Best-effort transaction rollback: remove newly created files,
            # then restore every backed-up old file.
            for dest in reversed(moved_new):
                try:
                    if dest.exists():
                        dest.unlink()
                except OSError:
                    logger.exception("Could not remove new output %s", dest)
            for dest, backup in reversed(backups):
                try:
                    if dest.exists():
                        dest.unlink()
                    if backup.exists():
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.move(str(backup), str(dest))
                except OSError:
                    logger.exception("Could not restore previous output %s", dest)
            logger.error(f"Commit failed for {bundle_key}: {e}")
            return False

    def rollback(
        self,
        bundle_key: str,
        staging_path: Path,
        preserve: bool = True,
    ):
        """
        On failure either preserve staging for debug
        or clean it up.
        """
        if not preserve:
            shutil.rmtree(staging_path, ignore_errors=True)
            logger.info(f"Cleaned up staging for {bundle_key}")
        else:
            logger.warning(
                f"Staging preserved for review: {staging_path}"
            )
