#!/usr/bin/env python3
"""Run a child command while streaming and saving the same output.

The Windows launcher uses this instead of redirecting the whole generator run
until exit. It keeps the live progress visible, writes a UTF-8 log, preserves
the child's exit code, and prints a heartbeat if a PDF operation is quiet for a
while.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import threading
import time
from queue import Empty, Queue
from pathlib import Path


def _emit(line: str, log_fh) -> None:
    log_fh.write(line)
    log_fh.flush()
    try:
        sys.stdout.write(line)
        sys.stdout.flush()
    except UnicodeEncodeError:
        # Windows cp1252 consoles cannot display the status glyphs used by the
        # generator. The UTF-8 log retains the original line.
        data = line.encode(getattr(sys.stdout, "encoding", None) or "utf-8", errors="replace")
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--log", required=True, help="UTF-8 log file")
    ap.add_argument("command", nargs=argparse.REMAINDER,
                    help="child command after --")
    args = ap.parse_args(argv)
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        print("ERROR: no child command was supplied", file=sys.stderr)
        return 2

    log_path = Path(args.log)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    print("[launcher] live output enabled; log: " + str(log_path))
    try:
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
    except Exception as exc:
        print(f"[launcher] could not start child: {exc}", file=sys.stderr)
        return 1

    queue: Queue[object] = Queue()

    def reader() -> None:
        assert proc.stdout is not None
        try:
            for line in iter(proc.stdout.readline, ""):
                queue.put(line)
        finally:
            queue.put(None)

    threading.Thread(target=reader, daemon=True).start()
    eof = False
    last_output = time.monotonic()
    heartbeat_after = 30.0
    with log_path.open("a", encoding="utf-8", errors="replace") as log_fh:
        while not eof or proc.poll() is None:
            try:
                item = queue.get(timeout=2.0)
            except Empty:
                if time.monotonic() - last_output >= heartbeat_after:
                    elapsed = int(time.monotonic() - started)
                    _emit(f"[launcher] still running ({elapsed}s since last output)...\n", log_fh)
                    last_output = time.monotonic()
                continue
            if item is None:
                eof = True
                continue
            _emit(str(item), log_fh)
            last_output = time.monotonic()
        # Drain any final lines after the process exits.
        while True:
            try:
                item = queue.get_nowait()
            except Empty:
                break
            if item is not None:
                _emit(str(item), log_fh)

    return int(proc.wait())


if __name__ == "__main__":
    raise SystemExit(main())
