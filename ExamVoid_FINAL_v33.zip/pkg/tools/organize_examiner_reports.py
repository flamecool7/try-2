#!/usr/bin/env python3
"""Organize and crop Examiner Reports without QP/MS files.

This is an ER-only workflow. It scans an extracted Examiner Report archive,
uses the existing locked ER parser/cropper, and writes a separate tree:

    Examiner_Reports_Output/
      A-Level/Chemistry_9701/Summer_2025/Paper_12/
        Q01_ER.webp
        Q02_ER.webp
        ER_Commentary.txt
      ...

No question topics are assigned, no metadata.json is created, and no QP/MS is
required. The original ER PDFs are copied once into a Source_PDFs folder unless
--no-source-copy is supplied. The input archive is never modified.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Optional


SCRIPT_DIR = Path(__file__).resolve().parent


SESSION_LABELS = {
    "m": "Spring",
    "s": "Summer",
    "w": "Winter",
    "sp": "Specimen",
}

FALLBACK_SUBJECTS = {
    "0417": "ICT_0417", "0450": "Business_Studies_0450",
    "0452": "Accounting_0452", "0455": "Economics_0455",
    "0460": "Geography_0460", "0470": "History_0470",
    "0475": "Literature_in_English_0475", "0478": "Computer_Science_0478",
    "0580": "Mathematics_0580", "0606": "Additional_Mathematics_0606",
    "0610": "Biology_0610", "0620": "Chemistry_0620",
    "0625": "Physics_0625", "0653": "Combined_Science_0653",
    "0654": "Coordinated_Sciences_0654", "0697": "Marine_Science_0697",
    "8021": "English_General_Paper_8021", "9084": "Law_9084",
    "9231": "Further_Mathematics_9231", "9239": "Global_Perspectives_9239",
    "9395": "Travel_and_Tourism_9395", "9482": "Drama_9482",
    "9483": "Music_9483", "9489": "History_9489",
    "9607": "Media_Studies_9607", "9609": "Business_9609",
    "9618": "Computer_Science_9618", "9626": "Information_Technology_9626",
    "9686": "Urdu_9686", "9693": "Marine_Science_9693",
    "9694": "Thinking_Skills_9694", "9695": "English_Literature_9695",
    "9696": "Geography_9696", "9699": "Sociology_9699",
    "9700": "Biology_9700", "9701": "Chemistry_9701",
    "9702": "Physics_9702", "9705": "Design_and_Technology_9705",
    "9706": "Accounting_9706", "9708": "Economics_9708",
    "9709": "Mathematics_9709", "9713": "Applied_ICT_9713",
    "9715": "Mandarin_Chinese_9715", "9716": "French_9716",
    "9717": "German_9717", "9719": "Spanish_9719",
    "9990": "Psychology_9990",
}


def _load_examvoid_modules(pkg_root: Optional[Path]):
    """Load the existing ER parser/cropper from the main ExamVoid package."""
    candidates = []
    if pkg_root:
        candidates.append(Path(pkg_root).expanduser().resolve())
    candidates.extend([
        SCRIPT_DIR.parent / "pkg",
        SCRIPT_DIR.parent,
        Path.cwd(),
    ])
    seen = set()
    chosen = None
    for candidate in candidates:
        key = str(candidate).casefold()
        if key in seen:
            continue
        seen.add(key)
        if (candidate / "core").is_dir():
            chosen = candidate
            break
    if chosen is None:
        raise RuntimeError(
            "Could not find the main ExamVoid pkg folder. Pass --pkg "
            "C:\\path\\to\\ExamVoid_FINAL_v24\\pkg"
        )
    if str(chosen) not in sys.path:
        sys.path.insert(0, str(chosen))

    # check_existing_ers supplies the same broad identity parser used by the
    # separate inventory tool, including session/year information in parent
    # folder names when an ER filename is generic.
    from check_existing_ers import _parse_identity
    from core.examiner_report import (
        ExaminerReportParser,
        _render_examiner_report_webp_cached,
    )
    from core.er_question_crops import build_question_crops_for_pdf
    from core.webp_utils import save_webp
    return chosen, _parse_identity, ExaminerReportParser, _render_examiner_report_webp_cached, build_question_crops_for_pdf, save_webp


def _safe_name(value: str, fallback: str = "Unknown") -> str:
    value = str(value or fallback).strip()
    value = re.sub(r"[<>:\"/\\|?*]+", "_", value)
    value = re.sub(r"\s+", "_", value)
    value = value.strip("._ ")
    return value or fallback


def _session_folder(season: str, year: str) -> str:
    label = SESSION_LABELS.get(str(season).lower(), str(season or "Unknown"))
    if str(year) in {"", "unknown", "0", "00"}:
        return f"{label}_Unknown_Year"
    return f"{label}_{year}"


def _component_sort(value: str):
    m = re.search(r"\d+", str(value))
    return (int(m.group()) if m else 999, str(value))


def _question_numbers(component_report) -> list[int]:
    numbers = []
    for key in (getattr(component_report, "question_comments", {}) or {}):
        m = re.search(r"\d+", str(key))
        if m:
            numbers.append(int(m.group()))
    if numbers:
        return sorted(set(numbers))

    # Fallback for ERs whose parser found a component section but no clean
    # question-comment dictionary. Only use explicit question headers; never
    # invent a complete 1..N range.
    raw = getattr(component_report, "raw_text", "") or ""
    for pattern in (
        r"(?im)^\s*question\s+([1-9]\d?)\b",
        r"(?im)^\s*q(?:uestion)?\s*([1-9]\d?)\s*[:.)-]",
    ):
        numbers.extend(int(n) for n in re.findall(pattern, raw))
    return sorted(set(numbers))


def _write_text_report(path: Path, component_report, *, code: str,
                       component: str, season: str, year: str) -> None:
    general = getattr(component_report, "general_comments", "") or ""
    questions = getattr(component_report, "question_comments", {}) or {}
    lines = [
        "ExamVoid Examiner Report",
        "========================",
        f"Syllabus: {code}",
        f"Paper:    {component}",
        f"Session:  {season} {year}",
        "",
        "GENERAL COMMENTS",
        "----------------",
        general.strip() or "(No general comments were extracted.)",
        "",
        "QUESTION COMMENTARIES",
        "---------------------",
    ]
    if questions:
        for q in sorted(questions, key=_component_sort):
            lines += [f"Question {q}", str(questions[q]).strip(), ""]
    else:
        lines.append("(No question commentaries were extracted.)")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def organize(input_root: Path, output_root: Path, pkg_root: Optional[Path] = None,
             copy_sources: bool = True) -> dict:
    (pkg, parse_identity, ExaminerReportParser, render_full,
     build_question_crops, save_webp) = _load_examvoid_modules(pkg_root)
    input_root = Path(input_root).expanduser().resolve()
    output_root = Path(output_root).expanduser().resolve()
    if not input_root.exists() or not input_root.is_dir():
        raise FileNotFoundError(f"ER input folder does not exist: {input_root}")
    output_root.mkdir(parents=True, exist_ok=True)

    pdfs = sorted(
        p for p in input_root.rglob("*")
        if p.is_file() and p.suffix.lower() == ".pdf"
    )
    summary = Counter()
    records = []
    errors = []
    seen_sources = set()

    for er_path in pdfs:
        try:
            identity = parse_identity(er_path)
        except Exception as exc:
            identity = None
            errors.append(f"{er_path}: identity parser error: {exc}")
        if identity is None or str(getattr(identity, "paper_type", "")).lower() != "er":
            summary["skipped_non_er_or_unparseable"] += 1
            continue
        source_key = str(er_path.resolve()).casefold()
        if source_key in seen_sources:
            continue
        seen_sources.add(source_key)
        summary["er_pdfs_found"] += 1

        code = str(getattr(identity, "syllabus_code", "") or "Unknown")
        season_code = str(getattr(identity, "season_letter", "") or "")
        season = SESSION_LABELS.get(season_code, str(getattr(identity, "season", "Unknown")))
        year_value = str(getattr(identity, "year", "") or "unknown")
        if year_value in {"", "0"}:
            year_value = "unknown"
        subject = str(getattr(identity, "subject_guess", "") or "")
        if not subject:
            subject = FALLBACK_SUBJECTS.get(code, f"Subject_{code}")
        level = str(getattr(identity, "level", "") or ("A-Level" if code.startswith(("8", "9")) else "IGCSE"))
        session_dir = _session_folder(season_code, year_value)
        subject_root = output_root / _safe_name(level) / _safe_name(subject)
        session_root = subject_root / session_dir
        source_dir = session_root / "Source_PDFs"
        if copy_sources:
            source_dir.mkdir(parents=True, exist_ok=True)
            source_dest = source_dir / _safe_name(er_path.name)
            if not source_dest.exists() or source_dest.stat().st_size != er_path.stat().st_size:
                shutil.copy2(er_path, source_dest)

        parsed = ExaminerReportParser.parse_pdf(er_path)
        if parsed is None:
            summary["parse_failed"] += 1
            errors.append(f"{er_path}: ER text parser returned no document")
            continue
        summary["parsed"] += 1

        # Render the complete ER once per source PDF, not once per component.
        # Component folders can point back to this source copy/full render.
        full_dir = session_root / "Full_Reports"
        full_dest = full_dir / f"{_safe_name(er_path.stem)}_Full_Report.webp"
        full_report_path = str(full_dest)
        try:
            full_dir.mkdir(parents=True, exist_ok=True)
            render_full(er_path, full_dest)
            summary["full_reports_written"] += 1
        except Exception as exc:
            full_report_path = ""
            errors.append(f"{er_path}: full report render failed: {exc}")

        component_reports = getattr(parsed, "component_reports", {}) or {}
        if not component_reports:
            # The source PDF and one full visual render remain available even
            # when no component/question boundaries were detectable.
            records.append({
                "source": str(er_path), "status": "parsed_no_components",
                "code": code, "subject": subject, "level": level,
                "season": season, "year": year_value,
                "full_report": full_report_path,
                "output": str(session_root),
            })
            continue

        for component in sorted(component_reports, key=_component_sort):
            comp_report = component_reports[component]
            component = str(component)
            paper_dir = session_root / f"Paper_{_safe_name(component)}"
            paper_dir.mkdir(parents=True, exist_ok=True)
            _write_text_report(
                paper_dir / "ER_Commentary.txt", comp_report,
                code=code, component=component, season=season, year=year_value,
            )
            qnums = _question_numbers(comp_report)
            component_record = {
                "source": str(er_path), "status": "component_processed",
                "code": code, "subject": subject, "level": level,
                "season": season, "year": year_value, "component": component,
                "questions_requested": qnums, "crops_written": 0,
                "full_report": full_report_path,
                "output": str(paper_dir),
            }
            if not qnums:
                # The one session-level full render remains available and the
                # limitation is made visible in the component manifest.
                component_record["status"] = "component_no_question_boundaries"
                records.append(component_record)
                summary["components_without_question_boundaries"] += 1
                continue

            # The locked ER cropper scopes by the exact component marker. Try
            # the parser's component code first, then safe zero-padding and the
            # filename component as a compatibility fallback.
            candidates = [component]
            if component.isdigit() and len(component) == 1:
                candidates.append(component.zfill(2))
            identity_variant = str(getattr(identity, "variant", "") or "")
            if identity_variant and identity_variant not in candidates:
                candidates.append(identity_variant)
            crops = None
            statuses = {}
            segment_texts = {}
            winning_format = "none"
            used_component = component
            crop_error = None
            for candidate in candidates:
                try:
                    crops, statuses, segment_texts, winning_format = build_question_crops(
                        er_path, code, candidate, qnums
                    )
                    used_component = candidate
                    if crops or any(str(v) == "webp_cropped" for v in statuses.values()):
                        break
                except Exception as exc:
                    crop_error = exc
            if crops is None:
                crops = {}
            if crop_error and not crops:
                errors.append(f"{er_path} component {component}: ER crop failed: {crop_error}")

            for qnum in qnums:
                image = crops.get(qnum)
                if image is None:
                    summary["question_boundaries_missing"] += 1
                    continue
                dest = paper_dir / f"Q{qnum:02d}_ER.webp"
                try:
                    written = save_webp(image, dest, quality=95)
                    component_record["crops_written"] += 1
                    summary["question_crops_written"] += 1
                    component_record.setdefault("files", []).extend(str(p) for p in written)
                except Exception as exc:
                    errors.append(f"{er_path} component {component} Q{qnum}: save failed: {exc}")
            # The complete visual report was rendered once at the session
            # level; keep the path in each component record for auditability.
            component_record["crop_component_used"] = used_component
            component_record["crop_format"] = winning_format
            component_record["statuses"] = statuses
            records.append(component_record)
            summary["components_processed"] += 1

    report = {
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "input_root": str(input_root),
        "output_root": str(output_root),
        "summary": dict(summary),
        "errors": errors,
        "records": records,
    }
    (output_root / "organizer_manifest.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    lines = [
        "EXAMVOID EXAMINER REPORT ORGANIZER",
        "===================================",
        f"Generated: {report['generated']}",
        "Mode: ER-only; no QP/MS required; no topic categorization",
        f"Input:  {input_root}",
        f"Output: {output_root}",
        "",
        "SUMMARY",
        "-------",
    ]
    for key, value in sorted(summary.items()):
        lines.append(f"{key}: {value}")
    lines += ["", "ERRORS"]
    if errors:
        lines.extend(f"- {error}" for error in errors)
    else:
        lines.append("None")
    lines += ["", "The full machine-readable result is in organizer_manifest.json."]
    (output_root / "organizer_report.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return report


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True,
                    help="Extracted ER folder; scanned recursively")
    ap.add_argument("--output", default="Examiner_Reports_Output",
                    help="Separate ER-only output folder")
    ap.add_argument("--pkg", default=None,
                    help="Main ExamVoid pkg folder; auto-detected when beside this folder")
    ap.add_argument("--no-source-copy", action="store_true",
                    help="Do not copy original ER PDFs into Source_PDFs")
    args = ap.parse_args(argv)
    try:
        report = organize(
            Path(args.input), Path(args.output),
            pkg_root=Path(args.pkg) if args.pkg else None,
            copy_sources=not args.no_source_copy,
        )
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    summary = report["summary"]
    print(f"ER PDFs found: {summary.get('er_pdfs_found', 0)}")
    print(f"Question ER crops written: {summary.get('question_crops_written', 0)}")
    print(f"Full ER reports written: {summary.get('full_reports_written', 0)}")
    print(f"Errors: {len(report['errors'])}")
    print(f"Report: {Path(args.output).resolve() / 'organizer_report.txt'}")
    return 1 if report["errors"] and summary.get("question_crops_written", 0) == 0 else 0


if __name__ == "__main__":
    raise SystemExit(main())
