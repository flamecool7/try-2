#!/usr/bin/env python3
"""Build verified classifier examples from labelled questions.

This is the accuracy loop's bridge from human labels to the optional retrieval
signal. It reads the external run audit and a filled label CSV, then writes one
``classification_examples.jsonl`` beside each subject config. It never edits
question folders or metadata.json.

Example:
    python tools/build_classification_examples.py \
      --output-root output \
      --labels topic_accuracy_labels_filled.csv \
      --subjects-root subjects

Only non-empty ``expected_topic`` labels are written. The classifier consumes
these examples on the next run as supplementary evidence; curated config
keywords remain primary.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

SENTINELS = {"", "review_required", "review_required_no_ms", "review_required_no_qp"}


def _key(value: str) -> str:
    return str(value or "").strip()


def _paper_aliases(value: str) -> set[str]:
    p = _key(value)
    if not p:
        return set()
    aliases = {p}
    for marker in ("_qp_", "_ms_"):
        if marker in p:
            aliases.add(p.replace(marker, "_"))
    return aliases


def load_audit(output_root: Path) -> dict[tuple[str, str], dict]:
    index: dict[tuple[str, str], dict] = {}
    audit_root = output_root / ".classification_audit"
    if not audit_root.exists():
        return index
    for path in sorted(audit_root.glob("*.jsonl")):
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                row = json.loads(raw)
            except Exception:
                continue
            q = _key(row.get("question_number"))
            if not q:
                continue
            for paper in _paper_aliases(row.get("paper_full_code")) | _paper_aliases(row.get("paper")):
                index[(paper, q)] = row
    return index


def build_examples(output_root: Path, labels_path: Path,
                   subjects_root: Path) -> tuple[int, int, list[str]]:
    audit = load_audit(output_root)
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    missing: list[str] = []
    used = 0
    with labels_path.open(newline="", encoding="utf-8-sig") as fh:
        for label in csv.DictReader(fh):
            expected = _key(label.get("expected_topic"))
            if expected in SENTINELS:
                continue
            subject = _key(label.get("subject"))
            level = _key(label.get("level"))
            paper = _key(label.get("paper"))
            q = _key(label.get("question_number"))
            candidate = None
            for alias in _paper_aliases(paper):
                candidate = audit.get((alias, q))
                if candidate:
                    break
            if not candidate or not _key(candidate.get("question_text")):
                missing.append(f"{paper}/{q}")
                continue
            grouped[(level, subject)].append({
                "subject": subject,
                "level": level,
                "paper": paper,
                "question_number": q,
                "topic": expected,
                "text": candidate["question_text"],
                "verified": True,
                "source": "filled_topic_accuracy_label",
            })
            used += 1

    written = 0
    for (level, subject), rows in grouped.items():
        target = subjects_root / level / subject / "classification_examples.jsonl"
        target.parent.mkdir(parents=True, exist_ok=True)
        # Deduplicate by paper/question/topic while retaining deterministic
        # ordering for reproducible classifier inputs.
        unique = {}
        for row in rows:
            unique[(row["paper"], row["question_number"], row["topic"])] = row
        ordered = [unique[k] for k in sorted(unique)]
        target.write_text(
            "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in ordered),
            encoding="utf-8",
        )
        written += len(ordered)
        print(f"[examples] {level}/{subject}: {len(ordered)} verified examples -> {target}")
    return written, len(grouped), missing


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-root", required=True)
    ap.add_argument("--labels", required=True)
    ap.add_argument("--subjects-root", default="subjects")
    args = ap.parse_args(argv)
    written, subjects, missing = build_examples(
        Path(args.output_root), Path(args.labels), Path(args.subjects_root)
    )
    print(f"[examples] wrote {written} verified examples across {subjects} subjects")
    if missing:
        print(f"[examples] skipped {len(missing)} labelled rows without an audit text trace")
        for item in missing[:10]:
            print(f"  - {item}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
