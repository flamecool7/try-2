#!/usr/bin/env python3
"""Build the small text report users can send with an ExamVoid run.

The report is deliberately a plain text file, so it can be attached or pasted
without opening a database. It summarizes the input identity pass, output tree,
runner log, and the first actionable errors. It never changes question crops or
metadata.json.
"""
from __future__ import annotations

import argparse
import re
import sys
import time
from collections import Counter
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from core.paper_identifier import parse_paper_filename
except Exception:
    parse_paper_filename = None


SESSION_LABELS = {
    "m": "Spring / February-March",
    "s": "Summer / May-June",
    "w": "Winter / October-November",
    "sp": "Specimen",
}


def _fallback_identity(path: Path):
    """Tiny fallback for report generation if core dependencies are missing."""
    name = path.stem.lower()
    code_match = re.search(r"(?<!\d)(\d{4})(?!\d)", name)
    if not code_match:
        return None
    code = code_match.group(1)
    compact = re.search(
        r"(?<![a-z])(sp|mj|on|fm|f|m|s|j|w|n)[-_ ]?(20\d{2}|\d{2})",
        name,
    )
    season = year = None
    if compact:
        season = {"mj": "s", "on": "w", "fm": "m", "f": "m", "j": "s", "n": "w"}.get(
            compact.group(1), compact.group(1)
        )
        year = compact.group(2)[-2:]
    else:
        if re.search(r"may[- /]?june|summer|\bmay\b|\bjune\b", name):
            season = "s"
        elif re.search(r"october[- /]?november|winter|\boctober\b|\bnovember\b", name):
            season = "w"
        elif re.search(r"february[- /]?march|spring|\bfebruary\b|\bmarch\b", name):
            season = "m"
        elif re.search(r"specimen|sample", name):
            season = "sp"
        full = re.search(r"(?<!\d)(20\d{2})(?!\d)", name)
        year = full.group(1)[-2:] if full else ("00" if season == "sp" else None)
    if not season or year is None:
        return None
    if re.search(r"examiner[ _-]*report|principal[ _-]*examiner|(?<![a-z])er(?![a-z])", name):
        kind = "er"
    elif re.search(r"mark[ _-]*(?:scheme|schemes)|markscheme|(?<![a-z])ms(?![a-z])", name):
        kind = "ms"
    elif re.search(r"question[ _-]*paper|questionpaper|(?<![a-z])qp(?![a-z])", name):
        kind = "qp"
    else:
        return None
    number = ""
    marker = re.search(r"(?:paper|component|qp|ms|er|report)[ _-]*([1-9]\d?)\b", name)
    if marker:
        number = marker.group(1)
    return type("Identity", (), {
        "paper_type": kind, "syllabus_code": code, "season_letter": season,
        "year_short": year, "year": "unknown" if year == "00" else f"20{year}",
        "variant": number,
    })()


def _identity(path: Path):
    try:
        if parse_paper_filename is not None:
            info = parse_paper_filename(path)
            if info is not None:
                return info
    except Exception:
        pass
    return _fallback_identity(path)


def input_inventory(input_dir: Path) -> dict:
    kinds = Counter()
    sessions = Counter()
    unknown = []
    paths = []
    if not input_dir.exists():
        return {"pdfs": 0, "kinds": kinds, "sessions": sessions, "unknown": [], "paths": []}
    for path in sorted(input_dir.rglob("*"), key=lambda p: str(p).casefold()):
        if not path.is_file() or path.suffix.lower() != ".pdf":
            continue
        paths.append(path)
        info = _identity(path)
        if info is None:
            unknown.append(path)
            continue
        kind = str(getattr(info, "paper_type", "unknown"))
        kinds[kind] += 1
        if kind in {"qp", "ms", "er"}:
            session = f"{getattr(info, 'season_letter', '')}{getattr(info, 'year_short', '')}"
            sessions[session] += 1
    return {"pdfs": len(paths), "kinds": kinds, "sessions": sessions, "unknown": unknown, "paths": paths}


def output_inventory(output_dir: Path) -> dict:
    if not output_dir.exists():
        return {"question_folders": 0, "metadata": 0, "summer_2026": 0, "reviews": 0}
    q_re = re.compile(r"_Q\d+$", re.IGNORECASE)
    folders = [p for p in output_dir.rglob("*") if p.is_dir() and q_re.search(p.name)]
    metadata = list(output_dir.rglob("metadata.json"))
    summer = [p for p in folders if "Summer_2026" in p.name or "s26" in p.name.lower()]
    reviews = [p for p in folders if "review_required" in p.parts]
    return {
        "question_folders": len(folders),
        "metadata": len(metadata),
        "summer_2026": len(summer),
        "reviews": len(reviews),
    }


def _read(path: Path, limit: int = 200000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")[:limit]
    except OSError:
        return ""


def _error_lines(log_text: str) -> list[str]:
    lines = []
    seen = set()
    for raw in log_text.splitlines():
        line = raw.strip()
        if not line or line in seen:
            continue
        low = line.lower()
        interesting = (
            "run failed" in low or "fatal:" in low or "traceback" in low
            or "failed" in low or "exception" in low or "error" in low
            or line.startswith("FAIL") or "worker exited" in low
        )
        if interesting and "0 failed" not in low and "failed: 0" not in low:
            seen.add(line)
            lines.append(line)
        if len(lines) >= 80:
            break
    return lines



def build_input_audit(input_dir: Path) -> str:
    inv = input_inventory(input_dir)
    lines = [
        "EXAMVOID INPUT AUDIT",
        "====================",
        f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Input: {input_dir.resolve()}",
        "Mode: pre-run identity audit only; no crops were generated",
        "",
        f"PDFs scanned : {inv['pdfs']}",
        f"QP files     : {inv['kinds'].get('qp', 0)}",
        f"MS files     : {inv['kinds'].get('ms', 0)}",
        f"ER files     : {inv['kinds'].get('er', 0)}",
        f"Other parsed : {sum(v for k, v in inv['kinds'].items() if k not in {'qp', 'ms', 'er'})}",
        f"Unrecognized : {len(inv['unknown'])}",
        "",
        "SESSIONS",
        "--------",
    ]
    if inv["sessions"]:
        for session, count in sorted(inv["sessions"].items()):
            key = session[:2] if session.startswith("sp") else session[:1]
            lines.append(f"{session:<8} {count:>5} file(s) — {SESSION_LABELS.get(key, 'unknown')}")
    else:
        lines.append("No parseable QP/MS/ER sessions found.")
    if inv["unknown"]:
        lines += ["", "UNRECOGNIZED FILES", "-------------------"]
        lines.extend(f"- {p}" for p in inv["unknown"][:200])
        if len(inv["unknown"]) > 200:
            lines.append(f"... and {len(inv['unknown']) - 200} more")
    lines += ["", "This audit is informational. The real run starts only after this file is written."]
    return "\n".join(lines) + "\n"



def _primary_failure(log_text: str, exit_code: str) -> tuple[str, str, str]:
    """Translate runner output into a human-readable failure category."""
    if str(exit_code) == "0":
        return "none", "none", "No failure."
    lines = [line.strip() for line in log_text.splitlines() if line.strip()]
    joined = "\n".join(lines)
    low = joined.lower()
    stage_match = re.search(r"stage\s+(s\d+[a-z]?)", low)
    stage = stage_match.group(1).upper() if stage_match else "unknown"
    rules = [
        ("Windows console/output encoding", "unicodeencodeerror|charmap|codec can.t encode"),
        ("Memory/resource limit", "insufficient memory|memavailable|out of memory|oom|memoryerror|worker killed|exit code 137"),
        ("Question-paper identity / filename parsing", "cannot parse cambridge paper identity|cannot re-identify qp|paper identity"),
        ("QP cropping mechanism", "qp crop|qp_cropping|qp cropping|stage s2|crop_qp"),
        ("MS cropping mechanism", "ms crop|ms_cropping|ms cropping|stage s3|mark scheme crop"),
        ("Missing question paper", "missing_qp|no qp|qp input missing|question paper.*missing"),
        ("Missing mark scheme", "missing_ms|no ms|mark scheme.*missing|ms input missing"),
        ("QP/MS pairing", "pair validation|pairing|missing ms for q|missing qp for q|question.*mismatch"),
        ("Question classification", "classification.*failed|classif.*review|winner set|topic.*taxonomy"),
        ("Output writing/commit", "output write|commit failed|staging commit|i/o error|metadata.*invalid"),
        ("Final validation/audit", "final validation|final audit|stage s8|validation failed"),
    ]
    category = "Unclassified runner failure"
    for name, pattern in rules:
        if re.search(pattern, low, re.IGNORECASE):
            category = name
            break
    reason = "No detailed reason was captured; inspect the full run log."
    preferred = []
    for line in lines:
        l = line.lower()
        if ("cannot parse" in l or "stage crashed" in l or "fatal" in l
                or line.startswith("FAIL") or "crop failed" in l
                or "missing" in l or "mismatch" in l or "exception" in l):
            preferred.append(line)
    if preferred:
        reason = preferred[0]
    elif lines:
        reason = lines[-1]
    return category, stage, reason


def build_report(args) -> str:
    input_dir = Path(args.input).resolve()
    output_dir = Path(args.output).resolve()
    log_path = Path(args.log).resolve() if args.log else None
    inv = input_inventory(input_dir)
    out = output_inventory(output_dir)
    log_text = _read(log_path) if log_path else ""
    exit_code = str(args.exit_code)
    status = {"0": "SUCCESS", "2": "COMPLETED WITH REVIEW", "1": "FAILED"}.get(exit_code, f"EXIT CODE {exit_code}")
    failure_category, failure_stage, failure_reason = _primary_failure(log_text, exit_code)
    start = args.started or "unknown"
    end = args.finished or time.strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "EXAMVOID TOPICAL GENERATOR RUN REPORT",
        "======================================",
        f"Status       : {status}",
        f"Exit code    : {exit_code}",
        f"Started      : {start}",
        f"Finished     : {end}",
        f"Session filter: {args.session or '(all sessions)'}",
        f"Subject filter: {args.subject or '(all subjects)'}",
        f"Resource profile: {args.profile or '(not recorded)'}",
        "",
        "PATHS",
        "-----",
        f"Project      : {Path(args.project).resolve() if args.project else PROJECT_ROOT}",
        f"Input        : {input_dir}",
        f"Output       : {output_dir}",
        f"Run log      : {log_path or '(not captured)'}",
        f"Input audit  : {Path(args.project).resolve() / 'input_audit.txt' if args.project else '(not captured)'}",
        "",
        "PRIMARY FAILURE (HUMAN-READABLE)",
        "---------------------------------",
        f"Category     : {failure_category}",
        f"Stage        : {failure_stage}",
        f"Reason       : {failure_reason}",
        "",
        "INPUT INVENTORY",
        "---------------",
        f"PDFs scanned : {inv['pdfs']}",
        f"QP files     : {inv['kinds'].get('qp', 0)}",
        f"MS files     : {inv['kinds'].get('ms', 0)}",
        f"ER files     : {inv['kinds'].get('er', 0)}",
        f"Other parsed : {sum(v for k, v in inv['kinds'].items() if k not in {'qp', 'ms', 'er'})}",
        f"Unrecognized : {len(inv['unknown'])}",
    ]
    if inv["sessions"]:
        lines.append("Sessions:")
        for session, count in sorted(inv["sessions"].items()):
            season = SESSION_LABELS.get(session[:2] if session.startswith("sp") else session[:1], "unknown")
            lines.append(f"  {session:<8} {count:>5} file(s) — {season}")
    lines += [
        "",
        "OUTPUT INVENTORY",
        "----------------",
        f"Question folders: {out['question_folders']}",
        f"metadata.json   : {out['metadata']}",
        f"Summer_2026 Qs  : {out['summer_2026']}",
        f"Review folders  : {out['reviews']}",
        "",
        "ERRORS / ACTIONABLE LINES",
        "--------------------------",
    ]
    errors = _error_lines(log_text)
    # Batch workers keep their detailed trace under .staging even when the
    # parent log only says that a bundle failed. Pull a few actionable lines
    # into report.txt so the user does not have to guess which file to send.
    worker_logs = sorted(output_dir.glob(".staging/**/worker_log.txt"))
    worker_logs += sorted(output_dir.glob("paper_failures/**/worker_log.txt"))
    for worker_log in worker_logs:
        if len(errors) >= 80:
            break
        for line in _error_lines(_read(worker_log, 100000)):
            tagged = f"{worker_log}: {line}"
            if tagged not in errors:
                errors.append(tagged)
            if len(errors) >= 80:
                break
    if errors:
        lines.extend(f"- {line}" for line in errors)
    else:
        lines.append("No actionable error lines were found in the captured log.")
    if inv["unknown"]:
        lines += ["", "UNRECOGNIZED INPUT FILES", "------------------------"]
        lines.extend(f"- {p}" for p in inv["unknown"][:100])
        if len(inv["unknown"]) > 100:
            lines.append(f"... and {len(inv['unknown']) - 100} more")
    lines += [
        "",
        "RELATED FAILURE FILES",
        "----------------------",
    ]
    related = []
    for candidate in [
        output_dir / "failure_report.txt",
        output_dir / "failed_papers_report.txt",
        output_dir / "failed_papers_report.json",
    ]:
        if candidate.exists():
            related.append(candidate)
    related.extend(sorted(output_dir.glob("paper_failures/**/failure_report.txt")))
    related.extend(sorted(output_dir.glob("paper_failures/**/worker_log.txt")))
    related.extend(sorted(output_dir.glob(".staging/**/failure_report.txt")))
    related.extend(sorted(output_dir.glob(".staging/**/worker_log.txt")))
    if related:
        lines.extend(f"- {p}" for p in related[:100])
    else:
        lines.append("None found.")
    lines += [
        "",
        "SEND THIS FILE FIRST. If it names a worker_log.txt, send that log too",
        "when the first report does not contain enough detail.",
    ]
    return "\n".join(lines) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--project", default=str(PROJECT_ROOT))
    ap.add_argument("--log", default=None)
    ap.add_argument("--report", default=None)
    ap.add_argument("--archive", default=None)
    ap.add_argument("--exit-code", default="0")
    ap.add_argument("--started", default="")
    ap.add_argument("--finished", default="")
    ap.add_argument("--session", default="")
    ap.add_argument("--subject", default="")
    ap.add_argument("--profile", default="")
    ap.add_argument("--audit-only", action="store_true")
    args = ap.parse_args(argv)
    default_name = "input_audit.txt" if args.audit_only else "report.txt"
    report_path = Path(args.report or (Path(args.project) / default_name)).resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    text = build_input_audit(Path(args.input)) if args.audit_only else build_report(args)
    report_path.write_text(text, encoding="utf-8")
    if args.archive:
        archive = Path(args.archive).resolve()
        archive.parent.mkdir(parents=True, exist_ok=True)
        archive.write_text(text, encoding="utf-8")
    print(f"Created report: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
