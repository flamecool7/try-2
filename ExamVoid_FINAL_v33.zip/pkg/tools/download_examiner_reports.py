#!/usr/bin/env python3
"""Download public Cambridge examiner reports for the configured subjects.

Scope defaults to every ``subjects/*/*/config.json`` profile in this project,
for 2020--2025 and the published March/February-March, May/June, and
October/November sessions. Cambridge is tried first; publicly accessible
PapaCambridge links are the mirror fallback. PastPapers.co URLs are checked as
additional candidates, but HTML/Cloudflare pages are rejected rather than
bypassed.

No login, paywall, CAPTCHA, robots, or access-control circumvention is used.
Only documents that are publicly served as genuine PDFs and pass a lightweight
examiner-report identity check are placed in the archive. Missing reports are
recorded in MANIFEST.json instead of being guessed.

Examples:
    python tools/download_examiner_reports.py --dry-run
    python tools/download_examiner_reports.py --output-root er_archive_2020_2025 \
        --zip Examiner_Reports_2020-2025_ExamVoid.zip

The generated archive is intended for the operator's own research/workflow;
source URLs and SHA-256 checksums are included for provenance.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import html
import json
import os
import re
import shutil
import tempfile
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from urllib.parse import quote, unquote, urljoin, urlparse
from zipfile import ZIP_DEFLATED, ZipFile

import requests

try:
    import fitz  # PyMuPDF
except Exception:  # pragma: no cover - dependency is in requirements.txt
    fitz = None

ROOT = Path(__file__).resolve().parents[1]
PAPACAMBRIDGE_ROOT = "https://pastpapers.papacambridge.com/"
PAPA_CATEGORY = {
    "A-Level": "https://pastpapers.papacambridge.com/papers/caie/as-and-a-level",
    "IGCSE": "https://pastpapers.papacambridge.com/papers/caie/igcse",
}
YEARS = tuple(range(2020, 2026))
SESSION_SLUGS = {
    "feb-march": "m",
    "march": "m",
    "may-june": "s",
    "oct-nov": "w",
}
SESSION_WORDS = {
    "m": ("february", "march", "feb-march", "march"),
    "s": ("may", "june", "may-june", "summer"),
    "w": ("october", "november", "oct-nov", "winter"),
}
REPORT_SIGNALS = (
    "examiner report", "principal examiner report", "general comments",
    "comments on specific questions", "candidate performance",
    "common errors", "for teachers",
)
REJECT_SIGNALS = ("mark scheme", "question paper", "grade threshold")
USER_AGENT = "ExamVoid-examiner-report-archive/1.0 (+public-PDF-only; contact operator)"

# Official slugs already used by ExamVoid. Other codes receive a conservative
# slug guess from the public PapaCambridge category link.
OFFICIAL_SLUGS = {
    "0610": "cambridge-igcse-biology-0610",
    "0620": "cambridge-igcse-chemistry-0620",
    "0625": "cambridge-igcse-physics-0625",
    "0580": "cambridge-igcse-mathematics-0580",
    "0606": "cambridge-igcse-additional-mathematics-0606",
    "0478": "cambridge-igcse-computer-science-0478",
    "0455": "cambridge-igcse-economics-0455",
    "0450": "cambridge-igcse-business-studies-0450",
    "0475": "cambridge-igcse-literature-in-english-0475",
    "0470": "cambridge-igcse-history-0470",
    "0417": "cambridge-igcse-information-and-communication-technology-0417",
    "0460": "cambridge-igcse-geography-0460",
    "9700": "cambridge-international-as-and-a-level-biology-9700",
    "9701": "cambridge-international-as-and-a-level-chemistry-9701",
    "9702": "cambridge-international-as-and-a-level-physics-9702",
    "9709": "cambridge-international-as-and-a-level-mathematics-9709",
    "9231": "cambridge-international-as-and-a-level-further-mathematics-9231",
    "9618": "cambridge-international-as-and-a-level-computer-science-9618",
    "9708": "cambridge-international-as-and-a-level-economics-9708",
    "9609": "cambridge-international-as-and-a-level-business-9609",
    "9695": "cambridge-international-as-and-a-level-english-literature-9695",
    "9489": "cambridge-international-as-and-a-level-history-9489",
    "9626": "cambridge-international-as-and-a-level-information-technology-9626",
    "9696": "cambridge-international-as-and-a-level-geography-9696",
}


@dataclass(frozen=True)
class Profile:
    level: str
    code: str
    subject: str
    papa_url: str = ""
    official_url: str = ""


@dataclass
class ReportCandidate:
    code: str
    subject: str
    level: str
    year: int
    season: str
    filename: str
    candidates: list[dict]
    discovered_from: str = ""


class FetchStats:
    def __init__(self):
        self.ok = 0
        self.missing = 0
        self.rejected = 0
        self.errors = 0


def _get(url: str, *, timeout: int = 20) -> requests.Response:
    return requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=timeout)


def _hrefs(text: str) -> list[str]:
    values = re.findall(r"(?:href|data-link|data-links)=[\"']([^\"']+)[\"']", text, re.I)
    return [html.unescape(unquote(v)).strip() for v in values]


def _root_url(href: str) -> str:
    if href.startswith("http://") or href.startswith("https://"):
        return href
    return urljoin(PAPACAMBRIDGE_ROOT, href.lstrip("./"))


def _load_profiles() -> list[Profile]:
    profiles = []
    for cfg_path in sorted((ROOT / "subjects").glob("*/*/config.json")):
        data = json.loads(cfg_path.read_text(encoding="utf-8"))
        profiles.append(Profile(
            level=str(data["level"]),
            code=str(data["syllabus_code"]),
            subject=str(data["subject"]),
        ))
    return profiles


def _category_mapping(level: str, codes: set[str]) -> dict[str, str]:
    """Discover PapaCambridge subject-page URLs from its public category page."""
    try:
        text = _get(PAPA_CATEGORY[level]).text
    except Exception:
        return {}
    mapping = {}
    for href in _hrefs(text):
        m = re.search(r"(?<!\d)(\d{4})(?!\d)", href)
        if not m or m.group(1) not in codes:
            continue
        mapping.setdefault(m.group(1), _root_url(href))
    # 9618 and occasionally newly listed subjects are exposed through the
    # category search parameter rather than the initial category listing.
    for code in sorted(codes - set(mapping)):
        try:
            text = _get(PAPA_CATEGORY[level] + "?search=" + quote(code)).text
            for href in _hrefs(text):
                if re.search(rf"(?<!\d){re.escape(code)}(?!\d)", href):
                    mapping.setdefault(code, _root_url(href))
        except Exception:
            continue
    return mapping


def _official_url(code: str, level: str, papa_url: str) -> str:
    slug = OFFICIAL_SLUGS.get(code)
    if not slug and papa_url:
        tail = urlparse(papa_url).path.rstrip("/").split("/")[-1]
        if tail.startswith("as-and-a-level-"):
            slug = "cambridge-international-" + tail
        elif tail.startswith("igcse-"):
            slug = "cambridge-" + tail
    return (
        f"https://www.cambridgeinternational.org/programmes-and-qualifications/{slug}/past-papers/"
        if slug else ""
    )


def _discover_official(profile: Profile) -> list[dict]:
    if not profile.official_url:
        return []
    try:
        response = _get(profile.official_url)
        if response.status_code != 200:
            return []
    except Exception:
        return []
    found = []
    text = response.text
    for match in re.finditer(
        r"<a\b[^>]*href=[\"']([^\"']+\.pdf[^\"']*)[\"'][^>]*>(.*?)</a>",
        text, re.I | re.S,
    ):
        href, anchor = match.groups()
        label = re.sub(r"<[^>]+>", " ", anchor)
        hay = f"{href} {label}".lower()
        if not any(signal in hay for signal in ("examiner report", "examiner-report")):
            continue
        year_match = re.search(r"20(20|21|22|23|24|25)", hay)
        if not year_match:
            continue
        year = int(year_match.group(0))
        season = None
        for letter, words in SESSION_WORDS.items():
            if any(word in hay for word in words):
                season = letter
                break
        # Official links often say only “June 2024”; that is May/June.
        if season is None and any(x in hay for x in ("june", "may")):
            season = "s"
        if season is None:
            continue
        found.append({
            "source": "cambridge_official",
            "url": urljoin(profile.official_url, html.unescape(href)),
            "year": year,
            "season": season,
            "label": re.sub(r"\s+", " ", label).strip(),
        })
    return found


def _session_pages(profile: Profile) -> list[tuple[int, str, str]]:
    """Return (year, season, page URL) for public Papa session folders."""
    try:
        response = _get(profile.papa_url)
        if response.status_code != 200:
            return []
    except Exception:
        return []
    out = []
    code = re.escape(profile.code)
    for href in _hrefs(response.text):
        absolute = _root_url(href)
        path = urlparse(absolute).path.lower()
        m = re.search(rf"(?<!\d)({code})-(20\d{{2}})-(feb-march|march|may-june|oct-nov)(?:/)?$", path)
        if m:
            year, slug = int(m.group(2)), m.group(3)
        else:
            # PapaCambridge has a legacy reverse form for some 2020 pages:
            # <code>-may-june-2020.
            m = re.search(rf"(?<!\d)({code})-(feb-march|march|may-june|oct-nov)-(20\d{{2}})(?:/)?$", path)
            if not m:
                continue
            slug, year = m.group(2), int(m.group(3))
        if year not in YEARS:
            continue
        out.append((year, SESSION_SLUGS[slug], absolute))
    return sorted(set(out))


def _papa_report_urls(text: str, code: str, year: int, season: str) -> list[str]:
    yy = str(year)[2:]
    filename = f"{code}_{season}{yy}_er.pdf"
    direct = []
    # Prefer the direct upload URL embedded in Papa's Download File link.
    for href in _hrefs(text):
        low = href.lower()
        if filename.lower() in low and low.endswith("_er.pdf"):
            direct.append(href)
    direct.extend(re.findall(
        rf"https?[^\"'<>\s]+/{re.escape(filename)}", text, re.I
    ))
    # De-duplicate while preserving order and reject wrapper links that are not
    # the actual public PDF URL.
    result = []
    for url in direct:
        url = html.unescape(url).replace("&amp;", "&")
        if "download_file.php?files=" in url.lower():
            nested = url.split("files=", 1)[1]
            url = unquote(nested)
        if url not in result:
            result.append(url)
    return result


def _mirror_candidates(profile: Profile, year: int, season: str) -> list[dict]:
    yy = str(year)[2:]
    filename = f"{profile.code}_{season}{yy}_er.pdf"
    # The Papa URL is always available as a deterministic final fallback even
    # if its session page failed to render.
    papa = (
        "https://pastpapers.papacambridge.com/directories/CAIE/"
        f"CAIE-pastpapers/upload/{filename}"
    )
    # PastPapers.co's direct endpoint is checked but never challenged/bypassed
    # if it returns a bot-check HTML page.
    subject_slug = profile.subject.rsplit("_", 1)[0].replace("_", "-").lower()
    level_slug = "a-level" if profile.level == "A-Level" else "igcse"
    season_folder = {"s": "May-June", "w": "October-November", "m": "February-March"}[season]
    past = (
        f"https://pastpapers.co/caie/{level_slug}/{subject_slug}-{profile.code}/"
        f"{year}-{season_folder}/{filename}"
    )
    return [
        {"source": "papacambridge", "url": papa},
        {"source": "pastpapers.co", "url": past},
    ]


def _discover_profile(profile: Profile):
    """Fetch one profile's official page and its public session pages.

    This unit is run in a bounded thread pool: the 76-profile archive should
    not wait serially on a slow/unavailable website, but the worker count stays
    small enough to remain polite.
    """
    official = _discover_official(profile)
    session_items = []
    for year, season, page in _session_pages(profile):
        urls = []
        try:
            response = _get(page)
            if response.status_code == 200:
                urls = _papa_report_urls(response.text, profile.code, year, season)
        except Exception:
            pass
        session_items.append((year, season, page, urls))
    return profile, official, session_items


def discover_candidates(profiles: list[Profile]) -> list[ReportCandidate]:
    by_level = {
        level: {p.code for p in profiles if p.level == level}
        for level in PAPA_CATEGORY
    }
    mappings = {
        level: _category_mapping(level, codes)
        for level, codes in by_level.items()
    }
    enriched = []
    for p in profiles:
        papa = mappings.get(p.level, {}).get(p.code, "")
        enriched.append(Profile(
            p.level, p.code, p.subject, papa,
            _official_url(p.code, p.level, papa),
        ))

    all_candidates: dict[tuple[str, int, str], ReportCandidate] = {}
    allowed_slots = {(year, season) for year in YEARS for season in SESSION_WORDS}

    def get_report(profile: Profile, year: int, season: str, source: str) -> ReportCandidate:
        key = (profile.code, year, season)
        return all_candidates.setdefault(key, ReportCandidate(
            code=profile.code, subject=profile.subject, level=profile.level,
            year=year, season=season,
            filename=f"{profile.code}_{season}{str(year)[2:]}_er.pdf",
            candidates=[], discovered_from=source,
        ))

    max_workers = min(8, max(1, len(enriched)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(_discover_profile, profile) for profile in enriched]
        for index, future in enumerate(concurrent.futures.as_completed(futures), 1):
            try:
                profile, official, session_items = future.result()
            except Exception:
                continue
            for item in official:
                if (item["year"], item["season"]) not in allowed_slots:
                    continue
                get_report(profile, item["year"], item["season"], "official").candidates.insert(0, item)
            for year, season, page, urls in session_items:
                report = get_report(profile, year, season, "papacambridge")
                for url in urls:
                    report.candidates.append({
                        "source": "papacambridge",
                        "url": url,
                        "index_page": page,
                    })
                report.candidates.extend(_mirror_candidates(profile, year, season))
            if index % 10 == 0 or index == len(enriched):
                print(f"[er-archive] discovery {index}/{len(enriched)} profiles", flush=True)

    # Some profiles have an index page without session-folder links. Add
    # deterministic public mirror candidates for every requested slot; the
    # downloader proves availability with a genuine-PDF identity check.
    for profile in enriched:
        for year, season in sorted(allowed_slots):
            report = get_report(profile, year, season, "deterministic-fallback")
            report.candidates.extend(_mirror_candidates(profile, year, season))

    # Keep only reports with candidates and de-duplicate URLs in source order.
    result = []
    for report in all_candidates.values():
        seen = set()
        candidates = []
        for candidate in report.candidates:
            url = candidate.get("url", "")
            if url and url not in seen:
                seen.add(url)
                candidates.append(candidate)
        report.candidates = candidates
        if candidates:
            result.append(report)
    return sorted(result, key=lambda r: (r.level, r.subject, r.year, r.season))


def _validate_pdf(path: Path, report: ReportCandidate) -> tuple[bool, str]:
    try:
        if path.stat().st_size < 10_000 or path.read_bytes()[:5] != b"%PDF-":
            return False, "not a genuine PDF payload"
    except OSError as exc:
        return False, str(exc)
    if fitz is None:
        return True, "magic/size verified; PyMuPDF unavailable"
    try:
        doc = fitz.open(str(path))
        text = ""
        for index, page in enumerate(doc):
            text += page.get_text("text") or ""
            if index >= 30 and len(text) > 50_000:
                break
        doc.close()
    except Exception as exc:
        return False, f"PDF failed to open: {exc}"
    low = text.lower()
    if not any(signal in low for signal in REPORT_SIGNALS):
        return False, "no examiner-report identity signal in extracted text"
    if any(signal in low for signal in REJECT_SIGNALS) and not any(signal in low for signal in REPORT_SIGNALS):
        return False, "looks like QP/MS/grade-threshold material"
    return True, "examiner-report signals verified"


def _download_one(report: ReportCandidate, output_root: Path, stats: FetchStats) -> dict:
    rel = Path(report.level) / report.subject / str(report.year) / report.season
    dest = output_root / rel / report.filename
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        ok, why = _validate_pdf(dest, report)
        if ok:
            data = dest.read_bytes()
            return {
                "status": "downloaded", "path": dest.relative_to(output_root).as_posix(),
                "source": "existing", "url": "", "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(), "validation": why,
            }
        dest.unlink(missing_ok=True)

    errors = []
    for candidate in report.candidates:
        url = candidate["url"]
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            response = _get(url, timeout=90)
            content_type = (response.headers.get("content-type") or "").lower()
            if response.status_code != 200 or not response.content.startswith(b"%PDF-"):
                errors.append(f"{candidate['source']}: HTTP {response.status_code} non-PDF ({content_type})")
                continue
            tmp.write_bytes(response.content)
            ok, why = _validate_pdf(tmp, report)
            if not ok:
                errors.append(f"{candidate['source']}: {why}")
                tmp.unlink(missing_ok=True)
                continue
            os.replace(tmp, dest)
            data = dest.read_bytes()
            stats.ok += 1
            return {
                "status": "downloaded", "path": dest.relative_to(output_root).as_posix(),
                "source": candidate["source"], "url": url, "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(), "validation": why,
            }
        except Exception as exc:
            errors.append(f"{candidate['source']}: {exc}")
            tmp.unlink(missing_ok=True)
    stats.missing += 1
    return {
        "status": "missing", "path": dest.relative_to(output_root).as_posix(),
        "source": "", "url": "", "bytes": 0, "sha256": "",
        "validation": "; ".join(errors[-5:]),
    }


def _write_readme(output_root: Path, manifest: dict) -> None:
    text = f"""ExamVoid Examiner Reports Archive\n================================\nScope: configured ExamVoid subjects, years 2020-2025.\nReports downloaded: {manifest['summary']['downloaded']}\nReports missing/unavailable: {manifest['summary']['missing']}\n\nSources are recorded per file in MANIFEST.json. Cambridge International is\ntried first; public mirror PDFs are used only when directly accessible. No\nlogin, paywall, CAPTCHA, robots, or access-control bypass was attempted.\nThe archive is for the operator's own research/workflow; retain the source\nprovenance and comply with the applicable site/Cambridge terms.\n"""
    (output_root / "README.txt").write_text(text, encoding="utf-8")


def make_zip(output_root: Path, zip_path: Path) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(zip_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(output_root.rglob("*")):
            if path.is_file():
                archive.write(path, Path(output_root.name) / path.relative_to(output_root))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", default="examiner_reports_2020_2025")
    parser.add_argument("--zip", default="Examiner_Reports_2020-2025_ExamVoid.zip")
    parser.add_argument("--years", default="2020-2025")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--dry-run", action="store_true", help="discover candidates only")
    args = parser.parse_args(argv)

    start, end = (int(x) for x in args.years.split("-", 1))
    if (start, end) != (2020, 2025):
        global YEARS
        YEARS = tuple(range(start, end + 1))
    profiles = _load_profiles()
    print(f"[er-archive] profiles: {len(profiles)}")
    candidates = discover_candidates(profiles)
    print(f"[er-archive] report slots discovered: {len(candidates)}")
    candidate_manifest = [asdict(c) for c in candidates]

    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    if args.dry_run:
        (output_root / "CANDIDATES.json").write_text(
            json.dumps(candidate_manifest, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        print(f"[er-archive] dry-run manifest: {output_root / 'CANDIDATES.json'}")
        return 0

    stats = FetchStats()
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = [pool.submit(_download_one, r, output_root, stats) for r in candidates]
        for index, future in enumerate(concurrent.futures.as_completed(futures), 1):
            result = future.result()
            results.append(result)
            if index % 25 == 0 or index == len(futures):
                print(f"[er-archive] progress {index}/{len(futures)} "
                      f"downloaded={stats.ok} missing={stats.missing}")

    results.sort(key=lambda r: r["path"])
    summary = {
        "profiles": len(profiles),
        "slots": len(candidates),
        "downloaded": sum(r["status"] == "downloaded" for r in results),
        "missing": sum(r["status"] == "missing" for r in results),
        "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    manifest = {
        "schema": "examvoid_examiner_reports/1",
        "scope": {"years": list(YEARS), "profile_count": len(profiles)},
        "summary": summary,
        "candidates": candidate_manifest,
        "files": results,
    }
    (output_root / "MANIFEST.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    _write_readme(output_root, manifest)
    make_zip(output_root, Path(args.zip))
    print(f"[er-archive] complete: {summary}")
    print(f"[er-archive] zip: {Path(args.zip).resolve()}")
    return 0 if summary["downloaded"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
