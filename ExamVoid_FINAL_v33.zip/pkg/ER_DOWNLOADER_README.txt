ExamVoid Examiner Report Downloader
====================================

What this package does
----------------------
Double-click download_examiner_reports.bat. It scans the 76 subject profiles
included in this package for public Cambridge examiner reports from 2020 through
2025, checks the downloaded payloads are genuine examiner-report PDFs, and
creates:

  examiner_reports_2020_2025\
  Examiner_Reports_2020-2025_ExamVoid.zip

A MANIFEST.json is written inside the output folder. It lists each attempted
report, the source URL, SHA-256 checksum, validation result, and reports that
were unavailable.

First run
---------
The batch file looks for Python 3.10 or newer using the Windows `py -3`
launcher or `python`. It automatically installs the two downloader packages
from requirements-er-downloader.txt if they are missing:

  requests
  PyMuPDF

Keep the batch file in this package root. The `tools` and `subjects` folders
must remain beside it.

Optional command-line modes
---------------------------
From Command Prompt in this folder:

  download_examiner_reports.bat --dry-run

The dry run discovers candidate reports without downloading PDFs.

Source and access policy
------------------------
Cambridge International is tried first, followed by publicly accessible
PapaCambridge links and direct PastPapers.co candidates. The downloader does
not use logins, paywalls, CAPTCHA bypasses, robots bypasses, or access-control
circumvention. HTML bot-check pages are rejected and recorded as unavailable.

The resulting archive is intended for the operator's own research/workflow.
Keep the source URLs and comply with the applicable Cambridge and website
terms when using or sharing the downloaded documents.
