#!/usr/bin/env python3
"""Offline examiner-report inventory for ExamVoid.

This utility recursively scans one or more folders for Cambridge PDFs and
compares every identified QP/MS bundle with the Examiner Reports already
present in the scanned tree.  It does not download anything and does not
modify input PDFs or ExamVoid output.

Examples (Windows, from the pkg folder):

    py -3 check_existing_ers.py --root .
    py -3 check_existing_ers.py --root input --root examiner_reports_2020_2025
    py -3 check_existing_ers.py --root "D:\\Exam Papers" --out-dir reports

Reports written to --out-dir:
    missing_examiner_reports.txt       human-readable missing list
    examiner_report_inventory.csv      one row per QP/MS bundle
    examiner_report_inventory.json     complete machine-readable inventory

Matching rules mirror ExamVoid's input identity rules:
  * an ER with no component, e.g. 9701_s26_er.pdf, covers every matching
    component in that syllabus/session;
  * a component ER, e.g. 9701_s26_er_12.pdf, matches the same paper number
    (the first digit of the component), so it also covers variants 11/12/13;
  * QP/MS files may be in different folders as long as they are scanned by a
    supplied root.

Missing is a result, not a program error. Use --fail-if-missing when this
command is being used in an automated check.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Optional

# Make the script work when launched directly from the packaged pkg folder.
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

try:
    from core.paper_identifier import parse_paper_filename as _examvoid_parse_paper_filename
    _PARSER_IMPORT_ERROR = None
except Exception as exc:  # Keep this checker usable before full dependencies are installed.
    _examvoid_parse_paper_filename = None
    _PARSER_IMPORT_ERROR = exc


SEASON_LABELS = {
    "m": "February-March (Spring)",
    "s": "May-June (Summer)",
    "w": "October-November (Winter)",
    "sp": "Specimen",
}

# Kept locally so the checker also works as a standalone folder without the
# main ExamVoid package or its optional PDF dependencies installed.
FALLBACK_SUBJECTS = {
    "0417": "ICT_0417", "0450": "Business_Studies_0450",
    "0455": "Economics_0455", "0460": "Geography_0460",
    "0470": "History_0470", "0475": "Literature_in_English_0475",
    "0478": "Computer_Science_0478", "0580": "Mathematics_0580",
    "0606": "Additional_Mathematics_0606", "0610": "Biology_0610",
    "0620": "Chemistry_0620", "0625": "Physics_0625",
    "8021": "English_General_Paper_8021",
    "9700": "Biology_9700", "9701": "Chemistry_9701",
    "9702": "Physics_9702", "9706": "Accounting_9706",
    "9708": "Economics_9708", "9709": "Mathematics_9709",
    "9231": "Further_Mathematics_9231", "9489": "History_9489",
    "9609": "Business_9609", "9618": "Computer_Science_9618",
    "9626": "Information_Technology_9626", "9695": "English_Literature_9695",
    "9696": "Geography_9696", "9699": "Sociology_9699",
    "9990": "Psychology_9990",
}

# These folders are common in a copied Python project and are never useful as
# paper roots. The walk remains recursive, but avoids dependency/cache noise.
IGNORED_DIR_NAMES = {
    ".git", ".venv", "venv", "env", "node_modules", "__pycache__",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox",
    ".next", ".cache", "build", "dist", "coverage", "target",
}


@dataclass
class _FallbackInfo:
    """Small filename-only identity object used if PyMuPDF is not installed.

    The normal ExamVoid parser remains authoritative whenever the packaged
    dependencies are available. This fallback only keeps the offline report
    usable on a fresh machine before ``requirements.txt`` has been installed.
    """
    file_path: Path
    syllabus_code: str
    year: str
    year_short: str
    season: str
    season_letter: str
    paper_type: str
    variant: str
    full_code: str
    level: str
    subject_guess: str = ""
    paper_format: str = ""


_FALLBACK_SEASON = {
    "m": "m", "f": "m", "s": "s", "j": "s", "w": "w", "n": "w",
    "mj": "s", "on": "w", "fm": "m", "sp": "sp", "spec": "sp",
    "specimen": "sp", "spring": "m", "summer": "s", "winter": "w",
    "march": "m", "may": "s", "june": "s",
}
_FALLBACK_MONTH = {
    "january": "m", "february": "m", "february-march": "m",
    "march": "m", "april": "m", "may": "s", "may-june": "s",
    "june": "s", "july": "s", "august": "s", "september": "s",
    "october": "w", "october-november": "w", "november": "w",
    "december": "w",
}


def _fallback_level(code: str) -> str:
    code = str(code)
    if code.startswith(("04", "05", "06", "09")):
        return "IGCSE"
    if code.startswith(("80", "86", "90", "92", "94", "96", "97")):
        return "A-Level"
    return "A-Level" if code.startswith("9") else "IGCSE"


def _fallback_parse_paper_filename(path: Path):
    """Parse the common ExamVoid filename forms without importing core.

    This is deliberately a rescue path, not a second production identity
    implementation. It covers the canonical ``9701_s26_er`` form and the
    normal long Cambridge names used by the ER checker.
    """
    stem = path.stem.lower().replace("–", "-")
    code_match = re.search(r"(?<!\d)(\d{4})(?!\d)", stem)
    if not code_match:
        return None
    code = code_match.group(1)
    level = _fallback_level(code)
    subject = FALLBACK_SUBJECTS.get(code, "")
    try:
        from core.config_loader import KNOWN_CODE_MAP
        subject = str(KNOWN_CODE_MAP.get(code, subject) or subject)
    except Exception:
        pass

    # Canonical short form: 9701_s26_er[_12], 9701_s26_qp_12, etc.
    short = re.search(
        r"(?<!\d)(?P<season>sp|spec|mj|on|fm|f|m|s|j|w|n)(?P<year>\d{2})(?:[_-])?"
        r"(?P<kind>qp|ms|er)(?:[_-]?(?P<variant>\d{1,2}))?\b",
        stem,
        re.IGNORECASE,
    )
    if short:
        season = _FALLBACK_SEASON[short.group("season").lower()]
        yy = short.group("year")
        kind = short.group("kind").lower()
        variant = short.group("variant") or ""
        return _FallbackInfo(
            file_path=path, syllabus_code=code, year=f"20{yy}",
            year_short=yy, season=SEASON_LABELS.get(season, season),
            season_letter=season, paper_type=kind, variant=variant,
            full_code=f"{code}_{season}{yy}_{kind}" + (f"_{variant}" if variant else ""),
            level=level, subject_guess=subject,
        )

    # Long form: 9701 Chemistry May-June 2026 Examiner Report 12.pdf.
    month = re.search(
        r"\b(february[- ]march|march|may[- ]june|may|june|"
        r"october[- ]november|october|november|spring|summer|winter)\b",
        stem,
        re.IGNORECASE,
    )
    year_match = re.search(r"(?<!\d)(20\d{2})(?!\d)", stem)
    if not month or not year_match:
        return None
    month_key = month.group(1).lower().replace(" ", "-")
    season = _FALLBACK_MONTH.get(month_key) or _FALLBACK_SEASON.get(month_key)
    if not season:
        return None
    if re.search(r"examiner[ _-]*report|principal[ _-]*examiner", stem):
        kind = "er"
    elif re.search(r"mark[ _-]*scheme|marking[ _-]*scheme", stem):
        kind = "ms"
    elif re.search(r"question[ _-]*paper", stem):
        kind = "qp"
    else:
        return None
    yy = year_match.group(1)[-2:]
    variant_match = re.search(r"(?:examiner[ _-]*report|question[ _-]*paper|mark[ _-]*scheme)"
                              r"[ _-]*(\d{1,2})\b", stem)
    variant = (variant_match.group(1) if variant_match else "")
    if kind in {"qp", "ms"} and not variant:
        variant = "12"
    return _FallbackInfo(
        file_path=path, syllabus_code=code, year=year_match.group(1),
        year_short=yy, season=SEASON_LABELS.get(season, season),
        season_letter=season, paper_type=kind, variant=variant,
        full_code=f"{code}_{season}{yy}_{kind}" + (f"_{variant}" if variant else ""),
        level=level, subject_guess=subject,
    )


def _context_session_year(text: str) -> tuple[Optional[str], Optional[str]]:
    """Recover a session/year from the full path, not only the filename.

    ER archives are often arranged as ``Subject\\2026\\May-June`` while the
    file itself is simply ``Examiner Report.pdf``. The production parser cannot
    infer identity from a parent directory, so this checker adds a conservative
    path-context rescue for inventory purposes.
    """
    low = text.lower().replace("–", "-")
    compact = re.sub(r"[_/]+", "-", low)

    # Explicit compact codes win over month words anywhere else in the path.
    compact_session = re.search(
        r"(?<![a-z])(sp|spec|specimen|mj|m-j|m_j|on|o-n|o_n|fm|f-m|f_m|[fmswjn])[-_ ]?(20\d{2}|\d{2})(?!\d)",
        low,
    )
    season = None
    year_short = None
    if compact_session:
        raw_season = compact_session.group(1).lower()
        season = _FALLBACK_SEASON.get(raw_season)
        raw_year = compact_session.group(2)
        year_short = raw_year[-2:]

    # Specimen is more specific than a stray month in a syllabus path.
    if season is None and re.search(r"\bspec(?:imen)?\b", low):
        season = "sp"
    if season is None:
        if re.search(
            r"may[ _/\-]+june|may[ _/\-]+jun|\bsummer\b|\bmay\b|\bjune\b|\bjun\b",
            compact,
        ):
            season = "s"
        elif re.search(
            r"october[ _/\-]+november|oct[ _/\-]+nov|\bwinter\b|\boctober\b|\boct\b|\bnovember\b|\bnov\b",
            compact,
        ):
            season = "w"
        elif re.search(
            r"february[ _/\-]+march|feb[ _/\-]+mar|\bspring\b|\bfebruary\b|\bfeb\b|\bmarch\b|\bmar\b",
            compact,
        ):
            season = "m"

    if year_short is None:
        full_year = re.search(r"(?<!\d)(20\d{2})(?!\d)", low)
        if full_year:
            year_short = full_year.group(1)[-2:]
    if year_short is None and season:
        # Handles paths such as ``Summer 26`` / ``Specimen 24``.
        label = {
            "m": r"(?:spring|march|feb(?:ruary)?(?:[- /]mar(?:ch)?)?)",
            "s": r"(?:summer|may(?:[- /]jun(?:e)?)?|june)",
            "w": r"(?:winter|oct(?:ober)?(?:[- /]nov(?:ember)?)?|nov(?:ember)?)",
            "sp": r"spec(?:imen)?",
        }.get(season, "")
        if label:
            nearby = re.search(label + r"[^0-9]{0,12}(?:20)?(\d{2})\b", low)
            if nearby:
                year_short = nearby.group(1)
    if year_short is None and season == "sp":
        # Some specimen archives intentionally omit a year. Matching all
        # yearless specimen files under the same identity is safer than
        # dropping them entirely; the report labels it as unknown.
        year_short = "00"
    return season, year_short


def _context_kind(text: str) -> Optional[str]:
    low = text.lower()
    if re.search(r"principal[ _-]*examiner|examiner[ _-]*report|\bpe?er\b|(?<![a-z])ers?(?![a-z])", low):
        return "er"
    if re.search(r"mark[ _-]*(?:scheme|schemes)|marking[ _-]*scheme|markscheme|(?<![a-z])ms(?![a-z])", low):
        return "ms"
    if re.search(r"question[ _-]*paper|questionpaper|(?<![a-z])qp(?![a-z])", low):
        return "qp"
    return None


def _context_variant(text: str, kind: str) -> str:
    """Get a component from ``Paper 12``/``Component 12`` path labels."""
    low = text.lower()
    patterns = [
        r"(?<![a-z])(?:paper|component)\s*[_-]?\s*([1-9]\d?)\b",
    ]
    if kind == "er":
        patterns += [r"(?<![a-z])(?:er|report)\s*[_-]?\s*([1-9]\d?)\b"]
    elif kind == "qp":
        patterns += [r"(?<![a-z])qp\s*[_-]?\s*([1-9]\d?)\b"]
    elif kind == "ms":
        patterns += [r"(?<![a-z])ms\s*[_-]?\s*([1-9]\d?)\b"]
    for pattern in patterns:
        match = re.search(pattern, low)
        if match:
            return match.group(1)
    return ""


def _context_parse_identity(path: Path):
    """Parse identity from the filename plus all parent-folder labels."""
    text = str(path).replace("\\", "/")
    code_matches = re.findall(r"(?<!\d)(\d{4})(?!\d)", text.lower())
    # Never mistake a directory year such as 2026 for the syllabus code.
    non_year_codes = [c for c in code_matches if not c.startswith(("19", "20"))]
    code = next((c for c in non_year_codes if c in FALLBACK_SUBJECTS), None)
    if code is None and non_year_codes:
        code = non_year_codes[0]
    if code is None:
        return None
    kind = _context_kind(text)
    if kind is None:
        return None
    season, yy = _context_session_year(text)
    if season is None or yy is None:
        return None
    variant = _context_variant(text, kind)
    if kind in {"qp", "ms"} and not variant:
        # A generic Paper/Mark Scheme file can still be inventoried as a
        # year/session bundle, but do not pretend it is a numbered variant.
        variant = ""
    year = "unknown" if yy == "00" else f"20{yy}"
    return _FallbackInfo(
        file_path=path, syllabus_code=code, year=year, year_short=yy,
        season=SEASON_LABELS.get(season, season), season_letter=season,
        paper_type=kind, variant=variant,
        full_code=f"{code}_{season}{yy}_{kind}" + (f"_{variant}" if variant else ""),
        level=_fallback_level(code),
        subject_guess=FALLBACK_SUBJECTS.get(code, ""),
        paper_format="",
    )


def _normalise_parser_variant(info, path: Path):
    """Remove the production parser's default ``12`` when no component exists.

    Long Cambridge filenames such as ``... Examiner Report.pdf`` historically
    receive a default variant of ``12`` in PaperInfo. That would make the ER
    appear to cover only Paper 1 variants and falsely report Papers 2-6 as
    missing. An explicit ``Paper 12``/``Component 12``/``er_12`` marker keeps
    its component; otherwise the document is treated as session-wide.
    """
    kind = str(getattr(info, "paper_type", "") or "").lower()
    if kind not in {"qp", "ms", "er"}:
        return info
    explicit = _context_variant(str(path), kind)
    if explicit:
        try:
            info.variant = explicit
        except Exception:
            pass
    else:
        try:
            info.variant = ""
        except Exception:
            pass
    return info


def _parse_identity(path: Path):
    if _examvoid_parse_paper_filename is not None:
        info = _examvoid_parse_paper_filename(path)
        if info is not None:
            return _normalise_parser_variant(info, path)
    info = _fallback_parse_paper_filename(path)
    if info is not None:
        return _normalise_parser_variant(info, path)
    return _context_parse_identity(path)


@dataclass
class Document:
    path: str
    kind: str
    code: str
    season: str
    year_short: str
    year: str
    variant: str
    level: str
    subject: str
    paper_format: str
    size_bytes: int
    sha256: str = ""
    parse_method: str = "filename"

    @property
    def session_key(self) -> tuple[str, str, str]:
        return self.code, self.season, self.year_short

    @property
    def identity(self) -> str:
        suffix = f"_{self.variant}" if self.variant else ""
        return f"{self.code}_{self.season}{self.year_short}_{self.kind}{suffix}"


@dataclass
class Bundle:
    code: str
    season: str
    year_short: str
    year: str
    variant: str
    level: str = ""
    subject: str = ""
    paper_format: str = ""
    qp: list[Document] = field(default_factory=list)
    ms: list[Document] = field(default_factory=list)
    er: list[Document] = field(default_factory=list)

    @property
    def key(self) -> str:
        return f"{self.code}_{self.season}{self.year_short}_{self.variant}"

    @property
    def session_label(self) -> str:
        return SEASON_LABELS.get(self.season, self.season)

    @property
    def status(self) -> str:
        return "FOUND" if self.er else "MISSING_ER"

    @property
    def notes(self) -> list[str]:
        notes = []
        if not self.qp:
            notes.append("missing_qp")
        if not self.ms:
            notes.append("missing_ms")
        if len(self.qp) > 1:
            notes.append(f"duplicate_qp_x{len(self.qp)}")
        if len(self.ms) > 1:
            notes.append(f"duplicate_ms_x{len(self.ms)}")
        return notes


@dataclass
class ScanResult:
    roots: list[str]
    pdfs_scanned: int = 0
    identified_qp: int = 0
    identified_ms: int = 0
    identified_er: int = 0
    identified_other: int = 0
    unparseable: list[str] = field(default_factory=list)
    documents: list[Document] = field(default_factory=list)
    bundles: dict[str, Bundle] = field(default_factory=dict)
    orphan_ers: list[Document] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Scanning and identity
# ---------------------------------------------------------------------------


def _canonical_roots(roots: Iterable[str | Path]) -> list[Path]:
    result: list[Path] = []
    seen: set[str] = set()
    for raw in roots:
        p = Path(raw).expanduser()
        if not p.exists():
            print(f"[warning] root does not exist: {p}")
            continue
        p = p.resolve()
        key = str(p).casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(p)
    return result


def _walk_pdfs(roots: Iterable[Path]) -> list[Path]:
    paths: dict[str, Path] = {}
    for root in roots:
        if root.is_file():
            candidates = [root] if root.suffix.lower() == ".pdf" else []
        else:
            candidates = []
            for path in root.rglob("*"):
                if path.is_file() and path.suffix.lower() == ".pdf":
                    if any(part in IGNORED_DIR_NAMES for part in path.parts):
                        continue
                    candidates.append(path)
        for path in candidates:
            try:
                resolved = path.resolve()
            except OSError:
                resolved = path.absolute()
            paths.setdefault(str(resolved).casefold(), resolved)
    return sorted(paths.values(), key=lambda p: str(p).casefold())


def _document_from_info(path: Path, info, *, parse_method: str = "filename") -> Document:
    return Document(
        path=str(path),
        kind=str(info.paper_type),
        code=str(info.syllabus_code),
        season=str(info.season_letter),
        year_short=str(info.year_short),
        year=str(info.year),
        variant=str(info.variant or ""),
        level=str(info.level or ""),
        subject=str(getattr(info, "subject_guess", "") or ""),
        paper_format=str(getattr(info, "paper_format", "") or ""),
        size_bytes=path.stat().st_size if path.exists() else 0,
        parse_method=parse_method,
    )


def _content_er_identity(path: Path) -> Optional[Document]:
    """Best-effort ER identity for a PDF whose filename is not parseable.

    This is deliberately limited to ERs. It requires strong examiner-report
    text signals plus a syllabus code and session. It never turns an arbitrary
    PDF into a QP/MS bundle.
    """
    try:
        import fitz  # PyMuPDF is already a core ExamVoid dependency.
        with fitz.open(str(path)) as doc:
            text = "\n".join((doc[i].get_text("text") or "")
                               for i in range(min(3, len(doc))))
    except Exception:
        return None

    low = text.lower()
    if not any(signal in low for signal in (
        "examiner report", "principal examiner report", "general comments",
        "comments on specific questions", "assessment at a glance",
    )):
        return None

    known_codes = set()
    try:
        from core.config_loader import KNOWN_CODE_MAP
        known_codes.update(str(k) for k in KNOWN_CODE_MAP)
    except Exception:
        pass
    codes = re.findall(r"(?<!\d)(\d{4})(?!\d)", low)
    code = next((c for c in codes if not known_codes or c in known_codes), None)
    if code is None:
        return None

    year_match = re.search(r"(?<!\d)(20\d{2})(?!\d)", low)
    if not year_match:
        return None
    year_full = year_match.group(1)
    year_short = year_full[-2:]

    if re.search(r"\b(?:may|june|summer)\b", low):
        season = "s"
    elif re.search(r"\b(?:october|november|winter)\b", low):
        season = "w"
    elif re.search(r"\b(?:february|march|spring)\b", low):
        season = "m"
    elif re.search(r"\bspecimen\b", low):
        season = "sp"
    else:
        return None

    # A report can be a session-wide compilation. Only use a component when
    # the first-page heading gives a clear paper/component marker.
    component = ""
    component_match = re.search(r"\b(?:paper|component)\s*([1-9]\d?)\b", low)
    if component_match:
        component = component_match.group(1)

    level = _fallback_level(code)
    subject = FALLBACK_SUBJECTS.get(code, "")
    try:
        from core.config_loader import KNOWN_CODE_MAP
        subject = str(KNOWN_CODE_MAP.get(code, subject) or subject)
    except Exception:
        pass
    return Document(
        path=str(path), kind="er", code=code, season=season,
        year_short=year_short, year=year_full, variant=component,
        level=level, subject=subject, paper_format="ER",
        size_bytes=path.stat().st_size if path.exists() else 0,
        parse_method="content-fallback",
    )


def scan(roots: list[Path], content_fallback: bool = True) -> ScanResult:
    result = ScanResult(roots=[str(r) for r in roots])
    for path in _walk_pdfs(roots):
        result.pdfs_scanned += 1
        try:
            info = _parse_identity(path)
        except Exception as exc:
            info = None
            print(f"[warning] parser error for {path.name}: {exc}")

        doc = _document_from_info(path, info) if info is not None else None
        if doc is None and content_fallback:
            doc = _content_er_identity(path)
        if doc is None:
            result.unparseable.append(str(path))
            continue

        result.documents.append(doc)
        if doc.kind == "qp":
            result.identified_qp += 1
        elif doc.kind == "ms":
            result.identified_ms += 1
        elif doc.kind == "er":
            result.identified_er += 1
        else:
            result.identified_other += 1

    # QP/MS pass. Keep MS-only and QP-only bundles visible; they are useful
    # missing-ER diagnostics even when the paper pair itself is incomplete.
    for doc in result.documents:
        if doc.kind not in {"qp", "ms"}:
            continue
        key = f"{doc.code}_{doc.season}{doc.year_short}_{doc.variant}"
        bundle = result.bundles.get(key)
        if bundle is None:
            bundle = Bundle(
                code=doc.code, season=doc.season, year_short=doc.year_short,
                year=doc.year, variant=doc.variant, level=doc.level,
                subject=doc.subject, paper_format=doc.paper_format,
            )
            result.bundles[key] = bundle
        if not bundle.level:
            bundle.level = doc.level
        if not bundle.subject:
            bundle.subject = doc.subject
        if not bundle.paper_format:
            bundle.paper_format = doc.paper_format
        getattr(bundle, doc.kind).append(doc)

    # ER pass. A variantless session ER applies to every component; a
    # component ER applies by first paper digit, matching batch_manifest.py.
    ers = [d for d in result.documents if d.kind == "er"]
    for er in ers:
        matched = []
        for bundle in result.bundles.values():
            if er.code != bundle.code or er.season != bundle.season \
                    or er.year_short != bundle.year_short:
                continue
            if not er.variant or str(er.variant)[:1] == str(bundle.variant)[:1]:
                matched.append(bundle)
        if matched:
            for bundle in matched:
                bundle.er.append(er)
        else:
            result.orphan_ers.append(er)

    return result


# ---------------------------------------------------------------------------
# Report rendering
# ---------------------------------------------------------------------------


def _display_doc_paths(docs: list[Document]) -> str:
    return " | ".join(d.path for d in docs)


def _expected_names(bundle: Bundle) -> list[str]:
    base = f"{bundle.code}_{bundle.season}{bundle.year_short}_er"
    names = [f"{base}.pdf"]
    if bundle.variant:
        names.append(f"{base}_{bundle.variant}.pdf")
    return names


def _bundle_row(bundle: Bundle) -> dict:
    return {
        "status": bundle.status,
        "code": bundle.code,
        "season": bundle.season,
        "session_label": bundle.session_label,
        "year": bundle.year,
        "year_short": bundle.year_short,
        "variant": bundle.variant,
        "level": bundle.level,
        "subject": bundle.subject,
        "paper_format": bundle.paper_format,
        "qp_count": len(bundle.qp),
        "ms_count": len(bundle.ms),
        "er_count": len(bundle.er),
        "expected_er_names": " | ".join(_expected_names(bundle)),
        "qp_paths": _display_doc_paths(bundle.qp),
        "ms_paths": _display_doc_paths(bundle.ms),
        "er_paths": _display_doc_paths(bundle.er),
        "notes": "; ".join(bundle.notes),
    }


def write_txt(result: ScanResult, path: Path) -> None:
    bundles = sorted(result.bundles.values(), key=lambda b: b.key)
    missing = [b for b in bundles if not b.er]
    found = [b for b in bundles if b.er]
    lines = [
        "ExamVoid — Examiner Report Inventory",
        "====================================",
        f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "Mode: offline recursive scan; no network access used",
        "",
        "SCAN SUMMARY",
        "------------",
        f"Roots scanned       : {len(result.roots)}",
        *[f"  - {root}" for root in result.roots],
        f"PDFs scanned        : {result.pdfs_scanned}",
        f"QP files identified : {result.identified_qp}",
        f"MS files identified : {result.identified_ms}",
        f"ER files identified : {result.identified_er}",
        f"Other PDFs parsed  : {result.identified_other}",
        f"Unparseable PDFs   : {len(result.unparseable)}",
        f"QP/MS bundles      : {len(bundles)}",
        f"Bundles with ER    : {len(found)}",
        f"Bundles missing ER : {len(missing)}",
        f"Unpaired ER files  : {len(result.orphan_ers)}",
        "",
    ]

    if missing:
        lines += [
            "MISSING EXAMINER REPORTS",
            "------------------------",
            "These QP/MS bundles had no matching ER PDF in the scanned folders.",
            "",
        ]
        for i, bundle in enumerate(missing, 1):
            lines += [
                f"{i}. {bundle.key} — {bundle.subject or '(subject unknown)'} ({bundle.level or 'level unknown'})",
                f"   session : {bundle.session_label} {bundle.year}",
                f"   expected: {' OR '.join(_expected_names(bundle))}",
                f"   QP      : {_display_doc_paths(bundle.qp) or '(missing)'}",
                f"   MS      : {_display_doc_paths(bundle.ms) or '(missing)'}",
                f"   notes   : {'; '.join(bundle.notes) or 'none'}",
                "",
            ]
    else:
        lines += ["SUCCESS: Every identified QP/MS bundle has a matching ER.", ""]

    if found:
        lines += [
            "ER-COVERED BUNDLES",
            "------------------",
        ]
        for bundle in found:
            lines += [
                f"{bundle.key} — {bundle.session_label} {bundle.year} — "
                f"{len(bundle.er)} ER file(s)",
                f"   ER: {_display_doc_paths(bundle.er)}",
            ]
        lines.append("")

    if result.orphan_ers:
        lines += [
            "UNPAIRED ER FILES",
            "-----------------",
            "These ER PDFs were found, but no matching QP/MS bundle was scanned.",
        ]
        for doc in sorted(result.orphan_ers, key=lambda d: d.identity):
            lines.append(f"{doc.identity} — {doc.path}")
        lines.append("")

    if result.unparseable:
        lines += [
            "UNPARSEABLE PDF FILES",
            "---------------------",
            "These files were not confidently identified from filename/content:",
        ]
        lines.extend(f"- {p}" for p in result.unparseable)
        lines.append("")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_csv(result: ScanResult, path: Path) -> None:
    fields = [
        "status", "code", "season", "session_label", "year", "year_short",
        "variant", "level", "subject", "paper_format", "qp_count", "ms_count",
        "er_count", "expected_er_names", "qp_paths", "ms_paths", "er_paths",
        "notes",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for bundle in sorted(result.bundles.values(), key=lambda b: b.key):
            writer.writerow(_bundle_row(bundle))


def write_json(result: ScanResult, path: Path) -> None:
    bundles = [_bundle_row(b) for b in sorted(result.bundles.values(), key=lambda b: b.key)]
    payload = {
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "mode": "offline_recursive_scan",
        "roots": result.roots,
        "summary": {
            "pdfs_scanned": result.pdfs_scanned,
            "identified_qp": result.identified_qp,
            "identified_ms": result.identified_ms,
            "identified_er": result.identified_er,
            "identified_other": result.identified_other,
            "unparseable": len(result.unparseable),
            "bundles": len(bundles),
            "bundles_with_er": sum(1 for row in bundles if row["status"] == "FOUND"),
            "bundles_missing_er": sum(1 for row in bundles if row["status"] == "MISSING_ER"),
            "orphan_ers": len(result.orphan_ers),
        },
        "bundles": bundles,
        "orphan_ers": [asdict(d) for d in sorted(result.orphan_ers, key=lambda d: d.identity)],
        "unparseable": result.unparseable,
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--root", "-r", action="append", default=None,
        help="Folder or PDF to scan recursively; repeat for separate QP/MS and ER folders (default: current folder).",
    )
    parser.add_argument(
        "--out-dir", "-o", default=".",
        help="Folder for the TXT/CSV/JSON reports (default: current folder).",
    )
    parser.add_argument(
        "--no-content-fallback", action="store_true",
        help="Only use filenames; do not inspect the first pages of unparseable PDFs for ER identity.",
    )
    parser.add_argument(
        "--fail-if-missing", action="store_true",
        help="Return exit code 1 when one or more QP/MS bundles have no ER.",
    )
    args = parser.parse_args(argv)

    raw_roots = args.root if args.root else ["."]
    roots = _canonical_roots(raw_roots)
    if not roots:
        print("ERROR: no valid scan roots were supplied.", file=sys.stderr)
        return 2

    if _PARSER_IMPORT_ERROR is not None:
        print("[info] Full ExamVoid parser unavailable; using standalone filename "
              f"parser ({_PARSER_IMPORT_ERROR}). This is sufficient for normal QP/MS/ER names.")

    result = scan(roots, content_fallback=not args.no_content_fallback)
    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    txt_path = out_dir / "missing_examiner_reports.txt"
    csv_path = out_dir / "examiner_report_inventory.csv"
    json_path = out_dir / "examiner_report_inventory.json"
    write_txt(result, txt_path)
    write_csv(result, csv_path)
    write_json(result, json_path)

    missing = sum(1 for b in result.bundles.values() if not b.er)
    print(f"Scanned {result.pdfs_scanned} PDF(s) across {len(roots)} root(s).")
    print(f"Identified QP={result.identified_qp}, MS={result.identified_ms}, ER={result.identified_er}.")
    print(f"QP/MS bundles: {len(result.bundles)}; ER found: {len(result.bundles) - missing}; missing ER: {missing}.")
    print(f"Unpaired ERs: {len(result.orphan_ers)}; unparseable PDFs: {len(result.unparseable)}.")
    print(f"Created: {txt_path}")
    print(f"Created: {csv_path}")
    print(f"Created: {json_path}")
    return 1 if args.fail_if_missing and missing else 0


if __name__ == "__main__":
    raise SystemExit(main())
