#!/usr/bin/env python3
"""CLI entry point for the batch runner (Overseer batch-infrastructure spec,
Phase 6 — honest port; imports the real core.batch_runner)."""

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))



def _configure_console_output():
    """Do not let cp1252 Windows consoles crash on status glyphs.

    Logs remain UTF-8; a console that cannot display a glyph gets a replacement
    character instead of terminating the parent after a worker failure.
    """
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(errors="replace")
        except Exception:
            pass


_configure_console_output()

from core.batch_runner import run_pipeline


def apply_resource_profile(args):
    """Optional higher-resource preset.

    Honest limit: software cannot allocate physical RAM. This profile only
    tells the pipeline to use the fuller crop path and, unless the user has
    already chosen a worker count, nudges concurrency slightly upward.
    """
    if getattr(args, "performance", False):
        args.low_ram = False
        if args.workers is None:
            args.workers = 6  # user-requested default (2026-08-14)
    return args


def main():
    parser = argparse.ArgumentParser(
        description="ExamVoid Topical Generator — batch mode"
    )
    parser.add_argument(
        "--input", required=True,
        help="Input directory containing PDF files"
    )
    parser.add_argument(
        "--output", required=True,
        help="Output directory for question bank"
    )
    parser.add_argument(
        "--topics", default="topics",
        help="(compat) Path to taxonomy JSON files"
    )
    parser.add_argument(
        "--workers", type=int, default=None,
        help="Number of parallel workers (default: cpu//2, RAM-guard clamped)"
    )
    parser.add_argument(
        "--resume", action="store_true", default=True,
        help="Skip already-complete bundles (default: on)"
    )
    parser.add_argument(
        "--retry-failed", action="store_true",
        help="Retry previously failed bundles"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Run preflight only, no processing"
    )
    parser.add_argument(
        "--fetch-missing-ms",
        action="store_true",
        default=False,
        help=(
            "Attempt to fetch missing mark schemes "
            "from pastpapers.co before processing. "
            "Opt-in only. All downloads are verified."
        )
    )
    parser.add_argument(
        "--fetch-missing-qp",
        action="store_true",
        default=False,
        help=(
            "Attempt to fetch missing question papers from the allowed "
            "sources (official Cambridge -> pastpapers.co) before "
            "processing. Opt-in only. All downloads are verified and "
            "registered into the bundle database."
        )
    )
    parser.add_argument(
        "--ms-cache-dir",
        default="ms_cache",
        help=(
            "Directory for cached downloaded MS PDFs. "
            "Default: ms_cache/"
        )
    )
    parser.add_argument(
        "--full-auto",
        action="store_true",
        default=True,
        help="DEFAULT ON (2026-08-14, user requirement): never route a usable "
             "QP crop to review_required — every question is cropped, "
             "categorized and sorted into a topical folder; deterministic "
             "fallback decisions stay in logs/sidecars. Pass --no-full-auto to "
             "restore fail-closed review routing."
    )
    parser.add_argument(
        "--no-full-auto",
        action="store_true",
        default=False,
        help="Restore fail-closed behavior: ambiguous/no-evidence questions "
             "go to review_required instead of being auto-sorted."
    )
    parser.add_argument(
        "--trust-self",
        action="store_true",
        default=False,
        help="Explicit alias for the default full-auto policy: categorize every "
             "usable QP crop, including QP-only and low-confidence questions."
    )
    parser.add_argument(
        "--fetch-missing-er",
        action="store_true",
        default=False,
        help=(
            "Attempt to fetch missing examiner reports (official -> "
            "pastpapers.co -> papacambridge -> xtrapapers -> papersdaddy; "
            "Scribd reported as manual links). Opt-in, verified only."
        )
    )
    parser.add_argument(
        "--qp-cache-dir",
        default="qp_cache",
        help=(
            "Directory for cached downloaded QP PDFs. "
            "Default: qp_cache/"
        )
    )
    parser.add_argument(
        "--fetch-dry-run",
        action="store_true",
        default=False,
        help=(
            "Show which MS files would be fetched "
            "without actually downloading anything."
        )
    )
    parser.add_argument(
        "--session", default=None,
        help="Process only one session, e.g. s26, summer, m26, winter, or specimen."
    )
    parser.add_argument(
        "--year", dest="year_filter", default=None,
        help="Process only one exam year, e.g. 2026 or 26."
    )
    parser.add_argument(
        "--subject", dest="subject_filter", default=None,
        help="Process only subjects whose name contains this text."
    )
    parser.add_argument(
        "--syllabus-code", dest="syllabus_code_filter", default=None,
        help="Process only one exact syllabus code, e.g. 9701."
    )
    parser.add_argument(
        "--level", dest="level_filter", default=None, choices=("IGCSE", "A-Level"),
        help="Process only IGCSE or A-Level bundles."
    )
    parser.add_argument(
        "--full-ram", dest="low_ram", action="store_false", default=True,
        help="Use the full production CroppingEngine path (needs a big machine)"
    )
    parser.add_argument(
        "--performance", action="store_true",
        help=(
            "Higher-resource preset: disables low-RAM mode and, if --workers "
            "was not supplied, nudges worker count slightly upward. Best used "
            "on a machine with about 4GB RAM or more."
        )
    )

    args = parser.parse_args()
    args = apply_resource_profile(args)
    # One policy value is passed through every preflight and worker path.  The
    # previous CLI accidentally passed raw `args.full_auto` in some branches,
    # so `--no-full-auto` could be ignored after a fetch preflight.
    auto_mode = bool(getattr(args, "full_auto", True) or getattr(args, "trust_self", False)) \
        and not bool(getattr(args, "no_full_auto", False))

    # MS-fetcher spec (opt-in only, RULE 1: never the default). Runs BEFORE
    # processing so fetched+verified MS files are picked up by this run's
    # get_pending_bundles() files-JOIN. Real module home: core/ms_fetcher.py
    # (the spec's cambridge_qb package does not exist).
    if args.fetch_missing_ms or args.fetch_dry_run:
        from core.ms_fetcher import MissingMSResolver

        db_path = Path(args.output) / "pipeline.sqlite"
        cache_dir = Path(args.ms_cache_dir)

        # Explicit MS retrieval is allowed to bootstrap and refresh its own
        # preflight.  This registers newly supplied QP-only bundles before the
        # resolver queries SQLite, while still doing zero processing.
        print("Refreshing the preflight manifest before resolving missing "
              "mark schemes.")
        run_pipeline(
            pdf_dir=args.input,
            output_dir=args.output,
            topics_dir=args.topics,
            workers=args.workers,
            resume=args.resume,
            retry_failed=args.retry_failed,
            dry_run=True,
            low_ram=args.low_ram,
            full_auto=auto_mode,
        )
        if not db_path.exists():
            print("Preflight did not create pipeline.sqlite; mark-scheme "
                  "retrieval is REVIEW_REQUIRED and processing is stopped.")
            return 1

        resolver = MissingMSResolver(
            db_path=db_path,
            cache_dir=cache_dir,
            dry_run=args.fetch_dry_run,
        )
        resolver.resolve_all()

        if args.fetch_dry_run:
            print("Dry run complete. No files downloaded.")
            return

    # QP-fetcher (2026-08-13, opt-in only, mirror of the MS block above).
    # Resolves bundles whose qp_file_id IS NULL, verifies the download, and
    # points the bundle at it; the next get_pending_bundles() files-JOIN then
    # consumes the fetched QP in this same run.
    if args.fetch_missing_qp:
        from core.qp_fetcher import MissingQPResolver

        db_path = Path(args.output) / "pipeline.sqlite"
        cache_dir = Path(args.qp_cache_dir)

        print("Refreshing the preflight manifest before resolving missing "
              "question papers.")
        run_pipeline(
            pdf_dir=args.input,
            output_dir=args.output,
            topics_dir=args.topics,
            workers=args.workers,
            resume=args.resume,
            retry_failed=args.retry_failed,
            dry_run=True,
            low_ram=args.low_ram,
            full_auto=auto_mode,
        )
        if not db_path.exists():
            print("Preflight did not create pipeline.sqlite; question-paper "
                  "retrieval is REVIEW_REQUIRED and processing is stopped.")
            return 1

        resolver = MissingQPResolver(
            db_path=db_path,
            cache_dir=cache_dir,
            dry_run=args.fetch_dry_run,
        )
        resolver.resolve_all()

        if args.fetch_dry_run:
            print("Dry run complete. No files downloaded.")
            return

    if args.fetch_missing_er:
        from core.er_fetcher import fetch_missing_ers_in_dir
        print("Refreshing preflight before ER fetch...")
        run_pipeline(
            pdf_dir=args.input,
            output_dir=args.output,
            topics_dir=args.topics,
            workers=args.workers,
            resume=args.resume,
            retry_failed=args.retry_failed,
            dry_run=True,
            low_ram=args.low_ram,
            full_auto=auto_mode,
        )
        fetch_missing_ers_in_dir(args.input, output_root=args.output,
                                 dry_run=args.fetch_dry_run)

    result = run_pipeline(
        pdf_dir=args.input,
        output_dir=args.output,
        topics_dir=args.topics,
        workers=args.workers,
        resume=args.resume,
        retry_failed=args.retry_failed,
        dry_run=args.dry_run,
        low_ram=args.low_ram,
        full_auto=auto_mode,
        session=args.session,
        year_filter=args.year_filter,
        subject_filter=args.subject_filter,
        syllabus_code_filter=args.syllabus_code_filter,
        level_filter=args.level_filter,
    )
    if result.get("failed", 0):
        return 1
    if result.get("review_required", 0):
        return 2
    if result.get("audit_passed") is False:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
