#!/usr/bin/env python3
"""
pipeline.py - Parallel batch orchestrator (Overseer Efficiency Upgrades U1+U5,
ported onto the real system).

The Overseer's spec targeted a nonexistent cambridge_qb.pipeline module calling
hallucinated APIs (markscheme.parse_markscheme, topics_enhanced.classify,
organize.route_question, output_validator.validate_output, webp_utils.save_question_crop).
This is the honest port onto what ACTUALLY exists and is locked:

  - one paper = one isolated `run_guarded.py --_worker <base_key>` subprocess
    (RS-2 memory-isolation architecture; worker heap dies with the process)
  - UP TO N workers alive at once (N = --workers, default max(1, cpu_count()//2)),
    clamped by a RAM guard calibrated from measured worker peaks (933-960MB RSS,
    see .pipeline evidence) so a batch can never OOM itself silently
  - the PARENT owns .pipeline_state.json (U1): register/skip/complete/fail here;
    children run with GUARDED_CHILD_NO_STATE=1 (no concurrent state-file writers)
  - tqdm progress with graceful ImportError fallback (U5)
  - examiner-report attach + final audit run once, after all workers (real
    equivalents of the spec's validate_output: core.validation.FinalValidator)

q: why no shared taxonomy objects across workers (spec U4 claim about fork)?
a: these are fresh subprocesses on purpose (memory safety); the per-worker cost
   is one config-tree parse, now session-cached per process (U4, config_loader).

Spec's dead branches (route_to_uncategorized on empty classify / missing MS)
are intentionally NOT ported: the locked classifier fallback chain never returns
empty, and the locked MISSING_MS policy skips the paper upfront. The separate
Uncategorized directive remains pending user decisions.
"""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from run_guarded import WORKER_OK, load_inputs  # noqa: E402

# RAM guard calibration (measured: run_guarded worker [mem] lines, RS-2 evidence runs)
PER_WORKER_PEAK_MB = 1100   # worker peak 933-960MB + headroom
PARENT_RESERVE_MB = 400     # parent + OS + filesystem cache floor


def available_mem_mb():
    """/proc first (zero-dep); psutil as optional fallback (spec U6 listing)."""
    try:
        with open("/proc/meminfo", encoding="ascii", errors="ignore") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except OSError:
        pass
    try:
        import psutil
        return int(psutil.virtual_memory().available // (1024 * 1024))
    except Exception:
        return None


def guard_decision(requested_workers, avail_mb):
    """Pure function: how many workers may run concurrently, and why (loud).

    Returns (concurrency, reasons). Never returns < 1 - a single isolated
    worker is always allowed (the sequential RS-2 path works on this box).
    """
    want = requested_workers if requested_workers is not None else 6  # user-requested default (2026-08-14)
    reasons = [f"requested/auto workers = {want}"]
    if avail_mb is None:
        reasons.append("MemAvailable unknown (no /proc/meminfo, no psutil) - trusting requested value")
        return max(1, want), reasons
    raw = (avail_mb - PARENT_RESERVE_MB) // PER_WORKER_PEAK_MB
    fit = max(1, raw)
    conc = min(want, fit)
    if raw < 1:
        cl = f"clamping {want} -> 1; " if want > 1 else ""
        reasons.append(
            f"RAM-GUARD: {avail_mb}MB available is below one-worker budget "
            f"({PER_WORKER_PEAK_MB}+{PARENT_RESERVE_MB}MB); {cl}floor of 1 applied "
            f"(sequential RS-2 path proven at this pressure; worker heap dies with its process)")
    elif conc < want:
        reasons.append(
            f"RAM-GUARD: {avail_mb}MB available, need ~{PER_WORKER_PEAK_MB}MB/worker "
            f"+ {PARENT_RESERVE_MB}MB reserve -> {fit} worker(s) fit; clamping {want} -> {conc}"
        )
    else:
        reasons.append(f"RAM-GUARD OK: {avail_mb}MB available, {conc} x ~{PER_WORKER_PEAK_MB}MB fits")
    return conc, reasons


def _spawn(base_key, args_ns, log_path):
    cmd = [sys.executable, "-u", str(Path(__file__).resolve().parent / "run_guarded.py"),
           "--input", str(args_ns.input), "--output", str(args_ns.output),
           "--_worker", base_key]
    if getattr(args_ns, "low_ram", False):
        cmd.append("--low-ram")
    env = dict(os.environ)
    env["GUARDED_CHILD_NO_STATE"] = "1"   # child must not touch .pipeline_state.json
    fh = open(log_path, "w", encoding="utf-8", errors="replace")
    proc = subprocess.Popen(cmd, stdout=fh, stderr=subprocess.STDOUT, env=env)
    return proc, fh


def _collect_bundles(sep, subject=None, level=None, syllabus_code=None):
    """(level, subject, base_key) for every group that has QP+MS, honoring filters."""
    from core.qp_ms_matcher import QPMSMatcher
    bundles, filtered = [], 0
    for lvl in ["IGCSE", "A-Level"]:
        if level and lvl != level:
            continue
        for subject_name, paper_list in sep["by_level_subject"].get(lvl, {}).items():
            if subject and subject.lower() not in subject_name.lower():
                continue
            from collections import defaultdict
            by_year = defaultdict(list)
            for p in paper_list:
                by_year[p.year].append(p)
            for year, year_papers in sorted(by_year.items()):
                groups = QPMSMatcher().group_papers(year_papers)
                for base_key, td in sorted(groups.items()):
                    if "qp" not in td:
                        continue  # QP-less groups never produce output (Overseer RULE 2: qp-only bundles DO flow)
                    if syllabus_code and not base_key.startswith(f"{syllabus_code}_"):
                        filtered += 1
                        continue
                    bundles.append((lvl, subject_name, base_key))
    return bundles, filtered


def _post_stages(gate, papers, output_root, total_saved):
    """ER text + ER crops + final audit (real equivalents of spec validate_output)."""
    from core.examiner_report import attach_examiner_reports_to_output
    from core.er_question_crops import attach_question_er_crops
    from core.output_manager import OutputManager
    from core.validation import FinalValidator

    er_papers = [p for p in papers if p.paper_type == "er"]

    def s6(check):
        if not er_papers:
            check("no ER papers supplied - stage skipped by design", True, "")
            return None
        stats = attach_examiner_reports_to_output(er_papers, output_root)
        check("ER: no processing errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        check("ER: commentary attached to questions", stats["questions_attached"] > 0,
              f"{stats['questions_attached']} attached")
        return stats

    def s7(check):
        if not er_papers:
            check("no ER papers supplied - stage skipped by design", True, "")
            return None
        stats = attach_question_er_crops(er_papers, output_root)
        check("ER crops: no errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        check("ER crops: all written crops text-verified",
              stats["crops_written"] == stats["verified"],
              f"{stats['crops_written']}/{stats['verified']}")
        return stats

    def s8(check):
        removed = OutputManager(output_root=output_root, target_width=2280, quality=95)\
            .cleanup_empty_and_invalid_folders()
        check("cleanup ran", True, f"removed {len(removed)} invalid folders" if removed else "nothing invalid")
        result = FinalValidator(output_root=output_root).validate_all()
        check("final audit passes", result["passed"], f"errors={result.get('total_errors', 0)}")
        folders = [p for p in output_root.rglob("*_Q*")
                   if p.is_dir() and re.search(r"_Q\d+$", p.name)]
        check("question folders on disk == saved this run", len(folders) == total_saved,
              f"{len(folders)} folders vs {total_saved} saved")
        return result

    gate.run_stage("S6", "ER text attach", s6)
    gate.run_stage("S7", "ER question crops", s7)
    gate.run_stage("S8", "final validation", s8)


def run_pipeline(pdf_dir, output_dir, subject=None, level=None, syllabus_code=None,
                 topics_dir="topics", workers=None, low_ram=False, plan_only=False):
    """Overseer run_pipeline() ported to the real locked components.

    topics_dir is accepted for spec-signature compatibility; the real system
    resolves subject configs from subjects/<Level>/<Subject>/config.json
    (never modified) - no topics/ shadow taxonomies are consulted here.
    Returns a list of per-paper result dicts.
    """
    t0 = time.time()
    output_dir = Path(output_dir)
    args_ns = argparse.Namespace(input=str(pdf_dir), output=str(output_dir),
                                 low_ram=low_ram, clean=False)
    gate, configs, papers, sep = load_inputs(args_ns)

    bundles, filtered = _collect_bundles(sep, subject=subject, level=level,
                                         syllabus_code=syllabus_code)
    if subject or level or syllabus_code:
        print(f"[pipeline] filter subject={subject} level={level} code={syllabus_code}: "
              f"{len(bundles)} bundles kept, {filtered} filtered out")

    from core.pipeline_state import PipelineState
    state = PipelineState.load_or_create(
        output_dir,
        subject=subject or (bundles[0][1] if bundles else "mixed"),
        syllabus_code=syllabus_code or (bundles[0][2].split("_")[0] if bundles else "0000"),
        level=level or (bundles[0][0] if bundles else "A-Level"),
    )

    todo, skipped = [], 0
    for lvl, subject_name, base_key in bundles:
        state.register_paper(base_key, qp_path="", ms_path="", er_path=None)
        if state.should_skip(base_key):
            skipped += 1
            print(f"[pipeline] RESUME-SKIP {base_key}: already complete in a previous run")
        else:
            todo.append((lvl, subject_name, base_key))
    if skipped:
        print(f"Skipped {skipped} already-completed papers")   # spec line, kept verbatim
    if not todo:
        print("No new papers to process")
        state.print_summary()
        return []

    avail = available_mem_mb()
    conc, reasons = guard_decision(workers, avail)
    for r in reasons:
        print(f"[pipeline] {r}")
    print(f"Processing {len(todo)} papers using {conc} parallel workers")  # spec line, adapted
    print(f"[pipeline] QP path: {'RAM-SAFE streaming (--low-ram)' if low_ram else 'production CroppingEngine'}")
    print(f"[pipeline] per-paper isolation: subprocess (RS-2); parent owns pipeline state")
    if plan_only:
        print("[pipeline] --plan-only: nothing spawned")
        return [{"paper_code": bk, "status": "planned"} for _, _, bk in todo]

    # Styled tqdm with a plain-text fallback when the dependency or terminal
    # color support is unavailable.
    try:
        from tqdm import tqdm as _tqdm
        from core.progress_ui import PlainProgress, format_postfix, make_progress
        bar, _bar_colors = make_progress(_tqdm, len(todo), "ExamVoid")
    except ImportError:
        print("[pipeline] tqdm not installed - plain progress lines "
              "(pip install tqdm to enable the styled bar)")
        from core.progress_ui import PlainProgress, format_postfix
        bar, _bar_colors = PlainProgress(len(todo), "ExamVoid"), False

    logs_dir = output_dir / ".worker_logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    env_note_printed = False
    running = {}      # base_key -> (proc, fh, log_path, t_start)
    pending = list(todo)
    results = []

    def finish_one(base_key, proc, fh, log_path, t_start):
        rc = proc.wait()
        fh.close()
        out = Path(log_path).read_text(encoding="utf-8", errors="replace")
        m = WORKER_OK.search(out)
        saved = int(m.group(1)) if m else -1
        if rc == 0 and saved >= 0:
            state.mark_complete(base_key, saved, saved)
            results.append({"paper_code": base_key, "status": "complete", "questions": saved})
        else:
            err = f"worker rc={rc} saved={saved} (log: {log_path})"
            state.mark_failed(base_key, err)
            results.append({"paper_code": base_key, "status": "failed", "error": err})
        bar.update(1)
        bar.set_postfix_str(format_postfix(
            sum(r.get("status") == "complete" for r in results),
            sum(r.get("status") == "failed" for r in results),
            sum(r.get("status") == "review_required" for r in results),
            f"{base_key} rc={rc} saved={saved} {time.time()-t_start:.0f}s",
            enabled=_bar_colors,
        ))

    with bar:
        while pending or running:
            while pending and len(running) < conc:
                lvl, subject_name, base_key = pending.pop(0)
                state.mark_processing(base_key)
                log_path = logs_dir / f"{base_key}.log"
                print(f"\n[pipeline] spawn worker: {base_key} -> log {log_path.name}")
                proc, fh = _spawn(base_key, args_ns, log_path)
                running[base_key] = (proc, fh, log_path, time.time())
            done = [bk for bk, (p, *_rest) in running.items() if p.poll() is not None]
            for bk in done:
                finish_one(bk, *running.pop(bk))
            if running and not done:
                time.sleep(0.5)

    state.save(output_dir)

    # ---- post stages: ER attach + final audit (once, parent-side) ----
    _post_stages(gate, papers, output_dir, sum(r.get("questions", 0) for r in results))

    n_ok = sum(1 for r in results if r["status"] == "complete")
    elapsed = time.time() - t0
    print(f"\n[pipeline] done: {n_ok}/{len(results)} papers complete, "
          f"{sum(r.get('questions', 0) for r in results)} questions, "
          f"{elapsed:.1f}s wall, workers={conc}")
    state.print_summary()
    return results


def main():
    ap = argparse.ArgumentParser(description="Parallel paper pipeline (RS-2 isolated workers)")
    ap.add_argument("--input", "-i", default="input")
    ap.add_argument("--output", "-o", default="output")
    ap.add_argument("--subject", default=None)
    ap.add_argument("--level", default=None)
    ap.add_argument("--syllabus-code", default=None)
    ap.add_argument("--workers", type=int, default=None,
                    help="default max(1, cpu_count()//2); RAM-guarded against measured 1100MB/worker")
    ap.add_argument("--low-ram", action="store_true")
    ap.add_argument("--plan-only", action="store_true", help="scan, group, guard plan; spawn nothing")
    args = ap.parse_args()
    results = run_pipeline(args.input, args.output, subject=args.subject, level=args.level,
                           syllabus_code=args.syllabus_code, workers=args.workers,
                           low_ram=args.low_ram, plan_only=args.plan_only)
    if args.plan_only:
        raise SystemExit(0)
    failed = [r for r in results if r["status"] == "failed"]
    if failed:
        print("XXX PIPELINE RUN FAILED XXX")
        for r in failed:
            print(f"  FAILED {r['paper_code']}: {r.get('error', '?')}")
        raise SystemExit(1)
    print(f"*** ALL GREEN *** pipeline run: {len(results)} papers")
    raise SystemExit(0)


if __name__ == "__main__":
    main()
