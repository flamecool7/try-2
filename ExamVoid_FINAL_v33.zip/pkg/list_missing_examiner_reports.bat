@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo ERROR: Python 3 was not found.
    pause
    exit /b 1
)

if not exist "list_missing_examiner_reports.py" (
    echo ERROR: list_missing_examiner_reports.py was not found in this folder.
    pause
    exit /b 1
)

%PYTHON_CMD% "list_missing_examiner_reports.py" %*
set "RC=%ERRORLEVEL%"
echo.
if exist "missing_examiner_reports.txt" echo Created: missing_examiner_reports.txt
pause
exit /b %RC%
