"""
universal.paths + universal.config — project layout and master configuration.

`PROJECT_ROOT` is discovered from this file's location so the engine works from
any CWD and on any platform. All paths in config.yaml are resolved relative to
the project root.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

PROJECT_ROOT: Path = Path(__file__).resolve().parent.parent

# Directories that must exist for the engine to run. Created lazily by
# `ensure_dirs()`; never created at import time (import must stay side-effect free).
_REQUIRED_DIRS = (
    "papers/raw", "papers/processed", "input",
    "output", "output/Universal_Question_Bank", "output/booklets", "output/reports",
    "logs", "cache", "quarantine", "proof_feedback", ".question_tmp",
    "taxonomies", "config/boards", "corpus", "docs/research",
)


def resolve(rel: str | Path, root: Optional[Path] = None) -> Path:
    """Resolve a possibly-relative path against the project root."""
    p = Path(rel)
    return p if p.is_absolute() else (root or PROJECT_ROOT) / p


def ensure_dirs(root: Optional[Path] = None) -> None:
    root = root or PROJECT_ROOT
    for d in _REQUIRED_DIRS:
        (root / d).mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Master config
# ---------------------------------------------------------------------------
_DEFAULTS: Dict[str, Any] = {
    "project": {"name": "Universal_Exam_Topical_Generator", "generator_version": "0.0.0"},
    "output": {"legacy_bank_root": "output",
               "question_bank": "output/Universal_Question_Bank",
               "booklets": "output/booklets", "reports": "output/reports",
               "image_format": "webp", "image_quality": 95, "jpeg_allowed": False,
               "forbidden_in_question_folder": ["proof.html"]},
    "crop": {"final_width": 2280, "top_white_margin": 20, "bottom_margin_min": 10,
             "side_margin_min": 10, "inter_page_separator": 30, "resampling": "lanczos",
             "engine": "canonical",
             "canonical_entry": "core.cropping_engine.CroppingEngine.process_paper",
             "gold_core": "original_reference/cambridge_qb", "webp_max_dim": 16383},
    "retry": {"max_retries": 4},
    "detection": {"min_confident": 0.75, "review_gap": 0.10,
                  "conflict_policy": "REVIEW_REQUIRED", "weights": {"filename": 10},
                  "year": {"min": 1900, "max": 9999,
                           "historical_coverage_from": 2001,
                           "missing_source_status": "SOURCE_NOT_FOUND"}},
    "ocr": {"enabled": True, "backends": ["tesseract", "rapidocr"],
            "trigger": "no_text_layer", "text_density_threshold": 20,
            "max_side_px": 2400, "downscale_resample": "lanczos", "tile": True,
            "timeout_page_s": 120, "unavailable_status": "OCR_UNAVAILABLE"},
    "validation": {"hard_rejection": True},
    "classification": {"min_confident": 0.70, "high_priority_below": 0.50,
                       "max_topics": 4, "human_corrected_wins": True,
                       "weights": {"lexical": 0.25, "semantic": 0.25, "syllabus": 0.20,
                                   "structural": 0.15, "domain": 0.15}},
    "taxonomy": {"dir": "taxonomies", "registry_file": "taxonomies/registry.json",
                 "corpus_sources": [], "legacy_sources": ["subjects_caie", "topics"],
                 "hierarchy": ["board", "qualification", "syllabus", "syllabus_version",
                               "subject", "topic", "subtopic", "concept"],
                 "never_merge_similar_names": True, "never_rename_historical": True},
    "processing": {"max_workers": "auto", "memory_budget_mb": 0, "incremental": True,
                   "manifest": ".processing_manifest.json",
                   "database": "cache/question_bank.db", "cache_dir": "cache",
                   "error_isolation": "per_document"},
    "corpus": {"dir": "corpus/", "raw_dir": "papers/raw", "processed_dir": "papers/processed",
               "downloader": {"respect_robots": True, "rate_limit_rps": 0.5,
                              "request_delay_s": 2.0, "max_file_size": 50_000_000,
                              "min_pdf_size": 5000, "bypass_controls": False,
                              "document_types": ["qp", "ms", "er", "insert"],
                              "never_fabricate": True}},
    "booklet": {"default_layout": {"size": "A4", "orientation": "portrait"},
                "answers_inline": False,
                "year_selection": ["individual", "all", "range", "custom"],
                "count_is_output_not_criterion": True,
                "naming": {"contiguous_range": "{board}_{subject}_{syllabus}_{topic}_{year_from}-{year_to}",
                           "non_contiguous": "{board}_{subject}_{syllabus}_{topic}_{years_underscored}",
                           "count_in_primary_name": False}},
    "proof": {"dir": "output/reports/proof", "max_samples": 200,
              "prioritize_hard_cases": True, "never_inside_question_folder": True},
    "logging": {"level": "INFO", "jsonl": True, "dir": "logs"},
    "security": {"validate_content_type": True, "zip_safety": True,
                 "network_at_runtime": False},
}


def _deep_merge(base: Dict[str, Any], over: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


@dataclass
class Config:
    """Loaded master config. Dict access + attribute access for the hot paths."""
    data: Dict[str, Any]
    path: Optional[Path] = None
    root: Path = PROJECT_ROOT

    # -- access --------------------------------------------------------------
    def get(self, dotted: str, default: Any = None) -> Any:
        cur: Any = self.data
        for part in dotted.split("."):
            if not isinstance(cur, dict) or part not in cur:
                return default
            cur = cur[part]
        return cur

    def __getitem__(self, k: str) -> Any:
        return self.data[k]

    def path_for(self, dotted: str, default: Optional[str] = None) -> Path:
        return resolve(self.get(dotted, default) or default or ".", self.root)

    # -- versioning (§0.12) --------------------------------------------------
    def config_hash(self) -> str:
        blob = json.dumps(self.data, sort_keys=True, default=str).encode("utf-8")
        return "sha256:" + hashlib.sha256(blob).hexdigest()

    def versions(self) -> Dict[str, str]:
        return {
            "generator_version": self.get("project.generator_version", "0.0.0"),
            "crop_engine_version": "3.2.0",       # CROPPING_LOCK.md lineage
            "metadata_schema_version": "2.0",
            "config_hash": self.config_hash(),
        }


_loaded: Optional[Config] = None


def load_config(path: Optional[str | Path] = None,
                root: Optional[Path] = None,
                reload: bool = False) -> Config:
    """Load config/config.yaml, deep-merged over built-in defaults.

    Built-in defaults exist so the engine still runs if YAML/pyyaml is absent —
    but they mirror the locked crop values exactly, so there is no divergence.
    """
    global _loaded
    if _loaded is not None and not reload and path is None:
        return _loaded
    root = Path(root) if root else PROJECT_ROOT
    cfg_path = Path(path) if path else (root / "config" / "config.yaml")
    data = dict(_DEFAULTS)
    if cfg_path.exists():
        try:
            import yaml  # type: ignore
            loaded_doc = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
            data = _deep_merge(_DEFAULTS, loaded_doc)
        except Exception as exc:  # pragma: no cover - defensive
            raise RuntimeError(f"config.yaml present but unreadable: {exc}") from exc
    cfg = Config(data=data, path=cfg_path if cfg_path.exists() else None, root=root)
    if path is None:
        _loaded = cfg
    return cfg


__all__ = ["PROJECT_ROOT", "resolve", "ensure_dirs", "Config", "load_config"]
