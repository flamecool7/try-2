#!/usr/bin/env python3
"""server.py — the Topical Bank + Booklet Builder's local server (stdlib only).

    python3 server.py [--host 0.0.0.0] [--port 8765] [--data-dir .] [--root DIR]… [--open]

Serves the four-screen app (`static/`) and a small JSON API over the tooling the repository already
has. **No pip installs**: `http.server` + `subprocess` + `json` is the whole dependency set, and every
heavy step (detection, batch, index, booklet) runs in a **child process** — the server itself never
loads PyMuPDF, never renders and never holds a paper in memory.

Contracts (see `design/TOPICAL_BOOKLET_DESIGN.md` §4):

* **A long job never blocks a request.** `POST /api/batch` and `POST /api/booklet` return a job id
  immediately; the client polls `GET /api/jobs/<id>` for `{status, progress, log_tail}`. Progress is
  read from *the job's own output* (the batch's pack tree / the booklet's manifest), never from
  parsing stdout as a contract.
* **Fail-closed.** Unknown endpoint → 404; bad JSON or missing field → 400; a path outside every
  registered root → **403** (no `..`, no absolute paths, no symlink escape); a tool that exits
  non-zero marks its job `failed` with the tail of its log.
* **One batch run, every board.** `POST /api/batch` plans one command per board group in the input
  folder: CAIE goes through `main.py` (the Cambridge pipeline — the universal router refuses those
  papers by design), every other board through `tools/run_universal_batch.py`. A folder holding both
  runs two steps in one job, each on a staged symlink dir, so no router ever sees a board it refuses.
  `full_auto` maps onto `main.py`'s own default (`--no-full-auto` is sent only to turn production
  mode off); `include_sat` / `include_ib` are ON by default and the app passes the direction explicitly (`--no-include-*` when a caller turns one off), so the child can never disagree with the request.
* **`/api/index` understands both output layouts** — the universal `final/<board>/…/PACKS/…` pack tree
  and the CAIE `<Level>/<Subject_code>/paper-N/<Topic>/<Q>/` tree — and emits one row schema for both,
  which is what makes the bank browsable across boards.
* **The launcher's six options live in the app.** Scan (detection), batch, index, booklet and
  "open output folder" (`POST /api/reveal`, registered roots only) are all reachable from the UI; the
  booklet step accepts either an inline request or a `booklet_path` to an existing `booklet.json`,
  which is what `run.bat` option 6 does.
* **`/files/<relpath>` serves only registered roots** — the batch outputs the server has run or seen
  in the index (plus any `--root` given on the command line).
* **`POST /api/index` has no ignored parameters.** `batch_out` is the complete set of sources for
  this build, `reset: true` drops rows that came from any other source (deterministic counts for one
  fixture), and `out` is honoured by writing an identical copy there — the server's own index stays
  the one file the app reads. A parameter that cannot be honoured is an error, never a no-op.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
TOOLS = ROOT / "tools"
#: The script ships an input/ and an output/ folder beside itself, so "scan the input folder, write the
#: crops to the output folder" needs nothing typed in (2026-09-28). Everything that used to require a
#: path uses these two unless a caller names its own.
INPUT_DIR = ROOT / "input"
OUTPUT_DIR = ROOT / "output"

CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".webp": "image/webp", ".pdf": "application/pdf", ".ico": "image/x-icon",
    ".woff2": "font/woff2", ".txt": "text/plain; charset=utf-8",
}
LOG_TAIL_LINES = 40


def _now() -> float:
    return time.time()


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:                                              # noqa: BLE001
        return default


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------------------------------
# jobs
# --------------------------------------------------------------------------------------------------
class Job:
    """One background unit of work: a child process, its log file, and its own progress source."""

    def __init__(self, kind: str, argv: List[str], log_path: Path,
                 progress_fn=None, on_success=None, env: Optional[dict] = None):
        self.id = f"{kind}-{uuid.uuid4().hex[:10]}"
        self.kind = kind
        self.argv = argv
        #: One command, or several run in sequence: a batch over a mixed-board folder is one
        #: command per board group (CAIE -> main.py, every other board -> the universal router).
        self.argvv: List[List[str]] = ([list(a) for a in argv]
                                       if argv and isinstance(argv[0], (list, tuple)) else [list(argv)])
        self.log_path = log_path
        self.progress_fn = progress_fn
        self.on_success = on_success
        self.env = env or {}
        self.status = "queued"                     # queued -> running -> done | failed
        #: the job genuinely waits here until the handler has answered the POST, so "queued" is an
        #: observable state rather than a label the response prints after the work already started
        self._go = threading.Event()
        self.created = _now()
        self.started: Optional[float] = None
        self.finished: Optional[float] = None
        self.returncode: Optional[int] = None
        self.result: Dict[str, Any] = {}
        self.error: str = ""
        self.thread: Optional[threading.Thread] = None

    # -- lifecycle -----------------------------------------------------------------------------
    def start(self) -> None:
        self.thread = threading.Thread(target=self._run, name=f"job-{self.id}", daemon=True)
        self.thread.start()

    def release(self) -> None:
        """Let a queued job run (called by the handler once the 202 has been written)."""
        self._go.set()

    def _run(self) -> None:
        self._go.wait(timeout=30.0)                # a job that is never released still starts
        self.status = "running"
        self.started = _now()
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with self.log_path.open("w", encoding="utf-8", errors="replace") as log:
                env = dict(os.environ)
                env.update(self.env)
                env.setdefault("PYTHONUNBUFFERED", "1")
                for index, argv in enumerate(self.argvv, start=1):
                    if len(self.argvv) > 1:
                        log.write(f"===== step {index}/{len(self.argvv)}: "
                                  f"{' '.join(argv)} =====\n")
                        log.flush()
                    proc = subprocess.Popen(argv, cwd=str(ROOT), stdout=subprocess.PIPE,
                                            stderr=subprocess.STDOUT, text=True, bufsize=1, env=env)
                    for line in proc.stdout or []:
                        log.write(line)
                        log.flush()
                    self.returncode = proc.wait()
                    if self.returncode != 0:
                        break
        except Exception as exc:                                   # noqa: BLE001 - reported, never raised
            self.error = f"{type(exc).__name__}: {exc}"
            self.returncode = -1
        self.finished = _now()
        if self.returncode == 0:
            try:
                if self.on_success is not None:
                    self.result = self.on_success() or {}
                self.status = "done"
            except Exception as exc:                               # noqa: BLE001
                self.error = f"post-processing failed: {type(exc).__name__}: {exc}"
                self.status = "failed"
        else:
            self.status = "failed"
            self.error = self.error or f"exit code {self.returncode}"

    # -- views ---------------------------------------------------------------------------------
    def log_tail(self, lines: int = LOG_TAIL_LINES) -> List[str]:
        try:
            text = self.log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return []
        return text[-lines:]

    def progress(self) -> Dict[str, Any]:
        base = {"phase": self.status}
        if self.progress_fn is not None:
            try:
                base.update(self.progress_fn() or {})
            except Exception:                                      # noqa: BLE001 - progress is best effort
                pass
        return base

    def view(self) -> Dict[str, Any]:
        return {
            "job": self.id, "kind": self.kind, "status": self.status,
            "created": self.created, "started": self.started, "finished": self.finished,
            "seconds": round((self.finished or _now()) - (self.started or self.created), 1),
            "returncode": self.returncode, "error": self.error,
            "progress": self.progress(), "log_tail": self.log_tail(),
            "result": self.result,
        }


class JobRegistry:
    def __init__(self) -> None:
        self._jobs: Dict[str, Job] = {}
        self._lock = threading.Lock()

    def add(self, job: Job) -> Job:
        with self._lock:
            self._jobs[job.id] = job
        job.start()
        return job

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock:
            return self._jobs.get(job_id)

    def all(self) -> List[Job]:
        with self._lock:
            return sorted(self._jobs.values(), key=lambda j: j.created, reverse=True)

    def running(self) -> int:
        return sum(1 for j in self.all() if j.status in ("queued", "running"))


# --------------------------------------------------------------------------------------------------
# server state
# --------------------------------------------------------------------------------------------------
class App:
    """Paths and helpers the handlers share; `roots` is the allow-list for `/files/`."""

    def __init__(self, data_dir: Path, roots: List[Path]):
        self.data_dir = data_dir.resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.jobs = JobRegistry()
        self.index_path = self.data_dir / "topical_index.json"
        self.overrides_path = self.data_dir / "topic_overrides.json"
        self.draft_path = self.data_dir / "draft_booklet.json"
        self.detection_path = self.data_dir / "detected_subjects.json"
        self.watcher: Optional[dict] = None
        self.watch_lock = threading.Lock()
        self._watch_stop = threading.Event()
        #: detection results by folder, keyed on the folder's own fingerprint -- rescanning an
        #: unchanged folder must be instant rather than a fresh 1.1 s subprocess. The fingerprint is
        #: checked on every hit, so this is a cache of *answers*, never of stale ones.
        self.detection_cache: Dict[str, Any] = {}
        self.detection_lock = threading.Lock()
        #: staging dir name -> {staged file name: the user's real path}. Recorded when the file is
        #: staged, because `index_sources.json` needs the *original* path and a staged file may now be
        #: a copy (Windows refuses symlinks) whose `resolve()` points into the scratch folder.
        self.staging_sources: Dict[str, Dict[str, str]] = {}
        self.roots: List[Path] = []
        for root in [data_dir, *roots]:
            self.register_root(root)
        for batch_out in (_read_json(self.index_path, {}) or {}).get("questions", []):
            if batch_out.get("batch_out"):
                self.register_root(Path(batch_out["batch_out"]))
        self.output_default = self.data_dir / "app_output"

    def register_root(self, path: Path) -> None:
        try:
            real = Path(path).resolve()
        except OSError:
            return
        if real not in self.roots:
            self.roots.append(real)

    def start_watch(self, input_dir: Path, output_dir: Path, interval: int) -> None:
        """Watch a folder and batch anything new that lands in it (opt-in, one watcher at a time).

        The fingerprint is (name, size, mtime) per PDF, so a file still being copied is picked up on a
        later pass rather than half-processed. Each detected batch runs as a normal job, which keeps
        progress, logs and re-run in one place.
        """
        self.stop_watch()
        self._watch_stop = threading.Event()
        with self.watch_lock:
            self.watcher = {"watching": True, "input": str(input_dir), "output": str(output_dir),
                            "interval": interval, "runs": [], "started": _now(), "last_pass": None}

        def fingerprint() -> dict:
            out = {}
            for pdf in sorted(input_dir.rglob("*.pdf")) + sorted(input_dir.rglob("*.PDF")):
                try:
                    stat = pdf.stat()
                except OSError:
                    continue
                out[str(pdf)] = (stat.st_size, int(stat.st_mtime))
            return out

        def loop() -> None:
            seen = fingerprint()
            with self.watch_lock:
                if self.watcher is not None:
                    self.watcher["known"] = len(seen)
            while not self._watch_stop.wait(interval):
                current = fingerprint()
                with self.watch_lock:
                    if self.watcher is None:
                        return
                    self.watcher["last_pass"] = _now()
                known = set(self.watcher.get("seen_keys") or ())
                new_files = [path for path, stamp in current.items()
                             if (path, stamp) not in known and (path, stamp[0]) not in seen.items() and path not in {p for p, _ in seen.items()}]
                seen = current
                with self.watch_lock:
                    if self.watcher is not None:
                        self.watcher["seen_keys"] = list({(p, s) for p, s in current.items()})
                if not new_files:
                    continue
                try:
                    job = make_batch_job(self, input_dir, output_dir, "")
                    self.jobs.add(job)
                    job.release()
                    with self.watch_lock:
                        if self.watcher is not None:
                            self.watcher["runs"] = (self.watcher.get("runs") or []) + [
                                {"job": job.id, "at": _now(), "files": [Path(p).name for p in new_files]}]
                except Exception as exc:                            # noqa: BLE001 - a watcher never dies
                    with self.watch_lock:
                        if self.watcher is not None:
                            self.watcher["last_error"] = f"{type(exc).__name__}: {exc}"

        threading.Thread(target=loop, name="watch-folder", daemon=True).start()

    def stop_watch(self) -> None:
        self._watch_stop.set()
        with self.watch_lock:
            if self.watcher is not None:
                self.watcher = {**self.watcher, "watching": False}

    def resolve_file(self, rel: str) -> Optional[Path]:
        """Resolve `/files/<rel>` against the registered roots -- or None when it escapes them all."""
        rel = unquote(rel or "").lstrip("/")
        if not rel or rel.startswith("~") or re.match(r"^[A-Za-z]:", rel):
            return None
        candidate = Path(rel)
        if candidate.is_absolute():
            return None
        for root in self.roots:
            target = (root / candidate)
            try:
                real = target.resolve()
                real.relative_to(root)                              # escape check (also defeats symlinks)
            except (OSError, ValueError):
                continue
            if real.is_file():
                return real
        return None


# --------------------------------------------------------------------------------------------------
# job factories
# --------------------------------------------------------------------------------------------------
def _packs_written(output: Path) -> Dict[str, int]:
    """Questions written so far, in either layout: universal packs and CAIE question folders."""
    packs = len(list(output.glob("final/*/*/*/PACKS/*/Q*/metadata.json")))
    flagged = len(list(output.glob("final/*/*/*/review_required/*/Q*/metadata.json")))
    ms = len([p for p in output.glob("final/*/*/*/MS/*/segments.json")])
    rendered = len(list(output.glob("final/*/*/*/{QP,MS}/*/*.webp"))) if output.exists() else 0
    caie = len(list(output.glob("*/*/paper-*/*/*/metadata.json"))) if output.exists() else 0
    caie_crops = len(list(output.glob("*/*/paper-*/*/*/*.webp"))) if output.exists() else 0
    return {"packs": packs + caie, "flagged_packs": flagged, "mark_schemes": ms,
            "crops": rendered + caie_crops, "caie_packs": caie}


#: The Cambridge pipeline's entry point. CAIE papers are the one board the universal router
#: refuses by design, so they are driven through this instead -- same binary the CLI quickstart uses.
MAIN = ROOT / "main.py"


def _documents_by_board(app: App, input_dir: Path) -> Dict[str, List[Path]]:
    """board name (as the detector reports it) -> the PDFs of that board, from one detection pass."""
    payload = run_detector(app, input_dir)
    groups: Dict[str, List[Path]] = {}
    for board_group in payload.get("boards", []):
        board = str(board_group.get("board") or "").strip()
        for subject in board_group.get("subjects", []):
            for doc in subject.get("documents", []):
                groups.setdefault(board, []).append(Path(str(doc["path"])))
    return groups


#: Set the first time a platform refuses to create a symlink, so the reason is explained once per
#: process rather than once per file.
_SYMLINK_REFUSED = False


def _stage_file(src: Path, target: Path) -> str:
    """Put `src` into the staging folder as `target`; return "symlink", "copy" or "existing".

    Staging exists so a tool is handed exactly the documents for one board, without the app ever moving
    or editing anything in the user's own `input/`. A symlink is the cheap way to say that and is what
    this has always done on Linux and macOS. Windows refuses it for an ordinary account --
    ``OSError: [WinError 1314] A required privilege is not held by the client``, unless the user is an
    administrator or has Developer Mode switched on -- so the fallback is a real copy. The copy is also
    strictly safer than a symlink: nothing downstream can write back through a staged path into the
    user's papers. Report of the original path is kept separately (see `App.staging_sources`).
    """

    global _SYMLINK_REFUSED
    if not src.is_file():
        # Caught here rather than as a dangling symlink or a copy error later: a paper that vanished
        # between the scan and the run should be reported by name, before any tool is started.
        raise ToolError(f"cannot stage {src}: no such file (was it moved while the batch was planned?)")
    if target.exists():
        return "existing"
    try:
        os.symlink(src.resolve(), target)
        return "symlink"
    except (OSError, NotImplementedError) as exc:
        if not _SYMLINK_REFUSED:
            _SYMLINK_REFUSED = True
            print(f"[stage] this system will not create symlinks ({type(exc).__name__}: {exc}); "
                  f"staging real copies instead. Nothing is wrong with the papers -- the run just uses "
                  f"a little more disk in the app's scratch folder.")
    try:
        shutil.copy2(src, target)
    except OSError as exc:
        raise ToolError(f"cannot stage {src.name} for the batch: {exc}") from exc
    return "copy"


def _stage_documents(app: App, docs: List[Path], prefix: str) -> Path:
    """A temp dir holding exactly these documents (symlinks when the OS allows, copies when not)."""

    tmp = Path(tempfile.mkdtemp(prefix=f"staged_{prefix}_", dir=str(app.data_dir / "jobs")))
    recorded: Dict[str, str] = {}
    for src in docs:
        _stage_file(src, tmp / src.name)
        recorded[src.name] = str(src)
    app.staging_sources[tmp.name] = recorded
    return tmp


#: --- AI assist (opt-in Review helper: "Suggest topic") ------------------------------------------
#: The module is imported lazily so a build without an AI provider configured carries no extra
#: startup work; every path below is off unless TOPICAL_AI_PROVIDER / <data-dir>/ai_assist.json
#: names a provider (see core/topic_suggest for the full contract).
def _ai_module():
    from core import topic_suggest
    return topic_suggest


def ai_config(data_dir: Path):
    """The current AI configuration, resolved from the environment and the data dir."""

    return _ai_module().load_config(data_dir)


#: Environment variables that configure AI assist, in the same order ``core.topic_suggest`` reads them.
_AI_ENV = {"provider": "TOPICAL_AI_PROVIDER", "model": "TOPICAL_AI_MODEL",
           "base_url": "TOPICAL_AI_BASE_URL", "api_key": "TOPICAL_AI_API_KEY",
           "timeout": "TOPICAL_AI_TIMEOUT"}
#: The module's own tables, copied so the light reader cannot disagree about a default.
_AI_PROVIDERS = ("none", "ollama", "openai")
_AI_DEFAULT_MODELS = {"ollama": "llama3.1", "openai": "gpt-4o-mini"}
_AI_DEFAULT_BASE_URLS = {"ollama": "http://127.0.0.1:11434", "openai": "https://api.openai.com"}


def _ai_config_light(data_dir: Path) -> Dict[str, Any]:
    """The same configuration, read **without importing `core.topic_suggest`**.

    Importing that module pulls in `core/__init__.py`, which imports the cropping engine and therefore
    PyMuPDF, Pillow and numpy -- ~155 ms on the first request after a restart, for a question whose usual
    answer is "AI assist is off". This reader answers that question from the environment and the JSON
    file alone. `tests/test_app_speed.py` pins it against `AiConfig.load_config` over a matrix of
    environment-and-file combinations, so the two can never drift into disagreeing about precedence.
    """

    payload: Dict[str, Any] = {}
    source = "default"
    if data_dir is not None:
        path = Path(data_dir) / "ai_assist.json"
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                source = str(path)
            else:
                payload = {}
        except (OSError, ValueError):
            payload = {}
    env = {key: (os.environ.get(name) or "") for key, name in _AI_ENV.items()}
    provider = (env["provider"] or str(payload.get("provider") or "none")).strip().lower()
    if provider not in _AI_PROVIDERS:
        provider = "none"
    model = env["model"] or str(payload.get("model") or "")
    base_url = env["base_url"] or str(payload.get("base_url") or "")
    api_key = env["api_key"] or str(payload.get("api_key") or "")
    try:
        timeout = max(5.0, float(env["timeout"] or payload.get("timeout") or 60))
    except (TypeError, ValueError):
        timeout = 60.0
    if env["provider"] or env["model"] or env["base_url"]:
        source = "environment"
    if provider != "none":
        # the same two lines the module applies, including its per-provider defaults
        model = model or _AI_DEFAULT_MODELS.get(provider, "")
        base_url = (base_url or _AI_DEFAULT_BASE_URLS.get(provider, "")).rstrip("/")
    enabled = provider != "none"
    return {
        "enabled": enabled,
        "provider": provider,
        "model": model if enabled else "",
        "base_url": base_url if enabled else "",
        "key_present": bool(api_key),
        "timeout": timeout,
        "configured_by": source,
    }


def _ai_disabled_hint(light: Dict[str, Any]) -> str:
    """Why the button is missing -- the module's own words, read from the module when it is importable.

    The copy below is the fallback for the case this reader exists for: a build where importing
    `core.topic_suggest` is exactly what we are avoiding (or impossible). `tests/test_topic_suggest.py`
    pins the copy against `DISABLED_HINT`.
    """

    # Deliberately a copy rather than an import: importing the module here is exactly the 155 ms this
    # function exists to avoid (and the case where it cannot be imported at all still needs an answer
    # for the UI). `tests/test_app_speed.py` asserts this string equals `topic_suggest.DISABLED_HINT`,
    # so the two cannot drift apart without a test going red.
    return ("AI assist is off. To enable the Suggest topic button, set a provider in <data-dir>/ai_assist.json or export TOPICAL_AI_PROVIDER=ollama (local) or TOPICAL_AI_PROVIDER=openai with TOPICAL_AI_API_KEY (hosted).")


def _ai_cache_count(data_dir: Path) -> int:
    """How many answers the cache holds, read without importing the module (see `_ai_config_light`)."""

    try:
        payload = json.loads((Path(data_dir) / "ai_suggestions.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    entries = payload.get("entries") if isinstance(payload, dict) else None
    return len(entries) if isinstance(entries, dict) else 0


def ai_cache_path(data_dir: Path) -> Path:
    return Path(data_dir) / "ai_suggestions.json"


def ai_cache_entries(data_dir: Path) -> Dict[str, Any]:
    return _ai_module().load_cache(ai_cache_path(data_dir))


def _universal_argv(input_dir: Path, output_dir: Path, *, limit_per_paper: int = 0,
                   include_sat: bool = True, include_ib: bool = True) -> List[str]:
    argv = [sys.executable, str(TOOLS / "run_universal_batch.py"),
            "--input", str(input_dir), "--output", str(output_dir)]
    if limit_per_paper:
        argv += ["--limit-per-paper", str(limit_per_paper)]
    # BOTH directions are passed explicitly. The tool defaults these ON (the user's standing rule is
    # that a run processes every board without anyone ticking a box), so an app-side ``False`` that
    # emitted nothing would be silently ignored -- "don't process SAT" has to say so out loud.
    argv.append("--include-sat" if include_sat else "--no-include-sat")
    argv.append("--include-ib" if include_ib else "--no-include-ib")
    # --jobs 0 = pick automatically: one core left for this UI process and free RAM / ~1.1 GB per
    # worker (tools/run_universal_batch.resolve_jobs clamps whatever comes back). A small machine
    # resolves to 1 and behaves exactly as before; a bigger one renders several documents at once.
    argv += ["--jobs", "0"]
    # --prune-stale-dirs: the app owns this output tree, and a QP directory left by an earlier run
    # (a document the classifier has since re-typed, or a render that produced nothing) makes the
    # pack assembler refuse a whole session -- the user saw "0 packs" from a perfectly good paper.
    # Pruning removes ONLY directories holding zero question crops, and the runner still records
    # exactly what it removed under audit["preflight"]["pruned"], so the evidence is not lost.
    argv.append("--prune-stale-dirs")
    return argv


def _caie_argv(input_dir: Path, output_dir: Path, *, full_auto: bool = True) -> List[str]:
    """`main.py` for CAIE. full_auto mirrors the tool's own contract: `--full-auto` is its DEFAULT
    (production: every question is cropped, classified and filed), and `--no-full-auto` restores
    fail-closed review routing -- so the app sends the switch only to turn production mode OFF."""
    argv = [sys.executable, str(MAIN), "--input", str(input_dir), "--output", str(output_dir)]
    if not full_auto:
        argv.append("--no-full-auto")
    return argv


def plan_batch(app: App, input_dir: Path, output_dir: Path, board: str = "", *,
               limit_per_paper: int = 0, include_sat: bool = True, include_ib: bool = True,
               full_auto: bool = True, groups: Optional[Dict[str, List[Path]]] = None
               ) -> Tuple[List[List[str]], List[Path]]:
    """(steps, temp_dirs) -- one command per board group, in a stable order.

    `board=""` means *everything in the folder*: CAIE documents go to `main.py`, everything else to
    the universal router, in one job if the folder holds both. A named board runs only that board.
    The universal router refuses CAIE papers on purpose, so a mixed folder must never be handed to
    it whole -- that is what the staging is for.
    """
    groups = groups if groups is not None else _documents_by_board(app, input_dir)
    steps: List[List[str]] = []
    temp_dirs: List[Path] = []
    wanted = board.strip()
    if wanted and wanted.upper() == "CAIE":
        groups = {"CAIE": groups.get("CAIE", [])}

    if wanted and wanted.upper() != "CAIE":
        # one named non-CAIE board: stage just its documents (the router's own board filter)
        docs = groups.get(wanted) or groups.get(wanted.upper()) or []
        if not docs:
            raise ToolError(f"no {wanted} documents recognized in {input_dir}")
        staged = _stage_documents(app, docs, wanted.lower())
        temp_dirs.append(staged)
        steps.append(_universal_argv(staged, output_dir, limit_per_paper=limit_per_paper,
                                     include_sat=include_sat, include_ib=include_ib))
        return steps, temp_dirs

    caie = groups.get("CAIE", [])
    others = [doc for name, docs in groups.items() if name.upper() != "CAIE" for doc in docs]
    if caie:
        staged = _stage_documents(app, caie, "caie")
        temp_dirs.append(staged)
        steps.append(_caie_argv(staged, output_dir, full_auto=full_auto))
    if others:
        # stage the non-CAIE documents whenever CAIE is also present: the universal router must
        # never be handed a folder that still holds a Cambridge paper.
        if caie:
            staged = _stage_documents(app, others, "universal")
            temp_dirs.append(staged)
            steps.append(_universal_argv(staged, output_dir, limit_per_paper=limit_per_paper,
                                         include_sat=include_sat, include_ib=include_ib))
        else:
            steps.append(_universal_argv(input_dir, output_dir, limit_per_paper=limit_per_paper,
                                         include_sat=include_sat, include_ib=include_ib))
    if not steps:
        raise ToolError(f"nothing recognized in {input_dir}: no CAIE, AQA, Edexcel, IB or SAT documents")
    return steps, temp_dirs


def make_batch_job(app: App, input_dir: Path, output_dir: Path, board: str = "",
                   limit_per_paper: int = 0, rebuild_index: bool = True,
                   include_sat: bool = True, include_ib: bool = True,
                   full_auto: bool = True) -> Job:
    """Stage the input by board, run one command per board group, then refresh the index.

    `include_sat` / `include_ib` are ON by default: the app is the main way to run the script, and the
    user's standing instruction is that pressing run must process every board in the folder without a
    checkbox. They remain settable so a caller can exclude a board deliberately; the tool's own
    caution (IB crop validation) is reported in the run's audit when it applies.
    """
    groups = _documents_by_board(app, input_dir)
    steps, temp_dirs = plan_batch(app, input_dir, output_dir, board,
                                  limit_per_paper=limit_per_paper, include_sat=include_sat,
                                  include_ib=include_ib, full_auto=full_auto, groups=groups)
    app.register_root(output_dir)

    def progress() -> Dict[str, Any]:
        counts = _packs_written(output_dir)
        audit = _read_json(output_dir / "universal_batch_audit.json", {}) or {}
        return {**counts, "audit_counts": audit.get("counts", {})}

    def on_success() -> Dict[str, Any]:
        # Keep a durable map of staged document -> the user's real file *before* the staging dirs go:
        # the CAIE pipeline records qp_path pointing at the staging symlink, and once that is removed
        # the question papers become unfindable -- which silently killed text extraction for every
        # CAIE run. `index_sources.json` is what the indexer reads to find a paper after the fact.
        sources: Dict[str, str] = {}
        sidecar = output_dir / "index_sources.json"
        try:
            if sidecar.is_file():
                sources = json.loads(sidecar.read_text(encoding="utf-8")) or {}
        except (OSError, ValueError):
            sources = {}
        sources.update(_collect_staged_sources(app, temp_dirs))
        if sources:
            _write_json(sidecar, sources)
        for tmp in temp_dirs:
            shutil.rmtree(tmp, ignore_errors=True)
        audit = _read_json(output_dir / "universal_batch_audit.json", {}) or {}
        result: Dict[str, Any] = {"output": str(output_dir), "counts": audit.get("counts", {}),
                                  "steps": len(steps), "boards": sorted(groups)}
        if rebuild_index:
            payload, gaps, notes = _rebuild_index(app, [output_dir])
            result["index"] = payload.get("counts", {}) if payload else {"gap": gaps}
            result["index_notes"] = notes
        return result

    job = Job("batch", steps, app.data_dir / "jobs" / "batch.log", progress, on_success)
    #: the plan is known now, not only at success time — the 202 answer reports it
    job.boards = sorted(groups)
    return job


def _stage_board_input(app: App, input_dir: Path, board: str) -> Tuple[Path, Path]:
    """A temp dir of symlinks to just that board's PDFs (the batch tool is never modified)."""
    try:
        payload = run_detector(app, input_dir)
    except ToolError as exc:
        raise ToolError(f"cannot stage {board} input: {exc}", exc.tail, exc.returncode) from exc
    tmp = Path(tempfile.mkdtemp(prefix=f"staged_{board.lower()}_", dir=str(app.data_dir / "jobs")))
    keep = []
    for board_group in payload.get("boards", []):
        if str(board_group.get("board", "")).lower() != board.lower():
            continue
        for subject in board_group.get("subjects", []):
            for doc in subject.get("documents", []):
                keep.append(Path(doc["path"]))
    recorded: Dict[str, str] = {}
    for src in keep:
        _stage_file(src, tmp / src.name)
        recorded[src.name] = str(src)
    app.staging_sources[tmp.name] = recorded
    return tmp, tmp


def _collect_staged_sources(app: App, temp_dirs: List[Path]) -> Dict[str, str]:
    """`{staged name: the user's real paper}` for the `index_sources.json` sidecar.

    The indexer reads that sidecar to find the *original* question paper after the run, and the
    staging folders are deleted straight afterwards. `entry.resolve()` used to be enough because every
    staged entry was a symlink; a staged **copy** (Windows, where symlinks need a privilege) resolves
    into the scratch folder and would leave the index pointing at a path that no longer exists. So the
    originals are taken from what was recorded while staging, and the resolve pass remains only as a
    fallback for a staging path that did not go through `_stage_documents`.
    """

    sources: Dict[str, str] = {}
    for tmp in temp_dirs:
        recorded = app.staging_sources.pop(tmp.name, None)
        if recorded:
            for name, original in recorded.items():
                if Path(original).is_file():
                    sources[name] = original
            continue
        try:
            for entry in sorted(tmp.iterdir()):
                if entry.is_symlink() or entry.is_file():
                    real = entry.resolve()
                    if real.is_file():
                        sources[entry.name] = str(real)
        except OSError:
            continue
    return sources


def reveal_in_file_manager(app: App, target: Path) -> Dict[str, Any]:
    """Open a folder in the OS file manager -- the launcher's "6. Open output folder", in the app.

    Only registered roots are revealable (the same allow-list `/files/` uses). Headless machines,
    containers and servers with no opener are not errors: the caller gets ``opened: False`` plus the
    path and the reason, so the UI can show the path instead of pretending something happened.
    """
    resolved = target if target.is_dir() else target.parent
    try:
        inside = any(resolved.resolve().is_relative_to(root) for root in app.roots)
    except OSError:
        inside = False
    if not inside:
        raise ToolError("path is outside the registered output roots", [], 403)
    if not resolved.is_dir():
        raise ToolError(f"no such folder: {resolved}", [], 404)
    if sys.platform.startswith("win"):
        try:
            os.startfile(str(resolved))                             # noqa: S606 - Windows shell API
            return {"path": str(resolved), "opened": True, "command": "startfile"}
        except OSError as exc:
            return {"path": str(resolved), "opened": False, "note": f"startfile failed: {exc}"}
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    if shutil.which(opener) is None:
        return {"path": str(resolved), "opened": False,
                "note": f"no file-manager opener on this machine ({opener} not found) -- "
                        f"the folder is at {resolved}"}
    try:
        subprocess.Popen([opener, str(resolved)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"path": str(resolved), "opened": True, "command": opener}
    except OSError as exc:
        return {"path": str(resolved), "opened": False, "note": f"{opener} failed: {exc}"}


def make_booklet_job(app: App, request: dict, allow_flagged: bool = False, fit: str = "one_page") -> Job:
    job_dir = app.data_dir / "booklets" / f"booklet-{uuid.uuid4().hex[:10]}"
    job_dir.mkdir(parents=True, exist_ok=True)
    request_path = job_dir / "booklet.json"
    _write_json(request_path, request)
    out_pdf = job_dir / "booklet.pdf"
    argv = [sys.executable, str(TOOLS / "build_booklet.py"),
            "--booklet", str(request_path), "--index", str(app.index_path), "--out", str(out_pdf),
            "--fit", fit]
    if allow_flagged:
        argv.append("--allow-flagged")
    #: the Word export renders the same manifest the PDF was built from, so they cannot disagree
    wants_docx = str(request.get("format") or "").lower() == "docx"

    def progress() -> Dict[str, Any]:
        manifest = _read_json(out_pdf.with_suffix(".manifest.json"), {}) or {}
        return {"pages": (manifest.get("pdf") or {}).get("pages"),
                "entries": len(manifest.get("entries") or []), "output": str(out_pdf)}

    def on_success() -> Dict[str, Any]:
        manifest_path = out_pdf.with_suffix(".manifest.json")
        manifest = _read_json(manifest_path, {}) or {}
        result: Dict[str, Any] = {
            "pdf": str(out_pdf), "manifest": str(manifest_path),
            "pages": (manifest.get("pdf") or {}).get("pages"),
            "questions": sum(1 for e in manifest.get("entries", []) if e.get("kind") == "question"),
            "answers": manifest.get("answers"), "fit": manifest.get("fit"),
            "total_marks": manifest.get("total_marks"),
            "warnings": manifest.get("warnings", [])}
        if wants_docx:
            # Same manifest, second renderer: the Word file can never disagree with the PDF.
            docx_path = job_dir / "booklet.docx"
            try:
                subprocess.run([sys.executable, str(TOOLS / "booklet_docx.py"),
                                "--manifest", str(manifest_path), "--out", str(docx_path)],
                               cwd=str(ROOT), capture_output=True, text=True, timeout=300, check=True)
                result["docx"] = str(docx_path)
                result["docx_batch_rel"] = _rel_to_root(app, docx_path)
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as exc:
                result["docx_error"] = f"{type(exc).__name__}: {exc}"
        return result

    return Job("booklet", argv, job_dir / "build.log", progress, on_success)


# --------------------------------------------------------------------------------------------------
# tool wrappers (subprocesses: the server process stays small)
# --------------------------------------------------------------------------------------------------
def _run_tool(argv: List[str], timeout: int = 900) -> subprocess.CompletedProcess:
    return subprocess.run(argv, cwd=str(ROOT), capture_output=True, text=True, timeout=timeout)


class ToolError(RuntimeError):
    """A tool the server shells out to failed; carries the tail of its output."""

    def __init__(self, message: str, tail: str = "", returncode: int = -1):
        super().__init__(message)
        self.tail = tail
        self.returncode = returncode


def _input_fingerprint(input_dir: Path) -> tuple:
    """Identity of what the detector would read: every PDF under the folder, by path, size and mtime.

    `detect_subjects.py` uses ``rglob`` over ``*.pdf`` and ``*.PDF``, so this walk uses exactly the
    same two patterns -- a fingerprint that looked at fewer files could serve an answer for a folder
    that has since changed.
    """

    try:
        paths = sorted({p.resolve() for pat in ("*.pdf", "*.PDF") for p in input_dir.rglob(pat)})
        return tuple((str(p), p.stat().st_size, p.stat().st_mtime_ns) for p in paths if p.is_file())
    except OSError:
        return ()          # unreadable folder: fingerprint as empty, which never matches a real scan


def run_detector(app: App, input_dir: Path, use_cache: bool = True) -> Dict[str, Any]:
    """Run `detect_subjects.py` and return its JSON -- or raise ToolError (never a silent empty).

    The detector is a subprocess (~1 s), and the app asks for it constantly: opening the Library, every
    board the batch planner stages, and any rescan. Results are kept per folder and returned only when
    the folder's fingerprint still matches, so a repeated scan of an unchanged folder costs a directory
    walk instead of a process.
    """

    key = str(input_dir.resolve())
    fingerprint = _input_fingerprint(input_dir)
    if use_cache:
        with app.detection_lock:
            hit = app.detection_cache.get(key)
        if hit is not None and hit[0] == fingerprint:
            return {**hit[1], "cached": True}
    out = app.data_dir / "jobs" / "detected_subjects.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()                                               # a stale file must never be served
    proc = _run_tool([sys.executable, str(TOOLS / "detect_subjects.py"),
                      "--input", str(input_dir), "--out", str(out), "--quiet"])
    payload = _read_json(out, {}) or {}
    if not payload or proc.returncode != 0:
        tail = "\n".join((proc.stdout + proc.stderr).strip().splitlines()[-8:])
        raise ToolError(f"detect_subjects.py exited {proc.returncode}", tail, proc.returncode)
    with app.detection_lock:
        app.detection_cache[key] = (fingerprint, payload)
        while len(app.detection_cache) > 8:      # a long session with many folders must not grow
            app.detection_cache.pop(next(iter(app.detection_cache)))
    return payload


def _rebuild_index(app: App, batch_outs: List[Path], reset: bool = False, ocr: bool = False,
                   extract_text: bool = True) -> Tuple[dict, List[str], List[str]]:
    if not batch_outs:
        batch_outs = [Path(r) for r in (_read_json(app.index_path, {}) or {}).get(
            "inputs", {}).get("batch_outs", [])]
        batch_outs = [p for p in batch_outs if Path(p).is_dir()]
    if not batch_outs:
        return {}, ["no batch output known yet"], []
    for root in batch_outs:
        app.register_root(root)
    argv = [sys.executable, str(TOOLS / "build_topical_index.py"), "--out", str(app.index_path),
            "--overrides", str(app.overrides_path)]
    if reset:
        argv.append("--reset")                     # index exactly these sources, drop older rows
    if not extract_text:
        argv.append("--no-text")
    if ocr:
        argv.append("--ocr")                       # asked for in the UI: OCR the crops for search
    for root in batch_outs:
        argv += ["--batch-out", str(root)]
    proc = _run_tool(argv, timeout=300)
    payload = _read_json(app.index_path, {}) or {}
    notes = list(payload.get("notes") or [])
    if proc.returncode != 0:
        return {}, [ln for ln in (proc.stdout + proc.stderr).splitlines() if ln.strip()][-6:], notes
    return payload, [], notes


# --------------------------------------------------------------------------------------------------
# request handlers
# --------------------------------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "TopicalBank/1.0"
    app: App = None                                                # set by make_server

    # -- plumbing ------------------------------------------------------------------------------
    def log_message(self, fmt: str, *args) -> None:                # quieter, still useful
        if os.environ.get("TOPICAL_APP_SERVER_LOG"):
            sys.stderr.write("[server] " + (fmt % args) + "\n")

    def _send(self, code: int, body: bytes, content_type: str, extra: Optional[dict] = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code: int, payload: Any) -> None:
        self._send(code, json.dumps(payload, indent=1, ensure_ascii=False).encode("utf-8"),
                   CONTENT_TYPES[".json"])

    def _error(self, code: int, message: str, **extra) -> None:
        self._json(code, {"error": message, "status": code, **extra})

    def _body(self) -> Optional[dict]:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except Exception:                                          # noqa: BLE001
            return None
        return payload if isinstance(payload, dict) else None

    def do_OPTIONS(self) -> None:                                   # noqa: N802
        self._send(204, b"", CONTENT_TYPES[".txt"])

    def do_GET(self) -> None:                                       # noqa: N802
        self._route("GET")

    def do_POST(self) -> None:                                      # noqa: N802
        self._route("POST")

    # -- routing -------------------------------------------------------------------------------
    def _origin_allowed(self, method: str, path: str) -> bool:
        """Refuse cross-site writes.

        A page on any site can POST to 127.0.0.1:8765 while it is open -- the browser does not stop it,
        and this server had no check. Mutating requests are therefore refused when the browser says they
        came from another origin (``Origin``, or ``Sec-Fetch-Site`` for browsers that omit it). Requests
        with neither header (curl, the CLI, tests) are unaffected, and a token -- when the server was
        started with ``--token`` -- authenticates anything that does carry one.
        """
        if method in ("GET", "HEAD", "OPTIONS"):
            return True
        host = self.headers.get("Host") or ""
        allowed = {f"127.0.0.1:{self.server.server_address[1]}", f"localhost:{self.server.server_address[1]}",
                   host}
        origin = self.headers.get("Origin")
        if origin:
            return any(origin == f"http://{name}" or origin == f"https://{name}" for name in allowed)
        site = self.headers.get("Sec-Fetch-Site")
        if site and site not in ("same-origin", "same-site", "none"):
            return False
        if self.server.token:
            supplied = self.headers.get("X-Token") or (parse_qs(urlparse(self.path).query).get("token") or [""])[0]
            return supplied == self.server.token
        return True

    def _route(self, method: str) -> None:
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        if not self._origin_allowed(method, path):
            return self._error(403, "cross-site or unauthenticated request refused",
                               hint="open the app from its own address, or pass ?token=… when the "
                                    "server was started with --token")
        try:
            if path.startswith("/api/"):
                return self._api(method, path, query)
            if path.startswith("/files/"):
                return self._files(path[len("/files/"):])
            if method == "GET":
                return self._static(path)
            return self._error(405, f"{method} not allowed for {path}")
        except BrokenPipeError:
            return
        except Exception as exc:                                   # noqa: BLE001 - never kill the server
            return self._error(500, f"{type(exc).__name__}: {exc}")

    def _api(self, method: str, path: str, query: Dict[str, List[str]]) -> None:
        app = self.app
        if path == "/api/health":
            INPUT_DIR.mkdir(parents=True, exist_ok=True)
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            return self._json(200, {
                "ok": True, "server": self.server_version, "python": sys.version.split()[0],
                "data_dir": str(app.data_dir), "roots": [str(r) for r in app.roots],
                "input_dir": str(INPUT_DIR), "output_dir": str(OUTPUT_DIR),
                "input_pdfs": sum(1 for p in INPUT_DIR.rglob("*")
                                  if p.is_file() and p.suffix.lower() == ".pdf"),
                #: a real folder of PDFs the self-test page can scan without the user typing a path
                "sample_input": str(ROOT / "papers" / "real_noncaie" / "aqa_extra"),
                "jobs_running": app.jobs.running(),
                "index": str(app.index_path) if app.index_path.exists() else None,
            })
        if path == "/api/catalogue":
            return self._json(200, _read_json(ROOT / "subjects.json", {}) or {})
        if path == "/api/detection" and method == "GET":
            # `?input=` is optional: with no argument, scan the standard input folder
            target = (query.get("input") or [""])[0] or str(INPUT_DIR)
            input_dir = Path(target).expanduser()
            if not input_dir.is_dir():
                return self._error(400, f"input directory not found: {input_dir}")
            try:
                return self._json(200, run_detector(app, input_dir))
            except ToolError as exc:
                # The detector's own refusal ("no PDFs under <dir>", exit 2, never a silent empty) is
                # reported as an *unprocessable folder*, not a server fault: scanning the shipped
                # `input/` before anything has been dropped into it is a normal state, and 500 would
                # read as "the app broke" when the honest answer is "that folder has no papers".
                # Matched on the detector's own words, because exit 2 is also what a python that
                # cannot even open the module returns -- and THAT is a real 500.
                status = 422 if (exc.returncode == 2 and "no PDFs" in exc.tail) else 500
                return self._error(status, str(exc), log_tail=exc.tail.splitlines(),
                                   returncode=exc.returncode, input_dir=str(input_dir))
        if path == "/api/batch" and method == "POST":
            body = self._body()
            if body is None:
                return self._error(400, "body must be a JSON object")
            # No folder named -> the folders that sit beside the script. A caller that DOES name one
            # still has to name a real one: a typo must never silently scan the default folder.
            input_dir = Path(str(body.get("input") or INPUT_DIR)).expanduser()
            if not input_dir.is_dir():
                return self._error(400, f"input folder not found: {input_dir}")
            output_dir = Path(str(body.get("output") or OUTPUT_DIR)).expanduser()
            output_dir.mkdir(parents=True, exist_ok=True)
            board = str(body.get("board") or "")
            # Every board runs unless the caller says otherwise: IB and SAT included by default, so
            # "run" just runs. A caller can still switch either off explicitly.
            include_sat = bool(body.get("include_sat", True))
            include_ib = bool(body.get("include_ib", True))
            # production mode is the Cambridge pipeline's own default; an absent flag must never
            # quietly turn it OFF or ON, so an omitted key means "leave the tool's default alone"
            full_auto = bool(body.get("full_auto", True))
            try:
                job = make_batch_job(app, input_dir.resolve(), output_dir.resolve(), board,
                                     int(body.get("limit_per_paper") or 0),
                                     bool(body.get("rebuild_index", True)),
                                     include_sat=include_sat, include_ib=include_ib,
                                     full_auto=full_auto)
            except ToolError as exc:
                return self._error(502, str(exc), log_tail=exc.tail.splitlines(),
                                   returncode=exc.returncode)
            app.jobs.add(job)
            self._json(202, {"job": job.id, "status": job.status, "kind": job.kind,
                             "output": str(output_dir),
                             "boards": list(getattr(job, "boards", []) or []) or None,
                             "steps": len(job.argvv),
                             "full_auto": full_auto,
                             "include_sat": include_sat, "include_ib": include_ib})
            job.release()
            return
        if path == "/api/reveal" and method == "POST":
            body = self._body()
            if body is None:
                return self._error(400, "body must be a JSON object")
            raw = str(body.get("path") or "").strip()
            if not raw:
                return self._error(400, "path is required")
            try:
                return self._json(200, reveal_in_file_manager(app, Path(raw).expanduser()))
            except ToolError as exc:
                return self._error(int(exc.returncode or 400), str(exc))
        if path == "/api/ai/status" and method == "GET":
            # What the UI needs to decide whether the Suggest topic button exists at all: shape and
            # model, never the API key (see core/topic_suggest.AiConfig.public).
            #
            # Answered from the light reader first: the usual answer is "off", and importing the AI
            # module to say so costs ~155 ms on the first request after every restart, because that
            # import drags the whole `core` package (and PyMuPDF) in with it. The heavy path is only
            # taken when a provider really is configured, and a build where the module cannot be
            # imported reports "off" with the reason instead of a 500 -- a missing dependency is not
            # a server fault.
            # Nothing here imports `core.topic_suggest`, configured or not. It used to take the heavy
            # path whenever a provider was set, which meant a status call could still cost 393 ms of
            # PyMuPDF on the first paint -- and could still 500 on a build whose dependencies were
            # missing. The light reader mirrors the module exactly (pinned by test), and the cache
            # count comes from the same file the module reads, so there is nothing left to import.
            light = _ai_config_light(app.data_dir)
            cache_path = ai_cache_path(app.data_dir)
            return self._json(200, {**light,
                                    "hint": "" if light["enabled"] else _ai_disabled_hint(light),
                                    "cache_entries": _ai_cache_count(app.data_dir),
                                    "cache_path": str(cache_path)})
        if path == "/api/ai/suggest" and method == "POST":
            body = self._body()
            if body is None or not str(body.get("id") or "").strip():
                return self._error(400, "body must be a JSON object with an index row 'id'")
            config = ai_config(app.data_dir)
            if not config.enabled:
                return self._error(501, "AI assist is not configured",
                                   hint=_ai_module().DISABLED_HINT)
            payload = _read_json(app.index_path, {}) or {}
            rows = payload.get("questions") or []
            row = next((r for r in rows if str(r.get("id")) == str(body["id"])), None)
            if row is None:
                return self._error(404, f"no index row with id {body['id']!r}",
                                   hint="rebuild the index (POST /api/index) if the batch output changed")
            refusal = _ai_module().refusal_for_row(row)
            if refusal:
                return self._error(409, refusal,
                                   hint="this button exists only for rows the offline classifier "
                                        "would not claim; a confident verdict is not re-litigated")
            topics = _ai_module().subject_topics(row.get("board") or "", row.get("code") or "")
            if not topics:
                return self._error(422, f"no topic list for {row.get('board')} {row.get('code')}",
                                   hint="the subject profile is missing, so there is no list for the "
                                        "model to choose from")
            try:
                result = _ai_module().suggest(config=config, question_text=str(row.get("text") or ""),
                                 topics=topics,
                                 board=str(row.get("board") or ""), code=str(row.get("code") or ""),
                                 component=str(row.get("component") or ""),
                                 question_number=row.get("question_number"), row_id=str(row.get("id")),
                                 cache_path=ai_cache_path(app.data_dir),
                                 refresh=bool(body.get("refresh")))
            except _ai_module().AiUnavailable as exc:
                return self._error(501, str(exc), hint=_ai_module().DISABLED_HINT)
            except _ai_module().AiError as exc:
                return self._error(502, f"the model could not answer: {exc}",
                                   hint=f"provider {config.provider}, model {config.model}")
            result["row"] = {"id": row.get("id"), "topic": row.get("topic"),
                             "status": row.get("status"), "text_source": row.get("text_source"),
                             "review_reasons": list(row.get("review_reasons") or [])}
            result["note"] = ("Suggestions only -- nothing was assigned. Choose one in the Assign "
                              "control, or ignore them.")
            return self._json(200, result)
        if path.startswith("/api/jobs/") and path.endswith("/rerun") and method == "POST":
            job_id = path[len("/api/jobs/"):-len("/rerun")].strip("/")
            job = app.jobs.get(job_id)
            if job is None:
                return self._error(404, f"no such job: {job_id}")
            if job.status in ("queued", "running"):
                return self._error(409, f"job {job_id} is still {job.status}")
            fresh = Job(job.kind, job.argvv if len(job.argvv) > 1 else job.argvv[0], job.log_path,
                        job.progress_fn, job.on_success)
            app.jobs.add(fresh)
            self._json(202, {"job": fresh.id, "status": fresh.status, "rerun_of": job_id})
            fresh.release()
            return
        if path == "/api/jobs" and method == "GET":
            return self._json(200, {"jobs": [j.view() for j in app.jobs.all()]})
        if path.startswith("/api/jobs/") and method == "GET":
            job = app.jobs.get(path.rsplit("/", 1)[-1])
            if job is None:
                return self._error(404, f"no such job: {path.rsplit('/', 1)[-1]}")
            return self._json(200, job.view())
        if path == "/api/index" and method == "GET":
            payload = _read_json(app.index_path, {}) or {}
            if not payload:
                return self._json(200, {"schema": "topical_index/1", "counts": {"questions": 0},
                                        "questions": [], "flagged": [],
                                        "note": "no index yet -- POST /api/index"})
            payload = _filter_index(payload, query)
            return self._json(200, payload)
        if path == "/api/index" and method == "POST":
            body = self._body()
            if body is None:
                return self._error(400, "body must be a JSON object")
            batch_outs = [Path(str(p)).expanduser() for p in (body.get("batch_out") or [])]
            out = Path(str(body.get("out") or app.index_path)).expanduser()
            missing = [str(p) for p in batch_outs if not p.is_dir()]
            if missing:
                return self._error(400, f"batch_out not found: {', '.join(missing)}")
            reset = bool(body.get("reset"))
            # both switches are honoured, never accepted-and-ignored: text extraction is on by
            # default (it is what makes the bank searchable) and OCR is opt-in because it is slow
            ocr = bool(body.get("ocr"))
            extract_text = bool(body.get("extract_text", True))
            payload, gaps, notes = _rebuild_index(app, batch_outs, reset=reset, ocr=ocr,
                                                   extract_text=extract_text)
            if gaps:
                return self._error(422, "index refused (fail-closed): " + "; ".join(gaps[:4]),
                                   notes=notes)
            written = [str(app.index_path)]
            if out != app.index_path:
                # `out` is honoured, not accepted-and-ignored: an identical copy lands there too
                # (the server's own index stays the single one the app reads).
                try:
                    out.parent.mkdir(parents=True, exist_ok=True)
                    _write_json(out, payload)
                    written.append(str(out))
                except OSError as exc:
                    return self._error(500, f"index built but could not be written to {out}: {exc}",
                                       written=written)
            payload["written"] = written
            payload["rebuilt"] = {"batch_outs": [str(p) for p in batch_outs], "reset": reset}
            return self._json(200, payload)
        if path == "/api/coverage" and method == "GET":
            payload = _read_json(app.index_path, {}) or {}
            return self._json(200, build_coverage(payload, app))
        if path == "/api/index/export" and method == "GET":
            payload = _read_json(app.index_path, {}) or {}
            if not payload:
                return self._error(409, "no topical index yet")
            fmt = ((query.get("format") or ["json"])[0] or "json").lower()
            filtered = _filter_index(payload, query)
            if fmt == "csv":
                body = _index_csv(filtered).encode("utf-8")
                return self._send(200, body, "text/csv; charset=utf-8",
                                  {"Content-Disposition": 'attachment; filename="topical_index.csv"'})
            if fmt == "html":
                from core.gallery_export import build_gallery_html      # noqa: PLC0415 (local, keeps server.py stdlib)
                page = build_gallery_html(filtered, app).encode("utf-8")
                return self._send(200, page, "text/html; charset=utf-8",
                                  {"Content-Disposition": 'attachment; filename="question_bank.html"'})
            body = json.dumps(filtered, indent=1, ensure_ascii=False).encode("utf-8")
            return self._send(200, body, "application/json; charset=utf-8",
                              {"Content-Disposition": 'attachment; filename="topical_index.json"'})
        if path == "/api/watch" and method == "GET":
            with app.watch_lock:
                state = dict(app.watcher or {})
            return self._json(200, state)
        if path == "/api/watch" and method == "POST":
            body = self._body()
            if body is None:
                return self._error(400, "body must be a JSON object")
            action = str(body.get("action") or "start").lower()
            if action == "stop":
                app.stop_watch()
                return self._json(200, {"watching": False})
            # watch = "there are papers in the input folder": same defaults as the batch button
            input_dir = Path(str(body.get("input") or INPUT_DIR)).expanduser()
            if not input_dir.is_dir():
                return self._error(400, f"input folder not found: {input_dir}")
            output_dir = Path(str(body.get("output") or OUTPUT_DIR)).expanduser()
            interval = max(5, int(body.get("interval") or 20))
            app.start_watch(input_dir.resolve(), output_dir.resolve(), interval)
            with app.watch_lock:
                state = dict(app.watcher or {})
            return self._json(200, state)
        if path == "/api/overrides" and method == "POST":
            body = self._body()
            if body is None:
                return self._error(400, "body must be a JSON object")
            qid = str(body.get("id") or "").strip()
            if not qid:
                return self._error(400, "id is required")
            from tools.build_topical_index import (clear, dismiss, load_overrides,  # noqa: PLC0415
                                                   save_overrides, set_topic)
            if body.get("dismiss"):
                dismiss(app.overrides_path, qid, str(body.get("reason") or ""))
            elif body.get("topic"):
                set_topic(app.overrides_path, qid, str(body["topic"]), str(body.get("note") or ""))
            elif body.get("clear"):
                clear(app.overrides_path, qid)
            else:
                return self._error(400, "send {id, topic} to assign, {id, dismiss: true} to dismiss, "
                                        "or {id, clear: true} to reset")
            payload, gaps, notes = _rebuild_index(app, [])
            return self._json(200, {"overrides": load_overrides(app.overrides_path),
                                    "index": payload.get("counts", {}), "gaps": gaps, "notes": notes})
        if path == "/api/draft" and method == "GET":
            return self._json(200, _read_json(app.draft_path, {}) or {"schema": "booklet_request/1",
                                                                     "questions": []})
        if path == "/api/draft" and method == "POST":
            body = self._body()
            if body is None:
                return self._error(400, "body must be a JSON object")
            draft = _read_json(app.draft_path, {}) or {"schema": "booklet_request/1", "questions": []}
            if body.get("reset"):
                draft = {"schema": "booklet_request/1", "questions": []}
            else:
                for key in ("title", "subtitle", "board", "code", "answers", "options"):
                    if key in body:
                        draft[key] = body[key]
                if "questions" in body:
                    draft["questions"] = body["questions"]
                elif "add" in body:
                    ids = [str(i) for i in (body["add"] if isinstance(body["add"], list)
                                            else [body["add"]])]
                    have = {str((q or {}).get("id")) for q in draft.get("questions", [])}
                    draft.setdefault("questions", []).extend({"id": i} for i in ids if i not in have)
                elif "remove" in body:
                    drop = {str(i) for i in (body["remove"] if isinstance(body["remove"], list)
                                             else [body["remove"]])}
                    draft["questions"] = [q for q in draft.get("questions", [])
                                          if str((q or {}).get("id")) not in drop]
                draft["schema"] = "booklet_request/1"
                draft["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime())
            _write_json(app.draft_path, draft)
            return self._json(200, draft)
        if path == "/api/booklet" and method == "POST":
            body = self._body()
            if body is None:
                return self._error(400, "body must be a JSON object")
            # "Build a booklet from a booklet.json" (the launcher's option 4): a request may name a
            # file instead of carrying the JSON inline. The file is read here so the tool receives
            # exactly the same shape either way, and a missing/invalid file is a 400, never a job
            # that fails later with a confusing log.
            booklet_path = str(body.get("booklet_path") or "").strip()
            if booklet_path:
                candidate = Path(booklet_path).expanduser()
                if not candidate.is_absolute():
                    candidate = (app.data_dir / candidate)
                if not candidate.is_file():
                    return self._error(400, f"no such booklet request: {candidate}")
                try:
                    loaded = json.loads(candidate.read_text(encoding="utf-8"))
                except (OSError, ValueError) as exc:
                    return self._error(400, f"{candidate} is not readable JSON: {exc}")
                if not isinstance(loaded, dict):
                    return self._error(400, f"{candidate} must hold a JSON object")
                loaded = {**loaded, **{k: v for k, v in body.items() if k != "booklet_path"}}
                body = loaded
                # a booklet.json whose questions are bare strings would start a job that dies inside
                # the tool with a traceback; name the shape here instead (the launcher's option 4
                # hits exactly this the moment someone hand-writes a request)
                questions = body.get("questions") or []
                if not isinstance(questions, list) or any(not isinstance(q, dict) for q in questions):
                    return self._error(400, f"{candidate}: 'questions' must be a list of objects like "
                                            f'{{"id": "AQA|8462/1H|June 2023|Q1"}}, not '
                                            f"{type(questions[0]).__name__ if questions else 'a non-list'}")
                if any(not q.get("id") for q in questions):
                    return self._error(400, f"{candidate}: every question needs an 'id'")
            if not (body.get("questions") or []):
                return self._error(400, "send a booklet request with at least one question")
            if not app.index_path.exists():
                return self._error(409, "no topical index yet -- POST /api/index first")
            job = make_booklet_job(app, body, bool(body.get("allow_flagged")),
                                   str((body.get("options") or {}).get("fit")
                                       or body.get("fit") or "one_page"))
            app.jobs.add(job)
            self._json(202, {"job": job.id, "status": job.status, "kind": job.kind})
            job.release()
            return
        if path.startswith("/api/booklet/") and path.endswith("/pdf") and method == "GET":
            job_id = path[len("/api/booklet/"):-len("/pdf")].strip("/")
            job = app.jobs.get(job_id)
            if job is None:
                return self._error(404, f"no such booklet job: {job_id}")
            pdf = Path(str(job.result.get("pdf") or ""))
            if job.status != "done" or not pdf.is_file():
                return self._error(409, f"booklet not ready (status {job.status})",
                                   log_tail=job.log_tail(12))
            return self._send(200, pdf.read_bytes(), CONTENT_TYPES[".pdf"],
                              {"Content-Disposition": f'inline; filename="{pdf.name}"'})
        return self._error(404, f"no such endpoint: {path}")

    # -- static + files --------------------------------------------------------------------------
    def _static(self, path: str) -> None:
        rel = path.lstrip("/") or "index.html"
        target = (STATIC / rel)
        try:
            real = target.resolve()
            real.relative_to(STATIC.resolve())
        except (OSError, ValueError):
            return self._error(403, "path escapes the static root")
        if not real.is_file():
            if rel == "index.html":
                return self._send(200, _PLACEHOLDER, CONTENT_TYPES[".html"])
            return self._error(404, f"not found: {rel}")
        return self._send(200, real.read_bytes(),
                          CONTENT_TYPES.get(real.suffix.lower(), "application/octet-stream"))

    def _files(self, rel: str) -> None:
        resolved = self.app.resolve_file(rel)
        if resolved is None:
            return self._error(403, "path is outside the registered output roots (or does not exist)",
                               requested=rel, roots=[str(r) for r in self.app.roots])
        return self._send(200, resolved.read_bytes(),
                          CONTENT_TYPES.get(resolved.suffix.lower(), "application/octet-stream"))


def _profile_topics(board: str, code: str, app: App) -> Optional[dict]:
    """The subject's declared topics from its profile, or None when it has no profile (adapter-only)."""
    roots = {"CAIE": ROOT / "subjects_caie", "AQA": ROOT / "subjects_aqa",
             "EDEXCEL": ROOT / "subjects_edexcel", "IB": ROOT / "subjects_ib"}
    root = roots.get(board.upper())
    if root is None or not root.is_dir():
        return None
    for config_path in sorted(root.rglob(f"*{code}*/config.json")):
        try:
            payload = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        major = list(payload.get("major_topics") or [])
        detailed = list(payload.get("detailed_topics") or payload.get("mapping") or [])
        if isinstance(detailed, dict):
            detailed = list(detailed)
        return {"majors": major, "detaileds": detailed, "profile": str(config_path.relative_to(ROOT))}
    return None


def build_coverage(index: dict, app: App) -> dict:
    """Declared syllabus topics vs questions actually banked, per subject.

    The question "what am I missing?" needs the profile's own topic list -- the index only knows what
    was found. Subjects without a profile (adapter-only inventory rows) are reported as such rather
    than shown as 100% covered.
    """
    counts: Dict[str, Dict[str, int]] = {}
    for row in index.get("questions") or []:
        key = f"{row.get('board')} {row.get('code') or '????'}"
        bucket = counts.setdefault(key, {})
        bucket[str(row.get("topic") or "UNKNOWN")] = bucket.get(str(row.get("topic") or "UNKNOWN"), 0) + 1
    subjects = []
    for key, seen in sorted(counts.items()):
        board, _, code = key.partition(" ")
        profile = _profile_topics(board, code, app)
        declared = []
        if profile:
            declared = sorted({*profile["majors"], *profile["detaileds"]})
        covered = [t for t in declared if seen.get(t)]
        subjects.append({
            "key": key, "board": board, "code": code, "profile": (profile or {}).get("profile"),
            "declared": declared, "covered": covered,
            "missing": [t for t in declared if not seen.get(t)],
            "found_outside_profile": sorted(t for t in seen if t not in declared and t != "UNKNOWN"),
            "counts": dict(sorted(seen.items())),
            "questions": sum(seen.values()),
        })
    return {"schema": "coverage/1", "subjects": subjects}


def _filter_index(payload: dict, query: Dict[str, List[str]]) -> dict:
    rows = list(payload.get("questions") or [])

    def one(key: str) -> str:
        return (query.get(key) or [""])[0].strip()

    if one("flagged") in ("1", "true", "yes"):
        rows = [r for r in rows if not r.get("listable")]
    for key, field in (("board", "board"), ("subject", "subject"), ("topic", "topic"),
                       ("component", "component"), ("session", "session"), ("year", "year")):
        want = one(key)
        if want:
            rows = [r for r in rows if str(r.get(field) or "").lower() == want.lower()]
    search = one("q")
    if search:
        low = search.lower()
        rows = [r for r in rows if low in json.dumps(r, ensure_ascii=False).lower()]
    out = dict(payload)
    out["questions"] = rows
    out["counts"] = dict(payload.get("counts") or {})
    out["filtered"] = {"rows": len(rows), "of": len(payload.get("questions") or [])}
    return out


def _rel_to_root(app: App, path: Path) -> str:
    """Path relative to whichever registered root contains it -- what `/files/<rel>` expects."""
    try:
        real = path.resolve()
        for root in app.roots:
            try:
                return str(real.relative_to(root))
            except ValueError:
                continue
    except OSError:
        pass
    return ""


_PLACEHOLDER = (b"<!doctype html><meta charset='utf-8'><title>Topical Bank</title>"
                b"<body style=\"font:16px -apple-system,system-ui,sans-serif;padding:2rem\">"
                b"<h1>Topical Bank + Booklet Builder</h1>"
                b"<p>The API is running. The frontend lands in Phase 3 (<code>static/index.html</code>)."
                b"</p><p>Try <a href='/api/health'>/api/health</a>, "
                b"<a href='/api/index'>/api/index</a>, <a href='/api/catalogue'>/api/catalogue</a>.</p>")


def _index_csv(payload: dict) -> str:
    import csv                                                      # noqa: PLC0415 (stdlib)
    import io                                                       # noqa: PLC0415
    buffer = io.StringIO()
    fields = ("id", "board", "code", "subject", "component", "session", "question_number", "topic",
              "status", "confidence", "marks", "listable", "layout")
    writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in payload.get("questions") or []:
        writer.writerow({key: row.get(key) for key in fields})
    return buffer.getvalue()

def make_server(host: str, port: int, app: App, handler=Handler, token: str = ""):
    handler.app = app
    httpd = ThreadingHTTPServer((host, port), handler)
    httpd.daemon_threads = True
    #: when set (``--token``), every mutating request must carry it; GETs stay open so the UI loads
    httpd.token = token
    return httpd


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--host", default="0.0.0.0", help="bind address (default 0.0.0.0)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--data-dir", default=str(ROOT), help="where index/overrides/draft/jobs live")
    ap.add_argument("--token", default="", help="require this token on mutating requests "
                                                "(for phones / a classroom LAN)")
    ap.add_argument("--root", action="append", default=[],
                    help="extra directory /files/ may serve from (repeatable)")
    ap.add_argument("--open", action="store_true", help="open the app in the default browser")
    args = ap.parse_args(argv)

    app = App(Path(args.data_dir), [Path(r) for r in args.root])
    httpd = make_server(args.host, args.port, app, token=str(args.token or ""))
    port = httpd.server_address[1]
    print(f"[server] Topical Bank + Booklet Builder on http://{args.host}:{port}  "
          f"(data dir {app.data_dir})")
    print(f"[server] file roots: {', '.join(str(r) for r in app.roots)}")
    print("[server] endpoints: /api/health /api/catalogue /api/detection /api/batch /api/jobs "
          "/api/index /api/overrides /api/draft /api/booklet /files/…")
    if args.open:
        try:
            webbrowser.open(f"http://127.0.0.1:{port}/")
        except Exception:                                          # noqa: BLE001
            pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[server] stopped")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
