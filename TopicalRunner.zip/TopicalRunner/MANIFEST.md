# MANIFEST — TopicalRunner slim runtime (built 2026-09-29)

Source: Universal_Exam_Topical_Generator at CLS-178h (run.bat is the ONE launcher: it starts the web app and carries the whole menu -- build, scan, index, booklet, clean+rebuild, validate, configs, demo, control menu; IB+SAT automatic on every run path; IB+SAT automatic on every run path; shipped input/ + output/ are the contract -- no folder prompt; per-question insert crops Q<n>_IN.webp + per-question ER detection Q<n>_ER.webp).
Method: precise AST import closure from the entry points
(`main`, `run_guarded`, `run_pipeline`, `server`, 9 runtime tools) +
dynamic adds (5 board adapters via pkgutil discovery, the
`original_reference/cambridge_qb` gold package, runtime data dirs).

## fetch-ectomy, ER attachment KEPT (17 surgical patches, dist copies only)
Patched files:
- `main.py`
- `run_guarded.py`
- `run_pipeline.py`
- `core/paper_identifier.py`
- `core/preflight.py`
- `core/batch_runner.py`
- `core/batch_manifest.py`

Deleted modules (exist in repo, absent here):
- `check_existing_ers`
- `core.er_fetcher`
- `core.examiner_report_gold`
- `core.ms_fetcher`
- `core.qp_fetcher`
- `list_missing_examiner_reports`
- `tools.download_examiner_reports`

Excluded runtime-unreachable non-test modules:
- `conftest`
- `core.config_gold`
- `core.converter_gold`
- `core.cropping_engine_reference`
- `core.mcq_support`
- `core.multipage_optimizer_reference`
- `core.paper_scan_gold`
- `core.pdf_io_gold`
- `core.reference_gold`
- `engine`
- `tests`
- `tools.ai_demo_row`
- `tools.aqa_alevel_maths_ms`
- `tools.aqa_alevel_ms_rows`
- `tools.aqa_alevel_reference`
- `tools.aqa_cs_profile`
- `tools.aqa_cs_reference`
- `tools.aqa_fixtures`
- `tools.aqa_gallery`
- `tools.aqa_literature_reference`
- `tools.aqa_maths_reference`
- `tools.aqa_spec_taxonomy`
- `tools.aqa_verdict_table`
- `tools.aqa_vocab_curation`
- `tools.archive.audit_crop_edges`
- `tools.archive.benchmark_classification_memory`
- `tools.archive.benchmark_scalability`
- `tools.archive.buff_categorization`
- `tools.archive.build_accounting_proof`
- `tools.archive.build_actual_accounting_proof`
- `tools.archive.build_classification_examples`
- `tools.archive.build_missing_configs`
- `tools.archive.build_run_report`
- `tools.archive.build_syllabus_index`
- `tools.archive.expand_vocabulary`
- `tools.archive.internet_categorizer`
- `tools.archive.live_dashboard`
- `tools.archive.manage_classification_memory`
- `tools.archive.migrate_major_topics`
- `tools.archive.mine_syllabus`
- `tools.archive.organize_examiner_reports`
- `tools.archive.pre_test_audit`
- `tools.archive.query_bank`
- `tools.archive.research.fetch_board_sources`
- `tools.archive.study_guide_generator`
- `tools.archive.validate_business_9609_memory`
- `tools.audit_associations`
- `tools.auto_band_report`
- `tools.bat_check`
- `tools.benchmark_workers`
- `tools.build_archive_proof`
- `tools.build_full_subject_catalog`
- `tools.build_label_template`
- `tools.build_source_tree_manifest`
- `tools.caie_corpus.build_proof`
- `tools.caie_corpus.download_caie`
- `tools.caie_corpus.rebuild_input`
- `tools.clean_output`
- `tools.cold_start_check`
- `tools.dependency_check`
- `tools.design_contract`
- `tools.download_fixtures`
- `tools.e2e_app_check`
- `tools.evaluate_topic_accuracy`
- `tools.export_accuracy_summary_csvs`
- `tools.fake_model_server`
- `tools.generate_subjects_catalogue`
- `tools.golden_set`
- `tools.launcher_check`
- `tools.make_fixture_papers`
- `tools.measure_render_estimate`
- `tools.patch_guard`
- `tools.profile_batch`
- `tools.profile_pipeline`
- `tools.quarantine_review`
- `tools.quarantine_reviewed_crops`
- `tools.render_topic_accuracy_dashboard`
- `tools.reset_state_papers`
- `tools.rtl_margin_recon`
- `tools.run_proof`
- `tools.run_with_log`
- `tools.selftest_app`
- `tools.selftest_html_check`
- `tools.static_wiring_check`
- `tools.sweep_suite`
- `tools.test_production_scenarios`
- `tools.tools_inventory`
- `tools.topic_accuracy_workflow`
- `tools.ui_dom_check`
- `tools.verify_ocr_engine`
- `universal`
- `universal.identity`
- `universal.identity.__main__`
- `universal.identity.evidence`
- `universal.identity.resolver`
- `universal.taxonomy`
- `universal.taxonomy.builder`
- `universal.taxonomy.extract_official`
- `universal.taxonomy.registry`
- `universal.taxonomy.versions`

Excluded data/dev trees: `tests/`, `fixtures/`, `papers/` (auto-created empty), `docs/`, `validation_evidence/`, `taxonomies/`, `topics/`, `tools/archive/`, `tools/caie_corpus/`, lock docs, proof outputs, ER bats.

ER handling in this build (local only, no network):
- `core/examiner_report.py` + `core/er_question_crops.py` are SHIPPED (CLS-178j):
  a Cambridge examiner report is parsed and attached to the question folders it
  belongs to. Restored after the user's IRL run found CAIE documents filed under AQA
  -- the shipped build could not detect a CAIE ER at all.
- Guarded stages S6 (ER attachment) and S7 (per-question ER crops) run for real.
- `core/paper_identifier.py` types ER PDFs; `core/preflight.py` reports them;
  `core/batch_manifest.py` pairs them (`unpaired_er` for a report with no bundle).
- ER output is CROPS ONLY (`Q<n>_ER.webp`, `<paper>_ER.webp`) -- the legacy
  `examiner_report.txt` writer is not called.
- Still absent: every fetcher and downloader, the `--fetch-*` flags, the ER fetch
  bookkeeping in preflight, and `core/examiner_report_gold.py` (test-only).
