"""Light validation for the verified multi-pass classification layer.

Run:  python tests/test_classification_engine.py      (pytest also works)

Checks only classification behaviour:
  * outputs are canonical topics of the subject (never invented/renamed)
  * malformed / empty / odd input never crashes and keeps a valid topic
  * an internal engine failure falls back to the untouched base result
  * disagreement between passes always triggers verification (no majority vote)
  * the downstream result format (ClassificationResult fields/types) is unchanged
  * decisions are deterministic
"""
from __future__ import annotations

import copy
import dataclasses
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core import classification_engine as engine  # noqa: E402
from core.classifier import ClassificationResult, TopicClassifier  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level  # noqa: E402

_CLF = {}


def _clf(code="9702", level="A-Level"):
    if (code, level) not in _CLF:
        cfg = load_subject_config_by_code_and_level(code, level, None)
        clf = TopicClassifier(cfg, classification_memory=None)
        clf._harvest_diagram_evidence = lambda _m: None  # no raster in these checks
        _CLF[(code, level)] = clf
    return _CLF[(code, level)]


def _mq(text, marks=1, fmt="MCQ", code="9702_s25_qp_12", num="Q1"):
    qp = SimpleNamespace(text=text, marks=marks, images=[], image=None, assembled_image=None)
    return SimpleNamespace(qp=qp, ms=None, ms_answer=None, variant="12", year=2025, season="s",
                           question_number=num, number_int=int("".join(c for c in num if c.isdigit()) or 0),
                           paper_format=fmt, full_qp_code=code)


PHYSICS = [
    "Light of wavelength 600 nm is incident normally on a diffraction grating. The second-order "
    "maxima are at an angle of 30 degrees. What is the number of lines per metre of the grating?",
    "A wire has resistivity 1.7 x 10-8 ohm m and cross-sectional area 2.0 mm2. What is its resistance?",
    "A ball is dropped from rest and falls through air. Which graph shows how its acceleration varies "
    "with time as it reaches terminal velocity?",
    "Which statement about the photoelectric effect is correct?",
    "A nucleus of uranium-235 undergoes alpha decay. What is the nucleon number of the daughter nucleus?",
]


def _check_result(res, clf):
    assert isinstance(res, ClassificationResult)
    assert isinstance(res.detailed_topics, list) and len(res.detailed_topics) <= 4
    if res.fallback_tier == "review_required" and not res.winning_major:
        # existing base routing for insufficient evidence; the engine must not touch it
        assert res.verification["status"] == "not_applicable", res.verification
        return
    assert res.winning_major in clf.config.major_topics, res.winning_major
    assert len(res.detailed_topics) >= 1
    assert isinstance(res.major_topic_scores, dict)
    assert isinstance(res.reasoning, str)
    assert isinstance(res.fallback_tier, str)


def test_canonical_topics_and_format():
    clf = _clf()
    fields = [f.name for f in dataclasses.fields(ClassificationResult)]
    for text in PHYSICS:
        res = clf.classify_question(_mq(text))
        _check_result(res, clf)
        # downstream format: exactly the dataclass fields, nothing added/removed
        assert [f.name for f in dataclasses.fields(res)] == fields
        assert "verification" not in dataclasses.asdict(res)
        rec = getattr(res, "verification", None)
        assert isinstance(rec, dict) and rec["engine"] == engine.ENGINE_VERSION


def test_malformed_inputs_never_crash():
    clf = _clf()
    odd = ["", "   ", None, "?!", "\u0000\ufffd\u2212\u00d7 ??", "A\nB\nC\nD",
           "x " * 20000, "What is the resistance? [3] (a) (b)(ii)"]
    for text in odd:
        mq = _mq(text, marks=None)
        res = clf.classify_question(mq)
        _check_result(res, clf)
    # structured / non-MCQ path and a mark scheme text
    res = clf.classify_question(_mq(PHYSICS[1], marks=4, fmt="STRUCTURED"), mark_scheme_text="R = rho L / A")
    _check_result(res, clf)


def test_engine_failure_keeps_base():
    clf = _clf()
    mq = _mq(PHYSICS[0])
    base = clf._classify_question_base(mq)
    real = engine._refine
    try:
        engine._refine = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        res = clf.classify_question(mq)
    finally:
        engine._refine = real
    assert res.winning_major == base.winning_major
    assert res.detailed_topics == base.detailed_topics
    assert res.verification["status"] == "error_kept_base"


def test_disagreement_triggers_verification():
    clf = _clf()
    mq = _mq(PHYSICS[1])  # clearly an electricity question
    base = clf._classify_question_base(mq)
    wrong = next(t for t in clf.config.major_topics if t != base.winning_major
                 and t in base.major_topic_scores)
    forged = copy.deepcopy(base)
    forged.winning_major = wrong  # pass A now disagrees with the independent passes
    res = engine.refine(clf, mq, forged)
    rec = res.verification
    assert rec["path"] and rec["path"][0] not in ("agreement", "agreement_with_abstention"), rec["path"]
    assert rec.get("verifications"), "disagreement must run pairwise verification"
    for v in rec["verifications"]:
        assert {"a", "b", "margin_a_over_b"} <= set(v)
    assert res.winning_major in clf.config.major_topics
    # every pass reports topic, competitors and scores
    for name, p in rec["passes"].items():
        assert {"topic", "competitors", "scores"} <= set(p), name


def test_agreement_is_cheap_and_unchanged():
    clf = _clf()
    for text in PHYSICS:
        mq = _mq(text)
        base = clf._classify_question_base(mq)
        res = clf.classify_question(mq)
        rec = res.verification
        if rec["path"] and rec["path"][0].startswith("agreement"):
            assert res.winning_major == base.winning_major
            assert "verifications" not in rec  # easy questions skip deep verification


def test_unreadable_script_keeps_base():
    """Subjects/questions in scripts the engine cannot read are left to the base scorer."""
    clf = _clf("9715")  # A-Level Mandarin: curated keywords are in Chinese
    mq = _mq("Explain how \u5bb6\u5ead relates to \u6211\u7684\u5bb6\u5ead. Describe \u5bb6\u4eba.",
             fmt="", code="9715_s25_qp_12")
    base = clf._classify_question_base(mq)
    res = clf.classify_question(mq)
    assert res.winning_major == base.winning_major
    assert res.verification["status"] == "not_applicable", res.verification
    clf = _clf()
    mq = _mq("\u0627\u0644\u0633\u0624\u0627\u0644 \u0627\u0644\u0623\u0648\u0644 \u0639\u0646 \u0627\u0644\u0645\u0648\u062c\u0627\u062a wave")
    res = clf.classify_question(mq)
    assert res.verification["status"] == "not_applicable", res.verification


def test_deterministic():
    clf = _clf()
    for text in PHYSICS:
        r1 = clf.classify_question(_mq(text))
        r2 = clf.classify_question(_mq(text))
        assert (r1.winning_major, r1.detailed_topics) == (r2.winning_major, r2.detailed_topics)


def test_trailing_option_heading_is_not_question_text():
    from core.classification_engine import strip_reference_material as strip
    q = "3 Assess the factors influencing tropical soil formation. [20]"
    tail = " Coastal environments If answering this option, answer Question 4 and either Question 5 or Question 6."
    assert strip(q + tail) == q
    lead = "Tropical environments If answering this option, answer Question 1. 1 Fig. 1.1 shows savanna vegetation."
    assert strip(lead) == lead          # a heading that opens the question belongs to it
    assert strip(q) == q


def test_normalize_arabic_repairs_rtl_extraction():
    from core.classification_engine import normalize_arabic
    assert normalize_arabic("\u0627\u0623\u0644\u0639\u0645\u0627\u0644") == "\u0627\u0644\u0623\u0639\u0645\u0627\u0644"
    assert normalize_arabic("\u0627\u0644\u0633\u0627\u0651\u0644\u0650\u0645") == "\u0627\u0644\u0633\u0644\u0627\u0645"
    assert normalize_arabic("Explain the term osmosis.") == "Explain the term osmosis."


def test_trailing_or_next_section_heading_is_stripped():
    from core.classification_engine import strip_reference_material as strip
    q = "3 Write a description of a busy market at the end of the day. [40]"
    assert strip(q + "\nOR\nNarrative writing\nDO NOT WRITE IN THIS MARGIN") == q
    assert strip(q) == q
    short = "OR\nNarrative writing"          # too close to the start: not a trailing heading
    assert strip(short) == short


def test_trailing_next_essay_title_is_stripped():
    from core.classification_engine import strip_reference_material as strip
    fr = "2 La police a un r\u00f4le impossible dans la soci\u00e9t\u00e9. Qu\u2019en pensez-vous ?"
    assert strip(fr + "\nL\u2019ordre public") == fr
    es = "1 Ser joven es dif\u00edcil. \u00bfComparte usted esta opini\u00f3n?"
    assert strip(es + "\nLa justicia y el orden p\u00fablico") == es
    zh = "1 \u4f60\u540c\u610f\u8fd9\u4e2a\u89c2\u70b9\u5417\uff1f\u8bf7\u8bf4\u660e\u4f60\u7684\u7406\u7531\u3002"
    assert strip(zh + "\n\u6c61\u67d3") == zh
    # genuine question endings are untouched
    keep = [
        "3 Explain why the rate of reaction increases. [3]",
        "4 Describe the graph.\nFigure 2 shows the results",           # digits: not a title
        "5 Discuss the view.\nThis line is far too long to be a heading at all here",
        "6 Outline two reasons. [4]\nTotal: 20 marks",
        "7 Analyse the poem\nThe Road",                                   # no sentence end before it
    ]
    for q in keep:
        assert strip(q) == q, q


def test_text_after_question_total_is_not_question_text():
    from core.classification_engine import strip_reference_material as strip
    q = "6 Explain two benefits of the new airport for the city. [4] [Total: 12]"
    assert strip(q + " DO NOT WRITE IN THIS MARGIN Exercise 2 Questions 7-15 Tourism") == q
    assert strip(q) == q
    # capture that starts with the previous question's tail: keep this question
    tail = "(c) Calculate the closing capital balance for the year. [4] [Total: 20]"
    own = " DO NOT WRITE IN THIS M 5 Rexford is a trader. All his sales are on credit. [5]"
    assert strip(tail + own, 5) == own.lstrip()
    assert strip(tail + own, 4) == tail                     # not this question's number
    hi = "6 \u0935\u093f\u092e\u093e\u0928 \u0938\u0947 \u0932\u093e\u092d? [1] [\u092a\u0942\u0923\u093e\u0154\u0915 8] \u0905\u092d\u094d\u092f\u093e\u0938 2"
    assert strip(hi).endswith("8]")


def test_devanagari_legacy_font_conjuncts_match_keywords():
    from core.classification_engine import normalize_devanagari
    from core.classifier import _keyword_pattern
    damaged = normalize_devanagari("\u0935\u093f\u0926\u0947\u0936\u0940 \u092a\u092f\u00c9\u091f\u0915 \u0930\u093e\u091c\u00c4\u0925\u093e\u0928")
    for kw in ("\u092a\u0930\u094d\u092f\u091f\u0915", "\u0930\u093e\u091c\u0938\u094d\u0925\u093e\u0928"):
        assert _keyword_pattern(kw).search(damaged), kw
        assert _keyword_pattern(kw).search(kw)                 # intact text still matches
    assert normalize_devanagari("Caf\u00e9 \u00c9vian") == "Caf\u00e9 \u00c9vian"


def test_urdu_visual_order_words_are_restored_from_keywords():
    from core.classification_engine import restore_urdu_visual_order as restore
    vocab = ["\u06a9\u0627\u0645", "\u062a\u0641\u0631\u06cc\u062d", "\u0627\u0641\u0633\u0627\u0646\u06c1"]
    scrambled = "\u0627\u0633 \u062f\u0648\u0631 \u06ba\u06cc\u0645 \u0627\u06a9\u0645 \u0627\u0648\u0631 \u0631\u0641\u062a\u062d\u06cc \u06ba\u06cc\u0645 \u0648\u062a\u0627\u0632\u0646"
    out = restore(scrambled, vocab)
    assert "\u06a9\u0627\u0645" in out and "\u062a\u0641\u0631\u06cc\u062d" in out
    normal = "\u0627\u0633 \u062f\u0648\u0631 \u0645\u06cc\u06ba \u06a9\u0627\u0645 \u0627\u0648\u0631 \u062a\u0641\u0631\u06cc\u062d"
    assert restore(normal, vocab) == normal                  # correctly ordered Urdu untouched
    arabic = "\u0639\u0645\u0644 \u0639\u0644\u0645 \u0645\u0644\u0639"
    assert restore(arabic, ["\u0639\u0644\u0645"]) == arabic   # Arabic never triggers


def test_zero_padded_component_numbers():
    from core.classifier import _paper_number_from_variant as pn
    assert pn("02") == 2 and pn("01") == 1
    assert pn("12") == 1 and pn("42") == 4 and pn("3") == 3 and pn("") == 0


def test_keyword_pattern_matches_inside_unspaced_scripts():
    from core.classifier import _keyword_pattern
    assert _keyword_pattern("\u7fbd\u6bdb\u7403").search("\u54e5\u54e5\u5728\u6253\u7fbd\u6bdb\u7403\u3002")
    assert _keyword_pattern("data").search("metadata") is None     # Latin word edges unchanged
    assert _keyword_pattern("data").search("the data shows")
    assert _keyword_pattern("carbon-13 nmr").search("Carbon 13 NMR spectrum")


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS {name}")
            except Exception as exc:  # report and continue
                failed += 1
                print(f"FAIL {name}: {type(exc).__name__}: {exc}")
    sys.exit(1 if failed else 0)


def test_exercise_passage_moves_to_its_questions():
    from types import SimpleNamespace as NS
    from core.classification_engine import apply_exercise_context, split_exercise_passage
    carrier = ("20 Georges a fete son anniversaire. [Total: 5] Exercice 2 Questions 21-29 "
               "Lisez le courriel d'Arthur: le club de recyclage au college.")
    own, found = split_exercise_passage(carrier, 20)
    assert "recyclage" not in own and found and found[0][:2] == (21, 29)
    mem = {}
    def q(n, text):
        return NS(qp=NS(text=text), number_int=n, full_qp_code="0520_s15_qp_22", variant="22", year="2015")
    v20 = apply_exercise_context(mem, q(20, carrier), q(20, carrier))
    assert "recyclage" not in v20.qp.text
    v23 = apply_exercise_context(mem, q(23, "23 Que fait le club?"), q(23, "23 Que fait le club?"))
    assert "recyclage" in v23.qp.text
    v30 = apply_exercise_context(mem, q(30, "30 Autre."), q(30, "30 Autre."))
    assert v30.qp.text == "30 Autre."
