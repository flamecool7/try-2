"""Golden regression tests for the CLS-310 fixes (2026-10-02).

Each test replays a real captured question that used to be misfiled, against
the committed subject configs, and asserts the winning major topic. Texts are
verbatim (trimmed) PDF extractions from the regression captures, including
their OCR artifacts — that is the point: the fixes must hold for exactly this
input.

Covered error classes:
  * soft paper gate (opt-in "paper_gate": "soft") — 0478 Q5: an out-of-paper
    major whose evidence dominates must survive the gate;
  * OCR-garbled function notation "( )x" — 0580 Q19 must route to
    Algebra_and_graphs, while genuine calculus questions with stray "( ) x"
    (0606 s15 Q8 shape) must NOT;
  * unicode hyphen variants (U+2011/U+2010) must normalize to plain hyphens;
  * AS / A Level syllabus-split keyword placement — 9708 externality and
    borrowing-requirement questions;
  * edition-specific configs — 9609 w24 uses the 2024-edition profile, whose
    Marketing topics need the "method of entry" evidence;
  * 9696 human-geography majors admitted to P1 + migration evidence;
  * 9706 incomplete-records questions stay Financial_statements.
"""
import re
from types import SimpleNamespace

import pytest

from core.config_loader import load_subject_config_by_code_and_level
from core.classifier import TopicClassifier, _normalize_text
from core.math_reference import _scrambled_function_evidence

_CLFS = {}


def _classify(code, level, year, variant, qn, text, marks, season="Summer"):
    key = (code, level, year)
    if key not in _CLFS:
        cfg = load_subject_config_by_code_and_level(code, level, year)
        _CLFS[key] = TopicClassifier(cfg, classification_memory=None)
    qp = SimpleNamespace(text=text, marks=marks, images=[], image=None,
                         assembled_image=None)
    stub = SimpleNamespace(qp=qp, ms=None, ms_answer=None, variant=variant,
                           year=year, season=season, question_number=qn,
                           number_int=int(re.sub(r"\D", "", qn) or 0),
                           paper_format="", full_qp_code=f"{code}_{season[0].lower()}{year[2:]}_qp_{variant}")
    return _CLFS[key].classify_question(stub, force_winner=True,
                                        mark_scheme_text="").winning_major


# ---------------------------------------------------------------------------
# core behaviour units
# ---------------------------------------------------------------------------
def test_non_breaking_hyphens_normalize():
    low, _ = _normalize_text("state\u2011transition diagram \u2010 done")
    assert "state-transition diagram - done" in low


def test_scrambled_function_evidence_positive():
    text = ("19 \n( )x\nx\n7\n8\nf\n=\n-     \n( )x\nx\n4\n5\ng\n=\n+     "
            "\n( )x\n2\n1\nh\nx\n=\n+\n \n(a) Find \n( )x\nf\n1\n-\n.")
    assert _scrambled_function_evidence(text)


def test_scrambled_function_evidence_ignores_vertical_calculus():
    # 0606 s15 Q8: vertical fractions under d/dx emit "( ) x" too, but there
    # is no "[fgh] =" definition shape — must NOT be treated as garbled
    # function notation.
    text = ("8 \n(i) Find \nx\n10e\ne\nd\nx\nx\n2\n2\n+\n-\n^\nh\ny\n. \n[2]\n "
            "\n(ii) Hence find \n(\n) x\n10e\ne\nd\nx\nx\nk\nk\n2\n2\n+\n-\n-y\n"
            " in terms of the constant k. \n[2]\n (iii) Given that \n(\n) x\n10"
            "\n60\ne\ne\nd\nx\nx\nk\nk\n2\n2\n+=\n-\n-\n-y\n, show that ...")
    assert not _scrambled_function_evidence(text)


# ---------------------------------------------------------------------------
# golden questions
# ---------------------------------------------------------------------------
def test_0478_soft_gate_keeps_dominant_boolean_question():
    # P1 paper_topics does not declare Boolean_logic; the gate must relax
    # because the boolean evidence dominates.
    text = ("5 \nConsider the following logic statement:\n"
            "X = ((A OR B) AND (NOT (B XOR C)) AND C)\n \n"
            "(a) Draw a logic circuit to represent the given logic statement.\n"
            "Do not attempt to simplify the logic statement. All logic gates "
            "must have a maximum of two inputs.\n"
            "(b) Complete the truth table for the given logic statement.\n"
            "A B C X\n0 0 0 0\n0 0 1 0\n0 1 0 0\n0 1 1 1\n1 0 0 0\n1 0 1 1\n"
            "1 1 0 0\n1 1 1 1")
    got = _classify("0478", "IGCSE", "2022", "12", "Q5", text, 9)
    assert got in {"Boolean_logic", "Hardware"}


def test_0580_garbled_functions_route_to_algebra():
    text = ("19 \n( )x\nx\n7\n8\nf\n=\n-     \n( )x\nx\n4\n5\ng\n=\n+     "
            "\n( )x\n2\n1\nh\nx\n=\n+\n \n(a) Find \n( )x\nf\n1\n-\n.\n "
            "\n( )x\nf\n1\n=\n-\n  ................................................  [2]\n "
            "\n(b) Find the value of x when ( )x\n3\n1\nh\ng\n=\ne o.\n "
            "\nx =  ................................................  [2]")
    assert _classify("0580", "IGCSE", "2022", "22", "Q19", text, 4) == "Algebra_and_graphs"


def test_9609_w24_entry_mode_routes_to_marketing():
    # Uses the 2024-edition Business profile (year-scoped config).
    text = ("2 \nAnalyse two factors influencing HCC\u2019s method of entry "
            "into international markets.\n "
            + "." * 200)
    assert _classify("9609", "A-Level", "2024", "32", "Q2", text, 8,
                     season="Winter") == "Marketing"


def test_9696_migration_question_beats_stray_settlement_heading():
    # The crop ends with a stray "Settlement dynamics" section heading; the
    # migration evidence must still win. Human majors are admitted on P1.
    text = ("5 \nFigs 4A and 4B show the five largest foreign-born (immigrant) "
            "groups in USA and Australia in 2001.\n \n"
            "(a) Using the information in Figs 4A and 4B, compare the pattern "
            "of immigration in Australia and USA. \n[3]\n \n"
            "(b) Describe one way that governments of receiving countries can "
            "affect immigration. \n[2]\n \n"
            "(c) Describe and explain the possible impacts of immigration on "
            "the receiving countries. \n[5]\nSettlement dynamics")
    assert _classify("9696", "A-Level", "2011", "12", "Q5", text, 10) == "Core_Human_Migration"


def test_9706_incomplete_records_stays_financial_statements():
    text = ("1 \nKhalid owns a wholesale business selling electrical goods. He "
            "does not keep proper books of account, but is able to provide the "
            "following information.\nBalances at 1 January 2014 $\n"
            "Motor vehicle at cost 38 400\nMotor vehicle provision for "
            "depreciation 12 600\nFixtures and fittings at cost 41 940\n"
            "Trade receivables 26 610\nTrade payables 19 920\nInventory 33 500\n"
            "Prepayment of two months\u2019 property rental 3 750\n"
            "General expenses accrued 410\nCash in hand 360\n"
            "Summary of bank account for the year ended 31 December 2014\n"
            "Payments to credit suppliers 134 750\nReceipts from credit "
            "customers 200 270\nDrawings 22 100")
    assert _classify("9706", "A-Level", "2015", "22", "Q1", text, 5) == "Financial_statements"


def test_9708_as_externality_table_routes_to_gov_micro_as():
    text = ("13 The table shows some of the costs and benefits at a given "
            "level of production of a good. \n \ncosts $m benefits $m\n"
            "private 80 private 90\nsocial 200 external 100\n \n"
            "What is correct at this level of production?\nA External benefits "
            "exceed external costs.\nB Private benefits exceed external costs.\n"
            "C Private costs exceed social benefits.\nD Social costs exceed "
            "social benefits.")
    got = _classify("9708", "A-Level", "2011", "12", "Q13", text, 0)
    assert got in {"Government_microeconomic_intervention_AS",
                   "The_price_system_and_the_microeconomy_AS"}


def test_9708_as_cost_benefit_analysis_routes_to_gov_micro_as():
    text = ("15 What is an advantage, rather than a disadvantage, of "
            "cost-benefit analysis in deciding on a government investment "
            "project?\nA Economic agents place different values on external "
            "costs and external benefits.\nB Estimates of external costs and "
            "external benefits are included.\nC Forecasts of future costs and "
            "benefits vary over time.\nD Miscalculations of the costs are "
            "financed by the taxpayer.")
    assert _classify("9708", "A-Level", "2011", "12", "Q15", text, 0) == \
        "Government_microeconomic_intervention_AS"


def test_9708_borrowing_requirement_routes_to_gov_macro():
    text = ("24 The diagram shows a government\u2019s revenue and expenditure "
            "for three years.\n2008 revenue expenditure\n2009 revenue "
            "expenditure\n2010 revenue expenditure\n$m\n \n \n"
            "What can be concluded from the diagram?\n"
            "A A budget deficit was replaced by a budget surplus.\n"
            "B A government borrowing requirement emerged.\n"
            "C The economy moved from a recession into a boom period.\n"
            "D The yield from taxation continuously increased.")
    assert _classify("9708", "A-Level", "2011", "32", "Q24", text, 0) == \
        "Government_macroeconomic_intervention_A_Level"
