"""B6 cropper fixes: section headings, numbered passages, trailing pages, stimulus starts."""
import fitz

from core import vector_first_cropper as vc
from core.vector_first_cropper import Marker

DOTS = "." * 120


def _m(number, page, y, text=None):
    return Marker(number=number, page=page, y0=y - 9, y1=y + 2, x0=50,
                  text=text or f"{number} Question text", score=1.0, reason="test")


def _page(doc, rows):
    page = doc.new_page(width=595, height=842)
    for x, y, text in rows:
        page.insert_text((x, y), text, fontsize=10)
    return page


def test_section_heading_needs_a_real_heading():
    r = vc.SECTION_HEADING_RE
    for t in ["Section A", "SECTION B", "Section 3", "Section C: Devised piece",
              "Section B Read the following passage", "DOCUMENT 1",
              "Answer one question from this section."]:
        assert r.match(t), t
    for t in ["section is from 300380 to 330380", "section Y.", "Section X of the journey"]:
        assert not r.match(t), t


def test_answer_lines_page_is_trailing_admin():
    doc = fitz.open()
    _page(doc, [(60, 120 + 26 * i, DOTS) for i in range(20)])
    assert vc._page_is_trailing_admin(doc[0])


def test_low_final_mark_keeps_answer_page():
    # 0457/0478: the last answer page ends with the question total near the footer
    doc = fitz.open()
    _page(doc, [(60, 120 + 26 * i, DOTS) for i in range(24)] + [(520, 780, "[24]")])
    assert not vc._page_is_trailing_admin(doc[0])


def test_part_label_line_keeps_page():
    # 9626: '(b) Rootkit ......' is a sub-part, not furniture
    doc = fitz.open()
    _page(doc, [(60, 120, "(b) Rootkit " + DOTS)] + [(60, 150 + 26 * i, DOTS) for i in range(10)])
    assert not vc._page_is_trailing_admin(doc[0])


def test_graph_page_keeps_page():
    # 9715: a grid drawn as many thin strokes is content
    doc = fitz.open()
    page = _page(doc, [])
    for i in range(11):
        page.draw_line((100 + 30 * i, 200), (100 + 30 * i, 500), width=0.3)
        page.draw_line((100, 200 + 30 * i), (400, 200 + 30 * i), width=0.3)
    assert not vc._page_is_trailing_admin(doc[0])


def _passage_doc(with_marks=True):
    doc = fitz.open()
    mk = lambda s: s if with_marks else ""
    _page(doc, [(50, 120, "1 Explain the first claim."), (520, 160, mk("[2]")),
                (50, 300, "2 Explain the second claim."), (520, 340, mk("[3]"))])
    _page(doc, [(50, 120, "1 It is often said that cities grow."),
                (50, 200, "2 Many people move for work."),
                (50, 280, "3 Some return home later.")])
    _page(doc, [(50, 120, "3 Evaluate the passage."), (520, 160, mk("[6]"))])
    markers = [_m(1, 0, 120), _m(2, 0, 300), _m(1, 1, 120), _m(2, 1, 200), _m(3, 1, 280), _m(3, 2, 120)]
    return doc, markers


def test_numbered_passage_is_dropped():
    doc, markers = _passage_doc()
    kept = vc._drop_numbered_passages(doc, markers)
    assert [(m.number, m.page) for m in kept] == [(1, 0), (2, 0), (3, 2)]


def test_numbered_passage_guard_skips_papers_without_marks():
    doc, markers = _passage_doc(with_marks=False)  # MCQ-style: no '[n]' anywhere
    assert vc._drop_numbered_passages(doc, markers) == markers


def test_stimulus_page_opens_next_group():
    # 0510 P1: 'Exercise 2' + reading text sit on the page before question 2
    doc = fitz.open()
    _page(doc, [(50, 120, "1 What does the writer say?"), (520, 160, "[1]")])
    _page(doc, [(50, 100, "Exercise 2"), (50, 140, "Read the article about underground homes."),
                (50, 180, "Many families now live below ground.")])
    _page(doc, [(50, 120, "2 Complete the notes."), (520, 160, "[4]")])
    q1, q2 = _m(1, 0, 120), _m(2, 2, 120)
    first = vc.segment_for_marker(doc, q1, q2, None)
    second = vc.segment_for_marker(doc, q2, None, q1)
    assert all(seg.page == 0 for seg in first)
    assert second[0].page == 1 and second[0].y0 < 100
    assert vc.segment_for_marker(doc, q2, None)[0].page == 2  # old call style unchanged


def test_heading_marker_is_not_its_own_group_heading():
    doc = fitz.open()
    page = _page(doc, [(50, 100, "Exercise 3"), (50, 140, "Read the text."), (50, 400, "Exercise 4")])
    assert vc._group_heading_y(page, _m(4, 0, 400, text="Exercise 4")) is None


def test_context_line_regex():
    assert vc._CONTEXT_LINE_RE.match("You will hear a talk about bees.")
    assert vc._CONTEXT_LINE_RE.match("You hear two friends talking.")
    assert not vc._CONTEXT_LINE_RE.match("Your answer should be brief.")
