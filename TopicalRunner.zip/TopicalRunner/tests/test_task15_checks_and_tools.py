"""Task 15 (2026-10-01): run checks, page-bottom content, ER/OCR evidence,
index-page duplicates and the run-report output contract."""
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))


def _cover_pdf(path, lines):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=A4)
    y = 700
    for text in lines:
        c.setFont("Helvetica", 11); c.drawString(60, y, text); y -= 20
    c.showPage(); c.save()


# ---------------------------------------------------------------- P3 checks
def test_question_marks_total_wins_else_sum():
    from core.run_report import question_marks
    assert question_marks("(a) ... [2]\n(b) ... [3]") == 5
    assert question_marks("(a) [2] (b) [3] (c) [3]\n[Total: 8]") == 8
    assert question_marks("no marks printed") == 0


def test_paper_checks_ok_mismatch_and_count(tmp_path):
    from core.run_report import paper_checks
    pdf = tmp_path / "qp.pdf"
    _cover_pdf(pdf, ["Answer all questions.", "The total mark for this paper is 10."])
    q = lambda n, t: SimpleNamespace(question_number=f"Q{n}", text=t)
    ok = paper_checks(pdf, [q(1, "[4]"), q(2, "[6]")], ms_count=2)
    assert ok["mark_check"].startswith("ok (10/10)") and ok["flags"] == []
    bad = paper_checks(pdf, [q(1, "[4]"), q(2, "[5]")], ms_count=3)
    assert bad["mark_check"].startswith("MISMATCH")
    assert any(f.startswith("mark_total_mismatch") for f in bad["flags"])
    assert any(f.startswith("question_count_mismatch") for f in bad["flags"])
    # a question without printed [N] marks -> never flagged on marks
    skip = paper_checks(pdf, [q(1, "[4]"), q(2, "essay")], ms_count=2)
    assert skip["mark_check"].startswith("not checked") and skip["flags"] == []


def test_run_report_keeps_flags_out_of_question_folders(tmp_path):
    from core.run_report import write_paper_record, build_reports
    qdir = tmp_path / "IGCSE" / "Physics_0625" / "paper-4" / "Waves" / "42_Summer_2024_Q5"
    qdir.mkdir(parents=True)
    (qdir / "metadata.json").write_text("{}")
    write_paper_record(tmp_path, "0625_s24_42", {
        "subject": "Physics_0625", "checks": {"flags": ["mark_total_mismatch: x"], "mark_check": "MISMATCH"},
        "questions": [{"q": "Q5", "folder": str(qdir.relative_to(tmp_path)), "topic": "Waves"}]})
    build_reports(tmp_path, [])
    assert (tmp_path / "run_report.html").exists() and (tmp_path / "qa_gallery.html").exists()
    flags = json.loads((tmp_path / ".run_report" / "flags.json").read_text())
    assert flags and flags[0]["paper"] == "0625_s24_42"
    assert sorted(p.name for p in qdir.iterdir()) == ["metadata.json"]   # output contract


def test_run_report_dir_is_not_an_orphan(tmp_path):
    from core.validation import FinalValidator
    rec = tmp_path / ".run_report" / "papers" / "0625_s24_42.json"
    rec.parent.mkdir(parents=True)
    rec.write_text("{}")
    (tmp_path / "worksheets").mkdir()
    (tmp_path / "worksheets" / "x.json").write_text("{}")
    try:
        FinalValidator(output_root=str(tmp_path)).validate_all()
    except Exception:
        pass
    assert rec.exists() and (tmp_path / "worksheets" / "x.json").exists()


# ------------------------------------------------------- page-bottom content
def test_last_line_just_above_footer_is_kept(tmp_path):
    import fitz
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from core.vector_first_cropper import page_body_bottom
    pdf = tmp_path / "p.pdf"
    h = A4[1]
    c = canvas.Canvas(str(pdf), pagesize=A4)
    c.setFont("Helvetica", 11)
    c.drawString(60, 400, "1 Some question text")
    c.drawString(530, h - 791, "[3]")                 # straddles the old 94% cut
    c.setFont("Helvetica", 9)
    c.drawString(50, h - 804, "\u00a9 UCLES 2024"); c.drawString(270, h - 804, "9618/22/M/J/24")
    c.drawString(490, h - 804, "[Turn over")
    c.showPage(); c.save()
    with fitz.open(pdf) as doc:
        page = doc[0]
        y3 = [w for w in page.get_text("words") if w[4] == "[3]"][0]
        foot = min(w[1] for w in page.get_text("words") if w[4] in ("[Turn", "UCLES"))
        bottom = page_body_bottom(page)
    assert bottom >= y3[3] - 0.5          # the whole "[3]" is inside the body
    assert bottom <= foot + 0.01          # the printed footer is not


# ---------------------------------------------------------- P4 ER evidence
def test_er_lookup_prefers_component_report(tmp_path):
    from core.er_evidence import find_er_pdf, text_for
    (tmp_path / "0625_s24_er.pdf").write_bytes(b"%PDF-1.4")
    assert find_er_pdf("0625_s24_qp_42", tmp_path).name == "0625_s24_er.pdf"
    (tmp_path / "0625_s24_er_42.pdf").write_bytes(b"%PDF-1.4")
    assert find_er_pdf("0625_s24_qp_42", tmp_path).name == "0625_s24_er_42.pdf"
    assert find_er_pdf("0625_w24_qp_42", tmp_path) is None
    assert text_for({"3": "moments"}, "Q3") == "moments" and text_for({}, "Q3") == ""


# ------------------------------------------------------ idea 13 OCR trigger
def test_ocr_trigger_only_for_junk_non_latin_text():
    from core.ocr_text import expected_script, script_share, tesseract_lang, maybe_ocr_questions
    assert expected_script(["خاندان", "والدین"]) == "arabic"
    assert expected_script(["परिवार"]) == "devanagari"
    assert expected_script(["force", "energy"]) is None
    assert script_share("»Ɔ Ñ ë± æ Ƅ", "arabic") < 0.25
    assert script_share("میرا خاندان", "arabic") > 0.9
    assert tesseract_lang("arabic", "Urdu_9686") == "urd"
    assert tesseract_lang("arabic", "Arabic_0544") == "ara"
    latin = SimpleNamespace(classification_keywords={"Waves": ["wave"]}, subject="Physics")
    m = SimpleNamespace(qp=SimpleNamespace(text="a wave", pages=[1]))
    assert maybe_ocr_questions([m], "/nonexistent.pdf", latin, log=lambda *_: None) == 0
    assert m.qp.text == "a wave"


# ------------------------------------------- idea 19 cross-variant duplicates
def test_cross_variant_duplicates(tmp_path):
    from PIL import Image, ImageDraw
    from build_index_page import find_duplicates

    def crop(name, seed):
        im = Image.new("RGB", (600, 800), "white")
        d = ImageDraw.Draw(im)
        for i in range(12):
            y = 30 + i * 60
            d.rectangle((40, y, 40 + ((i * 37 + seed * 101) % 480), y + 20), fill="black")
        p = tmp_path / name
        im.save(p)
        return str(p)

    rows = [
        {"id": "0625_s24|41|Q1", "code": "0625", "session": "s24", "component": "0625/41",
         "artifacts": {"qp": [crop("a.png", 1)]}},
        {"id": "0625_s24|43|Q1", "code": "0625", "session": "s24", "component": "0625/43",
         "artifacts": {"qp": [crop("b.png", 1)]}},      # same question, other variant
        {"id": "0625_s24|43|Q2", "code": "0625", "session": "s24", "component": "0625/43",
         "artifacts": {"qp": [crop("c.png", 7)]}},      # different question
    ]
    dup = find_duplicates(tmp_path, rows)
    assert dup.get("0625_s24|41|Q1") == ["0625_s24|43|Q1"]
    assert "0625_s24|43|Q2" not in dup


def test_check_me_lists_close_calls_only(tmp_path):
    import json
    from core import run_report as rr
    aud = tmp_path / ".classification_audit"
    aud.mkdir()
    recs = [
        {"paper": "9702_s24_22", "question_number": "Q4", "assigned_topic": "Work",
         "confidence": 0.3, "major_scores": {"Work": 144.8, "Deformation": 138.6, "Dynamics": 48.7},
         "output_folder": str(tmp_path / "A-Level/P/paper-2/Work/22_Summer_2024_Q4")},
        {"paper": "9702_s24_22", "question_number": "Q5", "assigned_topic": "Waves",
         "confidence": 0.9, "major_scores": {"Waves": 200.0, "Dynamics": 20.0}},
        {"paper": "9702_s24_22", "question_number": "Q6", "assigned_topic": "Dynamics",
         "confidence": 0.6, "major_scores": {"Kinematics": 100.0, "Dynamics": 95.0}},
    ]
    (aud / "9702_s24_22.jsonl").write_text("\n".join(json.dumps(r) for r in recs), encoding="utf-8")
    got = {c["question"]: c for c in rr.check_me(tmp_path)}
    assert set(got) == {"Q4", "Q6"}
    assert got["Q4"]["runner_up"] == "Deformation"
    assert got["Q4"]["folder"] == "A-Level/P/paper-2/Work/22_Summer_2024_Q4"
    assert got["Q6"]["runner_up"] == "Kinematics"   # filed topic is never its own runner-up
    rr.build_reports(tmp_path)
    assert (tmp_path / ".run_report" / "check_me.json").exists()
    assert "close topic calls" in (tmp_path / "run_report.html").read_text(encoding="utf-8")
