"""B7-listening: exercise-block pooling gives weak one-liners sibling evidence."""
from types import SimpleNamespace

from core.classification_engine import (apply_exercise_context, block_pool_view,
                                        split_exercise_passage)


def _view(text):
    return SimpleNamespace(qp=SimpleNamespace(text=text))


def _q(num, code="0525_s25_qp_12"):
    return SimpleNamespace(number_int=num, full_qp_code=code, variant="12", year="2025")


def test_header_question_stores_block_and_siblings_pool():
    mem = {}
    # Q8 carries the next exercise's instruction header (as on real papers).
    v8 = apply_exercise_context(mem, _q(8), _view(
        "8 Was macht Sonja jetzt? A B C D\nFragen 9-14 Sie hören jetzt zweimal eine "
        "Radiosendung über die Gartenschau 2025."))
    assert v8.qp.text.startswith("8 Was macht")  # header cut from own text
    # Siblings register their own wording into the block.
    apply_exercise_context(mem, _q(9), _view("9 Wo ist das Problem im Garten?"))
    apply_exercise_context(mem, _q(10), _view("10 Die Einwohner pflanzen Blumen."))
    weak = _view("11 Wo ist es schön?")
    pooled = block_pool_view(mem, _q(11), weak)
    assert pooled is not weak
    assert "Gartenschau" in pooled.qp.text and "Einwohner" in pooled.qp.text
    assert "11 Wo ist es schön?" in pooled.qp.text


def test_no_block_returns_same_view():
    mem = {}
    v = _view("3 Simple one-liner without any exercise header.")
    apply_exercise_context(mem, _q(3), v)
    assert block_pool_view(mem, _q(3), v) is v


def test_split_exercise_passage_cuts_later_ranges():
    own, found = split_exercise_passage(
        "8 x\nFragen 9-14 Sie hören eine Radiosendung über die Gartenschau.", 8)
    assert found and found[0][0] == 9 and found[0][1] == 14
    assert "Gartenschau" not in own
