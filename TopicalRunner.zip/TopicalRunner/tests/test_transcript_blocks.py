"""Transcript (<series>_qr_<var>.pdf) exercise-block parsing, all header grammars."""
import fitz

from core.transcript_text import find_transcript, parse_transcript_text, transcript_blocks


def _mk(path, body):
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    y = 100
    for line in body:
        page.insert_text((50, y), line, fontsize=10)
        y += 30
    doc.save(str(path))
    return path


def test_german_and_french_and_spanish_headers(tmp_path):
    pdf = _mk(tmp_path / "t_qr_12.pdf", [
        "Fragen 1-8 Sie hören jetzt einige Bemerkungen.",
        "Khaled begegnet Sonja in der Stadt.",
        "Questions 9 à 15 Maintenant vous écoutez une émission.",
        "Preguntas 16 a 20 Ahora escucha una conversación.",
    ])
    blocks = transcript_blocks(pdf)
    assert [(a, b) for a, b, _ in blocks] == [(1, 8), (9, 15), (16, 20)]
    assert "Sonja" in blocks[0][2] and "émission" in blocks[1][2]


def test_chinese_and_arabic_headers():
    text = ("问题1至5 现在你听到一段对话。\n"
            "问题6至10 现在你听到一个广播。\n"
            "16-11 الأسئلة من  الآن استمع\n")
    ranges = [(a, b) for a, b, _ in parse_transcript_text(text)]
    assert (1, 5) in ranges and (6, 10) in ranges and (11, 16) in ranges


def test_find_transcript_naming(tmp_path):
    (tmp_path / "0525_s25_qr_12.pdf").write_bytes(b"%PDF-1.4 fake")
    assert find_transcript(tmp_path, "0525_s25_qp_12").name == "0525_s25_qr_12.pdf"
    assert find_transcript(tmp_path, "0525_s25_qp_22") is None
    assert find_transcript(None, "0525_s25_qp_12") is None
