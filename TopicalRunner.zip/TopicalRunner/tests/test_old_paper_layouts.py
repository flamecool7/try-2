"""Old-paper layouts: Exercise-heading papers (engine #4) and short one-line questions."""
from pathlib import Path
from types import SimpleNamespace

import fitz
from PIL import Image

from core import exercise_heading_engine as ex


def _exercise_pdf(path: Path, n: int = 3, numbered: bool = False) -> Path:
    doc = fitz.open()
    for i in range(1, n + 1):
        page = doc.new_page(width=595, height=842)
        page.insert_text((50, 80), f"Exercise {i}", fontsize=12)
        page.insert_text((50, 120), "Read the article and answer the questions.", fontsize=11)
        page.insert_text((50, 160), "(a) What does the writer say about the town?", fontsize=11)
        page.insert_text((500, 200), "[1]", fontsize=11)
        if numbered:
            page.insert_text((50, 240), f"{i}  This paper also has numbered questions.", fontsize=11)
    doc.save(str(path))
    return path


def test_exercise_headings_detected(tmp_path):
    pdf = _exercise_pdf(tmp_path / "0510_s11_qp_12.pdf", n=3)
    ok, why = ex.should_handle(pdf)
    assert ok, why
    with fitz.open(str(pdf)) as doc:
        selected, _ = ex.exercise_markers(doc)
    assert [m.number for m in selected] == [1, 2, 3]
    assert [m.page for m in selected] == [0, 1, 2]


def test_exercise_engine_crops_each_exercise(tmp_path):
    pdf = _exercise_pdf(tmp_path / "0510_s11_qp_12.pdf", n=3)
    crops = ex.crop_exercise_paper(pdf, spool_dir=tmp_path / "spool", paper_code="0510_s11_qp_12")
    assert [c.question_number for c in crops] == ["Q1", "Q2", "Q3"]
    for c in crops:
        assert "Exercise" in c.text
        assert Path(c._spool_png).exists()
        assert Image.open(c._spool_png).width > 0


def test_single_heading_is_not_a_sequence(tmp_path):
    pdf = _exercise_pdf(tmp_path / "x_qp_12.pdf", n=1)
    ok, _ = ex.should_handle(pdf)
    assert not ok


def test_one_liner_rule_needs_mark_allocation():
    import run_guarded as rg
    img = Image.new("RGB", (2280, 76), "white")
    good = SimpleNamespace(text="1  Identify two features of the costumes in the extract. [2]")
    truncated = SimpleNamespace(text="1  Identify two features of the costumes in the")
    assert rg._is_complete_one_liner(good, img)
    assert not rg._is_complete_one_liner(truncated, img)
    assert not rg._is_complete_one_liner(good, Image.new("RGB", (2280, 30), "white"))


def test_qp_sequence_skips_indented_numbered_list():
    """0452_s15_qp_12: notes 1-5 (x=71) inside Q4 must not replace Q5, and
    the inner 1..N list starting mid-paper must not beat the real sequence."""
    from core.vector_first_cropper import Marker, select_qp_sequence

    def mk(number, page, x0, y0, score):
        return Marker(number=number, page=page, y0=y0, y1=y0 + 10, x0=x0, text=str(number), score=score, reason='test')

    real = [mk(1, 1, 50, 130, 1.0), mk(2, 5, 50, 64, 1.0), mk(3, 7, 50, 64, 1.0),
            mk(4, 10, 50, 64, 1.0), mk(5, 13, 50, 64, 1.0), mk(6, 15, 50, 64, 1.0)]
    notes = [mk(1, 8, 71, 260, 1.1), mk(2, 10, 71, 469, 1.1), mk(3, 10, 71, 520, 1.1),
             mk(4, 10, 71, 545, 1.1), mk(5, 10, 71, 671, 1.1)]
    chosen = select_qp_sequence(real + notes)
    assert [(m.number, m.page, m.x0) for m in chosen] == [(m.number, m.page, m.x0) for m in real]


# --- era-2015 failure fixes ------------------------------------------------
def test_pre2020_math_folders_accepted_by_audit():
    from core.math_reference import folder_topics_for_subject_paper as f
    assert "Vectors" in f("9709", 1)                       # old P1 had vectors
    assert "Probability" in f("9709", 6)                   # old P6 = Stats 1
    assert "The_Poisson_distribution" in f("9709", 6)      # current P6 kept
    assert "Integration" in f("9231", 1)                   # old P1 = sections 1+2


def test_qp_sequence_prefers_consistent_label_column():
    from core.vector_first_cropper import Marker, select_qp_sequence
    def m(n, page, y, x, score):
        return Marker(number=n, page=page, y0=y, y1=y + 12, x0=x, text=str(n),
                      score=score, reason="t")
    marks = [m(1, 1, 63, 50, 1.1)] + [m(k, 1, 400 + 40 * k, 61, 1.15) for k in (1, 2, 3, 4)]
    marks += [m(k, p, 63, 50, 1.1) for k, p in ((2, 3), (3, 8), (4, 11), (5, 13), (6, 16))]
    seq = select_qp_sequence(marks)
    assert [(s.number, s.x0) for s in seq] == [(k, 50) for k in range(1, 7)]


def test_question_heading_span_matches_whole_heading():
    from core.legacy_ms_split import _QUESTION_HEADING_SPAN
    assert _QUESTION_HEADING_SPAN.match("Question 3").group(1) == "3"
    assert not _QUESTION_HEADING_SPAN.match("Question 3, scoris will")


# --- exit-2 fixes: components that changed format, MS table grammars ------
def test_mcq_status_is_year_aware():
    from core.mcq_registry import is_mcq
    assert is_mcq("0452", "12", "2022") and not is_mcq("0452", "12", "2015")
    assert is_mcq("0620", "21", "2016") and not is_mcq("0620", "21", "2015")
    assert is_mcq("0654", "22", "2018") and not is_mcq("0654", "22", "2016")
    assert is_mcq("0620", "11", "2011")            # Paper 1 always MCQ
    assert is_mcq("0452", "12")                     # no year -> current syllabus


def test_paper_format_from_filename_uses_session_year():
    from core.paper_identifier import parse_paper_filename
    assert parse_paper_filename("0452_s15_qp_12.pdf").paper_format == "STRUCTURED"
    assert parse_paper_filename("0452_s22_qp_12.pdf").paper_format == "MCQ"
    assert parse_paper_filename("0610_s11_qp_21.pdf").paper_format == "STRUCTURED"
    assert parse_paper_filename("0610_s16_qp_21.pdf").paper_format == "MCQ"


def test_ms_row_rule_must_sit_directly_above_label():
    from core.markscheme_split_gold import MSLabel, _row_top_rule
    lab = MSLabel(page_index=0, y0=200.0, y1=210.0, question_number=31, text="31", x0=75.0)
    assert _row_top_rule([150.0, 192.0], lab, 100.0) == 192.0     # table row
    assert _row_top_rule([150.0], lab, 100.0) is None              # heading, no rule


def test_er_question_headings_with_part_ranges_and_colons():
    from core.examiner_report import QUESTION_HEADER_PATTERNS
    full = QUESTION_HEADER_PATTERNS[0][1]
    for heading in ("Question 1 (a – e)", "Question 6 (a-i)", "Question 2:", "Question 4 (a)(i)", "Question 3"):
        assert full.match(heading), heading
    for prose in ("Question 4e (saying just", "Question 1 and 2 in the role-play", "Question 2a and Question 2b"):
        assert not full.match(prose), prose


def test_er_closing_heading_ends_only_the_last_question():
    from core.er_question_crops import _section_boundary_in_segment
    lines = [[(100.0, "Question 3", [10.0]), (300.0, "Conclusion", [10.0]), (320.0, "text", [10.0])]]
    assert _section_boundary_in_segment(lines, 0, 100.0, 0, 800.0, last=True) == (0, 300.0)
    assert _section_boundary_in_segment(lines, 0, 100.0, 0, 800.0) is None


def test_er_closing_heading_ignores_wrapped_prose_word():
    from core.er_question_crops import _section_boundary_in_segment
    lines = [[(100.0, "Question 3", [10.0]), (300.0, "conclusion", [10.0])]]
    assert _section_boundary_in_segment(lines, 0, 100.0, 0, 800.0, last=True) is None


def test_er_conclusions_subheading_inside_question_is_kept():
    from core.er_question_crops import _section_boundary_in_segment
    lines = [[(100.0, "Question 2", [10.0]), (300.0, "Conclusions", [10.0]),
              (320.0, "(e) Most candidates knew that", [10.0])]]
    assert _section_boundary_in_segment(lines, 0, 100.0, 0, 800.0, last=True) is None


def test_9708_paper3_is_mcq_every_year():
    from core.mcq_registry import is_mcq, get_expected_question_count
    for year in ("2011", "2015", "2019", "2023"):
        assert is_mcq("9708", "32", year)
    assert not is_mcq("9708", "42", "2023") and not is_mcq("9708", "22", "2023")
    assert get_expected_question_count("9708", "31") == 30


def test_control_center_universal_batch_has_no_undefined_names():
    import subprocess, sys
    out = subprocess.run([sys.executable, "-m", "pyflakes", "core/control_center.py"],
                         capture_output=True, text=True).stdout
    assert "undefined name" not in out, out


def test_either_or_literature_labels():
    from core.vector_first_cropper import LITERATURE_ALT_STEM_RE, LITERATURE_ALT_WORD_RE
    assert LITERATURE_ALT_STEM_RE.match("Either * 1").group("number") == "1"
    assert LITERATURE_ALT_STEM_RE.match("Or \u2020 10").group("number") == "10"
    assert LITERATURE_ALT_STEM_RE.match("Or 18 How does Narayan").group("number") == "18"
    assert not LITERATURE_ALT_STEM_RE.match("Or else my sword with an unbattered edge")
    assert not LITERATURE_ALT_STEM_RE.match("or 2 more")
    assert LITERATURE_ALT_WORD_RE.match("Either") and not LITERATURE_ALT_WORD_RE.match("Either way")


def _pdf(path, pages):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(str(path), pagesize=A4)
    for lines in pages:
        y = 700
        c.setFont("Helvetica", 9); c.drawString(50, 815, "0000/12 Cambridge IGCSE - Mark Scheme")
        for text, bold in lines:
            c.setFont("Helvetica-Bold" if bold else "Helvetica", 11)
            c.drawString(50, y, text); y -= 30
        c.setFont("Helvetica", 8); c.drawString(50, 30, "(c) UCLES 2023")
        c.showPage()
    c.save()


def test_question_heading_ms_needs_exact_sequence(tmp_path):
    from core.legacy_ms_split import split_question_heading_ms
    p = tmp_path / "ms.pdf"
    _pdf(p, [[("MARK SCHEME", True)], [("Question 1", True), ("answer one", False)],
             [("more for one", False)], [("Question 2", True), ("answer two", False)]])
    out, _ = split_question_heading_ms(p, dpi=72, expected_top_numbers=[1, 2])
    assert sorted(out) == [1, 2] and out[1].height > out[2].height
    out, diag = split_question_heading_ms(p, dpi=72, expected_top_numbers=[1, 2, 3])
    assert out == {} and "!=" in diag.warnings[-1]


def test_generic_level_ms_refuses_question_content(tmp_path):
    from core.legacy_ms_split import split_generic_level_ms
    grid = [("All questions are marked out of 25.", False), ("Level 3  good", False),
            ("Level 2  fair", False), ("Level 1  weak", False)]
    p = tmp_path / "g.pdf"
    _pdf(p, [[("MARK SCHEME", True)], grid])
    out, _ = split_generic_level_ms(p, dpi=72, expected_top_numbers=[1, 2, 3])
    assert sorted(out) == [1, 2, 3]
    q = tmp_path / "q.pdf"
    _pdf(q, [[("MARK SCHEME", True)], [("1(a)  osmosis", False)] + grid])
    out, _ = split_generic_level_ms(q, dpi=72, expected_top_numbers=[1, 2, 3])
    assert out == {}


def test_section_heading_pattern():
    from core.exercise_heading_engine import SECTION_HEADING
    assert SECTION_HEADING.match("1 القسم") and SECTION_HEADING.match("القسم 2")
    assert SECTION_HEADING.match("Section 3") and not SECTION_HEADING.match("Section A")
    assert not SECTION_HEADING.match("Answer one question from Section 1")


def test_label_column_beats_indented_numbered_list():
    from core.vector_first_cropper import Marker, select_qp_sequence
    m = [Marker(1, 1, 64, 74, 50, "1", 1.1, "x")]
    m += [Marker(n, 3, 400 + 30 * n, 410 + 30 * n, 72, str(n), 0.95, "x") for n in range(1, 8)]
    m += [Marker(n, p, 64, 74, 50, str(n), 1.1, "x") for n, p in ((2, 7), (3, 10), (4, 13))]
    assert [(x.number, x.page) for x in select_qp_sequence(m)] == [(1, 1), (2, 7), (3, 10), (4, 13)]
