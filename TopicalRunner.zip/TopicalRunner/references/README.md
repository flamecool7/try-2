# references/ — paper-level topic references read at RUNTIME by `core/math_reference.py`

`Mathematics_9709 References.txt` (P1–P6) and `Further_Mathematics_9231 Reference.txt` (P1–P4) are
loaded by `core/math_reference.py` (`REFERENCE_PATH`, `FURTHER_9231_REFERENCE_PATH`) for question-level
mathematics routing. **They are live product data, not documentation.**

Incident record (2026-09-22, cleanup work order item A5): the work order stated this directory had
"ZERO references anywhere including tests" and it was deleted on that basis; the runtime consumer builds
the path with `Path(...) / "references" / ...`, which a search for the literal `references/` misses, and
24 mathematics tests failed. The two files were **reconstructed from the official 9709/9231 syllabus
paper structure and the topic vocabulary already pinned in `subjects_caie/A-Level/*_9709|9231/config.json`**
(order and spelling as the configs and `core/math_reference.py`'s alias table record them: the 9231 text
keeps the pre-canonical spellings `Inference_using_normal_and_t-distributions` /
`Non-parametric_tests` and no `Hooke's_law` line in P3, exactly as the alias code expects). The
reconstruction is not byte-identical to the originals pinned in the lock docs
(`a2ddf683…` / see `EFFICIENCY_AUDIT.md`); restore the originals from the release zip when available,
which will make those pins match again. Never delete this directory.
