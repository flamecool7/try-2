# TopicalRunner — slim runtime (built 2026-09-29, from repo CLS-178h (run.bat is the ONE launcher: it starts the web app and carries the whole menu -- build, scan, index, booklet, clean+rebuild, validate, configs, demo, control menu; IB+SAT automatic on every run path; IB+SAT automatic on every run path; shipped input/ + output/ are the contract -- no folder prompt; per-question insert crops Q<n>_IN.webp + per-question ER detection Q<n>_ER.webp))

Self-contained topical-question-bank generator. No tests, no fixtures, no
downloaders: the PDFs come from `input/` and everything lands in `output/`. Working dirs (`papers/`, `logs`,
`cache`, ...) are created automatically on first run.

## Run it
- `python main.py --input <pdf-dir> --output <out-dir>` — CAIE/0452-style
  papers (delegates to the guarded production path).
- `python main.py --universal-batch --input <dir> --output <dir>` — AQA /
  Edexcel / OxfordAQA / IB / SAT papers. IB and SAT are processed by default
  (`--no-include-ib` / `--no-include-sat` turn them off).
- `python run_guarded.py --input <dir> --output <out-dir> [--dry-run]` —
  the guarded pipeline directly (stages S0-S5 + S7b + S8).
- `run.bat` — the **only** launcher, and the Windows way in. Double-clicking it opens a
  menu that starts the **web app** (option 1: browser plus the local server window in
  its own console), builds the packs from `input/` into `output/` with the same two
  flags the app passes (`--jobs 0 --prune-stale-dirs`), scans the input folder, builds
  the index and a booklet, cleans and rebuilds, validates output and configurations,
  runs the demo, and opens the full Python control menu. No arguments = the menu;
  any arguments = forwarded to `run_pipeline.py` untouched.
- `python run_pipeline.py --menu` — the ExamVoid CLI control menu (it works, but it is
  not the web app).
- `python server.py --port 8765` — local web app (`static/` UI, stdlib only).

Deps: `pip install -r requirements.txt` (PyMuPDF, Pillow, numpy, OpenCV,
imagehash, PyWavelets, scipy, reportlab, python-docx, openpyxl, requests,
tqdm; psutil optional).

## AI assist (optional, off by default)
The Review screen can ask a model for **suggestions** on rows the offline classifier would
not claim (flagged/uncertain rows only — a confident verdict is never re-litigated). It fills
the Assign control and stops; nothing is auto-assigned and nothing leaves the machine unless
you configure a provider. Three candidates come back, each with a one-line reason, drawn only
from that subject's own topic list.

Turn it on either way (the environment wins if both are set):

- `<data-dir>/ai_assist.json` — e.g. `{"provider": "ollama", "model": "qwen2.5:7b",`
  `"base_url": "http://127.0.0.1:11434"}`
- environment: `TOPICAL_AI_PROVIDER` (`ollama` | `openai` | `none`), `TOPICAL_AI_MODEL`,
  `TOPICAL_AI_BASE_URL`, `TOPICAL_AI_API_KEY`, `TOPICAL_AI_TIMEOUT`

`ollama` talks to any Ollama server (`/api/chat`); `openai` talks to any OpenAI-compatible
endpoint (`/v1/chat/completions`, so vLLM, LM Studio, a gateway, or the hosted API).
Suggestions are cached in `<data-dir>/ai_suggestions.json` keyed by question text, and the
model id + timestamp are recorded beside the offline verdict. `GET /api/ai/status` reports
whether it is on and how many answers are cached (never the API key).

## Deliberately absent in this build
- QP/MS/ER downloaders + fetchers (`--fetch-*` flags are gone): you supply the PDFs.
  Everything that runs locally is present, examiner reports included.
- Dropped dev-only modules: `core/examiner_report_gold.py`, the fetcher modules and
  `tools/download_examiner_reports.py`.

## Examiner reports (both boards)
Drop a QP, its mark scheme, its insert booklet and its examiner report into `input/`.
- **CAIE**: the guarded pipeline parses the report and attaches it to the question
  folders it belongs to -- `Q<n>_ER.webp` (the section about that question) plus the
  whole-report tiles `<paper>_ER.webp` / `_ER_partN.webp`.
- **AQA / Edexcel / IB / SAT**: the universal batch does the same
  (`Q<n>.webp` + `Q<n>_MS.webp` + `Q<n>_IN.webp` + `Q<n>_ER.webp`).
- Output is crops only: there is no `_ER.txt` sidecar (a question folder holds its
  images and `metadata.json`).
- Dev factory: tests, fixtures, taxonomy sources, lock docs, proof tooling,
  curation scripts (including `tools/fake_model_server.py`, the stand-in model used to
  prove AI assist end to end). They live on in the source repo only.

See MANIFEST.md for the exact file list and the ER-removal ledger.
