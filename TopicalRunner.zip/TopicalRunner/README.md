# TopicalRunner — slim runtime (built 2026-09-29, from repo CLS-178h (run.bat is the ONE launcher: it starts the web app and carries the whole menu -- build, scan, index, booklet, clean+rebuild, validate, configs, demo, control menu; IB+SAT automatic on every run path; IB+SAT automatic on every run path; shipped input/ + output/ are the contract -- no folder prompt; per-question insert crops Q<n>_IN.webp + per-question ER detection Q<n>_ER.webp))

Self-contained topical-question-bank generator. No tests, no fixtures, no
downloaders: the PDFs come from `input/` and everything lands in `output/`. Working dirs (`papers/`, `logs`,
`cache`, ...) are created automatically on first run.

## Run it
- `python main.py --input <pdf-dir> --output <out-dir>` — CAIE/0452-style
  papers (delegates to the guarded production path).
- `python main.py --universal-batch --input <dir> --output <dir>` — AQA /
  Edexcel / OxfordAQA / IB / SAT papers. IB and SAT are processed by default
  (`--no-include-ib` / `--no-include-sat` turn them off).
- `python run_guarded.py --input <dir> --output <out-dir> [--dry-run]` —
  the guarded pipeline directly (stages S0-S5 + S7b + S8).
- `run.bat` — the **only** launcher, and the Windows way in. Double-clicking it opens a
  menu that starts the **web app** (option 1: browser plus the local server window in
  its own console), builds the packs from `input/` into `output/` with the same two
  flags the app passes (`--jobs 0 --prune-stale-dirs`), scans the input folder, builds
  the index and a booklet, cleans and rebuilds, validates output and configurations,
  runs the demo, and opens the full Python control menu. No arguments = the menu;
  any arguments = forwarded to `run_pipeline.py` untouched.
- `python run_pipeline.py --menu` — the ExamVoid CLI control menu (it works, but it is
  not the web app).
- `python server.py --port 8765` — local web app (`static/` UI, stdlib only).

Deps: `pip install -r requirements.txt` (PyMuPDF, Pillow, numpy, OpenCV,
imagehash, PyWavelets, scipy, reportlab, python-docx, openpyxl, requests,
tqdm; psutil optional).

## AI assist (optional, off by default)
The Review screen can ask a model for **suggestions** on rows the offline classifier would
not claim (flagged/uncertain rows only — a confident verdict is never re-litigated). It fills
the Assign control and stops; nothing is auto-assigned and nothing leaves the machine unless
you configure a provider. Three candidates come back, each with a one-line reason, drawn only
from that subject's own topic list.

Turn it on either way (the environment wins if both are set):

- `<data-dir>/ai_assist.json` — e.g. `{"provider": "ollama", "model": "qwen2.5:7b",`
  `"base_url": "http://127.0.0.1:11434"}`
- environment: `TOPICAL_AI_PROVIDER` (`ollama` | `openai` | `none`), `TOPICAL_AI_MODEL`,
  `TOPICAL_AI_BASE_URL`, `TOPICAL_AI_API_KEY`, `TOPICAL_AI_TIMEOUT`

`ollama` talks to any Ollama server (`/api/chat`); `openai` talks to any OpenAI-compatible
endpoint (`/v1/chat/completions`, so vLLM, LM Studio, a gateway, or the hosted API).
Suggestions are cached in `<data-dir>/ai_suggestions.json` keyed by question text, and the
model id + timestamp are recorded beside the offline verdict. `GET /api/ai/status` reports
whether it is on and how many answers are cached (never the API key).

## Deliberately absent in this build
- QP/MS/ER downloaders + fetchers (`--fetch-*` flags are gone): you supply the PDFs.
  Everything that runs locally is present, examiner reports included.
- Dropped dev-only modules: `core/examiner_report_gold.py`, the fetcher modules and
  `tools/download_examiner_reports.py`.

## Question papers without a mark scheme (CAIE)
A QP that arrives with no mark scheme is still **classified into its syllabus topic** from the
question text, then parked in a `review_required` folder **inside that topic**:

    <Level>/<Subject>/paper-N/<Topic>/review_required/<Variant>_<Season>_<Year>_Q<n>/
        <QID>.webp
        metadata.json        -> "topic": ["<Topic>", ...other detected topics]

`metadata.json` records the topic it was categorised into (same `topic` list a normal question
gets, `topic[0]` = the folder topic). When the mark scheme is added and the paper is re-run, the
question is promoted to the normal `<Topic>/<QID>/` folder and the review copy is removed. Only when
no topic can be chosen (`--no-full-auto` with no evidence) does it fall back to the flat
`<Subject>/review_required/` folder with the `review_required_no_ms` sentinel. Older runs' flat
no-MS folders are moved into their topic automatically on the next run. The app index lists these
questions on the Review screen (flagged `MISSING_MS`) with the topic pre-filled.

## Examiner reports (both boards)
Drop a QP, its mark scheme, its insert booklet and its examiner report into `input/`.
- **CAIE**: the guarded pipeline parses the report and attaches ONLY the section about each
  question to that question's folder: `<variant>_<Season>_<Year>_Q<n>_ER.webp`. The whole report is
  no longer copied into every question folder (the old `<paper>_ER.webp` / `_ER_partN.webp` tiles);
  tiles left by older runs are deleted automatically on the next run.
- **AQA / Edexcel / IB / SAT**: the universal batch does the same
  (`Q<n>.webp` + `Q<n>_MS.webp` + `Q<n>_IN.webp` + `Q<n>_ER.webp`).
- Output is crops only: there is no `_ER.txt` sidecar (a question folder holds its
  images and `metadata.json`).
- Dev factory: tests, fixtures, taxonomy sources, lock docs, proof tooling,
  curation scripts (including `tools/fake_model_server.py`, the stand-in model used to
  prove AI assist end to end). They live on in the source repo only.

See MANIFEST.md for the exact file list and the ER-removal ledger.

## Files named .pdf that are not PDFs (no more "error code 1")

Bulk downloads often contain HTML "not found" pages saved as `.pdf` for
documents that are not published yet (e.g. `0606_s26_ms_23.pdf`,
`0606_s26_er.pdf`), or half-finished downloads. These used to crash a paper
worker / stop stage S6 and the batch ended with error code 1.

Every run (`main.py`, `run_guarded.py`, `run_pipeline.py`,
`tools/run_universal_batch.py`, `run.bat`) now screens the input first
(`core/input_screen.py`): such files are **moved** (never deleted) to
`<input>/_not_a_pdf/` (renamed `.html` / `.bad`), listed in
`<output>/not_a_pdf_inputs.txt`, and the run continues as if they were missing
— e.g. a QP whose MS is fake goes to `<Topic>/review_required/`. Put the real
PDF back in the input folder and run again to complete it.

## No mark scheme -> always `<Topic>/review_required/` (every mode)

A question whose mark scheme is missing is ALWAYS classified from its QP and
filed inside its own paper's topic folder:

    A-Level/Physics_9702/paper-4/Astronomy_and_cosmology/review_required/42_Spring_2026_Q8/

This now holds with `--no-full-auto` / weak evidence and for MCQ papers too
(MCQ gets an empty `_MS.txt` until the real answer key arrives). The topic is
always one of that paper's syllabus topics (`paper_topics` in the config).
There is no flat `<Subject>/review_required/` for missing mark schemes any
more (only an emergency fallback if writing the topic folder itself crashes).
Re-run with the MS to move the question into the normal topic folder.

## Found the mark scheme later? Just drop it in

Run the QP without its MS -> questions go to `paper-N/<Topic>/review_required/`.
When you find the MS, put **only the MS** in the input folder (the QP is not
needed again) and run with the same output folder:

* each MS question is matched to its QP by paper + question number
  (e.g. `0606_s26_ms_22` Q3 <-> `22_Summer_2026_Q3`);
* the folder moves out of `review_required` into its topic,
  `paper-N/<Topic>/<QID>/`, and gets `<QID>_MS.webp` - exactly what a normal
  QP+MS run produces (MCQ papers: `<QID>_MS.txt` with the answer letter);
* when every question of that paper is matched, the paper is marked COMPLETE
  (exit 0 if nothing else needs review).

Putting the QP and MS in together also works (normal pairing replaces the
review folders). An MS whose QP was never run is still kept in
`<Subject>/review_required/` until the QP arrives.

## Arabic 0544 (right-to-left papers) — papers 2 and 4 no longer fail

2025+ Cambridge PDFs for 0544 use anonymised fonts (`AllAndNone`, no bold
flag). The RTL margin engine (`core/rtl_margin_engine.py`) required the
question number to be bold -> paper 2 found 0 questions; and its Arabic-share
gate counted garbled glyphs as Latin -> paper 4 (share 0.24 < 0.30) never
engaged. Now: bold is only required when the PDF carries weight info at all,
and the share is Arabic / (Arabic + A-Z) without the cover page (gate 0.15;
LTR papers measure 0.00). 0544 s25: 6/6 bundles pass (P1 37, P2 6, P4 3 Qs);
s24 unchanged (same counts).
