Pipeline output lands here. Empty on a fresh run.
