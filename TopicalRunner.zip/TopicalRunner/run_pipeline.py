#!/usr/bin/env python3
"""CLI entry point for the batch runner (Overseer batch-infrastructure spec,
Phase 6 — honest port; imports the real core.batch_runner)."""

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))



def _configure_console_output():
    """Do not let cp1252 Windows consoles crash on status glyphs.

    Logs remain UTF-8; a console that cannot display a glyph gets a replacement
    character instead of terminating the parent after a worker failure.
    """
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(errors="replace")
        except Exception:
            pass


_configure_console_output()

from core.batch_runner import run_pipeline


def apply_resource_profile(args):
    """Optional higher-resource preset.

    Honest limit: software cannot allocate physical RAM. This profile only
    tells the pipeline to use the fuller crop path and, unless the user has
    already chosen a worker count, nudges concurrency slightly upward.
    """
    if getattr(args, "performance", False):
        args.low_ram = False
        if args.workers is None:
            args.workers = 6  # user-requested default (2026-08-14)
    return args


def main():
    # If invoked with no args in an interactive terminal, launch the main control menu
    if len(sys.argv) == 1 and sys.stdin.isatty():
        from core.control_center import ControlMenu
        ControlMenu().run()
        return 0

    from core.control_center import SettingsManager
    sm = SettingsManager()

    parser = argparse.ArgumentParser(
        description="ExamVoid Topical Generator — batch mode & control system"
    )
    parser.add_argument(
        "--menu", action="store_true",
        help="Launch interactive ExamVoid control menu"
    )
    parser.add_argument(
        "--audit", action="store_true",
        help="Run fast archive audit without processing"
    )
    parser.add_argument(
        "--stats", action="store_true",
        help="Display archive metrics and storage statistics"
    )
    parser.add_argument(
        "--sys-check", action="store_true",
        help="Run system and installation dependency verification"
    )
    parser.add_argument(
        "--cleanup", action="store_true",
        help="Clean safe temporary files (.tmp, .staging, stale locks)"
    )
    parser.add_argument(
        "--benchmark", action="store_true",
        help="Run live pipeline performance benchmark"
    )
    parser.add_argument(
        "--scan-new", action="store_true",
        help="Scan input directory for newly added past paper PDFs"
    )
    parser.add_argument(
        "--universal-batch", action="store_true",
        help="Run the universal AQA/Edexcel batch router instead of the Cambridge topical pipeline (IB gated until official PDFs are supplied)"
    )
    parser.add_argument(
        "--include-sat", dest="include_sat", action="store_true", default=True,
        help="Process SAT papers (DEFAULT ON; --no-include-sat skips them)"
    )
    parser.add_argument(
        "--no-include-sat", dest="include_sat", action="store_false",
        help="Skip SAT papers in this run"
    )
    parser.add_argument(
        "--include-ib", dest="include_ib", action="store_true", default=True,
        help="Process IB papers (DEFAULT ON; --no-include-ib skips them)"
    )
    parser.add_argument(
        "--no-include-ib", dest="include_ib", action="store_false",
        help="Skip IB papers in this run"
    )
    parser.add_argument(
        "--universal-limit-per-paper", type=int, default=0,
        help="Debug/proof limiter for universal batch; 0 means all segments"
    )
    parser.add_argument(
        "--enable-ocr", action="store_true",
        help="Attempt optional Tesseract OCR for image-only universal-batch PDFs"
    )
    parser.add_argument(
        "--input", default=sm.get("input_folder", "input"),
        help="Input directory containing PDF files"
    )
    parser.add_argument(
        "--output", default=sm.get("output_folder", "output"),
        help="Output directory for question bank"
    )
    parser.add_argument(
        "--topics", default="topics",
        help="(compat) Path to taxonomy JSON files"
    )
    parser.add_argument(
        "--workers", type=int, default=None,
        help="Number of parallel workers (default: RAM-aware auto profile, then RAM-guard clamped)"
    )
    parser.add_argument(
        "--resume", action="store_true", default=True,
        help="Skip already-complete bundles (default: on)"
    )
    parser.add_argument(
        "--retry-failed", action="store_true",
        help="Retry previously failed bundles"
    )
    parser.add_argument(
        "--force-all", action="store_true", default=False,
        help="Force re-processing of all files regardless of previous completion status (never default)"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Preview the exact bundle plan without creating or modifying archive state"
    )
    parser.add_argument(
        "--full-auto",
        action="store_true",
        default=True,
        help="DEFAULT ON: auto-classify questions that have a valid answer "
             "representation. It never bypasses structured QP/MS pairing or "
             "crop safety gates; structured questions without a usable MS are "
             "preserved under review_required. Pass --no-full-auto to also "
             "route weak classification evidence to review."
    )
    parser.add_argument(
        "--no-full-auto",
        action="store_true",
        default=False,
        help="Also fail closed on ambiguous/no-evidence classification instead "
             "of selecting an automatic best-fit topic."
    )
    parser.add_argument(
        "--trust-self",
        action="store_true",
        default=False,
        help="Explicit alias for automatic classification only; it does not "
             "permit a structured missing-MS placeholder."
    )
    parser.add_argument(
        "--session", default=None,
        help="Process only one session, e.g. s26, summer, m26, winter, or specimen."
    )
    parser.add_argument(
        "--year", dest="year_filter", default=None,
        help="Process only one exam year, e.g. 2026 or 26."
    )
    parser.add_argument(
        "--subject", dest="subject_filter", default=None,
        help="Process only subjects whose name contains this text."
    )
    parser.add_argument(
        "--syllabus-code", dest="syllabus_code_filter", default=None,
        help="Process only one exact syllabus code, e.g. 9701."
    )
    parser.add_argument(
        "--level", dest="level_filter", default=None, choices=("IGCSE", "A-Level"),
        help="Process only IGCSE or A-Level bundles."
    )
    parser.add_argument(
        "--variant", dest="variant_filter", default=None,
        help="Process only one exact Cambridge paper component/variant, e.g. 21, 22, 31, or 42."
    )
    parser.add_argument(
        "--file", dest="selected_files", action="append", default=None,
        help="Process only the bundle containing this input PDF. May be repeated."
    )
    parser.add_argument(
        "--folder", dest="selected_folder", default=None,
        help="Process only bundles with an input component beneath this folder."
    )
    parser.add_argument(
        "--full-ram", dest="low_ram", action="store_false", default=True,
        help="Use the full production CroppingEngine path (needs a big machine)"
    )
    parser.add_argument(
        "--performance", action="store_true",
        help=(
            "Higher-resource preset: disables low-RAM mode and, if --workers "
            "was not supplied, nudges worker count slightly upward. Best used "
            "on a machine with about 4GB RAM or more."
        )
    )

    args = parser.parse_args()

    # Route control commands immediately without invoking batch preflights
    if args.menu:
        from core.control_center import ControlMenu
        ControlMenu().run()
        return 0
    if args.universal_batch:
        from tools.run_universal_batch import run_batch
        audit = run_batch(
            Path(args.input),
            Path(args.output),
            include_sat=args.include_sat,
            include_ib=args.include_ib,
            limit_per_paper=args.universal_limit_per_paper,
            enable_ocr=args.enable_ocr,
        )
        counts = audit.get("counts", {})
        if counts.get("render_fail", 0):
            return 1
        if counts.get("review_required", 0):
            return 2
        return 0
    if args.audit:
        from core.control_center import ArchiveAuditor
        ArchiveAuditor(Path(args.input), Path(args.output)).print_audit_report()
        return 0
    if args.stats:
        from core.control_center import ArchiveStatistics
        ArchiveStatistics(Path(args.input), Path(args.output)).print_stats_report()
        return 0
    if args.sys_check:
        from core.control_center import SystemVerifier
        ok = SystemVerifier(Path(args.input), Path(args.output)).print_verification_report()
        return 0 if ok else 1
    if args.cleanup:
        from core.control_center import SafeCleaner
        SafeCleaner(Path(args.output)).clean(interactive=False)
        return 0
    if args.benchmark:
        from core.control_center import PerformanceBenchmarker
        PerformanceBenchmarker(Path(args.output)).run_benchmark()
        return 0
    if args.scan_new:
        from core.control_center import NewFilesScanner
        NewFilesScanner(Path(args.input), Path(args.output)).print_scan_report()
        return 0

    selected_paths = set()
    for raw_path in args.selected_files or []:
        candidate = Path(raw_path).expanduser().resolve()
        if not candidate.is_file():
            parser.error(f"--file does not point to a readable file: {candidate}")
        selected_paths.add(str(candidate))
    if args.selected_folder:
        selected_folder_path = Path(args.selected_folder).expanduser().resolve()
        if not selected_folder_path.is_dir():
            parser.error(f"--folder does not point to a readable directory: {selected_folder_path}")
        args.selected_folder = str(selected_folder_path)

    args = apply_resource_profile(args)
    # One policy value is passed through every preflight and worker path.  The
    # previous CLI accidentally passed raw `args.full_auto` in some branches,
    # so `--no-full-auto` could be ignored after a fetch preflight.
    auto_mode = bool(getattr(args, "full_auto", True) or getattr(args, "trust_self", False)) \
        and not bool(getattr(args, "no_full_auto", False))

    # The --dry-run path below is strictly read-only (this build has no
    # fetch/download operations at all).
    needs_write_lock = not args.dry_run
    lock = None
    if needs_write_lock:
        from core.control_center import ExamVoidLock
        lock = ExamVoidLock(Path(args.output) / ".examvoid_run_lock")
        if not lock.acquire(interactive=sys.stdin.isatty(), command_desc=" ".join(sys.argv)):
            print(f"[ERROR] Could not acquire run lock for {args.output}")
            return 1

    try:
        result = run_pipeline(
            pdf_dir=args.input,
            output_dir=args.output,
            topics_dir=args.topics,
            workers=args.workers,
            resume=args.resume,
            retry_failed=args.retry_failed,
            force_all=getattr(args, "force_all", False),
            dry_run=args.dry_run,
            low_ram=args.low_ram,
            full_auto=auto_mode,
            session=args.session,
            year_filter=args.year_filter,
            subject_filter=args.subject_filter,
            syllabus_code_filter=args.syllabus_code_filter,
            level_filter=args.level_filter,
            variant_filter=args.variant_filter,
            selected_paths=selected_paths or None,
            selected_folder=args.selected_folder,
        )
    except KeyboardInterrupt:
        print("\nShutdown requested. Archive state was left resumable; lock released.")
        return 130
    finally:
        if lock is not None:
            lock.release()

    if result.get("interrupted"):
        return 130
    if result.get("failed", 0):
        return 1
    if result.get("review_required", 0):
        return 2
    if result.get("audit_passed") is False:
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
