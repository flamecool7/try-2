#!/usr/bin/env python3
"""run_guarded.py — self-checking orchestration runner (2026-08-10, user-approved:
"check itself every step" mode, wrapper architecture).

Runs the locked pipeline stage-by-stage with hard gates BETWEEN every stage.
Any failed check inside a stage aborts the run ON THE SPOT with a loud banner
naming the stage + every failed check + a failure_report.txt — downstream
stages never execute, and nothing half-built is treated as output.

    python3 run_guarded.py --input papers --output output [--clean] [--low-ram]

Exit codes: 0 = every stage green and no review-required output. 1 = a stage gate failed (see banner/report). 2 = the run completed safely but one or more question folders require human review.
This file changes NO locked source: it only calls the same public functions
main.py calls.

Architecture notes
------------------
* Each QP+MS paper bundle runs in its own subprocess ("paper worker"). Peak
  heap stays around ~950MB inside one worker and dies with it, instead of
  accumulating across papers (glibc retains freed heap: one 16+ page paper
  leaves ~935MB RSS that a second paper then kills against — exit 137 in this
  ~2GB sandbox). A worker crash (incl. SIGKILL/137) is surfaced by the parent
  as a loud failed gate naming the paper, not a silent empty log.
* QP paths (loudly reported at start):
    default   : CroppingEngine.process_paper.
    --low-ram : bundled vector-first QP cropping. PDF text/vector geometry is
                analyzed first and final question clips are spooled one at a
                time; QP/MS pairing is by exact question number.
* Width contract: engines may return content-width rasters (MS 1501px); the
  locked OutputManager scales to exactly 2280 at save. The hard 2280 gate
  lives in S5 on the saved files — where production actually guarantees it.
"""
import argparse
import gc
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))

# Evaluation-tooling hook (inert unless CLS_DUMP is set): lets the cls_eval
# capture hook wrap classify_question in this process AND in the isolated
# paper workers.  Loaded by file path because a distro sitecustomize may
# already occupy sys.modules.
if os.environ.get("CLS_DUMP") and os.environ.get("CLS_HOOK"):
    try:
        import importlib.util as _hook_ilu
        _hook_p = os.path.join(os.environ["CLS_HOOK"], "sitecustomize.py")
        _hook_spec = _hook_ilu.spec_from_file_location("cls_eval_hook", _hook_p)
        _hook_mod = _hook_ilu.module_from_spec(_hook_spec)
        _hook_spec.loader.exec_module(_hook_mod)
    except Exception:
        pass


def _configure_console_output():
    """Do not let cp1252 Windows consoles crash on status glyphs.

    Logs remain UTF-8; a console that cannot display a glyph gets a replacement
    character instead of terminating the parent after a worker failure.
    """
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(errors="replace")
        except Exception:
            pass


_configure_console_output()

logging.basicConfig(level=logging.WARNING)

import numpy as np

MIN_HEIGHT_PX = 80
TARGET_WIDTH = 2280
INK_MIN_FRAC = 0.0005


def er_crop_verification_gate(stats: dict) -> tuple[bool, str]:
    """Interpret ER crop verification under the no-text-file product policy.

    The cropper performs normalized containment only when the legacy
    ``examiner_report.txt`` probe exists.  The final product deliberately no
    longer writes that text file, so ``written > 0, verified == 0`` is an
    *unavailable text probe*, not a failed boundary crop.  Explicit containment
    mismatches remain fatal; image geometry/errors are still checked by S7.
    """
    written = int(stats.get("crops_written", 0) or 0)
    verified = int(stats.get("verified", 0) or 0)
    failed = list(stats.get("verify_failed", []) or [])
    if failed:
        return False, f"{written}/{verified}; containment failures: {failed[:3]}"
    if written == verified:
        return True, f"{written}/{verified} text-verified"
    return True, (f"{written}/{verified}; text probe unavailable under the "
                  "final-product no-.txt policy")


def qp_min_height_px(qp_info) -> int:
    """Per-paper sanity floor for QP crop height.

    Keep the default 80px floor everywhere unless we have specific evidence.
    IGCSE Mathematics 0580 Paper 2 can contain legitimate very short structured
    one-liners whose clean crops land in the high-60s / 70s px range at the
    final 2280px width; those should not fail the whole paper when they still
    contain ink and extracted text. This is a guard-only change, not a crop
    algorithm change.

    RS-59 (2026-08-16): the SAME reasoning applies to short-answer / essay
    subjects (Sociology, Psychology, History, English, Business, Economics,
    Law, Accounting, Geography, Global Perspectives, Thinking Skills) — a
    single-line question like "Describe two quantitative research methods.
    [4]" crops to ~75px and must not fail the whole paper.  Ink and extracted-
    text checks still run, so an empty/mangled crop is still caught.
    """
    code = str(getattr(qp_info, "syllabus_code", "") or "")
    # one-liner-prone short-answer/essay subjects (0580 precedent + RS-59)
    _SHORT_ANSWER_CODES = {
        "0580",  # IGCSE Mathematics (existing)
        "9699",  # Sociology
        "9990",  # Psychology
        "9489", "0470",  # History
        "9695", "0475", "0477",  # Literature in English (0477: "Or 18" prompts crop ~77px)
        "9093", "8021", "0500", "0510",  # English Language / General Paper
        "9084",  # Law
        "9609", "0450",  # Business
        "9708", "0455",  # Economics
        "9706", "0452",  # Accounting
        "9696", "0460",  # Geography
        "9239", "0457",  # Global Perspectives
        "9694",  # Thinking Skills
        "9693", "0697",  # Marine Science
        # Measured on the 2026-09-21 CAIE proof run: these practical papers
        # cropped to 66-76px one-liners with ink. The 80px floor failed the
        # whole paper. Same guard as RS-59, not a crop-algorithm change.
        "0400", "9479",  # Art and Design
        "0410", "9483",  # Music
        "0417",          # ICT
        "0549",          # Hindi: Q9 measured 75px on the fix re-run
        # A20 (2026-09-26): foreign-language listening/short-answer papers
        # are the same one-liner archetype (0520_s26_qp_11 Q15 ``15
        # Frédéric… [1]`` crops to 75px complete with ink+text; the 80px
        # floor failed all three 0520_s26 bundles). Hindi was already in
        # this set on identical evidence; the language family joins it.
        "0520", "0525", "0530", "0539", "0544", "0547",  # IGCSE languages
        "9686", "9715", "9716", "9717", "9719",  # A-Level languages
    }
    if code in _SHORT_ANSWER_CODES:
        return 60
    return MIN_HEIGHT_PX

ALL_STAGES = [
    ("S0", "environment + config validation"),
    ("S1", "paper identification + subject separation"),
    ("S2", "QP crop (gold-standard splitter)"),
    ("S3", "MS crop (LOCKED exact splitter)"),
    ("S4", "QP/MS grouping + pairing"),
    ("S5", "classify + save question pairs"),
    ("S6", "examiner-report visual attachment"),
    ("S7", "examiner-report per-question crops"),
    ("S8", "final validation + output audit"),
]

WORKER_OK = re.compile(r"WORKER-RESULT saved=(\d+) base=(\S+)")
# Question-level batching: a worker that could not afford one question's save
# transient names it on its own line so the parent can record a PARTIAL paper.
WORKER_SKIP = re.compile(r"^SKIP\s+(\S+)\s+(\S+):\s*(.*)$", re.MULTILINE)


class StageAbort(Exception):
    pass


def _rss_mb() -> int:
    try:
        with open("/proc/self/statm") as fh:
            pages = int(fh.read().split()[1])
        return pages * 4096 // (1024 * 1024)
    except Exception:
        return -1


class _NullState:
    """State API no-op for child workers spawned by pipeline.py (U1).

    In parallel mode the PARENT owns .pipeline_state.json; children must never
    read-modify-write it concurrently (corruption risk). should_skip() is
    always False because the parent pre-filters before spawning.
    """

    def __init__(self, real_state=None):
        self._real = real_state

    def register_paper(self, *a, **k):
        return None

    def should_skip(self, paper_code) -> bool:
        return False

    def mark_processing(self, paper_code):
        return None

    def mark_complete(self, paper_code, questions_found, questions_saved):
        return None

    def mark_failed(self, paper_code, error):
        return None

    def mark_review_required(self, paper_code, reason):
        return None

    def save(self, output_dir):
        return None

    def print_summary(self):
        return None


class Gate:
    """Collects checks for one stage; abort() ends the run loudly on any fail."""

    def __init__(self, output_root: Path):
        self.output_root = Path(output_root)
        self.stage_results = []

    def run_stage(self, sid: str, name: str, fn, *, abort_on_fail: bool = True):
        checks = []

        def check(nm, ok, detail=""):
            checks.append((nm, bool(ok), str(detail)))
            print(f"    [{'PASS' if ok else 'FAIL'}] {nm}: {detail}")

        print(f"\n=== STAGE {sid} — {name} ===")
        try:
            result = fn(check)
            print(f"  [mem] current RSS after {sid}: {_rss_mb()} MB")
        except StageAbort:
            raise
        except Exception as exc:  # crash containment: exception becomes a failed gate, not a traceback
            import traceback
            tb = traceback.format_exc(limit=3)
            check(f"stage crashed: {type(exc).__name__}", False, f"{exc} | {tb.splitlines()[-1] if tb else ''}")
            result = None

        fails = [(n, d) for n, ok, d in checks if not ok]
        if fails and abort_on_fail:
            self._abort(sid, name, checks, fails)
        self.stage_results.append((sid, name, checks))
        if fails:
            print(f"  -> STAGE {sid} SOFT-FAIL captured ({len(fails)} failed checks; continuing)")
        else:
            print(f"  -> STAGE {sid} OK ({len(checks)} checks)")
        return result

    def _abort(self, sid, name, checks, fails):
        print()
        print("!" * 64)
        print(f"  XXX RUN FAILED XXX — stopped at STAGE {sid}: {name}")
        print("!" * 64)
        print("  Failed checks:")
        for i, (n, d) in enumerate(fails, 1):
            print(f"    {i}. {n}" + (f"   ->  {d}" if d else ""))
        print()
        print("  Downstream stages did NOT run. Nothing half-built is treated as output.")
        self.output_root.mkdir(parents=True, exist_ok=True)
        rp = self.output_root / "failure_report.txt"
        lines = [
            f"failure_report  —  {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"run_guarded stopped at STAGE {sid}: {name}",
            f"failed {len(fails)}/{len(checks)} checks in this stage",
            "",
        ] + [f"FAIL  {n}: {d}" for n, d in fails]
        rp.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"  report written: {rp}")
        print("!" * 64)
        sys.exit(1)

    def finish_all(self, title="", worker=False, paper_failures=None):
        """Finish only after distinguishing clean output from safe review output.

        A review-required question is not a stage failure: its crop is kept and
        the run is internally consistent. It is also not an all-green run.
        Exit code 2 makes that distinction machine-readable for batch scripts.

        `paper_failures` is an optional list of per-bundle hard failures that
        were recorded but tolerated so the rest of the batch could continue.
        When present, the run ends with exit 1 AFTER all remaining bundles and
        post-processing stages have finished, and the user gets a specific
        failed-papers report instead of a first-error abort.
        """
        total = sum(len(c) for _, _, c in self.stage_results)
        review_roots = {"review_required", "review_required_no_ms"}
        review_dirs = [
            path for path in self.output_root.rglob("*")
            if path.is_dir() and any(part in review_roots for part in path.parts)
        ]
        # A historical-year review can legitimately keep its question folders
        # in normal topic directories.  Read the guarded state file as a
        # second review signal so direct run_guarded mode cannot print ALL
        # GREEN merely because no sentinel folder was needed.
        state_review = False
        state_file = self.output_root / ".pipeline_state.json"
        if state_file.exists():
            try:
                payload = json.loads(state_file.read_text(encoding="utf-8"))
                state_review = any(
                    "review" in str(record.get("status", "")).lower()
                    for record in payload.get("papers", {}).values()
                )
            except Exception:
                state_review = False
        paper_failures = list(paper_failures or [])
        stale = self.output_root / "failure_report.txt"
        if stale.exists() and not paper_failures:
            stale.unlink()
            print("  (cleared stale failure_report.txt from an earlier failed run)")

        print()
        print("=" * 64)
        if paper_failures:
            _n_partial = sum(1 for p in paper_failures if p.get("kind") == "partial")
            _n_failed = len(paper_failures) - _n_partial
            _head = ("SOME PAPERS FAILED" if _n_failed
                     else "PARTIAL PAPERS")
            print(f"  *** RUN COMPLETE — {_head} ***  "
                  f"{len(self.stage_results)} stages, {total} checks executed")
            if _n_partial:
                print(f"  partial papers (questions skipped, saved work kept): {_n_partial}")
            print(f"  failed paper bundles: {len(paper_failures)}")
            if review_dirs or state_review:
                print(f"  review-required directories: {len(review_dirs)}"
                      + (" (plus a review-required state record)" if state_review else ""))
            if title:
                print(f"  —  {title}")
            print("  Successful papers were kept. Failed papers are listed in failed_papers_report.txt.")
            print("=" * 64)
            raise SystemExit(1)

        if review_dirs or state_review:
            print(f"  *** RUN COMPLETE — REVIEW REQUIRED ***  "
                  f"{len(self.stage_results)} stages, {total} checks passed")
            print(f"  review-required directories: {len(review_dirs)}"
                  + (" (plus a review-required state record)" if state_review else ""))
            if title:
                print(f"  —  {title}")
            print("  Crops were preserved safely; do not treat this batch as complete.")
            print("=" * 64)
            # A child worker communicates its safe-but-review verdict through
            # the committed output and WORKER-RESULT marker.  It must exit 0
            # so the parent can finish ER/audit stages and return the batch
            # contract's exit code 2.  Only the top-level runner exits 2.
            if worker:
                return 0
            raise SystemExit(2)

        print(f"  *** ALL GREEN ***  {len(self.stage_results)} stages, {total} checks passed" +
              (f"  —  {title}" if title else ""))
        print("=" * 64)
        raise SystemExit(0)


def ink_frac(img) -> float:
    a = np.asarray(img.convert("L"))
    return float((a < 200).mean())


def question_image(cq):
    """The crop's pixels, whether they are in memory or still spooled.

    The locked low-ram path and engine #2 both park crop payloads as PNGs and drop
    the rasters; a check that runs before _unspool (S2's sane-raster/ink checks) must
    load the spooled copy rather than index an empty list. Deliberately NOT cached:
    the whole point of the spool is that one crop is decoded at a time.
    """
    img = getattr(cq, "assembled_image", None)
    if img is not None:
        return img
    if getattr(cq, "images", None):
        return cq.images[0]
    spooled = getattr(cq, "_spool_png", None)
    if spooled:
        from PIL import Image as _Img
        with _Img.open(spooled) as im:
            return im.convert("RGB")
    return None


MS_MIN_HEIGHT_PX = 40  # RS-16: real one-line MS rows measure 50-78px @150dpi (0580 evidence)

# Cambridge occasionally retracts a question mid-paper and prints a one-line
# notice instead ("Due to an issue with question 14, the question has been
# removed from the question paper." — real 0625_s24_qp_21 Q14). Such a crop
# is legitimately tiny: the height floor must not fail it, or the whole paper
# bundle dies with exit code 1 for a normal paper.
_REMOVED_QUESTION_RE = re.compile(
    r"\bquestion\b[^.\n]{0,80}?\bremoved\b|\bremoved\b[^.\n]{0,80}?\bquestion\b",
    re.IGNORECASE,
)


def _is_removed_question(crop) -> bool:
    text = getattr(crop, "text", "") or ""
    return bool(_REMOVED_QUESTION_RE.search(text))


# A complete one-line question ("3  Identify two features of the set. [2]")
# legitimately crops below the 80px floor in any subject. It still has to
# carry its own mark allocation and ink, so a truncated or empty crop fails.
_ONE_LINER_MIN_PX = 50
_MARK_ALLOCATION_RE = re.compile(r"\[\s*\d{1,2}\s*\]\s*$")


def _is_complete_one_liner(crop, img) -> bool:
    text = (getattr(crop, "text", "") or "").strip()
    return (img.height >= _ONE_LINER_MIN_PX and len(text) >= 15
            and bool(_MARK_ALLOCATION_RE.search(text)))


def check_crop_list(check, label, crops, *, list_level=True, pixel=True,
                    min_height=MIN_HEIGHT_PX, min_width=1000):
    if list_level:
        check(f"{label}: at least 1 question", len(crops) >= 1, f"{len(crops)} questions")
        nums = [c.number_int for c in crops]
        check(f"{label}: question numbers unique", len(set(nums)) == len(nums),
              f"{sorted(nums)}")
    if not pixel:
        return
    # NOTE: engines may return content-width rasters (e.g. MS 1501px); the
    # locked OutputManager scales to exactly 2280 at save — the hard width
    # gate lives in S5 on the saved files. Here: sane-raster checks only.
    for c in crops:
        img = question_image(c)
        if img is None:
            check(f"{label} {c.question_number}: pixels available", False,
                  "no raster in memory and no spooled payload")
            continue
        check(f"{label} {c.question_number}: sane raster", img.width >= min_width,
              f"{img.size} (scaled to 2280 at save)")
        _removed = _is_removed_question(c)
        _one_liner = img.height < min_height and _is_complete_one_liner(c, img)
        check(f"{label} {c.question_number}: height >= {min_height}",
              img.height >= min_height or _removed or _one_liner,
              f"{img.size}{' (Cambridge removal notice — legitimately short)' if _removed else ''}"
              f"{' (complete one-line question with mark allocation)' if _one_liner else ''}")
        frac = ink_frac(img)
        check(f"{label} {c.question_number}: has ink", frac > INK_MIN_FRAC, f"dark={frac:.5f}")


def _vector_first_identity_alias(qp_info, spool_root: Path):
    """Return a temporary canonical-name alias for the locked vector cropper.

    ``paper_identifier.py`` accepts long Cambridge names, but the bundled
    vector-first implementation deliberately accepts only its compact
    ``code_sYY_qp_component`` identity.  The old low-RAM wrapper passed the
    long filename straight through, so S1 passed and S2 failed before any crop
    work (for example, ``0450 Business Studies March 2026 Question Paper 12``).
    A hard link normally avoids copying PDF bytes; copy2 is the Windows/filesystem
    fallback. The alias is removed immediately and never enters input/output.
    """
    source = Path(qp_info.file_path)
    code = str(getattr(qp_info, "syllabus_code", "") or "0000")
    season = str(getattr(qp_info, "season_letter", "") or "s").lower()
    # vector_first_cropper's identity grammar is [msw]; specimen is only an
    # identity hint here, so use a temporary s token while final output still
    # uses the real PaperInfo season.
    if season not in {"m", "s", "w"}:
        season = {"f": "m", "fm": "m", "j": "s", "mj": "s", "n": "w", "on": "w", "sp": "s"}.get(season, "s")
    yy = str(getattr(qp_info, "year_short", "") or "")[-2:]
    variant = str(getattr(qp_info, "variant", "") or "12")
    canonical = spool_root / f"{code}_{season}{yy}_qp_{variant}.pdf"
    try:
        if canonical.resolve() == source.resolve():
            return source, False
    except OSError:
        pass
    canonical.unlink(missing_ok=True)
    try:
        os.link(source, canonical)
    except (OSError, NotImplementedError):
        shutil.copy2(source, canonical)
    return canonical, True


def qp_crops_low_ram(qp_info, spool=None) -> list:
    """Built-in RAM-safe vector-first QP cropper.

    The crop algorithm is unchanged. The wrapper supplies a temporary compact
    identity alias when a real Cambridge filename is long/non-standard, then
    deletes the alias after the existing vector-first cropper returns.
    """
    from core.vector_first_cropper import CambridgeCropper

    spool_root = Path(spool or _spool_dir())
    crop_root = spool_root / "vector_qp"
    crop_root.mkdir(parents=True, exist_ok=True)
    vector_input, alias_created = _vector_first_identity_alias(qp_info, spool_root)
    try:
        analysis, results = CambridgeCropper(crop_root, quality=95).crop_qp(vector_input)
    finally:
        if alias_created:
            vector_input.unlink(missing_ok=True)
    out = []
    for result in results:
        paths = [str(Path(path)) for path in result.image_paths]
        if not paths:
            continue
        text = result.text or ""
        marks = sum(int(mm) for mm in re.findall(r"\[(\d+)\]", text))
        out.append(SimpleNamespace(
            question_number=f"Q{result.number}", number_int=result.number,
            paper_code=qp_info.full_code,
            images=[], assembled_image=None,
            text=text, marks=marks, pages=result.pages,
            needs_review=(result.status != "PASS"),
            qc_reasons=list(result.warnings),
            _spool_png=paths[0], _spool_paths=paths,
        ))
    print(f"    [low-ram] vector-first extracted {len(out)} questions "
          f"from {qp_info.file_path.name}; analysis={analysis.elapsed_ms:.1f}ms")
    return out


def low_ram_qp_with_fallback(qp_info, subject: str, cropping_engine, spool=None) -> list:
    """Use vector-first first, but rescue known 0580 weak layouts by retrying
    the locked production cropper before failing the paper.

    This does NOT change any crop algorithm: it only chooses between two
    existing, already-shipped crop paths when the low-ram metadata pass for
    IGCSE Mathematics 0580 returns an implausibly small set.
    """
    qp_cropped = qp_crops_low_ram(qp_info, spool=spool)
    if str(getattr(qp_info, "syllabus_code", "")) != "0580":
        return qp_cropped
    if len(qp_cropped) >= 5:
        return qp_cropped
    print(f"    [low-ram] 0580 fallback: vector-first yielded {len(qp_cropped)} question(s); retrying locked CroppingEngine")
    try:
        fallback = cropping_engine.process_paper(qp_info.file_path)
    except Exception as exc:
        print(f"    [low-ram] 0580 fallback failed closed: {exc}")
        return qp_cropped
    if fallback:
        print(f"    [low-ram] 0580 fallback recovered {len(fallback)} question(s) via locked CroppingEngine")
        return fallback
    print("    [low-ram] 0580 fallback produced 0 questions; keeping vector-first result")
    return qp_cropped


def _exercise_sequence_present(pdf_path) -> bool:
    """A lone locked-engine "question" on a paper built from Exercise 1..N
    headings is a stray number, not the paper's structure (0510_s15_qp_12)."""
    try:
        from core import exercise_heading_engine as _ex_engine
        return bool(_ex_engine.should_handle(pdf_path)[0])
    except Exception:
        return False


def qp_crop_dispatch(pdf_path, cropping_engine, *, low_ram: bool = False,
                     qp_info=None, subject: str = "", spool=None) -> list:
    """Board-aware QP crop entry point (2026-09-21).

    Before this existed, every paper in this runner was cropped by the locked CAIE
    engine regardless of board, and the verified AQA/Edexcel/SAT adapters were
    unreachable from the product. Routing:

    * board has a working adapter -> adapter + locked gold geometry
      (``adapters.pipeline_dispatch``);
    * board is CAIE or unidentified -> the EXISTING locked path, unchanged
      (low-ram vector-first when --low-ram, else CroppingEngine.process_paper);
    * board is a KNOWN non-CAIE board with no usable adapter -> raise
      ``BoardDispatchUnsupported`` so the paper fails loudly. Silently CAIE-cropping
      another board's paper is the specific failure this prevents.
    """
    from adapters.pipeline_dispatch import (
        BoardDispatchUnsupported, DispatchStatus, crop_question_paper,
    )

    # Spooled mode (--low-ram passes a spool): render one segment at a time so a
    # 120-question PSAT does not hold every crop in memory. The existing S2/S5
    # _unspool/_release loop already reloads and releases these payloads.
    result = crop_question_paper(pdf_path, spool_dir=spool)
    if result.status is DispatchStatus.ADAPTER_USED:
        print(f"    [dispatch] {result.board} adapter -> {len(result.questions)} question(s)")
        return result.questions
    if result.status is DispatchStatus.REVIEW_REQUIRED and result.board:
        raise BoardDispatchUnsupported(result)
    if result.status is DispatchStatus.REVIEW_REQUIRED:
        print(f"    [dispatch] board not identified ({result.reason}); "
              f"using the locked CAIE path (historical behaviour)")
    # ---- engine #2: OCR boundary engine, image-only documents only (2026-09-21) ----
    # The locked vector engine needs a text layer to split on; an image-only paper
    # has none, and S2 used to fail by name ("0 questions") with no way forward.
    # The OCR engine sits behind this same interface - it never runs for a document
    # that has text, never replaces the locked cropper, and REFUSES BY NAME
    # (OCR_NO_QUESTION_PAGE) instead of inventing boundaries. Its crops carry
    # needs_review/qc_reasons, which S5 turns into review_required/<reason>/.
    _ocr_engaged = False
    try:
        from core import ocr_boundary_engine as _ocr_engine
        _ocr_ok, _ocr_why = _ocr_engine.should_handle(pdf_path)
        if _ocr_ok:
            _ocr_engaged = True
            print(f"    [ocr] image-only document ({_ocr_why}); boundary engine engaged")
            _ocr_crops = _ocr_engine.crop_image_only_paper(
                pdf_path, paper_code=str(getattr(qp_info, "full_code", "") or ""),
                spool_dir=spool)
            if _ocr_crops:
                return _ocr_crops
            print(f"    [ocr] boundary engine verdict: {_ocr_engine.last_reason()}")
    except Exception as _ocr_exc:
        print(f"    [ocr] boundary engine unavailable ({type(_ocr_exc).__name__}: "
              f"{_ocr_exc}); continuing on the locked path")

    if _ocr_engaged:
        # The engine ENGAGED (the document really has no text layer) and refused by
        # name. Handing it on to the text-based path cannot help - the measured
        # outcome there is an unrelated ValueError ("cannot parse paper identity")
        # from a sub-engine that was never meant to see an image-only file. The
        # refusal is the honest result, and it stays in the log for the failure
        # report; the empty list is what S2 already knows how to report.
        print("    [ocr] refusing: an image-only document cannot be split by the "
              "text-based locked path - no crops produced")
        return []
    if low_ram:
        crops = low_ram_qp_with_fallback(qp_info, subject, cropping_engine, spool=spool)
    else:
        crops = cropping_engine.process_paper(pdf_path)
    if crops and not (len(crops) < 2 and _exercise_sequence_present(pdf_path)):
        return crops
    # ---- engine #3: RTL margin engine, right-to-left text-layer papers only (A17, 2026-09-22) ----
    # Arabic 0544 / Urdu 0539 carry their question numbers as the usual bold Arial
    # span but in the RIGHT margin; the locked engine only looks left, so the
    # locked path returns nothing. Engine #3 engages only after that empty
    # result and only for a document whose letters are >= 30% Arabic-script; it
    # feeds mirrored markers to the locked module's own renderer, so geometry,
    # width and WebP output are the locked behaviour. Refuses by name otherwise.
    try:
        from core import rtl_margin_engine as _rtl_engine
        _rtl_ok, _rtl_why = _rtl_engine.should_handle(pdf_path)
        if _rtl_ok:
            print(f"    [rtl] right-to-left document ({_rtl_why}); margin engine engaged")
            _rtl_crops = _rtl_engine.crop_rtl_paper(
                pdf_path, spool_dir=Path(spool) if spool else _spool_dir(),
                paper_code=str(getattr(qp_info, "full_code", "") or ""))
            if _rtl_crops:
                return _rtl_crops
            print(f"    [rtl] margin engine verdict: {_rtl_engine.last_reason()}")
        else:
            print(f"    [rtl] not engaged ({_rtl_why})")
    except Exception as _rtl_exc:
        print(f"    [rtl] margin engine unavailable ({type(_rtl_exc).__name__}: {_rtl_exc}); "
              f"keeping the locked path's empty result")
    # ---- engine #4: "Exercise N" heading papers (old 0510-style language papers) ----
    # Engages only after the locked path (and RTL) produced nothing and only for a
    # document with a left-margin Exercise 1..N heading sequence.
    try:
        from core import exercise_heading_engine as _ex_engine
        _ex_ok, _ex_why = _ex_engine.should_handle(pdf_path)
        if _ex_ok:
            print(f"    [exercise] exercise-structured document ({_ex_why}); heading engine engaged")
            _ex_crops = _ex_engine.crop_exercise_paper(
                pdf_path, spool_dir=Path(spool) if spool else _spool_dir(),
                paper_code=str(getattr(qp_info, "full_code", "") or ""))
            if _ex_crops:
                return _ex_crops
            print(f"    [exercise] heading engine verdict: {_ex_engine.last_reason()}")
    except Exception as _ex_exc:
        print(f"    [exercise] heading engine unavailable ({type(_ex_exc).__name__}: {_ex_exc}); "
              f"keeping the locked path's empty result")
    # ---- engine #5: un-numbered "Section N" papers (7184 P2 essay choices) ----
    if not crops:
        try:
            from core import exercise_heading_engine as _sec_engine
            _sec_ok, _sec_why = _sec_engine.should_handle_sections(pdf_path)
            if _sec_ok:
                print(f"    [section] section-structured document ({_sec_why}); engine engaged")
                _sec_crops = _sec_engine.crop_section_paper(
                    pdf_path, spool_dir=Path(spool) if spool else _spool_dir(),
                    paper_code=str(getattr(qp_info, "full_code", "") or ""))
                if _sec_crops:
                    return _sec_crops
        except Exception as _sec_exc:
            print(f"    [section] engine unavailable ({type(_sec_exc).__name__}: {_sec_exc})")
    # ---- engine #6 (idea 13, 2026-10-01): junk-font text layer, last resort ----
    # Every text engine found nothing (custom-font papers such as 9686/0539 P2
    # carry their numbers in an unreadable font). When Tesseract is installed,
    # the OCR boundary engine reads the rendered pages instead; its crops carry
    # OCR_* review reasons. Without Tesseract nothing changes.
    if not crops and not _ocr_engaged:
        try:
            from core import ocr_boundary_engine as _ocr_engine
            _ocr_ok, _ocr_why = _ocr_engine.ocr_available()
            if _ocr_ok:
                print("    [ocr] text engines found no questions; reading rendered pages with Tesseract")
                _ocr_crops = _ocr_engine.crop_image_only_paper(
                    pdf_path, paper_code=str(getattr(qp_info, "full_code", "") or ""),
                    spool_dir=spool)
                if _ocr_crops:
                    return _ocr_crops
                print(f"    [ocr] boundary engine verdict: {_ocr_engine.last_reason()}")
            else:
                print(f"    [ocr] no questions found and OCR unavailable ({_ocr_why}); "
                      f"install Tesseract to split junk-font papers")
        except Exception as _ocr_exc:
            print(f"    [ocr] fallback unavailable ({type(_ocr_exc).__name__}: {_ocr_exc})")
    return crops


def pair_low_ram(qp_list, ms_list, qp_info, ms_info, subject):
    """Question-number pairing producing match_questions-compatible objects."""
    ms_by_q = {m.number_int: m for m in ms_list}
    out = []
    for q in sorted(qp_list, key=lambda c: c.number_int):
        mo = ms_by_q.get(q.number_int)
        if mo is None:
            continue
        out.append(SimpleNamespace(
            question_number=q.question_number, number_int=q.number_int,
            qp=q, ms=mo,
            paper_code=f"{qp_info.syllabus_code}_{qp_info.season_letter}{qp_info.year_short}",
            full_qp_code=qp_info.full_code, full_ms_code=ms_info.full_code,
            year=qp_info.year, season=qp_info.season, variant=qp_info.variant,
            subject=subject.split("_")[0], paper_format=getattr(qp_info, "paper_format", ""),
        ))
    return out


def _is_tmpfs(path: Path) -> bool:
    """True when ``path`` lives on a RAM-backed filesystem (tmpfs/ramfs).

    Reads /proc/mounts and takes the LONGEST matching mount point, so a bind mount
    inside /tmp is judged by the filesystem that actually holds it.
    """
    try:
        target = str(Path(path).resolve())
        best, best_fs = "", ""
        with open("/proc/mounts", encoding="utf-8") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) < 3:
                    continue
                mount, fstype = parts[1].replace("\\040", " "), parts[2]
                if (target == mount or target.startswith(mount.rstrip("/") + "/")) \
                        and len(mount) >= len(best):
                    best, best_fs = mount, fstype
        return best_fs in ("tmpfs", "ramfs")
    except Exception:                                     # noqa: BLE001
        return False


def _spool_dir():
    """A DISK-backed directory for spooled crops (2026-09-21).

    This used to be plain ``tempfile.mkdtemp()``, i.e. /tmp - which on this box is
    tmpfs, so every spooled crop was pinned in RAM. Measured consequence: the real
    CAIE 9231 Winter 2025 QP+MS pair running ``--low-ram --workers 1`` was
    SIGKILLed by the kernel at S5 Q7 with the worker at 765 MB RSS, because the
    spool (up to ~12 assembled 2280x5500 PNGs) was competing for the same ~2 GB
    the worker needed. Spooling is supposed to REDUCE peak memory; on tmpfs it
    does the opposite of what its own comment claims.

    Order: ``GUARDED_SPOOL_DIR`` (explicit, used verbatim) -> the first
    disk-backed candidate -> the system temp dir as a last resort, loudly.
    """
    import os
    import tempfile

    explicit = os.environ.get("GUARDED_SPOOL_DIR")
    if explicit:
        # A16: a not-yet-existing explicit spool root used to surface as an S2
        # "stage crashed: FileNotFoundError" inside every worker; create it.
        Path(explicit).mkdir(parents=True, exist_ok=True)
        return Path(tempfile.mkdtemp(prefix="qb_spool_", dir=explicit))

    for candidate in ("/var/tmp", "/tmp"):
        base = Path(candidate)
        if base.is_dir() and not _is_tmpfs(base):
            return Path(tempfile.mkdtemp(prefix="qb_spool_", dir=str(base)))
    print("[guarded] WARNING: no disk-backed spool location found "
          "(/var/tmp and /tmp are RAM-backed); spooled crops will occupy RAM")
    return Path(tempfile.mkdtemp(prefix="qb_spool_"))


def _mem_trace_enabled() -> bool:
    return os.environ.get("GUARDED_MEM_TRACE") == "1"


def _mem_trace_big_arrays(label: str) -> None:
    """Diagnostics (GUARDED_MEM_TRACE=1): the large live numpy buffers.

    tracemalloc does not track numpy's data buffers, so a Python-level leak hunt
    shows ~0MB while RSS climbs. This lists what is actually retained.
    """
    if not _mem_trace_enabled():
        return
    try:
        import gc as _gc
        import numpy as _np
        arrays = [o for o in _gc.get_objects() if isinstance(o, _np.ndarray)]
        arrays.sort(key=lambda a: a.nbytes, reverse=True)
        total = sum(a.nbytes for a in arrays) / (1024.0 * 1024.0)
        top = ", ".join(f"{tuple(a.shape)}:{a.dtype}={a.nbytes / 1048576.0:.0f}MB"
                        for a in arrays[:4])
        print(f"    [mem-trace] {label}: numpy live {len(arrays)} arrays, "
              f"{total:.0f}MB total | top: {top}")
    except Exception as exc:
        print(f"    [mem-trace] {label}: array census failed ({exc})")


def _mem_trace(label: str) -> None:
    """Print RSS + retained-object growth (GUARDED_MEM_TRACE=1). Diagnostics only:
    used to find what accumulates across S5's per-question loop, where a real
    9231 QP+MS bundle reached anon-rss 1.3 GB and was OOM-killed."""
    if not _mem_trace_enabled():
        return
    import gc as _gc
    import sys as _sys
    objs = _gc.get_objects()
    counts = {}
    for o in objs:
        counts[type(o).__name__] = counts.get(type(o).__name__, 0) + 1
    top = ", ".join(f"{k}={v}" for k, v in sorted(counts.items(),
                                                   key=lambda kv: -kv[1])[:6])
    print(f"    [mem-trace] {label}: RSS {_rss_mb()} MB | objects {len(objs)} | {top}")
    _ = _sys.getsizeof(objs)  # keep `objs` reachable until after the print


def _spool_crops(crops, spool, tag):
    """RS-16 low-ram: park assembled pixel payloads as lossless PNGs so S2/S3
    peaks stay flat on multi-page structured papers (assembled question
    images can reach 2280x10000+). PNG is pixel-exact -> the webp bytes saved
    at S5 are unchanged. Verified byte-identical on the 0620 MCQ oracle."""
    n = 0
    for i, c in enumerate(crops or []):
        img = getattr(c, "assembled_image", None)
        if img is None and getattr(c, "images", None):
            img = c.images[0]
        if img is None:
            continue
        p = spool / f"{tag}_{i:03d}.png"
        img.save(p, format="PNG")
        c._spool_png = str(p)
        c.assembled_image = None
        if getattr(c, "images", None):
            c.images = []
        n += 1
    if n:
        print(f"    [low-ram] spooled {n} {tag} crop payload(s) -> {spool.name}/ (PNG pixel-exact)")
    gc.collect()


def _unspool(crop):
    p = getattr(crop, "_spool_png", None) if crop is not None else None
    if p and getattr(crop, "assembled_image", None) is None:
        from PIL import Image as _Img
        with _Img.open(p) as im:
            img = im.convert("RGB")
        crop.assembled_image = img
        if not getattr(crop, "images", None):
            crop.images = [img]


def _heap_trim():
    """RS-16/17: return freed glibc arena pages to the OS so a question's
    released pixels actually drop RSS instead of lingering as reusable arena.
    Best-effort no-op off glibc."""
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


def _release(crop):
    if crop is not None and getattr(crop, "_spool_png", None):
        crop.assembled_image = None


# ---------------------------------------------------------------------------
# Question-level batching (2026-09-21, user-authorised mode). Opt-in:
# --batch-size N / GUARDED_BATCH_SIZE=N. With it OFF, S5 behaves exactly as it
# did before this block existed (one batch = the historic semantics).
#
# Why batching rather than a leak fix: tracemalloc measured ~0MB/question of
# Python retention and gc.get_objects() is flat, but RSS grows ~50MB/question
# (C-arena retention malloc_trim does not return) and one measured question
# (2280x16351 px) needs several live RGBA copies at once in the save path.
# Batching bounds the BASELINE that a later heavy question lands on, and the
# affordability guard turns an unfinishable question into a NAMED skip instead
# of an OOM kill.
# ---------------------------------------------------------------------------
_SAVE_BYTES_PER_PX = 4.0     # RGBA working copy
# Copies of the crop live at once during save (decode + resize + encode +
# encoder scratch). Calibrated against the measured kill, not guessed: the
# 9231 Winter 2025 Q7 save died with +547MB of RSS over its loaded state, and
# 547MB / (2280x16351x4 bytes) = 3.7 -> use 4.0.
_SAVE_COPY_FACTOR = 4.0
_MEM_RESERVE_MB = 256        # never spend the box's last 256MB
# Decoding a spooled crop into RAM costs ~3 bytes/px (RGB), and the classify
# step's own scratch is bounded by the diagram-evidence cap (see
# core/diagram_evidence.py, which used to allocate ~900MB of float64 scratch on a
# 16351px-tall crop and got the worker OOM-killed there).
_LOAD_BYTES_PER_PX = 3.0
_CLASSIFY_SCRATCH_MB = 96.0
# One process may not grow past this. Calibrated from two observed outcomes on
# the 1984MB reference box: a worker at anon-rss 1313MB was OOM-killed
# (global_oom, dmesg), while workers at ~1000MB finished. Override on a bigger
# machine with GUARDED_MAX_WORKER_RSS_MB.
_MAX_WORKER_RSS_MB = int(os.environ.get("GUARDED_MAX_WORKER_RSS_MB", "1150") or 1150)
_BATCH_WAIT_S = float(os.environ.get("GUARDED_BATCH_WAIT_S", "180") or 180)


def _total_ram_mb() -> int | None:
    """MemTotal from /proc/meminfo, in MB (None off Linux)."""
    try:
        with open("/proc/meminfo", encoding="ascii") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) // 1024
    except Exception:
        pass
    try:
        import psutil
        return int(psutil.virtual_memory().total // (1024 * 1024))
    except Exception:
        return None


def batch_size(args=None) -> int:
    """Resolve the question batch size: CLI flag first, then the env var, else 0.

    0 means "single batch" - the historic one-shot save semantics.
    """
    if args is not None:
        v = getattr(args, "batch_size", None)
        if v is not None and int(v) > 0:
            return int(v)
    raw = (os.environ.get("GUARDED_BATCH_SIZE") or "").strip()
    if not raw:
        return 0
    try:
        return max(0, int(raw))
    except ValueError:
        return 0


def batch_slices(n_items: int, batch_size_n: int) -> list:
    """Half-open [start, stop) ranges splitting ``n_items`` into batches.

    ``batch_size_n <= 0`` returns one range covering everything, so callers stay
    branch-free and the off state is provably identical to the old behaviour.
    """
    if n_items <= 0:
        return []
    if batch_size_n <= 0:
        return [(0, n_items)]
    return [(s, min(s + batch_size_n, n_items)) for s in range(0, n_items, batch_size_n)]


def crop_pixels(crop):
    """(width, height) of a crop WITHOUT decoding its pixels, or None.

    Spooled crops answer from the PNG header alone (flat-RAM discipline); crops
    already in memory answer from the loaded image.
    """
    if crop is None:
        return None
    size = getattr(getattr(crop, "assembled_image", None), "size", None)
    if size:
        return int(size[0]), int(size[1])
    p = getattr(crop, "_spool_png", None)
    if p:
        try:
            from PIL import Image as _Img
            with _Img.open(p) as im:      # header only; no pixel decode
                return int(im.size[0]), int(im.size[1])
        except Exception:
            return None
    return None


def save_transient_mb(*crops) -> float:
    """Worst-case live bytes the save path needs for these crops, in MB.

    Model fitted to the measured case (9231 Winter 2025 Q7 = 2280x16351 px, which
    needed ~450-500MB of transient on top of a ~520MB baseline).
    """
    px = 0
    for c in crops:
        wh = crop_pixels(c)
        if wh:
            px += wh[0] * wh[1]
    return px * _SAVE_BYTES_PER_PX * _SAVE_COPY_FACTOR / (1024.0 * 1024.0)


def save_affordable(m, *, avail_mb=None, rss_mb=None, include_load=False):
    """Is this question's save transient affordable RIGHT NOW? -> (ok, detail)

    The tighter of two independent limits decides: what the kernel can still hand
    out (MemAvailable) and what this process's own address space allows (total
    RAM minus its own RSS). Both keep _MEM_RESERVE_MB spare. Unknown headroom
    returns True with the estimate in the detail: never block on a broken
    /proc/meminfo, and never pretend to know.
    """
    est = save_transient_mb(getattr(m, "qp", None), getattr(m, "ms", None))
    if include_load:
        # Pricing the WHOLE question, checked before any of its pixels are
        # touched: decode into RAM + the classifier's bounded scratch + the save
        # transient. The earlier guard only priced the save and therefore never
        # ran on the question that actually died - the kernel killed the worker
        # in classify, before the save was ever reached.
        px = 0.0
        for _c in (getattr(m, "qp", None), getattr(m, "ms", None)):
            _wh = crop_pixels(_c)
            if _wh:
                px += _wh[0] * _wh[1]
        est += px * _LOAD_BYTES_PER_PX / (1024.0 * 1024.0) + _CLASSIFY_SCRATCH_MB
    avail = _mem_available_mb() if avail_mb is None else avail_mb
    rss = _rss_mb() if rss_mb is None else rss_mb
    total = _total_ram_mb()
    predicted = rss + est
    if predicted > _MAX_WORKER_RSS_MB:
        return False, (f"est {est:.0f}MB on top of RSS {rss}MB = {predicted:.0f}MB, "
                       f"over the {_MAX_WORKER_RSS_MB}MB per-process ceiling "
                       f"(a worker past this was OOM-killed here)")
    if avail is None or total is None:
        return True, f"est {est:.0f}MB (headroom unknown - attempting)"
    own_room = total - rss - _MEM_RESERVE_MB
    room = min(avail, own_room)
    detail = (f"est {est:.0f}MB -> predicted RSS {predicted:.0f}MB "
              f"(ceiling {_MAX_WORKER_RSS_MB}MB); room {room:.0f}MB "
              f"(MemAvailable {avail}MB, RSS {rss}MB of {total}MB)")
    return est <= room, detail


def batch_progress_path(args, base_key: str):
    """Per-paper batching ledger. Lives under paper_failures/ (a registered
    auxiliary tree) so it survives validation and output cleanup."""
    root = Path(getattr(args, "output", "output")) / "paper_failures" / str(base_key)
    return root / "batch_progress.jsonl"


def batch_progress_read(args, base_key: str) -> dict:
    """question -> last recorded entry for that question (later lines win)."""
    out = {}
    p = batch_progress_path(args, base_key)
    if not p.exists():
        return out
    try:
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except Exception:
                continue
            q = str(entry.get("question", ""))
            if q:
                out[q] = entry
    except Exception:
        return {}
    return out


def batch_progress_append(args, base_key: str, entry: dict) -> None:
    """Append one jsonl event; never fatal."""
    import time as _t
    p = batch_progress_path(args, base_key)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        entry = dict(entry)
        entry.setdefault("at", _t.strftime("%Y-%m-%d %H:%M:%S"))
        with p.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except OSError as exc:
        print(f"    [batch] progress write failed ({exc})")


def batch_skip_question(args, base_key: str, m, why: str, where: str) -> None:
    """Record + announce one unaffordable question. Never raises, never writes
    pixels: the write IS the transient that cannot be afforded."""
    batch_progress_append(args, base_key, {
        "question": str(m.question_number),
        "status": "skipped_insufficient_memory",
        "estimate_mb": round(save_transient_mb(getattr(m, "qp", None),
                                               getattr(m, "ms", None)), 1),
        "batch_size": batch_size(args),
        "checked_at": where,
        "detail": why,
    })
    print(f"SKIP  {base_key} {m.question_number}: cannot afford to process this "
          f"question safely - {why}")
    print(f"    [batch] {base_key} {m.question_number}: not written ({where}); re-run with "
          f"--batch-size 1 or on a bigger box (batch_progress.jsonl records it)")


def batch_wait_for_room(base_key: str, done: int, total: int, need_mb: float) -> float:
    """Between batches: wait (bounded) until the next question can be afforded.

    A timeout is NOT fatal - the per-question affordability guard decides what to
    do, which keeps a slow box from being reported as a broken run.
    """
    import time as _t
    avail = _mem_available_mb()
    if avail is None or avail >= need_mb:
        return 0.0
    t0 = _t.time()
    print(f"    [batch] {base_key}: {done}/{total} saved; headroom {avail}MB < "
          f"{need_mb:.0f}MB - waiting up to {_BATCH_WAIT_S:.0f}s ...")
    while _t.time() - t0 < _BATCH_WAIT_S:
        _t.sleep(1.0)
        gc.collect()
        _heap_trim()
        avail = _mem_available_mb()
        if avail is None or avail >= need_mb:
            print(f"    [batch] {base_key}: headroom OK ({avail}MB) - next batch")
            return _t.time() - t0
    print(f"    [batch] {base_key}: still {avail}MB after {_BATCH_WAIT_S:.0f}s; "
          f"per-question guard decides")
    return _t.time() - t0


def run_paper_stages(gate, args, base_key, qp_info, ms_info, subject, config, state,
                     cropping_engine, ms_cropping_engine, matcher, output_mgr,
                     insert_info=None, ci_info=None):
    """S2 -> S3 -> S4-pair -> S5 for ONE paper bundle. Returns saved count.
    insert_info (optional): source booklet processed after S5.
    ci_info (optional): confidential instructions copied intact to a
    paper-level ``_confidential`` sidecar; never sent through the cropper."""
    from core.classifier import TopicClassifier

    # Retain the original source path solely for read-only substantive MS text
    # extraction. The locked crop path below remains untouched, including any
    # rotation cache it legitimately uses for image processing.
    _raw_ms_source_path = Path(ms_info.file_path) if ms_info is not None else None

    state.register_paper(base_key, qp_path=str(qp_info.file_path),
                         ms_path=str(ms_info.file_path) if ms_info else None, er_path=None)
    # ROT-1 (rotation-handling round): sideways-display normalization.
    # Only pages whose DISPLAYED text runs vertically (/Rotate set on
    # upright-authored content) are re-baked to upright rotation=0 copies
    # under <output>/.rotcache/; Cambridge-style rotated files and all
    # rotation=0 inputs pass through UNTOUCHED (proven: detector votes
    # 142:16 sideways on the case-A probe, 0:39..7:130 on real ms_42).
    # Provenance above deliberately keeps the ORIGINAL paths.
    from core.page_rotation import ensure_upright
    _rotcache = Path(args.output) / ".rotcache"
    qp_info.file_path, _ = ensure_upright(qp_info.file_path, _rotcache)
    if ms_info is not None:
        ms_info.file_path, _ = ensure_upright(ms_info.file_path, _rotcache)
    if state.should_skip(base_key):
        print(f"    [guarded] RESUME-SKIP {base_key}")
        # 0, not -1: the parent only parses a non-negative WORKER-RESULT.
        # A skip is success with nothing new to save, not a failed paper.
        return 0
    state.mark_processing(base_key)
    # We reached processing because the bundle was new or its inputs changed;
    # permit the writer to replace a stale placement for the same logical
    # question instead of treating it as a second physical question.
    try:
        output_mgr.replace_existing = True
    except Exception:
        pass
    # Full-auto is a *classification* policy only: a question with a valid
    # QP/MS pair (or a valid MCQ grid letter) may receive an automatic best-fit
    # topic when its evidence is weak. It never permits a structured QP-only
    # placeholder: those real QP crops stay under review_required_no_ms.
    # `--no-full-auto` additionally restores fail-closed classification routing.
    _full_auto_eff = (
        bool(getattr(args, "full_auto", True))
        or bool(getattr(args, "trust_self", False))
    ) and not bool(getattr(args, "no_full_auto", False))
    _audit_path = _classification_audit_path(args, base_key)
    try:
        _audit_path.parent.mkdir(parents=True, exist_ok=True)
        _audit_path.write_text("", encoding="utf-8")
    except OSError as _audit_exc:
        print(f"    [audit] could not initialize {_audit_path}: {_audit_exc}")

    # ---------- S2 QP crop ----------
    _spool = None

    def s2(check):
        if args.low_ram:
            nonlocal _spool
            _spool = _spool_dir()
            qp_cropped = qp_crop_dispatch(qp_info.file_path, cropping_engine,
                                          low_ram=True, qp_info=qp_info,
                                          subject=subject, spool=_spool)
            _min_h = qp_min_height_px(qp_info)
            # list-level gates on metadata; pixel gates reload ONE crop at a
            # time from the pixel-exact spool (flat RAM, same texts/semantics)
            check_crop_list(check, f"QP {qp_info.full_code}", qp_cropped, pixel=False,
                            min_height=_min_h)
            for _c in qp_cropped:
                _unspool(_c)
                check_crop_list(check, f"QP {qp_info.full_code}", [_c], list_level=False,
                                min_height=_min_h)
                _release(_c)
            gc.collect()
        else:
            qp_cropped = qp_crop_dispatch(qp_info.file_path, cropping_engine)
            check_crop_list(check, f"QP {qp_info.full_code}", qp_cropped,
                            min_height=qp_min_height_px(qp_info))
        for c in qp_cropped:
            check(f"QP {qp_info.full_code} {c.question_number}: text extracted",
                  bool((c.text or "").strip()), f"{len(c.text or '')} chars")
        return qp_cropped

    qp_cropped = gate.run_stage("S2", f"{ALL_STAGES[2][1]} [{qp_info.full_code}]", s2)
    gc.collect()

    # ---------- S3 MS crop ----------
    # Mega-spec Fix 4 (2026-08-12): the MS/QP branch decision comes from the
    # strategy registry (profile + component), not an inline format string
    # check. Practical/essay components surface REVIEW_REQUIRED here instead of
    # being fed to the structured parser.
    from core.strategies import (StrategyUnsupported, select_ms_strategy,
                                 strategy_plan_for_paper)
    _strategy_issue = None
    try:
        _ms_strategy = select_ms_strategy(qp_info, ms_info)
        _plan = strategy_plan_for_paper(qp_info)
        print(f"    [strategy] {base_key}: {_plan.name} — {_plan.reason}")
        if getattr(_plan, "kind", "") == "unsupported":
            _strategy_issue = _plan.reason
    except StrategyUnsupported as _exc:
        _ms_strategy = None
        _strategy_issue = _exc.review_reason

    if _strategy_issue:
        print(f"    [strategy] {base_key}: {_strategy_issue}")
        if _full_auto_eff:
            # The QP cropper is still useful when this MS grammar has no
            # validated splitter. Drop only the unusable MS leg; S5 will retain
            # structured QP crops as review_required_no_ms rather than inventing
            # an MS image or text placeholder.
            print(f"    [strategy] {base_key}: no validated MS strategy -> "
                  "QP preserved for review; no fabricated MS crop")
            ms_info = None
            _ms_strategy = None
        else:
            state.mark_review_required(base_key, _strategy_issue)
            state.save(Path(args.output))
            gate._abort("S3", f"strategy selection [{base_key}]",
                        [], [("supported strategy exists", _strategy_issue)])
    _is_mcq = _ms_strategy is not None and _ms_strategy.name == "mcq_ms_grid"
    _mcq_answers = None
    # P3 (2026-10-01): hoisted so the paper record can flag a shared
    # levels/grid scheme attached to every question (0475 Literature).
    _ms_generic = False
    if ms_info is None:
        # Overseer RULE 2: no MS paper at all - QP-only mode
        print(f"    [guarded] {base_key}: no MS supplied - QP-only mode")
        ms_cropped = []
    elif _is_mcq:
        # IGCSE paper-format round (user decision mcq_ms=letters): MCQ mark
        # schemes carry a bare answer grid — extract letters, crop nothing.
        def s3(check):
            answers = ms_cropping_engine.extract_mcq_answers(ms_info.file_path)
            # In fail-closed mode an empty grid is a hard identity failure. In
            # full-auto mode only a known MCQ component may retain its QP with
            # the explicitly permitted MS_UNAVAILABLE answer-grid sidecar.
            check("MCQ answer grid extracted (fail-closed on empty)",
                  len(answers) > 0 or _full_auto_eff,
                  f"{len(answers)} answers"
                  + ("; full-auto QP fallback" if not answers and _full_auto_eff else ""))
            exp = getattr(qp_info, "expected_question_count", None)
            if exp is not None:
                # counts=advisory (user decision): measured, never a gate
                print(f"    [advisory] {base_key}: expected {exp} MCQ grid answers, parsed {len(answers)}")
            return answers

        _mcq_answers = gate.run_stage("S3", f"MCQ answer grid [{ms_info.full_code}]", s3)
        if _full_auto_eff and not _mcq_answers:
            print(f"    [guarded] {base_key}: empty known-MCQ grid -> "
                  "MCQ QP retention with permitted MS_UNAVAILABLE sidecars")
            ms_info = None
            _is_mcq = False
        ms_cropped = []
    else:
        def s3(check):
            nonlocal _spool
            nonlocal _ms_generic
            # Give the structured splitter the already-proven QP top-level
            # question numbers.  A missing trailing mark-scheme question is
            # then diagnosed explicitly instead of disappearing silently.
            _expected_ms_questions = [c.number_int for c in qp_cropped]
            # ---- board dispatch (A3, 2026-09-21) ---------------------------
            # A non-CAIE mark scheme never reaches the locked CAIE MS engine or
            # the CAIE-only portrait splitters below: that is how another board's
            # mark scheme silently becomes a Cambridge one. CAIE falls through to
            # that engine unchanged; an unidentified document keeps the
            # historical behaviour, loudly, exactly as the QP leg does.
            from adapters.ms_dispatch import crop_mark_scheme
            from adapters.pipeline_dispatch import DispatchStatus as _DispatchStatus

            _ms_dispatch = crop_mark_scheme(
                ms_info.file_path,
                expected_questions=_expected_ms_questions,
                spool_dir=_spool,
            )
            if _ms_dispatch.status is _DispatchStatus.ADAPTER_USED:
                print(f"    [ms-dispatch] {ms_info.file_path.name}: "
                      f"{_ms_dispatch.board} adapter -> "
                      f"{len(_ms_dispatch.questions)} mark-scheme question(s)")
                if _spool is not None:
                    # Same flat-peak discipline as S2: list gates on metadata,
                    # pixel gates one crop at a time off the pixel-exact spool.
                    check_crop_list(check, f"MS {ms_info.full_code}",
                                    _ms_dispatch.questions, pixel=False,
                                    min_height=MS_MIN_HEIGHT_PX)
                    for _c in _ms_dispatch.questions:
                        _unspool(_c)
                        check_crop_list(check, f"MS {ms_info.full_code}", [_c],
                                        list_level=False, min_height=MS_MIN_HEIGHT_PX)
                        _release(_c)
                    gc.collect()
                else:
                    check_crop_list(check, f"MS {ms_info.full_code}",
                                    _ms_dispatch.questions, min_height=MS_MIN_HEIGHT_PX)
                return _ms_dispatch.questions
            if _ms_dispatch.board and _ms_dispatch.status is _DispatchStatus.REVIEW_REQUIRED:
                print(f"    [ms-dispatch] {ms_info.file_path.name}: {_ms_dispatch.reason}")
                print(f"    [ms-dispatch] {ms_info.file_path.name}: mark scheme left "
                      f"uncropped -> QP-only review_required/no_markscheme")
                return []
            if _ms_dispatch.board is None:
                print(f"    [ms-dispatch] WARNING {ms_info.file_path.name}: board not "
                      f"identified ({_ms_dispatch.reason}); using the locked CAIE MS "
                      f"engine (historical behaviour)")
            else:
                print(f"    [ms-dispatch] {ms_info.file_path.name}: CAIE -> locked "
                      f"MSCroppingEngine")
            # A20 fat-MS handling (budgets: core/ms_cropping_engine header).
            # The locked engine renders every page (~17.2MB/page at dpi=150)
            # and a 77-page MS needs ~1.4GB engine-alone: it was SIGKILLed at
            # S3 entry RSS 315MB. Park QP pixels first (pixel-exact spool;
            # S4/S5 unspool as designed); low-ram mode already spooled (no-op).
            from core.ms_cropping_engine import (
                MS_FAT_REFUSE_MIN_PAGES, MS_FAT_SPOOL_MIN_PAGES,
                ms_pdf_page_count)
            _ms_pages = ms_pdf_page_count(ms_info.file_path)
            if _ms_pages > MS_FAT_REFUSE_MIN_PAGES:
                print(f"    [ms-fat] {ms_info.file_path.name}: {_ms_pages} pages "
                      f"exceeds {MS_FAT_REFUSE_MIN_PAGES} — beyond this box even "
                      f"stepped down; routing graceful QP-only review (no crash)")
                return []
            if _ms_pages > MS_FAT_SPOOL_MIN_PAGES:
                if _spool is None:
                    _spool = _spool_dir()
                print(f"    [low-ram] {_ms_pages}-page MS: parking "
                      f"{len(qp_cropped)} QP crop(s) before the locked MS render")
                _spool_crops(qp_cropped, _spool, f"{base_key}_qp_prems")
                _heap_trim()
            ms_cropped = ms_cropping_engine.process_paper(
                ms_info.file_path,
                expected_questions=_expected_ms_questions,
            )
            _expected = [c.number_int for c in qp_cropped]
            _found = {c.number_int for c in ms_cropped}
            if _found != set(_expected):
                # Gold remains first.  If it returns a partial set (the older
                # 0580 portrait table has one header page and continuation
                # pages without headers), do not accept the partial MS: try a
                # QP-proven portrait-column splitter that must recover the
                # complete number set.
                from core.legacy_ms_split import (
                    split_portrait_column_ms,
                    split_legacy_portrait_ms,
                    split_page_per_question_ms,
                    split_question_heading_ms,
                    split_generic_level_ms,
                )
                from core.ms_cropping_engine import MSCroppedQuestion

                print(f"    [MS-legacy] gold coverage {sorted(_found)} != "
                      f"QP coverage {_expected} — trying portrait-column fallback")
                _pieces, _diag = split_portrait_column_ms(
                    ms_info.file_path, dpi=ms_cropping_engine.dpi,
                    expected_top_numbers=_expected)
                if not _pieces:
                    # RS-16 A-Level portrait grammar fallback.  This remains
                    # strict 1..N + exact QP identity and therefore cannot turn
                    # a random number column into a mark scheme.
                    _pieces, _diag = split_legacy_portrait_ms(
                        ms_info.file_path, dpi=ms_cropping_engine.dpi,
                        expected_top_numbers=_expected)
                if not _pieces:
                    # Older boxed theory schemes with no column header: one
                    # question per page, page-leading label == QP sequence and
                    # a [Total] line per question, else refused.
                    _pp, _pp_diag = split_page_per_question_ms(
                        ms_info.file_path, dpi=ms_cropping_engine.dpi,
                        expected_top_numbers=_expected)
                    if _pp:
                        _pieces, _diag = _pp, _pp_diag
                _ms_generic = False
                if not _pieces:
                    # Sectioned schemes: a bold "Question N" heading opens each
                    # question's material (0500 P1); headings == QP sequence.
                    _qh, _qh_diag = split_question_heading_ms(
                        ms_info.file_path, dpi=ms_cropping_engine.dpi,
                        expected_top_numbers=_expected)
                    if _qh:
                        _pieces, _diag = _qh, _qh_diag
                if not _pieces:
                    # Generic level-descriptor scheme with NO question content
                    # (0475 Literature): the shared band table is every
                    # question's mark scheme.
                    _gl, _gl_diag = split_generic_level_ms(
                        ms_info.file_path, dpi=ms_cropping_engine.dpi,
                        expected_top_numbers=_expected)
                    if _gl:
                        _pieces, _diag = _gl, _gl_diag
                        _ms_generic = True
                if _pieces:
                    ms_cropped = [MSCroppedQuestion(
                        question_number=f"Q{q}", number_int=q,
                        paper_code=ms_info.file_path.stem,
                        images=[img], assembled_image=img,
                        text=(f"Generic level descriptors (shared by every question) for question {q}"
                              if _ms_generic else f"Mark scheme for question {q}"),
                        marks=0, pages=[])
                        for q, img in sorted(_pieces.items())]
                    print(f"    [MS-legacy] portrait fallback produced {len(ms_cropped)} crops "
                          f"(QP-validated exact set; sig: "
                          f"{_diag.split_notes[0] if _diag.split_notes else '?'})")
                else:
                    print(f"    [MS-legacy] portrait fallbacks refuse "
                          f"{_diag.warnings[-1][:120] if _diag.warnings else ''} — fail-closed stands")
            # RS-59 (2026-08-16): an essay-style mark scheme (e.g. Sociology
            # 9699 "Question | Answer | Marks" tables with sub-part markers
            # 2(a)/2(b) and level-of-response descriptors) can defeat gold AND
            # both portrait fallbacks.  Failing the WHOLE paper there is worse
            # than honest QP-only routing: keep the QP crops and let S4/S5
            # route every question to review_required/no_markscheme for human
            # fixing (fail-closed, never fabricating an MS crop).
            if not ms_cropped:
                print(f"    [MS-legacy] {ms_info.file_path.name}: mark scheme "
                      f"unsplittable (essay/level-descriptor format) — "
                      f"continuing QP-only -> review_required/no_markscheme")
                return ms_cropped
            # A20: the sane-raster floors are content-width calibrated at the
            # historical dpi=150; a stepped-down engine (fat MS) renders the
            # same content fewer pixels, so scale the floors with dpi. The
            # pass/fail boundary is then dpi-invariant (whatever passes at
            # 150 passes at 100 and vice versa); dpi=150 computes the exact
            # historical floors, so all existing papers are unaffected.
            _dpi_scale = getattr(ms_cropping_engine, "dpi", 150) / 150.0
            check_crop_list(check, f"MS {ms_info.full_code}", ms_cropped,
                            min_height=int(MS_MIN_HEIGHT_PX * _dpi_scale),
                            min_width=int(1000 * _dpi_scale))
            return ms_cropped

        if args.low_ram:
            print(f"    [mem] S3 entry RSS {_rss_mb()} MB")  # RS-16 trace
        ms_cropped = gate.run_stage("S3", f"{ALL_STAGES[3][1]} [{ms_info.full_code}]", s3)

    # In low-RAM mode question pixels stay spooled. S4 validates identity and
    # question-number coverage from metadata; S5 reloads one crop at a time.
    # Do not unspool the whole paper just to run pair validation.

    # ---------- S4 pair coverage ----------
    def s4b(check):
        if _is_mcq:
            # IGCSE paper-format round: pair each crop with its grid letter
            # (ms=None + ms_answer=letter — the letter IS the mark scheme).
            stubs = [SimpleNamespace(question_number=c.question_number, number_int=c.number_int,
                                     qp=c, ms=None, ms_answer=_mcq_answers.get(c.number_int),
                                     paper_code=base_key,
                                     full_qp_code=qp_info.full_code,
                                     full_ms_code=(
                                         None
                                         if (_full_auto_eff and _mcq_answers.get(c.number_int) is None)
                                         else ms_info.full_code
                                     ),
                                     year=qp_info.year, season=qp_info.season,
                                     variant=qp_info.variant, subject=subject.split("_")[0],
                                     paper_format=getattr(qp_info, "paper_format", ""))
                     for c in qp_cropped]
            valid = [s for s in stubs if s.ms_answer is not None]
            answered = {s.number_int for s in valid}
            unmatched_qp = [c for c in qp_cropped if c.number_int not in answered]
            check("MCQ: every cropped QP question paired with a grid letter or review_required-bound",
                  len(valid) + len(unmatched_qp) == len(qp_cropped),
                  f"answered {len(valid)} + unanswered {len(unmatched_qp)} = {len(qp_cropped)}")
            qn = [m.question_number for m in valid]
            check("MCQ: no question paired twice", len(set(qn)) == len(qn), qn)
            if unmatched_qp:
                print(f"    [info] {base_key}: {len(unmatched_qp)} MCQ question(s) without grid letter -> review_required/no_markscheme")
            return valid, unmatched_qp
        if ms_info is None:
            from types import SimpleNamespace as _SN0
            stubs = [_SN0(question_number=c.question_number, number_int=c.number_int,
                          qp=c, ms=None, paper_code=base_key,
                          full_qp_code=qp_info.full_code, full_ms_code=None,
                          year=qp_info.year, season=qp_info.season,
                          variant=qp_info.variant, subject=subject.split("_")[0],
                          paper_format=getattr(qp_info, "paper_format", ""))
                     for c in qp_cropped]
            check("QP-only mode: every QP question staged for review_required", True,
                  f"{len(stubs)} questions")
            return stubs, []
        if args.low_ram:
            matched = pair_low_ram(qp_cropped, ms_cropped, qp_info, ms_info, subject)
            # Pairing is by exact bundle identity + question number. Pixel
            # validation is intentionally deferred to S5, where one spooled
            # crop is loaded at a time.
            valid = [m for m in matched
                     if m.qp is not None and m.ms is not None
                     and m.qp.number_int == m.ms.number_int]
            errors = [] if len(valid) == len(matched) else ["metadata pair mismatch"]
        else:
            matched = matcher.match_questions(qp_cropped, ms_cropped, qp_info, ms_info, subject)
            valid, errors = matcher.validate_pairs(matched)
        check("no pair-validation errors", len(errors) == 0 or _full_auto_eff,
              (str(errors) if errors else "clean")
              + ("; unmatched items will follow the strict per-format routing policy" if errors and _full_auto_eff else ""))
        paired_ints = {m.number_int for m in valid}
        unmatched_qp = [c for c in qp_cropped if c.number_int not in paired_ints]
        check("every cropped QP question accounted (paired or review_required-bound)",
              len(valid) + len(unmatched_qp) == len(qp_cropped),
              f"paired {len(valid)} + unmatched {len(unmatched_qp)} = {len(qp_cropped)}")
        if unmatched_qp:
            print(f"    [info] {base_key}: {len(unmatched_qp)} QP question(s) without MS twin -> review_required/no_markscheme")
        qn = [m.question_number for m in valid]
        check("no question paired twice", len(set(qn)) == len(qn), qn)
        return valid, unmatched_qp

    _paired, _unmatched_qp = gate.run_stage("S4", f"pair coverage [{base_key}]", s4b)
    from types import SimpleNamespace as _SNQ
    valid_matched = list(_paired) + [
        _SNQ(question_number=_c.question_number, number_int=_c.number_int,
             qp=_c, ms=None, paper_code=base_key,
             full_qp_code=qp_info.full_code,
             full_ms_code=(
                 None
                 if (_full_auto_eff and _is_mcq
                      and _mcq_answers.get(_c.number_int) is None)
                 else (ms_info.full_code if ms_info else None)
             ),
             year=qp_info.year, season=qp_info.season,
             variant=qp_info.variant, subject=subject.split("_")[0],
             paper_format=getattr(qp_info, "paper_format", ""))
        for _c in _unmatched_qp
    ]
    # F4/F6 capture: collapse the QC verdict + crop count to scalars BEFORE
    # freeing the image lists (RAM hygiene), so the completion gate can read
    # them afterwards.
    _qp_crop_count = len(qp_cropped)
    _qc_flagged_qs = [c.question_number for c in qp_cropped
                      if getattr(c, "needs_review", False)]
    if _spool is not None:
        # S4 needed the real pixels (validate_pairs); park them again so S5
        # saves one question at a time instead of holding all payloads.
        _spool_crops([m.qp for m in valid_matched if getattr(m, "qp", None) is not None],
                     _spool, "qp2")
        _spool_crops([m.ms for m in valid_matched if getattr(m, "ms", None) is not None],
                     _spool, "ms2")
    # P3 checks run after S5; keep only the light facts they need.
    _p3_qp = [SimpleNamespace(question_number=getattr(c, "question_number", ""),
                              text=getattr(c, "text", "") or "") for c in qp_cropped]
    _p3_ms_n = len(ms_cropped or [])
    del qp_cropped, ms_cropped
    gc.collect()
    _heap_trim()  # RS-16: give S4's validation-peak pages back before S5 builds on them

    # ---------- S5 classify + save ----------
    # Read-only raw-PDF evidence fills the deliberate text gap in the locked MS
    # crop wrapper (whose ``.text`` is only a placeholder). Failure is nonfatal:
    # image pairing/routing keeps its existing guards and direct QP evidence.
    _ms_evidence_index = None
    _ms_evidence_error = ""
    if _raw_ms_source_path is not None and ms_info is not None and not _is_mcq:
        try:
            from core.mark_scheme_evidence import MarkSchemeEvidenceIndex
            _ms_evidence_index = MarkSchemeEvidenceIndex.from_pdf(_raw_ms_source_path)
            print(
                f"    [ms-evidence] read-only index: questions={_ms_evidence_index.question_numbers} "
                f"from {_raw_ms_source_path.name}"
            )
        except Exception as _ms_exc:
            _ms_evidence_error = f"{type(_ms_exc).__name__}: {_ms_exc}"
            print(f"    [ms-evidence] unavailable; QP/taxonomy classification continues: {_ms_evidence_error}")

    # P4 (2026-10-01): examiner-report commentary is classifier evidence ONLY
    # when a question has no substantive MS text (no MS / generic grid / MCQ
    # key). Offline, read-only, never written anywhere.
    _er_comments = {}
    if not _is_mcq:
        try:
            from core.er_evidence import question_comments as _er_qc
            _er_comments = _er_qc(getattr(qp_info, "full_code", "") or base_key,
                                  getattr(args, "input", None),
                                  er_path=getattr(args, "er_path", None),
                                  qp_path=getattr(qp_info, "file_path", None))
            if _er_comments:
                print(f"    [er-evidence] examiner-report commentary for "
                      f"{len(_er_comments)} question(s) (used only where MS text is empty)")
        except Exception:
            _er_comments = {}

    def _substantive_ms_for(_matched) -> str:
        _num = getattr(_matched, "number_int", getattr(_matched, "question_number", ""))
        _txt = ""
        if _ms_evidence_index is not None:
            _txt = _ms_evidence_index.text_for_question(_num)
        if not (_txt or "").strip() and _er_comments:
            from core.er_evidence import text_for as _er_text_for
            _txt = _er_text_for(_er_comments, getattr(_matched, "question_number", _num))
        return _txt

    _classification_memory = _open_classification_memory(args)
    classifier = TopicClassifier(config, classification_memory=_classification_memory)

    # Accuracy push (2026-10-01): listening transcripts (<series>_qr_<var>.pdf)
    # carry each exercise's spoken text; seed the exercise-context memory so
    # one-line listening stems score on their passage's theme words.
    _transcript_blocks = []
    if not _is_mcq:
        try:
            from core.transcript_text import find_transcript, transcript_blocks as _tblocks
            _tr = find_transcript(Path(args.input), Path(qp_info.file_path).stem)
            if _tr:
                _transcript_blocks = _tblocks(_tr)
                if _transcript_blocks:
                    _mem = classifier.__dict__.setdefault("_exercise_passages", {})
                    _store = _mem.setdefault(
                        (qp_info.full_code, str(qp_info.variant), str(qp_info.year))
                        + ("transcript",), {})
                    for _a, _b, _txt in _transcript_blocks:
                        _store[(_a, _b)] = _txt
                    print(f"    [transcript] {len(_transcript_blocks)} exercise block(s) from {_tr.name}")
        except Exception as _tr_exc:
            print(f"    [transcript] skipped ({type(_tr_exc).__name__}: {_tr_exc})")
    classifier._transcript_blocks = _transcript_blocks
    _pending_high_confidence_memory: list[dict] = []
    unc_counts = {"no_markscheme": 0, "classification_failed": 0}
    # C5 (2026-09-22): questions the memory guard refused to write. A paper with any
    # of these is PARTIAL, never COMPLETE — see the completion branch below.
    _memory_skipped: list = []

    # Buff 2026-08-13: paper-coherence prior. Pass 1 collects tentative
    # winners (cheap; no saving, no image loads in low-ram spool mode) so
    # ambiguous questions can be nudged toward topics that already won
    # elsewhere in the SAME paper. Pass 2 does the real classify+save with
    # the prior. Confident winners are never affected (prior only applies
    # to the pre-prior ambiguous state).
    # Idea 13 (2026-10-01): junk text layer (custom fonts, e.g. 0539/9686 Urdu)
    # -> local Tesseract text for classification only; no-op when not installed.
    if not _is_mcq:
        try:
            from core.ocr_text import maybe_ocr_questions
            maybe_ocr_questions(valid_matched, getattr(qp_info, "file_path", None), config)
        except Exception as _ocr_exc:
            print(f"    [ocr] skipped ({type(_ocr_exc).__name__})")
    from collections import Counter as _Counter
    _coherence = _Counter()
    try:
        for _m0 in valid_matched:
            _c0 = classifier.classify_question(
                _m0, force_winner=_full_auto_eff,
                mark_scheme_text=_substantive_ms_for(_m0))
            if getattr(_c0, "winning_major", ""):
                _coherence[_c0.winning_major] += 1
    except Exception:
        _coherence = _Counter()
    _coherence_prior = dict(_coherence) if _coherence else None
    _saved_folders = []  # (question_folder_str, question_text) for insert attachment

    def s5(check):
        nonlocal _saved_folders
        topic_union = set(getattr(config, "major_topics", [])) | set(getattr(config, "detailed_topics", []))
        saved_here = 0
        _prev_m = None
        _s5_i = 0
        _bs = batch_size(args)
        _resume_done = set()
        if _bs and getattr(args, "resume", False):
            # A resumed run must not re-save (or re-pay for) work already done.
            _resume_done = {q for q, e in batch_progress_read(args, base_key).items()
                            if e.get("status") == "saved"}
            if _resume_done:
                print(f"    [batch] {base_key}: resume - {len(_resume_done)} question(s) "
                      f"already saved ({', '.join(sorted(_resume_done))})")
        for m in valid_matched:
            _s5_i += 1
            if _bs and _s5_i > 1 and (_s5_i - 1) % _bs == 0:
                # ---- batch boundary: close the finished batch before the next ----
                if _prev_m is not None:
                    _release(getattr(_prev_m, "qp", None))
                    _release(getattr(_prev_m, "ms", None))
                    _prev_m = None
                gc.collect()
                _heap_trim()
                batch_wait_for_room(base_key, _s5_i - 1, len(valid_matched),
                                    save_transient_mb(getattr(m, "qp", None),
                                                      getattr(m, "ms", None)) + _MEM_RESERVE_MB)
            if _bs:
                # Price the whole question before touching any of it.
                _pre_ok, _pre_why = save_affordable(m, include_load=True)
                if not _pre_ok:
                    batch_skip_question(args, base_key, m, _pre_why, "before load")
                    _memory_skipped.append(str(m.question_number))
                    continue
            if _bs and str(m.question_number) in _resume_done:
                print(f"    [batch] {base_key} {m.question_number}: resume - already saved, "
                      f"not re-saving")
                saved_here += 1
                continue
            if _spool is not None:
                # flat-peak discipline: park the previous question's pixels
                # before loading this one (release lags exactly one iteration);
                # malloc_trim so the freed pages lower RSS, not just arena.
                if _prev_m is not None:
                    _release(getattr(_prev_m, "qp", None)); _release(getattr(_prev_m, "ms", None))
                    gc.collect()
                    _heap_trim()
                _unspool(getattr(m, "qp", None)); _unspool(getattr(m, "ms", None))
            _prev_m = m
            if args.low_ram:
                print(f"    [mem] s5 in {m.question_number}: RSS {_rss_mb()} MB")  # RS-16 trace
            _mem_trace(f"s5 {m.question_number} in")
            if _bs:
                # batching diagnostics: what the guard will price, and when.
                _mem_trace(f"s5 {m.question_number} loaded qp={crop_pixels(getattr(m, 'qp', None))} "
                           f"ms={crop_pixels(getattr(m, 'ms', None))} "
                           f"est={save_transient_mb(getattr(m, 'qp', None), getattr(m, 'ms', None)):.0f}MB")
            # A structured answer crop is mandatory for a normal topical
            # question folder.  Full-auto may choose a topic on weak evidence,
            # but it must never disguise a missing/unsplittable structured MS
            # as a complete pair with a text placeholder.  Preserve the real
            # QP crop under review_required_no_ms instead. MCQ grids remain the
            # sole allowed _MS.txt representation.
            if getattr(m, "ms", None) is None and getattr(m, "ms_answer", None) is None:
                _is_mcq_question = str(getattr(m, "paper_format", "")).upper() == "MCQ"
                if True:  # every no-MS question (MCQ too) -> <Topic>/review_required
                    # 2026-09-30 (user requirement, ALWAYS): a question without
                    # a mark scheme is classified from its QP text and parked
                    # in the review folder INSIDE its topic, e.g.
                    #   A-Level/Physics_9702/paper-4/Astronomy_and_cosmology/
                    #       review_required/<QID>/
                    # with metadata topic[0] = <Topic>. This holds in every
                    # mode (also --no-full-auto / weak evidence): the topic is
                    # always forced to one of THIS paper's syllabus topics.
                    # The flat <Subject>/review_required home is only an
                    # emergency fallback if writing the topic folder crashes.
                    _nm_c = None
                    try:
                        _nm_c = classifier.classify_question(
                            m, coherence_prior=_coherence_prior,
                            force_winner=True,
                            mark_scheme_text=_substantive_ms_for(m))
                    except Exception as _nm_exc:
                        print(f"    [guarded] {base_key} {m.question_number}: no-MS classification "
                              f"failed ({_nm_exc}) -> best paper topic")
                        _nm_c = None
                    _nm_c = _pin_no_ms_topic(_nm_c, m, config, topic_union)
                    try:
                        _review_saved = output_mgr.save_topic_review_question(m, _nm_c, config)
                    except Exception as _nm_save_exc:
                        print(f"    [guarded] {base_key} {m.question_number}: topic review folder "
                              f"failed ({_nm_save_exc}) -> flat review_required")
                        _review_saved = output_mgr.save_review_required_question(m, "no_markscheme", config)
                    _write_classification_audit(
                        _audit_path, base_key=base_key, matched=m, config=config,
                        classification=_nm_c,
                        full_auto=False, ms_available=False,
                        outcome="review_required_no_markscheme",
                        reason="mark scheme unavailable",
                        output_folder=str(_review_saved.get("question_folder", "")),
                    )
                    unc_counts["no_markscheme"] += 1
                    saved_here += 1
                    # Insert references remain useful while a structured MS is
                    # awaiting review, so preserve this genuine QP text/folder
                    # for the normal Insert attachment stage as well.
                    _saved_folders.append((
                        str(_review_saved.get("question_folder", "")),
                        getattr(getattr(m, "qp", None), "text", "") or "",
                    ))
                    _nm_topic = (_nm_c.winning_major if _nm_c is not None
                                 and getattr(_nm_c, "winning_major", "") else None)
                    if _nm_topic:
                        print(f"    [guarded] {base_key} {m.question_number}: no usable structured MS -> "
                              f"classified {_nm_topic!r} -> {_nm_topic}/review_required (QP crop kept)")
                    else:
                        print(f"    [guarded] {base_key} {m.question_number}: no usable structured MS -> "
                              f"review_required/no_markscheme (QP crop kept)")
                    if _spool is not None:
                        _release(getattr(m, "qp", None)); _release(getattr(m, "ms", None)); _heap_trim()
                    continue
                print(f"    [guarded] {base_key} {m.question_number}: no MCQ grid answer -> "
                      "full-auto MCQ placeholder sidecar")
            _ocr_reasons = [str(r) for r in (getattr(getattr(m, "qp", None), "qc_reasons", None) or [])
                            if str(r).startswith("OCR_")]
            if _ocr_reasons and not bool(getattr(args, "no_ocr_review", False)):
                # Explicit REVIEW_REQUIRED posture: when the boundary engine could
                # not vouch for this crop, it is kept for a human under
                # review_required/<first reason> - never filed under a topic as if
                # the evidence were sound.
                _reason_tag = re.sub(r"[^A-Z0-9_]", "", _ocr_reasons[0].split("(")[0]) or "OCR_UNCERTAIN"
                # 2026-10-01: the OCR reason codes are not review_required
                # sentinels (the old call asserted and crashed S5). Same home as
                # every other review question: classified, parked in
                # paper-N/<Topic>/review_required/; reasons go to the audit log.
                _ocr_c = None
                try:
                    _ocr_c = classifier.classify_question(
                        m, coherence_prior=_coherence_prior, force_winner=True,
                        mark_scheme_text=_substantive_ms_for(m))
                except Exception:
                    _ocr_c = None
                _ocr_c = _pin_no_ms_topic(_ocr_c, m, config, topic_union)
                try:
                    _review_saved = output_mgr.save_topic_review_question(m, _ocr_c, config)
                except Exception as _ocr_save_exc:
                    print(f"    [guarded] {base_key} {m.question_number}: topic review folder "
                          f"failed ({_ocr_save_exc}) -> flat review_required")
                    _review_saved = output_mgr.save_review_required_question(m, "review_required", config)
                _write_classification_audit(
                    _audit_path, base_key=base_key, matched=m, config=config,
                    classification=_ocr_c,
                    full_auto=False, ms_available=bool(getattr(m, "ms", None)),
                    outcome="review_required_ocr",
                    reason=", ".join(_ocr_reasons),
                    output_folder=str(_review_saved.get("question_folder", "")),
                )
                unc_counts["classification_failed"] += 1
                saved_here += 1
                _saved_folders.append((
                    str(_review_saved.get("question_folder", "")),
                    getattr(getattr(m, "qp", None), "text", "") or "",
                ))
                print(f"    [guarded] {base_key} {m.question_number}: OCR evidence uncertain "
                      f"({', '.join(_ocr_reasons)}) -> "
                      f"{_review_saved.get('question_folder', 'review_required')}")
                if _spool is not None:
                    _release(getattr(m, "qp", None)); _release(getattr(m, "ms", None)); _heap_trim()
                continue

            _raw_ms_text = _substantive_ms_for(m)
            c = classifier.classify_question(m, coherence_prior=_coherence_prior,
                                           force_winner=_full_auto_eff,
                                           mark_scheme_text=_raw_ms_text)
            if getattr(c, "fallback_tier", "scored") in ("paper_hint", "alphabetical_first", "review_required"):
                # 2026-08-14 (user requirement, boss checklist): with full-auto
                # ON (the default), REVIEW is NOT ALLOWED — re-classify with
                # force_winner=True (guaranteed guess) and save normally.
                # --no-full-auto restores the fail-closed behavior below.
                if _full_auto_eff:
                    print(f"    [guarded] {base_key} {m.question_number}: {c.fallback_tier} "
                          f"-> re-classifying with force (full-auto)")
                    c = classifier.classify_question(m, coherence_prior=_coherence_prior,
                                                     force_winner=True,
                                                     mark_scheme_text=_raw_ms_text)
                else:
                    # Overseer RULE 1 (decision: desperate_only): desperate tiers only
                    # RS-17: spec absolute rule — insufficient evidence routes to
                    # REVIEW_REQUIRED (never an alphabetical/first-topic rescue).
                    _unc_reason = "review_required" if getattr(c, "fallback_tier", "") == "review_required" else "classification_failed"
                    _review_saved = output_mgr.save_review_required_question(m, _unc_reason, config)
                    _write_classification_audit(
                        _audit_path, base_key=base_key, matched=m, config=config,
                        classification=c, full_auto=False,
                        ms_available=bool(getattr(m, "ms", None) or getattr(m, "ms_answer", None)),
                        outcome="review_required_classification",
                        reason=_unc_reason,
                        output_folder=str(_review_saved.get("question_folder", "")),
                    )
                    unc_counts["classification_failed"] += 1
                    saved_here += 1
                    print(f"    [guarded] {base_key} {m.question_number}: {c.fallback_tier} -> review_required")
                    if _spool is not None:
                        _release(getattr(m, "qp", None)); _release(getattr(m, "ms", None)); _heap_trim()
                    continue
            check(f"{base_key} {m.question_number}: winner set", bool(c.winning_major), c.winning_major)
            if topic_union:
                check(f"{base_key} {m.question_number}: winner in taxonomy",
                      c.winning_major in topic_union, c.winning_major)
            check(f"{base_key} {m.question_number}: <=4 detailed topics",
                  len(c.detailed_topics) <= 4, str(c.detailed_topics[:4]))
            if _bs:
                _mem_trace(f"s5 {m.question_number} classified: RSS {_rss_mb()} MB -> affordability check")
                _mem_trace_big_arrays(f"s5 {m.question_number} retained arrays")
            _aff_ok, _aff_why = save_affordable(m) if _bs else (True, "")
            if _bs:
                _mem_trace(f"s5 {m.question_number} affordability={'OK' if _aff_ok else 'REFUSED'} - {_aff_why}")
            if not _aff_ok:
                # Safety net: refuse to write a question whose save transient is
                # unaffordable even though it passed the pre-load check.
                batch_skip_question(args, base_key, m, _aff_why, "before save")
                _memory_skipped.append(str(m.question_number))
                if _spool is not None:
                    _release(getattr(m, "qp", None))
                    _release(getattr(m, "ms", None))
                    _heap_trim()
                continue
            saved = output_mgr.save_question_pair(m, c, config)
            if _bs:
                batch_progress_append(args, base_key, {
                    "question": str(m.question_number), "status": "saved",
                    "estimate_mb": round(save_transient_mb(getattr(m, "qp", None),
                                                           getattr(m, "ms", None)), 1),
                    "batch_size": _bs, "position": _s5_i,
                })
            qfolder = Path(saved["question_folder"])
            _write_classification_audit(
                _audit_path, base_key=base_key, matched=m, config=config,
                classification=c, full_auto=_full_auto_eff,
                ms_available=bool(getattr(m, "ms", None) or getattr(m, "ms_answer", None)),
                outcome="routed" if c.winning_major else "routed_without_winner",
                output_folder=str(qfolder),
            )
            _saved_folders.append((str(qfolder), getattr(getattr(m, "qp", None), "text", "") or ""))
            _mcq_save = getattr(m, "ms_answer", None) is not None
            _missing_ms_placeholder = (getattr(m, "ms", None) is None and not _mcq_save)
            if saved.get("skipped_duplicate"):
                qp_f = qfolder / f"{qfolder.name}.webp"
                ms_f = None if (_mcq_save or _missing_ms_placeholder) else qfolder / f"{qfolder.name}_MS.webp"
                js_f = qfolder / "metadata.json"
            else:
                qp_f, js_f = Path(saved["qp"]), Path(saved["json"])
                ms_f = None if (_mcq_save or _missing_ms_placeholder) else Path(saved["ms"])

            def on_disk(p: Path) -> bool:
                return p.exists() or any(p.parent.glob(p.stem + "_part*" + p.suffix))
            check(f"{base_key} {m.question_number}: QP file on disk", on_disk(qp_f), qp_f.name)
            if ms_f is not None:
                check(f"{base_key} {m.question_number}: MS file on disk", on_disk(ms_f), ms_f.name)
            else:
                _js0 = json.loads(js_f.read_text(encoding="utf-8"))
                _txt_files = list(qfolder.glob("*_MS.txt"))
                # User requirement (2026-08-14): metadata.json carries ONLY the
                # canonical 11 fields; MCQ letters / missing-MS status live in
                # sidecar files. The canonical-key invariant is asserted on
                # every question the guarded runner saves.
                from core.json_generator import CANONICAL_METADATA_FIELDS as _CANON
                check(f"{base_key} {m.question_number}: metadata = canonical 11 fields only",
                      set(_js0.keys()) == set(_CANON),
                      str(sorted(_js0.keys())))
                if _mcq_save:
                    # MCQ (mcq_ms=letters): no MS webp by design; the grid
                    # letter lives in the _MS.txt sidecar.
                    check(f"{base_key} {m.question_number}: MCQ _MS.txt on disk (unified-MCQ)",
                          len(_txt_files) == 1, f"{len(_txt_files)} found")
                    if _txt_files:
                        _tl = _txt_files[0].read_text(encoding="utf-8").strip()
                        check(f"{base_key} {m.question_number}: _MS.txt valid letter",
                              _tl in ("A", "B", "C", "D"), _tl or "(empty)")
                else:
                    # This branch is reachable only for a known MCQ item in
                    # full-auto mode whose grid did not yield a letter. The
                    # sidecar is permitted there only; structured no-MS items
                    # took the review-required path above.
                    check(f"{base_key} {m.question_number}: MCQ missing-answer sidecar on disk",
                          len(_txt_files) == 1, f"{len(_txt_files)} found")
            check(f"{base_key} {m.question_number}: metadata.json on disk", js_f.exists(), js_f.name)
            webps = sorted(qfolder.glob("*.webp"))
            check(f"{base_key} {m.question_number}: webp {'QP-only (MCQ)' if ms_f is None else 'pair'} written",
                  len(webps) >= (1 if ms_f is None else 2), f"{len(webps)} webps")
            from PIL import Image
            for w in webps:
                with Image.open(w) as im:
                    check(f"{base_key} {m.question_number}: {w.name} width 2280",
                          im.width == TARGET_WIDTH, f"{im.size}")
            json.loads(js_f.read_text(encoding="utf-8"))
            check(f"{base_key} {m.question_number}: metadata.json parses",
                  True, f"{js_f.stat().st_size} bytes")
            # Do not write a self-prediction while processing an incomplete
            # paper. It remains a volatile proposal until the post-S8-style
            # paper completion branch below explicitly commits it.
            if _classification_memory is not None and bool(getattr(args, "write_high_confidence_memory", False)):
                _queue_high_confidence_memory_record(
                    _pending_high_confidence_memory,
                    matched=m, classification=c, config=config,
                    mark_scheme_text=_raw_ms_text,
                    threshold=float(getattr(args, "memory_high_confidence_threshold", 0.95)),
                )
            # 2026-09-21: return THIS question's freed pixel arenas to the OS before
            # the next one is loaded. _heap_trim() was previously called only on the
            # error paths, so every successfully saved question left ~40-60 MB in
            # glibc arenas; the real 9231 bundle accumulated ~400 MB that way and a
            # single 2280x16351 px crop on top of it was OOM-killed at 1.3 GB.
            if _spool is not None:
                _release(getattr(m, "qp", None)); _release(getattr(m, "ms", None))
            gc.collect()
            _heap_trim()
            saved_here += 1
        check(f"{base_key}: all paired questions saved", saved_here == len(valid_matched),
              f"{saved_here}/{len(valid_matched)}")
        return saved_here

    saved_n = gate.run_stage("S5", f"{ALL_STAGES[5][1]} [{base_key}]", s5)
    print(f"    [guarded] review_required (no MS): {unc_counts['no_markscheme']} / (classify failed): {unc_counts['classification_failed']}")

    # ---------- P3 paper checks (flags only; filing is unchanged) ----------
    try:
        from core import run_report as _rr
        if ms_info is None:
            _ms_n = None
        elif _is_mcq:
            _ms_n = len(_mcq_answers or {}) or None
        else:
            _ms_n = _p3_ms_n or None
        _checks = _rr.paper_checks(qp_info.file_path, _p3_qp, ms_count=_ms_n,
                                   is_mcq=bool(_is_mcq))
        if _ms_generic:
            _checks["flags"].append(
                "generic_markscheme: shared levels/grid scheme attached to every"
                " question (no per-question MS content)")
        _folders = [f for f, _t in _saved_folders if f]
        _qrows = []
        _out_root = Path(args.output)
        for _f in _folders:
            _fp = Path(_f)
            _parts = _fp.parts
            _rev = [i for i, x in enumerate(_parts) if x.startswith("review_required")]
            _pidx = [i for i, x in enumerate(_parts) if x.startswith("paper-")]
            _topic = ""
            if _pidx and _pidx[-1] + 1 < len(_parts) - 1:
                _topic = _parts[_pidx[-1] + 1]
                if _topic.startswith("review_required"):
                    _topic = ""
            _reason = ""
            if _rev:
                _reason = (_parts[_rev[0] + 1] if _rev[0] + 2 < len(_parts) else "") or "no mark scheme"
                if re.search(r"_Q\d+$", _reason):
                    _reason = "no mark scheme" if ms_info is None else "review"
            try:
                _rel = str(_fp.relative_to(_out_root))
            except ValueError:
                _rel = str(_fp)
            _qrows.append({"q": _fp.name.rsplit("_", 1)[-1], "folder": _rel, "topic": _topic,
                           "review": bool(_rev), "review_reason": _reason})
        _rr.write_paper_record(args.output, base_key, {
            "subject": getattr(config, "subject", ""), "level": getattr(config, "level", ""),
            "qp": qp_info.full_code, "ms": getattr(ms_info, "full_code", None) if ms_info else None,
            "qp_count": len(_p3_qp), "ms_count": _ms_n, "saved": saved_n,
            "mcq": bool(_is_mcq), "checks": _checks, "questions": _qrows})
        for _fl in _checks.get("flags", []):
            print(f"    [check] {base_key}: FLAG {_fl}")
        print(f"    [check] {base_key}: mark total {_checks.get('mark_check')}")
    except Exception as _rr_exc:
        print(f"    [check] paper checks skipped ({type(_rr_exc).__name__}: {_rr_exc})")

    # ---------- S5b insert booklet processing ----------
    if insert_info is not None and _saved_folders:
        try:
            from core.insert_engine import InsertEngine, write_insert_outputs
            from core.output_manager import _paper_type_folder as _ptf
            _ins_eng = InsertEngine(target_width=2280, quality=95, dpi=150)
            _ins_res = _ins_eng.process_insert(insert_info.file_path)
            if _ins_res is not None:
                _pt_folder = _ptf(
                    str(getattr(qp_info, "variant", "") or ""),
                    syllabus_code=str(getattr(config, "syllabus_code", "")),
                    paper_format=getattr(qp_info, "paper_format", ""),
                )
                _sum = write_insert_outputs(
                    _ins_eng, _ins_res, insert_info.file_path,
                    Path(args.output), config.level, config.subject, _pt_folder,
                    base_key, question_refs=_saved_folders)
                print(f"    [guarded] insert {insert_info.file_path.name}: "
                      f"whole_pages={_sum['whole_pages']} sections={_sum['sections']}"
                      + (" (reference data — skipped)" if _sum['reference_data_skipped'] else ""))
        except Exception as _iexc:
            print(f"    [guarded] insert processing failed (non-fatal): {_iexc}")
    if ci_info is not None:
        _copy_confidential_instructions(ci_info, qp_info, config, output_mgr)
        _render_confidential_pages_to_questions(ci_info, _saved_folders, output_mgr)
    _paper_completed = False
    if unc_counts["no_markscheme"]:
        state.mark_review_required(
            base_key,
            f"MISSING_MS: {unc_counts['no_markscheme']} structured question(s) preserved for review",
        )
    elif ms_info is None:
        # MCQ-only no-MS paths retain their explicitly permitted sidecar
        # contract. Structured no-MS paths were already routed above.
        state.mark_complete(base_key, len(valid_matched), saved_n)
        _paper_completed = True
    elif _qp_crop_count == 0:
        # defect 6: never mark an empty/hollow paper complete
        state.mark_failed(base_key, "CROP_EMPTY (0 QP crops — fail-closed, never fabricated)")
        print(f"    [guarded] ❌ {base_key}: 0 QP crops — NOT marked complete")
    elif _qc_flagged_qs and not _full_auto_eff:
        # Fail-closed mode keeps the quality gate strict. Full-auto deliberately
        # trusts the deterministic crop/QP checks and records the question's
        # best topic instead of leaving the bundle unresolved.
        state.mark_failed(base_key, f"QC needs_review: {_qc_flagged_qs}")
        print(f"    [guarded] ⚠️ {base_key}: QC needs_review {_qc_flagged_qs} — NOT marked complete (crops saved for review)")
    elif getattr(config, "year_review_required", False) and not _full_auto_eff:
        # Historical/future paper year has no verified edition profile yet.
        # Preserve the real crops and classifications, but never advertise a
        # clean syllabus-level completion in fail-closed mode.
        reason = (
            f"SYLLABUS_YEAR_UNVERIFIED: {getattr(config, 'requested_year', '?')} "
            f"not in {getattr(config, 'syllabus_years', [])}"
        )
        state.mark_review_required(base_key, reason)
        print(f"    [guarded] ⚠️ {base_key}: {reason} — crops preserved; bundle REVIEW_REQUIRED")
    else:
        if _full_auto_eff and _qc_flagged_qs:
            print(f"    [guarded] {base_key}: full-auto accepted QC advisory flags "
                  f"for {_qc_flagged_qs}")
        if _full_auto_eff and getattr(config, "year_review_required", False):
            print(f"    [guarded] {base_key}: full-auto accepted unverified syllabus "
                  "year; crops categorized")
        if _memory_skipped:
            # C5 (2026-09-22): a guard-triggered skip used to leave the paper marked
            # COMPLETE with questions missing (state said 5/5 done, disk had 4) while
            # the parent filed a "partial" failure — two records that contradicted
            # each other and a --resume that would never come back for the question.
            # Honest status: REVIEW_REQUIRED with the skipped questions named; the
            # saved work is kept and --resume re-processes the bundle (with a bigger
            # budget or --batch-size 1) instead of skipping it forever.
            reason = (f"PARTIAL_MEMORY_SKIP: {len(_memory_skipped)} question(s) not written "
                      f"({', '.join(_memory_skipped)}) — saved work kept; re-run with more RAM "
                      f"or --batch-size 1")
            state.mark_review_required(base_key, reason)
            print(f"    [guarded] ⚠️ {base_key}: {reason} — NOT marked complete")
        else:
            state.mark_complete(base_key, len(valid_matched), saved_n)
            _paper_completed = True

    # Persistent high-confidence memory is opt-in and never becomes a partial
    # paper side effect. Review/failed/unverified-year papers discard their
    # volatile proposals; verified/correction records are always written only
    # through explicit review tooling.
    if _paper_completed and not getattr(config, "year_review_required", False):
        try:
            _committed = _flush_high_confidence_memory_records(
                _classification_memory, _pending_high_confidence_memory
            )
            if _committed:
                print(f"    [memory] committed {_committed} buffered high-confidence record(s) after paper completion")
        except Exception as _memory_exc:
            print(f"    [memory] buffered post-completion write failed (paper output unchanged): {_memory_exc}")
    elif _pending_high_confidence_memory:
        print(f"    [memory] discarded {len(_pending_high_confidence_memory)} buffered record(s): paper not cleanly complete")
    if _classification_memory is not None:
        _classification_memory.close()
    state.save(output_root_safe(output_mgr))
    del valid_matched
    if _spool is not None:
        shutil.rmtree(_spool, ignore_errors=True)
    gc.collect()
    return saved_n


def output_root_safe(output_mgr) -> Path:
    return Path(getattr(output_mgr, "output_root", "output"))


def _open_classification_memory(args):
    """Open a deliberate indexed memory store for one paper worker.

    A nonexistent default is not created merely by classifying a paper.  The
    only automatic writes are explicitly opted-in high-confidence records, and
    those are still buffered until the paper has completed.
    """
    from core.classification_memory import ClassificationMemory, default_memory_path

    requested = getattr(args, "classification_memory", None)
    write_enabled = bool(getattr(args, "write_high_confidence_memory", False))
    path = Path(requested).expanduser() if requested else default_memory_path()
    if not path.exists() and not write_enabled:
        if requested:
            print(f"    [memory] requested store does not exist; retrieval disabled: {path}")
        return None
    try:
        memory = ClassificationMemory(
            path, create=write_enabled or path.exists(), read_only=not write_enabled
        )
        stats = memory.stats()
        print(
            f"    [memory] indexed retrieval {'+ opt-in buffered writes' if write_enabled else 'read-only use'}: "
            f"{stats.get('records', 0)} record(s), {stats.get('tokens', 0)} token(s)"
        )
        return memory
    except Exception as exc:
        print(f"    [memory] unavailable; direct classification continues: {type(exc).__name__}: {exc}")
        return None


def _queue_high_confidence_memory_record(queue, *, matched, classification, config,
                                          mark_scheme_text: str, threshold: float) -> None:
    """Keep a proposed high-confidence record in memory until paper completion."""
    if getattr(classification, "fallback_tier", "scored") != "scored":
        return
    confidence = float(getattr(classification, "confidence", 0.0) or 0.0)
    if confidence < threshold or not getattr(classification, "winning_major", ""):
        return
    topics = list(getattr(classification, "detailed_topics", []) or [])[:4]
    if not topics:
        return
    summary = getattr(classification, "evidence_summary", {}) or {}
    ms_hits = ((summary.get("mark_scheme") or {}).get("topic_hits") or {})
    facts = ["Scored classification met the configured high-confidence threshold after direct current-question evidence."]
    hit_terms = sorted({term for terms in ms_hits.values() for term in terms})[:6]
    if hit_terms:
        facts.append("Raw mark scheme contained configured assessed concepts: " + ", ".join(hit_terms) + ".")
    queue.append({
        "subject": config.subject,
        "level": config.level,
        "paper": str(getattr(matched, "full_qp_code", "") or getattr(matched, "paper_code", "")),
        "variant": str(getattr(matched, "variant", "")),
        "question_number": str(getattr(matched, "question_number", "")),
        "topics": topics,
        "major_topics": [classification.winning_major],
        "evidence": facts,
        "question_text": getattr(getattr(matched, "qp", None), "text", "") or "",
        "mark_scheme_text": mark_scheme_text,
        "confidence": confidence,
        "classifier_version": str(summary.get("classifier_version", "")),
        "taxonomy_version": str(summary.get("taxonomy_version", getattr(config, "version", ""))),
        "syllabus_version": str(summary.get("syllabus_version", "")),
        "source": "opt_in_post_complete_high_confidence",
        "record_key": (
            f"auto-hc:{config.subject}:{getattr(matched, 'full_qp_code', getattr(matched, 'paper_code', ''))}:"
            f"{getattr(matched, 'question_number', '')}:{getattr(config, 'version', '')}"
        ),
    })


def _flush_high_confidence_memory_records(memory, queue) -> int:
    if memory is None or not queue:
        return 0
    committed = 0
    for record in queue:
        memory.record_high_confidence(**record)
        committed += 1
    return committed


def _classification_audit_path(args, base_key: str) -> Path:
    """Run-level audit path for classifier decisions.

    This deliberately lives outside each question folder. The canonical
    metadata.json contract remains exactly the 11 required fields; confidence,
    scores, fallback source, and evidence are recorded here instead.
    """
    explicit = getattr(args, "classification_audit_path", None)
    if explicit:
        return Path(explicit)
    return Path(args.output) / ".classification_audit" / f"{base_key}.jsonl"


def _write_classification_audit(
    path: Path,
    *,
    base_key: str,
    matched,
    config,
    classification=None,
    full_auto: bool,
    ms_available: bool,
    outcome: str,
    reason: str = "",
    output_folder: str = "",
) -> None:
    """Append one machine-readable decision without touching metadata.json."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        q = getattr(matched, "question_number", "")
        qp = getattr(matched, "qp", None)
        text = getattr(qp, "text", "") if qp is not None else ""
        record = {
            "paper": base_key,
            "paper_full_code": getattr(matched, "full_qp_code", ""),
            "variant": getattr(matched, "variant", ""),
            "question_number": q,
            "subject": getattr(config, "subject", ""),
            "level": getattr(config, "level", ""),
            "assigned_topic": getattr(classification, "winning_major", "") if classification else "",
            "detailed_topics": list(getattr(classification, "detailed_topics", []) or []) if classification else [],
            "confidence": getattr(classification, "confidence", None) if classification else None,
            "fallback_tier": getattr(classification, "fallback_tier", "") if classification else "",
            "auto_reason": getattr(classification, "auto_reason", "") if classification else "",
            "major_scores": getattr(classification, "major_topic_scores", {}) if classification else {},
            "diagram_evidence": getattr(classification, "diagram_evidence", None) if classification else None,
            # Separate audit only; JSONGenerator never receives this field.
            "classification_evidence": getattr(classification, "evidence_summary", None) if classification else None,
            "reasoning": getattr(classification, "reasoning", "") if classification else reason,
            "outcome": outcome,
            "full_auto": bool(full_auto),
            "ms_available": bool(ms_available),
            "question_text_chars": len(text or ""),
            "question_text": (text or "")[:12000],
            "output_folder": output_folder,
        }
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False, sort_keys=True, default=str) + "\n")
    except OSError as exc:
        # Observability must never prevent the question itself from being saved.
        print(f"    [audit] classification trace unavailable for {base_key} {getattr(matched, 'question_number', '')}: {exc}")


def _copy_confidential_instructions(ci_info, qp_info, config, output_mgr) -> Path | None:
    """Copy CI intact to the matching paper-level sidecar.

    Confidential instructions are administrative/source material, not question
    content. This function deliberately performs no raster rendering or crop
    operation.
    """
    if ci_info is None:
        return None
    try:
        from core.output_manager import _paper_type_folder
        paper_folder = _paper_type_folder(
            getattr(qp_info, "variant", ""),
            syllabus_code=getattr(config, "syllabus_code", ""),
            paper_format=getattr(qp_info, "paper_format", ""),
        )
        root = Path(getattr(output_mgr, "output_root", "output"))
        target_dir = root / config.level / config.subject / paper_folder / "_confidential"
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / f"{qp_info.full_code}_CI.pdf"
        shutil.copy2(ci_info.file_path, target)
        print(f"    [CI] copied intact: {ci_info.file_path.name} -> {target_dir}")
        return target
    except Exception as exc:
        print(f"    [CI] copy failed for {getattr(ci_info.file_path, 'name', ci_info)}: {exc}")
        return None


def _render_confidential_pages_to_questions(ci_info, question_refs, output_mgr) -> int:
    """Render every CI page as a full-page 2280px WebP inside each saved
    question folder. This is an attachment render, not a question crop: page
    geometry is preserved and the locked QP/MS croppers are not called.
    """
    if ci_info is None or not question_refs:
        return 0
    try:
        import fitz
        from PIL import Image as _PILImage
        doc = fitz.open(str(ci_info.file_path))
        count = 0
        qfolders = [Path(folder) for folder, _text in question_refs]
        total_pages = len(doc)
        for page_index, page in enumerate(doc):
            pix = page.get_pixmap(dpi=150, alpha=False)
            image = _PILImage.frombytes("RGB", [pix.width, pix.height], pix.samples)
            for qfolder in qfolders:
                suffix = "CI.webp" if total_pages == 1 else f"CI_part{page_index + 1}.webp"
                target = qfolder / f"{qfolder.name}_{suffix}"
                output_mgr._save_image(image, target)
                count += 1
            image.close()
        doc.close()
        print(f"    [CI] rendered {total_pages} full page(s) into {len(qfolders)} question folder(s)")
        return count
    except Exception as exc:
        print(f"    [CI] question-page attachment failed: {exc}")
        return 0


def load_inputs(args):
    """S0+S1 shared by parent and workers. Returns (gate, configs, papers, sep)."""
    input_dir, output_dir = Path(args.input), Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    gate = Gate(output_dir)

    if args.clean and output_dir.exists():
        for item in output_dir.iterdir():
            if item.name == ".gitkeep":
                continue
            shutil.rmtree(item) if item.is_dir() else item.unlink()
        print(f"[guarded] cleaned {output_dir}")

    from core.config_loader import (load_all_subject_configs,
                                    load_subject_config_by_code_and_level,
                                    validate_all_configs)

    def s0(check):
        ok, errors_by_subject = validate_all_configs()
        check("all subject configs validate", ok, f"errors={errors_by_subject if not ok else 'none'}")
        configs = load_all_subject_configs()
        check("configs loaded", len(configs) > 0, f"{len(configs)} entries")
        return configs

    configs = gate.run_stage("S0", ALL_STAGES[0][1], s0)

    from core.paper_identifier import identify_papers_in_dir
    from core.subject_detector import separate_papers_by_subject

    def s1(check):
        from core.batch_manifest import identify_via_manifest_or_live
        # RS-9: one-pass manifest (derived cache). Parent builds/refreshes it;
        # workers consume-or-fallback and NEVER build — kills the O(N^2)
        # per-worker whole-directory re-identification at 300+ files.
        papers, ident_src = identify_via_manifest_or_live(
            input_dir,
            manifest_path=getattr(args, "manifest", None),
            build_if_missing=not bool(getattr(args, "worker", None)),
            no_manifest=bool(getattr(args, "no_manifest", False)),
            full_check=bool(getattr(args, "manifest_full_check", False)),
        )
        check("at least one paper identified", len(papers) > 0,
              f"{len(papers)} papers in {input_dir} [identity:{ident_src}]")
        # Say the board of every examiner report out loud, from the document's own cover,
        # before any stage runs. The CAIE grammar leaves a report's board unset (its board is
        # implied by the pipeline it arrives in), and a user handing in a folder of reports
        # deserves to see the verdict instead of inferring it from the output tree.
        if not getattr(args, "worker", None):
            for _p in papers:
                if str(getattr(_p, "paper_type", "") or "").lower() != "er":
                    continue
                _verdict, _why = _er_document_board(getattr(_p, "file_path", ""))
                _recorded = str(getattr(_p, "board", "") or "").upper()
                _comp = getattr(_p, "variant", "") or getattr(_p, "syllabus_code", "") or "?"
                _note = (f"examiner report {Path(_p.file_path).name}: board {_verdict} "
                         f"({_why}), component {_comp}")
                if _recorded and _verdict not in ("UNKNOWN", _recorded):
                    _note += (f" -- recorded as {_recorded} here, so it routes by its own "
                              f"board rather than the Cambridge stages")
                print(f"[guarded] {_note}")
        for p in papers:
            check(f"{p.original_name or p.file_path.name}: parsed",
                  p.paper_type in {"qp", "ms", "er", "gt", "in", "insert", "ir", "ci", "sf"} and bool(p.syllabus_code),
                  f"type={p.paper_type} code={p.syllabus_code} {p.season_letter}{p.year_short} v{p.variant}")
        sep = separate_papers_by_subject(papers)
        check("no identity conflicts", len(sep["conflicts"]) == 0,
              f"{len(sep['conflicts'])} conflicts" if sep["conflicts"] else "clean")
        check("no papers needing review", len(sep["review"]) == 0,
              f"{len(sep['review'])} for review" if sep["review"] else "clean")
        check("papers sorted into subject contexts", len(sep["by_level_subject"]) > 0,
              str({lvl: list(d) for lvl, d in sep["by_level_subject"].items()}))
        # Every four-digit paper year is processable.  Declared syllabus
        # editions are clean; an undeclared historical/future year is loudly
        # bound to REVIEW_REQUIRED rather than aborting S1 and discarding the
        # entire paper before cropping begins.
        _cfg_by_code = {}
        for _cfg in configs.values():
            _cfg_by_code[(str(_cfg.syllabus_code), _cfg.level)] = _cfg
            # Alias codes (0983 -> 0478, 0971 -> 0620, 9608 -> 9618, ...)
            # must resolve to the canonical config in the S1 profile gate too,
            # or alias-code papers fail "profile exists for year" with
            # years=None even though their subject is fully configured.
            try:
                from core.config_loader import CODE_ALIASES
                for _alias, _canon in CODE_ALIASES.items():
                    if _canon == str(_cfg.syllabus_code):
                        _cfg_by_code[(_alias, _cfg.level)] = _cfg
            except Exception:
                pass
        for p in papers:
            if p.paper_type not in {"qp", "ms", "er", "in"}:
                continue
            _board = getattr(p, "board", None)
            if _board and str(_board).upper() not in ("CAIE", "CIE"):
                # A non-CAIE paper has no CAIE subject profile BY DESIGN, not by
                # omission: its cropping is adapter-driven (P1/A3) and a CAIE
                # syllabus profile does not describe it. Named per paper, per
                # board, so nothing can silently inherit a CAIE profile - and the
                # CAIE branch below is byte-for-byte unchanged (2026-09-21).
                print(f"    [info] {p.original_name or p.file_path.name}: {_board} paper - "
                      "no CAIE subject profile required (adapter-driven board path)")
                continue
            _full_year = f"20{p.year_short}" if len(str(p.year_short)) == 2 else str(p.year_short)
            _cfg_hit = _cfg_by_code.get((str(p.syllabus_code), p.level))
            _year_known = _cfg_hit is not None and _full_year in [
                str(y) for y in _cfg_hit.syllabus_years
            ]
            if _cfg_hit is not None and not _year_known:
                # A20 (2026-09-26): the TEMP global year bypass accepts all
                # years for categorization; say so instead of the stale
                # forced-review note (strict years: CAIE_TEMP_ALLOW_ALL_YEARS=0).
                from core.config_loader import TEMP_ALLOW_ALL_YEARS
                if TEMP_ALLOW_ALL_YEARS:
                    print(
                        f"    [info] {p.original_name or p.file_path.name}: year "
                        f"{_full_year} not in declared editions "
                        f"{_cfg_hit.syllabus_years}; TEMP-YEAR-BYPASS (A20): "
                        "categorizing normally (temporary)"
                    )
                else:
                    print(
                        f"    [info] {p.original_name or p.file_path.name}: year "
                        f"{_full_year} is not in the verified editions "
                        f"{_cfg_hit.syllabus_years}; crop allowed, bundle forced "
                        "REVIEW_REQUIRED"
                    )
            check(
                f"{p.original_name or p.file_path.name}: profile exists for year {_full_year}",
                _cfg_hit is not None,
                f"{p.syllabus_code} {p.level} declared_year={_year_known} "
                f"years={getattr(_cfg_hit, 'syllabus_years', None)} paper={_full_year}"
            )
        return papers, sep

    papers, sep = gate.run_stage("S1", ALL_STAGES[1][1], s1)
    return gate, configs, papers, sep


def _levels_in_order(sep) -> list:
    """Level keys to walk, CAIE levels first.

    S1's subject detector files a CAIE paper under "IGCSE"/"A-Level" and a
    non-CAIE paper under its board-scoped subject with level "Unknown". Walking
    only the two CAIE levels (pre-2026-09-21) meant a board-scoped context was
    never visited: S2-S5 produced nothing, the run fell straight through to S6,
    and S6 failed on the board's own examiner report. Order is deterministic:
    CAIE levels first, then anything else sorted.
    """
    present = list(sep.get("by_level_subject", {}))
    ordered = [lv for lv in ("IGCSE", "A-Level") if lv in present]
    ordered += sorted(lv for lv in present if lv not in ("IGCSE", "A-Level"))
    return ordered


#: Path -> (board, reason), filled by _er_document_board(). Keyed by (path, size, mtime) so a
#: long run asks each report once: _is_caie_board() is consulted per paper by the S2 routing
#: decision and again by the S6/S7 ER filter.
_ER_BOARD_CACHE: dict = {}


def _er_document_board(path) -> tuple[str, str]:
    """Which board an examiner report belongs to, from the document itself.

    The adapters are the authority (board signature at confidence 1.0 for both real fixtures);
    this is the thin reader the guarded pipeline uses so the answer is explicit and printed,
    instead of implied by which entry point the file happened to arrive through.
    """
    try:
        key = None
        p = Path(path)
        try:
            st = p.stat()
            key = (str(p), st.st_size, int(st.st_mtime))
        except OSError:
            pass
        if key is not None and key in _ER_BOARD_CACHE:
            return _ER_BOARD_CACHE[key]
        from adapters.associations import identify_document
        ident = identify_document(p)
        board = str(ident.board or "UNKNOWN").upper()
        reason = ""
        for ev in ident.evidence or []:
            if "board_signature" in str(ev):
                reason = f"cover signature, confidence {ident.confidence:.2f}"
                break
        if board in ("UNKNOWN", ""):
            reason = "no board evidence found in the document"
        elif not reason:
            reason = "identified from the document text"
        if key is not None:
            _ER_BOARD_CACHE[key] = (board, reason)
        return board, reason
    except Exception as exc:                      # noqa: BLE001 - never fails a run
        return "UNKNOWN", f"board check unavailable ({type(exc).__name__})"


def _companion_only(paper_list) -> bool:
    """True when a context holds no question paper and no mark scheme.

    An examiner report or insert supplied on its own is a legitimate input: there is nothing
    to render and no mark-scheme leg to run, and the ER is still identified and cropped. This
    mirrors the CAIE path's orphan-ER handling -- without it the same scenario was green on
    the Cambridge side and red on the board side.
    """
    kinds = {str(getattr(p, "paper_type", "") or "").lower() for p in paper_list}
    return bool(kinds) and not (kinds & {"qp", "ms"})


def _is_caie_board(paper) -> bool:
    """True when the Cambridge stages may take this paper."""
    board = getattr(paper, "board", None)
    if not board:
        # No board recorded => S1 identified it with the CAIE grammar. That is a filename
        # reading though, and a filename can lie; for an examiner report ask the document.
        # (A CAIE-shaped name over AQA content is the case that matters: the Cambridge ER
        # stages must not take it.)
        if str(getattr(paper, "paper_type", "") or "").lower() == "er":
            verdict, _why = _er_document_board(getattr(paper, "file_path", ""))
            if verdict not in ("CAIE", "CIE", "UNKNOWN"):
                return False
        return True
    return str(board).upper() in ("CAIE", "CIE")


def _run_board_path(gate, args, level, subject, paper_list, output_root,
                     renders_out=None) -> int:
    """S2-S5 for a board-scoped (non-CAIE) context, adapter-driven.

    The Cambridge stages call CroppingEngine/MSCroppingEngine plus a CAIE subject
    profile. A non-CAIE paper has neither: its crop engine IS the board adapter
    and its topic hints come from adapters.nonib_topics. Rather than grow a
    second crop path inside this runner - forbidden, one engine per job - the
    whole context is handed to the existing universal batch runner, which is the
    production home of the adapter-driven path. Nothing CAIE reaches here: the
    caller only routes a context whose every paper is non-CAIE.
    """
    from tools.run_universal_batch import run_batch

    pdfs = [Path(p.file_path) for p in paper_list if getattr(p, "file_path", None)]
    boards = sorted({str(getattr(p, "board", "?")).upper() for p in paper_list})
    limit = int(os.environ.get("GUARDED_BOARD_LIMIT", "0") or 0)
    print(f"    [board-path] {subject}: {len(pdfs)} file(s) {boards} -> "
          f"tools/run_universal_batch.run_batch (adapter-driven S2-S5)")

    def s_board(check):
        try:
            # One dedicated subtree, registered as auxiliary in core.validation /
            # core.output_manager: the CAIE validator deletes what it flags as an
            # orphan, and it deleted the board JSONs while this path lived at the
            # output root (2026-09-21). Board papers land in board_path/final/...
            audit = run_batch(Path(args.input), output_root / "board_path",
                              include_sat=True, include_ib=True,
                              limit_per_paper=limit, only_paths=pdfs)
        except Exception as exc:                      # noqa: BLE001 - reported, not raised
            check("board path completed", False, f"{type(exc).__name__}: {exc}")
            return 0
        counts = audit.get("counts", {})
        renders = audit.get("render_results", [])
        saved = sum(int(r.get("rendered", 0) or 0) for r in renders
                    if r.get("status") == "PASS")
        check("board path completed", True,
              f"files={len(pdfs)} boards={','.join(boards)} limited_to={limit or 'all'}")
        # An ER (or insert) supplied alone: identified and cropped, but there is no question
        # paper to render and no mark-scheme leg to run -- judged by its own evidence instead
        # of against counts it could never reach (2026-09-29; the CAIE path has been green on
        # this shape since RS-13 while the board path reported two failures).
        companion_only = _companion_only(paper_list)
        sections = int(counts.get("er_section_crops", 0)) + int(counts.get("insert_section_crops", 0))
        companion_out = (sections + int(counts.get("er_notes", 0))
                         + int(counts.get("insert_sources", 0)))
        if companion_only:
            check("board path companion-only input",
                  companion_out > 0 or bool(audit.get("review")),
                  f"no question paper/mark scheme supplied; ER/insert sections "
                  f"cropped={sections}, notes={int(counts.get('er_notes', 0))}, "
                  f"review={len(audit.get('review', []))}")
        check("board path rendered questions", saved > 0 or companion_only,
              f"rendered={saved}" + (f" (companion-only input: cropped {sections} section(s))"
                                     if companion_only else ""))
        check("board path render failures", int(counts.get("render_fail", 0)) == 0,
              f"render_fail={counts.get('render_fail', 0)}")
        check("board path mark-scheme leg", int(counts.get("ms_segments", 0)) > 0 or companion_only,
              f"ms_segments={counts.get('ms_segments', 0)}"
              + (" (companion-only input: no mark scheme to segment)" if companion_only else ""))
        check("board path review queue reported", True,
              f"review_required={counts.get('review_required', 0)} "
              f"indexed_only={counts.get('indexed_only', 0)}")
        for item in audit.get("review", []):
            print(f"      [board-path:{item.get('status')}] "
                  f"{Path(str(item.get('path'))).name}: {item.get('reason')}")
        if renders_out is not None:
            # (paper dir, questions rendered) per paper: S8 compares each paper's
            # own directory against the count, so the pack copies never inflate it.
            for _r in renders:
                _d = _r.get("output_dir")
                if _r.get("status") == "PASS" and _d:
                    renders_out.append((Path(_d), int(_r.get("rendered", 0) or 0)))
        print(f"    [board-path] output: {output_root}/board_path/UNIVERSAL_BATCH_AUDIT.md "
              f"(questions={saved}, packs={counts.get('question_packs', 0)})")
        return saved

    saved_n = gate.run_stage("S2", f"adapter-driven board path QP+MS+ER ({subject})",
                             s_board, abort_on_fail=False)
    return max(int(saved_n or 0), 0)


def find_bundle(base_key, configs, sep):
    """Locate (level, subject, config, qp_info, ms_info, insert_info, ci_info)
    for a bundle key."""
    from core.config_loader import load_subject_config_by_code_and_level
    for level in _levels_in_order(sep):
        for subject, paper_list in sep["by_level_subject"].get(level, {}).items():
            from collections import defaultdict
            by_year = defaultdict(list)
            for p in paper_list:
                by_year[p.year].append(p)
            for year, year_papers in by_year.items():
                from core.qp_ms_matcher import QPMSMatcher
                matcher = QPMSMatcher()
                groups = matcher.group_papers(year_papers)
                if base_key in groups:
                    td = groups[base_key]
                    config = load_subject_config_by_code_and_level(
                        year_papers[0].syllabus_code, level, year)
                    if config is None and str(level) not in ("IGCSE", "A-Level"):
                        raise SystemExit(
                            f"[guarded] FATAL: bundle {base_key} belongs to the board-scoped "
                            f"context {level!r}; board papers run through the guarded board "
                            f"path (tools/run_universal_batch.py), never through find_bundle")
                    if config is None:
                        # Spec Fix 10 (2026-08-12): NEVER substitute a default/
                        # nearest-profile config silently. Identity that resolves
                        # to no declared profile aborts the bundle loudly instead.
                        raise SystemExit(
                            f"[guarded] FATAL: no declared subject profile for "
                            f"{year_papers[0].syllabus_code} {level} (bundle {base_key}) — "
                            f"refusing to fall back to a default configuration")
                    _insert = None
                    for _k in ("insert", "in", "ir", "sf"):
                        if _k in td:
                            _insert = td[_k]
                            break
                    _ci = td.get("ci")
                    return (level, subject, config, td.get("qp"), td.get("ms"),
                            _insert, _ci)
    return None, None, None, None, None, None, None


def run_ms_only_review(ms_info, subject, config, output_root, low_ram=True):
    """2026-08-15 (user requirement): QP missing -> crop the MS anyway and
    preserve each MS crop in review_required/missing_qp. Returns saved count."""
    from core.ms_cropping_engine import (
        MS_FAT_REFUSE_MIN_PAGES, ms_engine_for, ms_pdf_page_count)
    from core.output_manager import OutputManager
    run_ms_only_review.last_matched = 0
    output_mgr = OutputManager(output_root=output_root, target_width=2280, quality=95)
    # A20: a mark scheme even the stepped-down engine cannot render routes
    # graceful review (0 crops), never a worker SIGKILL.
    if ms_pdf_page_count(ms_info.file_path) > MS_FAT_REFUSE_MIN_PAGES:
        print(f"    [guarded] MS-only review: {ms_info.file_path.name} exceeds "
              f"{MS_FAT_REFUSE_MIN_PAGES} pages — beyond this box, routing "
              "graceful review (0 crops)")
        return 0
    ms_engine = ms_engine_for(ms_info.file_path, target_width=2280, quality=95)
    # MCQ answer grid found later: pair each letter with the QP parked in
    # <Topic>/review_required/<QID>/ and write <QID>_MS.txt (normal layout).
    try:
        from core.mcq_registry import is_mcq as _is_mcq_comp
        _mcq = _is_mcq_comp(getattr(config, "syllabus_code", "") or ms_info.syllabus_code,
                            ms_info.variant or "", getattr(ms_info, "year", None))
    except Exception:
        _mcq = False
    if _mcq:
        try:
            answers = ms_engine.extract_mcq_answers(ms_info.file_path) or {}
        except Exception as exc:
            print(f"    [guarded] MS-only MCQ: answer grid unreadable ({exc})")
            answers = {}
        matched = 0
        for n, letter in sorted(answers.items()):
            qid = f"{ms_info.variant}_{ms_info.season}_{ms_info.year}_Q{int(n)}"
            try:
                if output_mgr.promote_topic_review_mcq(config.level, config.subject, qid, letter):
                    matched += 1
            except Exception as exc:
                print(f"    [guarded] MS-only MCQ: Q{n} not paired ({exc})")
        run_ms_only_review.last_matched = matched
        print(f"    [guarded] MCQ answer key found: {matched} of {len(answers)} question(s) "
              f"paired with their QP and filed into their topic folders ({ms_info.file_path.name})")
        return matched
    try:
        ms_cropped = ms_engine.process_paper(ms_info.file_path)
    except Exception as exc:
        print(f"    [guarded] MS-only review: crop failed for {ms_info.file_path.name}: {exc}")
        return 0
    if not ms_cropped:
        print(f"    [guarded] MS-only review: no MS crops produced for {ms_info.file_path.name}")
        return 0
    saved = matched = 0
    run_ms_only_review.last_matched = 0
    for c in ms_cropped:
        try:
            res = output_mgr.save_missing_qp_question(
                c, ms_info.variant or "", ms_info.season, ms_info.year,
                ms_info.full_code, config)
            saved += 1
            if isinstance(res, dict) and res.get("promoted_from_review"):
                matched += 1
        except Exception as exc:
            print(f"    [guarded] MS-only review: save failed for {c.question_number}: {exc}")
    run_ms_only_review.last_matched = matched
    if matched:
        print(f"    [guarded] MS found for earlier no-MS questions: {matched} question(s) "
              f"paired with their QP and filed into their topic folders ({ms_info.file_path.name})")
    if saved - matched:
        print(f"    [guarded] MS-only review: {saved - matched} MS crop(s) with no QP yet -> "
              f"review_required/missing_qp ({ms_info.file_path.name})")
    return saved



def _guarded_paper_matches(paper, *, session=None, year=None,
                           subject=None, syllabus_code=None, level=None):
    """Return True when a paper belongs to the optional real-run filter."""
    if session or year:
        from core.batch_runner import _normalise_session_filter
        if session:
            wanted_season, wanted_year = _normalise_session_filter(session)
            if wanted_season and str(paper.season_letter).lower() != wanted_season:
                return False
            if wanted_year and str(paper.year_short)[-2:] != wanted_year:
                return False
        if year:
            wanted_year = str(year).strip()
            if len(wanted_year) == 4:
                wanted_year = wanted_year[-2:]
            if str(paper.year_short)[-2:] != wanted_year:
                return False
    if subject and str(subject).casefold() not in str(getattr(paper, "subject_guess", "")).casefold():
        # subject_guess can be empty for a loose filename; the subject-context
        # filter below is authoritative in that case.
        return False
    if syllabus_code and str(paper.syllabus_code) != str(syllabus_code):
        return False
    if level and str(paper.level).casefold() != str(level).casefold():
        return False
    return True


def _apply_guarded_filters(papers, sep, args):
    """Filter the real guarded run without changing the S1 recognition pass."""
    active = any(getattr(args, name, None) not in (None, "") for name in (
        "session", "year_filter", "subject_filter", "syllabus_code_filter", "level_filter"
    ))
    if not active:
        return papers, sep, False

    selected = []
    selected_by_level_subject = {}
    for level, subject_map in sep.get("by_level_subject", {}).items():
        if getattr(args, "level_filter", None) and level.casefold() != args.level_filter.casefold():
            continue
        for subject, paper_list in subject_map.items():
            if getattr(args, "subject_filter", None) and args.subject_filter.casefold() not in subject.casefold():
                continue
            keep = [p for p in paper_list if _guarded_paper_matches(
                p,
                session=getattr(args, "session", None),
                year=getattr(args, "year_filter", None),
                subject=None,
                syllabus_code=getattr(args, "syllabus_code_filter", None),
                level=level,
            )]
            if keep:
                selected_by_level_subject.setdefault(level, {})[subject] = keep
                selected.extend(keep)

    filtered_sep = dict(sep)
    filtered_sep["by_level_subject"] = selected_by_level_subject
    filtered_sep["by_subject"] = {}
    for subject_map in selected_by_level_subject.values():
        for subject, paper_list in subject_map.items():
            filtered_sep["by_subject"].setdefault(subject, []).extend(paper_list)
    print("[guarded] real-run filters: "
          f"session={getattr(args, 'session', None) or '-'} "
          f"year={getattr(args, 'year_filter', None) or '-'} "
          f"subject={getattr(args, 'subject_filter', None) or '-'} "
          f"code={getattr(args, 'syllabus_code_filter', None) or '-'} "
          f"level={getattr(args, 'level_filter', None) or '-'} -> "
          f"{len(selected)} paper file(s)")
    return selected, filtered_sep, True


def worker_main(args):
    gate, configs, papers, sep = load_inputs(args)
    level, subject, config, qp_info, ms_info, insert_info, ci_info = find_bundle(args.worker, configs, sep)
    from core.cropping_engine import CroppingEngine
    from core.ms_cropping_engine import ms_engine_for
    from core.qp_ms_matcher import QPMSMatcher
    from core.output_manager import OutputManager
    from core.pipeline_state import PipelineState

    if not qp_info:
        gate._abort("S4", f"worker bundle {args.worker}", [],
                    [("bundle resolvable", f"qp={qp_info} ms={ms_info}")])
    cropping_engine = CroppingEngine(target_width=2280, quality=95, dpi=75)
    # A20: dpi steps down for fat mark schemes (caller-owned parameter).
    ms_engine = ms_engine_for(ms_info.file_path if ms_info else None,
                              target_width=2280, quality=95)
    output_mgr = OutputManager(output_root=args.output, target_width=2280, quality=95)
    state = PipelineState.load_or_create(Path(args.output), subject=subject,
                                         syllabus_code=qp_info.syllabus_code, level=level)
    if os.environ.get("GUARDED_CHILD_NO_STATE") == "1":
        # U1: spawned by pipeline.py parallel orchestrator - parent owns state file.
        print("    [guarded] child state I/O disabled (GUARDED_CHILD_NO_STATE=1)")
        state = _NullState(state)
    saved_n = run_paper_stages(gate, args, args.worker, qp_info, ms_info, subject,
                               config, state, cropping_engine, ms_engine, QPMSMatcher(),
                               output_mgr, insert_info=insert_info, ci_info=ci_info)
    gc.collect()  # U6: full sweep before the worker reports out
    print(f"  [mem] current RSS at worker end: {_rss_mb()} MB")
    print(f"WORKER-RESULT saved={saved_n} base={args.worker}")
    gate.finish_all(f"paper worker {args.worker}", worker=True)


# ---------------------------------------------------------------------------
# RAM survival (2026-08): /tmp on this box is tmpfs (every MB pinned in RAM),
# and one S4/S5 worker peaks ~510-790MB. dmesg caught the kernel killing a
# 738MB worker at MemAvailable=3.8MB while /tmp debris from crashed runs
# held ~830MB. Two defences, both loud: a pre-spawn headroom gate (fail hard
# after a timeout instead of gambling on the OOM killer) and an orphan sweep
# for /tmp/er_tiles_* dirs a crashed worker leaves behind (its tmpfs pages
# are real RAM: 830MB of debris + a 790MB worker exceeded the 2GB box).
# ---------------------------------------------------------------------------
_WORKER_PEAK_MB = 820       # measured worst worker anon RSS 790MB + margin
_MIN_HEADROOM_MB = _WORKER_PEAK_MB + 260   # parent + platform + tmpfs slack
_HEADROOM_TIMEOUT_S = 60.0


def _mem_available_mb() -> int | None:
    try:
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except OSError:
        pass
    try:  # Windows/macOS: no /proc - psutil keeps the RAM guard active
        import psutil
        return int(psutil.virtual_memory().available // (1024 * 1024))
    except Exception:
        return None


def _purge_er_tile_orphans() -> int:
    """Remove orphaned er-tile temp dirs left by crashed workers."""
    import shutil, tempfile
    tmp = Path(tempfile.gettempdir())
    n = 0
    for d in tmp.glob("er_tiles_*"):
        try:
            shutil.rmtree(d, ignore_errors=True); n += 1
        except OSError:
            pass
    return n


def _wait_for_memory_headroom(base_key: str, output_root: Path | None = None, low_ram: bool = False) -> None:
    """Block until a worker's worst-case peak can actually be satisfied.

    A RAM timeout is a real failed gate, so leave the same failure_report.txt
    artifact as every other guarded abort before exiting.
    """
    import time
    avail = _mem_available_mb()
    if avail is None:
        print(f"  [mem] /proc/meminfo unreadable; spawning {base_key} ungated")
        return
    required_mb = 650 if low_ram else _MIN_HEADROOM_MB
    t0 = time.time()
    waited = False
    while avail < required_mb:
        if time.time() - t0 > _HEADROOM_TIMEOUT_S:
            message = (
                f"[guarded] FATAL: insufficient memory to spawn worker for "
                f"{base_key}: MemAvailable={avail}MB < required="
                f"{required_mb}MB after {_HEADROOM_TIMEOUT_S}s - "
                f"free RAM or reduce concurrent load (never gambling on OOM)"
            )
            if output_root is not None:
                try:
                    output_root.mkdir(parents=True, exist_ok=True)
                    (output_root / "failure_report.txt").write_text(
                        "failure_report\n" + message + "\n", encoding="utf-8"
                    )
                except Exception:
                    pass
            raise SystemExit(message)
        if not waited:
            print(f"  [mem] headroom {avail}MB < {required_mb}MB - "
                  f"waiting before spawning {base_key} ...")
            waited = True
        time.sleep(1.0)
        gc.collect()
        avail = _mem_available_mb()
        if avail is None:
            return
    if waited:
        print(f"  [mem] headroom OK ({avail}MB) - spawning {base_key}")


def _extract_worker_failure_reason(text: str, rc: int) -> str:
    """Best-effort single-line reason for a failed paper worker."""
    for line in text.splitlines():
        if line.startswith("FAIL  "):
            return line[6:].strip()
    for line in text.splitlines():
        if "RUN FAILED" in line or "FATAL:" in line:
            return line.strip()
    for line in reversed(text.splitlines()):
        line = line.strip()
        if line:
            return line
    return f"worker exited with code {rc}"


def count_question_folders(root) -> int:
    """Number of ``*_Q<n>`` question folders under ``root`` (the S8 invariant's
    unit). Auxiliary trees are excluded so worker logs never count as questions."""
    root = Path(root)
    if not root.exists():
        return 0
    aux = {"Examiner_Reports", "board_path", "paper_failures"}
    total = 0
    for p in root.rglob("*_Q*"):
        if not p.is_dir() or not re.search(r"_Q\d+$", p.name):
            continue
        if any(part in aux for part in p.parts):
            continue
        total += 1
    return total


_BUNDLE_FROM_PAPER = re.compile(r"^(\d{4})_([a-z]\d{2})_(?:qp|ms)_(\d+)$")


def count_question_folders_by_bundle(root) -> dict:
    """A15 (2026-09-22): the S8 unit (``count_question_folders``) split per bundle.

    Each question folder's ``metadata.json`` names its source paper
    (``0620_s24_qp_42``); that maps to the runner's bundle key
    (``0620_s24_42`` — the variant token is un-padded exactly as
    ``QPMSMatcher`` groups it). Folders without a parsable ``paper`` are
    keyed ``_unknown`` so the per-bundle total always equals the flat count.
    Auxiliary trees are excluded the same way as ``count_question_folders``.
    """
    root = Path(root)
    counts: dict = {}
    if not root.exists():
        return counts
    aux = {"Examiner_Reports", "board_path", "paper_failures"}
    for p in root.rglob("*_Q*"):
        if not p.is_dir() or not re.search(r"_Q\d+$", p.name):
            continue
        if any(part in aux for part in p.parts):
            continue
        key = "_unknown"
        meta = p / "metadata.json"
        if meta.exists():
            try:
                paper = str(json.loads(meta.read_text(encoding="utf-8")).get("paper", ""))
                m = _BUNDLE_FROM_PAPER.match(paper)
                if m:
                    key = f"{m.group(1)}_{m.group(2)}_{int(m.group(3))}"
            except (OSError, ValueError):
                pass
        counts[key] = counts.get(key, 0) + 1
    return counts


def expected_question_folders(pre_total: int, pre_by_bundle: dict, processed, total_saved: int) -> int:
    """A15: what the tree must hold at S8 for "no phantom folders" to be true.

    Folders that existed before the run and belong to bundles this run did NOT
    touch are carried over unchanged; folders of bundles that were (re)processed
    are replaced by what those bundles saved this run. ``--resume`` re-processes
    every bundle that is not COMPLETE (review_required included), so the A11 rule
    ``new_folders == saved`` could never hold on such a run (rerun13: 0 new vs 168
    saved); this formulation still fails on a genuinely stale folder (a re-run
    that saved fewer questions than it left on disk — see the tests).
    """
    replaced = sum(pre_by_bundle.get(b, 0) for b in processed)
    return max(0, pre_total - replaced) + total_saved



def _pin_no_ms_topic(classification, matched, config, topic_union):
    """Guarantee a no-MS question a topic folder inside its own paper.

    Keeps the classifier's winner when it is one of this paper's syllabus
    topics; otherwise picks the best-scoring topic of the paper; with no
    usable scores at all, the paper's first syllabus topic (confidence 0,
    fallback_tier="no_ms_paper_default") so the question is still filed under
    <Subject>/paper-N/<Topic>/review_required/ and never lost.
    """
    import dataclasses as _dc
    from core.classifier import ClassificationResult as _CR
    try:
        from core.math_category import get_paper_number_from_variant as _pn
    except Exception:  # pragma: no cover
        _pn = None
    data = getattr(config, "data", {}) or {}
    paper_no = None
    try:
        paper_no = _pn(str(getattr(matched, "variant", ""))) if _pn else None
    except Exception:
        paper_no = None
    if paper_no is None:
        v = str(getattr(matched, "variant", "") or "")
        paper_no = int(v[0]) if v[:1].isdigit() else None
    mapping = getattr(config, "mapping", {}) or {}
    majors = list(getattr(config, "major_topics", []) or [])
    allowed = list((data.get("paper_topics") or {}).get(str(paper_no), []) or []) or majors
    order = data.get("syllabus_order") or {}
    allowed.sort(key=lambda t: order.get(t, 10 ** 6))
    allowed_set = set(allowed)

    def _major(t):
        return t if t in allowed_set else mapping.get(t, t)

    if classification is not None:
        win = getattr(classification, "winning_major", "") or ""
        if win and _major(win) in allowed_set and (not topic_union or win in topic_union
                                                   or _major(win) in topic_union):
            return classification
        scores = getattr(classification, "major_topic_scores", {}) or {}
        ranked = sorted(((sc, t) for t, sc in scores.items() if _major(t) in allowed_set),
                        key=lambda x: -float(x[0] or 0))
        if ranked and float(ranked[0][0] or 0) > 0:
            best = _major(ranked[0][1])
            try:
                return _dc.replace(classification, winning_major=best,
                                   detailed_topics=[best] + [t for t in classification.detailed_topics
                                                             if t != best and _major(t) in allowed_set],
                                   fallback_tier="no_ms_paper_restricted")
            except Exception:
                pass
    if not allowed:
        return classification
    best = allowed[0]
    return _CR(detailed_topics=[best], major_topic_scores={best: 0.0}, winning_major=best,
               topic_marks_breakdown={}, reasoning="no mark scheme and no usable topic evidence: "
               "filed under the paper's first syllabus topic for review",
               fallback_tier="no_ms_paper_default", confidence=0.0)


def _close_matched_no_ms_paper(output_root, base_key, ms_info, config, matched):
    """After a newly found MS was paired with a paper's earlier no-MS
    questions, mark that paper COMPLETE in .pipeline_state.json once none of
    its questions are left in any review_required folder."""
    if not matched:
        return
    try:
        root = Path(output_root) / config.level / config.subject
        prefix = f"{ms_info.variant}_{ms_info.season}_{ms_info.year}_Q"
        left = [d for d in root.rglob(f"{prefix}*")
                if d.is_dir() and "review_required" in d.parts]
        if left:
            print(f"    [guarded] {base_key}: {len(left)} question(s) still in review_required")
            return
        from core.pipeline_state import PipelineState, PaperStatus
        st = PipelineState.load_or_create(Path(output_root), "", "", "")
        rec = st.papers.get(base_key)
        if rec is not None and rec.status is PaperStatus.REVIEW_REQUIRED:
            st.mark_complete(base_key, questions_found=matched, questions_saved=matched)
            rec.ms_path = str(ms_info.file_path)
            rec.review_reason = ""
            st.save(Path(output_root))
            print(f"    [guarded] {base_key}: mark scheme found — all {matched} question(s) "
                  f"paired and filed; paper now COMPLETE")
    except Exception as exc:
        print(f"    [guarded] {base_key}: could not update paper state ({exc})")

def _record_paper_failure(output_root: Path, base_key: str, rc: int, log_text: str,
                          reason_override: str = None, kind: str = "failed") -> dict:
    """Persist a failed (or PARTIAL) paper's log/report without stopping the batch."""
    fail_root = output_root / "paper_failures" / base_key
    fail_root.mkdir(parents=True, exist_ok=True)
    log_path = fail_root / "worker_log.txt"
    log_path.write_text(log_text, encoding="utf-8")

    reason = reason_override or _extract_worker_failure_reason(log_text, rc)
    root_report = output_root / "failure_report.txt"
    report_text = ""
    if root_report.exists():
        try:
            report_text = root_report.read_text(encoding="utf-8")
        except Exception:
            report_text = ""
        try:
            root_report.unlink()
        except Exception:
            pass
    if not report_text:
        report_text = (
            f"failure_report\n"
            f"paper bundle: {base_key}\n"
            f"worker exit: {rc}\n"
            f"reason: {reason}\n"
        )
    report_path = fail_root / "failure_report.txt"
    report_path.write_text(report_text, encoding="utf-8")
    meta = {
        "paper": base_key,
        "kind": kind,
        "worker_exit_code": rc,
        "reason": reason,
        "failure_report": str(report_path.relative_to(output_root)),
        "worker_log": str(log_path.relative_to(output_root)),
    }
    (fail_root / "summary.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def _write_failed_papers_report(output_root: Path, paper_failures: list[dict]) -> tuple[Path, Path]:
    """Aggregate all tolerated paper-worker failures into user-facing reports."""
    txt_path = output_root / "failed_papers_report.txt"
    json_path = output_root / "failed_papers_report.json"
    root_failure = output_root / "failure_report.txt"
    lines = [
        f"failed_papers_report  —  {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"failed bundles: {len(paper_failures)}",
        "",
    ]
    _partials = [p for p in paper_failures if p.get("kind") == "partial"]
    if _partials:
        lines.insert(1, f"PARTIAL bundles (questions skipped, already-saved work kept): "
                        f"{len(_partials)}")
    for i, item in enumerate(paper_failures, 1):
        lines.extend([
            f"{i}. {item.get('paper', '')}"
            + ("   [PARTIAL]" if item.get("kind") == "partial" else ""),
            f"   exit code : {item.get('worker_exit_code', '')}",
            f"   reason    : {item.get('reason', '')}",
            f"   report    : {item.get('failure_report', '')}",
            f"   worker log: {item.get('worker_log', '')}",
            "",
        ])
    text = "\n".join(lines)
    txt_path.write_text(text, encoding="utf-8")
    root_failure.write_text(text, encoding="utf-8")
    json_path.write_text(json.dumps({"failed_papers": paper_failures}, indent=2), encoding="utf-8")
    return txt_path, json_path


def spawn_paper_worker(args, base_key) -> tuple:
    """Run one bundle in an isolated subprocess; stream its output. Returns (rc, saved, log_text)."""
    cmd = [sys.executable, "-u", str(Path(__file__).resolve()),
           "--input", str(args.input), "--output", str(args.output),
           "--_worker", base_key]
    if args.low_ram:
        cmd.append("--low-ram")
    if getattr(args, "batch_size", 0):
        cmd += ["--batch-size", str(int(args.batch_size))]
    if getattr(args, "resume", False):
        # Question-level batching resumes per QUESTION, and that decision lives
        # in the worker (it owns the ledger). Without this the parent's --resume
        # only skipped whole papers and every batched question was redone.
        cmd.append("--resume")
    if (getattr(args, "full_auto", True) or getattr(args, "trust_self", False)) \
            and not getattr(args, "no_full_auto", False):
        cmd.append("--full-auto")
    if getattr(args, "manifest", None):
        cmd += ["--manifest", str(args.manifest)]
    if getattr(args, "no_manifest", False):
        cmd.append("--no-manifest")
    if getattr(args, "manifest_full_check", False):
        cmd.append("--manifest-full-check")
    if getattr(args, "classification_memory", None):
        cmd += ["--classification-memory", str(args.classification_memory)]
    if getattr(args, "write_high_confidence_memory", False):
        cmd.append("--write-high-confidence-memory")
    if getattr(args, "memory_high_confidence_threshold", None) is not None:
        cmd += ["--memory-high-confidence-threshold", str(args.memory_high_confidence_threshold)]
    _orphans = _purge_er_tile_orphans()
    if _orphans:
        print(f"  [mem] purged {_orphans} orphaned er_tiles_* dir(s) from crashed workers")
    _wait_for_memory_headroom(base_key, Path(args.output), low_ram=bool(args.low_ram))
    print(f"\n[guarded] paper {base_key}: isolated process …")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1)
    buf = []
    for line in proc.stdout:
        sys.stdout.write(line)
        buf.append(line)
    rc = proc.wait()
    _purge_er_tile_orphans()
    gc.collect()
    log_text = "".join(buf)
    m = WORKER_OK.search(log_text)
    saved = int(m.group(1)) if m else (-9 if rc == 0 else -8)
    return rc, saved, log_text


def main():
    ap = argparse.ArgumentParser(description="Self-checking guarded runner (locked pipeline, gate between every stage)")
    ap.add_argument("--input", "-i", default="input")
    ap.add_argument("--output", "-o", default="output")
    ap.add_argument("--clean", action="store_true")
    ap.add_argument("--low-ram", action="store_true",
                    help="QP: RAM-safe streaming harness (production-identical segmentation)")
    ap.add_argument("--manifest", default=None,
                    help="batch manifest path (default <input>/.batch_manifest.json; env GUARDED_MANIFEST_JSON honoured)")
    ap.add_argument("--no-manifest", action="store_true",
                    help="disable the manifest cache; force live per-worker identification (pre-RS-9 behaviour)")
    ap.add_argument("--manifest-full-check", action="store_true",
                    help="hash-verify every file against the manifest (slow, max paranoia)")
    # Mega-spec Fix 1 flags (2026-08-12)
    ap.add_argument("--workers", type=int, default=2,
                    help="bounded parallel bundle workers (default 2). Honest "
                         "note: per-paper process isolation is sequential on "
                         "this box by design — the flag is accepted, recorded "
                         "and clamped so RAM-safe ordering is never violated.")
    ap.add_argument("--no-ocr-review", action="store_true",
                    help="file OCR-flagged crops by topic instead of routing them to "
                         "review_required (default: OCR uncertainty means REVIEW)")
    ap.add_argument("--batch-size", type=int,
                    default=int(os.environ.get("GUARDED_BATCH_SIZE", "0") or 0),
                    help="question-level batching: classify+save at most N questions "
                         "per memory batch (0 = one batch, the historic semantics)")
    ap.add_argument("--resume", action="store_true",
                    help="skip bundles already COMPLETE in pipeline state "
                         "(this is also the default; the flag documents intent)")
    ap.add_argument("--retry-failed", action="store_true",
                    help="reset FAILED bundles to PENDING before the run")
    ap.add_argument("--dry-run", action="store_true",
                    help="identify, group, and print the per-bundle plan "
                         "(strategies, missing MS, review items) without "
                         "processing anything")
    ap.add_argument("--full-auto", action="store_true", default=True,
                    help="DEFAULT ON: auto-classify valid QP/MS pairs and valid "
                         "MCQ grid answers. It never bypasses structured MS "
                         "requirements; structured QP-only crops remain under "
                         "review_required.")
    ap.add_argument("--no-full-auto", action="store_true", default=False,
                    help="Also route ambiguous/no-evidence classification to review.")
    ap.add_argument("--classification-memory", default=None,
                    help="SQLite indexed classification-memory path. Existing stores are read for supporting evidence; absent default store stays disabled unless high-confidence writing is explicitly enabled.")
    ap.add_argument("--write-high-confidence-memory", action="store_true", default=False,
                    help="OPT-IN: queue scored high-confidence predictions and commit them only after the whole paper completes. Never writes metadata.json.")
    ap.add_argument("--memory-high-confidence-threshold", type=float, default=0.95,
                    help="minimum calibrated classifier confidence for OPT-IN high-confidence memory writes (default 0.95)")
    ap.add_argument("--trust-self", action="store_true", default=False,
                    help="Alias for automatic classification only; never creates "
                         "a structured missing-MS placeholder.")
    ap.add_argument("--session", default=None,
                    help="REAL RUN FILTER: process one session, e.g. s26, summer, m26, winter, or specimen")
    ap.add_argument("--year", dest="year_filter", default=None,
                    help="REAL RUN FILTER: process one two- or four-digit exam year")
    ap.add_argument("--subject", dest="subject_filter", default=None,
                    help="REAL RUN FILTER: process subjects containing this text")
    ap.add_argument("--syllabus-code", dest="syllabus_code_filter", default=None,
                    help="REAL RUN FILTER: process one exact syllabus code")
    ap.add_argument("--level", dest="level_filter", default=None,
                    choices=("IGCSE", "A-Level"),
                    help="REAL RUN FILTER: process only IGCSE or A-Level")
    ap.add_argument("--validate", action="store_true",
                    help="run ONLY the final output audit (S8) on --output and exit")
    ap.add_argument("--_worker", dest="worker", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()
    if not 0.0 <= float(args.memory_high_confidence_threshold) <= 1.0:
        ap.error("--memory-high-confidence-threshold must be between 0 and 1")

    if args.worker:
        worker_main(args)
        return

    if args.validate:
        # Mega-spec required command: main/run_guarded --validate = audit-only.
        from core.validation import FinalValidator
        result = FinalValidator(output_root=args.output).validate_all()
        review_roots = {"review_required", "review_required_no_ms"}
        review_present = any(
            path.is_dir() and any(part in review_roots for part in path.parts)
            for path in Path(args.output).rglob("*")
        ) if Path(args.output).exists() else False
        _state_file = Path(args.output) / ".pipeline_state.json"
        if _state_file.exists():
            try:
                _payload = json.loads(_state_file.read_text(encoding="utf-8"))
                review_present = review_present or any(
                    "review" in str(record.get("status", "")).lower()
                    for record in _payload.get("papers", {}).values()
                )
            except Exception:
                pass
        status = "PASS — REVIEW REQUIRED" if result["passed"] and review_present else (
            "PASS" if result["passed"] else "FAIL"
        )
        print(f"[validate] {status}: "
              f"errors={result.get('total_errors', 0)} output={args.output}")
        for e in result.get("errors", [])[:20]:
            print(f"  [validate] ERROR: {e}")
        if not result["passed"]:
            raise SystemExit(1)
        raise SystemExit(2 if review_present else 0)

    if args.workers != 2:
        print(f"[guarded] --workers={args.workers}: recorded; per-paper isolation "
              f"stays sequential for RAM safety (worker dies with its peak heap); "
              f"for parallel bundles use run_pipeline.py --workers N (RAM-guarded)")
    if args.resume:
        print("[guarded] --resume: completed bundles are skipped (default behavior; flag recorded)")

    print(f"[guarded] QP path: {'RAM-SAFE streaming (locked triplet, low-ram)' if args.low_ram else 'production CroppingEngine (main.py-exact)'}")
    print(f"[guarded] per-paper process isolation: ON (worker dies with its peak heap)")

    # Files named .pdf that are really HTML "not published" pages (common in
    # bulk downloads, e.g. 0606_s26_ms_23 / 0606_s26_er) used to crash a
    # worker or stop S6 -> exit 1. Set them aside first; treat as missing.
    if not getattr(args, "dry_run", False):
        from core.input_screen import screen_input_pdfs
        screen_input_pdfs(args.input, args.output)

    gate, configs, papers, sep = load_inputs(args)
    papers, sep, _filters_used = _apply_guarded_filters(papers, sep, args)
    if _filters_used and not any(p.paper_type == "qp" for p in papers):
        gate._abort(
            "S1", "real-run selection filter", [],
            [("matching question-paper bundle", "no QP matched the requested filters")],
        )
    output_root = Path(args.output)

    from core.qp_ms_matcher import QPMSMatcher
    from core.pipeline_state import PipelineState

    if args.retry_failed:
        _st = PipelineState.load_or_create(output_root, subject="_run", syllabus_code="", level="")
        _n = _st.reset_failed()
        _st.save(output_root)
        print(f"[guarded] --retry-failed: {_n} failed bundle(s) returned to PENDING")

    if args.dry_run:
        # Mega-spec Fix 1: one-pass plan only. Nothing is processed, nothing
        # is written to the output tree beyond the manifest S1 already wrote.
        from core.strategies import strategy_plan_for_paper
        print("\n[guarded] DRY RUN plan (no processing):")
        _matcher = QPMSMatcher()
        _groups = _matcher.group_papers(papers)
        for _bk, _td in sorted(_groups.items()):
            _qp = _td.get("qp")
            _plan = strategy_plan_for_paper(_qp) if _qp is not None else None
            print(f"  - {_bk}: qp={'Y' if 'qp' in _td else '-'} ms={'Y' if 'ms' in _td else '-'} "
                  f"er={'Y' if 'er' in _td else '-'}"
                  + (f" | strategy {_plan.name} ({_plan.reason})" if _plan else " | ER/insert-only"))
            if "qp" in _td and "ms" not in _td:
                print(f"      REVIEW: no mark scheme supplied — "
                      f"the bundle runs QP-only (review_required_no_ms)")
        if _matcher.grouping_errors:
            print(f"  duplicate/conflict grouping errors: {_matcher.grouping_errors}")
        print("[guarded] DRY RUN complete — 0 papers processed")
        return

    total_saved = 0
    # Resume baseline: folders that already existed BEFORE this run. Question-level
    # batching can legitimately save nothing new on a resume run (every question
    # already recorded as saved), and an output tree that is already complete must
    # not be reported as a phantom-folder failure.
    _pre_folders = count_question_folders(output_root)
    # A15: per-bundle baseline so re-processed bundles (review_required on
    # --resume, requeued snapshots) replace their own old folders in the count.
    _pre_by_bundle = count_question_folders_by_bundle(output_root)
    _processed_bundles = set()
    if _pre_folders:
        print(f"[guarded] resume baseline: {_pre_folders} question folder(s) already on disk")
    board_saved_total = 0   # adapter-driven board path runs its own S2-S5
    board_renders = []      # (paper dir, questions rendered) for the S8 disk check
    paper_failures = []
    for level in _levels_in_order(sep):
        if level not in sep["by_level_subject"]:
            continue
        from collections import defaultdict
        for subject, paper_list in sep["by_level_subject"][level].items():
            print(f"\n[guarded] subject context {level}/{subject}: {len(paper_list)} papers")
            if paper_list and not any(_is_caie_board(p) for p in paper_list):
                # 2026-09-21: a board-scoped context has no CAIE stage to run.
                # Hand it to the adapter-driven universal batch runner (S2-S5),
                # then move on - the Cambridge gates below would mis-measure it.
                board_saved_total += _run_board_path(gate, args, level, subject,
                                                     paper_list, output_root,
                                                     renders_out=board_renders)
                continue
            by_year = defaultdict(list)
            for p in paper_list:
                by_year[p.year].append(p)

            for year, year_papers in by_year.items():
                matcher = QPMSMatcher()
                groups = matcher.group_papers(year_papers)

                # RS-13 (S4-fix round): an ER/insert-ONLY context has nothing to
                # pair by definition — skip it loudly instead of aborting the
                # whole run (pre-existing defect: one orphan-ER subject killed
                # an otherwise-clean batch at this gate). Duplicate-input
                # grouping errors remain a hard gate even here.
                _bundles_n = sum(1 for _v in groups.values() if ("qp" in _v or "ms" in _v))
                if _bundles_n == 0 and not matcher.grouping_errors:
                    print(f"    [guarded] SKIP {subject} {year}: no QP/MS bundles — "
                          f"ER/insert-only context ({len(groups)} group(s)); orphan ER "
                          f"output handled at S6/S7 and listed at run end")
                    continue

                # ---------- S4 grouping gates (structure only) ----------
                def s4(check, groups=groups, year=year):
                    check("no duplicate-input grouping errors", len(matcher.grouping_errors) == 0,
                          str(matcher.grouping_errors) if matcher.grouping_errors else "clean")
                    bundles = {k: v for k, v in groups.items() if ("qp" in v or "ms" in v)}
                    loners = [k for k, v in groups.items() if ("qp" not in v and "ms" not in v)]
                    check("at least one QP/MS group", len(bundles) > 0,
                          f"{len(bundles)} bundles, {len(loners)} er/insert-only groups")
                    for k in loners:
                        print(f"    [info] {k}: no QP/MS — handled in ER stages S6/S7")
                    for base_key, td in bundles.items():
                        if "qp" not in td:
                            # MS-only bundle: not a hard gate — the MS-only
                            # review path (review_required/missing_qp) handles it.
                            print(f"    [info] {base_key}: no QP (MS-only) -> "
                                  f"review_required/missing_qp")
                            continue
                        check(f"{base_key}: has QP", True, ",".join(td.keys()))
                        if "ms" not in td:
                            # Overseer RULE 2: no MS -> QP preserved to review_required
                            print(f"    [info] {base_key}: no MS - QP-only run, questions -> review_required/no_markscheme")
                            continue
                        if "qp" in td and "ms" in td:
                            check(f"{base_key}: QP/MS level agree", td["qp"].level == td["ms"].level,
                                  f"{td['qp'].level} vs {td['ms'].level}")
                    return None

                gate.run_stage("S4", f"{ALL_STAGES[4][1]} [{subject} {year}]", s4)

                for base_key, td in groups.items():
                    if "qp" not in td:
                        if "ms" in td:
                            print(f"    [info] {base_key}: no QP — supply it; "
                                  f"the MS is preserved in review_required/missing_qp")
                        else:
                            print(f"    [info] {base_key}: support file only "
                                  f"(grade thresholds / ER / insert) — no questions to cut")
                        # 2026-08-15 (user requirement): don't drop the bundle —
                        # crop the MS (if present) and preserve it in
                        # review_required/missing_qp for human fixing.
                        if "ms" in td:
                            try:
                                from core.config_loader import load_subject_config_by_code_and_level
                                _ms_info = td["ms"]
                                _cfg = load_subject_config_by_code_and_level(
                                    _ms_info.syllabus_code, _ms_info.level, year)
                                if _cfg is None:
                                    print(f"    [guarded] MS-only review: no config "
                                          f"for {_ms_info.syllabus_code}/{_ms_info.level} — skip")
                                else:
                                    _ms_only_n = run_ms_only_review(
                                        _ms_info, subject, _cfg, output_root,
                                        low_ram=bool(getattr(args, "low_ram", True)))
                                    total_saved += _ms_only_n
                                    _processed_bundles.add(base_key)
                                    _close_matched_no_ms_paper(
                                        output_root, base_key, _ms_info, _cfg,
                                        getattr(run_ms_only_review, "last_matched", 0))
                            except Exception as _exc:
                                print(f"    [guarded] MS-only review failed for "
                                      f"{base_key}: {_exc}")
                        else:
                            print(f"    [info] {base_key}: no QP and no MS — nothing to crop")
                        continue  # QP-less groups never produce QP output; ER handled post-loop
                    rc, saved_n, worker_log = spawn_paper_worker(args, base_key)
                    _skips = WORKER_SKIP.findall(worker_log or "")
                    if f"RESUME-SKIP {base_key}" not in (worker_log or ""):
                        _processed_bundles.add(base_key)  # A15: its old folders are replaced

                    def wp(check, bk=base_key, rc=rc, sn=saved_n, failures=paper_failures,
                           sk=tuple(_skips)):
                        _ok = (rc == 0 and sn >= 0)
                        _detail = f"exit={rc}, saved={sn}"
                        if not _ok:
                            _reason = _extract_worker_failure_reason(worker_log, rc)
                            _detail += f" | {_reason}"
                        check(f"{bk}: worker process exited cleanly", _ok, _detail)
                        check(f"{bk}: worker reported saved count", sn >= 0, f"saved={sn}")
                        if sk:
                            # Soft failure: the stage continues, the paper is named.
                            check(f"{bk}: every question saved (question batching)", False,
                                  f"{len(sk)} skipped: " + ", ".join(s[1] for s in sk))
                        return max(sn, 0)

                    saved_n = gate.run_stage("S5", f"paper worker result [{base_key}]", wp,
                                             abort_on_fail=False)
                    if rc == 0 and saved_n >= 0:
                        total_saved += saved_n
                        if _skips:
                            _partial_reason = (
                                f"partial: {len(_skips)} question(s) skipped for memory - "
                                + "; ".join(f"{s[1]}: {s[2][:100]}" for s in _skips))
                            failure = _record_paper_failure(
                                output_root, base_key, rc, worker_log,
                                reason_override=_partial_reason, kind="partial")
                            paper_failures.append(failure)
                            print(f"    [guarded] {base_key}: PARTIAL - {len(_skips)} "
                                  f"question(s) skipped (already-saved work kept): "
                                  f"paper_failures/{base_key}/batch_progress.jsonl")
                    else:
                        failure = _record_paper_failure(output_root, base_key, rc, worker_log)
                        paper_failures.append(failure)
                        print(f"    [guarded] continuing after failed paper {base_key}: {failure['reason']}")
                    gc.collect()

    # ---------- S6 ER text ----------
    # Board-scoped ERs were parsed by the board path above (adapters.companion_segments
    # -> ER notes + question links). Only CAIE ERs may enter the CAIE ER parser:
    # feeding it an AQA report fails the stage on a report that was never its job.
    er_papers = [p for p in papers if p.paper_type == "er" and _is_caie_board(p)]
    _board_er_papers = [p for p in papers if p.paper_type == "er" and not _is_caie_board(p)]
    if _board_er_papers:
        print("[guarded] board examiner report(s) handled by the board path: "
              + ", ".join(p.file_path.name for p in _board_er_papers))

    # RS-13: orphan ERs = examiner reports whose paper context produced no
    # question folders this run (their subject was skipped at S4 by design).
    # They parse and report fine, but there is nothing to attach to.
    _QDIR_RE = re.compile(r"_Q\d+$")
    orphan_ers = []
    for _p in er_papers:
        _level_root = Path(args.output) / _p.level
        _attachable = (
            any(qd.is_dir() and _QDIR_RE.search(qd.name)
                for sd in _level_root.glob(f"*_{_p.syllabus_code}")
                for qd in sd.rglob("*"))
            if _level_root.exists() else False
        )
        if not _attachable:
            orphan_ers.append(_p)
    if orphan_ers:
        print(f"[guarded] orphan examiner reports (no question output to attach to): "
              + ", ".join(Path(p.file_path).name for p in orphan_ers))

    def s6(check):
        if not er_papers:
            check("no ER papers supplied — stage skipped by design", True, "")
            return None
        from core.examiner_report import attach_examiner_reports_to_output
        stats = attach_examiner_reports_to_output(er_papers, output_root)
        check("ER: no processing errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        check("ER: every detected report parsed", stats["reports_parsed"] == stats["reports_detected"],
              f"{stats['reports_parsed']}/{stats['reports_detected']}")
        check("ER: commentary attached to questions",
              stats["questions_attached"] > 0 or (er_papers and len(orphan_ers) == len(er_papers)),
              f"{stats['questions_attached']} attached"
              + (f" ({len(orphan_ers)}/{len(er_papers)} ERs orphan — nothing to attach to)"
                 if orphan_ers else ""))
        return stats

    _er_attach_stats = gate.run_stage("S6", ALL_STAGES[6][1], s6)
    try:
        from core.examiner_report import clear_er_tile_cache
        clear_er_tile_cache()  # RS-18: /tmp tile caches drop here, not at exit
    except Exception:
        pass

    # ---------- S7 ER crops ----------
    def s7(check):
        if not er_papers:
            check("no ER papers supplied — stage skipped by design", True, "")
            return None
        from core.er_question_crops import attach_question_er_crops
        stats = attach_question_er_crops(
            er_papers, output_root,
            verified_folders=(_er_attach_stats or {}).get("verified_folders"))
        check("ER crops: no errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        er_verified_ok, er_verified_detail = er_crop_verification_gate(stats)
        check("ER crops: no containment-verification failures", er_verified_ok,
              er_verified_detail)
        from PIL import Image
        tiles = [p for p in output_root.rglob("*_ER.webp")]
        check("ER crops: at least one crop on disk",
              len(tiles) > 0 or (er_papers and len(orphan_ers) == len(er_papers)),
              f"{len(tiles)} tiles"
              + (f" ({len(orphan_ers)}/{len(er_papers)} ERs orphan)" if orphan_ers else ""))
        for t in tiles:
            with Image.open(t) as im:
                check(f"ER crop {t.parent.name}/{t.name}: width 2280", im.width == TARGET_WIDTH,
                      f"{im.size}")
        return stats

    gate.run_stage("S7", ALL_STAGES[7][1], s7)

    # ---------- S7b grade thresholds (gt extraction) ----------
    gt_papers = [p for p in papers if p.paper_type == "gt"]

    def s7b(check):
        if not gt_papers:
            check("no grade-threshold (gt) files supplied — stage skipped by design", True, "")
            return None
        from core.grade_threshold import write_grade_thresholds
        written = 0
        failed = []
        for p in gt_papers:
            try:
                res = write_grade_thresholds(
                    p.file_path, output_root,
                    level=p.level,
                    season_letter=p.season_letter,
                    year_short=p.year_short,
                )
            except Exception as exc:
                res = None
                print(f"    [gt] extraction error for {Path(p.file_path).name}: {exc}")
            if res is None:
                failed.append(Path(p.file_path).name)
            else:
                written += 1
        check("every gt file extracted", len(failed) == 0,
              f"{written} written"
              + (f"; failed: {failed}" if failed else ""))
        return written

    gate.run_stage("S7b", "grade-threshold extraction", s7b)

    # ---------- S8 final validation ----------
    from core.validation import FinalValidator
    from core.output_manager import OutputManager
    output_mgr = OutputManager(output_root=args.output, target_width=2280, quality=95)

    def s8(check):
        removed = output_mgr.cleanup_empty_and_invalid_folders()
        check("cleanup ran", True, f"removed {len(removed)} invalid folders" if removed else "nothing invalid")
        dup_errors, _ = output_mgr.ensure_no_duplicate_distribution()
        check("no duplicate distribution", len(dup_errors) == 0,
              str(dup_errors[:3]) if dup_errors else "clean")
        qpms_errors = output_mgr.validate_qp_ms_pairs()
        check("QP/MS pairs valid on disk", len(qpms_errors) == 0,
              str(qpms_errors[:3]) if qpms_errors else "clean")
        result = FinalValidator(output_root=output_root).validate_all()
        check("final audit passes", result["passed"], f"errors={result.get('total_errors', 0)}")
        folders_n = count_question_folders(output_root)
        # The invariant is "no phantom folders": everything on disk was either
        # saved by this run or already there when it started (resume). A15:
        # bundles that were (re)processed replace their own pre-existing
        # folders, so the baseline is reduced by exactly those before adding
        # what this run saved.
        _replaced = sum(_pre_by_bundle.get(b, 0) for b in _processed_bundles)
        _expected = expected_question_folders(_pre_folders, _pre_by_bundle, _processed_bundles, total_saved)
        check("question folders on disk == saved this run", folders_n == _expected,
              f"{folders_n} folders on disk vs {_expected} expected "
              f"({_pre_folders} pre-existing - {_replaced} replaced by {len(_processed_bundles)} "
              f"re-processed bundle(s) + {total_saved} saved)")
        if board_saved_total:
            # The board path has its own layout (board_path/final/<BOARD>/...) and
            # its own audit; compare each paper's own directory against its own
            # rendered count instead of measuring it with a CAIE folder pattern
            # (question_packs/ holds COPIES of the same images by design).
            _bad = []
            for _dir, _n in board_renders:
                # Count QUESTION crops only (2026-09-29). Since the per-question ER attachment landed
                # (CLS-175/178d) the paper's own directory also holds `Q{n}_ER.webp` (and `Q{n}_IN.webp`)
                # beside `{component}_{season}_{year}_Q{n}.webp`, so a bare `*.webp` count read a
                # 1-question limited run as "11 on disk vs 1 rendered" and failed this gate on every
                # run that had an examiner report. Both the gate's intent -- no phantom question
                # crops -- and the attachment feature are worth keeping, so the pattern is the fix.
                _found = len([p for p in Path(_dir).glob("*.webp")
                              if re.match(r".*_Q\d+\.webp$", p.name)])
                if _found != _n:
                    _bad.append(f"{Path(_dir).name}: {_found} on disk vs {_n} rendered")
            check("board path questions on disk == rendered", not _bad,
                  "; ".join(_bad) if _bad
                  else f"{board_saved_total} question(s) across {len(board_renders)} paper(s)")
        # RS-13: state-mirror parity (phase-1 posture: advisory, never fatal).
        # JSON remains authoritative; drift is reported loudly, not gated.
        _state_file = Path(args.output) / ".pipeline_state.json"
        if _state_file.exists():
            try:
                from core.pipeline_state import PipelineState as _PS
                from core.state_mirror import verify_parity as _vp
                _st = _PS.load_or_create(Path(args.output), "", "", "")
                _ok, _drift = _vp(_st, Path(args.output))
                if _ok:
                    check("state-mirror parity (advisory)", True,
                          f"MIRRORED OK ({len(_st.papers)} papers)")
                else:
                    print(f"  [state-mirror] PARITY DRIFT (advisory): {_drift[:3]}")
                    check("state-mirror parity (advisory)", True,
                          f"DRIFT x{len(_drift)}: {_drift[:2]}")
            except Exception as _exc:
                print(f"  [state-mirror] parity check skipped ({_exc})")
                check("state-mirror parity (advisory)", True, f"skipped: {_exc}")
        return result

    gate.run_stage("S8", ALL_STAGES[8][1], s8)

    print(f"\n[guarded] questions saved: {total_saved}"
          + (f" (+{board_saved_total} via the adapter-driven board path)" if board_saved_total else ""))
    if paper_failures:
        txt_report, json_report = _write_failed_papers_report(output_root, paper_failures)
        print(f"[guarded] failed paper bundles recorded: {len(paper_failures)}")
        print(f"[guarded] failed-papers reports: {txt_report} and {json_report}")
    if orphan_ers:
        print(f"[guarded] orphan ERs unused this run (supply their QP/MS to use them): "
              + ", ".join(Path(p.file_path).name for p in orphan_ers))
    try:
        from core.run_report import build_reports
        _rep = build_reports(output_root, paper_failures)
        print(f"[guarded] run report: {_rep['report']}")
        print(f"[guarded] QA gallery: {_rep['gallery']}")
    except Exception as _rep_exc:
        print(f"[guarded] run report skipped ({type(_rep_exc).__name__}: {_rep_exc})")
    gate.finish_all("full guarded run", paper_failures=paper_failures)


if __name__ == "__main__":
    main()
