"""Board-aware topic hints for universal batch outputs (AQA spec taxonomies + Edexcel keywords).

AQA (2026-09-23, AQA fix round MAIN 1): topics come from the official specifications, one
vocabulary per specification code, with three evidence tiers and word-form expansion. The old
board-level keyword dict is kept ONLY as a fallback for a paper whose specification code cannot
be read (``AQA_LEGACY_KEYWORDS``); it is never the primary path for 8462 / 8702.

Scoring (documented so the numbers mean something):

* every keyword has a weight — diagnostic 3 (a term that names the topic: "electrolysis",
  "nanoparticle", "Act 1 Scene 5"), specific 2 (strongly associated: "titration", "alloy",
  "narrator"), generic 1 ("mass", "volume", "acid" — real words of the topic that also appear
  elsewhere, so they only corroborate);
* a keyword matches in any of its word forms (``bond`` → bond/bonds/bonded/bonding,
  ``metal`` → metal/metals/metallic, ``electron`` → electron/electrons) — plain words are
  expanded automatically, irregular forms are written out in the vocabulary;
* topic score = Σ weight × sqrt(min(occurrences, 3)) over the DISTINCT keywords that matched
  (repetition helps a little, never dominates);
* a topic is a HINT only with minimum evidence: score ≥ 3 and (one diagnostic/specific match
  OR three distinct generic matches). Otherwise the question is UNKNOWN → review_required.
  Generic words alone can no longer decide a question;
* ties are broken by evidence, never by name: score → number of distinct keywords matched →
  longest matched keyword → topic id (documented deterministic last resort);
* confidence = 0.50 + 0.30 × margin + 0.20 × strength, where margin = (top − second) / top
  and strength = min(1, top / 9). Calibrated on the June-2023 8462 and 8702-specimen verdict
  tables: unambiguous winners land ≥ 0.75, debatable ones 0.5–0.75, everything without
  minimum evidence is gated to UNKNOWN (0.0).

The scored text is the question's OWN crop rects (layout lines inside the segment's page
rects); whole-page text is used only when the rect holds no text, and the result says so
(``text_source``).

English Literature (8702) follows the CAIE 0475 precedent: forms (Poetry / Prose / Drama /
Unseen_texts) are the primary, folder-naming topic; Literary_techniques / Themes_and_characterisation /
Context_and_comparison are secondary aspects. Set-text titles and author names are never topics.
"""
from __future__ import annotations

import math
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

from adapters.base import DocumentContext

# --------------------------------------------------------------------------- weights / grammar
WEIGHTS = {"diagnostic": 3.0, "specific": 2.0, "generic": 1.0}
MIN_SCORE = 3.0
_SUFFIX = r"(?:s|es|ed|ing|ion|ions)?"


def keyword_regex(keyword: str) -> re.Pattern:
    """Word-form expansion. A keyword written with regex meta (``metal(s|lic)?``) is used as
    written; a plain word gets ``s/es/ed/ing/ion`` endings; multi-word keywords expand each
    word and allow any whitespace between them."""
    kw = keyword.strip().lower()
    if any(ch in kw for ch in "()|[]?+*\\"):
        return re.compile(r"\b" + kw + r"\b", re.I)
    words = [re.escape(w) + _SUFFIX for w in kw.split()]
    return re.compile(r"\b" + r"\s+".join(words) + r"\b", re.I)


# --------------------------------------------------------------------------- AQA specifications
# Sources (fetched 2026-09-23, hashed):
#   8462 GCSE Chemistry specification: https://filestore.aqa.org.uk/resources/chemistry/specifications/AQA-8462-SP-2016.PDF
#        sha256 ecd869d1874091a0a52abaeb8fce238a9c1cc207698713dfb66788eb0d448d43 (§4.1–4.10, pp. 18–88)
#   8702 GCSE English Literature specification: https://filestore.aqa.org.uk/resources/english/specifications/AQA-8702-SP-2015.PDF
#        sha256 3b7d3b63998b6fd8b1bfbc169fcde53cf7b9d395da778f45e9b9c9e23c03aebe (subject content + AO1–AO4)
AQA_SPECS: Dict[str, Dict[str, Any]] = {
    "8462": {
        "name": "GCSE Chemistry",
        "source": "https://filestore.aqa.org.uk/resources/chemistry/specifications/AQA-8462-SP-2016.PDF",
        "sha256": "ecd869d1874091a0a52abaeb8fce238a9c1cc207698713dfb66788eb0d448d43",
        "classes": None,                       # one class: every topic can be primary
        "topics": {
            "atomic_structure_periodic_table": {
                "spec": "4.1 Atomic structure and the periodic table (4.1.1–4.1.3)",
                "diagnostic": ["periodic table", "plum pudding", "isotope", "atomic number", "mass number",
                               "relative atomic mass", "electronic structure", "noble gas", "group 7", "group 1",
                               "group 0", "halogen", "alkali metal", "transition metal", "nuclear model", "subatomic"],
                "specific": ["proton", "neutron", "electron shell", "outer shell", "atom", "element", "compound", "mixture",
                             "group 2", "chromatography", "filtration", "crystallisation", "distillation"],
                "generic": ["electron", "nucleus", "shell", "group", "period", "symbol"],
            },
            "bonding_structure_properties": {
                "spec": "4.2 Bonding, structure, and the properties of matter (4.2.1–4.2.4)",
                "diagnostic": ["ionic bond", "covalent bond", "metallic bond", "bond(s|ed|ing)?", "nanoparticle",
                               "graphene", "fullerene", "nanotube", "giant covalent", "delocalised electron", "alloy",
                               "intermolecular", "lattice", "diamond", "graphite", "state symbol", "dot and cross"],
                "specific": ["conduct(s|ing|ivity)? electricity", "electrical conductivity", "metal(s|lic)?",
                             "melting point", "boiling point", "structure", "polymer", "particle model", "surface area to volume"],
                "generic": ["ion", "molecule", "solid", "liquid", "gas", "layer", "property", "properties"],
            },
            "quantitative_chemistry": {
                "spec": "4.3 Quantitative chemistry (4.3.1–4.3.5)",
                "diagnostic": ["relative formula mass", "mol/dm3", "moles?", "avogadro", "atom economy", "percentage yield",
                               "limiting reactant", "conservation of mass", "dm3", "g/dm3", "concentration"],
                "specific": ["titration", "calculate the mass", "calculate the volume", "balanced equation",
                             "volume of (the )?gas", "24 dm3", "mr", "ar", "uncertainty"],
                "generic": ["mass", "volume", "calculate", "kg", "grams?", "yield"],
            },
            "chemical_changes": {
                "spec": "4.4 Chemical changes (4.4.1 reactivity of metals, 4.4.2 reactions of acids, 4.4.3 electrolysis)",
                "diagnostic": ["electrolysis", "electrolys(e|ed|ing)", "electrode", "half equation", "reactivity series",
                               "displacement", "neutralisation", "soluble salt", "oxidation", "reduction", "reduced", "oxidised",
                               "cryolite", "extracted", "extraction", "weak acid", "strong acid", "ionisation"],
                # "acid"/"alkali"/"salt"/"pH" occur in titration, rate and energy questions too — they
                # corroborate 4.4 but cannot decide it (the June-2023 Q5 titration question is quantitative).
                "specific": ["hydrochloric acid", "sulfuric acid", "nitric acid", "carbonate", "metal oxide", "hydroxide",
                             "crystals", "insoluble", "reacts with", "more reactive", "less reactive", "dilute acid"],
                "generic": ["acid", "alkali", "salt", "ph", "react", "reaction", "product", "dilute", "solution", "observation"],
            },
            "energy_changes": {
                "spec": "4.5 Energy changes (4.5.1 exothermic/endothermic, 4.5.2 cells and fuel cells)",
                "diagnostic": ["exothermic", "endothermic", "activation energy", "bond energy", "bond energies",
                               "reaction profile", "energy change", "temperature change", "fuel cell", "chemical cell",
                               "energy (is )?released", "energy (is )?transferred", "energy level diagram"],
                "specific": ["temperature", "polystyrene cup", "thermometer", "surroundings", "energy", "kj/mol", "overall energy",
                             "lowest temperature", "highest temperature", "hand warmer", "self-heating"],
                "generic": ["heat", "hydrogen", "battery", "cell"],
            },
            "rates_equilibrium": {
                "spec": "4.6 The rate and extent of chemical change (4.6.1 rate of reaction, 4.6.2 reversible reactions and equilibrium)",
                "diagnostic": ["rate of reaction", "rate of the reaction", "catalyst", "equilibrium", "le chatelier",
                               "reversible reaction", "collision theory", "dynamic equilibrium", "mean rate", "activation energy"],
                "specific": ["rate", "reversible", "frequency of collisions", "gradient", "tangent", "surface area", "pressure",
                             "concentration", "temperature", "position of equilibrium"],
                "generic": ["faster", "slower", "time taken", "collision"],
            },
            "organic_chemistry": {
                "spec": "4.7 Organic chemistry (4.7.1 fuels and feedstock, 4.7.2 alkenes and alcohols, 4.7.3 polymers)",
                "diagnostic": ["alkane", "alkene", "crude oil", "hydrocarbon", "fractional distillation", "cracking", "alcohol",
                               "carboxylic acid", "ester", "polymer", "polymerisation", "addition polymer", "condensation polymer",
                               "homologous series", "functional group", "bromine water", "ethanol", "ethene", "methane", "propane", "butane"],
                "specific": ["fraction", "combustion", "monomer", "saturated", "unsaturated", "double bond", "fermentation",
                             "amino acid", "dna", "starch", "cellulose", "protein", "nylon", "polyester"],
                "generic": ["fuel", "oil", "carbon dioxide", "water"],
            },
            "chemical_analysis": {
                "spec": "4.8 Chemical analysis (4.8.1 purity, formulations and chromatography, 4.8.2 gases, 4.8.3 ions)",
                "diagnostic": ["chromatography", "chromatogram", "rf value", "flame test", "flame emission", "formulation",
                               "pure substance", "test for (hydrogen|oxygen|carbon dioxide|chlorine)", "limewater", "glowing splint",
                               "squeaky pop", "litmus", "precipitate", "sodium hydroxide solution", "silver nitrate", "barium chloride"],
                "specific": ["solvent", "mobile phase", "stationary phase", "instrumental", "spectroscop(y|ic)", "identify the ion",
                             "halide", "sulfate", "indicator", "melting point"],
                "generic": ["test", "colour", "white", "green", "brown", "blue"],
            },
            "chemistry_of_the_atmosphere": {
                "spec": "4.9 Chemistry of the atmosphere (4.9.1 evolution of the atmosphere, 4.9.2 greenhouse gases, 4.9.3 pollutants)",
                "diagnostic": ["atmosphere", "greenhouse gas", "greenhouse effect", "global warming", "climate change",
                               "carbon footprint", "early atmosphere", "acid rain", "sulfur dioxide", "oxides of nitrogen",
                               "particulates", "global dimming", "carbon monoxide", "photosynthesis", "volcanic activity"],
                "specific": ["carbon dioxide", "methane", "oxygen", "nitrogen", "billion years", "pollutant", "incomplete combustion"],
                "generic": ["air", "gas", "temperature", "earth"],
            },
            "using_resources": {
                "spec": "4.10 Using resources (4.10.1 potable water, 4.10.2 life cycle assessment and recycling, 4.10.3 materials, 4.10.4 Haber process and fertilisers)",
                "diagnostic": ["potable water", "desalination", "life cycle assessment", "recycling", "sustainable development",
                               "finite resource", "haber process", "npk fertiliser", "fertiliser", "phytomining", "bioleaching",
                               "waste water", "sewage", "corrosion", "rusting", "sacrificial protection", "galvanis(ed|ing)",
                               "ceramics?", "composites?", "reverse osmosis", "chlorination", "sterilis(e|ed|ing|ation)"],
                "specific": ["copper ore", "low-grade ore", "renewable", "non-renewable", "ammonia", "reuse", "landfill",
                             "glass", "clay", "bricks?", "soda-lime", "borosilicate", "high density", "low density", "thermosetting",
                             "thermosoftening", "raw material"],
                "generic": ["resource", "water", "energy", "cost", "environment"],
            },
        },
    },
    "8702": {
        "name": "GCSE English Literature",
        "source": "https://filestore.aqa.org.uk/resources/english/specifications/AQA-8702-SP-2015.PDF",
        "sha256": "3b7d3b63998b6fd8b1bfbc169fcde53cf7b9d395da778f45e9b9c9e23c03aebe",
        # CAIE 0475 precedent: a FORM is the primary (folder) topic; aspects are secondary.
        "classes": {"primary": ["Drama", "Prose", "Poetry", "Unseen_texts"],
                    "secondary": ["Themes_and_characterisation", "Literary_techniques", "Context_and_comparison"]},
        "topics": {
            "Drama": {
                "spec": "Paper 1 Section A Shakespeare; Paper 2 Section A modern prose or drama (spec 3.1, 3.3)",
                "diagnostic": ["act \\d+ scene \\d+", "shakespeare", "the play", "in the play", "play as a whole", "soliloquy",
                               "stage direction", "dramatist", "playwright", "audience"],
                "specific": ["speech", "scene", "act", "performance", "on stage", "character(s)? speak"],
                "generic": ["play", "line", "spoken"],
            },
            "Prose": {
                "spec": "Paper 1 Section B the 19th-century novel; Paper 2 Section A modern prose (spec 3.2, 3.3)",
                "diagnostic": ["chapter \\d+", "the novel", "in the novel", "novel as a whole", "novelist", "narrator",
                               "narrative", "short stor(y|ies)", "from chapter"],
                "specific": ["extract", "passage", "prose", "story", "society", "reader"],
                "generic": ["book", "text", "writes"],
            },
            "Poetry": {
                "spec": "Paper 2 Section B poetry anthology (spec 3.4)",
                "diagnostic": ["poem", "poet", "anthology", "stanza", "verse", "power and conflict", "love and relationships",
                               "poetry cluster", "compare the ways"],
                "specific": ["rhyme", "rhythm", "metre", "sonnet", "imagery", "speaker"],
                "generic": ["lines?", "voice"],
            },
            "Unseen_texts": {
                "spec": "Paper 2 Section C unseen poetry (spec 3.5)",
                "diagnostic": ["unseen poetry", "unseen poem", "unseen text", "two unseen"],
                "specific": ["compare (the ways|how)", "second poem"],
                "generic": [],
            },
            "Themes_and_characterisation": {
                "spec": "AO1 read, understand and respond to texts; characters, themes, relationships (spec 3.1–3.4 'ideas, themes and issues')",
                "diagnostic": ["presents?", "presented", "attitudes? towards", "outsider", "ambition", "relationship", "powerful",
                               "power", "feelings?", "character", "strong female", "love and acceptance", "as a (good|strong|powerful)",
                               "sense of mystery", "theme", "ideas about", "the importance of"],
                "specific": ["how far", "explore how", "write about how", "explain how", "attitude", "women", "men", "father",
                             "acceptance", "love", "society", "treated", "frightening"],
                "generic": ["think", "feel", "shows?", "portray(s|ed)?"],
            },
            "Literary_techniques": {
                "spec": "AO2 analyse the language, form and structure used by a writer to create meanings and effects (spec 4.1)",
                "diagnostic": ["language, form and structure", "creates? a sense of", "writer'?s? methods", "use of language",
                               "structure", "imagery", "metaphor", "simile", "symbolism", "setting", "uses places", "dramatic irony",
                               "tone", "atmosphere", "tension", "effect on the reader"],
                "specific": ["language", "form", "technique", "method", "creates?", "sense of", "describes?", "description"],
                "generic": ["words?", "effect"],
            },
            "Context_and_comparison": {
                "spec": "AO3 relationship between texts and the contexts in which they were written; comparison across texts (spec 4.1, 3.4)",
                "diagnostic": ["context", "contextual", "19th[- ]century", "nineteenth[- ]century", "victorian", "elizabethan",
                               "jacobean", "compare and contrast", "comparison", "compare"],
                "specific": ["society at the time", "when it was written", "historical", "social", "cultural", "both texts", "both poems"],
                "generic": ["time", "period", "era"],
            },
        },
    },
}

# Legacy board-level keywords (pre-2026-09-23). AQA entries are a FALLBACK only, used when the
# paper's specification code is unknown; EDEXCEL is unchanged (out of the AQA round's scope).
TOPIC_KEYWORDS = {
    "AQA": {
        "atomic_structure_periodic_table": ["isotope", "relative atomic", "periodic", "group 7", "electron", "proton", "neutron", "atom"],
        "bonding_structure_properties": ["bond", "ionic", "covalent", "metallic", "nanoparticle", "graphene", "polymer"],
        "quantitative_chemistry": ["mole", "concentration", "dm3", "mass", "volume", "relative formula mass", "titration"],
        "chemical_changes": ["acid", "alkali", "electrolysis", "salt", "reactivity", "oxidation", "reduction"],
        "energy_changes": ["exothermic", "endothermic", "activation energy", "bond energy", "reaction profile"],
        "rates_equilibrium": ["rate of reaction", "catalyst", "equilibrium", "le chatelier", "reversible"],
        "organic_chemistry": ["alkane", "alkene", "crude oil", "hydrocarbon", "polymer", "ethanol"],
        "chemical_analysis": ["chromatography", "flame test", "precipitate", "instrumental", "indicator"],
    },
    "EDEXCEL": {
        "pure_algebra_functions": ["function", "polynomial", "quadratic", "roots", "sequence", "series", "logarithm", "exponential"],
        "coordinate_geometry_vectors": ["coordinate", "vector", "line", "circle", "gradient", "cartesian", "parametric"],
        "calculus": ["differentiate", "derivative", "integrate", "integral", "stationary", "area under"],
        "mechanics_kinematics": ["velocity", "acceleration", "displacement", "projectile", "kinematics", "motion"],
        "mechanics_forces_energy": ["force", "friction", "momentum", "impulse", "energy", "work", "power", "collision"],
        "statistics_probability": ["probability", "distribution", "hypothesis", "sample", "mean", "variance", "normal"],
        "decision_discrete": ["algorithm", "network", "graph", "route", "critical path", "linear programming"],
    },
}
AQA_LEGACY_KEYWORDS = TOPIC_KEYWORDS["AQA"]

_COMPILED: Dict[Tuple[str, str], List[Tuple[str, float, re.Pattern]]] = {}


def _compiled_vocab(spec_code: str, topic: str) -> List[Tuple[str, float, re.Pattern]]:
    key = (spec_code, topic)
    if key not in _COMPILED:
        entry = AQA_SPECS[spec_code]["topics"][topic]
        out = []
        for tier, weight in WEIGHTS.items():
            for kw in entry.get(tier, []):
                out.append((kw, weight, keyword_regex(kw)))
        _COMPILED[key] = out
    return _COMPILED[key]


def spec_code_for(component: Optional[str], subject_hint: str = "") -> Optional[str]:
    """``8462/1H`` → ``8462``; also accepts a bare code. None when unknown (→ legacy fallback)."""
    for cand in (component or "", subject_hint or ""):
        m = re.search(r"\b(\d{4})\b", str(cand))
        if m and m.group(1) in AQA_SPECS:
            return m.group(1)
    return None


# --------------------------------------------------------------------------- text of a segment
def _rect_lines(ctx: DocumentContext, seg: Dict[str, Any]) -> List[str]:
    pages = (ctx.layout or {}).get("pages") or []
    out: List[str] = []
    for sp in seg.get("pages") or []:
        pi = int(sp.get("page_index", -1))
        rect = sp.get("rect")
        if not (0 <= pi < len(pages)) or not rect:
            continue
        x0, y0, x1, y1 = (float(v) for v in rect)
        for ln in pages[pi].get("lines") or []:
            bbox = ln.get("bbox")
            if not bbox:
                continue
            bx0, by0, bx1, by1 = (float(v) for v in bbox)
            if by0 >= y0 - 1.0 and by1 <= y1 + 1.0 and bx0 < x1 and bx1 > x0:
                out.append(str(ln.get("text", "")))
    return out


def _page_text(ctx: DocumentContext, seg: Dict[str, Any]) -> str:
    pages = (ctx.layout or {}).get("pages") or []
    parts: List[str] = []
    for sp in seg.get("pages") or []:
        pi = int(sp.get("page_index", -1))
        if 0 <= pi < len(pages):
            parts.append(str(pages[pi].get("text", "")))
    return "\n".join(parts)


def _segment_text(ctx: DocumentContext, seg: Dict[str, Any]) -> Tuple[str, str]:
    """(text, source): the segment's own rect text; whole-page text only as a recorded fallback."""
    lines = _rect_lines(ctx, seg)
    if any(l.strip() for l in lines):
        return "\n".join(lines), "rect"
    return _page_text(ctx, seg), "page"


# --------------------------------------------------------------------------- scoring
def _score_topics(spec_code: str, text: str) -> List[Dict[str, Any]]:
    low = text.lower()
    rows = []
    for topic in AQA_SPECS[spec_code]["topics"]:
        score = 0.0
        hits: List[Tuple[str, float, int]] = []
        for kw, weight, rx in _compiled_vocab(spec_code, topic):
            n = len(rx.findall(low))
            if n:
                hits.append((kw, weight, n))
                score += weight * math.sqrt(min(n, 3))
        if not hits:
            continue
        strong = sum(1 for _kw, w, _n in hits if w >= WEIGHTS["specific"])
        generic = sum(1 for _kw, w, _n in hits if w == WEIGHTS["generic"])
        rows.append({
            "topic": topic, "score": round(score, 3), "distinct": len(hits),
            "longest": max(len(kw) for kw, _w, _n in hits),
            "evidence": [f"{kw}×{n}" for kw, _w, n in sorted(hits, key=lambda h: (-h[1], -h[2], h[0]))][:8],
            "meets_minimum": score >= MIN_SCORE and (strong >= 1 or generic >= 3),
        })
    # evidence-based order; the topic id is only the deterministic last resort
    rows.sort(key=lambda r: (-r["score"], -r["distinct"], -r["longest"], r["topic"]))
    return rows


def _confidence(top: float, second: float) -> float:
    margin = (top - second) / top if top > 0 else 0.0
    strength = min(1.0, top / 9.0)
    return round(min(0.97, 0.50 + 0.30 * margin + 0.20 * strength), 3)


def classify_spec_topic(spec_code: str, text: str) -> Dict[str, Any]:
    """Primary (+ secondary) topic for one question under an AQA specification vocabulary."""
    rows = _score_topics(spec_code, text)
    classes = AQA_SPECS[spec_code].get("classes")
    if classes:
        primary_rows = [r for r in rows if r["topic"] in classes["primary"]]
        secondary_rows = [r for r in rows if r["topic"] in classes["secondary"]]
    else:
        primary_rows, secondary_rows = rows, []
    winners = [r for r in primary_rows if r["meets_minimum"]]
    if not winners:
        return {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED", "evidence": [],
                "secondary": [], "spec": spec_code, "candidates": rows[:3]}
    top = winners[0]
    runner = next((r for r in primary_rows if r["topic"] != top["topic"]), None)
    conf = _confidence(top["score"], runner["score"] if runner else 0.0)
    if classes:
        secondary = [r["topic"] for r in secondary_rows if r["meets_minimum"]][:2]
    else:
        secondary = [r["topic"] for r in rows[1:3] if r["meets_minimum"] and r["score"] >= 0.5 * top["score"]]
    return {"topic": top["topic"], "confidence": conf, "status": "HINT", "evidence": top["evidence"],
            "secondary": secondary, "spec": spec_code,
            "spec_ref": AQA_SPECS[spec_code]["topics"][top["topic"]].get("spec", ""),
            "runner_up": ({"topic": runner["topic"], "score": runner["score"]} if runner else None),
            "score": top["score"]}


def classify_segment_topic(board: str, text: str, component: Optional[str] = None) -> Dict[str, Any]:
    """Board entry point. AQA papers with a known specification code use the spec vocabularies;
    anything else (Edexcel, unknown AQA code) uses the legacy keyword dict with the SAME
    evidence-ordered tie-break and calibrated confidence."""
    board = board.upper()
    if board == "AQA":
        code = spec_code_for(component)
        if code:
            return classify_spec_topic(code, text)
    vocab = TOPIC_KEYWORDS.get(board, {})
    low = text.lower()
    rows = []
    for topic, kws in vocab.items():
        hits = [(kw, len(keyword_regex(kw).findall(low))) for kw in kws]
        hits = [(kw, n) for kw, n in hits if n]
        if hits:
            rows.append({"topic": topic, "score": round(sum(math.sqrt(min(n, 3)) for _kw, n in hits), 3),
                         "distinct": len(hits), "longest": max(len(kw) for kw, _n in hits), "hits": [kw for kw, _n in hits]})
    if not rows:
        return {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED", "evidence": [], "secondary": []}
    rows.sort(key=lambda r: (-r["score"], -r["distinct"], -r["longest"], r["topic"]))
    top = rows[0]
    second = rows[1]["score"] if len(rows) > 1 else 0.0
    return {"topic": top["topic"], "confidence": _confidence(top["score"], second), "status": "HINT",
            "evidence": top["hits"][:8], "secondary": [r["topic"] for r in rows[1:2]],
            "legacy_vocab": True}


def classify_segments(board: str, ctx: DocumentContext, segments: Iterable[Dict[str, Any]],
                      component: Optional[str] = None) -> List[Dict[str, Any]]:
    out = []
    for seg in segments:
        text, source = _segment_text(ctx, seg)
        cls = classify_segment_topic(board, text, component=component)
        out.append({
            "question_number": seg.get("question_number"),
            "canonical_question": seg.get("canonical_question"),
            "text_source": source,
            **cls,
        })
    return out
