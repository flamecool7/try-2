"""Pearson Edexcel adapter.

Handles the real 9FM0/3C format measured in docs/research. The adapter excludes
physical gutter boxes before handing rectangles to the shared gold geometry
bridge, so margin ink cannot become the top-band anchor.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List

from adapters.base import BoardAdapter, DocumentContext, Evidence
from adapters.common_text import first_line_y, full_page_clip, page_size, page_texts
from adapters.layout_profiles import LayoutArchetype, crop_plan

_COMPONENT = re.compile(r"\b([0-9][A-Z]{2,3}[0-9])\s*/\s*([0-9][A-Z]{0,2})\b")
_PAGE_REF = re.compile(r"\*[A-Z]\d{5}A\d{2,3}\d{2}\*")
_Q_START = re.compile(r"(?:^|\n)\s*(\d{1,2})\.\s+")
_CONT = re.compile(r"Question\s+(\d{1,2})\s+continued", re.I)


class Adapter(BoardAdapter):
    BOARD_ID = "EDEXCEL"
    BOARD_NAMES = ["Pearson Edexcel", "Edexcel", "Pearson"]
    CONFIG_FILE = "config/boards/edexcel.yaml"

    def normalize_name(self, raw: str) -> str:
        return re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")

    def _hay(self, ctx: DocumentContext) -> str:
        return f"{ctx.filename}\n{ctx.first_page_text}\n{ctx.full_text}".lower()

    def identify_document(self, ctx: DocumentContext) -> List[Evidence]:
        hay = self._hay(ctx)
        out: List[Evidence] = []
        if "pearson edexcel" in hay or "edexcel" in hay:
            out.append(Evidence("board_signature", "board", self.BOARD_ID, 1.0, "Pearson/Edexcel text", "document"))
        if _PAGE_REF.search(ctx.full_text or ctx.first_page_text or ""):
            out.append(Evidence("header_footer", "board", self.BOARD_ID, 0.85, "Edexcel page-reference code, not CAIE barcode", "page furniture"))
        return out

    def identify_subject(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.first_page_text or ""
        out: List[Evidence] = []
        m = _COMPONENT.search(text)
        if m:
            out.append(Evidence("qualification_code", "syllabus_code", m.group(1), 0.95, f"component {m.group(0)!r}", "page 1"))
            out.append(Evidence("component_code", "component", f"{m.group(1)}/{m.group(2)}", 0.95, f"component {m.group(0)!r}", "page 1"))
        if "further mathematics" in text.lower():
            out.append(Evidence("first_page_text", "subject", "Further Mathematics", 0.9, "cover subject title", "page 1"))
        return out

    def identify_qualification(self, ctx: DocumentContext) -> List[Evidence]:
        low = (ctx.first_page_text or "").lower()
        if "level 3 gce" in low or "advanced" in low:
            return [Evidence("first_page_text", "qualification", "A-LEVEL", 0.9, "Level 3 GCE Advanced on cover", "page 1")]
        return []

    def identify_session(self, ctx: DocumentContext) -> List[Evidence]:
        """Read the series and year the cover actually prints.

        The series token is matched against this adapter's OWN config session
        table (``sessions[].aliases``), so adding a series is a config change,
        not a code change - the same pattern as the AQA adapter.

        The emitted value is the session NAME ("June"), not the calendar season
        word ("Summer"). The universal identity layer, the association keys and
        the batch directory contract all speak month names, so hardcoding
        "Summer" made Edexcel disagree with every other board - found 2026-09-21
        when the adapter-first identify_document started consuming this value;
        it had been masked by the legacy fallback.
        """
        text = ctx.first_page_text or ""
        low = text.lower()
        out: List[Evidence] = []
        m = re.search(r"\b(19\d{2}|20\d{2}|[3-9]\d{2})\b", text)
        if m:
            out.append(Evidence("first_page_text", "year", int(m.group(1)), 0.9, "year on cover", "page 1"))
        if "specimen" in low:
            out.append(Evidence("first_page_text", "season", "Specimen", 1.0, "Specimen material", "page 1"))
        for spec in self.sessions():
            found = None
            for alias in [spec.name] + list(getattr(spec, "aliases", None) or []):
                token = str(alias or "").strip().lower()
                # Single letters ("s", "j") are filename hints, not cover text.
                if len(token) >= 3 and re.search(r"\b" + re.escape(token), low):
                    found = token
                    break
            if found:
                out.append(Evidence("first_page_text", "season", spec.name, 0.9,
                                    f"series token {found!r} on cover", "page 1"))
                break
        return out

    def identify_component(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        m = _COMPONENT.search(ctx.first_page_text or "")
        if m:
            # "component" is the FULL code ("9FM0/3C"), not the bare paper letter
            # ("3C"): the paper number alone does not discriminate, because two
            # different Edexcel syllabuses in one session can both have a "3C".
            # This matches the AQA adapter (full code as component, board-native
            # number as paper_number) and the directory naming the batch runner
            # already derives. Fixed 2026-09-21; the adapter-first association
            # change had made the bare paper letter win for the first time.
            out.append(Evidence("component_code", "component", f"{m.group(1)}/{m.group(2)}", 1.0, f"paper reference {m.group(0)!r}", "page 1"))
            out.append(Evidence("component_code", "paper_number", m.group(2)[:1], 0.85, "first digit of Edexcel paper component", "page 1"))
        return out

    def identify_document_type(self, ctx: DocumentContext) -> List[Evidence]:
        low = (ctx.first_page_text or "").lower()
        if "mark scheme" in low:
            return [Evidence("header_footer", "document_type", "MS", 0.95, "mark scheme heading", "page 1")]
        if "examiner report" in low or "resultsplus" in low:
            return [Evidence("header_footer", "document_type", "ER", 0.9, "examiner report/resultsplus", "page 1")]
        if "answer all questions" in (ctx.full_text or "").lower() and "paper reference" in low:
            return [Evidence("header_footer", "document_type", "QP", 0.9, "question-paper cover + instructions", "page 1")]
        return []

    def identify_question_structure(self, ctx: DocumentContext) -> List[Evidence]:
        segs = self.segment(ctx)
        return [Evidence("document_structure", "question_count", len(segs), 0.95, "Edexcel numbered starts with continuations", "document")] if segs else []

    def identify_mark_scheme(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "MS"]

    def identify_examiner_report(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "ER"]

    def segments_document(self) -> bool:
        return True

    def _body_rect(self, ctx: DocumentContext, page_index: int, *, start: bool) -> tuple[float, float, float, float]:
        w, h = page_size(ctx, page_index)
        # Explicitly exclude the physical "DO NOT WRITE IN THIS AREA" gutters.
        # Real P61181A pages are 651.97 x 898.58 and carry full-height gutter
        # rasters at x 0.0-54.7 and 596.9-651.6 (measured 2026-09-21, 100 dpi
        # ink runs); the mathematical body is x 62.6-589.7 and question numbers
        # start at x 71. The old left=45.0 sat *inside* the left hatch, so ~10pt
        # of cross-hatch was cropped into the left edge of every page, and the
        # old right=55.0 (edge 596.97) grazed the right gutter. 56.0/57.0 clear
        # both: edge 594.97, 5.3pt right of the widest body ink, 1.9pt left of
        # the gutter. left=59.0 additionally clears the gutter *raster*'s own
        # 34.0-57.8pt placement rect, so the crop-edge audit reports no cut
        # objects there at all.
        #
        # The box width is bounded from below by the WEBP 16383px height limit,
        # not by taste: Q7 is a five-page question and segment pages render at
        # 2280 / box_width px per pt, so a narrower box pushes the stacked image
        # past the limit. At 535.97pt of body Q7 assembles to 16143px (< 16383);
        # at the old 552.0pt it was ~16089px - already tight. Verified by
        # re-cropping the real paper: Q7 came out 2280x16023px.
        left = 59.0
        right = 57.0
        y = 72.0
        if start:
            y0 = first_line_y(ctx, page_index, r"^\s*\d{1,2}\.\s+")
            if y0 is not None:
                y = max(55.0, y0 - 10.0)
        else:
            y0 = first_line_y(ctx, page_index, r"Question\s+\d+\s+continued")
            if y0 is not None:
                y = max(55.0, y0 - 8.0)
        # Bottom: body ink ends at 823.2 on every page while the barcode strip
        # ("*P61181A0228*", the label row and "Turn over") runs 829.4-863.0, so
        # the old h-52.0 = 846.6 sliced the barcode in half - the IB QP defect
        # again. h-72.5 = 826.08 sits in the empty window: 2.9pt below content
        # and 0.3pt above the footer page number glyph (826.4-838.8) which the
        # h-72.0 edge shaved by 0.2pt (A4f, found by a solid-object cross test),
        # 2.8pt above the barcode.
        return (left, y, w - right, h - 72.5)

    def segment(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        texts = page_texts(ctx)
        starts: List[tuple[int, int]] = []
        for i, text in enumerate(texts):
            m = _Q_START.search(text)
            if m:
                qn = int(m.group(1))
                # Covers can contain dates/numbers; require the real answer-space furniture or instructions.
                if i > 0 and ("DO NOT WRITE IN THIS AREA" in text or "Answer ALL questions" in text):
                    starts.append((qn, i))
        starts.sort(key=lambda t: t[1])
        segments: List[Dict[str, Any]] = []
        for idx, (qn, start_page) in enumerate(starts):
            end_page = (starts[idx + 1][1] - 1) if idx + 1 < len(starts) else len(texts) - 1
            pages = []
            for p in range(start_page, end_page + 1):
                pages.append({"page_index": p, "rect": self._body_rect(ctx, p, start=(p == start_page))})
            segments.append({
                "id": f"3C_Summer_2019_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "3C",
                "pages": pages,
                "metadata": {"source_pages": [p + 1 for p in range(start_page, end_page + 1)], "layout_archetype": LayoutArchetype.EDEXCEL_GUTTER_NUMBERED_BOOKLET.value, "crop_plan": crop_plan(self.BOARD_ID, ctx), "page_reference_pattern": "Edexcel page reference excluded separately from CAIE barcode regex"},
            })
        return segments
