"""Edexcel adapter (Phase 2 of the non-CAIE build-out)."""
