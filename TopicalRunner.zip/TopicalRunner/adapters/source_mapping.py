"""Conservative source/insert-to-question linking.

This maps only explicit labels mentioned in the question text, for example
"Use Source A" or "Figure 2 shows". It never infers an attachment solely from
order or subject matter.
"""
from __future__ import annotations

import re
from dataclasses import asdict
from typing import Any, Dict, Iterable, List

from adapters.base import DocumentContext
from adapters.companion_segments import TextCompanion


def _segment_text(ctx: DocumentContext, seg: Dict[str, Any]) -> str:
    pages = (ctx.layout or {}).get("pages") or []
    parts: List[str] = []
    for sp in seg.get("pages") or []:
        pi = int(sp.get("page_index", -1))
        if 0 <= pi < len(pages):
            parts.append(str(pages[pi].get("text", "")))
    return "\n".join(parts)


def _label_variants(label: str) -> List[str]:
    words = " ".join(label.split())
    out = [words]
    m = re.match(r"(Source|Extract|Figure|Fig\.|Item)\s+([A-Z]|\d{1,2})\b", words, re.I)
    if m:
        head, ident = m.group(1), m.group(2)
        out.extend([f"{head} {ident}", f"{head.rstrip('.')} {ident}"])
        if head.lower().startswith("fig"):
            out.append(f"Figure {ident}")
    return sorted(set(out), key=len, reverse=True)


def link_sources_to_questions(ctx: DocumentContext, qp_segments: Iterable[Dict[str, Any]], sources: Iterable[TextCompanion]) -> List[Dict[str, Any]]:
    links: List[Dict[str, Any]] = []
    source_list = list(sources)
    for seg in qp_segments:
        text = _segment_text(ctx, seg)
        if not text.strip():
            continue
        found = []
        for src in source_list:
            for variant in _label_variants(src.canonical_question):
                if re.search(r"\b" + re.escape(variant) + r"\b", text, re.I):
                    found.append({"label": src.canonical_question, "source": asdict(src), "matched_text": variant})
                    break
        if found:
            links.append({
                "question_number": seg.get("question_number"),
                "canonical_question": seg.get("canonical_question"),
                "sources": found,
                "confidence": 0.88,
                "reason": "explicit source label appears in question text",
            })
    return links
