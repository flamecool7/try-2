"""AQA board adapter."""
