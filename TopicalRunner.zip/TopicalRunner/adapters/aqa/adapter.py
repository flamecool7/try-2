"""AQA adapter.

Boundary detection is AQA-specific; rendering and final geometry are delegated to
``adapters.segment_geometry`` and the locked gold primitives.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List

from adapters.base import BoardAdapter, DocumentContext, Evidence
from adapters.common_text import first_line_y, full_page_clip, page_size, page_texts
from adapters.layout_profiles import LayoutArchetype, crop_plan

# AQA prints the paper code as syllabus/paper-number where the paper number may
# carry a tier letter: "8462/1H", "8702/1", "8462/2F". The trailing \b after
# the digits could never match "8462/1H" (there is no word boundary between "1"
# and "H"), so the whole pattern failed and identify_component returned [] for
# every AQA science paper. The letter is captured, but "component" stays the
# FULL code: a bare "1H" would merge two different AQA subjects sitting in the
# same session (8461 Biology 1H and 8462 Chemistry 1H) into one group.
#: The component code on an AQA cover. The trailing letters are the paper-3 option suffix on
#: the A-level sciences (7408/3BA = Paper 3 Section B Astrophysics, 7408/3A = its Section A), so
#: up to two of them are part of the code rather than the paper_number "3".
_SPEC = re.compile(r"\b(\d{4})\s*/\s*(\d[A-Za-z]{0,2})\b")
_YEAR = re.compile(r"\b(19\d{2}|20\d{2}|[3-9]\d{2})\b")


_AQA_FURNITURE_SUBS = (
    # Multi-word phrases first, then the split fragments left behind.
    (re.compile(r"turn over for the next question"), " "),
    (re.compile(r"do not write on this page"), " "),
    (re.compile(r"there are no questions printed on this page"), " "),
    (re.compile(r"additional page,? if required"), " "),
    (re.compile(r"ib\s*/\s*m\s*/\s*[a-z]+\s*\d+[a-z0-9/]*"), " "),  # IB/M/Jun23/8462/1H
    (re.compile(r"\*?\s*\d+\s*\*?"), " "),                    # page number, *05*, dates, numerals
    (re.compile(r"turn over"), " "),
    (re.compile(r"do not write"), " "),
    (re.compile(r"outside the box"), " "),
    (re.compile(r"answer in the spaces provided"), " "),
    (re.compile(r"please turn over"), " "),
    (re.compile(r"write the question number"), " "),
)


def _page_has_question_content(page: Dict[str, Any]) -> bool:
    """True only when a page carries anything other than AQA page furniture.

    "Turn over for the next question" is a footer hint printed on pages that DO
    carry questions: 84621H page 13 holds ``0 4 . 5`` with Figure 5 and page 25
    holds ``0 8 . 4`` about barium. Treating that hint as an empty-page marker
    silently dropped both pages, so Q4 lost its last part and Q8 lost its whole
    last sub-question (found 2026-09-21 while auditing segment coverage). Judge
    the page by what is left after the furniture is subtracted instead.
    """
    txt = re.sub(r"\s+", " ", re.sub(r"[\u25ba*]", " ", str(page.get("text", ""))).lower())
    if re.search(r"additional page,? if required", txt) or re.search(
            r"there are no questions printed on this page", txt):
        return False   # designated blank answer sheets / explicitly empty pages
    for pat, repl in _AQA_FURNITURE_SUBS:
        txt = pat.sub(repl, txt)
    return bool(re.sub(r"[^a-z]+", " ", txt).strip())


# --------------------------------------------------------------------------- #
# Content-keyed furniture (AQA fix round, 2026-09-23). Every rule below matches TEXT the
# page prints, never a position, and every fallback is recorded in the segment metadata.
# --------------------------------------------------------------------------- #
_CONTINUES_LINE = re.compile(r"^question\s+\d{1,2}\s+continues\s+on\s+the\s+next\s+page$", re.I)
_OPTION_MARKER = re.compile(r"^(?:either|or)$", re.I)               # whole line only, never the word in a sentence
_SECTION_TITLE = re.compile(r"^section\s+[ab]\s*[:\u2013-]", re.I)
_SECTION_RUBRIC = re.compile(r"^answer\s+one\s+question\s+from\s+this\s+section", re.I)
_TURN_OVER = re.compile(r"^turn\s+over", re.I)
_MS_RUNNING_HEADER = re.compile(r"^mark\s+scheme\s*[\u2013-]", re.I)   # MARK SCHEME – GCSE CHEMISTRY – 8462/1H – JUNE 2023
_PAGE_NUMBER_LINE = re.compile(r"^\*?\d{1,2}\*?$")
#: pt of white kept above a cut made under content (FIX 3 fallback / FIX 5) and below furniture.
_CUT_PAD_BELOW_CONTENT = 12.0
_CUT_PAD_ABOVE_FURNITURE = 8.0


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip().lower()


def _page_lines(ctx: DocumentContext, page_index: int) -> List[tuple[str, float, float, float, float]]:
    pages = (ctx.layout or {}).get("pages") or []
    if not (0 <= page_index < len(pages)):
        return []
    out = []
    for ln in pages[page_index].get("lines") or []:
        bbox = ln.get("bbox") or []
        if len(bbox) == 4:
            x0, y0, x1, y1 = map(float, bbox)
            out.append((str(ln.get("text", "")), x0, y0, x1, y1))
    out.sort(key=lambda t: (t[2], t[1]))
    return out


def _is_sqp_furniture(text: str) -> bool:
    n = _norm(text)
    return bool(_OPTION_MARKER.match(n) or _SECTION_TITLE.match(n) or _SECTION_RUBRIC.match(n))


_INK_CACHE: Dict[tuple[str, int], List[tuple[float, float, float, float]]] = {}


def _page_ink_boxes(ctx: DocumentContext, page_index: int) -> List[tuple[float, float, float, float]]:
    """Every printed thing on the page as (x0, y0, x1, y1): text lines from the layout plus vector
    drawings (answer rules, boxes, figures) and raster images from the PDF itself. Used so a
    content-keyed cut never lands on a drawn answer line or a figure that has no text."""
    key = (str(ctx.path), page_index)
    if key in _INK_CACHE:
        return _INK_CACHE[key]
    boxes = [(x0, y0, x1, y1) for _t, x0, y0, x1, y1 in _page_lines(ctx, page_index) if _norm(_t)]
    try:
        import fitz
        with fitz.open(str(ctx.path)) as doc:
            page = doc[page_index]
            for d in page.get_drawings():
                r = d.get("rect")
                if r is None:
                    continue
                # The answer-box border is page furniture, not content: measured on
                # 8462/1H June 2023 as a 498.9 pt top/bottom rule (y 53.4 / 765.4) and two
                # 0.5 x 711.5 pt side borders on every question page. Answer lines are
                # 374-420 pt wide, so a width gate at 480 pt separates them cleanly.
                if (r.width >= 480.0 and r.height < 2.0) or (r.height >= 300.0 and r.width < 2.0):
                    continue
                # border joints (0.5 x 0.4 pt squares at the box corners, x 39.2 / 538.6) and
                # anything else drawn inside the border strips is furniture too
                if r.width < 2.0 and r.height < 2.0:
                    continue
                if r.x1 <= 42.0 or r.x0 >= 537.0:
                    continue
                boxes.append((float(r.x0), float(r.y0), float(r.x1), float(r.y1)))
            for blk in page.get_text("dict").get("blocks", []):
                if blk.get("type") == 1:
                    x0, y0, x1, y1 = blk["bbox"]
                    boxes.append((float(x0), float(y0), float(x1), float(y1)))
    except Exception as exc:  # noqa: BLE001 - text-only ink model is still valid, say so
        print(f"    [aqa] page {page_index + 1}: drawings/images unavailable ({type(exc).__name__}); text ink only")
    _INK_CACHE[key] = boxes
    return boxes


def _qp_page_span(ctx: DocumentContext, page_index: int, *, top: float, floor: float, right: float,
                  final_page: bool) -> tuple[float, str]:
    """Bottom of a numbered-boxed QP page rect, content-keyed (FIX 3).

    * a printed "Question N continues on the next page" line ends the rect 8 pt above it and
      is itself excluded (it references pages; the assembled crop has none);
    * a non-final page without that line ends 12 pt below its last content line (logged);
    * the final page keeps the measured page box (answer space stays).
    Returns (bottom_y, rule_name).
    """
    if final_page:
        return floor, "final_page_box"
    lines = _page_lines(ctx, page_index)
    for text, x0, y0, x1, y1 in lines:
        if _CONTINUES_LINE.match(_norm(text)) and y0 > top:
            return max(top + 2.0, min(floor, y0 - _CUT_PAD_ABOVE_FURNITURE)), "continues_line"
    # last content INK inside the box: text, drawn answer lines, figures - not "Turn over",
    # not the right-margin "Do not write outside the box" strip, nothing below the floor.
    ink = [y1 for x0, y0, x1, y1 in _page_ink_boxes(ctx, page_index)
           if y0 >= top and y1 <= floor and x0 < right and x1 > 30.0]
    for text, x0, y0, x1, y1 in lines:
        n = _norm(text)
        if (_TURN_OVER.match(n) or n.startswith("do not write")) and y1 in ink:
            ink.remove(y1)
    if ink:
        print(f"    [aqa] page {page_index + 1}: no 'continues' line on a non-final page - rect ends at last content ink + {_CUT_PAD_BELOW_CONTENT:.0f} pt")
        return max(top + 2.0, min(floor, max(ink) + _CUT_PAD_BELOW_CONTENT)), "last_ink_fallback"
    return floor, "page_box_no_ink"


# --------------------------------------------------------------------------- #
# GCSE Mathematics 8300 (2026-09-23). A maths paper carries no boxed "0 N" marker at all:
# every question starts with a bare BOLD "N" (or "N (a)") in the left margin, 11 pt Arial
# (12 pt on 8300/1H MS Q27, measured), and a question whose parts are laid out as separate
# blocks re-prints its number before each part. Measured on the three June-2023 Higher
# papers: 8300/1H 27 questions (QP and MS agree), 8300/2H 26, 8300/3H 23 -- every marker
# run is exactly 1..N with no gaps, which is the fail-closed gate below. The mark scheme is
# a table again, but unlike the science schemes its "Q" cell is vertically CENTRED in the
# block, so a block's top is its repeated "Q Answer Mark Comments" header row, not the
# marker's own y. Continuation pages print "cont" in the Q column and no header row.
_MATHS_QP_MARKER = re.compile(r"^(?:(\d{1,2})(?:\s*\(?\s?([a-z])\s?\)?)?|\(\s?([a-z])\s?\))$")
_MATHS_MS_MARKER = re.compile(r"^(\d{1,2})(?:\(?\s?([a-z])\s?\))?$")
_MATHS_MARKER_SIZE = (10.5, 12.6)
_MATHS_QP_MARKER_X = (30.0, 90.0)
_MATHS_MS_MARKER_X = (50.0, 90.0)
_MATHS_MIN_QUESTIONS = 15
_MATHS_QP_HEADER_BAND = 52.0        # below the page-number line (ends 41.1) and the strip at 53.9
_MATHS_QP_FLOOR = 768.0             # above "Turn over" (771.8-784.1) and the IB/M footer (816.2-824.1)
# --------------------------------------------------------------------------- #
# AQA A-LEVEL (Biology/Chemistry/Physics 7402/7405/7408 first, 2026-09-23). An A-level paper is
# NOT an 8300 paper and NOT a GCSE science paper:
#
#   * the question marker is the printed ``0 N`` pair (two spans, x0 52.7) and every part re-prints
#     it: ``0 1`` / ``. 1``, then ``0 1`` / ``. 2`` beside the next part -- so a crop starts at the
#     number and runs to the next question's number, exactly like the maths path;
#   * a GCSE science paper prints the SAME ``0 N`` + ``. M`` pair, so the level printed on the
#     cover is the discriminator ("A-level" and no "GCSE", measured on 7402/1 vs 8461/1H);
#   * the mark scheme labels rows ``01.1`` (bold, x0 70.7) under a repeated header row
#     ``Question | Marking Guidance | Mark | Comments``, and its Mark cell carries AQA's own
#     assessment-objective attribution -- ``2 (2 x AO1)``, ``4 (2 x AO1, 2 x AO2)``, ``1 (AO3)``,
#     ``3 max (3 x AO2)`` -- which tools/aqa_verdict_table.py reads back as the paper's ground
#     truth (spec §4.2 prints the per-paper AO ranges to check it against).
_ALEVEL_LEVEL = re.compile(r"\ba[\s-]?level\b", re.I)
# AQA A-level English Literature A (7712, and its AS sibling 7711) prints each question's number as
# the same two-span "0 N" pair the science papers use, but ONCE per question, on the line that carries
# the text's title (measured on 77121-QP-JUN22 page 2: bold "0 " at x 52.7 and bold "1 " at x 72.5,
# same baseline y 169.5, 11 pt Arial-BoldMT, then "Othello - William Shakespeare" at x 102.4). The
# paper is a choice paper -- one question per section, seven printed in all -- so the markers are the
# only structure the document has, and the section headings are recorded beside them.
_LIT_QP_MARKER_X = (44.0, 95.0)
_LIT_QP_MARKER_SIZE = (10.4, 12.6)
_LIT_SECTION = re.compile(r"^section\s+([abc])\s*:\s*(.+)$", re.I)
_LIT_MIN_QUESTIONS = 5
_LIT_MAX_QUESTIONS = 30
#: the mark scheme's own block headings, "Question 01" .. "Question 07" (bold 11 pt at x 42.6)
_LIT_MS_HEADING = re.compile(r"^question\s+(\d{1,2})$", re.I)
# AQA A-level Computer Science 7517 (2026-09-24). Its question paper is an ON-SCREEN paper: the
# candidate writes and extends programs in an Electronic Answer Document, so a question is all
# instructions with NO printed answer space and NO mark caption -- the marks are printed in the mark
# scheme instead. The question number is the same "0 N" pair the science papers use (measured on
# 75171-QP-JUN23 page 4: bold "0 " at x 52.7 and bold "3 " at x 72.5, 11 pt Arial-BoldMT), printed
# once per question on a line of its own, with each part marker ". M" on a line of its own below it.
# The paper prints its own section headings (Section A-D; B is multiple choice, D the Skeleton
# Program) and an examiner-use grid on the cover that lists every question number -- which is why the
# cover page is never read. AQA also omits the questions whose answer is the on-screen program, so
# the run of printed questions is never 1..N (7517/1 June 2023 prints eleven: 02, 03, 05-08, 12-16;
# 7517/2 prints twelve), and each paper is worth 100 marks.
_CS_QP_EVIDENCE = re.compile(r"\bcomputer\s+science\b", re.I)
_CS_CODE = re.compile(r"\b751[67]\s*/\s*[12]\b")
_CS_QP_MARKER_X = (44.0, 95.0)
_CS_QP_PART_X = (76.0, 101.0)
#: the foot of the crop on a page of a Computer Science question paper (see _segment_cs_questions)
_CS_QP_FLOOR = 790.0
_CS_QP_MARKER_SIZE = (10.4, 12.6)
_CS_SECTION = re.compile(r"^section\s+([a-d])\s*$", re.I)
_CS_MIN_QUESTIONS = 5
_CS_MAX_QUESTIONS = 30
#: the mark scheme's own headers, measured on both June-2023 schemes: 7517/1 prints
#: "Question | Marks" (bold 11 pt, x 48.2 / 526.6) with the question, its part and the mark in three
#: separate cells; 7517/2 prints "Qu | Pt | Marking guidance | Total marks" (x 49.3 / 79.9 / 258.2 /
#: 522.9). Neither prints a specification reference, and 7517/1's five-language appendix re-prints
#: the answers under "VB.Net | Question | Marks" headings, so only header pages are read as rows.
#: (each header is the set of names as PRINTED, one name per cell: 7517/2 prints "Total" and "marks"
#: as two cells, so the pair is two names, not one phrase)
_CS_MS_HEADERS = (("question", "marks"), ("qu", "pt", "marking guidance", "total", "marks"))
_CS_MS_LABEL = re.compile(r"^0?([1-9]\d?)\s*\.?\s*(\d+)?$")
_CS_MS_LABEL_SIZE = (10.4, 12.6)
_CS_MS_HEADER_TOL = 6.0
#: the mark scheme's label columns, measured by x band: "Question" 53.5 and its part column 85.8 on
#: 7517/1, "Qu" 50.8 and "Pt" 82.3 on 7517/2. 7517/2 prints "Total"/"marks" on the line ABOVE the
#: other three header names, so a header is the union of the names printed within 14 pt of each other.
_CS_MS_Q_X = (44.0, 75.0)
_CS_MS_P_X = (75.0, 101.0)
_CS_MS_HEADER_WINDOW = 14.0
#: 7517/1's appendix re-prints every programming answer under a language heading in the left margin
#: (x 42.5) and then another "Question | Marks" header -- those rows are not question blocks
_CS_APPENDIX_X = 47.0
_CS_APPENDIX = re.compile(r"^(vb\.?\s?net|visual\s+basic(\.net)?|python(\s*[23])?|c\#|java|"
                          r"pascal|delphi|pascal[/\s-]*delphi)$", re.I)
#: AQA pads a question number to two digits and prints each digit as its own span: "0 1" is
#: question 1 and "1 0" is question 10 (measured on 7402/1 QP, page 30). Matching two digits
#: with an optional gap is therefore the correct shape, not a permissive one.
_ALEVEL_QP_NUM = re.compile(r"^(\d)\s?(\d)$")
_ALEVEL_QP_PART = re.compile(r"^\.\s*(\d{1,2})$")
_ALEVEL_MS_LABEL = re.compile(r"^(\d{1,2})(?:\.(\d{1,2}))?$")
_ALEVEL_MARKER_X = (45.0, 70.0)
_ALEVEL_PART_X = (70.0, 96.0)
_ALEVEL_MARKER_SIZE = (10.5, 12.6)
_ALEVEL_MIN_QUESTIONS = 5
_ALEVEL_MAX_QUESTIONS = 15
_ALEVEL_QP_HEADER_BAND = 52.0        # below the page-number line (ends 41.3) and the title strip
_ALEVEL_QP_FLOOR = 768.0             # above "Turn over" (771.8-784.1) and the page-number block (790.0-)
#: the A-level mark-scheme header, which AQA words per subject: biology prints
#: ``Question | Marking Guidance | Mark | Comments``, chemistry ``Question | Answers |
#: Additional comments/Guidelines | Mark`` (the third cell prints on two lines). Both are
#: repeated above every row group, so either identifies the table.
_ALEVEL_MS_HEADERS = (
    ("Question", "Marking Guidance", "Mark", "Comments"),
    ("Question", "Answers", "Additional comments/Guidelines", "Mark"),
    # physics prints a three-cell table (7408/3A, 7408/3BA: no Comments/Guidelines column) and a
    # two-cell one over its multiple-choice section (7408/1, 7408/2: "Question | Key | Answer")
    ("Question", "Answers", "Mark"),
    ("Question", "Key", "Answer"),
)
_ALEVEL_MS_HEADER_ANY = frozenset(cell for header in _ALEVEL_MS_HEADERS for cell in header)
#: 7405/3 (A-level Chemistry Paper 3) runs 36 questions: Section A structured, then 30
#: one-mark multiple-choice items in Section B, numbered straight on from them. A paper that
#: long is only accepted on the printed evidence that it is that paper type.
_ALEVEL_MCQ_MAX_QUESTIONS = 40
_ALEVEL_MCQ_EVIDENCE = re.compile(r"only one answer per question is allowed", re.I)
#: AQA's A-level sciences print paper 3 as TWO components -- Section A (practical skills) and one
#: Section B option -- and each is a short paper in its own right: measured on 7408/3A (3 questions,
#: 45 marks) and 7408/3BA Astrophysics (5 questions, 35 marks). The printed pair "Paper 3" +
#: "Section A"/"Section B" is the evidence that waives the structured-paper floor of
#: ``_ALEVEL_MIN_QUESTIONS``, exactly as the multiple-choice instruction is for the long MCQ papers.
_ALEVEL_PAPER3_MIN_QUESTIONS = 3
_ALEVEL_PAPER3_EVIDENCE = re.compile(r"paper\s*3\b.*?section\s*[ab]\b|section\s*[ab]\b.*?paper\s*3\b",
                                     re.I | re.S)
_ALEVEL_MS_HEADER_TOL = 2.5          # the four cells share one baseline (measured 91.9 pt, all four)
_ALEVEL_MS_LABEL_X = (50.0, 96.0)
_ALEVEL_MS_LABEL_SIZE = (10.5, 12.6)

#: A-level MATHEMATICS 7357 (papers 1-3, June 2023) is a third A-level layout again, and neither of
#: the two above it can express it:
#:   * its QUESTION PAPER prints the question number as a bare 11 pt number in the left margin --
#:     ``3``, ``5 (a)``, ``14 (a) (i)`` -- in the AQA maths font (AdvArial-b, which carries no
#:     "Bold" in its name), starting at x0 57.3 for one-digit and 51.2 for two-digit numbers, with
#:     the question's own sentence beginning at x0 107.7 ON THE SAME LINE. That same-line pair is
#:     what makes the marker identifiable: a diagram label or a stray number in the margin has no
#:     sentence beside it. Measured 16 / 20 / 17 questions on 7357/1, 7357/2, 7357/3.
#:   * its MARK SCHEME is a five-column table ``Q | Marking instructions | AO | Marks | Typical
#:     solution`` whose row labels are ``1``, ``5(a)``, ``13(c)``, ``14(b)(i)`` (bold, x0 53.6-60.6),
#:     whose question ends with a bold ``Question N Total`` row, and whose per-row AO is AQA's fine
#:     code (``1.1b``, ``2.2a``, ``3.1a``) rather than a spec reference.
_ALEVEL_MATHS_MS_HEADERS = (("Q", "marking instructions", "AO", "Marks", "Typical solution"),)
_ALEVEL_MATHS_MS_HEADER_TOL = 2.5
_ALEVEL_MATHS_MS_LABEL_X = (45.0, 96.0)
_ALEVEL_MATHS_MS_LABEL_SIZE = (10.4, 12.6)
_ALEVEL_MATHS_MS_LABEL = re.compile(r"^(\d{1,2})((?:\s*\([a-z]+\))*)$")
_ALEVEL_MATHS_MS_TOTAL = re.compile(r"^question\s+(\d{1,2})\s+total$", re.I)
_ALEVEL_MATHS_QP_MARKER = re.compile(r"^(\d{1,2})(?:\s*\(([a-z])\)(?:\s*\(([ivx]+)\))?)?$")
_ALEVEL_MATHS_QP_MARKER_X = (44.0, 68.0)
_ALEVEL_MATHS_QP_TEXT_X = (100.0, 118.0)
_ALEVEL_MATHS_QP_MARKER_SIZE = (10.4, 12.1)
_ALEVEL_MATHS_MIN_QUESTIONS = 12
_ALEVEL_MATHS_MAX_QUESTIONS = 26
_ALEVEL_MATHS_QP_HEADER_BAND = 70.0   # below the page number (44.8) and the "Do not write" strip (64.8)
_ALEVEL_MATHS_QP_FLOOR = 774.0        # above "Turn over" (780.6) and the page number (790.6)

_MATHS_MS_HEADER_CELLS = ("Q", "Answer", "Mark", "Comments")
_MATHS_MS_HEADER_TOL = 2.5          # the four cells share one baseline within 0.3 pt
_MATHS_MS_CONT = "cont"

_SPAN_CACHE: Dict[tuple[str, int], List[tuple[str, float, float, float, float, bool]]] = {}


def _page_text_spans(ctx: DocumentContext, page_index: int) -> List[tuple[str, float, float, float, float, bool]]:
    """[(text, x0, y0, y1, size, bold)] for one page, cached: the shared layout keeps line
    text and bbox only, and both maths paths key on the font AQA prints the marker in."""
    key = (str(ctx.path), page_index)
    if key in _SPAN_CACHE:
        return _SPAN_CACHE[key]
    out: List[tuple[str, float, float, float, float, bool]] = []
    try:
        import fitz
        with fitz.open(str(ctx.path)) as doc:
            for blk in doc[page_index].get_text("dict").get("blocks", []):
                for line in blk.get("lines", []) or []:
                    for span in line.get("spans", []) or []:
                        text = str(span.get("text", "")).strip()
                        if not text:
                            continue
                        bbox = span.get("bbox") or [0.0, 0.0, 0.0, 0.0]
                        out.append((text, float(bbox[0]), float(bbox[1]), float(bbox[3]),
                                    float(span.get("size", 0.0)), "Bold" in str(span.get("font", ""))))
    except Exception as exc:  # noqa: BLE001 - a paper without spans simply takes the other paths
        print(f"    [aqa-maths] page {page_index + 1}: spans unavailable ({type(exc).__name__})")
    _SPAN_CACHE[key] = out
    return out


def _maths_is_bold_marker(text: str, *, table: bool) -> re.Match | None:
    return (_MATHS_MS_MARKER if table else _MATHS_QP_MARKER).match(text)


def _rect_has_ink(ctx: DocumentContext, page_index: int, rect: tuple[float, float, float, float]) -> bool:
    """True when anything is printed inside ``rect`` on that page.

    The maths mark scheme's last block on a page ends above the next question's header row, which
    sits below the running header on the FOLLOWING page -- that leaves a 11-25 pt rect holding
    nothing at all on 16-22 questions per paper. Measured before this guard: 8300/1H MS Q2-Q26 all
    carried an ink-free sliver; rendering one would ship a blank strip inside a question bundle.
    """
    x0, y0, x1, y1 = rect
    for bx0, by0, bx1, by1 in _page_ink_boxes(ctx, page_index):
        if bx0 < x1 and bx1 > x0 and by0 >= y0 - 0.5 and by1 <= y1 + 0.5:
            return True
    return False


def _qp_continuation_top(ctx: DocumentContext, page_index: int, *, header_band: float, right: float) -> tuple[float, str]:
    """First content ink below the header band on a continuation page (FIX 3): text, drawing or
    image, whichever is printed first; the page-number line inside the band is not content."""
    tops = [y0 for x0, y0, x1, y1 in _page_ink_boxes(ctx, page_index)
            if y0 >= header_band and x0 < right and x1 > 30.0]
    if tops:
        return max(header_band, min(tops) - 6.0), "first_content_ink"
    return header_band, "header_band"


_MS_RULE_CACHE: Dict[tuple, List[float]] = {}


def _ms_row_rules(ctx: DocumentContext, page_index: int) -> List[float]:
    """y of a mark-scheme table's row separators, from the PDF's own drawn segments.

    An AQA mark scheme draws its table as per-cell hairlines, not as one box per row: at a row
    boundary the same y carries a segment over the Question column and another over Marking
    guidance (7405/3 Section B: x 41.5-103.4 and 103.9-403.8), while the option grid inside a
    multiple-choice Comments cell draws its own lines further right (x 465.8-787.2, 557.2-744.5).
    Only segments reaching the left side of the table count, which is what tells a row boundary
    from an option grid.
    """

    key = (str(ctx.path), page_index)
    if key in _MS_RULE_CACHE:
        return _MS_RULE_CACHE[key]
    rules: List[float] = []
    try:
        import fitz
        with fitz.open(str(ctx.path)) as doc:
            for dr in doc[page_index].get_drawings():
                r = dr.get("rect")
                if r is None or float(r.height) >= 2.0 or float(r.width) < 20.0:
                    continue
                if float(r.x0) >= 200.0:
                    continue
                rules.append(float(r.y0))
    except Exception as exc:  # noqa: BLE001 - a text-only model is still valid, say so
        print(f"    [aqa] page {page_index + 1}: table rules unavailable ({type(exc).__name__})")
    rules = sorted({round(y, 1) for y in rules})
    _MS_RULE_CACHE[key] = rules
    return rules


def _ms_furniture_bounds(ctx: DocumentContext, page_index: int) -> tuple[float | None, float | None, Dict[str, Any]]:
    """(content_top, content_bottom) of a mark-scheme page, keyed on the running header /
    page-number text and the horizontal rules printed with them (FIX 4).

    Measured on 8462/1H June 2023: header text 37.7–49.7 with its rule at y=68.0 on every page,
    page number 796.0–806.9 with its rule at y=790.8. The old box (54 → h−46 = 795.9) kept both
    rules and ended 0.1 pt above the page number, so every crop carried a stray rule mid-crop,
    the blank page tail above the footer rule, and a sliced fragment at the bottom.
    """
    lines = _page_lines(ctx, page_index)
    w, h = page_size(ctx, page_index)
    header_bottom = None
    page_number_top = None
    for text, x0, y0, x1, y1 in lines:
        n = _norm(text)
        if _MS_RUNNING_HEADER.match(n) and y1 < h * 0.15:
            header_bottom = max(header_bottom or 0.0, y1)
        if _PAGE_NUMBER_LINE.match(n) and y0 > h * 0.9:
            page_number_top = min(page_number_top or h, y0)
    rules: List[float] = []
    try:
        import fitz
        with fitz.open(str(ctx.path)) as doc:
            for d in doc[page_index].get_drawings():
                r = d.get("rect")
                if r is not None and r.width > 0.5 * w and r.height < 3.0:
                    rules.append(float(r.y0))
    except Exception as exc:  # noqa: BLE001 - drawings are an extra; text bounds still apply
        rules = []
        print(f"    [aqa-ms] page {page_index + 1}: drawings unavailable ({type(exc).__name__}); text bounds only")
    top = bottom = None
    note: Dict[str, Any] = {}
    if header_bottom is not None:
        header_rules = [y for y in rules if header_bottom <= y <= header_bottom + 30.0]
        top = (max(header_rules) + 4.0) if header_rules else header_bottom + 4.0
        note["header"] = "text+rule" if header_rules else "text"
    if page_number_top is not None:
        footer_rules = [y for y in rules if page_number_top - 30.0 <= y <= page_number_top]
        bottom = (min(footer_rules) - 6.0) if footer_rules else page_number_top - 6.0
        note["footer"] = "rule+page_number" if footer_rules else "page_number"
    return top, bottom, note


def _ms_snap_below_content(ctx: DocumentContext, page_index: int, bound: float) -> tuple[float, bool]:
    """Push a mark-scheme page's bottom edge below any text line it would otherwise slice.

    Measured 2026-09-23 on 8464: the P/1H footer rule is not returned by ``get_drawings()``, so
    the page box ended at ``page_number_top - 6`` = 767.3 -- 2.3 pt INSIDE the "Total Question 1"
    row (span 754.5-769.6) -- and B/2H Q2 ended 0.1 pt inside "explanation(s).". Both shipped a
    crop with a sliced line. Furniture detection stays as it was; this only refuses to place the
    edge through a line.
    """
    straddling = [y1 for _t, _x0, y0, _x1, y1 in _page_lines(ctx, page_index) if y0 < bound < y1]
    if not straddling:
        return bound, False
    return max(bound, max(straddling) + 2.0), True


class Adapter(BoardAdapter):
    BOARD_ID = "AQA"
    BOARD_NAMES = ["AQA", "Assessment and Qualifications Alliance"]
    CONFIG_FILE = "config/boards/aqa.yaml"

    def normalize_name(self, raw: str) -> str:
        return re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")

    def _hay(self, ctx: DocumentContext) -> str:
        return f"{ctx.filename}\n{ctx.first_page_text}\n{ctx.full_text}".lower()

    def identify_document(self, ctx: DocumentContext) -> List[Evidence]:
        hay = self._hay(ctx)
        out: List[Evidence] = []
        if "aqa" in hay or "assessment and qualifications alliance" in hay:
            out.append(Evidence("board_signature", "board", self.BOARD_ID, 1.0, "AQA token in document", "document"))
        if "do not write outside the box" in hay or "for this paper you must have" in hay:
            out.append(Evidence("first_page_text", "board", self.BOARD_ID, 0.65, "AQA-style instruction/signature", "page 1"))
        return out

    def identify_subject(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        head = ctx.first_page_text or ""
        m = _SPEC.search(head)
        if m:
            full = f"{m.group(1)}/{m.group(2)}"
            out.append(Evidence("qualification_code", "syllabus_code", m.group(1), 0.95, f"spec/component {m.group(0)!r}", "page 1"))
            out.append(Evidence("component_code", "component", full, 0.95, f"spec/component {m.group(0)!r}", "page 1"))
        if "english literature" in head.lower():
            out.append(Evidence("first_page_text", "subject", "English Literature", 0.95, "cover subject title", "page 1"))
        return out

    def identify_qualification(self, ctx: DocumentContext) -> List[Evidence]:
        low = (ctx.first_page_text or "").lower()
        if "gcse" in low:
            return [Evidence("first_page_text", "qualification", "GCSE", 0.95, "GCSE on cover", "page 1")]
        return []

    def identify_session(self, ctx: DocumentContext) -> List[Evidence]:
        """Read the series and year the cover actually prints.

        The series token is matched against the adapter's OWN config session table
        (``sessions[].aliases``), so adding a series is a config change, not a code
        change. This matters because AQA prints it two different ways: mark schemes
        and reports say "June 2023", while question papers only carry the
        abbreviated form in the barcode/date line ("*JUN2384621Q01*",
        "IB/M/Jun23/E15"), which is why ``jun`` is an alias in the config.
        """
        out: List[Evidence] = []
        text = ctx.first_page_text or ""
        low = text.lower()
        if "specimen" in low:
            out.append(Evidence("first_page_text", "season", "Specimen", 1.0, "Specimen material", "page 1"))
        for spec in self.sessions():
            found = None
            for alias in [spec.name] + list(getattr(spec, "aliases", None) or []):
                token = str(alias or "").strip().lower()
                # Single letters ("s", "n") are filename hints, not cover text.
                if len(token) >= 3 and re.search(r"\b" + re.escape(token), low):
                    found = token
                    break
            if found:
                out.append(Evidence("first_page_text", "season", spec.name, 0.9,
                                    f"series token {found!r} on cover", "page 1"))
                break
        # The cover's series token wins over any year printed in the body text: the 8700/2 June
        # 2023 source insert says "published in 1933" in its first source, and taking the last
        # year on the page dated the paper June 1933 (the same defect class as the batch's
        # association pass, fixed beside this in adapters/associations.py).
        series = re.search(r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*/?\s*(\d{2,4})\b",
                           text, re.I)
        if series:
            tok = series.group(1)
            year = int(tok) if len(tok) == 4 else (2000 + int(tok) if int(tok) < 70 else 1900 + int(tok))
            out.append(Evidence("first_page_text", "year", year, 0.9,
                                f"series token {series.group(0)!r} on cover", "page 1"))
        else:
            years = [int(y) for y in _YEAR.findall(text)]
            if years:
                out.append(Evidence("first_page_text", "year", years[-1], 0.9, "year printed on cover", "page 1"))
        return out

    def identify_component(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        m = _SPEC.search(ctx.first_page_text or "")
        if m:
            full = f"{m.group(1)}/{m.group(2)}"
            out.append(Evidence("component_code", "component", full, 1.0, f"paper code {m.group(0)!r}", "page 1"))
            out.append(Evidence("component_code", "paper_number", m.group(2), 1.0, "AQA paper number is board-native", "page 1"))
        return out

    def identify_document_type(self, ctx: DocumentContext) -> List[Evidence]:
        low = (ctx.first_page_text or "").lower()
        if "mark scheme" in low:
            return [Evidence("header_footer", "document_type", "MS", 0.95, "mark scheme heading", "page 1")]
        # AQA titles these "Report on the Examination"; "examiner report" is the
        # phrase Cambridge uses. Both are the same document type, and the AQA
        # form is what its own covers print.
        if "examiner report" in low or "report on the examination" in low:
            return [Evidence("header_footer", "document_type", "ER", 0.95, "examiner report heading", "page 1")]
        if "paper 1" in low and ("instructions" in low or "answer one question" in low):
            return [Evidence("header_footer", "document_type", "QP", 0.9, "question-paper cover structure", "page 1")]
        # Any AQA question paper's cover prints its own rubric (Time allowed / Instructions /
        # For Examiner's Use / Answer all questions); an insert prints "Insert" and the sources.
        # English Language 8700/2's cover mentions "provided as a separate Insert", so the rubric
        # has to win over the word "insert" or the question paper is typed as an insert.
        if ("time allowed" in low or "for examiner" in low or "instructions" in low
                or "answer all questions" in low or "answer one question" in low
                or "question paper" in low):
            if "insert" not in low or "provided as a separate insert" in low:
                return [Evidence("header_footer", "document_type", "QP", 0.9,
                                 "question-paper cover rubric", "page 1")]
        if re.search(r"\binsert\b", low[:220]) or "insert booklet" in low:
            return [Evidence("header_footer", "document_type", "IN", 0.9, "insert cover", "page 1")]
        return []

    def identify_question_structure(self, ctx: DocumentContext) -> List[Evidence]:
        segs = self.segment(ctx)
        if segs:
            return [Evidence("document_structure", "question_count", len(segs), 0.95, "AQA alternative-pages segmentation", "document")]
        return []

    def identify_mark_scheme(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "MS"]

    def identify_examiner_report(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "ER"]

    def segments_document(self) -> bool:
        return True

    def segments_mark_scheme(self) -> bool:
        return True

    def _language_ms_starts(self, ctx: DocumentContext) -> List[tuple[int, int, float]]:
        """(question, page, y) for an English Language mark scheme, or [] if this is not one.

        The Language mark scheme is not the Science/Maths table: it prints one block per question
        ("0 1" in the same spaced left-margin form as the question paper, followed by the question
        restated, the AO it assesses and the level descriptors) with no Question/Answers/Mark
        header row at all, so the table gates reject every page of it. Measured on 8700/1 and
        8700/2 June 2023: rows at "0 1" p7 y=86.8, "0 2" p8 y=504.3, "0 3" p11, "0 4" p13, "0 5"
        p16 -- once each, contiguous 1..5, left margin x=48.2, while the page numbers ("10".."20")
        are 8 pt at x=42.5 or x=543.8 and sit below the footer rule.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text_low = " ".join(str(pg.get("text") or "").lower() for pg in pages)
        if "mark scheme" not in text_low:
            return []
        found: Dict[int, List[tuple[int, float]]] = {}
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            page_low = str(page.get("text") or "").lower()
            if "mark scheme" not in page_low:
                continue
            for line in page.get("lines") or []:
                txt = str(line.get("text", "")).strip()
                if not re.fullmatch(r"0\s+\d", txt):
                    continue
                bbox = line.get("bbox") or []
                if len(bbox) != 4:
                    continue
                x0, y0 = float(bbox[0]), float(bbox[1])
                if not (40.0 <= x0 <= 70.0 and 54.0 <= y0 <= 760.0):
                    continue
                found.setdefault(int(txt.replace(" ", "")), []).append((pi, y0))
        if not found or any(len(v) > 1 for v in found.values()):
            return []
        if sorted(found) != list(range(1, len(found) + 1)):
            return []
        return sorted(((qn, found[qn][0][0], found[qn][0][1]) for qn in found), key=lambda t: (t[1], t[2]))

    def _segment_language_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        starts = self._language_ms_starts(ctx)
        if not starts:
            return []
        full_code, paper_number = _aqa_paper_codes(self, ctx)
        total_pages = ctx.page_count or len(ctx.layout.get("pages") or [])
        segments: List[Dict[str, Any]] = []
        for idx, (qn, start_page, y0) in enumerate(starts):
            end_page = starts[idx + 1][1] - 1 if idx + 1 < len(starts) else total_pages - 1
            end_page = max(end_page, start_page)
            pages: List[Dict[str, Any]] = []
            ms_rules: List[Dict[str, Any]] = []
            for p in range(start_page, end_page + 1):
                w, h = page_size(ctx, p)
                furn_top, furn_bottom, note = _ms_furniture_bounds(ctx, p)
                page_top = furn_top if furn_top is not None else _MS_PAGE_TOP
                page_bottom = furn_bottom if furn_bottom is not None else h - 46.0
                page_bottom, snapped = _ms_snap_below_content(ctx, p, page_bottom)
                if snapped:
                    note["bottom_snapped_below_content"] = True
                top = max(page_top, y0 - _MS_ROW_PAD) if p == start_page else page_top
                ms_rules.append({"page": p + 1, **note, "top": round(page_top, 1), "bottom": round(page_bottom, 1)})
                pages.append({"page_index": p, "rect": (30.0, top, w - 30.0, max(top + 2.0, page_bottom))})
            if not pages:
                continue
            segments.append({
                "id": f"{paper_number or full_code or 'AQA'}_Unknown_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": full_code or "1",
                "pages": pages,
                "metadata": {"source_pages": [p["page_index"] + 1 for p in pages],
                             "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value,
                             "crop_plan": crop_plan(self.BOARD_ID, ctx),
                             "geometry": {"page_spans": ms_rules,
                                          "row_form": "spaced left-margin '0 N' block (Language mark scheme)"},
                             "sub_parts": [], "naming_decision": "one block per question"},
            })
        return segments

    def _maths_ms_blocks(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Mark-scheme blocks of a GCSE Mathematics paper, or [] if this is not one.

        The maths mark scheme repeats the table header row ``Q Answer Mark Comments`` at the
        start of EVERY block -- a sub-part is its own block -- and prints the question marker in
        the Q column **vertically centred** in that block, so the header row, never the marker's
        own y, is the block's top edge. Measured on 8300/1H June 2023: 1(a) header y=90.1 with
        its marker at y=231.9; 2 header y=371.2 with its marker at y=461.5. A block that runs
        onto the next page prints ``cont`` in the Q column (x=57.7) instead of a header row.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text_low = " ".join(str(pg.get("text") or "").lower() for pg in pages)
        if "mathematic" not in text_low or "gcse" not in text_low:
            return []
        headers: List[tuple[int, float]] = []
        markers: List[tuple[int, float, int, str]] = []
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            rows: List[tuple[float, set]] = []
            for text, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                if not bold:
                    continue
                if text in _MATHS_MS_HEADER_CELLS:
                    # The four cells share one baseline to within 0.3 pt, but 8300/1H page 26
                    # prints "Q"/"Mark" at 91.0 and "Answer"/"Comments" at 90.0 -- exact bucketing
                    # split that row in two and Q22's block lost its header. Cluster with a
                    # tolerance instead; _MATHS_MS_HEADER_TOL is well under the row pitch (~85 pt).
                    for row in rows:
                        if abs(row[0] - y0) <= _MATHS_MS_HEADER_TOL:
                            row[1].add(text)
                            break
                    else:
                        rows.append((y0, {text}))
                if not (_MATHS_MARKER_SIZE[0] <= size <= _MATHS_MARKER_SIZE[1]):
                    continue
                if not (_MATHS_MS_MARKER_X[0] <= x0 <= _MATHS_MS_MARKER_X[1]):
                    continue
                m = _maths_is_bold_marker(text, table=True)
                if m is None or text == _MATHS_MS_CONT:
                    continue
                markers.append((pi, y0, int(m.group(1)), text))
            for y0, cells in rows:
                if set(_MATHS_MS_HEADER_CELLS) <= cells:
                    headers.append((pi, float(y0)))
        headers.sort()
        markers.sort()
        if len(headers) < _MATHS_MIN_QUESTIONS or not markers:
            return []
        # each header row owns the block that runs to the next header row; the block's question
        # is the first marker printed inside it
        blocks: List[Dict[str, Any]] = []
        for idx, (h_page, h_y) in enumerate(headers):
            nxt = headers[idx + 1] if idx + 1 < len(headers) else None
            inside = [m for m in markers
                      if (m[0], m[1]) > (h_page, h_y)
                      and (nxt is None or (m[0], m[1]) < nxt)]
            if not inside:
                continue
            qn, label = inside[0][2], inside[0][3]
            blocks.append({"q": qn, "page": h_page, "y0": h_y, "label": label,
                           "part": label[len(str(qn)):] or ""})
        if not blocks:
            return []
        # group consecutive blocks per question, keeping document order
        groups: List[Dict[str, Any]] = []
        for blk in blocks:
            if groups and groups[-1]["q"] == blk["q"]:
                groups[-1]["blocks"].append(blk)
                groups[-1]["parts"].append(blk["label"])
                continue
            groups.append({"q": blk["q"], "blocks": [blk], "parts": [blk["label"]]})
        nums = [g["q"] for g in groups]
        if sorted(set(nums)) != list(range(1, max(nums) + 1)) or nums != sorted(nums):
            print(f"    [aqa-maths] mark scheme blocks do not form a clean 1..N run ({nums[:12]}...); not a maths MS")
            return []
        if max(nums) < _MATHS_MIN_QUESTIONS:
            return []
        return groups

    def _segment_maths_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        groups = self._maths_ms_blocks(ctx)
        if not groups:
            return []
        full_code, paper_number = _aqa_paper_codes(self, ctx)
        total_pages = ctx.page_count or len(ctx.layout.get("pages") or [])
        first_block = groups[0]["blocks"][0]
        segments: List[Dict[str, Any]] = []
        for idx, group in enumerate(groups):
            start = group["blocks"][0]
            if idx + 1 < len(groups):
                nxt = groups[idx + 1]["blocks"][0]
            else:
                nxt = None
            end_page = nxt["page"] if nxt is not None else total_pages - 1
            pages: List[Dict[str, Any]] = []
            ms_rules: List[Dict[str, Any]] = []
            for p in range(start["page"], end_page + 1):
                w, h = page_size(ctx, p)
                furn_top, furn_bottom, note = _ms_furniture_bounds(ctx, p)
                page_top = furn_top if furn_top is not None else _MS_PAGE_TOP
                page_bottom = furn_bottom if furn_bottom is not None else h - 46.0
                page_bottom, snapped = _ms_snap_below_content(ctx, p, page_bottom)
                if snapped:
                    note["bottom_snapped_below_content"] = True
                top = max(page_top, start["y0"] - _MS_ROW_PAD) if p == start["page"] else page_top
                if nxt is not None and nxt["page"] == p:
                    if nxt["y0"] <= page_top + 6.0 and p != start["page"]:
                        continue          # this page holds only the next question's block
                    bottom = max(top + 2.0, nxt["y0"] - _MS_ROW_PAD)
                    rule = "next_block_header"
                else:
                    bottom = page_bottom
                    rule = "page_box"
                # A maths mark scheme has no answer space to preserve: a block that ends above the
                # next header row leaves the rest of the page blank, and the page box would carry
                # that blank into the crop (measured on 8300/1H: page 5's last row rule at 711.6
                # against the footer bound 784.8 -- 73 pt of empty table). Trim to the last ink.
                if p != end_page or nxt is None:
                    ink_bottom = max((by1 for bx0, by0, bx1, by1 in _page_ink_boxes(ctx, p)
                                      if bx0 < w - 30.0 and bx1 > 30.0 and by0 >= top - 0.5
                                      and by1 <= bottom + 0.5), default=None)
                    if ink_bottom is not None and ink_bottom + _CUT_PAD_BELOW_CONTENT < bottom:
                        bottom = max(top + 2.0, ink_bottom + _CUT_PAD_BELOW_CONTENT)
                        rule = f"{rule}+content_trim"
                rect = (30.0, top, w - 30.0, max(top + 2.0, bottom))
                if not _rect_has_ink(ctx, p, rect):
                    note["dropped"] = "ink_free_page"
                    ms_rules.append({"page": p + 1, **note, "top": round(top, 1),
                                     "bottom": round(bottom, 1), "bottom_rule": rule})
                    continue
                ms_rules.append({"page": p + 1, **note, "top": round(top, 1), "bottom": round(bottom, 1),
                                 "bottom_rule": rule})
                pages.append({"page_index": p, "rect": rect})
            if not pages:
                continue
            qn = group["q"]
            segments.append({
                "id": f"{paper_number or full_code or 'AQA'}_Unknown_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": paper_number or full_code,
                "pages": pages,
                "sub_parts": group["parts"],
                "metadata": {
                    "document_type": "MS",
                    "paper_code": full_code,
                    "source_pages": [p["page_index"] + 1 for p in pages],
                    "sub_parts": group["parts"],
                    "sub_part_count": len(group["blocks"]),
                    "layout_archetype": LayoutArchetype.AQA_MS_SUB_PART_TABLE.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "ms_geometry": (
                        "block starts at its repeated 'Q Answer Mark Comments' header row (the Q cell "
                        "is vertically centred in the block, so the marker's own y is not the top); "
                        "every page bounded by the running header rule and the footer rule/page "
                        "number; 'cont' pages carry no header row and stay inside their block"
                    ),
                    "page_furniture": ms_rules,
                    "first_block_header": {"page": first_block["page"] + 1, "y": round(first_block["y0"], 1)},
                },
            })
        return segments

    def segment_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Segment an AQA mark scheme into one region per top-level question.

        See the module-level gates above for what makes a row a real row. Returns
        ``[]`` -- never a partial set -- when the rows do not form a clean
        1..N-per-question table, so the caller can fall back to QP-only routing
        instead of emitting a mark scheme whose coverage is quietly wrong.
        """
        # English Language first: its mark scheme is block-per-question, not a table
        # (see _language_ms_starts) and the table gates reject every page of it.
        literature = self._segment_literature_mark_scheme(ctx)
        if literature:
            return literature
        # A-level Computer Science next: its mark scheme is a "Question | Marks" (7517/1) or
        # "Qu | Pt | Marking guidance | Total marks" (7517/2) block per question with the marks in
        # the last column, plus a five-language appendix the row finder must not read as rows.
        cs = self._segment_cs_mark_scheme(ctx)
        if cs:
            return cs
        language = self._segment_language_mark_scheme(ctx)
        if language:
            return language
        # AQA A-level next: its rows are labelled 01.1 under a header row repeated per page and per
        # row group, which the GCSE science row gates cannot express (see _alevel_ms_blocks).
        alevel = self._segment_alevel_mark_scheme(ctx)
        if alevel:
            return alevel
        # AQA A-level Mathematics next: its five-column table ("Q | Marking instructions | AO |
        # Marks | Typical solution") and its "5(a)"-shaped labels are not rows of the science table
        # above (see _alevel_maths_ms_blocks).
        alevel_maths_ms = self._segment_alevel_maths_mark_scheme(ctx)
        if alevel_maths_ms:
            return alevel_maths_ms
        # GCSE Mathematics next: its table repeats a header row per block and centres the Q cell,
        # which the science row gates below cannot express (see _maths_ms_blocks).
        maths = self._segment_maths_mark_scheme(ctx)
        if maths:
            return maths
        rows = _ms_rows(ctx)
        if not rows:
            return []
        groups = _ms_group_rows(rows)
        if groups is None:
            return []
        full_code, paper_number = _aqa_paper_codes(self, ctx)
        segments: List[Dict[str, Any]] = []
        for idx, group in enumerate(groups):
            qn = group["question"]
            first = group["rows"][0]
            start_page = first["page"]
            # Stop BEFORE the next question's first page: that page belongs to the
            # next question, and truncating it mid-header would show a half row.
            if idx + 1 < len(groups):
                end_page = groups[idx + 1]["rows"][0]["page"] - 1
            else:
                end_page = (ctx.page_count or len(ctx.layout.get("pages") or [])) - 1
            end_page = max(end_page, start_page)
            pages: List[Dict[str, Any]] = []
            ms_rules: List[Dict[str, Any]] = []
            for p in range(start_page, end_page + 1):
                w, h = page_size(ctx, p)
                # FIX 4 (2026-09-23): the running header (text + rule at y=68) and the
                # page-number footer (rule at y=790.8 + number) are furniture on every
                # page; the rect stays between them, so no crop carries a stray rule,
                # the blank tail above the footer, or a sliced page number.
                furn_top, furn_bottom, note = _ms_furniture_bounds(ctx, p)
                page_top = furn_top if furn_top is not None else _MS_PAGE_TOP
                page_bottom = furn_bottom if furn_bottom is not None else h - 46.0
                page_bottom, snapped = _ms_snap_below_content(ctx, p, page_bottom)
                if snapped:
                    note["bottom_snapped_below_content"] = True
                top = max(page_top, first["y0"] - _MS_ROW_PAD) if p == start_page else page_top
                ms_rules.append({"page": p + 1, **note, "top": round(page_top, 1), "bottom": round(page_bottom, 1)})
                # Symmetric 30pt margins -- NOT the question paper's min(542, w-30).
                # That 542pt right edge exists to exclude a QUESTION PAPER's right
                # margin "Do not write outside the box" grading gutter. A mark scheme
                # has no such gutter: it has an AO / Spec. Ref. column whose text runs
                # to x=556.2 and a table border at x=556.3 on every page (measured on
                # 8462/1H June 2023), so inheriting the question-paper box would clip
                # ~14pt of that column on every single crop. The layout rule is the
                # document's own, not its companion's.
                pages.append({"page_index": p, "rect": (30.0, top, w - 30.0, max(top + 2.0, page_bottom))})
            if not pages:
                continue
            segments.append({
                "id": f"{paper_number or full_code or 'AQA'}_Unknown_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": paper_number or full_code,
                "pages": pages,
                "sub_parts": [r.get("label") or f"{qn:02d}.{r['part']}" for r in group["rows"]],
                "metadata": {
                    "document_type": "MS",
                    "paper_code": full_code,
                    "source_pages": [p["page_index"] + 1 for p in pages],
                    "sub_parts": [r.get("label") or f"{qn:02d}.{r['part']}" for r in group["rows"]],
                    "sub_part_count": len(group["rows"]),
                    "layout_archetype": LayoutArchetype.AQA_MS_SUB_PART_TABLE.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "ms_geometry": (
                        "row_start_minus_7pt_to_next_question_page; every page bounded by the running "
                        "header rule and the footer rule/page number (FIX 4); fallbacks 54pt / h-46pt"
                    ),
                    "page_furniture": ms_rules,
                },
            })
        return segments

    def _language_marker_starts(self, ctx: DocumentContext) -> List[tuple[int, int, float]]:
        """Left-margin question markers of an English Language paper, or [] if this is not one.

        A Science/Maths paper repeats the question number in the left margin of every page of a
        question ("0 1" at the top of the page AND beside each sub-part), while a Language paper
        prints each question's marker exactly once, wherever the question starts -- including
        mid-page. That difference is the discriminator, and it is measured on the real papers:

            8700/1 June 2023  "0 1" y=157.5 p2 | "0 2" y=68.8 p3 | "0 3" y=68.4 p6
                              "0 4" y=68.4 p9  | "0 5" y=169.3 p13     -> five, each once
            8462/1H June 2023 "0 1" y=68.7 AND y=111.0 AND y=603.6 on p2 alone -> repeats

        A paper whose markers repeat, or whose numbers are not exactly 1..N, is not a Language
        paper and falls through to the other paths unchanged.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text_low = " ".join(str(pg.get("text") or "").lower() for pg in pages)
        if "section b: writing" not in text_low and "section a: reading" not in text_low:
            return []
        found: Dict[int, List[tuple[int, float]]] = {}
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            for line in page.get("lines") or []:
                txt = str(line.get("text", "")).strip()
                if not re.fullmatch(r"\d\s+\d", txt):
                    continue
                bbox = line.get("bbox") or []
                if len(bbox) != 4:
                    continue
                x0, y0 = float(bbox[0]), float(bbox[1])
                if not (40.0 <= x0 <= 70.0 and 40.0 <= y0 <= 760.0):
                    continue
                found.setdefault(int(txt.replace(" ", "")), []).append((pi, y0))
        if not found:
            return []
        if any(len(v) > 1 for v in found.values()):
            return []                                   # repeats -> not a Language paper
        if sorted(found) != list(range(1, len(found) + 1)):
            return []
        starts = [(qn, found[qn][0][0], found[qn][0][1]) for qn in sorted(found)]
        starts.sort(key=lambda t: (t[1], t[2]))
        return starts

    def _segment_language_markers(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        starts = self._language_marker_starts(ctx)
        if not starts:
            return []
        pages = (ctx.layout or {}).get("pages") or []
        segments: List[Dict[str, Any]] = []
        for idx, (qn, start_page, y0) in enumerate(starts):
            if idx + 1 < len(starts):
                next_page, next_y = starts[idx + 1][1], starts[idx + 1][2]
            else:
                next_page, next_y = None, None
            end_page = next_page if next_page is not None else len(pages) - 1
            seg_pages: List[Dict[str, Any]] = []
            span_rules: List[Dict[str, Any]] = []
            content_pages = [p for p in range(start_page, end_page + 1) if _page_has_question_content(pages[p])]
            for order, p in enumerate(content_pages):
                w, h = page_size(ctx, p)
                right = min(542.0, w - 30.0)
                # Bottom furniture measured on both 8700 June 2023 papers (ink bands, all pages):
                # the answer-space rules end at 765.8, "Turn over" runs 771.8-784.1 and the
                # "IB/G/Jun23/8700/n" footer sits at 816.2-824.1, so 768.0 is inside the empty
                # window (2.2 pt below the rules, 3.8 pt above "Turn over").
                floor = min(768.0, h - 74.0)
                if p == start_page:
                    top, top_rule = max(52.0, y0 - 10.0), "question_marker"
                else:
                    top, top_rule = _qp_continuation_top(ctx, p, header_band=54.0, right=right)
                if next_page == p:
                    # The next question's marker is printed on THIS page. Its text belongs to the
                    # next question, so the rect stops 10 pt above the marker -- and when the marker
                    # starts the page (top band) this page holds nothing of the current question at
                    # all and is dropped: without that rule 8700/1 Q1 carried Q2's text and P2 Q3
                    # carried Q4's, which is exactly what the classifier scores.
                    if next_y <= 100.0 and p != start_page:
                        continue
                    if next_y <= 100.0 and p == start_page:
                        continue
                    bottom, bottom_rule = max(top + 2.0, next_y - 10.0), "next_question_marker"
                else:
                    bottom, bottom_rule = _qp_page_span(ctx, p, top=top, floor=floor, right=right,
                                                        final_page=(p == content_pages[-1]))
                seg_pages.append({"page_index": p, "rect": (30.0, top, right, bottom)})
                span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule})
            if not seg_pages:
                continue
            segments.append({
                "id": f"1H_Unknown_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1",
                "pages": seg_pages,
                "metadata": {"source_pages": [p["page_index"] + 1 for p in seg_pages],
                             "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value,
                             "crop_plan": crop_plan(self.BOARD_ID, ctx),
                             "geometry": {"page_spans": span_rules,
                                          "marker": "once per question (Language layout)"}},
            })
        return segments

    def _literature_evidence(self, ctx: DocumentContext) -> bool:
        """True when this document is an AQA A-level English Literature paper (never AS/GCSE)."""

        text = " ".join(str(pg.get("text") or "") for pg in (ctx.layout or {}).get("pages") or [])
        if "english literature" not in text.lower():
            return False
        if not _ALEVEL_LEVEL.search(text) or re.search(r"\bgcse\b", text, re.I):
            return False
        # the printed paper reference 7711/7712 (AS/A-level English Literature A) on the cover
        return re.search(r"\b771[12]\s*/\s*[12]\b", text) is not None

    def _literature_qp_markers(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Question starts of an AQA A-level English Literature question paper, or [] if not one.

        The marker is the printed two-span pair ("0 " then "N "), printed once per question on the
        line that carries the set text's title, and the questions run 1..N with N >= 5 (7712/1 June
        2022 prints seven: four Shakespeare plays, the unseen-poetry question and two comparing-text
        questions). The paper is closed-book and choice-based: the section each question belongs to is
        recorded from the bold "Section X: Name" heading printed above it.
        """

        pages = (ctx.layout or {}).get("pages") or []
        if not self._literature_evidence(ctx):
            return []
        found: List[Dict[str, Any]] = []
        section = ""
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            spans = [sp for sp in _page_text_spans(ctx, pi)
                     if _LIT_QP_MARKER_SIZE[0] <= sp[4] <= _LIT_QP_MARKER_SIZE[1]]
            y_marks: Dict[float, Dict[str, float]] = {}
            for text, x0, y0, _y1, _size, bold in spans:
                token = re.sub(r"\s+", "", text)
                if not bold:
                    continue
                head = _LIT_SECTION.match(re.sub(r"\s+", " ", text).strip())
                if head:
                    section = head.group(2).strip()
                    continue
                if not _LIT_QP_MARKER_X[0] <= x0 <= _LIT_QP_MARKER_X[1]:
                    continue
                if token == "0":
                    y_marks.setdefault(round(y0, 1), {})["zero"] = x0
                elif re.fullmatch(r"\d{1,2}", token):
                    y_marks.setdefault(round(y0, 1), {})["digit"] = x0
                    y_marks[round(y0, 1)]["value"] = float(token)
            for y in sorted(y_marks):
                row = y_marks[y]
                if "zero" in row and "digit" in row and row["digit"] > row["zero"]:
                    found.append({"q": int(row["value"]), "page": pi, "y0": y, "section": section})
        if not found:
            return []
        firsts = [f["q"] for f in found]
        if firsts != sorted(firsts) or len(set(firsts)) != len(firsts):
            print(f"    [aqa-lit] question markers out of order ({firsts[:12]}...); not an English "
                  f"Literature QP")
            return []
        if firsts != list(range(1, len(firsts) + 1)):
            print(f"    [aqa-lit] question markers are not a clean 1..N run ({firsts[:12]}...); not an "
                  f"English Literature QP")
            return []
        if not (_LIT_MIN_QUESTIONS <= len(found) <= _LIT_MAX_QUESTIONS):
            print(f"    [aqa-lit] {len(found)} questions is outside "
                  f"{_LIT_MIN_QUESTIONS}..{_LIT_MAX_QUESTIONS}; not an English Literature QP")
            return []
        return found

    def _segment_literature_questions(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level English Literature question paper (see
        _literature_qp_markers)."""

        starts = self._literature_qp_markers(ctx)
        if not starts:
            return []
        pages = (ctx.layout or {}).get("pages") or []
        segments: List[Dict[str, Any]] = []
        for idx, st in enumerate(starts):
            nxt = starts[idx + 1] if idx + 1 < len(starts) else None
            end_page = nxt["page"] if nxt is not None else len(pages) - 1
            seg_pages: List[Dict[str, Any]] = []
            span_rules: List[Dict[str, Any]] = []
            for p in range(st["page"], end_page + 1):
                w, h = page_size(ctx, p)
                right = min(542.0, w - 30.0)
                floor = min(768.0, h - 74.0)
                if p == st["page"]:
                    top, top_rule = max(52.0, st["y0"] - 12.0), "question_marker"
                else:
                    top, top_rule = _qp_continuation_top(ctx, p, header_band=54.0, right=right)
                if nxt is not None and nxt["page"] == p:
                    if nxt["y0"] <= 100.0:
                        # the page carries only the next question (its marker starts the page)
                        continue
                    bottom, bottom_rule = max(top + 2.0, nxt["y0"] - 12.0), "next_question_marker"
                else:
                    bottom, bottom_rule = _qp_page_span(ctx, p, top=top, floor=floor, right=right,
                                                        final_page=(p == end_page))
                rect = (30.0, top, right, bottom)
                if not _rect_has_ink(ctx, p, rect):
                    span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule,
                                       "dropped": "ink_free_page"})
                    continue
                seg_pages.append({"page_index": p, "rect": rect})
                span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule})
            if not seg_pages:
                continue
            qn = st["q"]
            segments.append({
                "id": f"7712/1_Unknown_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1",
                "pages": seg_pages,
                "metadata": {
                    "source_pages": [p["page_index"] + 1 for p in seg_pages],
                    "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "section": st["section"],
                    "geometry": {"page_spans": span_rules,
                                 "marker": "once per question: the bold '0 N' pair on the line that "
                                           "carries the set text's title (English Literature layout)",
                                 "section_heading": st["section"],
                                 "floor": 768.0},
                },
            })
        return segments

    def _literature_ms_starts(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Question blocks of an AQA A-level English Literature mark scheme, or [] if not one.

        The mark scheme is not a table: after the generic level-of-response grid it prints one block
        per question, headed by a bold ``Question 01`` .. ``Question 07`` (measured on 77121-MS-JUN22
        page 13: bold 11 pt at x 42.6, followed by the question's own "0 N" marker). Every block
        restates the question, names the set text and lists the AO focus for that question.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text = " ".join(str(pg.get("text") or "") for pg in pages)
        if "mark scheme" not in text.lower() or not self._literature_evidence(ctx):
            return []
        found: List[Dict[str, Any]] = []
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            for text_, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                if not bold or not (10.0 <= size <= 12.6) or not (35.0 <= x0 <= 60.0):
                    continue
                m = _LIT_MS_HEADING.match(re.sub(r"\s+", " ", text_).strip())
                if m:
                    found.append({"q": int(m.group(1)), "page": pi, "y0": y0})
        if not found:
            return []
        firsts = [f["q"] for f in found]
        if firsts != sorted(firsts) or len(set(firsts)) != len(firsts) \
                or firsts != list(range(1, len(firsts) + 1)):
            print(f"    [aqa-lit] mark scheme block headings are not a clean 1..N run "
                  f"({firsts[:12]}...); not an English Literature mark scheme")
            return []
        if not (_LIT_MIN_QUESTIONS <= len(found) <= _LIT_MAX_QUESTIONS):
            print(f"    [aqa-lit] {len(found)} mark-scheme blocks is outside "
                  f"{_LIT_MIN_QUESTIONS}..{_LIT_MAX_QUESTIONS}")
            return []
        return found

    def _segment_literature_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level English Literature mark scheme (see
        _literature_ms_starts)."""

        starts = self._literature_ms_starts(ctx)
        if not starts:
            return []
        total_pages = ctx.page_count or len((ctx.layout or {}).get("pages") or [])
        segments: List[Dict[str, Any]] = []
        for idx, st in enumerate(starts):
            nxt = starts[idx + 1] if idx + 1 < len(starts) else None
            end_page = nxt["page"] if nxt is not None else total_pages - 1
            pages: List[Dict[str, Any]] = []
            ms_rules: List[Dict[str, Any]] = []
            for p in range(st["page"], end_page + 1):
                w, h = page_size(ctx, p)
                furn_top, furn_bottom, note = _ms_furniture_bounds(ctx, p)
                page_top = furn_top if furn_top is not None else _MS_PAGE_TOP
                page_bottom = furn_bottom if furn_bottom is not None else h - 46.0
                page_bottom, snapped = _ms_snap_below_content(ctx, p, page_bottom)
                if snapped:
                    note["bottom_snapped_below_content"] = True
                top = max(page_top, st["y0"] - 8.0) if p == st["page"] else page_top
                if nxt is not None and nxt["page"] == p:
                    if nxt["y0"] <= page_top + 6.0 and p != st["page"]:
                        continue
                    bottom = max(top + 2.0, nxt["y0"] - 8.0)
                    rule = "next_question_heading"
                else:
                    bottom = page_bottom
                    rule = "page_box"
                if p != end_page or nxt is None:
                    ink_bottom = max((by1 for bx0, by0, bx1, by1 in _page_ink_boxes(ctx, p)
                                      if bx0 < w - 30.0 and bx1 > 30.0 and by0 >= top - 0.5
                                      and by1 <= bottom + 0.5), default=None)
                    if ink_bottom is not None and ink_bottom + _CUT_PAD_BELOW_CONTENT < bottom:
                        bottom = max(top + 2.0, ink_bottom + _CUT_PAD_BELOW_CONTENT)
                        rule = f"{rule}+content_trim"
                rect = (30.0, top, w - 30.0, max(top + 2.0, bottom))
                if not _rect_has_ink(ctx, p, rect):
                    note["dropped"] = "ink_free_page"
                    ms_rules.append({"page": p + 1, **note, "top": round(top, 1),
                                     "bottom": round(bottom, 1), "bottom_rule": rule})
                    continue
                ms_rules.append({"page": p + 1, **note, "top": round(top, 1),
                                 "bottom": round(bottom, 1), "bottom_rule": rule,
                                 "heading_y": round(st["y0"], 1) if p == st["page"] else None})
                pages.append({"page_index": p, "rect": rect})
            if not pages:
                continue
            qn = st["q"]
            segments.append({
                "id": f"7712/1_Unknown_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1",
                "pages": pages,
                "metadata": {
                    "document_type": "MS",
                    "paper_code": "7712/1",
                    "source_pages": [p["page_index"] + 1 for p in pages],
                    "layout_archetype": LayoutArchetype.AQA_MS_SUB_PART_TABLE.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "ms_geometry": (
                        "question block starts at the bold 'Question NN' heading above the question's "
                        "own restatement and ends above the next question's heading; every page "
                        "bounded by the running header and the footer rule"
                    ),
                    "page_furniture": ms_rules,
                },
            })
        return segments

    def _cs_evidence(self, ctx: DocumentContext) -> bool:
        """True when this document is an AQA A-level Computer Science paper (never AS/GCSE)."""

        text = " ".join(str(pg.get("text") or "") for pg in (ctx.layout or {}).get("pages") or [])
        if not _CS_QP_EVIDENCE.search(text) or not _ALEVEL_LEVEL.search(text) \
                or re.search(r"\bgcse\b", text, re.I):
            return False
        return _CS_CODE.search(text) is not None

    def _cs_qp_markers(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Question starts of an AQA A-level Computer Science question paper, or [] if not one.

        The marker is one bold span at the left of the text column that prints the question number
        with an internal space -- "0 1" is question 1 and "1 4" is question 14 -- and it is printed
        ONCE per question, because this is an ON-SCREEN paper whose answer is written in the
        Electronic Answer Document and whose parts each carry their own ". M" line (75171-QP-JUN23
        pages 4-5 print "0 3" once and then "0 3" + ". 1" .. ". 7" for its seven parts). A line that
        also carries a part marker is therefore a part, not a new question, and the part markers print
        in their own column (measured: x 82.3-87.8, so _CS_QP_PART_X is 76.0-101.0 -- a narrower
        84-100 band missed the ". 1" of a part whose marker sits at 82.3), so the two are told apart
        by the marker's own column as well as by shape. A number is a NEW question only the first time
        it is printed in ascending order: a later line carrying the same number is one of that
        question's parts, or a repeat in the "Evidence that you need to provide" list AQA prints at the
        foot of the question (measured: all four published papers run 1..N -- 16, 14, 12 and 13
        questions).
        """

        pages = (ctx.layout or {}).get("pages") or []
        if not self._cs_evidence(ctx):
            return []
        found: List[Dict[str, Any]] = []
        section = ""
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue                  # the cover prints the examiner-use grid of every question
            lines: Dict[float, Dict[str, Any]] = {}
            for text_, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                if not bold or not (_CS_QP_MARKER_SIZE[0] <= size <= _CS_QP_MARKER_SIZE[1]):
                    continue
                cell = re.sub(r"\s+", " ", text_).strip()
                head = _CS_SECTION.match(cell)
                if head:
                    section = head.group(0).strip()
                    continue
                token = re.sub(r"\s+", "", text_)
                key = round(y0, 1)
                row = lines.setdefault(key, {"number": None, "part": False})
                if re.fullmatch(r"\d{1,2}", token) and x0 <= _CS_QP_MARKER_X[1]:
                    row["number"] = int(token)
                elif re.fullmatch(r"\.?\d{1,2}", token) and _CS_QP_PART_X[0] <= x0 <= _CS_QP_PART_X[1]:
                    row["part"] = True
            for key in sorted(lines):
                row = lines[key]
                if row["number"] is not None and row["number"] > 0:
                    found.append({"q": row["number"], "page": pi, "y0": key, "section": section})
        if not found:
            return []
        # A question whose parts start straight away prints its number ON THE SAME LINE as its first
        # part ("0 4 . 1"), so the number that STARTS a question is the first line that carries it --
        # every later line with the same number is one of its parts (or a repeat in the "Evidence that
        # you need to provide" list at the foot of the question). Numbers must ascend; a repeat or a
        # stray bold number in a table is not a new question.
        starts: List[Dict[str, Any]] = []
        for f in found:
            if not starts or f["q"] > starts[-1]["q"]:
                starts.append(dict(f))
        firsts = [f["q"] for f in starts]
        if firsts != sorted(set(firsts)):
            print(f"    [aqa-cs] question markers are not an ascending run ({firsts[:12]}...); not a "
                  f"Computer Science QP")
            return []
        if not (_CS_MIN_QUESTIONS <= len(starts) <= _CS_MAX_QUESTIONS):
            print(f"    [aqa-cs] {len(starts)} questions is outside {_CS_MIN_QUESTIONS}.."
                  f"{_CS_MAX_QUESTIONS}; not a Computer Science QP")
            return []
        return starts

    def _segment_cs_questions(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level Computer Science question paper (see _cs_qp_markers).

        The paper is on-screen: a question is instructions only, so its crop runs from the question's
        own marker line to the line above the next question's marker (or to the foot of the last page
        that carries it), and the section heading printed above it (Section A-D) is recorded.
        """

        starts = self._cs_qp_markers(ctx)
        if not starts:
            return []
        pages = (ctx.layout or {}).get("pages") or []
        label = self._paper_label(ctx) or "AQA"
        segments: List[Dict[str, Any]] = []
        for idx, st in enumerate(starts):
            nxt = starts[idx + 1] if idx + 1 < len(starts) else None
            end_page = nxt["page"] if nxt is not None else len(pages) - 1
            seg_pages: List[Dict[str, Any]] = []
            span_rules: List[Dict[str, Any]] = []
            for p in range(st["page"], end_page + 1):
                w, h = page_size(ctx, p)
                right = min(542.0, w - 30.0)
                # this subject's page furniture sits lower than the science papers': the last caption
                # of a question can print at y 780 (75171-QP-JUN22 Q13's "[1 mark]"), while "Turn over"
                # prints at y 800 and the footer at y 821 -- so the floor is 790, not the 768 the
                # science papers use (which cut that caption off)
                floor = min(_CS_QP_FLOOR, h - 52.0)
                if p == st["page"]:
                    top, top_rule = max(52.0, st["y0"] - 12.0), "question_marker"
                else:
                    top, top_rule = _qp_continuation_top(ctx, p, header_band=54.0, right=right)
                if nxt is not None and nxt["page"] == p:
                    if nxt["y0"] <= 100.0:
                        continue          # the page carries only the next question
                    bottom, bottom_rule = max(top + 2.0, nxt["y0"] - 12.0), "next_question_marker"
                else:
                    bottom, bottom_rule = _qp_page_span(ctx, p, top=top, floor=floor, right=right,
                                                        final_page=(p == end_page))
                rect = (30.0, top, right, bottom)
                if not _rect_has_ink(ctx, p, rect):
                    span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule,
                                       "dropped": "ink_free_page"})
                    continue
                seg_pages.append({"page_index": p, "rect": rect})
                span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule})
            if not seg_pages:
                continue
            qn = st["q"]
            segments.append({
                "id": f"{label}_Unknown_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": (label.split("/")[1] if "/" in label else "1"),
                "pages": seg_pages,
                "metadata": {
                    "source_pages": [p["page_index"] + 1 for p in seg_pages],
                    "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "section": st["section"],
                    "geometry": {"page_spans": span_rules,
                                 "marker": "once per question: the bold '0 N' pair on a line of its "
                                           "own (an A-level Computer Science on-screen paper)",
                                 "section_heading": st["section"],
                                 "marks": "printed in the mark scheme, not on this paper",
                                 "floor": _CS_QP_FLOOR},
                },
            })
        return segments

    def _cs_ms_blocks(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Question blocks of an AQA A-level Computer Science mark scheme, in the shape the A-level
        mark-scheme crop loop expects (see _segment_alevel_mark_scheme).

        Both table layouts this subject prints are read here. 7517/1 repeats "Question | Marks" at the
        top of every page of its table with the question number in the Question column (x 53.5) and
        its part, where it has one, in a column of its own (x 85.8); 7517/2 repeats
        "Qu | Pt | Marking guidance | Total marks" -- whose "Total"/"marks" pair prints on the line
        above the other three names -- with the same label columns at x 50.8 and x 82.3. A row is read
        by x band, because the Marking guidance column prints bold marks and codes ("Max 1", "A.",
        "2 marks") on the same line as the row label. Pages whose left margin prints a language
        heading (7517/1's appendix re-prints every programming answer under "VB.Net", "Python 3", ...
        and repeats the header and the label columns) are not question blocks. Neither scheme prints a
        specification reference or a question total.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text = " ".join(str(pg.get("text") or "") for pg in pages)
        if not re.search(r"\bmark\s+scheme\b", text, re.I) or not self._cs_evidence(ctx):
            return []
        appendix: Optional[int] = None
        for page in pages:
            pi = int(page.get("page_index", 0))
            for text_, x0, _y0, _y1, _size, bold in _page_text_spans(ctx, pi):
                if not bold or x0 > _CS_APPENDIX_X:
                    continue
                if _CS_APPENDIX.match(re.sub(r"\s+", " ", text_).strip()):
                    appendix = pi if appendix is None else min(appendix, pi)
                    break
        rows_by_page: Dict[int, List[tuple]] = {}
        header_tops: Dict[int, List[float]] = {}
        for page in pages:
            pi = int(page.get("page_index", 0))
            if appendix is not None and pi >= appendix:
                continue
            rows: List[tuple] = []
            for text_, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                cell = re.sub(r"\s+", " ", text_).strip()
                if not bold or not (_CS_MS_LABEL_SIZE[0] <= size <= _CS_MS_LABEL_SIZE[1]):
                    continue
                for row in rows:
                    if abs(row[0] - y0) <= _CS_MS_HEADER_TOL:
                        row[1].append((cell, x0, y0))
                        break
                else:
                    rows.append((y0, [(cell, x0, y0)]))
            cells = [cell for _y, group in rows for cell in group]
            tops: List[float] = []
            for y0, _group in rows:
                names = {c.lower() for c, _x, y in cells if abs(y - y0) <= _CS_MS_HEADER_WINDOW}
                if any(set(hdr) <= names for hdr in _CS_MS_HEADERS):
                    tops.append(min(y for _c, _x, y in cells
                                    if abs(y - y0) <= _CS_MS_HEADER_WINDOW))
            if rows:
                rows_by_page[pi] = rows
            if tops:
                header_tops[pi] = sorted(set(tops))
        if not header_tops:
            return []
        # the FIRST header starts the table (everything before it is the cover, the AO grid and the
        # grade-descriptor notes); from there to the appendix every page carries rows, because AQA
        # prints the header once per question block, not once per page
        first_header_page = min(header_tops)
        headers = sorted((pi, y) for pi, ys in header_tops.items() for y in ys)
        rows_by_page = {pi: rows for pi, rows in rows_by_page.items() if pi >= first_header_page}
        if not rows_by_page:
            return []
        headers.sort()
        labels: List[Dict[str, Any]] = []
        for pi in sorted(rows_by_page):
            for y0, cells in rows_by_page[pi]:
                q_cell = [(c, x) for c, x, _y in cells
                          if _CS_MS_Q_X[0] <= x < _CS_MS_Q_X[1] and re.fullmatch(r"\d{1,2}", c)]
                if not q_cell:
                    continue
                q_text, q_x = min(q_cell, key=lambda t: t[1])
                part = None
                p_cell = [(c, x) for c, x, _y in cells
                          if _CS_MS_P_X[0] <= x <= _CS_MS_P_X[1] and re.fullmatch(r"\d{1,2}", c)]
                if p_cell:
                    part = min(p_cell, key=lambda t: t[1])[0]
                labels.append({"page": pi, "y0": y0, "x0": q_x, "label": q_text,
                               "part": part, "bold": True, "q": int(q_text)})
        labels.sort(key=lambda d: (d["page"], d["y0"]))
        if not labels:
            return []
        groups: List[Dict[str, Any]] = []
        for lab in labels:
            if not groups or groups[-1]["q"] != lab["q"]:
                groups.append({"q": lab["q"], "labels": []})
            groups[-1]["labels"].append(lab)
        nums = [g["q"] for g in groups]
        if nums != sorted(nums) or len(set(nums)) != len(nums) \
                or not (_CS_MIN_QUESTIONS <= len(nums) <= _CS_MAX_QUESTIONS):
            print(f"    [aqa-cs] mark-scheme row labels are not a clean ascending question run "
                  f"({nums[:12]}...); not a Computer Science mark scheme")
            return []
        for grp in groups:
            for lab in grp["labels"]:
                above = [hb for hb in headers if hb <= (lab["page"], lab["y0"])]
                lab["header"] = above[-1] if above else (lab["page"], 54.0)
            grp["first"] = grp["labels"][0]
            grp["start_header"] = grp["labels"][0]["header"]
            grp["parts"] = [lab["part"] for lab in grp["labels"]]
            grp["row_bounded"] = False
        # the last block of 7517/1's table is followed by the appendix (whose pages are not read as
        # rows at all), so the block stops on the last page of the table
        groups[-1]["stop_page"] = max(rows_by_page)
        return groups

    def _segment_cs_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level Computer Science mark scheme."""

        groups = self._cs_ms_blocks(ctx)
        if not groups:
            return []
        return self._segment_alevel_mark_scheme(ctx, groups=groups)

    def _maths_marker_starts(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Question starts of a GCSE Mathematics QUESTION PAPER, or [] if this is not one.

        A maths question paper has no boxed ``0 N`` marker: each question opens with a bare bold
        ``N`` (or ``N (a)`` when its first part is printed beside the number) in the left margin,
        and when the parts are separate blocks the number is re-printed before each of them.
        The marker run must be exactly 1..N with N >= {min_q}, in ascending document order --
        measured 27 / 26 / 23 questions on the three June-2023 Higher papers -- so a paper that
        merely has bold numbers in its margin cannot be segmented by this path.
        """.format(min_q=_MATHS_MIN_QUESTIONS)

        pages = (ctx.layout or {}).get("pages") or []
        text_low = " ".join(str(pg.get("text") or "").lower() for pg in pages)
        if "mathematic" not in text_low or "gcse" not in text_low:
            return []
        hits: List[Dict[str, Any]] = []
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            current: int | None = hits[-1]["marker_q"] if hits else None
            for text, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                if not bold or not (_MATHS_MARKER_SIZE[0] <= size <= _MATHS_MARKER_SIZE[1]):
                    continue
                if not (_MATHS_QP_MARKER_X[0] <= x0 <= _MATHS_QP_MARKER_X[1]):
                    continue
                m = _maths_is_bold_marker(text, table=False)
                if m is None:
                    continue
                num, letter = m.group(1), m.group(2)
                hits.append({"page": pi, "y0": y0, "text": text,
                             "marker_q": int(num) if num else current,
                             "letter": letter or (m.group(3) or None),
                             "bare_part": num is None})
        numbered = [h for h in hits if not h["bare_part"]]
        if not numbered:
            return []
        firsts: Dict[int, Dict[str, Any]] = {}
        order: List[int] = []
        for h in numbered:
            qn = h["marker_q"]
            if qn not in firsts:
                firsts[qn] = h
                order.append(qn)
        if order != sorted(order):
            print(f"    [aqa-maths] question markers out of order ({order[:12]}...); not a maths QP")
            return []
        if sorted(firsts) != list(range(1, max(firsts) + 1)):
            print(f"    [aqa-maths] question markers are not a clean 1..N run "
                  f"({sorted(firsts)[:12]}...); not a maths QP")
            return []
        if max(firsts) < _MATHS_MIN_QUESTIONS:
            return []
        qn_order = [firsts[q]["marker_q"] for q in order]
        starts: List[Dict[str, Any]] = []
        for idx, qn in enumerate(qn_order):
            nxt = qn_order[idx + 1] if idx + 1 < len(qn_order) else None
            parts: List[str] = []
            for h in hits:
                if h["marker_q"] != qn or h is firsts[qn]:
                    continue
                if nxt is None or (h["page"], h["y0"]) < (firsts[nxt]["page"], firsts[nxt]["y0"]):
                    parts.append(h["text"])
            if firsts[qn]["letter"]:
                parts.insert(0, firsts[qn]["text"])
            starts.append({"q": qn, "page": firsts[qn]["page"], "y0": firsts[qn]["y0"],
                           "parts": sorted(set(parts),
                                           key=lambda t: (t, len(t)))})
        return starts

    def _segment_maths_questions(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        starts = self._maths_marker_starts(ctx)
        if not starts:
            return []
        pages = (ctx.layout or {}).get("pages") or []
        segments: List[Dict[str, Any]] = []
        for idx, st in enumerate(starts):
            nxt = starts[idx + 1] if idx + 1 < len(starts) else None
            end_page = nxt["page"] if nxt is not None else len(pages) - 1
            seg_pages: List[Dict[str, Any]] = []
            span_rules: List[Dict[str, Any]] = []
            for p in range(st["page"], end_page + 1):
                w, h = page_size(ctx, p)
                right = min(542.0, w - 30.0)       # excludes the right-margin "Do not write" strip
                floor = min(_MATHS_QP_FLOOR, h - 74.0)
                if p == st["page"]:
                    top, top_rule = max(_MATHS_QP_HEADER_BAND, st["y0"] - 12.0), "question_marker"
                else:
                    top, top_rule = _qp_continuation_top(ctx, p, header_band=_MATHS_QP_HEADER_BAND,
                                                         right=right)
                if nxt is not None and nxt["page"] == p:
                    if nxt["y0"] <= _MATHS_QP_HEADER_BAND + 40.0 and p != st["page"]:
                        continue                    # the page holds only the next question
                    bottom, bottom_rule = max(top + 2.0, nxt["y0"] - 10.0), "next_question_marker"
                else:
                    bottom, bottom_rule = _qp_page_span(ctx, p, top=top, floor=floor, right=right,
                                                        final_page=(p == end_page))
                rect = (30.0, top, right, bottom)
                if not _rect_has_ink(ctx, p, rect):
                    span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule,
                                       "dropped": "ink_free_page"})
                    continue
                seg_pages.append({"page_index": p, "rect": rect})
                span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule})
            if not seg_pages:
                continue
            qn = st["q"]
            segments.append({
                "id": f"{self._paper_label(ctx)}_Unknown_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1",
                "pages": seg_pages,
                "metadata": {
                    "source_pages": [p["page_index"] + 1 for p in seg_pages],
                    "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "sub_parts": st["parts"],
                    "geometry": {"page_spans": span_rules,
                                 "marker": "bare bold 'N' question number, re-printed before each "
                                           "separate part block (Maths layout)",
                                 "floor": _MATHS_QP_FLOOR},
                },
            })
        return segments

    def _alevel_maths_qp_markers(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Question starts of an AQA A-LEVEL MATHEMATICS question paper, or [] if this is not one.

        The marker is a bare number (or a number with its part label, ``5 (a)``, ``14 (a) (i)``) in
        the left margin with the question's own sentence beside it on the same line -- see the
        constants above for the measured geometry. The run must be a clean 1..N in ascending
        document order with N inside the range these papers print (measured 16 / 20 / 17), which is
        what keeps a diagram label or a margin number from being read as a question.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text = " ".join(str(pg.get("text") or "") for pg in pages)
        if "mathematic" not in text.lower() or not _ALEVEL_LEVEL.search(text) \
                or re.search(r"\bgcse\b", text, re.I):
            return []
        hits: List[Dict[str, Any]] = []
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            spans = _page_text_spans(ctx, pi)
            text_ys = sorted({round(y0, 1) for t, x0, y0, _y1, _size, _bold in spans
                              if _ALEVEL_MATHS_QP_TEXT_X[0] <= x0 <= _ALEVEL_MATHS_QP_TEXT_X[1] and len(t) > 2})
            for t, x0, y0, _y1, size, _bold in spans:
                if not (_ALEVEL_MATHS_QP_MARKER_SIZE[0] <= size <= _ALEVEL_MATHS_QP_MARKER_SIZE[1]):
                    continue
                if not (_ALEVEL_MATHS_QP_MARKER_X[0] <= x0 <= _ALEVEL_MATHS_QP_MARKER_X[1]):
                    continue
                m = _ALEVEL_MATHS_QP_MARKER.match(t.strip())
                if m is None:
                    continue
                if not any(abs(y - y0) <= 3.0 for y in text_ys):
                    continue                       # no sentence beside it: not a question marker
                hits.append({"page": pi, "y0": y0, "text": t.strip(), "q": int(m.group(1)),
                             "part": (m.group(2) or ""), "sub": (m.group(3) or "")})
        if not hits:
            return []
        hits.sort(key=lambda h: (h["page"], h["y0"]))
        firsts: Dict[int, Dict[str, Any]] = {}
        order: List[int] = []
        for h in hits:
            if h["q"] not in firsts:
                firsts[h["q"]] = h
                order.append(h["q"])
        if order != sorted(order) or sorted(firsts) != list(range(1, max(firsts) + 1)):
            print(f"    [aqa-alevel-maths] question markers are not a clean 1..N run "
                  f"({sorted(firsts)[:12]}...); not an A-level maths QP")
            return []
        count = max(firsts)
        if not (_ALEVEL_MATHS_MIN_QUESTIONS <= count <= _ALEVEL_MATHS_MAX_QUESTIONS):
            print(f"    [aqa-alevel-maths] {count} questions is outside "
                  f"{_ALEVEL_MATHS_MIN_QUESTIONS}..{_ALEVEL_MATHS_MAX_QUESTIONS}; not an A-level maths QP")
            return []
        starts: List[Dict[str, Any]] = []
        for idx, qn in enumerate(order):
            nxt = order[idx + 1] if idx + 1 < len(order) else None
            parts = []
            for h in hits:
                if h["q"] != qn:
                    continue
                if nxt is not None:
                    limit = (firsts[nxt]["page"], firsts[nxt]["y0"])
                    if (h["page"], h["y0"]) >= limit:
                        continue
                parts.append(h["text"])
            starts.append({"q": qn, "page": firsts[qn]["page"], "y0": firsts[qn]["y0"],
                           "parts": parts, "opening": firsts[qn]["text"]})
        return starts

    def _segment_alevel_maths_questions(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level mathematics question paper (see
        _alevel_maths_qp_markers)."""

        starts = self._alevel_maths_qp_markers(ctx)
        if not starts:
            return []
        pages = (ctx.layout or {}).get("pages") or []
        segments: List[Dict[str, Any]] = []
        for idx, st in enumerate(starts):
            nxt = starts[idx + 1] if idx + 1 < len(starts) else None
            end_page = nxt["page"] if nxt is not None else len(pages) - 1
            seg_pages: List[Dict[str, Any]] = []
            span_rules: List[Dict[str, Any]] = []
            for p in range(st["page"], end_page + 1):
                w, h = page_size(ctx, p)
                # The A-level maths answer box closes at x 535.7 and the right-margin "Do not write
                # outside the box" strip starts at x 545.2 (measured on 73571-QP-JUN23 pages 2/3/9),
                # so the crop stops at 542 -- the same edge the other AQA question paths use. The
                # earlier 556.0 kept 11 pt of that strip in every crop, which the output contract
                # refuses ("AQA boxed crop includes right-margin box ink").
                right = min(542.0, w - 30.0)
                floor = min(_ALEVEL_MATHS_QP_FLOOR, h - 74.0)
                if p == st["page"]:
                    top, top_rule = max(_ALEVEL_MATHS_QP_HEADER_BAND, st["y0"] - 12.0), "question_marker"
                else:
                    top, top_rule = _qp_continuation_top(ctx, p, header_band=_ALEVEL_MATHS_QP_HEADER_BAND,
                                                         right=right)
                if nxt is not None and nxt["page"] == p:
                    if nxt["y0"] <= _ALEVEL_MATHS_QP_HEADER_BAND + 40.0 and p != st["page"]:
                        continue                  # the page holds only the next question
                    bottom, bottom_rule = max(top + 2.0, nxt["y0"] - 10.0), "next_question_marker"
                else:
                    bottom, bottom_rule = _qp_page_span(ctx, p, top=top, floor=floor, right=right,
                                                        final_page=(p == end_page))
                rect = (30.0, top, right, bottom)
                if not _rect_has_ink(ctx, p, rect):
                    span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule,
                                       "dropped": "ink_free_page"})
                    continue
                seg_pages.append({"page_index": p, "rect": rect})
                span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule})
            if not seg_pages:
                continue
            qn = st["q"]
            segments.append({
                "id": f"{self._paper_label(ctx)}_Unknown_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1",
                "pages": seg_pages,
                "metadata": {
                    "source_pages": [p["page_index"] + 1 for p in seg_pages],
                    "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "sub_parts": st["parts"],
                    "geometry": {"page_spans": span_rules,
                                 "marker": "bare number (or number + part label) in the left margin "
                                           "with the question's sentence beside it on the same line "
                                           "(A-level Mathematics layout)",
                                 "floor": _ALEVEL_MATHS_QP_FLOOR},
                },
            })
        return segments

    def _alevel_qp_markers(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Question starts of an AQA A-LEVEL question paper, or [] if this is not one.

        Measured on 7402/1 June 2023 (36 pp): the marker is ``0 1`` at x0 52.7, bold 11 pt, and
        the part marker ``. 1`` sits on the SAME line at x0 82.4; a part laid out as its own block
        re-prints the number above it (``0 1`` then ``. 2``). 38 number spans and 38 part spans
        over 9 questions -- every part of every question, which is the fail-closed run below:
        the numbers must first occur in ascending order as a clean 1..N run with N >= {min_q}.
        A GCSE science paper prints the same marker pair, so the cover's level word decides.
        """.format(min_q=_ALEVEL_MIN_QUESTIONS)

        pages = (ctx.layout or {}).get("pages") or []
        text = " ".join(str(pg.get("text") or "") for pg in pages)
        if not _ALEVEL_LEVEL.search(text) or re.search(r"\bgcse\b", text, re.I):
            return []
        events: List[Dict[str, Any]] = []
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            for text_, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                if not bold or not (_ALEVEL_MARKER_SIZE[0] <= size <= _ALEVEL_MARKER_SIZE[1]):
                    continue
                body = text_
                m = _ALEVEL_QP_NUM.match(body)
                if m and _ALEVEL_MARKER_X[0] <= x0 <= _ALEVEL_MARKER_X[1]:
                    events.append({"page": pi, "y0": y0, "kind": "q",
                                   "value": int(m.group(1) + m.group(2)), "text": body})
                    continue
                m = _ALEVEL_QP_PART.match(body)
                if m and _ALEVEL_PART_X[0] <= x0 <= _ALEVEL_PART_X[1]:
                    events.append({"page": pi, "y0": y0, "kind": "part", "value": int(m.group(1)), "text": body})
        if not events:
            return []
        # one printed LINE can hold the number and its part (0 1 . 1); cluster the events by line
        lines: List[Dict[str, Any]] = []
        for ev in sorted(events, key=lambda e: (e["page"], round(e["y0"], 1), 0 if e["kind"] == "q" else 1)):
            for line in lines:
                if line["page"] == ev["page"] and abs(line["y0"] - ev["y0"]) <= 2.0:
                    line.setdefault(ev["kind"], []).append(ev)
                    break
            else:
                lines.append({"page": ev["page"], "y0": ev["y0"], ev["kind"]: [ev]})
        numbered = [ln for ln in lines if ln.get("q")]
        if not numbered:
            return []
        firsts: Dict[int, Dict[str, Any]] = {}
        order: List[int] = []
        for ln in numbered:
            qn = ln["q"][0]["value"]
            if qn not in firsts:
                firsts[qn] = ln
                order.append(qn)
        if order != sorted(order) or sorted(firsts) != list(range(1, max(order) + 1)):
            print(f"    [aqa-alevel] question markers are not a clean 1..N run ({order[:12]}...); not an A-level QP")
            return []
        count = max(firsts)
        min_questions = (_ALEVEL_PAPER3_MIN_QUESTIONS if _ALEVEL_PAPER3_EVIDENCE.search(text)
                         else _ALEVEL_MIN_QUESTIONS)
        if count > _ALEVEL_MAX_QUESTIONS:
            if not (_ALEVEL_MCQ_EVIDENCE.search(text) and count <= _ALEVEL_MCQ_MAX_QUESTIONS):
                print(f"    [aqa-alevel] {count} questions is outside "
                      f"{min_questions}..{_ALEVEL_MAX_QUESTIONS} and the paper carries no "
                      f"multiple-choice section; not an A-level QP")
                return []
            print(f"    [aqa-alevel] {count} questions with the Section B multiple-choice "
                  f"instructions printed: A-level MCQ paper")
        elif count < min_questions:
            print(f"    [aqa-alevel] {count} questions is below {min_questions}; not an A-level QP")
            return []
        starts: List[Dict[str, Any]] = []
        for idx, qn in enumerate(order):
            nxt = order[idx + 1] if idx + 1 < len(order) else None
            parts: List[str] = []
            for ln in lines:
                if (ln["page"], ln["y0"]) < (firsts[qn]["page"], firsts[qn]["y0"]):
                    continue
                if nxt is not None and (ln["page"], ln["y0"]) >= (firsts[nxt]["page"], firsts[nxt]["y0"]):
                    continue
                for ev in ln.get("part", []):
                    if ev["text"] not in parts:
                        parts.append(ev["text"])
            parts.sort(key=lambda t: (int(t.replace(".", "").strip() or 0), t))
            starts.append({"q": qn, "page": firsts[qn]["page"], "y0": firsts[qn]["y0"], "parts": parts})
        return starts

    def _segment_alevel_questions(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level question paper (see _alevel_qp_markers)."""

        starts = self._alevel_qp_markers(ctx)
        if not starts:
            return []
        pages = (ctx.layout or {}).get("pages") or []
        segments: List[Dict[str, Any]] = []
        for idx, st in enumerate(starts):
            nxt = starts[idx + 1] if idx + 1 < len(starts) else None
            end_page = nxt["page"] if nxt is not None else len(pages) - 1
            seg_pages: List[Dict[str, Any]] = []
            span_rules: List[Dict[str, Any]] = []
            for p in range(st["page"], end_page + 1):
                w, h = page_size(ctx, p)
                right = min(542.0, w - 30.0)
                floor = min(_ALEVEL_QP_FLOOR, h - 74.0)
                if p == st["page"]:
                    top, top_rule = max(_ALEVEL_QP_HEADER_BAND, st["y0"] - 12.0), "question_marker"
                else:
                    top, top_rule = _qp_continuation_top(ctx, p, header_band=_ALEVEL_QP_HEADER_BAND, right=right)
                if nxt is not None and nxt["page"] == p:
                    if nxt["y0"] <= _ALEVEL_QP_HEADER_BAND + 40.0 and p != st["page"]:
                        continue
                    bottom, bottom_rule = max(top + 2.0, nxt["y0"] - 10.0), "next_question_marker"
                else:
                    bottom, bottom_rule = _qp_page_span(ctx, p, top=top, floor=floor, right=right,
                                                        final_page=(p == end_page))
                rect = (30.0, top, right, bottom)
                if not _rect_has_ink(ctx, p, rect):
                    span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule,
                                       "dropped": "ink_free_page"})
                    continue
                seg_pages.append({"page_index": p, "rect": rect})
                span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule})
            if not seg_pages:
                continue
            qn = st["q"]
            segments.append({
                "id": f"{self._paper_label(ctx)}_Unknown_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1",
                "pages": seg_pages,
                "metadata": {
                    "source_pages": [p["page_index"] + 1 for p in seg_pages],
                    "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "sub_parts": st["parts"],
                    "geometry": {"page_spans": span_rules,
                                 "marker": "printed '0 N' with the part marker '. M' on the same line; "
                                           "each part block re-prints the number (A-level layout)",
                                 "floor": _ALEVEL_QP_FLOOR},
                },
            })
        return segments

    def _alevel_maths_ms_blocks(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Mark-scheme row blocks of an AQA A-LEVEL MATHEMATICS paper, or [] if this is not one.

        Five columns (``Q | Marking instructions | AO | Marks | Typical solution``), the header row
        repeated above every question's own table, the row labels ``1`` / ``5(a)`` / ``14(b)(i)`` in
        the Q column, and a bold ``Question N Total`` row closing each table. Questions are cut at
        their own header row: a crop runs from the header above its first label to the header above
        the next question's first label.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text = " ".join(str(pg.get("text") or "") for pg in pages)
        if not re.search(r"\bmark\s+scheme\b", text, re.I) or not _ALEVEL_LEVEL.search(text) \
                or "mathematic" not in text.lower() or re.search(r"\bgcse\b", text, re.I):
            return []
        headers: List[tuple[int, float]] = []
        labels: List[Dict[str, Any]] = []
        totals: List[Dict[str, Any]] = []
        for page in pages:
            pi = int(page.get("page_index", 0))
            rows: List[tuple[float, Dict[str, float]]] = []
            for text_, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                cell = re.sub(r"\s+", " ", text_).strip()
                if bold and any(cell.lower() == known.lower()
                                for header in _ALEVEL_MATHS_MS_HEADERS for known in header):
                    for row in rows:
                        if abs(row[0] - y0) <= _ALEVEL_MATHS_MS_HEADER_TOL:
                            row[1].setdefault(cell, x0)
                            break
                    else:
                        rows.append((y0, {cell: x0}))
                    continue
                # the closing "Question N Total" row of each table is bold and sits in the middle of
                # the page (x0 170.8), so it is identified before the label column's x band applies
                total = _ALEVEL_MATHS_MS_TOTAL.match(cell)
                if total and bold:
                    totals.append({"page": pi, "y0": y0, "q": int(total.group(1))})
                    continue
                if not (_ALEVEL_MATHS_MS_LABEL_SIZE[0] <= size <= _ALEVEL_MATHS_MS_LABEL_SIZE[1]):
                    continue
                if not (_ALEVEL_MATHS_MS_LABEL_X[0] <= x0 <= _ALEVEL_MATHS_MS_LABEL_X[1]):
                    continue
                m = _ALEVEL_MATHS_MS_LABEL.match(cell)
                if m is None:
                    continue
                labels.append({"page": pi, "y0": y0, "x0": x0, "label": cell, "bold": bool(bold),
                               "q": int(m.group(1)),
                               "parts": re.findall(r"\(([a-z]+)\)", m.group(2) or "")})
            for y0, cells in rows:
                lowered = {k.lower() for k in cells}
                if any({c.lower() for c in header} <= lowered for header in _ALEVEL_MATHS_MS_HEADERS):
                    headers.append((pi, float(y0)))
        headers.sort()
        if not headers or not labels:
            return []
        labels.sort(key=lambda d: (d["page"], d["y0"]))
        groups: List[Dict[str, Any]] = []
        for lab in labels:
            if groups and groups[-1]["q"] == lab["q"]:
                groups[-1]["labels"].append(lab)
            else:
                groups.append({"q": lab["q"], "labels": [lab]})
        order = [g["q"] for g in groups]
        if order != sorted(order) or sorted(set(order)) != list(range(1, max(order) + 1)):
            print("    [aqa-alevel-maths] mark-scheme rows are not a clean 1..N run; not an A-level maths MS")
            return []
        count = max(order)
        if not (_ALEVEL_MATHS_MIN_QUESTIONS <= count <= _ALEVEL_MATHS_MAX_QUESTIONS):
            return []
        total_qs = sorted({t["q"] for t in totals})
        if total_qs != list(range(1, count + 1)):
            print(f"    [aqa-alevel-maths] {len(total_qs)} 'Question N Total' rows for {count} questions; "
                  f"not an A-level maths MS")
            return []
        for grp in groups:
            first = grp["labels"][0]
            above = [h for h in headers if (h[0], h[1]) <= (first["page"], first["y0"] - 0.5)]
            if not above:
                return []
            grp["header"] = above[-1]
            grp["parts"] = [lab["label"] for lab in grp["labels"]]
            grp["total"] = next(t for t in totals if t["q"] == grp["q"])
        return groups

    def _segment_alevel_maths_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level mathematics mark scheme (see
        _alevel_maths_ms_blocks)."""

        groups = self._alevel_maths_ms_blocks(ctx)
        if not groups:
            return []
        full_code, paper_number = _aqa_paper_codes(self, ctx)
        total_pages = ctx.page_count or len(ctx.layout.get("pages") or [])
        segments: List[Dict[str, Any]] = []
        for idx, grp in enumerate(groups):
            nxt = groups[idx + 1] if idx + 1 < len(groups) else None
            start = grp["header"]
            end_page = nxt["header"][0] if nxt is not None else total_pages - 1
            pages: List[Dict[str, Any]] = []
            ms_rules: List[Dict[str, Any]] = []
            for p in range(start[0], end_page + 1):
                w, h = page_size(ctx, p)
                furn_top, furn_bottom, note = _ms_furniture_bounds(ctx, p)
                page_top = furn_top if furn_top is not None else _MS_PAGE_TOP
                page_bottom = furn_bottom if furn_bottom is not None else h - 46.0
                page_bottom, snapped = _ms_snap_below_content(ctx, p, page_bottom)
                if snapped:
                    note["bottom_snapped_below_content"] = True
                top = max(page_top, start[1] - _MS_ROW_PAD) if p == start[0] else page_top
                if nxt is not None and nxt["header"][0] == p:
                    if nxt["header"][1] <= page_top + 6.0 and p != start[0]:
                        continue
                    bottom = max(top + 2.0, nxt["header"][1] - _MS_ROW_PAD)
                    rule = "next_question_header"
                else:
                    bottom = page_bottom
                    rule = "page_box"
                if p != end_page or nxt is None:
                    ink_bottom = max((by1 for bx0, by0, bx1, by1 in _page_ink_boxes(ctx, p)
                                      if bx0 < w - 30.0 and bx1 > 30.0 and by0 >= top - 0.5
                                      and by1 <= bottom + 0.5), default=None)
                    if ink_bottom is not None and ink_bottom + _CUT_PAD_BELOW_CONTENT < bottom:
                        bottom = max(top + 2.0, ink_bottom + _CUT_PAD_BELOW_CONTENT)
                        rule = f"{rule}+content_trim"
                rect = (30.0, top, w - 30.0, max(top + 2.0, bottom))
                if not _rect_has_ink(ctx, p, rect):
                    note["dropped"] = "ink_free_page"
                    ms_rules.append({"page": p + 1, **note, "top": round(top, 1),
                                     "bottom": round(bottom, 1), "bottom_rule": rule})
                    continue
                ms_rules.append({"page": p + 1, **note, "top": round(top, 1), "bottom": round(bottom, 1),
                                 "bottom_rule": rule, "header_y": round(start[1], 1) if p == start[0] else None})
                pages.append({"page_index": p, "rect": rect})
            if not pages:
                continue
            qn = grp["q"]
            segments.append({
                "id": f"{paper_number or full_code or 'AQA'}_Unknown_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": paper_number or full_code,
                "pages": pages,
                "sub_parts": grp["parts"],
                "metadata": {
                    "document_type": "MS",
                    "paper_code": full_code,
                    "source_pages": [p["page_index"] + 1 for p in pages],
                    "sub_parts": grp["parts"],
                    "sub_part_count": len(grp["labels"]),
                    "layout_archetype": LayoutArchetype.AQA_MS_SUB_PART_TABLE.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "ms_geometry": (
                        "question block starts at the repeated 'Q Marking instructions AO Marks Typical "
                        "solution' header row above its first labelled row and ends above the next "
                        "question's header row; pages bounded by the running header and the footer rule"
                    ),
                    "page_furniture": ms_rules,
                },
            })
        return segments

    def _alevel_ms_blocks(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Mark-scheme row blocks of an AQA A-LEVEL paper, or [] if this is not one.

        The A-level mark scheme is a wide table again: the header row ``Question | Marking
        Guidance | Mark | Comments`` is repeated at the top of every page AND before each new row
        group on the same page, and each part is its own row labelled ``01.1`` (bold, x0 70.7).
        Questions are cut at part boundaries; the crop for a question runs from the header row
        above its first part to the header row above the next question's first part.
        """

        pages = (ctx.layout or {}).get("pages") or []
        text = " ".join(str(pg.get("text") or "") for pg in pages)
        if not re.search(r"\bmark\s+scheme\b", text, re.I) or not _ALEVEL_LEVEL.search(text) \
                or re.search(r"\bgcse\b", text, re.I):
            return []
        headers: List[tuple[int, float]] = []
        label_spans: List[Dict[str, Any]] = []
        question_col: List[tuple[int, float]] = []      # (page, x0) of each printed "Question" header cell
        #: pages whose table is the multiple-choice key table (``Question | Key | Answer``, 7408/1 and
        #: 7408/2 Section B): its row labels run to two digits but print as ONE when the question number
        #: is a single digit (7408/2 page 29 prints ``8`` and ``9`` at x 88.4 where ``10`` sits at 85.4),
        #: so on those pages a bare single digit IS a row label
        key_header_pages: set[int] = set()
        for page in pages:
            pi = int(page.get("page_index", 0))
            rows: List[tuple[float, Dict[str, float]]] = []
            for text_, x0, y0, _y1, size, bold in _page_text_spans(ctx, pi):
                cell = re.sub(r"\s+", " ", text_).strip()
                if bold and any(cell.lower() == known.lower() for known in _ALEVEL_MS_HEADER_ANY):
                    for row in rows:
                        if abs(row[0] - y0) <= _ALEVEL_MS_HEADER_TOL:
                            row[1].setdefault(cell, x0)
                            break
                    else:
                        rows.append((y0, {cell: x0}))
                    continue
                if not (_ALEVEL_MS_LABEL_SIZE[0] <= size <= _ALEVEL_MS_LABEL_SIZE[1]):
                    continue
                m = _ALEVEL_MS_LABEL.match(cell)
                if m is None:
                    continue
                label_spans.append({"page": pi, "y0": y0, "x0": x0, "label": cell, "bold": bool(bold),
                                    "q": int(m.group(1)),
                                    "part": int(m.group(2)) if m.group(2) else None})
            for y0, cells in rows:
                lowered = {k.lower() for k in cells}
                if any({c.lower() for c in header} <= lowered for header in _ALEVEL_MS_HEADERS):
                    headers.append((pi, float(y0)))
                    if "key" in lowered:
                        key_header_pages.add(pi)
                    for name, qx in cells.items():
                        if name.lower() == "question":
                            question_col.append((pi, float(qx)))
        headers.sort()
        if not headers or not label_spans:
            return []

        def _label_bands(page_index: int, style: str) -> List[tuple[float, float]]:
            """Where a row label can sit, from the page's own printed Question column.

            AQA re-draws the table per row group and the Question column moves with it. Measured on
            the three 7405 mark schemes: the label sits right under its header cell (7405/1: header
            x0 46.7, label x0 46.7), 13.0 pt right of it (7405/2: 49.6 / 62.6) or 17.3 pt right of it
            (7405/3 Section B: 49.0 / 66.3) -- and a mark scheme's data cells are full of values that
            look exactly like a label, so the band is never a document-wide constant. Three styles are
            tried in order and the first one that yields a clean 1..N run wins: the leftmost candidate
            column, the header-anchored band, then a wide band.
            """

            here = [x for pg, x in question_col if pg == page_index]
            if not here:
                # a continuation page prints no header of its own: the table simply runs on, so the
                # column is the last one AQA printed above it
                earlier = [pg for pg, _x in question_col if pg < page_index]
                if not earlier:
                    return []
                qx = min(x for pg, x in question_col if pg == max(earlier))
            else:
                qx = min(here)
            if style == "modal":
                # the label column of THIS page's table: the x where most label-shaped spans sit
                near = {}
                for lb in label_spans:
                    if lb["page"] != page_index or not (qx - 6.0 <= lb["x0"] <= qx + 30.0):
                        continue
                    near.setdefault(round(lb["x0"] / 2.0) * 2.0, []).append(lb)
                if not near:
                    return []
                col = max(near.items(), key=lambda kv: (len(kv[1]), -kv[0]))[0]
                return [(col - 2.5, col + 2.5)]
            if style == "leftmost":
                near = [lb["x0"] for lb in label_spans
                        if lb["page"] == page_index and qx - 6.0 <= lb["x0"] <= qx + 30.0]
                if not near:
                    return []
                x0 = min(near)
                return [(x0 - 2.0, x0 + 6.0)]
            if style == "header":
                return [(qx - 5.0, qx + 14.0)]
            return [(qx - 5.0, qx + 30.0)]

        def _is_label(lb: Dict[str, Any], strict: bool) -> bool:
            """A row label is ``NN.M``/``N.M`` or a bare two-digit question (``07``).

            A bare one-digit span in the Question column is a Mark cell that moved with the table
            (7405/3 prints ``1`` under a question row), never a row label -- accepted only in the
            loose pass, which exists for a scheme that numbers a whole question with one digit. The
            one place it IS a label is a multiple-choice key table, whose question numbers run past
            nine but print in one digit below ten (7408/2 ``8``/``9``).
            """

            if lb["part"] is not None or len(lb["label"]) == 2:
                return True
            if not strict:
                return True
            return len(lb["label"]) == 1 and lb["label"].isdigit() and lb["page"] in key_header_pages

        min_questions = (_ALEVEL_PAPER3_MIN_QUESTIONS if _ALEVEL_PAPER3_EVIDENCE.search(text)
                         else _ALEVEL_MIN_QUESTIONS)

        def _group(labels: List[Dict[str, Any]]) -> Optional[List[Dict[str, Any]]]:
            for lab in labels:
                above = [hb for hb in headers if (hb[0], hb[1]) <= (lab["page"], lab["y0"])]
                lab["header"] = above[-1] if above else (lab["page"], _ALEVEL_QP_HEADER_BAND)
            groups: List[Dict[str, Any]] = []
            for lab in labels:
                if groups and groups[-1]["q"] == lab["q"]:
                    groups[-1]["labels"].append(lab)
                    continue
                groups.append({"q": lab["q"], "labels": [lab]})
            nums = [g["q"] for g in groups]
            if nums != sorted(nums) or sorted(set(nums)) != list(range(1, max(nums) + 1)):
                return None
            count = max(nums)
            if count > _ALEVEL_MAX_QUESTIONS:
                # an MCQ mark scheme prints one row per question, so more questions than the
                # structured-paper ceiling is only accepted when most rows carry no part number
                bare = sum(1 for g in groups if all(lb["part"] is None for lb in g["labels"]))
                if not (bare * 2 >= len(groups) and count <= _ALEVEL_MCQ_MAX_QUESTIONS):
                    return None
                print(f"    [aqa-alevel] {count} mark-scheme questions, {bare} of them single-row "
                      f"(multiple-choice section): A-level MCQ mark scheme")
            elif count < min_questions:
                return None
            return groups

        first_table_page = min(pg for pg, _y in headers)
        label_spans = [lb for lb in label_spans if lb["page"] >= first_table_page]
        groups: Optional[List[Dict[str, Any]]] = None
        # biology prints its row labels bold (7402: bold at x0 70.7); chemistry prints them in
        # regular weight (7405: x0 46.7). Try the stricter reading first, then without the bold
        # requirement, so neither subject can mis-read the other and each keeps its own path.
        for require_bold in (True, False):
          for strict in (True, False):
            for style in ("modal", "leftmost", "header", "wide"):
                candidates = sorted([lb for lb in label_spans
                                     if (lb["bold"] or not require_bold) and _is_label(lb, strict)],
                                    key=lambda d: (d["page"], d["y0"]))
                candidates = [lb for lb in candidates
                              if any(lo <= lb["x0"] <= hi
                                     for lo, hi in _label_bands(lb["page"], style))]
                if not candidates:
                    continue
                groups = _group(candidates)
                if groups:
                    break
            if groups:
                break
          if groups:
            break
        if not groups:
            print("    [aqa-alevel] mark scheme rows are not a clean 1..N run; not an A-level MS")
            return []
        for grp in groups:                       # headers first: a row's bounds need its neighbours'
            grp["first"] = grp["labels"][0]      # header, which is only known once every group has one
            grp["start_header"] = grp["labels"][0]["header"]
            grp["parts"] = [lab["label"] for lab in grp["labels"]]
        for idx, grp in enumerate(groups):
            first = grp["labels"][0]
            last = grp["labels"][-1]
            hdr = grp["start_header"]
            # A block that prints ONE header for many questions (7405/3 Section B: 30 single-row
            # multiple-choice questions under one header, running over three pages) cannot be cut at
            # headers -- every row shares the same one, and cutting at it collapses the crop to the
            # 2 pt floor. Such a row is cut at its own table separators instead, so each question gets
            # its own row. Measured: the separators bracket the label (07 at y 136.0 between 116.8
            # and 170.4).
            shared = ((idx and groups[idx - 1]["start_header"] == hdr)
                      or (idx + 1 < len(groups) and groups[idx + 1]["start_header"] == hdr))
            top = max([y for y in _ms_row_rules(ctx, first["page"]) if y <= first["y0"] - 0.5],
                      default=None)
            bottom = min([y for y in _ms_row_rules(ctx, last["page"]) if y >= last["y0"] + 0.5],
                         default=None)
            grp["row_bounded"] = bool(shared and first["page"] == last["page"]
                                      and top is not None and bottom is not None)
            if grp["row_bounded"]:
                # the separators are the row's own borders and the crop starts below them, so the
                # contract's white top band stays white (0.5 pt of border ink is 2 px at 300 dpi)
                grp["start_point"] = (first["page"], top + 2.0)
                grp["end_point"] = (last["page"], bottom)
            else:
                grp["start_point"] = None
                grp["end_point"] = None
        return groups

    def _segment_alevel_mark_scheme(self, ctx: DocumentContext,
                                    groups: Optional[List[Dict[str, Any]]] = None,
                                    id_prefix: str = "") -> List[Dict[str, Any]]:
        """One crop per question of an AQA A-level mark scheme (see _alevel_ms_blocks).

        ``groups`` lets a subject whose mark scheme the science row finder cannot express hand in its
        own blocks (A-level Computer Science 7517 does: see _cs_ms_blocks); the crop loop, the page
        furniture and the ids are the same for both.
        """

        groups = groups if groups is not None else self._alevel_ms_blocks(ctx)
        if not groups:
            return []
        full_code, paper_number = _aqa_paper_codes(self, ctx)
        total_pages = ctx.page_count or len(ctx.layout.get("pages") or [])
        segments: List[Dict[str, Any]] = []
        for idx, grp in enumerate(groups):
            nxt = groups[idx + 1] if idx + 1 < len(groups) else None
            start = grp.get("start_point") or grp["start_header"]
            end_y = None
            if grp.get("end_point"):
                end_page, end_y = grp["end_point"]
            else:
                end_page = nxt["start_header"][0] if nxt is not None else total_pages - 1
                if grp.get("stop_page") is not None:
                    # a scheme whose last block runs into material that is NOT the block (7517/1's
                    # five-language appendix) caps it (see _cs_ms_blocks)
                    end_page = min(end_page, int(grp["stop_page"]))
            pages: List[Dict[str, Any]] = []
            ms_rules: List[Dict[str, Any]] = []
            for p in range(start[0], end_page + 1):
                w, h = page_size(ctx, p)
                furn_top, furn_bottom, note = _ms_furniture_bounds(ctx, p)
                page_top = furn_top if furn_top is not None else _MS_PAGE_TOP
                page_bottom = furn_bottom if furn_bottom is not None else h - 46.0
                page_bottom, snapped = _ms_snap_below_content(ctx, p, page_bottom)
                if snapped:
                    note["bottom_snapped_below_content"] = True
                top = max(page_top, start[1] - _MS_ROW_PAD) if p == start[0] else page_top
                if end_y is not None and p == end_page:
                    bottom = max(top + 2.0, end_y)
                    rule = "own_row_separator"
                elif nxt is not None and nxt["start_header"][0] == p:
                    if nxt["start_header"][1] <= page_top + 6.0 and p != start[0]:
                        continue
                    bottom = max(top + 2.0, nxt["start_header"][1] - _MS_ROW_PAD)
                    rule = "next_question_header"
                else:
                    bottom = page_bottom
                    rule = "page_box"
                if p != end_page or nxt is None:
                    ink_bottom = max((by1 for bx0, by0, bx1, by1 in _page_ink_boxes(ctx, p)
                                      if bx0 < w - 30.0 and bx1 > 30.0 and by0 >= top - 0.5
                                      and by1 <= bottom + 0.5), default=None)
                    if ink_bottom is not None and ink_bottom + _CUT_PAD_BELOW_CONTENT < bottom:
                        bottom = max(top + 2.0, ink_bottom + _CUT_PAD_BELOW_CONTENT)
                        rule = f"{rule}+content_trim"
                rect = (30.0, top, w - 30.0, max(top + 2.0, bottom))
                if not _rect_has_ink(ctx, p, rect):
                    note["dropped"] = "ink_free_page"
                    ms_rules.append({"page": p + 1, **note, "top": round(top, 1),
                                     "bottom": round(bottom, 1), "bottom_rule": rule})
                    continue
                ms_rules.append({"page": p + 1, **note, "top": round(top, 1), "bottom": round(bottom, 1),
                                 "bottom_rule": rule, "header_y": round(start[1], 1) if p == start[0] else None})
                pages.append({"page_index": p, "rect": rect})
            if not pages:
                continue
            qn = grp["q"]
            segments.append({
                "id": f"{id_prefix}{paper_number or full_code or 'AQA'}_Unknown_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": paper_number or full_code,
                "pages": pages,
                "sub_parts": grp["parts"],
                "metadata": {
                    "document_type": "MS",
                    "paper_code": full_code,
                    "source_pages": [p["page_index"] + 1 for p in pages],
                    "sub_parts": grp["parts"],
                    "sub_part_count": len(grp["labels"]),
                    "layout_archetype": LayoutArchetype.AQA_MS_SUB_PART_TABLE.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "ms_geometry": (
                        "question block starts at the repeated 'Question Marking Guidance Mark Comments' "
                        "header row above its first labelled row (01.1) and ends above the header row of "
                        "the next question; pages bounded by the running header and the footer rule"
                    ),
                    "page_furniture": ms_rules,
                },
            })
        return segments

    def _paper_label(self, ctx: DocumentContext) -> str:
        full_code, _paper = _aqa_paper_codes(self, ctx)
        return full_code or "AQA"

    def segment(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        # English Language first: its paper is the one layout whose question markers are unique
        # (see _language_marker_starts). The page-based path below keys on phrases that appear in
        # this paper's own printed title ("Explorations in creative reading and writing" contains
        # "explore"), so it must not get first refusal on a Language paper.
        # AQA A-level English Literature first: it prints the same "0 N" pair as the science papers
        # but ONCE per question on the set text's own line, and its paper is a choice paper whose
        # sections are the only structure (see _literature_qp_markers).
        literature = self._segment_literature_questions(ctx)
        if literature:
            return literature
        language = self._segment_language_markers(ctx)
        if language:
            return language
        # AQA A-level Computer Science next: its question number is the same "0 N" pair but printed
        # ONCE per question (an on-screen paper whose parts carry their own ". M" lines), and AQA
        # omits the questions the program answers, so its runs are never 1..N (see _cs_qp_markers).
        cs = self._segment_cs_questions(ctx)
        if cs:
            return cs
        # AQA A-level second: its markers are the printed "0 N" + ". M" pair and a GCSE science
        # paper prints the same pair, so the level word on the cover decides (see _alevel_qp_markers).
        alevel = self._segment_alevel_questions(ctx)
        if alevel:
            return alevel
        # AQA A-level Mathematics third: its markers are bare margin numbers with the question's
        # sentence beside them, a shape the science path above never matches (see
        # _alevel_maths_qp_markers).
        alevel_maths = self._segment_alevel_maths_questions(ctx)
        if alevel_maths:
            return alevel_maths
        # GCSE Mathematics third: a maths paper's markers are bare bold numbers, so it has to be
        # claimed before the page-phrase paths below (see _maths_marker_starts).
        maths = self._segment_maths_questions(ctx)
        if maths:
            return maths
        texts = page_texts(ctx)
        segments: List[Dict[str, Any]] = []
        qn = 1
        for page_index, text in enumerate(texts):
            low = text.lower()
            if page_index < 3:
                continue
            if "there are no questions printed on this page" in low:
                continue
            if "question" in low and "page" in low and "section a" in low and "section b" in low:
                continue
            if not ("read the following extract" in low or "answer the question" in low or "explore" in low):
                continue
            w, h = page_size(ctx, page_index)
            # Bottom furniture measured on AQA-87021-SQP-V1 pages 3-15: the answer
            # box rule sits at 778.1 and the AQA footer row (paper code / page
            # number) starts at 789.1, so the old h-42.0 = 799.9 sliced that
            # footer on every page. h-59.0 = 782.9 is inside the empty window:
            # 4.4pt below the box rule, 6.2pt above the footer.
            page_floor = h - 59.0
            # MAIN 2 (2026-09-23): the standalone EITHER / OR option markers, the
            # "Section A: ..." title and the "Answer one question from this section"
            # rubric are answer-one-of-N furniture, not question content. The rect
            # starts at the first line that is NOT furniture (the set-text title),
            # below the furniture printed above it. Content-keyed, never positional.
            lines = _page_lines(ctx, page_index)
            body = [ln for ln in lines if ln[2] >= 40.0 and ln[4] <= page_floor and _norm(ln[0])]
            furniture = [ln for ln in body if _is_sqp_furniture(ln[0]) or _TURN_OVER.match(_norm(ln[0]))]
            content = [ln for ln in body if not (_is_sqp_furniture(ln[0]) or _TURN_OVER.match(_norm(ln[0])))]
            if content:
                first = content[0]
                above = [f[4] for f in furniture if f[4] <= first[2] + 1.0]
                start_y = first[2] - _CUT_PAD_ABOVE_FURNITURE
                if above:
                    # The marker and the set-text title are adjacent lines (OR ends at
                    # 80.46, "Romeo and Juliet" starts at 80.84 on the specimen): the cut
                    # goes in the gap between them, never into either line's box.
                    furn_bottom = max(above)
                    gap_top, gap_bottom = furn_bottom, first[2]
                    if gap_bottom - gap_top >= 0.6:
                        start_y = min(gap_bottom - 0.3, max(start_y, gap_top + 0.3))
                    else:
                        start_y = (gap_top + gap_bottom) / 2.0
                start_rule = "first_non_furniture_line"
            else:
                start_y = 70.0
                start_rule = "no_text_fallback_70pt"
            start_y = max(0.0, start_y)
            # FIX 5 (2026-09-23): the question ends at its last printed line (marks /
            # AO tag); the empty answer box below it is not content. Content-aware
            # bottom = last text line + 12 pt, never below the measured page floor.
            trailing = [ln[4] for ln in content if ln[2] > start_y]
            if trailing:
                last_y1 = max(trailing)
                bottom_y = min(page_floor, last_y1 + _CUT_PAD_BELOW_CONTENT)
                # never pad into the next printed line ("Turn over for Section B" sits
                # 0.2 pt under the marks line on the specimen's page 9)
                below = [ln[2] for ln in lines if ln[2] >= last_y1 - 0.5 and ln[2] < bottom_y + 0.5 and _norm(ln[0])]
                if below:
                    next_y0 = min(below)
                    if next_y0 - last_y1 >= 0.6:
                        bottom_y = max(last_y1 + 0.3, min(bottom_y, next_y0 - 0.3))
                    else:
                        bottom_y = (last_y1 + next_y0) / 2.0
                bottom_rule = "last_text_line"
            else:
                bottom_y = page_floor
                bottom_rule = "page_floor_no_text"
            rect = (42.0, start_y, w - 42.0, bottom_y)
            excluded = [_norm(f[0]) for f in furniture if f[4] <= start_y + 1.0]
            section = "A" if page_index <= 8 else "B"
            segments.append({
                "id": f"1_Specimen_2014_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1",
                "pages": [{"page_index": page_index, "rect": rect}],
                "metadata": {"section": section, "source_page": page_index + 1, "layout_archetype": LayoutArchetype.AQA_ALT_EXTRACT_ONE_PAGE.value, "crop_plan": crop_plan(self.BOARD_ID, ctx), "naming_decision": "AQA contents-table alternatives mapped to Q1..Qn by printed order",
                             "geometry": {"start_rule": start_rule, "bottom_rule": bottom_rule, "furniture_excluded": excluded}},
            })
            qn += 1
        if segments:
            return segments
        return self._segment_numbered_boxed(ctx)

    def _segment_numbered_boxed(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """AQA science/maths boxed-answer papers.

        Top-level question starts are the left-margin two-token form ``0 1`` / ``1 0``
        with NO same-baseline ``. n`` subpart marker. Continuation pages often start
        at the same y with ``0 1 . 3`` etc.; those are deliberately rejected.
        """
        pages = (ctx.layout or {}).get("pages") or []
        starts: List[tuple[int, int, float]] = []
        for page in pages:
            pi = int(page.get("page_index", 0))
            if pi == 0:
                continue
            lines = page.get("lines") or []
            for idx, line in enumerate(lines):
                txt = str(line.get("text", "")).strip()
                if not re.fullmatch(r"\d\s+\d", txt):
                    continue
                bbox = line.get("bbox") or []
                if len(bbox) != 4:
                    continue
                x0, y0, x1, y1 = map(float, bbox)
                if not (40 <= x0 <= 70 and 45 <= y0 <= 120):
                    continue
                # Reject subquestion markers where the next line on the same
                # baseline is '. 1', '. 2', ...
                same_base_dot = False
                for nxt in lines[idx + 1:idx + 4]:
                    nb = nxt.get("bbox") or []
                    nt = str(nxt.get("text", "")).strip()
                    if len(nb) == 4 and abs(float(nb[1]) - y0) < 3 and re.fullmatch(r"\.\s*\d+", nt):
                        same_base_dot = True
                        break
                if same_base_dot:
                    continue
                qn = int(txt.replace(" ", ""))
                starts.append((qn, pi, y0))
                break
        starts.sort(key=lambda t: (t[1], t[2]))
        segments: List[Dict[str, Any]] = []
        for idx, (qn, start_page, y0) in enumerate(starts):
            end_page = starts[idx + 1][1] - 1 if idx + 1 < len(starts) else len(pages) - 1
            seg_pages = []
            span_rules: List[Dict[str, Any]] = []
            content_pages = [p for p in range(start_page, end_page + 1) if _page_has_question_content(pages[p])]
            for p in content_pages:
                w, h = page_size(ctx, p)
                right = min(542.0, w - 30.0)
                # Exclude AQA right-margin "Do not write outside the box" ink.
                if p == start_page:
                    top, top_rule = max(52.0, y0 - 10.0), "question_marker"
                else:
                    # FIX 3: continuation pages start at their first content ink below
                    # the header band, not at the band itself.
                    top, top_rule = _qp_continuation_top(ctx, p, header_band=54.0, right=right)
                # Bottom furniture measured on AQA-84621H-QP-JUN23 across all 32
                # question pages (150 dpi ink bands, 2026-09-21): the answer-space
                # rules end at 765.6, "Turn over" runs 773.8-781.9 and the barcode
                # bars + label + "IB/M/Jun23/8462/1H" footer run 790.1-823.7. The
                # old h-46.0 = 795.9 landed inside the barcode band and sliced it
                # in half - the same defect class as the IB question paper's
                # barcode. h-72.0 = 769.9 sits in the empty window: 4.3pt below
                # the last answer rule, 3.9pt above "Turn over".
                # FIX 3 (2026-09-23): a non-final page ends above its printed
                # "Question N continues on the next page" line (the line itself is
                # excluded) or, without one, 12 pt below its last content line -
                # never at the full page box, which dragged the blank answer space
                # and the page margins into the middle of the assembled crop.
                bottom, bottom_rule = _qp_page_span(ctx, p, top=top, floor=h - 72.0, right=right,
                                                    final_page=(p == content_pages[-1]))
                seg_pages.append({"page_index": p, "rect": (30.0, top, right, bottom)})
                span_rules.append({"page": p + 1, "top": top_rule, "bottom": bottom_rule})
            segments.append({
                "id": f"1H_Unknown_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": "1H",
                "pages": seg_pages,
                "metadata": {"source_pages": [p + 1 for p in range(start_page, end_page + 1)], "layout_archetype": LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED.value, "crop_plan": crop_plan(self.BOARD_ID, ctx),
                             "geometry": {"page_spans": span_rules}},
            })
        return segments


# --------------------------------------------------------------------------- #
# Mark-scheme segmentation (A3)
# --------------------------------------------------------------------------- #
# An AQA mark scheme is not a question paper: it is ONE bordered table spanning the
# paper, with one row per sub-part ("01.1" .. "10.2") and the sub-part number in a
# narrow left column. So a sub-part number is a ROW HEADER, not a question start:
# a question region is the run of consecutive rows that share its number.
#
# Four gates separate a real row from the other "NN.N" text an AQA mark scheme
# contains. Each was measured on the real 8462/1H June 2023 mark scheme (30 pages,
# 46 question rows) before it was written down:
#
#   1. pattern          ->  62 candidates (too many)
#   2. + page carries the marks-table header  ->  49  (drops the 13 front-matter
#                          "2.1".."3.9" numbered-paragraph headings on pages 3-5;
#                          those pages have no Question/Answers/Mark header)
#   3. + leftmost ink of its row              ->  47  (drops 2 of the 3 numbers
#                          sitting inside calculation working on page 18)
#   4. + left-column cluster                  ->  46  (drops the last one)
#
# The result is exactly questions 01-10, sub-parts numbered 1..N with no gaps, and
#
#   Q1..Q10 = 5,6,2,5,7,3,5,5,6,2
#
# which matches the companion question paper's own sub-part markers 10/10.
_MS_ROW = re.compile(r"^(\d{1,2})\.(\d)$")
#: Combined-science papers (8464/B, /C, /P) also print WHOLE-QUESTION rows -- a question
#: with no sub-parts is numbered "02" / "05" in the same left column, with no ".N".
#: Measured on 8464/B/1H June 2023 MS: Q2 and Q5 are single 6-mark rows printed as bare
#: "02"/"05" at the same x=67.3 as the 32 sub-part rows, so the row gates (header page,
#: leftmost ink, column cluster) already separate them from page numbers (x~300, outside
#: the cluster) and from answer-column working. Without this pattern the row table has a
#: gap at Q2/Q5, `_ms_group_rows` refuses the document and the batch falls back to a
#: single whole-document crop (which exceeds the WebP dimension limit).
_MS_WHOLE_ROW = re.compile(r"^(\d{1,2})$")
_MS_TABLE_HEADERS = ("Question", "Answers", "Mark")
#: AQA prints every sub-part number at one x for a whole paper -- measured 67.2-67.4
#: on 8462/1H (0.2pt of jitter) -- while numbers inside answer-column working sit at
#: 142.0/201.3/208.5. Clustering the left column removes them without hardcoding the
#: column widths, which differ per paper.
_MS_COLUMN_TOLERANCE = 3.0
#: Gate 4 accepts every row number within this many points of the modal column.
#: Measured on 8463/1H June 2023 MS: Q2-Q9 rows print at x=61.6 but Q1's five rows
#: at x=68.7 (7.1pt away, same Question column -- the first question's table starts
#: slightly further in), while numbers inside the answer column sit at 142.0/195.5.
#: A single-cluster gate therefore discarded all of Q1 and the whole mark scheme was
#: refused (0 segments -> the batch fell back to page-level crops). 15pt keeps the
#: number column whatever the per-question indent and still rejects answer-column
#: working by a wide margin; gate 3 (leftmost ink) remains the primary guard.
_MS_COLUMN_BAND = 15.0
#: A row separator sits ~6.5pt above the sub-part text (measured: 01.1 text top
#: 154.59, rule above it 148.2-148.6). Starting 7pt above the text therefore lands
#: just inside the separator and can never clip the row it is naming, nor bleed into
#: the row above it.
_MS_ROW_PAD = 7.0
#: Page box used for continuation pages, matching the verified AQA QP convention
#: (adapters/aqa/adapter.py::_segment_numbered_boxed).
_MS_PAGE_TOP = 54.0


def _aqa_paper_codes(adapter: "Adapter", ctx: DocumentContext) -> tuple[str, str]:
    """Return ``(full_code, native_paper_number)`` from the adapter's own evidence."""
    full = native = ""
    for ev in adapter.identify_component(ctx):
        if ev.field == "component" and ev.value:
            full = full or str(ev.value)
        elif ev.field == "paper_number" and ev.value:
            native = native or str(ev.value)
    return full, native


def _ms_rows(ctx: DocumentContext) -> List[Dict[str, Any]]:
    """Return the genuine sub-part rows of an AQA mark scheme, in document order.

    Applies the four gates documented above. Deliberately text-and-geometry only:
    no drawn-border detection, because the same rule has to hold for a rasterised
    mark scheme, where there are no vector rules to find.
    """
    pages = (ctx.layout or {}).get("pages") or []
    by_index: Dict[int, Dict[str, Any]] = {}
    for pos, page in enumerate(pages):
        by_index[int(page.get("page_index", pos))] = page

    candidates: List[Dict[str, Any]] = []
    for page_index in sorted(by_index):
        page = by_index[page_index]
        lines = page.get("lines") or []
        tokens = {str(line.get("text", "")).strip() for line in lines}
        # Gate 2: only a page carrying the marks table can carry a question row.
        if not all(header in tokens for header in _MS_TABLE_HEADERS):
            continue
        for line in lines:
            # Gate 1: the row header itself.
            text = re.sub(r"\s+", "", str(line.get("text", "")))
            match = _MS_ROW.match(text)
            whole = False
            if match:
                part = int(match.group(2))
            else:
                match = _MS_WHOLE_ROW.match(text)
                if not match:
                    continue
                whole, part = True, 1
            bbox = line.get("bbox") or []
            if len(bbox) != 4:
                continue
            x0, y0, x1, y1 = (float(v) for v in bbox)
            # Gate 3: the sub-part number is the leftmost ink of its row. Numbers
            # sitting inside answer-column working always have text beside them.
            for other in lines:
                if other is line:
                    continue
                obox = other.get("bbox") or []
                if len(obox) != 4:
                    continue
                if float(obox[3]) > y0 - 2.0 and float(obox[1]) < y1 + 2.0 and float(obox[0]) < x0 - 2.0:
                    break
            else:
                candidates.append({
                    "question": int(match.group(1)),
                    "part": part,
                    "whole": whole,
                    "label": text,
                    "page": page_index,
                    "x0": x0,
                    "y0": y0,
                })

    if not candidates:
        return []

    # Gate 4: cluster the left column. The row numbers all share one x; anything
    # else that survived the first three gates is an outlier.
    counts: Dict[float, int] = {}
    for row in candidates:
        key = round(row["x0"], 1)
        counts[key] = counts.get(key, 0) + 1
    modal = max(counts.items(), key=lambda kv: (kv[1], -kv[0]))[0]
    kept = [row for row in candidates if abs(row["x0"] - modal) <= _MS_COLUMN_BAND]
    kept.sort(key=lambda row: (row["page"], row["y0"]))
    return kept


def _ms_group_rows(rows: List[Dict[str, Any]]) -> Any:
    """Group consecutive rows into questions, or ``None`` when the table is not clean.

    A question number must appear as exactly one run of consecutive rows: AQA
    prints each question's rows together. A number that reappears later (or a
    sub-part that jumps) means the gates have picked up something that is not a
    row table, and a partial or duplicated question set is worse than none, so the
    caller is told to refuse rather than emit it.
    """
    groups: List[Dict[str, Any]] = []
    for row in rows:
        if groups and groups[-1]["question"] == row["question"]:
            groups[-1]["rows"].append(row)
        else:
            groups.append({"question": row["question"], "rows": [row]})

    seen: Dict[int, int] = {}
    for group in groups:
        seen[group["question"]] = seen.get(group["question"], 0) + 1
    if any(count > 1 for count in seen.values()):
        return None

    expected = sorted(seen)
    if expected != list(range(1, len(expected) + 1)):
        # A mark scheme numbered 1..N only; "0 1" .. "1 0" normalises to 1..10.
        return None

    for group in groups:
        parts = [row["part"] for row in group["rows"]]
        # A whole-question row ("02", no sub-part number) is its own one-row group;
        # it is the printed pattern for combined-science questions with no sub-parts.
        if all(row.get("whole") for row in group["rows"]):
            continue
        if parts != list(range(1, len(parts) + 1)):
            return None
    return groups
