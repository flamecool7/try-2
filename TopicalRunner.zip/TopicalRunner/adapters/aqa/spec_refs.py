#!/usr/bin/env python3
"""AQA's own mark-scheme specification references, read at run time and held against the classifier.

An AQA mark scheme prints, beside every marking row, the specification node that carries those marks
(the "AO / Spec. Ref." column). That is the **board's own statement** of what the question assesses --
stronger evidence than any keyword score, because it is not an inference at all. This module reads it
the way it is printed (coordinates and font, never a flat text regex: AQA splits a question marker
into glyph runs, prints question 10 as "1 0", and prints a bare page number bold in the same column a
whole-question row label uses) and compares it with the classifier's verdict:

* **agree**    -- the verdict is recorded as verified against the board's own reference
                  (``spec_ref_status="agree"`` + the reference block). The topic is not changed.
* **disagree** -- the row becomes ``REVIEW_REQUIRED`` with **both** topics on the record
                  (``classifier_topic`` and the ``spec_ref`` block). A conflict between the classifier
                  and the board is never shipped as fact, and never silently "resolved" either way.
* **unreadable / no reference** -- nothing is claimed: no annotation at all (``unchecked``).

The one direction that *does* change a topic is the case the A-level and Mathematics references already
established: the classifier returned ``UNKNOWN`` (or a topic the board's own column contradicts while
offering a single unambiguous winner) and the mark scheme names exactly one node -- then the board's
answer is adopted, with ``classifier_topic`` kept beside it and ``engine="aqa_spec_reference"`` on the
row. Ties are never adopted (the board itself says two nodes), only flagged for a human.

Nothing here invents a topic. `tools/aqa_verdict_table.py` (the dev-side adjudicator) imports these
readers, so there is exactly one parser for the printed table.
"""
from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

#: AQA prints sub-part rows as ``01.2`` and whole-question rows as a bare ``02``; both are rows.
QP_MARKER = re.compile(r"^(\d) (\d)$")
QP_SUBPART = re.compile(r"^\.\s*(\d+)$")
QP_BAND = re.compile(r"^\[(\d+) marks?\]$")
MS_ROW_RIGHT = re.compile(r"^(0\d|1\d)$")
MS_SUBPART_ROW = re.compile(r"^(0\d|1\d)\.(\d+)$")
MS_TOTAL_RE = re.compile(r"Total Question (\d+)")
REF_RE = re.compile(r"[4567]\.\d+(?:\.\d+)*")


def page_lines(path: Path) -> List[Tuple[int, float, float, str, float, bool]]:
    """Every non-empty line with (page, y, x, text, size, bold), in reading order."""
    import fitz

    doc = fitz.open(str(path))
    out: List[Tuple[int, float, float, str, float, bool]] = []
    for page in range(doc.page_count):
        for block in doc[page].get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                text = "".join(span["text"] for span in line["spans"]).strip()
                if not text or not line["spans"]:
                    continue
                span = line["spans"][0]
                x0, y0 = line["bbox"][0], line["bbox"][1]
                out.append((page, y0, x0, text, float(span["size"]),
                            "Bold" in span["font"]))
    return out


def qp_marks(path: Path) -> Dict[Tuple[int, int], int]:
    """Marks per (question, sub-part) from the question paper's own marker lines.

    Anchored, not guessed: a question marker is bold >=10.5 pt at x<70 printed as "0 2"; a sub-part
    is ". 4" in the 70-105 x-window (some are printed at 0.5 pt, so no size gate -- the window is
    what identifies them); a marks band is "[N marks]" at x>400.
    """
    marks: Dict[Tuple[int, int], int] = {}
    question, sub = 0, 0
    for _page, _y, x0, text, size, bold in page_lines(path):
        if bold and size >= 10.5 and x0 < 70 and (marker := QP_MARKER.match(text)):
            question, sub = int(marker.group(1) + marker.group(2)), 0
            continue
        if 70 <= x0 < 105 and (subpart := QP_SUBPART.match(text)):
            sub = int(subpart.group(1))
            continue
        if question and (band := QP_BAND.match(text)):
            marks[(question, sub)] = int(band.group(1))
    return marks


def ms_refs(path: Path) -> Tuple[Dict[Tuple[int, int], List[str]], Dict[int, int]]:
    """Spec refs per (question, sub-part), plus the scheme's own ``Total Question N`` rows."""
    refs: Dict[Tuple[int, int], List[str]] = {}
    totals: Dict[int, int] = {}
    lines = page_lines(path)
    # The marks value printed under "Total Question N" sits in the same right-hand column, in the
    # same bold 11 pt, as a whole-question row label -- it must be excluded before rows are read, or
    # every question worth >= 10 marks invents a question 10..18 in the table.
    value_lines: set = set()
    for i, (_p, _y, _x, text, _s, _b) in enumerate(lines):
        total = MS_TOTAL_RE.search(text)
        if not total:
            continue
        for j in range(i + 1, min(i + 5, len(lines))):
            if lines[j][3].strip().isdigit():
                totals[int(total.group(1))] = int(lines[j][3].strip())
                value_lines.add(j)
                break
    collected: Optional[Tuple[int, int]] = None
    for i, (_page, _y, x0, text, size, bold) in enumerate(lines):
        if i in value_lines:
            continue
        label = MS_SUBPART_ROW.match(text) if x0 < 100 else None
        whole = MS_ROW_RIGHT.match(text) if bold and size >= 10.5 else None
        if label or whole:
            match = label or whole
            collected = (int(match.group(1)), int(match.group(2) or 0) if label else 0)
            refs.setdefault(collected, [])
            continue
        if collected and REF_RE.fullmatch(text):
            refs[collected].append(text)
    return refs, totals


def major_lookup(profile: Dict[str, Any]):
    """Longest-prefix match of a printed spec ref against the profile's spec_tree."""
    spec2major = {node["spec"]: major for major, nodes in profile["spec_tree"].items() for node in nodes}
    ordered = sorted(spec2major, key=len, reverse=True)

    def major_of(ref: str) -> Optional[str]:
        for candidate in ordered:
            if ref == candidate or ref.startswith(candidate + ".") or candidate.startswith(ref + "."):
                return spec2major[candidate]
        return None

    return major_of


def official_questions(qp: Path, ms: Path, profile: Dict[str, Any]) -> Dict[str, Any]:
    """Per-question topic the mark scheme's own spec references name, with the weighting split.

    ``{}`` (a plain dict with no ``questions`` key) when the paper cannot be read or the profile has
    no spec tree -- the caller then claims nothing. Marks per row are split in proportion to the refs
    AQA printed, exactly as ``tools/aqa_verdict_table.py`` does, so a row citing one energy node and
    two particle nodes is weighted 1:2 rather than 50/50.
    """
    if not profile.get("spec_tree"):
        return {}
    marks = qp_marks(qp)
    refs, _totals = ms_refs(ms)
    if not marks and not refs:
        return {}
    major_of = major_lookup(profile)

    per_q: Dict[int, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
    q_marks: Dict[int, int] = defaultdict(int)
    for key in sorted(set(marks) | set(refs)):
        q, _sub = key
        q_marks[q] += marks.get(key, 0)
        rows = marks.get(key) or 1
        mapped = [m for m in (major_of(r) for r in refs.get(key, [])) if m]
        if not mapped:
            continue
        counts = {m: mapped.count(m) for m in set(mapped)}
        for major, n in counts.items():
            per_q[q][major] += rows * n / len(mapped)

    questions: Dict[int, Dict[str, Any]] = {}
    for q in sorted(q_marks):
        parts = sorted(per_q[q].items(), key=lambda kv: -kv[1])
        if not parts:
            continue
        # A tie means the top two carry the SAME marks (8462/1H Q4: 6 bonding / 6 energy). Without
        # the second check every question with a runner-up would report its own winner as a "tie".
        ties = (sorted(k for k, v in parts if v == parts[0][1])
                if len(parts) > 1 and parts[0][1] == parts[1][1] else [])
        questions[q] = {"topic": parts[0][0], "ties": ties,
                        "splits": {k: round(v, 4) for k, v in parts},
                        "marks": q_marks[q]}
    return {"questions": questions, "rows": len(marks), "qp_total": sum(marks.values())}


def profile_for_component(component: str) -> Dict[str, Any]:
    """The AQA subject profile for a component ("8462/1H" -> 8462), or ``{}`` when there is none."""
    code = re.search(r"\b(\d{4})\b", str(component or ""))
    if not code:
        return {}
    from adapters.aqa.classification import PROFILE_ROOT                      # noqa: PLC0415
    for cfg in sorted(PROFILE_ROOT.glob(f"*/*_{code.group(1)}/config.json")):
        try:
            import json
            return json.loads(cfg.read_text(encoding="utf-8"))
        except Exception:                                                      # noqa: BLE001
            return {}
    return {}


def annotate_topics(topics: List[Dict[str, Any]], *, qp_pdf: Path, ms_pdf: Optional[Path],
                    component: str = "", profile: Optional[Dict[str, Any]] = None) -> Dict[str, int]:
    """Hold the classifier's verdicts against the board's own printed references, in place.

    Returns counters for the run audit: ``{checked, agree, disagree, unchecked, adopted}``.
    Never raises: a paper whose table cannot be read simply records nothing.
    """
    counters = {"checked": 0, "agree": 0, "disagree": 0, "unchecked": 0, "adopted": 0}
    if not topics or ms_pdf is None or not Path(ms_pdf).is_file():
        return counters
    try:
        profile = profile if profile is not None else profile_for_component(component)
        table = official_questions(Path(qp_pdf), Path(ms_pdf), profile)
    except Exception:                                                          # noqa: BLE001
        return counters
    questions = table.get("questions") or {}
    if not questions:
        return counters
    # Coverage guard: the printed table has to cover nearly every question the classifier saw before
    # any of it is trusted enough to *adopt* or *flag*. A paper whose table half-extracted (an odd
    # layout, a scanned MS) is recorded as unchecked -- claiming nothing beats claiming wrongly.
    asked = [int(t.get("question_number") or 0) for t in topics if isinstance(t, dict)]
    asked = [q for q in asked if q]
    if not asked or len(questions) / len(asked) < 0.8:
        return counters
    source = f"mark scheme AO/Spec. Ref. column ({Path(ms_pdf).name})"
    for entry in topics:
        if not isinstance(entry, dict):
            continue
        row = questions.get(int(entry.get("question_number") or 0))
        if not row:
            counters["unchecked"] += 1
            continue
        counters["checked"] += 1
        winners = set(row.get("ties") or [row["topic"]])
        verdict = str(entry.get("topic") or "")
        accepted = winners | {str(v) for v in (entry.get("secondary") or [])}
        block = {"topic": row["topic"], "winners": sorted(winners), "ties": list(row.get("ties") or []),
                 "topics": row["splits"], "marks": row["marks"], "source": source}
        if verdict and verdict != "UNKNOWN" and verdict in accepted:
            entry["spec_ref_status"] = "agree"
            entry["spec_ref"] = block
            counters["agree"] += 1
            continue
        if not row.get("ties") and verdict != row["topic"]:
            # A single node the classifier did not name. The board's column is the authority the
            # A-level and Mathematics references already use, so it carries the routing -- but only
            # when it is unambiguous, and the classifier's verdict stays on the record.
            entry.setdefault("classifier_topic", verdict or "UNKNOWN")
            entry.setdefault("classifier_confidence", entry.get("confidence"))
            entry["spec_ref"] = block
            entry["spec_ref_status"] = "adopted"
            entry["topic"] = row["topic"]
            entry["status"] = "HINT"
            entry["engine"] = "aqa_spec_reference"
            entry["text_source"] = str(entry.get("text_source") or "") + "+spec_reference"
            counters["adopted"] += 1
            continue
        # A tie (the board itself names two nodes) the classifier did not land in: flagged, both
        # topics kept, nothing adopted -- "either" is a human decision, not a guess.
        entry.setdefault("classifier_topic", verdict or "UNKNOWN")
        entry.setdefault("classifier_confidence", entry.get("confidence"))
        entry["spec_ref"] = block
        entry["spec_ref_status"] = "disagree"
        entry["status"] = "REVIEW_REQUIRED"
        entry["review_reason"] = ("topic conflicts with the mark scheme's own spec reference: "
                                  f"classifier={verdict or 'UNKNOWN'}, board={row['topic']}")
        counters["disagree"] += 1
    return counters
