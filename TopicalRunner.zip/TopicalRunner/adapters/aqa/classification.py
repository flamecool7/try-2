"""AQA questions classified by the SAME machinery as Cambridge subjects (AQA-to-CAIE depth, Phase 2).

An AQA subject profile lives in ``subjects_aqa/<Qualification>/<Subject_Code>/config.json`` in the
Cambridge ``SubjectConfig`` schema (major_topics, detailed_topics, mapping, classification_keywords,
specialization_weights, syllabus_order, official_source + syllabus_source_sha256 …). It is loaded
into ``core.config_loader.SubjectConfig`` and classified by ``core.classifier.TopicClassifier`` —
the classifier CAIE papers use, with its normalisation, formula/unit signals, IDF weighting, the
1.5-point direct-evidence floor and the review_required tier — never a parallel keyword scorer.

Why a separate directory: ``core.config_loader.SubjectConfig.validate()`` only admits IGCSE/A-Level,
and ``load_all_subject_configs()`` is scanned by every Cambridge run (S0 validates all of it), so AQA
profiles must not live under ``subjects_caie/``. Nothing under ``core/`` changes; CAIE behaviour is
byte-identical (proven by the suite + the CAIE proof gate).

Fallback (allowed by the work order, never primary): a spec code with no profile here, or a
profile that fails to load, falls back to ``adapters.nonib_topics`` (the Phase-0 vocabulary) and says
so (``engine: nonib_fallback``).
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Iterable, List, Optional, Tuple

from adapters.base import DocumentContext
from adapters import nonib_topics as _fallback

PROJ = Path(__file__).resolve().parent.parent.parent
PROFILE_ROOT = PROJ / "subjects_aqa"

_CACHE: Dict[str, Any] = {}


def profile_path(spec_code: str) -> Optional[Path]:
    for cfg in sorted(PROFILE_ROOT.glob(f"*/*_{spec_code}/config.json")):
        return cfg
    return None


def load_profile(spec_code: str):
    """(SubjectConfig, TopicClassifier) for a spec code, or (None, None) when no profile exists."""
    if spec_code in _CACHE:
        return _CACHE[spec_code]
    path = profile_path(spec_code)
    if path is None:
        _CACHE[spec_code] = (None, None)
        return _CACHE[spec_code]
    from core.config_loader import SubjectConfig
    from core.classifier import TopicClassifier
    data = json.loads(path.read_text(encoding="utf-8"))
    config = SubjectConfig(data, config_path=path)
    classifier = TopicClassifier(config)          # no classification memory: never auto-populated
    _CACHE[spec_code] = (config, classifier)
    return _CACHE[spec_code]


def _stub(text: str, question_number: Any, component: str, year: str = "", season: str = "") -> SimpleNamespace:
    """A MatchedQuestion-shaped object carrying the crop's own text (marks read from the text)."""
    marks = sum(int(m) for m in re.findall(r"\[(\d{1,2})\s*marks?\]", text or "", re.I))
    qp = SimpleNamespace(text=text or "", marks=marks, paper_code=component, question_number=f"Q{question_number}",
                         number_int=int(question_number or 0), assembled_image=None, images=[])
    variant = (component.split("/")[1] if "/" in component else "") or ""
    return SimpleNamespace(question_number=f"Q{question_number}", number_int=int(question_number or 0),
                           qp=qp, ms=None, paper_code=component, full_qp_code=component, full_ms_code="",
                           year=year or "", season=season or "", variant=variant, subject="", paper_format="STRUCTURED")


def _confidence(result) -> float:
    """Calibrated like the Phase-0 formula, from the classifier's own major scores: margin between the
    winner and the runner-up plus the winner's strength against the 1.5-point floor."""
    scores = dict(result.major_topic_scores or {})
    if not scores or not result.winning_major:
        return 0.0
    top = float(scores.get(result.winning_major, 0.0))
    others = sorted((float(v) for k, v in scores.items() if k != result.winning_major), reverse=True)
    second = others[0] if others else 0.0
    margin = (top - second) / top if top > 0 else 0.0
    strength = min(1.0, top / 6.0)
    return round(min(0.97, 0.50 + 0.30 * margin + 0.20 * strength), 3)


def classify_text(spec_code: str, text: str, *, question_number: Any = 0, component: str = "",
                  year: str = "", season: str = "") -> Dict[str, Any]:
    config, classifier = load_profile(spec_code)
    if classifier is None:
        out = _fallback.classify_spec_topic(spec_code, text) if spec_code in _fallback.AQA_SPECS else \
            _fallback.classify_segment_topic("AQA", text, component=component)
        out["engine"] = "nonib_fallback"
        return out
    result = classifier.classify_question(_stub(text, question_number, component or spec_code, year, season))
    tier = getattr(result, "fallback_tier", "scored")
    scores = dict(result.major_topic_scores or {})
    ranked = sorted(scores.items(), key=lambda kv: (-float(kv[1]), kv[0]))
    if tier in ("review_required", "alphabetical_first", "paper_hint") or not result.winning_major:
        # fail closed exactly like a Cambridge question with insufficient direct evidence
        return {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED", "evidence": [],
                "secondary": [], "spec": spec_code, "engine": "caie_classifier", "fallback_tier": tier,
                "candidates": [{"topic": k, "score": round(float(v), 3)} for k, v in ranked[:3]],
                "reasoning": str(getattr(result, "reasoning", ""))[:300]}
    weights = dict(getattr(config, "specialization_weights", {}) or {})
    aspects = {k for k, w in weights.items() if float(w) < 1.0}      # 0475 precedent: forms primary, aspects secondary
    pool = [(k, v) for k, v in ranked if k != result.winning_major and (not aspects or k in aspects)]
    secondary = [k for k, v in pool if float(v) >= 1.5][:2]
    return {"topic": result.winning_major, "confidence": _confidence(result), "status": "HINT",
            "evidence": list(result.detailed_topics or [])[:4] + [f"score {scores.get(result.winning_major, 0):.2f}"],
            "secondary": secondary, "spec": spec_code, "engine": "caie_classifier", "fallback_tier": tier,
            "major_scores": {k: round(float(v), 3) for k, v in ranked[:4]},
            "reasoning": str(getattr(result, "reasoning", ""))[:300]}


def _notation_evidence(ctx: DocumentContext, seg: Dict[str, Any], text: str, profile: Dict[str, Any]):
    """(text, terms) with the mathematics notation layer applied (see adapters.aqa.maths_notation).

    The layer applies only to a subject it is declared for, and only ever emits terms the profile
    itself lists: a routing decision stays traceable to the specification's vocabulary.
    """
    from adapters.aqa.maths_notation import MATHS_SUBJECTS, maths_evidence_text
    code = str(profile.get("syllabus_code") or "")
    if code not in MATHS_SUBJECTS:
        return text, []
    from adapters.aqa.adapter import _page_text_spans
    spans = []
    for page in seg.get("pages", []):
        x0, y0, x1, y1 = page.get("rect") or (0.0, 0.0, 0.0, 0.0)
        for span in _page_text_spans(ctx, page.get("page_index", 0)):
            t, sx0, sy0, _sy1, size, bold = span
            if y0 - 2.0 <= sy0 and sx0 >= x0 - 2.0 and sx0 <= x1 + 2.0:
                spans.append((t, sx0, sy0, _sy1, size, bold))
    return maths_evidence_text(text, spans, dict(profile.get("classification_keywords") or {}),
                               str(profile.get("syllabus_code") or code))


_MS_TEXT_CACHE: Dict[str, Any] = {}
_MATHS_REFERENCE: Dict[str, Any] = {}
_ALEVEL_REFERENCE: Dict[str, Any] = {}


def maths_reference(component: str) -> Dict[str, Any]:
    """The approved per-question reference for an AQA mathematics paper, or ``{}``.

    The 8300 round ships ``references/Mathematics_8300_topics.json`` (built by
    ``tools/aqa_maths_reference.py --build``): for a paper listed there the reference *is* the
    routing, exactly as the CAIE mathematics subjects route from their approved reference files.
    The classifier's independent verdict is kept on the result (``classifier_topic``,
    ``classifier_agrees``) so a disagreement stays visible instead of being overwritten silently.
    """

    if not _MATHS_REFERENCE:
        path = PROJ / "references/Mathematics_8300_topics.json"
        try:
            _MATHS_REFERENCE.update(json.loads(path.read_text(encoding="utf-8")) if path.exists() else {})
        except (OSError, ValueError):
            _MATHS_REFERENCE["papers"] = {}
    papers = _MATHS_REFERENCE.get("papers") or {}
    code = re.sub(r"[^0-9A-Za-z]", "", str(component or "")).upper()
    for key, entry in papers.items():
        if code.endswith(key.upper()) or code.startswith(key.upper()):
            return entry
    return {}


def mark_scheme_texts(qp_path) -> Dict[int, str]:
    """``{question number: mark-scheme block text}`` for the MS published with this question paper.

    AQA prints no specification reference for an 8300 question, and the question paper of a
    diagram-led item can print almost no words at all -- but the mark scheme for that same question
    restates, in AQA's own words and marks, what the question is asking ("oe correct equation",
    "Denotes the given recurring decimal by a letter", "x < 13 or 13 > x"). Both documents are
    always published together, so the paired MS is read here and used as additional evidence by the
    mathematics subjects only (``adapters.aqa.maths_notation.MATHS_SUBJECTS``) -- the science
    rounds' pinned verdicts are unaffected.
    """

    key = str(qp_path)
    if key in _MS_TEXT_CACHE:
        return _MS_TEXT_CACHE[key]
    out: Dict[int, str] = {}
    path = Path(qp_path)
    try:
        cand = None
        for sibling in path.parent.glob("*.PDF"):
            if sibling == path:
                continue
            a, b = path.name.upper(), sibling.name.upper()
            if "-QP-" in a and "-MS-" in b and a.replace("-QP-", "-") == b.replace("-MS-", "-"):
                cand = sibling
                break
        if cand is None:
            _MS_TEXT_CACHE[key] = out
            return out
        from tools.crop_noncaie_segments import build_context
        from adapters.registry import get_adapter
        adapter = get_adapter("AQA")
        ctx = build_context(cand)
        for seg in adapter.segment_mark_scheme(ctx):
            text, _source = _fallback._segment_text(ctx, seg)
            out[int(seg.get("question_number") or 0)] = text
    except Exception as exc:      # noqa: BLE001 - the MS is supporting evidence, never a gate
        print(f"    [aqa] mark scheme text unavailable for {path.name}: {type(exc).__name__}")
    _MS_TEXT_CACHE[key] = out
    return out


def _ms_evidence(seg: Dict[str, Any], texts: Dict[int, str]) -> Tuple[str, str]:
    """(mark scheme text for this question, recorded evidence source)."""

    if not texts:
        return "", ""
    try:
        q = int(seg.get("question_number") or 0)
    except (TypeError, ValueError):
        return "", ""
    body = texts.get(q) or ""
    return body, (f"ms_q{q}" if body else "")


def classify_segments(ctx: DocumentContext, segments: Iterable[Dict[str, Any]], component: str,
                      year: str = "", season: str = "") -> List[Dict[str, Any]]:
    spec_code = _fallback.spec_code_for(component) or (re.search(r"\b(\d{4})\b", component or "") or [None, None])[1]
    out = []
    for seg in segments:
        text, source = _fallback._segment_text(ctx, seg)
        if spec_code and profile_path(spec_code):
            config, _classifier = load_profile(spec_code)
            profile = json.loads(profile_path(spec_code).read_text(encoding="utf-8"))
            text, terms = _notation_evidence(ctx, seg, text, profile)
            code = str(profile.get("syllabus_code") or "")
            from adapters.aqa.maths_notation import MATHS_SUBJECTS
            ms_text, ms_source = ("", "")
            if code in MATHS_SUBJECTS:
                ms_text, ms_source = _ms_evidence(seg, mark_scheme_texts(ctx.path))
            cls = classify_text(spec_code, text, question_number=seg.get("question_number"), component=component,
                                year=year, season=season)
            source_label = source + "+notation" if terms else source
            # The mark scheme of the SAME question is the second evidence level: it restates, in
            # AQA's own working, a question whose paper prints nothing but notation or a diagram.
            # It is consulted only when the question's own text carries no direct evidence --
            # AQA's answer-format boilerplate ("oe fraction, decimal or percentage") is otherwise
            # loud enough to outvote the question (measured on 8300/1H Q11, a Venn-diagram
            # probability question whose answer is 0.13).
            if ms_text and cls.get("status") != "HINT":
                ms_cls = classify_text(spec_code, text + "\n" + ms_text, question_number=seg.get("question_number"),
                                       component=component, year=year, season=season)
                if ms_cls.get("status") == "HINT":
                    ms_cls["text_source"] = source_label + "+mark_scheme"
                    ms_cls["notation_evidence"] = terms + ["mark_scheme_text"]
                    cls = ms_cls
                else:
                    cls["text_source"] = source_label + "+mark_scheme(unresolved)"
            if terms:
                cls["notation_evidence"] = terms
            if not cls.get("text_source"):
                cls["text_source"] = source_label
            from adapters.aqa.alevel_reference import ALEVEL_SUBJECTS, alevel_reference, alevel_row
            if code in ALEVEL_SUBJECTS:
                # A-level science: the mark scheme prints no specification reference, so the
                # approved reference (tools/aqa_alevel_reference.py) carries the routing for every
                # question of a paper it covers. The classifier's own verdict stays on the record.
                entry = alevel_reference(component, year=year, season=season)
                arow = alevel_row(entry, seg.get("question_number"))
                if arow and arow.get("topic"):
                    topics = arow["topics"] or {}
                    cls["classifier_topic"] = cls.get("topic")
                    cls["classifier_confidence"] = cls.get("confidence")
                    cls["classifier_agrees"] = bool(
                        cls.get("topic") in arow["winner"]
                        or cls.get("topic") in (arow.get("accept") or [])
                        or cls.get("topic") in (arow.get("secondary") or []))
                    cls["reference"] = {"topic": arow["topic"], "winner": list(arow["winner"]),
                                        "topics": dict(topics),
                                        "spec_reference": ", ".join(arow["spec_references"]),
                                        "accept": list(arow.get("accept") or []),
                                        "options": list(arow.get("options") or []),
                                        "marks": arow["marks"], "source": arow["source"]}
                    cls["secondary"] = list(arow.get("secondary") or [])[:3]
                    cls["topic"] = arow["topic"]
                    cls["status"] = "HINT"
                    cls["engine"] = "aqa_alevel_reference"
                    if not cls["classifier_agrees"]:
                        cls["text_source"] = str(cls.get("text_source") or source_label) + "+reference"
            reference = maths_reference(component) if code in MATHS_SUBJECTS else {}
            row = ((reference.get("questions") or {}).get(str(seg.get("question_number")))) or None
            if row:
                cls["classifier_topic"] = cls.get("topic")
                cls["classifier_confidence"] = cls.get("confidence")
                cls["classifier_agrees"] = bool(row.get("topic") == cls.get("topic") or
                                                cls.get("topic") in (row.get("accept") or []))
                cls["reference"] = {"topic": row["topic"], "spec_reference": row.get("spec_reference"),
                                    "accept": list(row.get("accept") or []), "marks": row.get("marks"),
                                    "source": "references/Mathematics_8300_topics.json"}
                cls["secondary"] = list(row.get("accept") or [])[:2]
                # The approved reference carries the routing for a paper it covers: one adjudicated
                # section per question, so the same question cannot land in a different folder
                # depending on which alternative the scorer happened to prefer. The classifier's own
                # verdict stays in the record (classifier_topic/classifier_agrees) either way.
                cls["topic"] = row["topic"]
                cls["status"] = "HINT"
                cls["engine"] = "aqa_maths_reference"
                if not cls["classifier_agrees"]:
                    cls["text_source"] = str(cls.get("text_source") or source_label) + "+reference"
        else:
            cls = _fallback.classify_segment_topic("AQA", text, component=component)
            cls["engine"] = "nonib_fallback"
        out.append({"question_number": seg.get("question_number"), "canonical_question": seg.get("canonical_question"),
                    "text_source": source, **cls})
    return out
