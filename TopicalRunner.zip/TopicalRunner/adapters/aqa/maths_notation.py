"""Notation evidence for AQA mathematics papers (GCSE Mathematics 8300 is the first).

A mathematics question is often *all notation*: "Work out 0.7 × 0.5" prints no word that names its
topic, and a diagram-led question may print almost nothing at all. The science subjects never had
this problem -- their questions are prose, and the vocabulary rounds (8461/8462/8463/8464/8700)
settled them by matching that prose against the specification's own wording. For mathematics the
same rule is kept (`no keyword the specification does not print in that section`) but the evidence
is read from the question's *notation* as well as its words:

    0.7 × 0.5           -> "decimals"      (spec 3.1: "calculate with fractions, decimals ...")
    5² / x³             -> "indices"       (superscript-shaped span, spec 3.1 "integer indices")
    √2                  -> "surds"         (spec 3.1: "calculate exactly with fractions, surds")
    x < 7               -> "inequalities"  (spec 3.2: "solve linear inequalities")
    (8, 22)             -> "coordinates"   (spec 3.2: "work with coordinates")
    x = 5 / solve x     -> "equations"     (spec 3.2: "solve linear equations")
    5 : 6               -> "ratio"         (spec 3.3: "use ratio notation")
    π                   -> "circles"       (spec 3.4)
    °                   -> "angle"         (spec 3.4)

Every derived term must be one the *subject's own profile* already lists for a section
(``profile_terms``): notation can select among the specification's terms, never invent one. The
derived terms are appended to the crop text handed to the classifier and recorded on the result
under ``notation_evidence``, so any routing decision can be traced to the printed notation that
produced it.

Superscripts are read from the PDF's own text spans (size relative to the page's body size): AQA
prints ``5²`` as a smaller span raised above the baseline, and the layout lines shared by the crop
engine carry no size, so span geometry is the only place that evidence exists.
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Dict, Iterable, List, Sequence, Tuple

#: syllabus codes whose papers carry notation-led questions (the sciences' maths items are prose).
#: A-level Mathematics 7357 joined in its round: its multiple-choice items ("Circle your answer")
#: print almost no prose at all, and its pure questions are read the same way 8300's are.
MATHS_SUBJECTS = {"8300", "7357"}

#: derived term -> (pattern over the crop text, terms that must ALSO be present or absent)
#: the "require" list is the disambiguating context: "=" alone is not an equation, "=" next to a
#: letter or a bracket is.
RULES: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "decimals": (r"(?<![\d.])\d+\.\d+", ()),
    "percentages": (r"%", ()),
    "standard form": (r"[×x]\s*10\s*(?:\^|\d)", ()),
    "surds": (r"√|sqrt", ()),
    "mixed numbers": (r"mixed\s+number", ()),
    "ratio": (r"\b\d+\s*:\s*\d+\b", ()),
    "directly proportional": (r"directly\s+proportional", ()),
    "inverse proportion": (r"inversely?\s+proportional", ()),
    "speed": (r"\bkm/h\b|\bm/s\b|\bmph\b", ()),
    "coordinates": (r"\(\s*-?\d+\s*,\s*-?\d+\s*\)", ()),
    "inequalities": (r"[<>⩽⩾≤≥]", (r"\b[a-zA-Z]\b|\d[a-zA-Z](?![a-zA-Z])|⩽|⩾",)),
    "equations": (r"=|≡",
                  (r"\b[a-zA-Z]\b\s*[=<>≡]|[=<>≡]\s*-?\s*[a-zA-Z]\b|\b[a-zA-Z]\b\d*\s*[+\-–×÷]"
                   r"|\d[a-zA-Z](?![a-zA-Z])|[a-zA-Z]\d(?![a-zA-Z0-9])",)),
    "angle": (r"°", ()),
    "circles": (r"π", ()),
    "volume": (r"cm3|m3|cm³|m³", ()),
    "probability": (r"\bP\s*\(|\bprobabilit", ()),
    "charts": (r"cumulative\s+frequency|box\s+plot|scatter|histogram", ()),
    "brackets": (r"\([^)]*[+\-–−×÷/][^)]*\)", ()),
}

#: Subjects whose questions are read with ALEVEL_RULES added to the GCSE ones.
ALEVEL_NOTATION_SUBJECTS = {"7357"}

#: A-level Mathematics 7357 (added in its round). An A-level paper prints its mathematics the same
#: way a GCSE one does -- by notation -- and its highest-mark questions are often its shortest:
#: "Given that y = 2x3 find dy/dx", "Show that (the integral) ... = (pi)/8", "Find the value of
#: P(A and B)". AQA's own vocabulary for the subject is the specification's wording, and each rule
#: below names a term that vocabulary lists for a section (§3.8 G2 prints "Differentiate", §3.9 H2
#: "Integrate", §3.6 E1 "area of sector", §3.15 N2 "Normal distribution", §3.20 S1 "moments").
#:
#: Two details of these documents shaped the patterns: the symbol face AQA uses loses its Unicode
#: mapping in extraction, so "+" arrives as "þ", "−" as a control character and the integral sign as
#: "ð"; and the mark scheme is not part of the notation evidence at all.
#:
#: The terms are filtered against the subject's own profile exactly as the GCSE rules are, so a rule
#: whose term a subject does not list emits nothing. The rules are only ADDED for the subjects above:
#: the GCSE Mathematics round's verdicts are pinned, and must not move.
ALEVEL_RULES: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    # "dy/dx" arrives as "dy dx": the fraction slash of the display is dropped in extraction, so the
    # rule reads the two differentials next to each other with or without it
    "derivative": (r"d\s*y\s*/?\s*d\s*x|d\s*x\s*/?\s*d\s*y|f\s*['\u2019]\s*\(", ()),
    "differentiate": (r"\bdifferentiat|\bdifferentiat", ()),
    "stationary points": (r"stationary\s+point", ()),
    "tangents": (r"\btangent\b|\bnormal\s+to\s+the\s+curve\b", ()),
    "integral": (r"\u00f0|\bintegral\b|\bd\s*x\b", ()),
    "integrate": (r"\bintegrat", ()),
    "area under a curve": (r"the\s+area,?\s*A\b|\barea\b[^.]{0,30}\bcurve\b", ()),
    "definite integral": (r"\u00f0|\bfrom\s+0\s+to\b|\bfrom\s+-?\d+\s+to\s+\d+\b", ()),
    "differential equation": (r"\bcontainer\b|\bdV\b|\bd\s*[vV]\s*/\s*d\s*t\b", ()),
    "logarithm": (r"\bln\b|\blog\s*10\b|\blog10\b|\blogarithms?\b", ()),
    "logarithmic graphs": (r"\blog\s*10\b|\blog10\b", ()),
    # NOT "\be\s*[x×]", which the case-insensitive pass matches inside "Express"/"exclusive"
    "exponential": (r"\be\s*\^|\d\s*[eE]\s*[\dx]|\bexponential\b", ()),
    "growth and decay": (r"\bexponent", ()),
    "trigonometric": (r"\b(?:sin|cos|tan|cosec|cot|sec|arcsin|arccos|arctan|sine|cosine"
                      r"|tangent)\b", ()),
    "radian measure": (r"\bradians?\b", ()),
    "area of sector": (r"\bsector\b", ()),
    "arc length": (r"\barc\s+length\b|\bperimeter\b", ()),
    "small angle approximations": (r"\bsmall\s+angle", ()),
    "binomial expansion": (r"\bexpansion\b|\bexpand\b", ()),
    "rational exponents": (r"\bx\s*p\b|\bx\s*q\b|\bx\s*\^", ()),
    # the radical sign of these papers arrives as the ligature "ﬃﬃ", so the surd rule reads it too
    "surds": (r"ﬃﬃ|\u221a|\bsqrt\b", ()),
    "binomial distribution": (r"\bB\s*\(\s*\d+\s*,|\bbinomial\b", ()),
    "normal distribution": (r"normal\s+distribution|normally\s+distributed", ()),
    "standard deviation": (r"standard\s+deviation", ()),
    "hypothesis testing": (r"\bhypothesis\b|\bsignificance\s+level\b|\bcritical\s+"
                           r"(?:value|region)\b|\btest\s+statistic\b|\blevel\s+of\s+"
                           r"significance\b", ()),
    # the word "probability" usually comes BEFORE the condition in AQA's wording ("Find the
    # probability ... , given that ..."), so the requirement is a separate pattern, not a lookahead
    "conditional probability": (r"\bgiven\s+that\b", (r"probab",)),
    "mutually exclusive": (r"\bmutually\s+exclusive\b", ()),
    "outliers": (r"\boutliers?\b|\binterquartile\b|\bquartiles?\b|\bIQR\b", ()),
    "correlation": (r"\bcorrelation\b|\bscatter\b|\bregression\b", ()),
    "regression lines": (r"\bline\s+of\s+best\s+fit\b|\bregression\b", ()),
    "moments": (r"\bmoments?\b(?!\s+correlation)|\bpivot\b|\bplank\b", ()),
    "resultant forces": (r"\bresultant\b|\btension\b|\bresistance\s+force\b", ()),
    "coefficient of friction": (r"\bcoefficient\s+of\s+friction\b|\u03bc|\u00b5|\bfriction\b", ()),
    "equilibrium": (r"\bequilibrium\b|\bhanging\b|\btension\b", ()),
    "acceleration": (r"\bacceleration\b|m\s*s\s*[\u2212\u2013-]\s*2", ()),
    "velocity": (r"\bvelocity\b|m\s*s\s*[\u2212\u2013-]\s*1", ()),
    "displacement": (r"\bdisplacement\b", ()),
    "projectiles": (r"\bprojectile\b|\bthrown\b|\bcatch(?:es)?\s+the\s+ball\b", ()),
    "motion under gravity": (r"\bg\s*=\s*9|\bfalls?\s+freely\b|\bgravity\b", ()),
    "vector": (r"\bvectors?\b|\bmagnitude\b|\bposition\s+vectors?\b|\bi\s*[\u00fe+]", ()),
    "nth term": (r"\bn\s*th\b", ()),
    "sequences": (r"\bu\s*n\b|\bu\s*\(?\s*n\b", ()),
    "modulus": (r"\bmodulus\b|(?<![a-z])j\s*[a-z]\s*[\u00fe+\u2212]", ()),
    "inverse functions": (r"\binverse\b|\b(?:f|g|h)\s*[\u2212\u2013-]\s*1\s*\(", ()),
    "composite functions": (r"\bcomposite\b|\bgf\s*\(|\bg\s*\(\s*f\s*\(", ()),
    "transformations": (r"\bstretch\b|\btransformation", ()),
    "parametric equations": (r"\bparametric\b|\bparametrically\b", ()),
    "partial fractions": (r"\bpartial\s+fractions?\b", ()),
    "asymptotes": (r"\basymptote", ()),
}

#: a span is superscript-shaped when it is this much smaller than the page's body size
_SUPERSCRIPT_RATIO = 0.85


def _body_size(spans: Sequence[Tuple[str, float, float, float, float, bool]]) -> float:
    """The page's body font size: its most common span size (ties -> the larger)."""

    sizes = Counter(round(s[4], 1) for s in spans if s[0].strip())
    if not sizes:
        return 0.0
    return float(max(sizes.items(), key=lambda kv: (kv[1], kv[0]))[0])


def _has_numeric_superscript(spans: Sequence[Tuple[str, float, float, float, float, bool]]) -> bool:
    """True when the crop holds a raised smaller digit printed on a NUMERIC base (5², 10³, cm³).

    The distinction matters: "5²" is a power of a number (spec 3.1 Number: "integer indices"), while
    "x²" is an algebraic square and belongs to 3.2 Algebra's own wording ("expand", "simplify",
    "factorise", "complete the square"). Measured: treating every superscript as Number evidence
    pulled 8300/2H Q15 ("Expand (x² – 9xy)(2x + 5y)") and Q8 (an identity in x) into Number.
    """

    body = _body_size(spans)
    if body <= 0:
        return False
    lines: Dict[int, List[Tuple[str, float, float]]] = {}
    for text, x0, y0, _y1, size, _bold in spans:
        t = text.strip()
        if t:
            lines.setdefault(int(round(y0 / 3.0)), []).append((t, x0, size))
    for group in lines.values():
        ordered = sorted(group, key=lambda item: item[1])
        for prev, cur in zip(ordered, ordered[1:]):
            if 0 < cur[2] <= body * _SUPERSCRIPT_RATIO and (cur[0].isdigit() or cur[0] in "+-") \
                    and prev[2] >= body * _SUPERSCRIPT_RATIO and prev[0][-1:].isdigit():
                return True
    return False


def _profile_twins(text: str, profile_terms: Dict[str, List[str]]) -> List[str]:
    """Profile terms whose plural/singular twin is printed in the question.

    The classifier matches a keyword literally, and the specification prints some of its own terms
    only in the plural ("multiples", "bar charts", "mixed numbers") while a question prints the
    singular ("a multiple of 4", "Complete the bar chart", "as a mixed number"). This maps between
    the two spellings OF THE SAME PROFILE TERM only -- it can never introduce a term the profile
    does not list, and it never touches a science profile (this layer is mathematics-only).
    """

    low = " " + re.sub(r"\s+", " ", (text or "").lower()) + " "
    out: List[str] = []
    for section_terms in (profile_terms or {}).values():
        for term in section_terms:
            t = term.lower()
            twins = [t[:-1]] if t.endswith("s") else [t + "s", t + "es"]
            for tw in twins:
                if len(tw) >= 4 and re.search(r"(?<![a-z])" + re.escape(tw) + r"(?![a-z])", low):
                    out.append(term)
                    break
    return out


def maths_notation_terms(text: str, spans: Iterable[Sequence] = (),
                         profile_terms: Dict[str, List[str]] | None = None,
                         subject_code: str = "") -> List[str]:
    """Specification terms evidenced by the question's own notation (never invented).

    ``subject_code`` selects the rule set: the GCSE rules alone, or those plus the A-level rules for
    a subject listed in ``ALEVEL_NOTATION_SUBJECTS`` (see the comment on ``ALEVEL_RULES``).
    """

    src = text or ""
    rules = dict(RULES)
    if str(subject_code) in ALEVEL_NOTATION_SUBJECTS:
        rules.update(ALEVEL_RULES)
    found: List[str] = []
    for term, (pattern, required) in rules.items():
        if re.search(pattern, src, re.I | re.M) and all(re.search(r, src, re.I | re.M) for r in required):
            found.append(term)
    spans = list(spans)
    if spans and _has_numeric_superscript(spans):
        found += ["indices", "powers"]
    if profile_terms:
        found += _profile_twins(src, profile_terms)
    if profile_terms:
        allowed = {t for terms in profile_terms.values() for t in terms}
        expanded = list(found)
        for term in found:                      # the profile's own plural/singular twin
            for cand in (term + "s", term[:-1] if term.endswith("s") else term + "es"):
                if cand in allowed and cand not in expanded:
                    expanded.append(cand)
        found = [t for t in expanded if t in allowed]
    out: List[str] = []
    for term in found:
        if term not in out:
            out.append(term)
    return out


def maths_evidence_text(text: str, spans: Iterable[Sequence] = (),
                        profile_terms: Dict[str, List[str]] | None = None,
                        subject_code: str = "") -> Tuple[str, List[str]]:
    """(crop text + one line of derived specification terms, the terms themselves)."""

    terms = maths_notation_terms(text, spans, profile_terms, subject_code)
    return ((text or "") + ("\n" + " ".join(terms) if terms else ""), terms)
