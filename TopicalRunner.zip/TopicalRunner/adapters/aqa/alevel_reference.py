"""The approved A-level question references the AQA adapter routes from.

A-level mark schemes print no specification reference at all (the science schemes print the AO
split in the Mark cell, the mathematics scheme prints AQA's own fine AO code beside each mark), so
-- like GCSE Mathematics 8300, and unlike the GCSE sciences 8461-8464 whose mark schemes print
``AO / Spec. Ref.`` per row -- the routing for these papers comes from an approved, adjudicated
reference file:

    references/A-Level_<Subject>_<code>_topics.json   (tools/aqa_alevel_reference.py --build)

For a paper listed there the reference *is* the routing: one adjudicated section per question, so
the same question cannot land in a different folder depending on which alternative a text scorer
happened to prefer. Everything the classifier decided on its own is kept on the record
(``classifier_topic``, ``classifier_agrees``) so a disagreement stays visible.

A question whose marks are split across sections keeps the split: ``winner`` lists the section(s)
with the largest share, and the router takes the first of them. A question that offers a choice
(7402/3's essay) carries ``options``; the router takes the default option's section and keeps the
other option's sections in ``secondary``.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict

PROJ = Path(__file__).resolve().parents[2]

#: syllabus code -> the reference file that covers its papers
ALEVEL_SUBJECTS: Dict[str, str] = {
    "7402": "references/A-Level_Biology_7402_topics.json",
    "7405": "references/A-Level_Chemistry_7405_topics.json",
    "7408": "references/A-Level_Physics_7408_topics.json",
    # A-level Mathematics 7357 (2026-09-23) prints no specification reference either. Its mark
    # scheme DOES print AQA's own fine assessment objective per marking row, so the reference for
    # this subject carries the AO split of every question alongside the section it assesses
    # (``tools/aqa_alevel_reference.py --subject Mathematics_7357``).
    "7357": "references/A-Level_Mathematics_7357_topics.json",
    # A-level English Literature A 7712 (2026-09-24). A literature mark scheme is a level-of-response
    # scheme: no table, no printed specification reference, and the AO split is the paper-wide
    # weighting line both published 7712/1 schemes print ("AO1: 7 marks AO2: 6 marks AO3: 6 marks
    # AO4: 3 marks AO5: 3 marks"). The adjudicated section per question -- the §4.1.1 core Shakespeare
    # play, the §4.1 two unseen poems, the §4.1.1 comparative poetry-and-prose comparison -- comes
    # from the question paper's own section headings and wording
    # (tools/aqa_literature_reference.py --build/--check).
    "7712": "references/A-Level_English_Literature_A_7712_topics.json",
    # A-level Computer Science 7517 (2026-09-24). Its mark schemes print no specification reference
    # either -- the row header is "Question | Marks" (7517/1, 7517/2 June 2022, 7517/1 June 2023) or
    # "Qu | Pt | Marking guidance | Total marks" (7517/2 June 2023) -- so the routing is the
    # adjudicated section of every question, read off the question paper's own wording against the
    # specification's own nodes, with the marks and the AO split re-derived from the scheme's
    # marking rows (tools/aqa_cs_reference.py --build/--check). 7517 is the first subject here with
    # TWO published series in the same reference: both June 2022 and June 2023 are adjudicated, so
    # its paper keys carry the series ("75171JUN22") and the lookup below matches them by
    # component-digits + year.
    "7517": "references/A-Level_Computer_Science_7517_topics.json",
}

_CACHE: Dict[str, Any] = {}


def reference_payload(code: str) -> Dict[str, Any]:
    """The whole reference file for a syllabus code (``{}`` when the code has none)."""

    rel = ALEVEL_SUBJECTS.get(str(code))
    if not rel:
        return {}
    if rel not in _CACHE:
        path = PROJ / rel
        try:
            _CACHE[rel] = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        except (OSError, ValueError):
            _CACHE[rel] = {}
    return _CACHE[rel]


def alevel_reference(component: str, year: str = "", season: str = "") -> Dict[str, Any]:
    """The paper entry of the approved reference that covers ``component`` (and ``year``), or ``{}``.

    ``component`` is the batch's component string ("7402/1", "74021", "AQA-74021-QP-JUN23.PDF");
    the paper key is matched against the digits, the way the 8300 reference is matched. A subject
    with more than one published series keys its papers by series as well ("75171JUN22"), and the
    series-qualified match -- the component's own digits followed by the year's last two -- is tried
    first, so June 2022 and June 2023 papers of the same component cannot be given each other's
    routing.
    """

    code = re.sub(r"[^0-9]", "", str(component or ""))
    yy = re.sub(r"[^0-9]", "", str(year or ""))[-2:]
    if code and yy:
        for key, payload in ((k, reference_payload(k)) for k in ALEVEL_SUBJECTS):
            for paper_code, entry in (payload.get("papers") or {}).items():
                if re.sub(r"[^0-9]", "", paper_code) == code + yy:
                    entry = dict(entry)
                    entry["_source"] = ALEVEL_SUBJECTS[key]
                    entry["_reference_code"] = key
                    return entry
    for key, payload in ((k, reference_payload(k)) for k in ALEVEL_SUBJECTS):
        papers = (payload.get("papers") or {})
        for paper_code, entry in papers.items():
            digits = re.sub(r"[^0-9]", "", paper_code)
            # Physics prints paper 3 as "7408/3A" and "7408/3BA": a paper code whose component
            # carries a LETTER is matched on the whole code, digit-for-digit and letter-for-letter
            # (the digit-only rule below would let "7408/3A" claim "74083BA"'s entry), and the
            # digit-only rule stays for the components that carry no letter at all.
            m = re.match(r"^(\d{4})(\d?)([A-Za-z]*)$", paper_code or "")
            if m and m.group(3):
                pattern = (re.escape(m.group(1)) + r"\s*/?\s*" + re.escape(m.group(2))
                           + re.escape(m.group(3)))
                if component and re.search(pattern, str(component), re.I):
                    entry = dict(entry)
                    entry["_source"] = ALEVEL_SUBJECTS[key]
                    entry["_reference_code"] = key
                    return entry
                continue
            if code and (code.startswith(digits) or digits.startswith(code) or code.endswith(digits)):
                entry = dict(entry)
                entry["_source"] = ALEVEL_SUBJECTS[key]
                entry["_reference_code"] = key
                return entry
    return {}


def alevel_row(entry: Dict[str, Any], question_number) -> Dict[str, Any]:
    """The reference row for one question of a covered paper (``{}`` when there is none)."""

    if not entry:
        return {}
    row = (entry.get("questions") or {}).get(str(question_number)) or {}
    if not row:
        return {}
    winner = list(row.get("winner") or [])
    options = list(row.get("options") or [])
    topic = winner[0] if winner else ""
    if options and not topic:
        topic = options[0].get("topic", "")
    secondary = [t for t in row.get("topics") or {} if t != topic]
    for opt in options:
        if opt.get("topic") and opt["topic"] != topic:
            secondary.append(opt["topic"])
    return {"topic": topic, "winner": winner,
            "topics": dict(row.get("topics") or {}),
            "spec_references": list(row.get("spec_references") or []),
            "accept": [t for t in (row.get("accept") or []) if t != topic],
            "marks": row.get("marks"), "options": options,
            "secondary": list(dict.fromkeys(secondary))[:4],
            "evidence": row.get("evidence", ""),
            "source": entry.get("_source", "references/A-Level_<Subject>_<code>_topics.json")}
