"""Optional OCR fallback for image-only PDFs.

The universal runner uses this only when a PDF has no usable text layer and the
user enables OCR. If Tesseract/pytesseract are unavailable, the paper is routed
to REVIEW_REQUIRED with an explicit installation reason. OCR output is treated
as low-confidence layout evidence and never silently trusted.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List
import hashlib
import shutil

import fitz
from PIL import Image

from adapters.base import DocumentContext


@dataclass(frozen=True)
class OCRResult:
    available: bool
    ctx: DocumentContext | None
    reason: str
    confidence: float = 0.0


def _sha256(path: Path) -> str:
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    return h


def ocr_available() -> tuple[bool, str]:
    if shutil.which("tesseract") is None:
        return False, "tesseract executable not found"
    try:
        import pytesseract  # noqa: F401
    except Exception as exc:
        return False, f"pytesseract import failed: {exc}"
    return True, "tesseract+pytesseract available"


def build_ocr_context(pdf_path: str | Path, max_pages: int = 0, dpi: int = 150) -> OCRResult:
    ok, reason = ocr_available()
    path = Path(pdf_path)
    if not ok:
        return OCRResult(False, None, reason)
    import pytesseract

    pages = []
    full_parts: List[str] = []
    first = ""
    total_words = 0
    confident_words = 0
    with fitz.open(path) as doc:
        count = min(len(doc), max_pages) if max_pages else len(doc)
        for idx in range(count):
            page = doc[idx]
            zoom = dpi / 72.0
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
            words = []
            lines_by_key = {}
            n = len(data.get("text", []))
            for i in range(n):
                text = str(data["text"][i] or "").strip()
                if not text:
                    continue
                try:
                    conf = float(data.get("conf", ["-1"])[i])
                except Exception:
                    conf = -1.0
                total_words += 1
                if conf >= 50:
                    confident_words += 1
                x = float(data["left"][i]) / zoom
                y = float(data["top"][i]) / zoom
                w = float(data["width"][i]) / zoom
                h = float(data["height"][i]) / zoom
                key = (data.get("block_num", [0])[i], data.get("par_num", [0])[i], data.get("line_num", [0])[i])
                lines_by_key.setdefault(key, []).append((x, y, x + w, y + h, text))
                words.append(text)
            lines = []
            for _key, items in sorted(lines_by_key.items(), key=lambda kv: min(x[1] for x in kv[1])):
                txt = " ".join(item[4] for item in sorted(items, key=lambda t: t[0])).strip()
                if not txt:
                    continue
                x0 = min(item[0] for item in items); y0 = min(item[1] for item in items)
                x1 = max(item[2] for item in items); y1 = max(item[3] for item in items)
                lines.append({"text": txt, "bbox": [x0, y0, x1, y1], "ocr": True})
            text = "\n".join(line["text"] for line in lines)
            if idx == 0:
                first = text
            full_parts.append(text)
            pages.append({"page_index": idx, "size": [float(page.rect.width), float(page.rect.height)], "text": text, "lines": lines, "ocr": True})
    confidence = (confident_words / total_words) if total_words else 0.0
    ctx = DocumentContext(
        path=str(path), filename=path.name, stem=path.stem, suffix=path.suffix,
        size_bytes=path.stat().st_size, sha256=_sha256(path), page_count=len(pages),
        first_page_text=first, full_text="\f".join(full_parts), has_text_layer=False,
        text_chars_per_page=[len(p.get("text", "")) for p in pages],
        layout={"pages": pages, "ocr": True, "ocr_confidence": confidence},
    )
    if not "".join(full_parts).strip():
        return OCRResult(False, ctx, "OCR produced no text", confidence)
    return OCRResult(True, ctx, "OCR text extracted", confidence)
