"""Board-aware QP/MS/ER/insert association helpers.

This module deliberately does not trust filenames.  It extracts lightweight
identity from first-page/early-page PDF text and groups documents by the board,
component and session evidence that the board adapters can also see.  Unknowns
are explicit so callers can review rather than silently mis-associate papers.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib
import json
import re
from typing import Dict, Iterable, List, Optional

import fitz  # PyMuPDF


_DOC_TYPES = ("QP", "MS", "ER", "IN")

#: Adapter document-type codes -> the canonical four. The adapters speak their own board's
#: vocabulary ("insert", "grade_boundaries", "syllabus"), and this module used to test the raw
#: code against ("QP","MS","ER","IN"). Cambridge's "insert" therefore became UNKNOWN, the
#: document fell through to the legacy heuristics, and the AQA heuristic claimed it off
#: Cambridge's own cover code ("9706/32") -- a CAIE insert filed under final/AQA/9706_32/.
_DOC_TYPE_ALIASES = {
    "QP": "QP", "PAPER": "QP", "QUESTION": "QP", "QUESTION_PAPER": "QP",
    "MS": "MS", "MARKSCHEME": "MS", "MARK_SCHEME": "MS", "MARKING_SCHEME": "MS",
    "ER": "ER", "EXAMINER_REPORT": "ER", "EXAMINERS_REPORT": "ER",
    "PRINCIPAL_EXAMINER_REPORT": "ER", "REPORT": "ER",
    "IN": "IN", "INSERT": "IN", "INSERTS": "IN", "INSERT_BOOKLET": "IN",
    "SOURCE": "IN", "SOURCES": "IN", "SOURCE_BOOKLET": "IN", "CASE_STUDY": "IN",
}


def canonical_document_type(code) -> str:
    """One of QP/MS/ER/IN, or UNKNOWN -- the adapters' vocabulary in this module's terms.

    Codes that are real document types but not ones a pack carries (grade boundaries, the
    syllabus itself) stay UNKNOWN here on purpose: an association group does not want them.
    """
    raw = str(code or "").strip().upper().replace("-", "_").replace(" ", "_")
    return _DOC_TYPE_ALIASES.get(raw, "UNKNOWN")


@dataclass(frozen=True)
class DocumentIdentity:
    path: str
    sha256: str
    board: str
    document_type: str
    component: str
    season: str
    year: str
    confidence: float
    evidence: List[str]
    # Syllabus code as printed on the document (CAIE: "0980/01" -> "0980").
    # Optional and appended last so every existing positional construction
    # keeps working. Boards whose component already carries the subject code
    # (AQA "8462/1H", Edexcel "9FM0/3C", IB "IBBI/1A") simply leave it blank.
    syllabus_code: str = ""

    @property
    def association_key(self) -> str:
        return "|".join((self.board, self.component, self.season, self.year))


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _first_text(path: Path, pages: int = 3) -> str:
    with fitz.open(path) as doc:
        return "\n".join(doc[i].get_text("text") for i in range(min(pages, len(doc))))


def _season_year(text: str) -> tuple[str, str, List[str]]:
    ev: List[str] = []
    low = text.lower()
    season = "UNKNOWN"
    if re.search(r"\b(may/june|june|jun)\b", low):
        season = "June"; ev.append("season: June token")
    elif re.search(r"\b(october/november|november|nov)\b", low):
        season = "November"; ev.append("season: November token")
    elif re.search(r"\b(march|mar)\b", low):
        season = "March"; ev.append("season: March token")
    year = "UNKNOWN"
    m = re.search(r"\b(19\d{2}|20\d{2})\b", text)
    if m:
        year = m.group(1); ev.append(f"year: {year} token")
    else:
        # AQA/Pearson sometimes print compact publication codes such as Jun23.
        m2 = re.search(r"\b(?:Jun|June|Nov|November|Mar|March)\s*/?\s*(\d{2})(?!\d)", text, re.I)
        if m2:
            yy = int(m2.group(1))
            year = str(2000 + yy if yy < 70 else 1900 + yy)
            ev.append(f"year: compact two-digit token {m2.group(0)}")
    # A cover year is a series token ("Jun23", "June 2023", "Monday 12 June 2023"), never a
    # year printed inside the text. The 8700/2 June 2023 source insert says "An extract from a
    # travel book, published in 1933", and taking the last year on the page dated the paper
    # June 1933. The series token wins wherever it appears on the page.
    if year != "UNKNOWN":
        ser = re.search(r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*/?\s*(\d{2,4})\b",
                        text, re.I)
        if ser:
            tok = ser.group(1)
            yrs = int(tok) if len(tok) == 4 else (2000 + int(tok) if int(tok) < 70 else 1900 + int(tok))
            if str(yrs) != year:
                ev = [e for e in ev if not e.startswith("year:")]
                ev.append(f"year: series token {ser.group(0)!r} on cover (a year printed in the text is not the series)")
                year = str(yrs)
    if season == "UNKNOWN":
        sm = re.search(r"\b(Jun|June|Nov|November|Mar|March)\s*/?\s*\d{2}(?!\d)", text, re.I)
        if sm:
            head = sm.group(1).lower()
            season = "June" if head.startswith("jun") else "November" if head.startswith("nov") else "March"
            ev.append(f"season: compact token {sm.group(0)}")
    return season, year, ev


def _doc_type(text: str) -> tuple[str, List[str]]:
    low = text.lower()
    if "mark scheme" in low or "markscheme" in low:
        return "MS", ["document_type: mark scheme heading"]
    if "examiner report" in low or "report on the examination" in low or "examiners' report" in low:
        return "ER", ["document_type: examiner/report heading"]
    # A question paper's cover prints its own rubric -- "Time allowed: ...", "Instructions",
    # "Answer all questions" -- and it is this, not the word "insert", that decides. AQA's
    # 8700/2 June 2023 cover says "Source A and Source B - provided as a separate Insert." and
    # nothing else, so the old order typed the QUESTION PAPER as an insert (and the batch then
    # filed it under IN/, leaving every pack of that paper without its questions).
    if ("time allowed" in low or "instructions" in low or "question paper" in low
            or "answer all questions" in low or "answer one question" in low
            or "for examiner" in low):
        return "QP", ["document_type: question paper cover rubric"]
    if "insert" in low or "source booklet" in low or "resource booklet" in low:
        return "IN", ["document_type: insert/source booklet heading"]
    return "UNKNOWN", ["document_type: UNKNOWN"]


#: Text that only a Cambridge paper prints. Used by the legacy path (the one taken when the
#: adapters cannot be imported): without it, the AQA heuristic's coverage-code regex below
#: matched Cambridge's own cover code ("9706/32") and called a CAIE document AQA.
_CAMBRIDGE_SIGNATURES = ("cambridge international", "cambridge assessment",
                         "university of cambridge", "ucles")


def _looks_cambridge(text: str) -> bool:
    low = text.lower()
    return any(sig in low for sig in _CAMBRIDGE_SIGNATURES)


def _identify_cambridge(text: str) -> Optional[tuple[str, str, str, str, float, List[str]]]:
    """CAIE from its own printed signatures, with the syllabus code off the cover.

    The adapters are the authority and this never runs before them; it exists so the legacy
    fallback has *all* the boards, not three of five, and so a Cambridge document can never
    be typed by a heuristic that does not know Cambridge.
    """
    if not _looks_cambridge(text):
        return None
    dt, ev = _doc_type(text)
    season, year, sev = _season_year(text); ev += sev
    component = "UNKNOWN"
    syllabus = ""
    # Cambridge covers print "<syllabus>/<component>" ("9706/32", "0620/12"); the report's
    # own "Paper 9706/11" heading is the same shape and the first one on the page wins.
    m = re.search(r"\b(\d{4})\s*/\s*(\d{1,2})\b", text)
    if m:
        # the tuple's contract is a compound code ("8462/1H" from AQA, "9FM0/3C" from
        # Edexcel); identify_document_from_text splits the Cambridge one into the syllabus
        # code and the component number, exactly as the adapter path carries them
        syllabus, component = m.group(1), f"{m.group(1)}/{m.group(2)}"
        ev.append(f"component: {component} (Cambridge cover code)")
    confidence = 0.9 if component != "UNKNOWN" else 0.74
    ev.append("identified from Cambridge signatures in the document text")
    return "CAIE", dt, component, season, year, confidence, ev


def _identify_aqa(text: str) -> Optional[tuple[str, str, str, str, float, List[str]]]:
    low = text.lower()
    if _looks_cambridge(text):
        # Belt and braces: the caller tries Cambridge first, and this guard keeps a direct call
        # from re-introducing the defect (a Cambridge cover code read as an AQA component).
        return None
    if ("aqa" not in low and "aqa.org.uk" not in low
            and not re.search(r"\b\d{4}\s*/\s*[0-9A-Z]+\b", text)
            and "do not write" not in low):
        return None
    dt, ev = _doc_type(text)
    season, year, sev = _season_year(text); ev += sev
    component = "UNKNOWN"
    # AQA GCSE science and similar forms: 8462/1H; literature: 8702/1.
    m = re.search(r"\b(\d{4})\s*/\s*([0-9A-Z]+)\b", text)
    if m:
        component = f"{m.group(1)}/{m.group(2)}"; ev.append(f"component: {component}")
    confidence = 0.94 if component != "UNKNOWN" and dt in _DOC_TYPES else 0.78
    return "AQA", dt, component, season, year, confidence, ev


def _identify_edexcel(text: str) -> Optional[tuple[str, str, str, str, float, List[str]]]:
    low = text.lower()
    if "pearson edexcel" not in low and "edexcel" not in low:
        return None
    dt, ev = _doc_type(text)
    season, year, sev = _season_year(text); ev += sev
    component = "UNKNOWN"
    m = re.search(r"Paper Reference\s*([0-9A-Z]+\s*/\s*[0-9A-Z]+)", text, re.I)
    if not m:
        m = re.search(r"\b(9[A-Z0-9]{3}\s*/\s*[0-9A-Z]+)\b", text)
    if m:
        component = re.sub(r"\s+", "", m.group(1)); ev.append(f"component: {component}")
    confidence = 0.92 if component != "UNKNOWN" and dt in _DOC_TYPES else 0.76
    return "EDEXCEL", dt, component, season, year, confidence, ev


def _identify_ib(text: str) -> Optional[tuple[str, str, str, str, float, List[str]]]:
    low = text.lower()
    if "international baccalaureate" not in low and "ibo.org" not in low:
        return None
    dt, ev = _doc_type(text)
    season, year, sev = _season_year(text); ev += sev
    component = "UNKNOWN"
    m = re.search(r"\b(Paper\s*[0-9][A-Z]?)\b", text, re.I)
    if m:
        component = re.sub(r"\s+", " ", m.group(1)).title(); ev.append(f"component: {component}")
    confidence = 0.86 if component != "UNKNOWN" else 0.70
    return "IB", dt, component, season, year, confidence, ev


def identify_document_from_text(path: str | Path, text: str, sha256: str | None = None) -> DocumentIdentity:
    """Identify a document from trusted extracted text.

    Used by normal PDF text extraction and optional OCR fallback. The caller is
    still responsible for provenance: filenames are not used for identity.
    """
    p = Path(path)
    digest = sha256 or _sha256(p)
    for fn in (_identify_edexcel, _identify_cambridge, _identify_aqa, _identify_ib):
        got = fn(text)
        if got:
            board, dt, component, season, year, confidence, ev = got
            # Cambridge's syllabus half is its own field (the component alone cannot resolve a
            # subject), so carry it through exactly as the adapter path does.
            syllabus = ""
            if board == "CAIE" and component != "UNKNOWN" and "/" in component:
                head, _, tail = component.partition("/")
                if tail:
                    syllabus, component = head, tail
            return DocumentIdentity(str(p), digest, board, dt, component, season, year,
                                    confidence, ev, syllabus)
    dt, ev = _doc_type(text)
    season, year, sev = _season_year(text); ev += sev
    return DocumentIdentity(str(p), digest, "UNKNOWN", dt, "UNKNOWN", season, year, 0.30, ev)


def _best_evidence_value(evidence, field):
    """Highest-confidence non-null ``value`` for one evidence field."""
    best_conf = -1.0
    best_val = None
    for ev in evidence or []:
        if getattr(ev, "field", None) != field:
            continue
        val = getattr(ev, "value", None)
        if val is None:
            continue
        conf = float(getattr(ev, "confidence", 0.0) or 0.0)
        if conf > best_conf:
            best_conf, best_val = conf, val
    return best_val


def _identify_via_adapters(path: Path, digest: str) -> Optional[DocumentIdentity]:
    """Identify a document by asking the board adapters - the single authority.

    This module used to carry its own parallel heuristics
    (``_identify_aqa``/``_identify_edexcel``/``_identify_ib``) covering three of the
    five boards, so SAT and CAIE papers fell through as all-UNKNOWN and could never
    be associated. Measured: both real PSAT papers grouped as
    ``UNKNOWN|UNKNOWN|UNKNOWN|UNKNOWN``.

    The adapters cover all five boards and are the same code path the cropping
    dispatch uses, so identity here can never disagree with how a paper is actually
    cropped. Filenames are still never trusted - evidence comes from document text.

    Returns ``None`` when the adapters cannot decide, so the caller can fall back to
    the legacy heuristics rather than lose coverage.
    """
    try:
        from adapters.pipeline_dispatch import build_document_context, resolve_board
        from adapters.registry import get_adapter
    except Exception:  # adapters unavailable -> legacy path still works
        return None

    try:
        # Cover-page text decides board identity; no need to parse a 56-page PSAT.
        ctx = build_document_context(path, max_pages=3)
    except Exception:
        return None

    # floor=0.0: take the best board evidence even when weak, then record the
    # weakness in confidence so callers still see review_required.
    resolution = resolve_board(ctx, floor=0.0)
    if not resolution.board:
        return None
    adapter = get_adapter(resolution.board)
    if adapter is None:
        return None

    evidence: List[str] = list(resolution.evidence)

    def _ask(method_name: str, field: str):
        method = getattr(adapter, method_name, None)
        if method is None:
            return None
        try:
            return _best_evidence_value(method(ctx), field)
        except Exception:
            return None

    # Board-native fields come from the adapter too, never a second parser.
    document_type = _ask("identify_document_type", "document_type") or "UNKNOWN"

    # Cambridge covers print "<syllabus>/<component>" ("0980/01"), and its
    # adapter reports the four-digit syllabus half as its own field. The
    # component alone ("01") cannot resolve a subject, so carry the syllabus
    # code through when the adapter can see one.
    syllabus_code = ""
    try:
        syllabus_code = str(_best_evidence_value(adapter.identify_subject(ctx), "syllabus_code") or "")
    except Exception:
        syllabus_code = ""

    # Component granularity matters for grouping. Most boards have exactly one
    # component per paper, so "component" is the right key. A SAT/PSAT paper spans
    # FOUR modules, where a per-module id would let two different practice tests
    # merge - so adapters may expose a document-level "document_component" instead.
    _ask_doc_component = getattr(adapter, "identify_document_component", None)
    component = None
    if _ask_doc_component is not None:
        try:
            component = _best_evidence_value(_ask_doc_component(ctx), "document_component")
        except Exception:
            component = None
    if not component:
        component = _ask("identify_component", "component")
    component = component or "UNKNOWN"
    season = _ask("identify_session", "season") or "UNKNOWN"
    year = _ask("identify_session", "year")
    year = str(year) if year not in (None, "") else "UNKNOWN"

    # Canonical, never the raw code: the aliases are the adapter->association contract.
    dt_upper = canonical_document_type(document_type)
    if dt_upper != "UNKNOWN" and str(document_type).upper().lstrip("_") != dt_upper:
        evidence.append(f"adapter document_type={document_type!r} -> {dt_upper}")

    confidence = float(resolution.confidence or 0.0)
    evidence.append(f"identified via {resolution.board} adapter")

    return DocumentIdentity(
        str(path), digest, resolution.board, dt_upper,
        str(component), str(season), str(year), confidence, evidence,
        syllabus_code,
    )


def _merge_identity(primary: DocumentIdentity, filler: DocumentIdentity) -> DocumentIdentity:
    r"""``primary`` keeps the board; ``filler`` may only fill fields primary left UNKNOWN.

    Why this exists: the legacy heuristics are *more complete* than the adapters on some
    documents and *less correct*. Measured 2026-09-29 on Cambridge 9706/32 (Accounting):
    the adapter read board=CAIE, component=32, type=insert; the legacy AQA heuristic read
    board=AQA (its "\d{4}/\d+" coverage-code regex matches Cambridge's own cover code),
    component=9706/32, type=IN. Completeness won, so a Cambridge insert was filed under
    final/AQA/9706_32/. A board resolved from cover-page signatures by the adapter is an
    identification; a regex hit is a guess. The guess may fill a hole, never re-board.
    """
    def _take(value: str) -> str:
        return "" if value in (None, "", "UNKNOWN") else str(value)

    evidence = list(primary.evidence)
    if _take(filler.board) and _take(filler.board) != primary.board:
        evidence.append(f"legacy heuristic claimed board={filler.board} "
                        f"(rejected: the adapter resolved {primary.board} from the document)")
    document_type = _take(primary.document_type) or _take(filler.document_type) or "UNKNOWN"
    if _take(primary.document_type) == "" and _take(filler.document_type):
        evidence.append(f"document_type {filler.document_type} from the legacy heuristic")
    syllabus = _take(primary.syllabus_code)
    component = _take(primary.component)
    if not component:
        component = _take(filler.component) or "UNKNOWN"
        # The legacy heuristics keep the compound code ("9706/32"); the adapter path carries the
        # syllabus separately. Split it, so both identities describe the document the same way --
        # and if the adapter had no syllabus either, that hole is filled from the same code.
        if "/" in component:
            head, _, tail = component.partition("/")
            if tail and re.fullmatch(r"\d{4}", head) and (not syllabus or head == syllabus):
                component, syllabus = tail, (syllabus or head)
        if component != "UNKNOWN":
            evidence.append(f"component {component} from the legacy heuristic")
        if syllabus and not _take(primary.syllabus_code):
            evidence.append(f"syllabus_code {syllabus} from the legacy heuristic")
    season = _take(primary.season) or _take(filler.season) or "UNKNOWN"
    year = _take(primary.year) or _take(filler.year) or "UNKNOWN"
    confidence = max(float(primary.confidence or 0.0), 0.0)
    return DocumentIdentity(primary.path, primary.sha256, primary.board, document_type,
                            component, season, year, confidence, evidence, syllabus)


def identify_document(path: str | Path) -> DocumentIdentity:
    """Identify a document, preferring the board adapters.

    Order: adapters (all five boards, one authority) -> legacy text heuristics
    (three boards, kept so an adapter failure cannot lose coverage). When both speak, the
    adapter keeps the board and the heuristic fills only what the adapter left UNKNOWN.
    """
    p = Path(path)
    digest = _sha256(p)

    via_adapter = _identify_via_adapters(p, digest)
    if via_adapter is not None and "UNKNOWN" not in (
        via_adapter.board, via_adapter.document_type, via_adapter.component,
    ):
        return via_adapter

    text = _first_text(p)
    fallback = identify_document_from_text(p, text, sha256=digest)
    if via_adapter is not None and via_adapter.board not in ("", "UNKNOWN"):
        # Adapter knew the board -- it keeps it, whatever the heuristic thinks.
        if "UNKNOWN" in (via_adapter.document_type, via_adapter.component, via_adapter.season,
                         via_adapter.year) and fallback.board != "UNKNOWN":
            return _merge_identity(via_adapter, fallback)
        return via_adapter
    return fallback


def associate_documents(paths: Iterable[str | Path]) -> Dict[str, dict]:
    groups: Dict[str, dict] = {}
    for path in paths:
        ident = identify_document(path)
        key = ident.association_key
        group = groups.setdefault(key, {
            "association_key": key,
            "board": ident.board,
            "component": ident.component,
            "season": ident.season,
            "year": ident.year,
            "documents": {},
            "review_required": False,
            "notes": [],
        })
        bucket = ident.document_type if ident.document_type in _DOC_TYPES else "UNKNOWN"
        group["documents"].setdefault(bucket, []).append(asdict(ident))
        if "UNKNOWN" in (ident.board, ident.document_type, ident.component, ident.season, ident.year):
            group["review_required"] = True
            group["notes"].append("identity has UNKNOWN fields; do not auto-merge without review")
    for group in groups.values():
        if "QP" not in group["documents"]:
            group["review_required"] = True
            group["notes"].append("no question paper in association group")
        for dt, docs in list(group["documents"].items()):
            if len(docs) > 1:
                group["review_required"] = True
                group["notes"].append(f"multiple {dt} documents in one association group")
    return groups


def write_association_manifest(paths: Iterable[str | Path], out_path: str | Path) -> Path:
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "manifest_version": 1,
        "source": "adapters.associations.write_association_manifest",
        "groups": associate_documents(paths),
    }
    out.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    return out
