"""Small helpers shared by non-CAIE adapters.

These helpers operate only on a ``DocumentContext.layout`` prepared upstream or
on text already present in the context. They do not open or OCR PDFs.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Sequence


def pages_from_layout(ctx: Any) -> List[Dict[str, Any]]:
    pages = (getattr(ctx, "layout", None) or {}).get("pages")
    return pages if isinstance(pages, list) else []


def page_texts(ctx: Any) -> List[str]:
    pages = pages_from_layout(ctx)
    if pages and all(isinstance(p.get("text"), str) for p in pages):
        return [p.get("text", "") for p in pages]
    # Fallback convention used by our tooling: form-feed separates pages.
    text = getattr(ctx, "full_text", "") or ""
    if "\f" in text:
        return text.split("\f")
    return [text]


def first_line_y(ctx: Any, page_index: int, pattern: str, *, flags: int = re.I) -> Optional[float]:
    """Return the y0 of the first layout line whose text matches pattern."""
    pages = pages_from_layout(ctx)
    if not (0 <= page_index < len(pages)):
        return None
    rx = re.compile(pattern, flags)
    for line in pages[page_index].get("lines") or []:
        text = str(line.get("text", ""))
        if rx.search(text):
            bbox = line.get("bbox") or line.get("rect")
            if bbox and len(bbox) == 4:
                return float(bbox[1])
    return None


def line_ys(ctx: Any, page_index: int, pattern: str, *, flags: int = re.I) -> List[float]:
    pages = pages_from_layout(ctx)
    if not (0 <= page_index < len(pages)):
        return []
    rx = re.compile(pattern, flags)
    out: List[float] = []
    for line in pages[page_index].get("lines") or []:
        text = str(line.get("text", ""))
        if rx.search(text):
            bbox = line.get("bbox") or line.get("rect")
            if bbox and len(bbox) == 4:
                out.append(float(bbox[1]))
    return out


def page_size(ctx: Any, page_index: int) -> tuple[float, float]:
    pages = pages_from_layout(ctx)
    if 0 <= page_index < len(pages):
        size = pages[page_index].get("size") or pages[page_index].get("page_size")
        if size and len(size) == 2:
            return float(size[0]), float(size[1])
    # conservative fallback for A4-ish documents
    return 595.0, 842.0


def full_page_clip(ctx: Any, page_index: int, *, left: float = 0, top: float = 0,
                   right: float = 0, bottom: float = 0) -> tuple[float, float, float, float]:
    w, h = page_size(ctx, page_index)
    return (float(left), float(top), max(float(left) + 1, w - float(right)), max(float(top) + 1, h - float(bottom)))
