"""Universal paper-layout profile registry for board adapters.

This is NOT a crop engine. It is a small decision layer that names the layout
archetype a board adapter has detected, and states which boundary detector should
be used before handing page rectangles to the shared gold-geometry bridge.

The goal is to avoid the old false assumption that every paper looks like a
Cambridge science/math structured paper. Different boards and subjects have
stable layout families: MCQ grids, numbered structured questions, extract-based
literature alternatives, essay prompt lists, source-booklet papers, practical
papers, and Edexcel-style answer-space booklets with printed gutter ink.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional


class LayoutArchetype(str, Enum):
    # Cambridge / CAIE families
    CAIE_NUMBERED_STRUCTURED = "caie_numbered_structured"
    CAIE_MCQ_NUMBERED = "caie_mcq_numbered"
    CAIE_PRACTICAL_STRUCTURED = "caie_practical_structured"
    CAIE_ESSAY_OR_RUBRIC = "caie_essay_or_rubric"
    CAIE_SOURCE_INSERT = "caie_source_insert"

    # AQA families
    AQA_ALT_EXTRACT_ONE_PAGE = "aqa_alt_extract_one_page"
    AQA_NUMBERED_BOXED_STRUCTURED = "aqa_numbered_boxed_structured"
    AQA_ESSAY_PROMPT_LIST = "aqa_essay_prompt_list"
    AQA_SOURCE_INSERT = "aqa_source_insert"
    #: AQA mark schemes are not question pages: one bordered table per paper,
    #: one row per sub-part (01.1..NN.M), sub-part number in a narrow left column.
    AQA_MS_SUB_PART_TABLE = "aqa_ms_sub_part_table"

    # Pearson Edexcel families
    EDEXCEL_GUTTER_NUMBERED_BOOKLET = "edexcel_gutter_numbered_booklet"
    EDEXCEL_GRID_OR_BOX_STRUCTURED = "edexcel_grid_or_box_structured"
    EDEXCEL_ESSAY_PROMPT_LIST = "edexcel_essay_prompt_list"
    EDEXCEL_SOURCE_INSERT = "edexcel_source_insert"

    # IB families
    IB_ESSAY_PROMPT_LIST = "ib_essay_prompt_list"
    IB_MCQ_PAPER_1A = "ib_mcq_paper_1a"
    IB_DATA_RESPONSE = "ib_data_response"
    IB_TEXT_BOOKLET = "ib_text_booklet"
    # IB mark schemes: question number in the left margin, one answer+marks block
    # per sub-part, closed by a "Total [n marks]" row. Same role as
    # AQA_MS_SUB_PART_TABLE for AQA.
    IB_MS_ANSWER_COLUMN = "ib_ms_answer_column"

    # Fallback / non-rendering
    TEXT_ONLY_OFFICIAL_SOURCE = "text_only_official_source"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class LayoutProfile:
    archetype: LayoutArchetype
    boundary_detector: str
    geometry: str = "shared_gold_geometry_bridge"
    ms_policy: str = "board_specific"
    insert_policy: str = "board_specific"
    verified_on_real_pdf: bool = False
    notes: str = ""


PROFILES: Dict[LayoutArchetype, LayoutProfile] = {
    LayoutArchetype.CAIE_NUMBERED_STRUCTURED: LayoutProfile(
        LayoutArchetype.CAIE_NUMBERED_STRUCTURED,
        "locked_gold_question_split",
        geometry="locked_caie_production_geometry",
        ms_policy="structured_ms_gold_or_legacy_portrait_fallback",
        verified_on_real_pdf=True,
        notes="Cambridge numbered QP families: science, maths, CS, accounting, economics structured papers.",
    ),
    LayoutArchetype.CAIE_MCQ_NUMBERED: LayoutProfile(
        LayoutArchetype.CAIE_MCQ_NUMBERED,
        "locked_gold_or_vector_first_numbered_mcq",
        geometry="locked_caie_production_geometry",
        ms_policy="answer_grid_txt_sidecar_only",
        verified_on_real_pdf=True,
        notes="Cambridge MCQ papers: numbered stems; MS is grid extraction, not MS WebP.",
    ),
    LayoutArchetype.CAIE_PRACTICAL_STRUCTURED: LayoutProfile(
        LayoutArchetype.CAIE_PRACTICAL_STRUCTURED,
        "locked_gold_numbered_structured_for_validated_practical_profiles",
        geometry="locked_caie_production_geometry",
        ms_policy="structured_ms_gold",
        verified_on_real_pdf=True,
        notes="IGCSE science Paper 5/6 practical/ATP content but numbered structured raster grammar.",
    ),
    LayoutArchetype.CAIE_ESSAY_OR_RUBRIC: LayoutProfile(
        LayoutArchetype.CAIE_ESSAY_OR_RUBRIC,
        "essay_prompt_or_rubric_detector_review_gated",
        verified_on_real_pdf=False,
        notes="History, literature, sociology and language essay/rubric papers need prompt-level boundaries, not science table assumptions.",
    ),
    LayoutArchetype.CAIE_SOURCE_INSERT: LayoutProfile(
        LayoutArchetype.CAIE_SOURCE_INSERT,
        "locked_insert_engine_or_sidecar_copy",
        geometry="insert_engine_2280_width",
        insert_policy="whole_page_and_referenced_section_sidecars",
        verified_on_real_pdf=True,
        notes="Source/booklet material is attached as _IN/_CI sidecars, not question crops.",
    ),
    LayoutArchetype.AQA_ALT_EXTRACT_ONE_PAGE: LayoutProfile(
        LayoutArchetype.AQA_ALT_EXTRACT_ONE_PAGE,
        "aqa_extract_alternative_page_detector",
        verified_on_real_pdf=True,
        notes="AQA English Literature 8702/1: contents table excluded; each EITHER/OR extract alternative is one crop.",
    ),
    LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED: LayoutProfile(
        LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED,
        "aqa_numbered_question_box_detector",
        verified_on_real_pdf=False,
        notes="AQA science/maths: numbered question starts plus answer boxes; do not treat AQA inserts as CAIE data booklets.",
    ),
    LayoutArchetype.AQA_ESSAY_PROMPT_LIST: LayoutProfile(
        LayoutArchetype.AQA_ESSAY_PROMPT_LIST,
        "aqa_prompt_list_detector",
        verified_on_real_pdf=False,
        notes="AQA history/essay papers: prompt lists and source/stimulus sections must be kept with the owning question.",
    ),
    LayoutArchetype.AQA_SOURCE_INSERT: LayoutProfile(
        LayoutArchetype.AQA_SOURCE_INSERT,
        "aqa_source_material_sidecar_detector",
        verified_on_real_pdf=False,
        notes="AQA source material/insert pages are sidecars unless explicitly part of a question region.",
    ),
    LayoutArchetype.AQA_MS_SUB_PART_TABLE: LayoutProfile(
        LayoutArchetype.AQA_MS_SUB_PART_TABLE,
        "aqa_ms_sub_part_row_detector",
        ms_policy="sub_part_row_table_segmented_by_aqa_adapter",
        verified_on_real_pdf=True,
        notes="AQA mark schemes: a bordered table where each row is headed by its sub-part number, so a question is the run of consecutive rows sharing a number. Front-matter NN.N paragraphs are not rows.",
    ),
    LayoutArchetype.EDEXCEL_GUTTER_NUMBERED_BOOKLET: LayoutProfile(
        LayoutArchetype.EDEXCEL_GUTTER_NUMBERED_BOOKLET,
        "edexcel_numbered_start_plus_continuation_detector_with_gutter_exclusion",
        verified_on_real_pdf=True,
        notes="Edexcel printed DO NOT WRITE gutter ink and page-reference codes are excluded before geometry.",
    ),
    LayoutArchetype.EDEXCEL_GRID_OR_BOX_STRUCTURED: LayoutProfile(
        LayoutArchetype.EDEXCEL_GRID_OR_BOX_STRUCTURED,
        "edexcel_numbered_box_detector",
        verified_on_real_pdf=False,
        notes="Edexcel GCSE/IAL science and maths can use boxed response areas without the 9FM0 gutter geometry.",
    ),
    LayoutArchetype.EDEXCEL_ESSAY_PROMPT_LIST: LayoutProfile(
        LayoutArchetype.EDEXCEL_ESSAY_PROMPT_LIST,
        "edexcel_prompt_list_detector",
        verified_on_real_pdf=False,
        notes="Edexcel humanities/languages use prompt and source structures rather than continuous calculation answer-space booklets.",
    ),
    LayoutArchetype.EDEXCEL_SOURCE_INSERT: LayoutProfile(
        LayoutArchetype.EDEXCEL_SOURCE_INSERT,
        "edexcel_source_booklet_sidecar_detector",
        verified_on_real_pdf=False,
    ),
    LayoutArchetype.IB_ESSAY_PROMPT_LIST: LayoutProfile(
        LayoutArchetype.IB_ESSAY_PROMPT_LIST,
        "ib_prompt_list_detector",
        verified_on_real_pdf=False,
        notes="IB English A Paper 2 specimen: four prompts; direct PDF binary remains access-blocked in this sandbox.",
    ),
    LayoutArchetype.IB_MCQ_PAPER_1A: LayoutProfile(
        LayoutArchetype.IB_MCQ_PAPER_1A,
        "ib_mcq_numbered_option_detector",
        ms_policy="answer_grid_or_markscheme_table_by_ib_component",
        verified_on_real_pdf=False,
        notes="IB science Paper 1A MCQ: count comes from paper/level, not Cambridge registry.",
    ),
    LayoutArchetype.IB_DATA_RESPONSE: LayoutProfile(
        LayoutArchetype.IB_DATA_RESPONSE,
        "ib_numbered_data_response_detector",
        verified_on_real_pdf=False,
        notes="IB Paper 1B/Paper 2 data-response / structured questions with IB-native headers and data booklets.",
    ),
    LayoutArchetype.IB_TEXT_BOOKLET: LayoutProfile(
        LayoutArchetype.IB_TEXT_BOOKLET,
        "ib_text_booklet_sidecar_detector",
        verified_on_real_pdf=False,
    ),
    LayoutArchetype.IB_MS_ANSWER_COLUMN: LayoutProfile(
        LayoutArchetype.IB_MS_ANSWER_COLUMN,
        "ib_ms_question_number_column_detector",
        ms_policy="question_number_column_segmented_by_ib_adapter",
        verified_on_real_pdf=True,
        notes=("IB markscheme: question number at x0 42.6-50.2 in the left margin, "
               "mark codes in the right column, question closed by a Total [n marks] row. "
               "Verified on the mirror-sourced May 2024 AA HL Paper 1 markscheme, 2026-09-21."),
    ),
    LayoutArchetype.TEXT_ONLY_OFFICIAL_SOURCE: LayoutProfile(
        LayoutArchetype.TEXT_ONLY_OFFICIAL_SOURCE,
        "text_prompt_detector_non_renderable",
        geometry="not_renderable_until_pdf_binary_available",
        verified_on_real_pdf=False,
        notes="Official text accessible but PDF binary absent; identity/segmentation only, no crop claim.",
    ),
    LayoutArchetype.UNKNOWN: LayoutProfile(
        LayoutArchetype.UNKNOWN,
        "review_required_no_detector",
        geometry="none",
        verified_on_real_pdf=False,
        notes="Fail closed; do not crop by guessing.",
    ),
}


def get_profile(archetype: LayoutArchetype | str) -> LayoutProfile:
    if isinstance(archetype, LayoutArchetype):
        key = archetype
    else:
        key = LayoutArchetype(str(archetype))
    return PROFILES[key]


def select_layout_archetype(board_id: str, ctx: Any) -> LayoutArchetype:
    """Best-effort, fail-closed layout family selection from already prepared context.

    Adapters may override with stronger board-specific knowledge, but this gives
    the universal router a consistent language across boards/subjects.
    """
    board = str(board_id or "").upper()
    text = f"{getattr(ctx, 'filename', '')}\n{getattr(ctx, 'first_page_text', '')}\n{getattr(ctx, 'full_text', '')}".lower()

    if board == "AQA":
        # Checked before the question-paper signatures: a mark scheme carries
        # "mark scheme" on its cover and none of the QP signatures, so this cannot
        # reclassify a question paper.
        if "mark scheme" in text:
            return LayoutArchetype.AQA_MS_SUB_PART_TABLE
        if "read the following extract" in text and ("either" in text or " or " in text):
            return LayoutArchetype.AQA_ALT_EXTRACT_ONE_PAGE
        if "source material" in text or "insert" in text:
            return LayoutArchetype.AQA_SOURCE_INSERT
        if "do not write outside the box" in text or "answer all questions in the spaces provided" in text:
            return LayoutArchetype.AQA_NUMBERED_BOXED_STRUCTURED
        if "answer one question" in text:
            return LayoutArchetype.AQA_ESSAY_PROMPT_LIST
        return LayoutArchetype.UNKNOWN

    if board == "EDEXCEL":
        if "do not write in this area" in text:
            return LayoutArchetype.EDEXCEL_GUTTER_NUMBERED_BOOKLET
        if "source booklet" in text or "source material" in text:
            return LayoutArchetype.EDEXCEL_SOURCE_INSERT
        if "answer all questions" in text or "write your answers in the spaces provided" in text:
            return LayoutArchetype.EDEXCEL_GRID_OR_BOX_STRUCTURED
        if "answer one" in text or "essay" in text:
            return LayoutArchetype.EDEXCEL_ESSAY_PROMPT_LIST
        return LayoutArchetype.UNKNOWN

    if board == "IB":
        if getattr(ctx, "suffix", "").lower() in {".md", ".txt"}:
            return LayoutArchetype.TEXT_ONLY_OFFICIAL_SOURCE
        # Checked before the question-paper signatures, exactly as in the AQA
        # branch: a markscheme prints "Markscheme" on its cover and none of the
        # question-paper signatures, so this cannot reclassify a question paper.
        if "markscheme" in text or "marking notes" in text:
            return LayoutArchetype.IB_MS_ANSWER_COLUMN
        if "paper 1a" in text and "choose the answer" in text:
            return LayoutArchetype.IB_MCQ_PAPER_1A
        if "answer one question" in text:
            return LayoutArchetype.IB_ESSAY_PROMPT_LIST
        if "data booklet" in text or "paper 1b" in text or "paper 2" in text:
            return LayoutArchetype.IB_DATA_RESPONSE
        return LayoutArchetype.UNKNOWN

    if board == "CAIE":
        if "insert" in text or "source booklet" in text or "confidential instructions" in text:
            return LayoutArchetype.CAIE_SOURCE_INSERT
        if "multiple choice" in text or "choose the answer" in text:
            return LayoutArchetype.CAIE_MCQ_NUMBERED
        if "practical" in text or "alternative to practical" in text:
            return LayoutArchetype.CAIE_PRACTICAL_STRUCTURED
        if "answer one" in text or "essay" in text or "source" in text:
            return LayoutArchetype.CAIE_ESSAY_OR_RUBRIC
        return LayoutArchetype.CAIE_NUMBERED_STRUCTURED

    return LayoutArchetype.UNKNOWN


def crop_plan(board_id: str, ctx: Any) -> Dict[str, Any]:
    arch = select_layout_archetype(board_id, ctx)
    profile = get_profile(arch)
    return {
        "board_id": str(board_id).upper(),
        "archetype": profile.archetype.value,
        "boundary_detector": profile.boundary_detector,
        "geometry": profile.geometry,
        "ms_policy": profile.ms_policy,
        "insert_policy": profile.insert_policy,
        "verified_on_real_pdf": profile.verified_on_real_pdf,
        "notes": profile.notes,
    }


__all__ = ["LayoutArchetype", "LayoutProfile", "PROFILES", "get_profile", "select_layout_archetype", "crop_plan"]
