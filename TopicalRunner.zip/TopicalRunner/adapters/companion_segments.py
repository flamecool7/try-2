"""Question-level companion extraction for non-CAIE board documents.

This is deliberately conservative. It only splits companions where headings are
visible in the PDF text/layout stream (for example, AQA ``Question 1`` mark
scheme sections or ER question headings). Ambiguous or unheaded content is left
for REVIEW_REQUIRED instead of guessed.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import re
from typing import Any, Dict, Iterable, List, Tuple

from adapters.base import DocumentContext
from adapters.common_text import page_size


@dataclass(frozen=True)
class TextCompanion:
    question_number: int
    canonical_question: str
    text: str
    pages: List[int]
    confidence: float
    reason: str


#: an insert/source heading at the start of a line ("Source A", "Figure 1", "Case Study 2")
_INSERT_LABEL_RE = re.compile(r"^\s*(?:Source|Extract|Figure|Fig\.?|Item|Case\s*Study|Case|"
                              r"Stimulus|Exhibit|Table|Diagram|Photo|Map|Chart)\s+[A-Z]\b|"
                              r"^\s*(?:Source|Extract|Figure|Fig\.?|Item|Case\s*Study|Case|"
                              r"Stimulus|Exhibit|Table|Diagram|Photo|Map|Chart)\s+\d{1,3}\b", re.I)

#: "Question 3", "Q3", "Q 3", "(a) Question 3" *anywhere* in a line -- a mention, not necessarily a
#: heading. Only used by the examiner-report fallback, and only when the mentions run in order.
_ER_MENTION_RE = re.compile(r"\b(?:Questions?|Q)\s*0?(\d{1,2})\b")


def _question_heading(text: str) -> int | None:
    t = " ".join(str(text).strip().split())
    patterns = (
        r"^Question\s+0?(\d{1,2})\b",
        r"^Q(?:uestion)?\s*0?(\d{1,2})\b",
    )
    for pat in patterns:
        m = re.search(pat, t, re.I)
        if m:
            return int(m.group(1))
    return None


def _subpart_question(text: str) -> int | None:
    t = " ".join(str(text).strip().split())
    m = re.match(r"^0?(\d{1,2})\s*\.\s*\d+\b", t)
    if m:
        return int(m.group(1))
    return None


def _line_starts(ctx: DocumentContext) -> List[Tuple[int, float, int, str, str]]:
    """Return question-section starts as (page, y, qn, kind, text)."""
    starts: List[Tuple[int, float, int, str, str]] = []
    pages = (ctx.layout or {}).get("pages") or []
    seen_heading: set[int] = set()
    first_subpart: set[int] = set()
    for page in pages:
        pi = int(page.get("page_index", 0))
        for line in page.get("lines") or []:
            txt = str(line.get("text", "")).strip()
            bbox = line.get("bbox") or []
            if len(bbox) != 4:
                continue
            y0 = float(bbox[1])
            hq = _question_heading(txt)
            if hq is not None:
                starts.append((pi, y0, hq, "heading", txt))
                seen_heading.add(hq)
                continue
            sq = _subpart_question(txt)
            # Fallback only if no explicit heading for this qn has appeared;
            # AQA/Edexcel mark schemes often repeat 01.1 rows under a section.
            if sq is not None and sq not in seen_heading and sq not in first_subpart:
                starts.append((pi, y0, sq, "subpart_fallback", txt))
                first_subpart.add(sq)
    # Prefer explicit headings. If a document has any explicit Question N
    # headings, do not use numeric subpart fallbacks; table values such as
    # 16.8 or 22.7 can otherwise look like question labels.
    explicit = {qn for _, _, qn, kind, _ in starts if kind == "heading"}
    if explicit:
        filtered = [s for s in starts if s[3] == "heading"]
    else:
        filtered = list(starts)
    filtered.sort(key=lambda t: (t[0], t[1], t[2]))
    # Deduplicate repeated headings/headers for same qn at near-identical spots.
    dedup: List[Tuple[int, float, int, str, str]] = []
    for st in filtered:
        if dedup and st[2] == dedup[-1][2] and st[0] == dedup[-1][0] and abs(st[1] - dedup[-1][1]) < 8:
            continue
        # Ignore duplicate later subparts/headers for same qn if a start exists.
        if any(prev[2] == st[2] for prev in dedup):
            continue
        dedup.append(st)
    return dedup


def _insert_label_starts(ctx: DocumentContext) -> List[Tuple[int, float, str]]:
    """(page, y, label) for every "Source A" / "Figure 1" / "Case Study 2" heading, in reading order."""
    pages = (ctx.layout or {}).get("pages") or []
    labels: List[Tuple[int, float, str]] = []
    for page in pages:
        pi = int(page.get("page_index", 0))
        for line in page.get("lines") or []:
            txt = " ".join(str(line.get("text", "")).split())
            bbox = line.get("bbox") or []
            if len(bbox) != 4 or not txt:
                continue
            if _INSERT_LABEL_RE.search(txt):
                labels.append((pi, float(bbox[1]), txt))
    labels.sort(key=lambda t: (t[0], t[1]))
    dedup: List[Tuple[int, float, str]] = []
    for item in labels:
        if dedup and item[2].casefold() == dedup[-1][2].casefold():
            continue                     # the same heading repeated in a running header
        dedup.append(item)
    return dedup


def _bare_heading_question(text: str) -> int | None:
    """The question number when the line *is* a heading -- "Question 3", "Q3", "Question 3:" -- else None.

    "Question 4 was the weakest answered on the paper." is prose that happens to start with the same
    words, and treating the two identically is how a report's summary paragraph becomes a section
    boundary. Headings end quickly; prose keeps going.
    """
    t = " ".join(str(text).strip().split())
    m = re.match(r"^(?:Questions?|Q)\s*0?(\d{1,2})\b", t, re.I)
    if not m:
        return None
    tail = t[m.end():].strip(" .:–-—()[]")
    return int(m.group(1)) if len(tail) <= 3 else None


def _er_question_mentions(ctx: DocumentContext) -> List[Tuple[int, float, int, bool]]:
    """(page, y, question number) for every line that *mentions* a question, headings or not.

    An examiner report is prose: the heading is often just "Question 3" in bold, but plenty of real
    reports open a paragraph with "Question 3 was answered well…" or list "Q3 (a)" inside a table.
    This finds all of them; the caller decides which ones may start a section.
    """
    pages = (ctx.layout or {}).get("pages") or []
    hits: List[Tuple[int, float, int, bool]] = []
    for page in pages:
        pi = int(page.get("page_index", 0))
        for line in page.get("lines") or []:
            txt = " ".join(str(line.get("text", "")).split())
            bbox = line.get("bbox") or []
            if len(bbox) != 4 or not txt:
                continue
            bare = _bare_heading_question(txt)
            if bare is not None:
                hits.append((pi, float(bbox[1]), bare, True))
                continue
            m = _ER_MENTION_RE.search(txt)
            if m:
                hits.append((pi, float(bbox[1]), int(m.group(1)), False))
    return sorted(hits, key=lambda t: (t[0], t[1], t[2]))


def segment_examiner_report(ctx: DocumentContext, board: str = "",
                            known_questions: Iterable[int] | None = None
                            ) -> List[Dict[str, Any]]:
    """Per-question examiner-report segments, renderable exactly like a mark scheme crop.

    Two passes, and the second one only ever *fills gaps the first left*:

    1. **Explicit headings** (``Question 3``, ``Q3``) — the confident case, one section each.
    2. **Mentions** (``Question 3 was…``, a ``Q3`` cell in a table) — used only for question numbers
       that had no heading anywhere in the report, and only when the mention is *monotone* through
       the document: a report that walks 1, 2, 3, 4 in order can have its bands cut at those rows,
       while one that jumps backwards (a summary table listing Q4 before Q2) cannot and is left alone.

    ``known_questions`` (the numbers the matching question paper actually has) is an optional
    guard-rail: when supplied, a mention for a number that is not a question on the paper is ignored.
    """
    pages = (ctx.layout or {}).get("pages") or []
    if not pages:
        return []
    allowed = {int(q) for q in known_questions} if known_questions else None

    all_hits = _er_question_mentions(ctx)
    confidence_of: Dict[int, float] = {}
    starts: List[Tuple[int, float, int]] = []
    seen: set[int] = set()
    for page, y, qn, is_heading in all_hits:
        if not is_heading:
            continue
        if allowed is not None and qn not in allowed:
            continue
        if qn in seen:
            continue                     # first heading wins; later repeats are sub-sections
        seen.add(qn)
        starts.append((page, y, qn))
        confidence_of[qn] = 0.9

    missing = sorted((allowed or set()) - seen) if allowed else []
    if missing or not starts:
        wanted = missing or None
        picked: List[Tuple[int, float, int]] = []
        picked_seen: set[int] = set()
        last_qn = 0
        last_pos = (-1, -1.0)
        for page, y, qn, _is_heading in all_hits:
            if qn in seen or qn in picked_seen or (wanted is not None and qn not in wanted):
                continue
            if (page, y) <= last_pos:
                continue
            if qn < last_qn:
                continue                 # not monotone: this report does not walk its questions
            picked.append((page, y, qn))
            picked_seen.add(qn)          # a report that says "Question 4" twice gets ONE section
            last_qn, last_pos = qn, (page, y)
        for page, y, qn in picked:
            starts.append((page, y, qn))
            # a sentence that merely mentions the question: usable as a boundary, never claimed exact
            confidence_of[qn] = 0.6

    starts.sort(key=lambda t: (t[0], t[1]))
    out: List[Dict[str, Any]] = []
    for idx, (start_page, start_y, qn) in enumerate(starts):
        nxt = starts[idx + 1] if idx + 1 < len(starts) else None
        seg_pages = _section_bands(ctx, start_page, start_y, nxt)
        if not seg_pages:
            continue
        out.append({
            "id": f"ER_Q{qn}",
            "question_number": qn,
            "canonical_question": f"Q{qn}",
            "board": board.upper() if board else "UNKNOWN",
            "pages": seg_pages,
            "metadata": {
                "document_type": "ER",
                "question_level_companion": True,
                "split_kind": "heading" if confidence_of.get(qn, 0) >= 0.9 else "question_mention",
                "match_confidence": confidence_of.get(qn, 0.6),
                "layout_archetype": "companion_examiner_report_question_sections",
                "crop_plan": {"delegate": "locked_gold_geometry_bridge",
                              "source": "companion_segments.segment_examiner_report"},
            },
        })
    return out


def segment_insert_sources(ctx: DocumentContext, board: str = "") -> List[Dict[str, Any]]:
    """Per-label insert/source segments, renderable exactly like a mark scheme crop.

    One segment per "Source A"/"Figure 1"/"Case Study 2" block, so each question that names a source
    can be handed that source's own crop instead of the whole booklet.
    """
    pages = (ctx.layout or {}).get("pages") or []
    labels = _insert_label_starts(ctx)
    out: List[Dict[str, Any]] = []
    for idx, (sp, sy, label) in enumerate(labels):
        nxt = labels[idx + 1] if idx + 1 < len(labels) else None
        ep = nxt[0] if nxt else len(pages) - 1
        seg_pages = _section_bands(ctx, sp, sy, nxt)
        if not seg_pages:
            continue
        out.append({
            "id": _insert_id(label),
            "label": label,
            "question_number": None,          # a source is not a question; the link does that
            "canonical_question": label,
            "board": board.upper() if board else "UNKNOWN",
            "pages": seg_pages,
            "metadata": {
                "document_type": "IN",
                "source_label": label,
                "layout_archetype": "companion_insert_source_section",
                "crop_plan": {"delegate": "locked_gold_geometry_bridge",
                              "source": "companion_segments.segment_insert_sources"},
            },
        })
    return out


#: A band thinner than this is page furniture (usually the blank strip above the next heading), not
#: content — the fixture rounds prove it: a two-page insert produced a 20 px sliver for "Source A" on
#: the page where "Source B" starts. Not worth a crop.
_MIN_BAND_PX = 60.0


def _section_bands(ctx: DocumentContext, start_page: int, start_y: float,
                   nxt: Tuple[int, float, int] | None) -> List[Dict[str, Any]]:
    """Page bands for one section: from its heading to the next section's heading (or the last page)."""
    pages = (ctx.layout or {}).get("pages") or []
    end_page = nxt[0] if nxt else len(pages) - 1
    bands: List[Dict[str, Any]] = []
    for p in range(start_page, end_page + 1):
        w, h = page_size(ctx, p)
        top = max(36.0, start_y - 12.0) if p == start_page else 42.0
        bottom = h - 42.0
        if nxt and p == nxt[0]:
            bottom = min(h - 42.0, max(top, nxt[1] - 12.0))
        if bottom - top < (0.0 if p == start_page else _MIN_BAND_PX):
            continue
        bands.append({"page_index": p, "rect": (34.0, top, w - 34.0, bottom)})
    return bands


def _insert_id(label: str) -> str:
    return "IN_" + "".join(c if c.isalnum() else "_" for c in label).strip("_")[:40]


def segment_mark_scheme(ctx: DocumentContext, board: str = "") -> List[Dict[str, Any]]:
    """Split a mark scheme into per-question renderable segments.

    Returns adapter-like segment dicts so callers can reuse the locked geometry
    bridge. The split is question-level, not subpart-level; that is the safest
    common denominator for AQA/Edexcel table-style schemes.
    """
    starts = _line_starts(ctx)
    if not starts:
        return []
    pages = (ctx.layout or {}).get("pages") or []
    out: List[Dict[str, Any]] = []
    for idx, (start_page, start_y, qn, kind, evidence) in enumerate(starts):
        next_start = starts[idx + 1] if idx + 1 < len(starts) else None
        end_page = (next_start[0] if next_start else len(pages) - 1)
        seg_pages = []
        for p in range(start_page, end_page + 1):
            w, h = page_size(ctx, p)
            top = max(36.0, start_y - 12.0) if p == start_page else 42.0
            bottom = h - 42.0
            if next_start and p == next_start[0]:
                bottom = max(top + 20.0, next_start[1] - 12.0)
            # Full table body, excluding page furniture.
            seg_pages.append({"page_index": p, "rect": (34.0, top, w - 34.0, bottom)})
        out.append({
            "id": f"MS_Q{qn}",
            "question_number": qn,
            "canonical_question": f"Q{qn}",
            "board": board.upper() if board else "UNKNOWN",
            "pages": seg_pages,
            "metadata": {
                "document_type": "MS",
                "question_level_companion": True,
                "split_evidence": evidence,
                "split_kind": kind,
                "layout_archetype": "companion_mark_scheme_question_sections",
                "crop_plan": {"delegate": "locked_gold_geometry_bridge", "source": "companion_segments.segment_mark_scheme"},
            },
        })
    return out


def extract_insert_sources(ctx: DocumentContext, board: str = "") -> List[TextCompanion]:
    """Index labelled source/insert material without assigning it blindly.

    This detects labels such as Source A, Extract B, Figure 1, or Item A and
    captures text until the next label. The result is a source index; attaching
    a source to a particular question remains a separate verified mapping step.
    """
    pages = (ctx.layout or {}).get("pages") or []
    labels: List[Tuple[int, float, str]] = []
    label_re = re.compile(r"^(Source|Extract|Figure|Fig\.|Item)\s+([A-Z]|\d{1,2})\b", re.I)
    for page in pages:
        pi = int(page.get("page_index", 0))
        for line in page.get("lines") or []:
            txt = str(line.get("text", "")).strip()
            bbox = line.get("bbox") or []
            if len(bbox) != 4:
                continue
            if label_re.search(" ".join(txt.split())):
                labels.append((pi, float(bbox[1]), txt))
    labels.sort(key=lambda t: (t[0], t[1]))
    out: List[TextCompanion] = []
    for idx, (sp, sy, label) in enumerate(labels):
        nxt = labels[idx + 1] if idx + 1 < len(labels) else None
        ep = nxt[0] if nxt else len(pages) - 1
        parts: List[str] = []
        used_pages: List[int] = []
        for p in range(sp, ep + 1):
            page_lines = []
            for line in pages[p].get("lines") or []:
                txt = str(line.get("text", "")).strip()
                bbox = line.get("bbox") or []
                if not txt or len(bbox) != 4:
                    continue
                y0 = float(bbox[1])
                if p == sp and y0 < sy:
                    continue
                if nxt and p == nxt[0] and y0 >= nxt[1]:
                    continue
                page_lines.append(txt)
            if page_lines:
                used_pages.append(p)
                parts.append("\n".join(page_lines))
        text = "\n\n".join(parts).strip()
        if text:
            out.append(TextCompanion(idx + 1, label, text, used_pages, 0.72, "explicit source/insert label"))
    return out


def extract_examiner_report_notes(ctx: DocumentContext, board: str = "") -> List[TextCompanion]:
    """Extract conservative per-question ER text snippets.

    Uses explicit ``Question N`` headings where present. It returns text-only
    snippets because ER prose is more useful/searchable as text and often does
    not need a rendered crop.
    """
    starts = _line_starts(ctx)
    starts = [s for s in starts if s[3] == "heading"]
    if not starts:
        return []
    pages = (ctx.layout or {}).get("pages") or []
    notes: List[TextCompanion] = []
    for idx, (sp, sy, qn, _kind, evidence) in enumerate(starts):
        next_start = starts[idx + 1] if idx + 1 < len(starts) else None
        ep = next_start[0] if next_start else len(pages) - 1
        parts: List[str] = []
        used_pages: List[int] = []
        for p in range(sp, ep + 1):
            page = pages[p]
            page_lines = []
            for line in page.get("lines") or []:
                txt = str(line.get("text", "")).strip()
                bbox = line.get("bbox") or []
                if not txt or len(bbox) != 4:
                    continue
                y0 = float(bbox[1])
                if p == sp and y0 < sy:
                    continue
                if next_start and p == next_start[0] and y0 >= next_start[1]:
                    continue
                # Drop repeating report headers/page numbers where obvious.
                low = txt.lower()
                if "report on the examination" in low or re.fullmatch(r"\d+\s+of\s+\d+", txt):
                    continue
                page_lines.append(txt)
            if page_lines:
                used_pages.append(p)
                parts.append("\n".join(page_lines))
        text = "\n\n".join(parts).strip()
        if text:
            notes.append(TextCompanion(qn, f"Q{qn}", text, used_pages, 0.82, f"explicit heading: {evidence}"))
    return notes
