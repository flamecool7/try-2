"""Board-specific output contract validation for adapter-produced segments.

The locked Cambridge crop engine still owns final geometry.  These checks sit at
the adapter/output boundary and fail closed on unknown layout/profile metadata,
missing canonical question IDs, non-WEBP image contracts, or board-specific
rectangles that include known non-question gutters.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping

from PIL import Image


@dataclass(frozen=True)
class ContractIssue:
    level: str
    segment_id: str
    message: str


def validate_segments(board: str, segments: Iterable[Dict[str, Any]]) -> List[ContractIssue]:
    issues: List[ContractIssue] = []
    board = board.upper()
    for seg in segments:
        sid = str(seg.get("id", "UNKNOWN"))
        if not seg.get("canonical_question"):
            issues.append(ContractIssue("ERROR", sid, "missing canonical_question"))
        if not seg.get("pages") and not seg.get("metadata", {}).get("text_only"):
            issues.append(ContractIssue("ERROR", sid, "no page rectangles for renderable segment"))
        meta = seg.get("metadata") or {}
        if not meta.get("layout_archetype"):
            issues.append(ContractIssue("ERROR", sid, "missing layout_archetype metadata"))
        if not meta.get("crop_plan"):
            issues.append(ContractIssue("ERROR", sid, "missing crop_plan metadata"))
        if board == "AQA" and meta.get("layout_archetype") == "aqa_numbered_boxed_structured":
            for page in seg.get("pages") or []:
                rect = page.get("rect") or ()
                if len(rect) == 4 and float(rect[2]) > 545:
                    issues.append(ContractIssue("ERROR", sid, "AQA boxed crop includes right-margin box ink"))
        if board == "EDEXCEL":
            for page in seg.get("pages") or []:
                rect = page.get("rect") or ()
                if len(rect) == 4 and float(rect[2]) > 610:
                    issues.append(ContractIssue("WARN", sid, "Edexcel crop may include right gutter"))
    return issues


def validate_rendered_webps(paths: Iterable[str | Path], measured: Mapping[str, Mapping[str, Any]] | None = None) -> List[ContractIssue]:
    """Check every written crop against the board contract.

    ``measured`` maps a written path to the geometry ``segment_geometry.save_rendered_segments``
    recorded from the in-memory image (``measure_crop``). When a path is present there, the
    checks run against those numbers and the file itself is only opened for its HEADER --
    enough to prove a readable WEBP of the declared size exists on disk. Lossless WEBP stores
    the source pixels exactly (verified 2026-09-29: decoded bytes == source bytes on the real
    crops), so the in-memory reading is the same verdict the decode used to give; the decode
    itself was 13 % of a demo batch (4.7 s / 35.7 s) and the pure-Python ink scan over
    2280x20 px another 1.4 s. Without ``measured`` the decode path below still runs.
    """

    issues: List[ContractIssue] = []
    for raw in paths:
        p = Path(raw)
        sid = p.stem
        if p.suffix.lower() != ".webp":
            issues.append(ContractIssue("ERROR", sid, "rendered output is not WEBP"))
            continue
        if not p.exists():
            # A measured record is not evidence a file exists: the crop on disk is the deliverable.
            issues.append(ContractIssue("ERROR", sid, "rendered crop is missing on disk"))
            continue
        record = (measured or {}).get(str(p))
        if record is not None:
            try:
                with Image.open(p) as im:  # header only: no .load(), so nothing is decoded
                    if im.format not in (None, "WEBP"):
                        issues.append(ContractIssue("ERROR", sid, f"written file is {im.format}, not WEBP"))
                    file_width, file_height = im.width, im.height
            except OSError as exc:
                issues.append(ContractIssue("ERROR", sid, f"written WEBP is unreadable: {exc}"))
                continue
            if int(record.get("width", 0)) != file_width or int(record.get("height", 0)) != file_height:
                issues.append(ContractIssue("ERROR", sid, "written WEBP size does not match the rendered image"))
            if file_width != 2280:
                issues.append(ContractIssue("ERROR", sid, f"WEBP width {file_width} != 2280"))
            if file_height >= 16383:
                issues.append(ContractIssue("ERROR", sid, "WEBP height reaches format limit"))
            if record.get("top_band_ink"):
                issues.append(ContractIssue("ERROR", sid, "top 20 px verified white band is not blank"))
            continue
        try:
            handle = Image.open(p)
        except OSError as exc:
            issues.append(ContractIssue("ERROR", sid, f"written WEBP is unreadable: {exc}"))
            continue
        with handle as im:
            if im.width != 2280:
                issues.append(ContractIssue("ERROR", sid, f"WEBP width {im.width} != 2280"))
            if im.height >= 16383:
                issues.append(ContractIssue("ERROR", sid, "WEBP height reaches format limit"))
            pix = im.load()
            # Renderers may preserve anti-aliased near-white source pixels as
            # 254 after lossless WEBP encode; treat >=250 in all channels as
            # verified white and still fail on real ink.
            ink = any(any(ch < 250 for ch in pix[x, y][:3]) for y in range(min(20, im.height)) for x in range(im.width))
            if ink:
                issues.append(ContractIssue("ERROR", sid, "top 20 px verified white band is not blank"))
    return issues


def write_contract_report(board: str, segments: Iterable[Dict[str, Any]], rendered_paths: Iterable[str | Path], out_path: str | Path) -> Path:
    import json
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    issues = validate_segments(board, segments) + validate_rendered_webps(rendered_paths)
    payload = {
        "contract_version": 1,
        "board": board.upper(),
        "status": "PASS" if not any(i.level == "ERROR" for i in issues) else "FAIL",
        "issues": [asdict(i) for i in issues],
    }
    out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return out
