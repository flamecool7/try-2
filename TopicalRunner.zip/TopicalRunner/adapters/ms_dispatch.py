"""Mark-scheme dispatch for non-CAIE boards (A3).

Two rules shape this module, and both exist to protect verified work:

1. **The CAIE mark-scheme path is not touched.** ``core.ms_cropping_engine`` is the
   locked gold implementation for CAIE. :func:`crop_mark_scheme` returns
   ``FALLBACK_CAIE`` for a CAIE document so the caller runs that engine unchanged.
   There is no second mark-scheme cropper here.

2. **A non-CAIE mark scheme is never handed to the CAIE engine.** That is the same
   mistake the question-paper side already refuses to make: it is how another
   board's document silently becomes a CAIE document, producing crops whose
   geometry is wrong in a way nobody notices until a student sees them. A board
   whose adapter cannot segment its mark schemes gets ``REVIEW_REQUIRED`` and
   QP-only routing instead.

What this module *is* is a thin dispatcher, exactly like ``pipeline_dispatch`` for
question papers: resolve the board, ask the adapter to segment the mark scheme,
then render those regions through the same locked gold geometry (``render_segment``)
and emit the same ``MSCroppedQuestion`` contract that ``MSCroppingEngine`` produces.
Downstream sees no difference between a CAIE mark-scheme crop and an AQA one, which
is the point -- the pairing layer, the QC layer and the output layer all keep
working unchanged.
"""
from __future__ import annotations

import gc
from pathlib import Path
from typing import Any, Dict, List, Optional

import fitz  # PyMuPDF

from adapters.pipeline_dispatch import (
    CAIE_BOARD,
    DEFAULT_MAX_RENDER_BYTES,
    effective_render_budget,
    DispatchResult,
    DispatchStatus,
    _estimate_render_bytes,
    _extract_segment_text,
    build_document_context,
    resolve_board,
)
from adapters.registry import get_adapter
from adapters.segment_geometry import render_segment


#: Render-budget ceiling for the MARK-SCHEME leg, in estimated bytes of decoded
#: RGB pixels. Deliberately lower than the question-paper leg's 700 MB, because a
#: mark scheme is cropped while every question-paper crop of the same bundle is
#: still live in memory.
#:
#: Measured on this sandbox (1984 MB RAM) for the AQA 8462/1H June 2023 mark
#: scheme -- 10 regions, 72k pixels of assembled height:
#:
#:   predicted peak 1437 MB (assembled 586 MB + largest 99 MB, IB Paper 1 MS; the
#:   pre-2026-09-21 estimate said 458 MB -> measured peak 1031 MB on TOP of the
#:   live question-paper crops, which is the OOM-kill this budget exists to stop).
#:
#: The budget is a PREDICTED PEAK RSS budget (same model as the QP leg, see
#: adapters.pipeline_dispatch._estimate_render_bytes). At 1 GiB a mark scheme of
#: this size is refused with a message naming the two working options (spool_dir=,
#: or run_guarded.py --low-ram, which spools both legs and stays flat).
DEFAULT_MS_MAX_RENDER_BYTES = 1024 * 1024 * 1024


class MarkSchemeDispatchUnsupported(RuntimeError):
    """A document's board is known, non-CAIE, and cannot segment its mark schemes.

    Raised instead of silently handing the mark scheme to the CAIE engine.
    """

    def __init__(self, result: "DispatchResult"):
        super().__init__(result.reason)
        self.result = result


def _to_ms_cropped_question(rendered: Any, segment: Dict[str, Any], paper_code: str):
    """Adapt a RenderedSegment into the ``MSCroppedQuestion`` contract.

    ``paper_code`` is the mark-scheme file stem, matching both producers of that
    contract today (``MSCroppingEngine`` and the legacy portrait fallback in
    ``run_guarded``), so downstream code sees one shape regardless of board.
    """
    from core.ms_cropping_engine import MSCroppedQuestion  # local: avoid import cycle

    raw = segment.get("question_number", 0)
    try:
        number_int = int(str(raw).lstrip("Qq").split(".")[0])
    except (TypeError, ValueError):
        number_int = 0

    return MSCroppedQuestion(
        question_number=f"Q{number_int}" if number_int else f"Q{raw}",
        number_int=number_int,
        paper_code=paper_code,
        images=[rendered.image],
        assembled_image=rendered.image,
        text="",
        marks=0,
        pages=list(rendered.source_pages or []),
    )


def crop_mark_scheme(
    pdf_path: str | Path,
    *,
    ctx: Optional[Any] = None,
    expected_questions: Optional[List[int]] = None,
    limit: int = 0,
    max_render_bytes: int = DEFAULT_MS_MAX_RENDER_BYTES,
    spool_dir: Optional[str | Path] = None,
) -> DispatchResult:
    """Dispatch a mark scheme to the right board path.

    Returns a :class:`DispatchResult`. ``questions`` is populated only for
    ``ADAPTER_USED``; for ``FALLBACK_CAIE`` the caller must use the existing locked
    ``MSCroppingEngine`` unchanged.

    ``expected_questions`` is the companion question paper's top-level question
    numbers. When given, a mark scheme whose coverage differs is refused
    (``REVIEW_REQUIRED``) rather than emitted as a partial bundle -- the same
    fail-closed rule the CAIE leg already applies.
    """
    pdf_path = Path(pdf_path)
    try:
        ctx = ctx or build_document_context(pdf_path)
    except Exception as exc:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, None, 0.0,
            f"could not read document context: {exc}",
        )

    res = resolve_board(ctx)

    if res.board == CAIE_BOARD:
        return DispatchResult(
            DispatchStatus.FALLBACK_CAIE, CAIE_BOARD, res.confidence,
            "board identified as CAIE - use the locked MSCroppingEngine",
            evidence=res.evidence,
        )

    if res.board is None:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, None, res.confidence,
            "board not identified - refuse to guess (never silently CAIE-crop a "
            "mark scheme)",
            evidence=res.evidence,
        )

    adapter = get_adapter(res.board)
    if adapter is None:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"board {res.board} has no adapter - cannot crop mark scheme; never "
            f"silently CAIE-crop",
            evidence=res.evidence,
        )
    if not getattr(adapter, "segments_mark_scheme", lambda: False)():
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"adapter for {res.board} does not implement segments_mark_scheme(): "
            f"no mark scheme on disk has been validated for this board yet, so "
            f"its mark scheme is left uncropped (QP-only routing) rather than "
            f"guessed at",
            evidence=res.evidence,
        )

    try:
        segments = list(adapter.segment_mark_scheme(ctx) or [])
    except Exception as exc:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"adapter {res.board} mark-scheme segmentation failed: {exc}",
            evidence=res.evidence,
        )

    if not segments:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"adapter {res.board} produced 0 mark-scheme segments - refuse to emit "
            f"an empty or partial mark scheme",
            evidence=res.evidence,
        )

    if expected_questions:
        expected = {int(n) for n in expected_questions}
        found = {int(s.get("question_number", 0)) for s in segments}
        if found != expected:
            return DispatchResult(
                DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
                f"mark-scheme coverage {sorted(found)} != question paper coverage "
                f"{sorted(expected)} - refusing a partial mark scheme",
                segments=segments,
                evidence=res.evidence,
            )

    if limit:
        segments = segments[:limit]

    estimate = _estimate_render_bytes(segments)
    budget, tightened = effective_render_budget(max_render_bytes)
    if spool_dir is None and estimate > budget:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"refusing to render {len(segments)} mark-scheme segment(s) in memory: "
            f"predicted peak RSS {estimate / 1048576:.0f} MB exceeds the "
            f"{budget / 1048576:.0f} MB budget{tightened}. Two options: pass spool_dir= "
            f"to render one segment at a time, or run run_guarded.py --low-ram, which "
            f"spools. Without either, the question-paper crops are still live in memory "
            f"alongside these, which risks an OOM-kill instead of a clean failure.",
            segments=segments,
            evidence=res.evidence,
        )

    spool_path: Optional[Path] = None
    if spool_dir is not None:
        spool_path = Path(spool_dir)
        spool_path.mkdir(parents=True, exist_ok=True)

    paper_code = pdf_path.stem
    questions: List[Any] = []
    try:
        with fitz.open(str(pdf_path)) as doc:
            for index, seg in enumerate(segments):
                rendered = render_segment(pdf_path, seg)
                text = _extract_segment_text(doc, seg)
                question = _to_ms_cropped_question(rendered, seg, paper_code)
                question.text = text
                if spool_path is not None:
                    png = spool_path / f"{res.board or 'UNK'}_MS_{index:03d}.png"
                    question.assembled_image.save(png, format="PNG")
                    question._spool_png = str(png)
                    question.assembled_image = None
                    question.images = []
                    del rendered
                    gc.collect()
                questions.append(question)
    except Exception as exc:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"rendering mark-scheme segment {len(questions) + 1}/{len(segments)} "
            f"failed: {exc}",
            questions=questions,
            evidence=res.evidence,
        )

    if spool_path is not None:
        print(f"[ms-dispatch] {pdf_path.name}: spooled {len(questions)} mark-scheme "
              f"crop payload(s) -> {spool_path.name}/ (PNG pixel-exact)")

    return DispatchResult(
        DispatchStatus.ADAPTER_USED, res.board, res.confidence,
        f"cropped {len(questions)} mark-scheme question(s) via the {res.board} "
        f"adapter + locked gold geometry",
        questions=questions,
        segments=segments,
        evidence=res.evidence,
    )


def crop_mark_scheme_or_none(
    pdf_path: str | Path,
    *,
    expected_questions: Optional[List[int]] = None,
    strict: bool = False,
    log: bool = True,
    spool_dir: Optional[str | Path] = None,
    max_render_bytes: int = DEFAULT_MS_MAX_RENDER_BYTES,
) -> List[Any]:
    """Dispatch a mark scheme to its board adapter, or return no crops at all.

    This is what the pipeline calls. Behaviour:

    * ``ADAPTER_USED``  -> the adapter's mark-scheme crops.
    * ``FALLBACK_CAIE`` -> ``[]`` plus a logged instruction, because only the caller
      holds the locked ``MSCroppingEngine``; this function deliberately does not
      import or re-implement it.
    * ``REVIEW_REQUIRED``, board KNOWN non-CAIE -> ``[]`` unless ``strict``, in
      which case raise :class:`MarkSchemeDispatchUnsupported`.

    Returning no markscheme crops is a valid, expected outcome: the pipeline
    routes every question of that paper to ``review_required/no_markscheme`` and
    fails closed. It is never permission to crop the mark scheme some other way.
    """
    result = crop_mark_scheme(
        pdf_path, expected_questions=expected_questions, spool_dir=spool_dir,
        max_render_bytes=max_render_bytes,
    )
    name = Path(pdf_path).name

    if result.status is DispatchStatus.ADAPTER_USED:
        if log:
            print(f"[ms-dispatch] {name}: {result.board} adapter -> "
                  f"{len(result.questions)} mark-scheme question(s)")
        return result.questions

    if result.status is DispatchStatus.FALLBACK_CAIE:
        if log:
            print(f"[ms-dispatch] {name}: CAIE -> locked MSCroppingEngine")
        return []

    if result.board and strict:
        raise MarkSchemeDispatchUnsupported(result)

    if log:
        print(f"[ms-dispatch] {name}: {result.reason}")
    return []


def _main(argv: Optional[List[str]] = None) -> int:
    import argparse
    import json

    ap = argparse.ArgumentParser(
        description="Dispatch a mark scheme to its board adapter (auditor; never "
                    "substitutes for the CAIE MSCroppingEngine)."
    )
    ap.add_argument("pdf", help="mark-scheme PDF")
    ap.add_argument("--spool-dir", default=None, help="render one segment at a time into this dir")
    ap.add_argument("--max-render-mb", type=int, default=700,
                    help="in-memory render budget for this single-paper inspection "
                         "(the pipeline passes the mark-scheme bundle budget itself)")
    ap.add_argument("--json", action="store_true", help="emit JSON")
    args = ap.parse_args(argv)

    result = crop_mark_scheme(args.pdf, spool_dir=args.spool_dir,
                              max_render_bytes=args.max_render_mb * 1024 * 1024)
    payload = {
        "pdf": args.pdf,
        "status": result.status.value,
        "board": result.board,
        "confidence": round(float(result.confidence), 3),
        "reason": result.reason,
        "questions": len(result.questions),
        "segments": len(result.segments),
        "coverage": sorted(int(s.get("question_number", 0)) for s in result.segments),
        "sub_parts": {str(s.get("question_number")): s.get("sub_parts") for s in result.segments},
    }
    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print(f"{payload['status']}  board={payload['board']}  "
              f"confidence={payload['confidence']}  questions={payload['questions']}")
        print(f"  {payload['reason']}")
        if payload["coverage"]:
            print(f"  coverage: {payload['coverage']}")
            for q, parts in payload["sub_parts"].items():
                print(f"    Q{q}: {parts}")
    return 0 if result.status in (DispatchStatus.ADAPTER_USED, DispatchStatus.FALLBACK_CAIE) else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(_main())
