"""pipeline_dispatch — makes board adapters reachable from the real pipeline.

WHY THIS EXISTS
---------------
Every board adapter (AQA / Edexcel / SAT / IB / CAIE) was built and verified, but
none of them was reachable from the product: ``main.py``, ``run_guarded.py``,
``run_pipeline.py``, ``pipeline.py`` and ``core/batch_runner.py`` contained zero
references to the adapter registry, and every paper was routed through the locked
CAIE cropper regardless of board.

This module is the missing wire. It is deliberately a *dispatcher*, not a cropper:
it never opens a PDF to decide boundaries itself and it never re-implements
geometry. It reuses, in this order:

* ``adapters.registry.get_all_adapters`` / ``get_adapter``  - board discovery and
  the adapters' own ``identify_document`` evidence (board detection is the
  adapters' job, not this module's);
* ``adapters.segment_geometry.render_segment``             - the shared
  segment-to-gold-geometry bridge;
* ``assemble_multipage_question`` / ``enforce_exact_width_2280`` /
  ``_align_top_white_band_final``                            - the locked gold
  primitives, reached *through* the bridge, never copied.

FAIL-CLOSED CONTRACT
--------------------
Silently cropping a non-CAIE paper with the CAIE engine is the exact failure this
module exists to prevent. Therefore:

===============================  =========================================
Situation                         Result
===============================  =========================================
board identified as CAIE          ``FALLBACK_CAIE``  - locked path, as today
non-CAIE board WITH adapter       ``ADAPTER_USED``   - adapter + gold geometry
non-CAIE board, NO adapter        ``REVIEW_REQUIRED``- loud; never CAIE-cropped
board not identified              ``REVIEW_REQUIRED``- loud; never guessed
adapter raises                    ``REVIEW_REQUIRED``- reason recorded
===============================  =========================================

Callers decide what to do with ``REVIEW_REQUIRED``; the pipeline convention is to
surface it as a review item rather than fabricate output.

KNOWN GAPS (honest, not hidden)
-------------------------------
* ``CroppedQuestion.text`` is empty on the adapter path. Gold's cropper returns
  classification text alongside crops; the adapter path currently renders images
  only. Classification for non-CAIE boards therefore needs a text step before it
  can match CAIE quality - see NEXT_STEPS.md.
* The MS (mark scheme) path is not dispatched here; only question papers.
"""
from __future__ import annotations

import gc
import hashlib
import os
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import fitz  # PyMuPDF

from adapters.base import DocumentContext
from adapters.registry import get_adapter, get_all_adapters
from adapters.segment_geometry import TARGET_WIDTH, render_segment

CAIE_BOARD = "CAIE"

#: Minimum board-evidence confidence required to trust a non-CAIE routing decision.
#: Below this the document is treated as unidentified (REVIEW_REQUIRED), never
#: guessed at.
BOARD_CONFIDENCE_FLOOR = 0.60

#: Render-budget ceiling, in PREDICTED PEAK RSS bytes (2026-09-21).
#:
#: The adapter path holds every rendered crop of a paper in memory at once, so a
#: tall multi-page paper can exceed a small box. Until 2026-09-21 this budget was
#: compared against an estimate that was a LOWER BOUND: it multiplied each page
#: rect's height by the render scale and by TARGET_WIDTH, which (a) misses the
#: upscale to 2280 px whenever the rect is narrower than the page - 1.02x for a
#: full-width AQA/Edexcel/IB rect but 2.02x for a half-width SAT column - and
#: (b) ignores the transient buffers and allocator retention that the render
#: actually peaks at. A paper could therefore pass the gate and then peak at
#: 2-4x the number the gate had measured.
#:
#: _estimate_render_bytes() now predicts the peak. Measured on this sandbox
#: (~2 GB RAM) with tools/measure_render_estimate.py, one paper per process:
#:
#:   paper            segs  assembled  largest  measured peak  predicted
#:   AQA 8462/1H QP     10     586 MB    84 MB        1151 MB     1396 MB
#:   Edexcel 9FM0/3C     7     564 MB   105 MB        1313 MB     1407 MB
#:   IB Paper 1 QP      12     254 MB    40 MB         464 MB      651 MB
#:   IB Paper 1 MS      15     586 MB    99 MB        1040 MB     1437 MB
#:   PSAT 8/9 (first 12) 12    255 MB    35 MB         353 MB      639 MB
#:
#: The model covers every measured paper with a 7-80% margin; the full PSAT book
#: (120 segments, ~2.6 GB assembled) is predicted at ~5.1 GB and is refused, which
#: is the point - holding 120 crops is impossible on this box, and the spooled
#: path exists for exactly that case.
#:
#: The default admits every paper measured to work here (AQA, Edexcel, IB QP,
#: IB MS) and refuses the ones that cannot fit. Lower it on a smaller box; the
#: refusal message names both working options (spool_dir=, run_guarded.py --low-ram).
DEFAULT_MAX_RENDER_BYTES = 1536 * 1024 * 1024

#: Optional tighten-only override for the in-memory render budgets.
#:
#:     GUARDED_RENDER_BUDGET_MB=1150 python run_guarded.py ...
#:
#: Read at each call, never captured once, so a constrained box - or a run that
#: shares the machine with something else - can squeeze the render gate without a
#: code change. It can only LOWER the effective budget: a value at or above the
#: declared one is ignored, so an env var can never loosen a documented
#: admission, and an unset one leaves behaviour exactly as it was.
RENDER_BUDGET_ENV = "GUARDED_RENDER_BUDGET_MB"

#: Sanity ceiling for an override (100 GB): anything outside (0, this) is treated
#: as garbage rather than as a budget - that also disposes of inf/nan, whose
#: comparison results would otherwise reach int() and raise.
_RENDER_BUDGET_MAX_MB = 100_000.0


def effective_render_budget(declared_bytes: int) -> tuple:
    """Return ``(budget_bytes, note)`` for a render gate: declared, tightened on request.

    ``note`` is "" when nothing changed and otherwise says where the tighter
    number came from, so a refusal can name its own cause.
    """
    raw = os.environ.get(RENDER_BUDGET_ENV)
    if not raw:
        return declared_bytes, ""
    try:
        mb = float(raw)
    except (TypeError, ValueError):
        return declared_bytes, ""
    if not (0.0 < mb < _RENDER_BUDGET_MAX_MB):
        return declared_bytes, ""
    want = int(mb * 1048576)
    if want >= declared_bytes:                       # tighten-only, by construction
        return declared_bytes, ""
    return want, (f" [{RENDER_BUDGET_ENV}={mb:g} MB tightens the "
                  f"{declared_bytes // 1048576} MB box default]")



class DispatchStatus(str, Enum):
    ADAPTER_USED = "ADAPTER_USED"
    FALLBACK_CAIE = "FALLBACK_CAIE"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"


@dataclass
class BoardResolution:
    board: Optional[str]
    confidence: float
    evidence: List[str] = field(default_factory=list)


@dataclass
class DispatchResult:
    status: DispatchStatus
    board: Optional[str]
    confidence: float
    reason: str
    questions: List[Any] = field(default_factory=list)
    segments: List[Dict[str, Any]] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)

    @property
    def used_adapter(self) -> bool:
        return self.status is DispatchStatus.ADAPTER_USED


# --------------------------------------------------------------------------- #
# Document context
# --------------------------------------------------------------------------- #
def build_document_context(
    pdf_path: str | Path,
    *,
    max_pages: Optional[int] = None,
) -> DocumentContext:
    """Build the canonical ``DocumentContext`` for a PDF.

    The brief's rule: *DocumentContext already carries path, full_text, page_count,
    layout - never re-open or re-OCR the PDF in an adapter.* This is the single
    place that opens the PDF to populate it. Semantics match the verification
    utility ``tools/crop_noncaie_segments.build_context`` so adapter behaviour is
    identical between verification and production.

    ``max_pages`` reads only the first N pages. Board identification is decided by
    cover-page text, so callers that only need identity (the association auditor)
    pass 3 rather than parsing a 56-page PSAT in full. ``page_count`` always
    reports the true document page count, never the truncated prefix.
    """
    path = Path(pdf_path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    pages: List[Dict[str, Any]] = []
    full_parts: List[str] = []
    first = ""
    true_page_count = 0
    with fitz.open(str(path)) as doc:
        true_page_count = doc.page_count
        for idx, page in enumerate(doc):
            if max_pages is not None and idx >= max_pages:
                break
            text = page.get_text("text") or ""
            if idx == 0:
                first = text
            full_parts.append(text)
            lines: List[Dict[str, Any]] = []
            raw = page.get_text("dict")
            for block in raw.get("blocks", []):
                for line in block.get("lines", []) or []:
                    spans = line.get("spans", []) or []
                    s = "".join(span.get("text", "") for span in spans).strip()
                    if not s:
                        continue
                    bbox = list(line.get("bbox", block.get("bbox", [0, 0, 0, 0])))
                    lines.append({"text": s, "bbox": bbox})
            pages.append({
                "page_index": idx,
                "size": [float(page.rect.width), float(page.rect.height)],
                "text": text,
                "lines": lines,
            })
    return DocumentContext(
        path=str(path),
        filename=path.name,
        stem=path.stem,
        suffix=path.suffix,
        size_bytes=path.stat().st_size,
        sha256=digest,
        page_count=true_page_count,
        first_page_text=first,
        full_text="\f".join(full_parts),
        has_text_layer=bool("".join(full_parts).strip()),
        text_chars_per_page=[len(p.get("text", "")) for p in pages],
        layout={"pages": pages},
    )


# --------------------------------------------------------------------------- #
# Board resolution
# --------------------------------------------------------------------------- #
def resolve_board(
    ctx: DocumentContext,
    *,
    floor: float = BOARD_CONFIDENCE_FLOOR,
) -> BoardResolution:
    """Ask every adapter to identify the document; take the strongest board vote.

    Board detection is delegated to the adapters' own ``identify_document`` so
    there is exactly one authority per board. Ties cannot silently win: equal
    confidence between two different boards is reported at the reduced confidence
    of the evidence rather than resolved by dictionary order.
    """
    best: Dict[str, tuple[float, str]] = {}
    errors: List[str] = []
    for board_id, adapter in (get_all_adapters() or {}).items():
        try:
            for ev in adapter.identify_document(ctx) or []:
                if getattr(ev, "field", None) != "board":
                    continue
                conf = float(getattr(ev, "confidence", 0.0))
                detail = f"{board_id}:{getattr(ev, 'kind', '?')}@{conf:.2f}"
                prior = best.get(board_id)
                if prior is None or conf > prior[0]:
                    best[board_id] = (conf, detail)
        except Exception as exc:  # one broken adapter must not kill dispatch
            errors.append(f"{board_id}: {exc}")
            continue

    if not best:
        return BoardResolution(None, 0.0, errors or ["no adapter reported board evidence"])

    ranked = sorted(best.items(), key=lambda kv: -kv[1][0])
    top_board, (top_conf, top_detail) = ranked[0]

    # Ambiguity guard: a different board with equal confidence is a conflict.
    if len(ranked) > 1 and abs(ranked[1][1][0] - top_conf) < 1e-9:
        other, (oconf, odetail) = ranked[1]
        return BoardResolution(
            None, top_conf,
            [f"ambiguous board: {top_detail} vs {odetail} at equal confidence"] + errors,
        )

    evidence = [top_detail] + [f"{b}:{c:.2f}" for b, (c, _) in ranked[1:4]] + errors
    if top_conf < floor:
        return BoardResolution(
            None, top_conf, [f"board confidence {top_conf:.2f} < floor {floor:.2f}"] + evidence
        )
    return BoardResolution(top_board, top_conf, evidence)


# --------------------------------------------------------------------------- #
# Cropping
# --------------------------------------------------------------------------- #
_FURNITURE_LINE_RE = re.compile(
    r"""^\s*(
        \d{1,3}                                  # bare page number
      | \*[A-Z0-9]{6,}\*                          # page-reference code, e.g. *P61181A0228*
      | (?:turn\s+over|please\s+turn\s+over)\s*$  # running instruction
      | do\s+not\s+write\s+(?:in|outside)\s+this\s+(?:area|box)\s*$
      | blank\s+page\s*$
    )\s*$""",
    re.IGNORECASE | re.VERBOSE,
)


def _strip_page_furniture(text: str) -> str:
    """Remove page furniture from adapter-extracted segment text.

    Adapter rects intentionally cover the whole question band, so extracted text
    can begin with running header/footer material - measured on
    P61181A_9FM0_3C.pdf, where Q1 text started ``2\\n*P61181A0228*\\n1.\\t A van of
    mass ...``. The crops are geometrically correct; only the *text* carries this.

    Stripping is deliberately conservative:

    * only **leading** furniture is removed, so a number that is genuinely part of
      a question (a mass, a page reference inside prose) is never touched;
    * standalone page-reference codes are removed wherever they appear, since they
      are never question content.

    This makes adapter-path classification text comparable to gold's, which reads
    text from the same bands but through a splitter that already excludes furniture.
    """
    lines = text.splitlines()
    start = 0
    while start < len(lines) and (not lines[start].strip() or _FURNITURE_LINE_RE.match(lines[start])):
        start += 1
    kept = [ln for ln in lines[start:] if not _FURNITURE_LINE_RE.match(ln) or ln.strip()[:1].isdigit() and len(ln.strip()) > 3]
    return "\n".join(kept).strip()


def _extract_segment_text(doc: "fitz.Document", segment: Dict[str, Any]) -> str:
    """Extract text from the SAME source-coordinate bands the crop renders.

    Gold's cropper returns classification text read from the identical page bands
    as the image (`question_split.extract_question_text`), so classification can
    never drift from the crop. The adapter path must match that property or its
    classification would be reading a different region than the picture shows.
    This reads each segment rectangle through PyMuPDF's clip, which is the same
    source-coordinate rule expressed for adapter-style rectangles.
    """
    parts: List[str] = []
    for item in segment.get("pages") or []:
        try:
            page_index = int(item.get("page_index", item.get("page", 0)))
        except (TypeError, ValueError):
            continue
        if page_index < 0 or page_index >= doc.page_count:
            continue
        page = doc[page_index]
        raw_rect = item.get("rect") or item.get("clip")
        if raw_rect:
            try:
                rect = fitz.Rect(*[float(v) for v in raw_rect]) & page.rect
            except (TypeError, ValueError):
                rect = None
            if rect is not None and not rect.is_empty:
                parts.append(page.get_text("text", clip=rect) or "")
                continue
        parts.append(page.get_text("text") or "")
    return _strip_page_furniture("\n".join(p for p in parts if p).strip())


def _to_cropped_question(rendered: Any, segment: Dict[str, Any], board: str, text: str = ""):
    """Adapt a RenderedSegment into the pipeline's CroppedQuestion contract."""
    from core.cropping_engine import CroppedQuestion  # local: avoid import cycle

    raw_num = segment.get("question_number", segment.get("canonical_question", "0"))
    try:
        number_int = int(str(raw_num).lstrip("Qq").split(".")[0])
    except (TypeError, ValueError):
        number_int = 0

    return CroppedQuestion(
        question_number=str(raw_num),
        number_int=number_int,
        paper_code=str(segment.get("component") or ""),
        images=[rendered.image],
        assembled_image=rendered.image,
        text=text or "",
        pages=list(rendered.source_pages or []),
        needs_review=False,
        qc_reasons=[],
    )


#: Peak model constants, measured (not guessed) on this sandbox, 2026-09-21.
#: peak ~= K_HELD * assembled_bytes + K_TRANSIENT * largest_segment_bytes + K_FIXED
#: K_HELD covers the assembled rasters plus their resampling copies; K_TRANSIENT
#: covers the page pixmap + resize buffers alive for the segment being rendered
#: plus glibc arena retention (RSS never returns to the OS); K_FIXED covers the
#: interpreter, PyMuPDF and Pillow themselves. See tools/measure_render_estimate.py.
K_HELD = 1.9
K_TRANSIENT = 2.6
K_FIXED_BYTES = 64 * 1024 * 1024


def _assembled_bytes(segments: List[Dict[str, Any]]) -> tuple:
    """Exact decoded-RGB bytes of the assembled crops: (total, largest).

    Geometry, from adapters.segment_geometry + core.multipage_optimizer: a page
    rect is rendered at RENDER_DPI (300), then the assembled question is scaled
    to exactly TARGET_WIDTH (2280) px. So the upscale factor is
    2280 / (rect_width_pt * 300 / 72), and the assembled height is
    rect_height_pt * (300 / 72) * upscale - NOT rect_height * scale, which is
    what the pre-2026-09-21 estimate used and why a half-width SAT column crop
    was under-predicted by 2x. The 30 px interpage gap is included.
    """
    from adapters.segment_geometry import RENDER_DPI
    from core.multipage_optimizer import INTERPAGE_GAP

    scale = RENDER_DPI / 72.0
    total = 0
    largest = 0
    for seg in segments:
        seg_bytes = 0
        pages = 0
        for item in seg.get("pages") or []:
            rect = item.get("rect") or item.get("clip")
            if not (rect and len(rect) == 4):
                continue
            try:
                w_pt = float(rect[2]) - float(rect[0])
                h_pt = float(rect[3]) - float(rect[1])
            except (TypeError, ValueError):
                continue
            if w_pt <= 1.0 or h_pt <= 1.0:
                continue
            rendered_w = w_pt * scale
            rendered_h = h_pt * scale
            assembled_h = rendered_h * (TARGET_WIDTH / rendered_w)
            seg_bytes += int(TARGET_WIDTH * assembled_h * 3)
            pages += 1
        if pages > 1:
            seg_bytes += (pages - 1) * INTERPAGE_GAP * TARGET_WIDTH * 3
        total += seg_bytes
        largest = max(largest, seg_bytes)
    return total, largest


def _estimate_render_bytes(segments: List[Dict[str, Any]]) -> int:
    """Predict PEAK RSS bytes for rendering every segment of a paper in memory.

    Was a lower bound (assembled pixels only, without the upscale factor); now a
    prediction of the peak, calibrated against five real papers - see
    DEFAULT_MAX_RENDER_BYTES for the measurement table and the model constants.
    """
    assembled, largest = _assembled_bytes(segments)
    return int(K_HELD * assembled + K_TRANSIENT * largest + K_FIXED_BYTES)


def crop_question_paper(
    pdf_path: str | Path,
    *,
    target_width: int = TARGET_WIDTH,
    limit: int = 0,
    ctx: Optional[DocumentContext] = None,
    max_render_bytes: int = DEFAULT_MAX_RENDER_BYTES,
    spool_dir: Optional[str | Path] = None,
) -> DispatchResult:
    """Dispatch a question paper to the right board path.

    Returns a :class:`DispatchResult`. ``questions`` is populated only for
    ``ADAPTER_USED``; for ``FALLBACK_CAIE`` the caller must use the existing
    locked CAIE cropper unchanged.
    """
    pdf_path = Path(pdf_path)
    try:
        ctx = ctx or build_document_context(pdf_path)
    except Exception as exc:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, None, 0.0,
            f"could not read document context: {exc}",
        )

    res = resolve_board(ctx)

    if res.board == CAIE_BOARD:
        return DispatchResult(
            DispatchStatus.FALLBACK_CAIE, CAIE_BOARD, res.confidence,
            "board identified as CAIE - use the locked CAIE cropper",
            evidence=res.evidence,
        )

    if res.board is None:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, None, res.confidence,
            "board not identified - refuse to guess (never silently CAIE-crop)",
            evidence=res.evidence,
        )

    adapter = get_adapter(res.board)
    if adapter is None:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"board {res.board} has no adapter - cannot crop; never silently CAIE-crop",
            evidence=res.evidence,
        )
    if not getattr(adapter, "segments_document", lambda: False)():
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"adapter for {res.board} does not implement segments_document()",
            evidence=res.evidence,
        )

    try:
        segments = list(adapter.segment(ctx) or [])
    except Exception as exc:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"adapter {res.board} segmentation failed: {exc}",
            evidence=res.evidence,
        )

    if not segments:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"adapter {res.board} produced 0 segments - refuse to emit an empty bank",
            evidence=res.evidence,
        )

    if limit:
        segments = segments[:limit]

    estimate = _estimate_render_bytes(segments)
    budget, tightened = effective_render_budget(max_render_bytes)
    if spool_dir is None and estimate > budget:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"refusing to render {len(segments)} segment(s) in memory: predicted "
            f"peak RSS {estimate / 1048576:.0f} MB exceeds the "
            f"{budget / 1048576:.0f} MB budget{tightened}. Two options: pass "
            f"spool_dir= to render one segment at a time (flat memory), or run "
            f"run_guarded.py --low-ram, which spools. Without either, proceeding "
            f"risks an OOM-kill instead of a clean failure.",
            segments=segments,
            evidence=res.evidence,
        )

    # Spooled mode: render ONE segment at a time and park its pixels on disk as a
    # pixel-exact PNG, matching run_guarded's established contract (_spool_png +
    # cleared images, reloaded by _unspool at S5). PNG, not WEBP, because PNG is
    # pixel-exact, so the WEBP bytes saved later at S5 are unchanged.
    spool_path: Optional[Path] = None
    if spool_dir is not None:
        spool_path = Path(spool_dir)
        spool_path.mkdir(parents=True, exist_ok=True)

    questions: List[Any] = []
    try:
        with fitz.open(str(pdf_path)) as doc:
            for index, seg in enumerate(segments):
                rendered = render_segment(pdf_path, seg)
                text = _extract_segment_text(doc, seg)
                question = _to_cropped_question(rendered, seg, res.board, text)
                if spool_path is not None:
                    png = spool_path / f"{res.board or 'UNK'}_{index:03d}.png"
                    question.assembled_image.save(png, format="PNG")
                    question._spool_png = str(png)
                    question.assembled_image = None
                    question.images = []
                    del rendered
                    gc.collect()
                questions.append(question)
    except Exception as exc:
        return DispatchResult(
            DispatchStatus.REVIEW_REQUIRED, res.board, res.confidence,
            f"rendering segment {len(questions) + 1}/{len(segments)} failed: {exc}",
            questions=questions,
            evidence=res.evidence,
        )

    if spool_path is not None:
        print(f"[dispatch] {Path(pdf_path).name}: spooled {len(questions)} crop payload(s) "
              f"-> {spool_path.name}/ (PNG pixel-exact, one segment at a time)")

    return DispatchResult(
        DispatchStatus.ADAPTER_USED, res.board, res.confidence,
        f"cropped {len(questions)} question(s) via the {res.board} adapter + locked gold geometry",
        questions=questions,
        segments=segments,
        evidence=res.evidence,
    )


# --------------------------------------------------------------------------- #
# Pipeline entry point
# --------------------------------------------------------------------------- #
class BoardDispatchUnsupported(RuntimeError):
    """A document's board is known, non-CAIE, and has no usable adapter.

    Raised instead of silently cropping with the CAIE engine. The pipeline
    convention is to surface this as REVIEW_REQUIRED, never as output.
    """

    def __init__(self, result: "DispatchResult"):
        super().__init__(result.reason)
        self.result = result


def crop_question_paper_or_caie(
    pdf_path: str | Path,
    caie_engine: Any,
    *,
    strict: bool = False,
    log: bool = True,
    spool_dir: Optional[str | Path] = None,
    max_render_bytes: Optional[int] = None,
) -> List[Any]:
    """Dispatch a QP to its board adapter, falling back to the locked CAIE cropper.

    This is the function the production entry points call. Behaviour:

    * ``ADAPTER_USED``     -> adapter crops, returned directly.
    * ``FALLBACK_CAIE``    -> CAIE engine, unchanged (today's behaviour).
    * ``REVIEW_REQUIRED``, board KNOWN non-CAIE -> raise
      :class:`BoardDispatchUnsupported`. Never silently CAIE-crops another board.
    * ``REVIEW_REQUIRED``, board UNIDENTIFIED -> CAIE engine, preserving historical
      behaviour, but loudly logged. Pass ``strict=True`` to raise instead.

    The unidentified case stays permissive on purpose: this repo's existing corpus
    is overwhelmingly CAIE, and turning an unidentified paper into a hard failure
    would break runs that work today. It is a known limitation, not an oversight -
    flip ``strict=True`` once every board has a verified adapter.
    """
    # spool_dir / max_render_bytes are forwarded, not swallowed: a caller that can
    # afford a scratch directory must be able to take the low-memory render path
    # through THIS entry point too (a 7-segment Edexcel paper peaks at ~1.45 GB
    # rendered in memory, which is what made the caller OOM - 2026-09-21).
    kwargs: Dict[str, Any] = {}
    if spool_dir is not None:
        kwargs["spool_dir"] = spool_dir
    if max_render_bytes is not None:
        kwargs["max_render_bytes"] = max_render_bytes
    result = crop_question_paper(pdf_path, **kwargs)
    name = Path(pdf_path).name

    if result.status is DispatchStatus.ADAPTER_USED:
        if log:
            print(f"[dispatch] {name}: {result.board} adapter -> {len(result.questions)} question(s)")
        return result.questions

    if result.status is DispatchStatus.FALLBACK_CAIE:
        if log:
            print(f"[dispatch] {name}: CAIE -> locked cropper")
        return caie_engine.process_paper(pdf_path)

    # REVIEW_REQUIRED
    if result.board:
        raise BoardDispatchUnsupported(result)

    if strict:
        raise BoardDispatchUnsupported(result)

    if log:
        print(f"[dispatch] WARNING {name}: board not identified ({result.reason}); "
              f"falling back to the locked CAIE cropper (historical behaviour)")
    return caie_engine.process_paper(pdf_path)


# --------------------------------------------------------------------------- #
# CLI - proof that the wiring works, independent of the full pipeline
# --------------------------------------------------------------------------- #
def _main(argv: Optional[List[str]] = None) -> int:
    import argparse
    import json

    ap = argparse.ArgumentParser(description="Dispatch a QP to its board adapter.")
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    result = crop_question_paper(args.pdf, limit=args.limit)
    from adapters.segment_geometry import measure_top_band

    report = {
        "pdf": args.pdf,
        "status": result.status.value,
        "board": result.board,
        "confidence": round(result.confidence, 3),
        "reason": result.reason,
        "questions": len(result.questions),
        "invariants": {
            "all_2280_wide": all(q.images[0].width == 2280 for q in result.questions) if result.questions else None,
            "all_top_band_20": all(measure_top_band(q.images[0]) == 20 for q in result.questions) if result.questions else None,
        },
        "evidence": result.evidence[:6],
    }
    print(json.dumps(report, indent=2))
    return 0 if result.status is not DispatchStatus.REVIEW_REQUIRED else 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(_main())
