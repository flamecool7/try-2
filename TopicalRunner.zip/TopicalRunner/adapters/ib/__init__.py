"""International Baccalaureate adapter."""
