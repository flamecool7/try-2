"""International Baccalaureate adapter.

This adapter is deliberately conservative. IB papers are not Cambridge-like:
timezone, level, language and paper number are native IB identity fields. The
adapter consumes official sample/specimen text where available and can segment
question prompts in the English A Paper 2 specimen once a PDF/layout context is
available. It does not invent unavailable timezone/session data.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from adapters.base import BoardAdapter, DocumentContext, Evidence
from adapters.common_text import page_size, pages_from_layout, page_texts
from adapters.layout_profiles import LayoutArchetype, crop_plan, select_layout_archetype

_SPEC_CODE = re.compile(r"\bSPEC/([0-9])/([A-Z0-9]+)/([A-Z]+)([0-9])?/([A-Z]{3})/TZ([0-9])/XX(?:/([A-Z]))?\b")
# A question start is "1." possibly followed by its text. The text is OPTIONAL on
# purpose: real IB papers (measured on the mirror-sourced May 2024 AA HL Paper 1,
# 2026-09-21) put the number alone on its line with the question following
# underneath, so requiring "\s+(.+)" matched nothing on a real paper and silently
# dropped the whole document to the text-only fallback.
_Q_PROMPT = re.compile(r"^\s*(\d{1,2})\.(?:\s+(.+))?\s*$", re.M)


# --- Question-paper page geometry (multi-page questions) ------------------------
# Measured on the mirror-sourced May 2024 AA HL Paper 1 (17 pp, 2026-09-21):
#   * question markers sit at x0=42.5, the leftmost content of any kind at 42.5
#     and the widest text at x1=555.8;
#   * every page carries furniture at the top (page label " - N - " and running
#     code "2224 - 7101", y 40.6-52.9) and at the bottom (a barcode at y 777.8-
#     812.7 with the paper code below it, plus printer register combs that bleed
#     off the page);
#   * content stops at y=770.8 on every question page (the answer-space border),
#     so a crop ending at the legacy h-46=796 clipped through the barcode.
# A question that needs more room continues on the next page under the printed
# header "(Question 9 continued)" - the question paper, unlike the mark scheme,
# says so in words, so a question's page span is every content page up to the
# next question's start page. Instruction pages ("Please do not write on this
# page ... will not be marked") are paper furniture and never join a span.
_QP_PAGE_TOP = 58.0           # continuation top: clears the 40.6-52.9 furniture band
_QP_FIRST_TOP_PAD = 12.0      # clearance above a question's own first line
_QP_LEFT = 30.0               # 12.5pt clear of the leftmost content (42.5)
_QP_RIGHT_PAD = 30.0          # 26.5pt clear of the widest text (555.8)
_QP_BOTTOM_PAD = 68.0         # content ends 770.8; barcode starts 777.8 (h-68 = 774.0)
_QP_SAME_PAGE_GAP = 8.0       # cut between two questions sharing one page
_QP_CONTINUED = re.compile(r"^\(Question\s+\d+\s+continued\)$", re.I)
_QP_INSTRUCTION = re.compile(
    r"please do not write on this page|answers written on this page", re.I)


def _qp_is_question_page(page: Mapping[str, Any]) -> bool:
    """True for a page that can carry question content.

    Blank pages and the "Please do not write on this page / Answers written on
    this page will not be marked" notices are furniture: they belong to no
    question and must not be added to a question's page span.
    """
    lines = _ms_page_lines(page)
    if not lines:
        return False
    return not any(_QP_INSTRUCTION.search(text) for _, _, _, text in lines)


# --- Mark-scheme geometry ------------------------------------------------------
# Measured on the mirror-sourced May 2024 AA HL Paper 1 markscheme (33 pp,
# 2026-09-21). Ink extents across the 27 answer pages, text AND vector rules:
#   x0 = 42.6  question-number column (a vertical rule shares this x)
#   x1 = 572.9 a rule on p9 (widest text line reaches 570.1)
#   y1 = 796.6 the closing "Total [17 marks]" row and a rule on p28
# Page furniture is the label " - N - " (x0 282.5/285.5) and the running code
# "2224 - 7101M" (x0 484.3); both sit at y 47.1-59.5 on EVERY answer page, so a
# crop that starts above 59.5 picks up page furniture and one that ends before
# 796.6 clips the last row. These boxes are therefore derived from this
# document's own ink, NOT inherited from the question paper: a question paper's
# widest line stops at x1=555.8 and it has no content past y=772, while this
# mark scheme is 16pt wider on the right and 25pt deeper. Same lesson as the AQA
# mark scheme: a crop box is a property of the document type, never of the board.
_MS_MARK_CODES = re.compile(r"^\(?[MARC]\d?\)?$|^AG$")   # (M1) A1 M1 AG R1 ...
_MS_TOTAL_ROW = re.compile(r"^\s*Total\s*\[", re.I)
_MS_FURNITURE_BOTTOM = 62.0   # bottom of the page-label band (59.5) + slack
_MS_PAGE_TOP = 66.0           # continuation-page top: clears the band, above body (83.3)
_MS_FIRST_TOP_PAD = 12.0      # clearance above the first ink of a first page
_MS_LEFT = 30.0               # 12.6pt clear of the leftmost ink (42.6)
_MS_RIGHT_PAD = 16.0          # 6.4pt clear of the rightmost ink (572.9)
_MS_BOTTOM_PAD = 36.0         # 9.4pt clear of the deepest ink (796.6)
_MS_MARKER_MAX_X0 = 60.0      # question numbers sit at x0 42.6-50.2
_MS_ROW_TOL = 2.0             # vertical tolerance when merging ink into visual rows
_MS_SAME_PAGE_GAP = 8.0       # cut between two questions sharing one page


def _ms_page_lines(page: Mapping[str, Any]) -> List[Tuple[float, float, float, str]]:
    out: List[Tuple[float, float, float, str]] = []
    for line in page.get("lines") or []:
        bbox = line.get("bbox") or []
        text = str(line.get("text", "")).strip()
        if len(bbox) == 4 and text:
            out.append((float(bbox[1]), float(bbox[3]), float(bbox[0]), text))
    return out


def _ms_body_lines(page: Mapping[str, Any]) -> List[Tuple[float, float, float, str]]:
    """Lines below the page furniture band, i.e. real markscheme content."""
    return [l for l in _ms_page_lines(page) if l[0] >= _MS_FURNITURE_BOTTOM]


def _ms_is_answer_page(page: Mapping[str, Any]) -> bool:
    """True when the page carries the marks column.

    The front matter (pp 0-5) is a false-positive minefield: an example table
    prints rows beginning "1." and "2." at x0=48.0 -- inside the question-number
    column -- and a "Using the markscheme" list numbers 1-8 at x0=42.6, so page
    geometry alone cannot separate contents from question 1. Every ANSWER page,
    however, carries mark codes ((M1), A1, AG, R1) in the right-hand column at
    x0 > 480, and no front-matter page carries a single one (measured: 0 codes on
    pp 0-5, 2-10 on each of pp 6-32). That is the discriminator, and it is a
    property of the marks column rather than of a page number.
    """
    return any(x0 > 480.0 and bool(_MS_MARK_CODES.match(text)) for _, _, x0, text in _ms_page_lines(page))


def _ms_bands(lines: Sequence[Tuple[float, float, float, str]]) -> List[List[float]]:
    """Merge ink into visual rows by vertical overlap.

    A markscheme row is not one line object: the stacked superscripts of a row
    report fragments whose tops start ABOVE the row's main text (measured: on p7
    the "10^(1/3)" superscripts start at y0=86.5 while the row's "2. (a)" starts
    at y0=98.2). Anything that reads "ink above y" as "the previous question's
    tail" therefore misreads a question's own first row, which is why the
    boundary test below works on merged rows and not on raw line boxes.
    """
    bands: List[List[float]] = []
    for y0, y1 in sorted((l[0], l[1]) for l in lines):
        if bands and y0 <= bands[-1][1] + _MS_ROW_TOL:
            bands[-1][1] = max(bands[-1][1], y1)
        else:
            bands.append([y0, y1])
    return bands


def _ms_borrows_page_top(page: Mapping[str, Any], y0: float, y1: float) -> bool:
    """True when ink sits entirely above the marker's own visual row.

    Those are the cases where a question starts part-way down a page and the
    content above it (a full-width "Note:" preamble for Q8, the "Section B"
    heading for Q10) belongs to the question starting there -- not to the
    previous question. See ``segment_mark_scheme`` for the closure test that
    makes that safe.
    """
    bands = _ms_bands(_ms_body_lines(page))
    for top, bottom in bands:
        if top <= y1 and bottom >= y0:
            return any(b[1] < top for b in bands)
    return False


def _ms_has_total_row(page: Mapping[str, Any]) -> bool:
    return any(_MS_TOTAL_ROW.match(text) for _, _, _, text in _ms_page_lines(page))


class Adapter(BoardAdapter):
    BOARD_ID = "IB"
    BOARD_NAMES = ["International Baccalaureate", "IB", "IBO"]
    CONFIG_FILE = "config/boards/ib.yaml"

    def normalize_name(self, raw: str) -> str:
        return re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")

    def _hay(self, ctx: DocumentContext) -> str:
        return f"{ctx.filename}\n{ctx.first_page_text}\n{ctx.full_text}".lower()

    def identify_document(self, ctx: DocumentContext) -> List[Evidence]:
        hay = self._hay(ctx)
        out: List[Evidence] = []
        if "international baccalaureate" in hay or "ibo.org" in hay:
            out.append(Evidence("board_signature", "board", self.BOARD_ID, 0.95, "IB/IBO source text", "document"))
        if _SPEC_CODE.search(ctx.full_text or ctx.first_page_text or ""):
            out.append(Evidence("component_code", "board", self.BOARD_ID, 1.0, "IB SPEC code present", "document"))
        return out

    def identify_subject(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        out: List[Evidence] = []
        if "English A: literature" in text:
            out.append(Evidence("first_page_text", "subject", "English A: literature", 0.95, "official specimen title", "document"))
            out.append(Evidence("qualification_code", "subject_code", "A1ENG", 0.75, "English A literature specimen code family", "document"))
        elif "Biology" in text and "Paper 1A" in text:
            out.append(Evidence("first_page_text", "subject", "Biology", 0.9, "official specimen title", "document"))
            out.append(Evidence("qualification_code", "subject_code", "BIOLO", 0.75, "Biology specimen code family", "document"))
        m = _SPEC_CODE.search(text)
        if m:
            out.append(Evidence("component_code", "subject_code", m.group(2), 0.9, f"IB code {m.group(0)!r}", "document"))
        return out

    def identify_qualification(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        if "Diploma" in text or "Higher and standard level" in text or "Higher level" in text:
            return [Evidence("first_page_text", "qualification", "DP", 0.9, "DP specimen wording / HL-SL levels", "document")]
        return []

    def identify_session(self, ctx: DocumentContext) -> List[Evidence]:
        """Read the examination session the document prints.

        Real IB covers carry it as a date line ("1 May 2024 | Zone A afternoon")
        or a session label ("May 2024"); specimens carry "SPEC/". The token is
        matched against this adapter's OWN config session table, and it is
        anchored to a following four-digit year ON PURPOSE: "may" is an English
        modal verb, and every IB page-1 copyright notice reads "No part of this
        product may be reproduced ..." - matching that would stamp a false May
        session on every paper in the corpus. Validated against real mirror-sourced
        papers (2026-09-21, A4): both the QP and its markscheme resolve to May 2024.
        """
        text = ctx.full_text or ctx.first_page_text or ""
        out: List[Evidence] = []
        if "Specimen paper" in text or "SPEC/" in text:
            # field is "season": that is the name every consumer asks for
            # (adapters.associations._ask("identify_session", "season")). Emitting
            # "session" here made the evidence invisible (found 2026-09-21).
            out.append(Evidence("first_page_text", "season", "SPECIMEN", 1.0, "specimen paper", "document"))
        session_year: Optional[int] = None
        for spec in self.sessions():
            token = str(getattr(spec, "name", "") or "").strip()
            if len(token) < 3:
                continue
            m = re.search(r"\b" + re.escape(token) + r"\s+(20\d{2}|19\d{2})\b", text)
            if m:
                out.append(Evidence("first_page_text", "season", spec.name, 0.9,
                                    f"session date line {m.group(0)!r}", "document"))
                session_year = int(m.group(1))
                break
        if session_year is not None:
            out.append(Evidence("first_page_text", "year", session_year, 0.9,
                                "year taken from the session date line", "document"))
            return out
        m = re.search(r"©\s*International Baccalaureate Organization\s*(20\d{2}|19\d{2})", text)
        if m:
            out.append(Evidence("first_page_text", "year", int(m.group(1)), 0.7, "copyright/source year, not an exam session", "document"))
        return out

    def identify_component(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        out: List[Evidence] = []
        # The previous check could only ever match "Paper 2", so a real Paper 1 or
        # Paper 3 could only be named by the legacy fallback parser - two
        # authorities for the same field. Now the adapter supplies it, and stays
        # silent when the document names more than one paper (UNKNOWN over a guess).
        papers: List[str] = []
        for m in re.finditer(r"\bPaper\s+([123])\b", text, re.I):
            if m.group(1) not in papers:
                papers.append(m.group(1))
        if len(papers) == 1:
            out.append(Evidence("first_page_text", "component", f"Paper {papers[0]}", 0.9,
                                f"Paper {papers[0]} title", "document"))
            out.append(Evidence("first_page_text", "paper_number", papers[0], 0.9,
                                f"Paper {papers[0]} title", "document"))
        if "Higher and standard level" in text or "Higher and Standard level" in text:
            out.append(Evidence("first_page_text", "level", "HL_SL", 0.85, "Higher and standard level", "document"))
        m = _SPEC_CODE.search(text)
        if m:
            out.append(Evidence("component_code", "component", m.group(0), 0.95, "IB native SPEC code", "document"))
            out.append(Evidence("component_code", "timezone", f"TZ{m.group(6)}", 0.95, "timezone from IB SPEC code", "document"))
        return out

    def identify_document_type(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        if "Markscheme" in text or "marking notes" in text:
            return [Evidence("header_footer", "document_type", "MS", 0.85, "markscheme/marking notes text", "document")]
        # "Answer one question" is the ESSAY-paper wording. Real science and
        # mathematics papers say "answer all questions" (measured on the
        # mirror-sourced May 2024 AA HL Paper 1, 2026-09-21), so requiring the
        # essay wording typed every maths paper as UNKNOWN.
        if "Instructions to candidates" in text and re.search(r"answer (all|one) question", text, re.I):
            return [Evidence("header_footer", "document_type", "QP", 0.9, "IB question-paper instructions", "document")]
        return []

    def identify_question_structure(self, ctx: DocumentContext) -> List[Evidence]:
        segs = self.segment(ctx)
        if segs:
            return [Evidence("document_structure", "question_count", len(segs), 0.9, "IB prompt segmentation", "document")]
        return []

    def identify_mark_scheme(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "MS"]

    def identify_examiner_report(self, ctx: DocumentContext) -> List[Evidence]:
        return []

    def segments_document(self) -> bool:
        return True

    def segments_mark_scheme(self) -> bool:
        return True

    def _ms_question_starts(self, ctx: DocumentContext) -> List[Tuple[int, int, float, float]]:
        """(question number, page_index, marker top, marker bottom) for each start."""
        out: List[Tuple[int, int, float, float]] = []
        for page in pages_from_layout(ctx):
            if not _ms_is_answer_page(page):
                continue
            page_index = int(page.get("page_index", 0))
            for y0, y1, x0, text in _ms_body_lines(page):
                match = _Q_PROMPT.match(text)
                if match and x0 <= _MS_MARKER_MAX_X0:
                    out.append((int(match.group(1)), page_index, y0, y1))
        return sorted(out, key=lambda item: (item[1], item[2]))

    def segment_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Segment an IB markscheme into one region per top-level question.

        Returns ``[]`` -- never a partial set -- when the document does not
        present a clean 1..N of question starts, so the caller falls back to
        QP-only routing instead of emitting a markscheme whose coverage is
        quietly wrong. Two measured rules drive the page spans:

        1. A question owns whole pages, from its start page up to (but not
           including) the next question's start page, except when two questions
           share one page -- then the cut sits at the current question's own
           "Total [n marks]" row. Whole pages are deliberate: on this document 8
           of the 12 boundaries have the next question starting part-way down a
           page, and the ink above a marker is sometimes that question's own
           preamble (Q8's "Note:" block on p17, "Section B" above Q10 on p21).
        2. Such a borrowed page top is only trusted when the PREVIOUS question
           is provably closed by a "Total [n marks]" row on the page before.
           Without that row the segmentation refuses: guessing the boundary
           would silently drop marks.
        """
        starts = self._ms_question_starts(ctx)
        if not starts:
            return []
        numbers = [item[0] for item in starts]
        # Strict 1..N in page order: one stray "10." (front matter p5 prints one
        # at x0=42.6) or a duplicated number means this is not a document whose
        # structure was understood, so refuse rather than emit a partial scheme.
        if numbers != list(range(1, len(numbers) + 1)):
            return []

        pages = {int(page.get("page_index", 0)): page for page in pages_from_layout(ctx)}
        answer_pages = sorted(pi for pi, page in pages.items() if _ms_is_answer_page(page))
        if not answer_pages:
            return []
        last_answer_page = answer_pages[-1]

        labels = self._segment_identity(ctx)
        archetype = select_layout_archetype(self.BOARD_ID, ctx)
        segments: List[Dict[str, Any]] = []

        for idx, (qn, page_index, marker_top, marker_bottom) in enumerate(starts):
            if page_index not in pages:
                return []
            next_start = starts[idx + 1] if idx + 1 < len(starts) else None
            next_page = next_start[1] if next_start else last_answer_page + 1

            if idx > 0 and _ms_borrows_page_top(pages[page_index], marker_top, marker_bottom):
                if not _ms_has_total_row(pages.get(page_index - 1) or {}):
                    return []

            if next_page == page_index:
                # Two questions share one page: the only safe cut is the current
                # question's closing Total row. No row, no cut, no segment.
                totals = [b for a, b, _, text in _ms_page_lines(pages[page_index])
                          if _MS_TOTAL_ROW.match(text) and marker_bottom < a < next_start[2]]
                if not totals:
                    return []
                bottom = min(next_start[2] - 1.0, max(totals) + _MS_SAME_PAGE_GAP)
                if bottom <= marker_bottom:
                    return []
                page_rects = [(page_index, bottom)]
            else:
                page_rects = [(p, None) for p in range(page_index, next_page)]

            page_boxes: List[Dict[str, Any]] = []
            for p, cut in page_rects:
                w, h = page_size(ctx, p)
                body = _ms_body_lines(pages[p])
                if p == page_index:
                    # A question's first page starts at that page's first ink, so
                    # a preamble above the marker travels with the question.
                    first_ink = min((line[0] for line in body), default=marker_top)
                    top = max(_MS_PAGE_TOP, first_ink - _MS_FIRST_TOP_PAD)
                else:
                    top = _MS_PAGE_TOP
                bottom = h - _MS_BOTTOM_PAD if cut is None else cut
                page_boxes.append({"page_index": p, "rect": (_MS_LEFT, top, w - _MS_RIGHT_PAD, bottom)})
            if not page_boxes:
                continue

            segments.append({
                "id": f"IB_{labels['component']}_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": labels["component"],
                "pages": page_boxes,
                "metadata": {
                    "document_type": "MS",
                    "source_pages": [box["page_index"] + 1 for box in page_boxes],
                    "ib_level": labels["level"],
                    "session": labels["session"],
                    "layout_archetype": archetype.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "ms_geometry": (
                        "whole answer pages per question; first page top = that page's first ink - 12pt "
                        "(floor 66pt, below the page-label band at 47.1-59.5); continuation top 66pt; "
                        "box (30.0, top, w-16.0, h-36.0) measured against this markscheme's own ink "
                        "(x0 42.6, x1 572.9, y1 796.6) -- NOT the question paper's box"
                    ),
                },
            })
        return segments

    def _layout_question_positions(self, ctx: DocumentContext) -> List[Tuple[int, int, float]]:
        out: List[Tuple[int, int, float]] = []
        for page in pages_from_layout(ctx):
            pi = int(page.get("page_index", 0))
            for line in page.get("lines") or []:
                txt = str(line.get("text", "")).strip()
                m = _Q_PROMPT.match(txt)
                if not m:
                    continue
                bbox = line.get("bbox") or []
                if len(bbox) == 4:
                    out.append((int(m.group(1)), pi, float(bbox[1])))
        return sorted(out, key=lambda t: (t[1], t[2], t[0]))

    def _segment_identity(self, ctx: DocumentContext) -> Dict[str, str]:
        """Labels for a segment, taken from THIS document's own evidence.

        The first version of this adapter hardcoded ``IB_EnglishA_P2_Specimen_Q…``,
        ``component: "P2"`` and "official IBO specimen text via page fetcher" into
        every segment it produced - fine while the only input was the specimen
        text, actively wrong once a real mathematics Paper 1 arrived (it would have
        labelled real maths crops as an English A specimen). Nothing here is
        inferred: each value comes from the adapter's own evidence method, and
        stays UNKNOWN when the document does not say.
        """
        component = "UNKNOWN"
        level = "UNKNOWN"
        for ev in self.identify_component(ctx):
            value = str(getattr(ev, "value", "") or "")
            if ev.field == "component" and re.fullmatch(r"Paper\s+[123]", value):
                component = "P" + value.split()[-1]
            elif ev.field == "level":
                level = value
        if level == "UNKNOWN":
            text = ctx.full_text or ctx.first_page_text or ""
            higher = bool(re.search(r"\bHigher level\b", text))
            standard = bool(re.search(r"\bStandard level\b", text))
            if higher and not standard:
                level = "HL"
            elif standard and not higher:
                level = "SL"
        session = "UNKNOWN"
        for ev in self.identify_session(ctx):
            if ev.field == "season":
                session = str(ev.value)
                break
        return {"component": component, "level": level, "session": session}

    def segment(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        # Layout path: real PDF/layout present, renderable by segment_geometry.
        positions = self._layout_question_positions(ctx)
        if positions:
            labels = self._segment_identity(ctx)
            archetype = select_layout_archetype(self.BOARD_ID, ctx)
            layout_pages = pages_from_layout(ctx)
            segments: List[Dict[str, Any]] = []
            for idx, (qn, page_index, y) in enumerate(positions):
                next_position = positions[idx + 1] if idx + 1 < len(positions) else None

                # One segment per question, over ALL of its pages. A question that
                # needs more room continues under a printed "(Question N continued)"
                # header (Q9 of the real paper holds its "sketch the graph" part on
                # the second page); cropping only the start page silently dropped
                # that answer space. Pages run up to, but never include, the page
                # the next question starts on.
                share_page_cut = None
                if next_position is not None and next_position[1] == page_index:
                    share_page_cut = max(40.0, next_position[2] - _QP_SAME_PAGE_GAP)
                    page_numbers = [page_index]
                else:
                    last = next_position[1] if next_position is not None else len(layout_pages)
                    page_numbers = [p for p in range(page_index, last)
                                    if _qp_is_question_page(layout_pages[p])]
                if not page_numbers:
                    continue

                # Margins measured on the real paper (May 2024 AA HL Paper 1,
                # 2026-09-21): question numbers sit at x0=42.5 and the widest text
                # reaches x1=555.8, so the original 48.0 margin CLIPPED the number
                # of every question it cropped (only the period survived). 30 pt
                # symmetric margins cover the full text extent; the bottom stops at
                # h-68 because a lower edge cut through the page barcode. Same rule
                # the AQA mark scheme needed: measure ink per document, never
                # inherit a box.
                page_boxes: List[Dict[str, Any]] = []
                for p in page_numbers:
                    w, h = page_size(ctx, p)
                    top = max(_QP_PAGE_TOP, y - _QP_FIRST_TOP_PAD) if p == page_index else _QP_PAGE_TOP
                    bottom = h - _QP_BOTTOM_PAD
                    if share_page_cut is not None and p == page_numbers[-1]:
                        bottom = min(bottom, share_page_cut)
                    page_boxes.append({"page_index": p, "rect": (_QP_LEFT, top, w - _QP_RIGHT_PAD, bottom)})

                segments.append({
                    "id": f"IB_{labels['component']}_Q{qn}",
                    "question_number": qn,
                    "board": self.BOARD_ID,
                    "component": labels["component"],
                    "canonical_question": qn,
                    "pages": page_boxes,
                    "metadata": {"source_page": page_index + 1,
                                 "source_pages": [box["page_index"] + 1 for box in page_boxes],
                                 "ib_level": labels["level"],
                                 "session": labels["session"], "layout_archetype": archetype.value,
                                 "crop_plan": crop_plan(self.BOARD_ID, ctx),
                                 "naming_decision": "IB segment labelled from document evidence, not the specimen fixture"},
                })
            return segments

        # Text-only proof path for official IBO pages when direct PDF download is
        # blocked by Cloudflare in this sandbox. Not renderable, clearly marked.
        text = ctx.full_text or ctx.first_page_text or ""
        labels = self._segment_identity(ctx)
        # The specimen text is the one validated text source; anything else that
        # reaches this path has page geometry we failed to read, and says so.
        is_text_source = getattr(ctx, "suffix", "").lower() in {".md", ".txt"}
        prompts = [(int(m.group(1)), (m.group(2) or "").strip()) for m in _Q_PROMPT.finditer(text)]
        source_note = ("official IBO specimen text via page fetcher" if is_text_source
                       else "text-only: no page geometry read from this document")
        component = "P2" if is_text_source else labels["component"]
        session = "SPECIMEN" if is_text_source else labels["session"]
        return [{
            "id": ("IB_EnglishA_P2_Specimen_Q{}".format(qn) if is_text_source
                   else f"IB_{labels['component']}_Q{qn}"),
            "question_number": qn,
            "board": self.BOARD_ID,
            "component": component,
            "pages": [],
            "text_only": True,
            "metadata": {"prompt": prompt, "source": source_note, "renderable": False,
                         "session": session,
                         "layout_archetype": (LayoutArchetype.TEXT_ONLY_OFFICIAL_SOURCE.value
                                              if is_text_source else
                                              select_layout_archetype(self.BOARD_ID, ctx).value),
                         "crop_plan": crop_plan(self.BOARD_ID, ctx)},
        } for qn, prompt in prompts]
