"""IB questions classified by the SAME machinery as Cambridge subjects.

Twin of ``adapters.edexcel.classification`` (profile discovery pointed at
``subjects_ib/`` instead of ``subjects_edexcel/``). IB-only note: components
carry paper letters (``IBBI/1A``, ``IBBI/1B``, ``IBBI/2``); core's per-paper
gate reads the variant's first character, so 1A/1B both gate to paper "1"
with no adjustment needed (no zero-padded variants exist on this board).

An IB subject profile lives in
``subjects_ib/<Programme>/<Subject_Code>/config.json`` in the Cambridge
``SubjectConfig`` schema. It is loaded into
``core.config_loader.SubjectConfig`` and classified by
``core.classifier.TopicClassifier`` — never a parallel keyword scorer.

Nothing under ``core/`` changes; CAIE behaviour is byte-identical.

IB vocabularies are PROVISIONAL (guides paywalled; built from official
subject briefs + IBO pages + CAIE-cognate vocab — see each profile's
validation/provenance notes). Full-standard profiles need user-supplied
guides.

Fallback (allowed by the work order, never primary): a spec code with no
profile here, or a profile that fails to load, falls back to
``adapters.nonib_topics`` (the Phase-0 vocabulary) and says so
(``engine: nonib_fallback``).
"""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Optional

from adapters import nonib_topics as _fallback

PROJ = Path(__file__).resolve().parent.parent.parent
PROFILE_ROOT = PROJ / "subjects_ib"

_CACHE: Dict[str, Any] = {}


def profile_path(spec_code: str) -> Optional[Path]:
    for cfg in sorted(PROFILE_ROOT.glob(f"*/*_{spec_code}/config.json")):
        return cfg
    return None


def load_profile(spec_code: str):
    """(SubjectConfig, TopicClassifier) for a spec code, or (None, None) when no profile exists."""
    if spec_code in _CACHE:
        return _CACHE[spec_code]
    path = profile_path(spec_code)
    if path is None:
        _CACHE[spec_code] = (None, None)
        return _CACHE[spec_code]
    from core.config_loader import SubjectConfig
    from core.classifier import TopicClassifier
    data = json.loads(path.read_text(encoding="utf-8"))
    config = SubjectConfig(data, config_path=path)
    classifier = TopicClassifier(config)          # no classification memory: never auto-populated
    _CACHE[spec_code] = (config, classifier)
    return _CACHE[spec_code]


def _stub(text: str, question_number: Any, component: str, year: str = "", season: str = "") -> SimpleNamespace:
    """A MatchedQuestion-shaped object carrying the crop's own text (marks read from the text)."""
    import re
    marks = sum(int(m) for m in re.findall(r"\[(\d{1,2})\s*marks?\]", text or "", re.I))
    qp = SimpleNamespace(text=text or "", marks=marks, paper_code=component, question_number=f"Q{question_number}",
                         number_int=int(question_number or 0), assembled_image=None, images=[])
    variant = (component.split("/")[1] if "/" in component else "") or ""
    return SimpleNamespace(question_number=f"Q{question_number}", number_int=int(question_number or 0),
                           qp=qp, ms=None, paper_code=component, full_qp_code=component, full_ms_code="",
                           year=year or "", season=season or "", variant=variant, subject="", paper_format="STRUCTURED")


def _confidence(result) -> float:
    """Calibrated like the Phase-0 formula, from the classifier's own major scores: margin between the
    winner and the runner-up plus the winner's strength against the 1.5-point floor."""
    scores = dict(result.major_topic_scores or {})
    if not scores or not result.winning_major:
        return 0.0
    top = float(scores.get(result.winning_major, 0.0))
    others = sorted((float(v) for k, v in scores.items() if k != result.winning_major), reverse=True)
    second = others[0] if others else 0.0
    margin = (top - second) / top if top > 0 else 0.0
    strength = min(1.0, top / 6.0)
    return round(min(0.97, 0.50 + 0.30 * margin + 0.20 * strength), 3)


def classify_text(spec_code: str, text: str, *, question_number: Any = 0, component: str = "",
                  year: str = "", season: str = "") -> Dict[str, Any]:
    config, classifier = load_profile(spec_code)
    if classifier is None:
        out = _fallback.classify_segment_topic("IB", text, component=component)
        out["engine"] = "nonib_fallback"
        return out
    result = classifier.classify_question(_stub(text, question_number, component or spec_code, year, season))
    tier = getattr(result, "fallback_tier", "scored")
    scores = dict(result.major_topic_scores or {})
    ranked = sorted(scores.items(), key=lambda kv: (-float(kv[1]), kv[0]))
    if tier in ("review_required", "alphabetical_first", "paper_hint") or not result.winning_major:
        # fail closed exactly like a Cambridge question with insufficient direct evidence
        return {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED", "evidence": [],
                "secondary": [], "spec": spec_code, "engine": "caie_classifier", "fallback_tier": tier,
                "candidates": [{"topic": k, "score": round(float(v), 3)} for k, v in ranked[:3]],
                "reasoning": str(getattr(result, "reasoning", ""))[:300]}
    weights = dict(getattr(config, "specialization_weights", {}) or {})
    aspects = {k for k, w in weights.items() if float(w) < 1.0}      # 0475 precedent: forms primary, aspects secondary
    pool = [(k, v) for k, v in ranked if k != result.winning_major and (not aspects or k in aspects)]
    secondary = [k for k, v in pool if float(v) >= 1.5][:2]
    return {"topic": result.winning_major, "confidence": _confidence(result), "status": "HINT",
            "evidence": list(result.detailed_topics or [])[:4] + [f"score {scores.get(result.winning_major, 0):.2f}"],
            "secondary": secondary, "spec": spec_code, "engine": "caie_classifier", "fallback_tier": tier,
            "major_scores": {k: round(float(v), 3) for k, v in ranked[:4]},
            "reasoning": str(getattr(result, "reasoning", ""))[:300]}
