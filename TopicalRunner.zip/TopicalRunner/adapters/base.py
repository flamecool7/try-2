"""
adapters.base — BOARD ADAPTER INTERFACE CONTRACT

Spec: UNIVERSAL-EXAM-TOPICAL-GEN-MEGAPROMPT-v2.txt §15.1.

Every board adapter implements the nine `identify_*` methods plus naming
normalisation, researched MCQ-format knowledge and researched component-taxonomy
knowledge. Adding a board = new adapter package + qualification registry entries
+ research documents + corpus fixtures. **The core engine is never modified.**

The universal core must contain NO `if board == "CAIE"` logic (directive §4,
spec §1.2). All board variance is expressed through this interface and through
data in `config/boards/*.yaml` and `taxonomies/`.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from universal.status import DetectionStatus, DOCUMENT_TYPES


# ---------------------------------------------------------------------------
# Evidence — the atomic unit of identity resolution (directive §7)
# ---------------------------------------------------------------------------
@dataclass
class Evidence:
    """One observed fact about a document, with its provenance and weight key.

    `kind` must match a key in config.yaml `detection.weights` so that evidence
    fusion is data-driven and tunable rather than hardcoded.
    """
    kind: str                                  # e.g. "first_page_text"
    field: str                                 # e.g. "year"
    value: Any                                 # e.g. 2026
    confidence: float = 1.0                    # 0..1 — quality of THIS observation
    detail: str = ""                           # human-readable provenance
    locator: str = ""                          # where in the doc (page, bbox…)

    def as_dict(self) -> Dict[str, Any]:
        return {"kind": self.kind, "field": self.field, "value": self.value,
                "confidence": round(float(self.confidence), 4),
                "detail": self.detail, "locator": self.locator}


@dataclass
class FieldVote:
    """Fused result for one identity field."""
    field: str
    value: Any
    confidence: float
    status: DetectionStatus
    alternatives: List[Dict[str, Any]] = field(default_factory=list)
    evidence: List[Evidence] = field(default_factory=list)
    conflict: bool = False

    def as_dict(self) -> Dict[str, Any]:
        return {"field": self.field, "value": self.value,
                "confidence": round(float(self.confidence), 4),
                "status": self.status.value, "conflict": self.conflict,
                "alternatives": self.alternatives,
                "evidence": [e.as_dict() for e in self.evidence]}


@dataclass
class DocumentIdentity:
    """Canonical identity of an examination document (directive §7 output)."""
    board: Optional[str] = None
    qualification: Optional[str] = None
    syllabus: Optional[str] = None            # subject code / specification code
    syllabus_version: Optional[str] = None
    subject: Optional[str] = None
    subject_code: Optional[str] = None
    year: Optional[int] = None
    session: Optional[str] = None             # normalized session CODE
    session_name: Optional[str] = None        # human name, e.g. "May/June"
    component: Optional[str] = None           # board-native component id
    paper_number: Optional[str] = None
    variant: Optional[str] = None
    document_type: Optional[str] = None       # QP | MS | ER | INSERT | SYLLABUS
    tier: Optional[str] = None                # foundation/higher, core/extension…
    language: Optional[str] = None
    region: Optional[str] = None              # e.g. "Pakistan only"
    total_marks: Optional[int] = None
    page_count: Optional[int] = None
    confidence: float = 0.0
    status: DetectionStatus = DetectionStatus.UNKNOWN
    votes: Dict[str, FieldVote] = field(default_factory=dict)
    findings: List[Dict[str, Any]] = field(default_factory=list)
    source_path: Optional[str] = None
    source_filename: Optional[str] = None
    ocr_used: bool = False
    has_text_layer: Optional[bool] = None

    # -- convenience ---------------------------------------------------------
    @property
    def conflicts(self) -> List[str]:
        return [f for f, v in self.votes.items() if v.conflict]

    @property
    def review_required(self) -> bool:
        return (self.status == DetectionStatus.REVIEW_REQUIRED
                or bool(self.conflicts)
                or any(f.get("status") == "REVIEW_REQUIRED" for f in self.findings))

    def as_dict(self) -> Dict[str, Any]:
        d = {k: v for k, v in self.__dict__.items() if k not in ("votes",)}
        d["status"] = self.status.value
        d["votes"] = {k: v.as_dict() for k, v in self.votes.items()}
        d["conflicts"] = self.conflicts
        return d


# ---------------------------------------------------------------------------
# Component / session knowledge — RESEARCHED, per board, data-driven
# ---------------------------------------------------------------------------
@dataclass
class ComponentSpec:
    """One board-native component. Never assume P1..P6 mean the same thing
    across boards (directive §10)."""
    component_id: str                 # as printed by the board, e.g. "42", "1H", "4CH1/2C"
    paper_number: Optional[str] = None
    variant: Optional[str] = None
    name: str = ""
    type: str = "THEORY"              # MCQ | THEORY | PRACTICAL | COURSEWORK | ORAL
    is_mcq: bool = False
    expected_question_count: Optional[int] = None
    tier: Optional[str] = None
    aliases: List[str] = field(default_factory=list)
    provenance: str = ""              # where this fact came from (URL / PDF / corpus)
    verified: bool = False            # "board says it exists" vs "we proved it"


@dataclass
class SessionSpec:
    code: str                         # normalized internal code
    name: str                         # human name
    aliases: List[str] = field(default_factory=list)
    months: List[int] = field(default_factory=list)
    filename_tokens: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# The contract
# ---------------------------------------------------------------------------
class BoardAdapter(abc.ABC):
    """Base class every board adapter must subclass."""

    #: stable machine id, e.g. "CAIE"
    BOARD_ID: str = ""
    #: human names / aliases used for detection and display
    BOARD_NAMES: List[str] = []
    #: where the board's own data lives (yaml under config/boards/)
    CONFIG_FILE: str = ""
    #: does this board publish examiner reports at all?
    HAS_EXAMINER_REPORTS: bool = True
    #: does this board publish inserts / resource booklets?
    HAS_INSERTS: bool = True

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        self.config: Dict[str, Any] = config or {}
        self.qualifications: List[Dict[str, Any]] = self.config.get("qualifications", [])
        self._components: Dict[str, List[ComponentSpec]] = {}
        self._sessions: List[SessionSpec] = []
        self._load_board_knowledge()

    # -- board knowledge (data-driven; override only to add behaviour) --------
    def _load_board_knowledge(self) -> None:
        for s in self.config.get("sessions", []):
            self._sessions.append(SessionSpec(
                code=s["code"], name=s.get("name", s["code"]),
                aliases=list(s.get("aliases", [])),
                months=list(s.get("months", [])),
                filename_tokens=list(s.get("filename_tokens", [])),
            ))
        for syll, comps in (self.config.get("components") or {}).items():
            self._components[syll] = [
                ComponentSpec(component_id=str(c.get("component_id")),
                              paper_number=c.get("paper_number"),
                              variant=c.get("variant"),
                              name=c.get("name", ""),
                              type=c.get("type", "THEORY"),
                              is_mcq=bool(c.get("is_mcq", False)),
                              expected_question_count=c.get("expected_question_count"),
                              tier=c.get("tier"),
                              aliases=list(c.get("aliases", [])),
                              provenance=c.get("provenance", ""),
                              verified=bool(c.get("verified", False)))
                for c in comps
            ]

    # -- the nine required identify_* methods (§15.1) ------------------------
    @abc.abstractmethod
    def identify_document(self, ctx: "DocumentContext") -> List[Evidence]:
        """All board-level evidence for this document."""

    @abc.abstractmethod
    def identify_subject(self, ctx: "DocumentContext") -> List[Evidence]: ...

    @abc.abstractmethod
    def identify_qualification(self, ctx: "DocumentContext") -> List[Evidence]: ...

    @abc.abstractmethod
    def identify_session(self, ctx: "DocumentContext") -> List[Evidence]: ...

    @abc.abstractmethod
    def identify_component(self, ctx: "DocumentContext") -> List[Evidence]: ...

    @abc.abstractmethod
    def identify_document_type(self, ctx: "DocumentContext") -> List[Evidence]: ...

    @abc.abstractmethod
    def identify_question_structure(self, ctx: "DocumentContext") -> List[Evidence]: ...

    @abc.abstractmethod
    def identify_mark_scheme(self, ctx: "DocumentContext") -> List[Evidence]: ...

    @abc.abstractmethod
    def identify_examiner_report(self, ctx: "DocumentContext") -> List[Evidence]: ...

    # -- naming normalisation ------------------------------------------------
    @abc.abstractmethod
    def normalize_name(self, raw: str) -> str:
        """Normalise a board-native identifier into the canonical internal form."""

    # -- researched knowledge accessors --------------------------------------
    def sessions(self) -> List[SessionSpec]:
        return list(self._sessions)

    def components_for(self, syllabus: str) -> List[ComponentSpec]:
        return list(self._components.get(syllabus, []))

    def all_components(self) -> Dict[str, List[ComponentSpec]]:
        return {k: list(v) for k, v in self._components.items()}

    def is_mcq_component(self, syllabus: str, component_id: str) -> Optional[bool]:
        """True/False when the board's researched component table is decisive;
        None when unknown — callers must then decide from document structure and
        never assume (directive §14)."""
        for c in self._components.get(syllabus, []):
            if c.component_id == str(component_id) or str(component_id) in c.aliases:
                return c.is_mcq
        return None

    def supports_document_type(self, doc_type: str) -> bool:
        if doc_type == "ER":
            return self.HAS_EXAMINER_REPORTS
        if doc_type == "INSERT":
            return self.HAS_INSERTS
        return doc_type in DOCUMENT_TYPES

    # -- segmentation hooks (SAT needs these; others use the defaults) --------
    def segments_document(self) -> bool:
        """True when the board needs bespoke segmentation before question
        detection (SAT modules — spec §15.6)."""
        return False

    def segment(self, ctx: "DocumentContext") -> List[Dict[str, Any]]:
        return []

    # -- mark-scheme segmentation hooks ---------------------------------------
    def segments_mark_scheme(self) -> bool:
        """True when the board can segment a MARK SCHEME into per-question regions.

        Separate from :meth:`segments_document` because a question paper and its
        mark scheme are different layouts: a board that has a working question-paper
        splitter has said nothing about its mark schemes. An adapter that has not
        been validated on a real mark scheme must return False here so the caller
        falls back to QP-only routing rather than feeding the mark scheme to another
        board's engine.
        """
        return False

    def segment_mark_scheme(self, ctx: "DocumentContext") -> List[Dict[str, Any]]:
        return []

    def __repr__(self) -> str:  # pragma: no cover
        return f"<{type(self).__name__} board={self.BOARD_ID} sessions={len(self._sessions)} component_tables={len(self._components)}>"


# ---------------------------------------------------------------------------
# DocumentContext — everything an adapter may look at, prepared once by the
# ingestion layer so no adapter re-opens or re-OCRs the PDF.
# ---------------------------------------------------------------------------
@dataclass
class DocumentContext:
    path: str
    filename: str
    stem: str
    suffix: str
    size_bytes: int = 0
    sha256: str = ""
    # PDF-level
    page_count: int = 0
    pdf_metadata: Dict[str, Any] = field(default_factory=dict)
    has_text_layer: Optional[bool] = None
    text_chars_per_page: List[int] = field(default_factory=list)
    # content (cheap, always attempted first)
    first_page_text: str = ""
    full_text: str = ""
    header_footer_text: str = ""
    # content (expensive, only when triggered)
    ocr_text: str = ""
    ocr_lines: List[Dict[str, Any]] = field(default_factory=list)
    ocr_used: bool = False
    # layout
    layout: Dict[str, Any] = field(default_factory=dict)
    images_per_page: List[int] = field(default_factory=list)
    drawings_per_page: List[int] = field(default_factory=list)
    # corpus / provenance
    source_url: Optional[str] = None
    provenance: Dict[str, Any] = field(default_factory=dict)
    # adapter scratch space
    extra: Dict[str, Any] = field(default_factory=dict)

    def best_text(self) -> str:
        """Text layer if present, otherwise OCR. Never fabricate."""
        return self.full_text.strip() or self.ocr_text.strip()

    def first_page_evidence_text(self) -> str:
        return (self.first_page_text.strip()
                or "\n".join(l.get("text", "") for l in self.ocr_lines
                             if l.get("page") == 0))


__all__ = ["Evidence", "FieldVote", "DocumentIdentity", "ComponentSpec",
           "SessionSpec", "BoardAdapter", "DocumentContext",
           "Sequence", "DOCUMENT_TYPES"]
