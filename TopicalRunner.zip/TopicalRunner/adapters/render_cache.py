"""Content-addressed crop cache for the universal batch runner (efficiency item 4).

Re-running a batch that already rendered most of its crops -- the common case in the web app,
where a user adds one paper to a folder that already holds a season -- used to re-render and
re-encode every question from scratch. Rendering is the expensive half of a run (PDF
rasterising + the locked assembly + the lossless WEBP encoder: 25.3 s of a 4-PDF demo, and the
share grows with paper count), so a run that changes nothing should not pay for it twice.

A crop is identified by everything that can change its bytes: the source PDF's SHA-256, the
segment's board and page rectangles (to 0.1 pt), the effective render scale, the 2280 px target
width, and the encoder tag. Any of those changing is a different key, so the cache can never
hand back a crop the current settings would not have produced. The entry stores the written
file name plus the same measurements ``segment_geometry.measure_crop`` records (width, height,
top band, top-band ink) -- a hit therefore skips not only the render but the measurement pass,
and the output contract still runs against those numbers with the file only opened for its
header (see output_contracts.validate_rendered_webps).

The cache lives beside the crops it describes (``render_cache.json`` in the same output
directory), so it is scoped to one document's output, dies with it, and is trivially inspectable.
``--no-cache`` bypasses lookups *and* writes, which is the escape hatch for "render it again
exactly as the code does today".
"""
from __future__ import annotations

import json
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

#: Bump when the render/encode path changes in a way the key fields cannot see (e.g. the band
#: sanitiser, the assembler padding, a new WEBP feature). Old caches then simply miss.
CACHE_VERSION = 1
CACHE_FILENAME = "render_cache.json"


def encoder_tag(*, lossless: bool = True, quality: int = 95, method: int = 4) -> str:
    """Stable label for the encoder settings that produced a crop."""

    return f"webp-{'lossless' if lossless else 'lossy'}-q{quality}-m{method}"


def segment_key(pdf_sha256: str, segment: Mapping[str, Any], *, scale: float | None,
                target_width: int, encoder: str) -> str:
    """SHA-256 over everything that decides a crop's bytes (see module docstring)."""

    pages: List[Dict[str, Any]] = []
    for page in segment.get("pages") or []:
        rect = page.get("rect") or page.get("clip") or []
        try:
            rounded = [round(float(value), 1) for value in rect][:4]
        except (TypeError, ValueError):
            rounded = []
        pages.append({"page_index": int(page.get("page_index", page.get("page", 0)) or 0), "rect": rounded})
    payload = {
        "cache_version": CACHE_VERSION,
        "pdf_sha256": pdf_sha256,
        "board": str(segment.get("board") or "").upper(),
        "pages": pages,
        "scale": None if scale is None else round(float(scale), 6),
        "target_width": int(target_width),
        "encoder": encoder,
    }
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


class RenderCache:
    """One document's crop cache: lookup by key, record after a real render, persisted as JSON."""

    def __init__(self, path: str | Path, *, pdf_sha256: str, encoder: str) -> None:
        self.path = Path(path)
        self.dir = self.path.parent
        self.pdf_sha256 = pdf_sha256
        self.encoder = encoder
        self.entries: Dict[str, List[Dict[str, Any]]] = {}
        self.hits = 0
        self.misses = 0
        self.reused: List[str] = []

    @classmethod
    def load(cls, path: str | Path, *, pdf_sha256: str, encoder: str) -> "RenderCache":
        """Read a cache file; a version, PDF or encoder mismatch starts an empty cache."""

        cache = cls(path, pdf_sha256=pdf_sha256, encoder=encoder)
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cache
        if (payload.get("cache_version") != CACHE_VERSION
                or payload.get("pdf_sha256") != pdf_sha256
                or payload.get("encoder") != encoder):
            return cache
        entries = payload.get("entries")
        if isinstance(entries, dict):
            cache.entries = {str(k): v for k, v in entries.items() if isinstance(v, list)}
        return cache

    def get(self, key: str) -> List[Dict[str, Any]] | None:
        """The recorded crops for ``key`` -- only when every recorded file still exists."""

        records = self.entries.get(key)
        if not records:
            self.misses += 1
            return None
        for record in records:
            if not (self.dir / str(record.get("file", ""))).is_file():
                self.misses += 1
                return None
        self.hits += 1
        self.reused.extend(str(record.get("file")) for record in records)
        return [dict(record) for record in records]

    def put(self, key: str, records: Sequence[Mapping[str, Any]]) -> None:
        self.entries[key] = [dict(record) for record in records]

    def save(self) -> Path:
        """Write the cache atomically; nothing is written when no lookup was ever asked for."""

        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"cache_version": CACHE_VERSION, "pdf_sha256": self.pdf_sha256,
                   "encoder": self.encoder, "entries": self.entries}
        tmp = self.path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)
        return self.path
