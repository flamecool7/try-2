"""Assemble universal-batch board outputs into per-question packs.

The universal batch renderer writes verified artifacts by document type
(QP/MS/ER/IN). This module creates a user-facing question pack without changing
crop engines: one folder per question, canonical companion names, metadata,
review-required folders for missing companions/topic uncertainty, and a topic
index.
"""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _question_from_name(path: Path) -> int | None:
    m = re.search(r"_Q(\d+)(?:_|\.|$)", path.name)
    return int(m.group(1)) if m else None


def _copy_or_manifest(src: Path, dst: Path, copy_files: bool = True) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if copy_files:
        shutil.copy2(src, dst)
        return str(dst)
    return str(src)


def _qp_dirs(session_dir: Path) -> List[Path]:
    qp_root = session_dir / "QP"
    if not qp_root.is_dir():
        return []
    return sorted([p for p in qp_root.iterdir() if p.is_dir()])


def _first_qp_dir(session_dir: Path) -> Optional[Path]:
    dirs = _qp_dirs(session_dir)
    return dirs[0] if dirs else None


def _collect_companions(session_dir: Path) -> Dict[int, Dict[str, List[Path]]]:
    """question number -> {qp/ms/er/in: [files]} for one session.

    `er` gathers the report's per-question visual crop (`Q3_ER.webp`) and only that: the examiner
    report ships as its crop, with no `_ER.txt` sidecar (2026-09-29, user rule -- the extracted text
    stays in the ER pass's own `er_notes.json`). `in` gathers the insert/source crops a question's
    own text asked for (`Q3_IN.webp`). Both are produced per question by
    `tools/run_universal_batch.py`; a question without one simply has none, and the pack says so
    instead of shipping the whole booklet.
    """
    out: Dict[int, Dict[str, List[Path]]] = {}
    patterns = {
        "qp": session_dir / "QP",
        "ms": session_dir / "MS",
        # "er" is deliberately absent: the report's crops reach this function through the
        # Q{n}_ER.webp attachments below, and nothing collects its text files any more (CLS-178d).
    }
    for kind, root in patterns.items():
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if kind == "qp" and path.suffix.lower() != ".webp":
                # the per-question insert and ER crops live beside the QP crops, not under QP/
                continue
            if kind == "ms" and not path.name.endswith("_MS.webp"):
                continue
            qn = _question_from_name(path)
            if qn is None:
                continue
            out.setdefault(qn, {}).setdefault(kind, []).append(path)
    # per-question crops attached next to the paper itself: Q3_IN.webp / Q3_ER.webp (+ _partN tiles)
    for kind, suffix in (("in", "_IN"), ("er", "_ER")):
        for path in session_dir.rglob(f"Q*{suffix}*.webp"):
            if not path.is_file() or path.parent.name in {"SECTIONS", "_insert"}:
                continue
            # never collect the assembler's OWN output: PACKS/Q3/Q3_ER.webp is a copy of the file
            # this loop is looking for, and re-assembling a session (which the batch does whenever a
            # folder is re-run) crashed on copying a file onto itself until this guard existed.
            if {"PACKS", "review_required"} & set(path.parts):
                continue
            # these are named by the ATTACHMENT pass as Q3_IN.webp / Q3_ER_part2.webp -- no leading
            # underscore, which is why _question_from_name (written for the renderer's names) cannot
            # be reused here and the number is read from the front of the name instead.
            m = re.match(r"^Q(\d+)", path.name)
            if not m:
                continue
            qn = int(m.group(1))
            bucket = out.setdefault(qn, {}).setdefault(kind, [])
            if path not in bucket:
                bucket.append(path)
    # An MCQ's mark scheme is its `_MS.txt` sidecar (2026-09-29, user rule). No batch path writes one
    # yet -- it arrives when an MCQ tree is packed -- but where it exists it is collected here so it
    # can be copied into the pack as an artifact instead of being ignored. The locked base naming
    # (`{component}_{season}_{year}_Q{n}_MS.txt`) is matched first; a short `Q{n}_MS.txt` beside the
    # crops is accepted too, the same two shapes the IN/ER attachments arrive in.
    for root in (session_dir / "QP", session_dir / "MS"):
        if not root.is_dir():
            continue
        for path in root.rglob("*_MS.txt"):
            if not path.is_file() or {"PACKS", "review_required"} & set(path.parts):
                continue
            qn = _question_from_name(path)
            if qn is None:
                m = re.match(r"^Q(\d+)", path.name)
                qn = int(m.group(1)) if m else None
            if qn is None:
                continue
            bucket = out.setdefault(qn, {}).setdefault("ms_txt", [])
            if path not in bucket:
                bucket.append(path)
    return out


def _er_claimed_questions(er_root: Path, er_supplied: bool) -> set:
    """Which questions the supplied examiner report actually discusses.

    Read from the two manifests the ER pass writes (`er_notes.json` = the text notes it could
    extract, `er_sections.json` = the visual sections it could cut). Either one is enough: a report
    that segments but yields no text still claims its questions.

    When the ER was supplied but neither manifest exists (a hand-made or older output tree), fall
    back to "every question is claimed", which is the conservative reading -- better a noisy review
    list than a silently dropped attachment.
    """
    claimed: set = set()
    if not er_supplied:
        return claimed
    saw_manifest = False
    for name in ("er_notes.json", "er_sections.json"):
        for manifest in er_root.rglob(name):
            saw_manifest = True
            data = _read_json(manifest, [])
            rows = data if isinstance(data, list) else (data or {}).get("notes") or []
            for row in rows:
                if not isinstance(row, dict):
                    continue
                qn = row.get("question_number")
                try:
                    claimed.add(int(qn))
                except (TypeError, ValueError):
                    continue
    return claimed if saw_manifest else {qn for qn in range(1, 101)}


def _topic_for_question(qp_dir: Path | None, qn: int) -> Dict[str, Any]:
    if not qp_dir:
        return {"topic": "UNKNOWN", "status": "REVIEW_REQUIRED", "confidence": 0.0, "evidence": []}
    hints = _read_json(qp_dir / "topic_hints.json", [])
    for h in hints:
        if int(h.get("question_number") or -1) == qn:
            return h
    return {"topic": "UNKNOWN", "status": "REVIEW_REQUIRED", "confidence": 0.0, "evidence": []}


def _source_links_for_question(qp_dir: Path | None, qn: int) -> List[dict]:
    if not qp_dir:
        return []
    links = _read_json(qp_dir / "source_links.json", [])
    return [l for l in links if int(l.get("question_number") or -1) == qn]


def source_links_present(qp_dir: Path | None, qn: int) -> bool:
    """True when this question's own text named an insert/source (so a crop is expected)."""
    return bool(_source_links_for_question(qp_dir, qn))


def _slug(value: str) -> str:
    value = value or "UNKNOWN"
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in value)[:100] or "UNKNOWN"


def _session_is_mcq(session_dir: Path) -> bool:
    """True when this session's component is an MCQ paper -- the ONE case a `_MS.txt` may be kept.

    2026-09-29, user rule: "THE MCQ SHOULD ONLY HAVE AN _MS.TXT FILE PERIOD". The component dir is
    ``{syllabus}_{variant}`` (``9701_11``, ``8700_2``, ``8464_P``), so the first underscore separates
    the two halves. core.mcq_registry.is_mcq is the single MCQ authority in the tree (RULE 1) and
    decides by PAPER NUMBER, so a variant digit Cambridge adds later still resolves. Anything
    unparseable is NOT an MCQ -- the conservative direction, because the other mistake would be
    keeping a text file inside a structured question's folder, which is forbidden outright.
    """
    code, _, variant = session_dir.parent.name.partition("_")
    if not code or not variant:
        return False
    try:
        from core.mcq_registry import is_mcq
    except Exception:
        return False
    # The session folder name carries the exam year ("2015", "s15", ...);
    # components that became MCQ later are structured before that year.
    import re as _re
    m = _re.search(r"(20\d{2})|(?<![0-9A-Za-z])[smwSMW](\d{2})(?![0-9])", session_dir.name)
    year = (m.group(1) or m.group(2)) if m else None
    try:
        return bool(is_mcq(code, variant, year))
    except Exception:
        return False


def assemble_session_packs(session_dir: str | Path, *, copy_files: bool = True) -> dict:
    session_dir = Path(session_dir)
    qp_dir = _first_qp_dir(session_dir)
    qp_documents = _qp_dirs(session_dir)
    if len(qp_documents) > 1:
        # Fail closed instead of cross-labelling. One session dir is one paper: every identity
        # parsed out of an AQA combined-science filename collapses to a single component
        # (AQA-8464P1H/P2H both resolve to "8464/P"), so the two QPs share a session dir and a
        # question number. Assembling from the first QP document would file 8464/P2H's Q1-Q6
        # under 8464/P1H's topics and leave everything past Q6 (measured: P2H Q7) as
        # TOPIC_UNKNOWN -- silently wrong packs. The universal batch is run one paper per input
        # dir for exactly this reason; anything else must be reported, not guessed.
        summary = {
            "pack_assembler_version": 1,
            "session_dir": str(session_dir),
            "packs": 0,
            "review_items": [{
                "reason": "MULTIPLE_QP_DOCUMENTS_IN_SESSION",
                "documents": [d.name for d in qp_documents],
                "detail": "one session dir must hold one question paper; run each paper separately",
            }],
            "topics": {},
        }
        _write_json(session_dir / "pack_index.json", summary)
        return summary

    companions = _collect_companions(session_dir)
    # An ER document for this paper is what makes a missing ER crop worth reporting; a run with no
    # examiner report at all must not fill the review list with "MISSING_ER_CROP" for every question.
    er_root = session_dir / "ER"
    # "supplied" = the ER pass wrote anything for this paper. Its manifests (`er_notes.json`,
    # `er_sections.json`) count, not just the .txt/.webp it produced: a report whose text and crops
    # both fail to materialise is exactly the run that has to be reported.
    er_supplied = er_root.is_dir() and any(p.is_file() for p in er_root.rglob("*"))
    er_claimed = _er_claimed_questions(er_root, er_supplied)
    packs_root = session_dir / "PACKS"
    review_root = session_dir / "review_required"
    topic_index: Dict[str, List[str]] = {}
    packs = []
    review_items = []
    strays_removed: List[str] = []
    # The one file class that may legally sit in a question folder as text (see `allowed` below).
    session_is_mcq = _session_is_mcq(session_dir)

    for qn in sorted(companions):
        comp = companions[qn]
        topic = _topic_for_question(qp_dir, qn)
        topic_name = topic.get("topic") or "UNKNOWN"
        topic_status = topic.get("status") or "REVIEW_REQUIRED"
        if topic_status == "HINT" and topic_name != "UNKNOWN":
            pack_dir = packs_root / _slug(topic_name) / f"Q{qn}"
        else:
            pack_dir = review_root / "TOPIC_UNKNOWN" / f"Q{qn}"
            review_items.append({"question_number": qn, "reason": "TOPIC_UNKNOWN", "topic": topic})
        pack_dir.mkdir(parents=True, exist_ok=True)

        artifacts: Dict[str, List[str]] = {"qp": [], "ms": [], "er": [], "in": []}
        if not comp.get("qp"):
            review_items.append({"question_number": qn, "reason": "MISSING_QP"})
        for src in sorted(comp.get("qp", [])):
            artifacts["qp"].append(_copy_or_manifest(src, pack_dir / f"Q{qn}.webp", copy_files))
        # For an MCQ component the sidecar IS the mark scheme, so its presence satisfies
        # MS. A structured session never gets here with one: the closed inventory sweeps it.
        ms_txts = sorted(comp.get("ms_txt", [])) if session_is_mcq else []
        if not comp.get("ms") and not ms_txts:
            review_items.append({"question_number": qn, "reason": "MISSING_MS"})
        for src in sorted(comp.get("ms", [])):
            artifacts["ms"].append(_copy_or_manifest(src, pack_dir / f"Q{qn}_MS.webp", copy_files))
        for src in ms_txts:
            artifacts["ms"].append(_copy_or_manifest(src, pack_dir / f"Q{qn}_MS.txt", copy_files))
        # 2026-09-29 (CLS-178d): the crop only. A legacy `_ER.txt` left on disk by an older run
        # is ignored rather than copied into a pack that the user has said must not carry one.
        er_crops = [p for p in sorted(comp.get("er", [])) if p.suffix.lower() == ".webp"]
        for idx, src in enumerate(er_crops, start=1):
            # the report section for THIS question, tiled as ..._ER.webp, _ER_part2.webp, ...
            tile = f"Q{qn}_ER.webp" if idx == 1 else f"Q{qn}_ER_part{idx}.webp"
            artifacts["er"].append(_copy_or_manifest(src, pack_dir / tile, copy_files))
        # `MISSING_ER_CROP` means "the report talks about this question and produced no section for
        # it", NOT "this paper came with a report". A 10-question paper whose report discusses 2 of
        # them is a normal paper, and flagging the other 8 made the review list useless (2026-09-28).
        if qn in er_claimed and not er_crops:
            review_items.append({"question_number": qn,
                                 "reason": "MISSING_ER_CROP"})
        inserts = sorted(comp.get("in", []))
        for idx, src in enumerate(inserts, start=1):
            tile = f"Q{qn}_IN.webp" if idx == 1 else f"Q{qn}_IN_part{idx}.webp"
            artifacts["in"].append(_copy_or_manifest(src, pack_dir / tile, copy_files))
        if source_links_present(qp_dir, qn) and not inserts:
            review_items.append({"question_number": qn, "reason": "MISSING_INSERT_CROP"})

        # 2026-09-29 (CLS-178f): the pack used to carry a second copy of this list as
        # source_links.json. The same list is already in metadata.json below, and nothing read it
        # from the pack -- the attachment pass reads the session's copy. A question folder now holds
        # its artifacts and metadata.json, nothing else.
        source_links = _source_links_for_question(qp_dir, qn)
        metadata = {
            "pack_version": 1,
            "question_number": qn,
            "canonical_question": f"Q{qn}",
            "topic": topic,
            "artifacts": artifacts,
            "source_links": source_links,
            "review_required": [r for r in review_items if r.get("question_number") == qn],
        }
        _write_json(pack_dir / "metadata.json", metadata)
        # 2026-09-29 (CLS-178f, user rule): "if a question has a qp, ms, in and er the ONLY files in
        # there should be those files". The inventory is therefore closed: the artifacts this
        # question actually earned, plus metadata.json. Anything else -- an older version's text
        # sidecar, a stray note, a second copy of the links -- goes when the pack is (re)built.
        # ONE exception, and it is MCQ-ONLY (2026-09-29, user rule: "THE MCQ SHOULD ONLY HAVE AN
        # _MS.TXT FILE PERIOD"): an MCQ component's mark scheme IS its `_MS.txt` sidecar, so for
        # an MCQ session that file is an artifact and is never swept. For every other question it
        # is a stray and goes. core/bundle_worker draws the same line for CAIE staging folders.
        allowed = {f"Q{qn}.webp", f"Q{qn}_MS.webp", f"Q{qn}_IN.webp", f"Q{qn}_ER.webp",
                   "metadata.json"}
        if session_is_mcq:
            allowed.add(f"Q{qn}_MS.txt")
        part_re = re.compile(rf"^Q{qn}_(?:IN|ER)_part\d+\.webp$")
        for item in sorted(pack_dir.iterdir()):
            if not item.is_file() or item.name in allowed or part_re.match(item.name):
                continue
            try:
                item.unlink()
                strays_removed.append(item.name)
            except OSError:
                pass
        topic_index.setdefault(topic_name, []).append(str(pack_dir.relative_to(session_dir)))
        packs.append(metadata | {"pack_dir": str(pack_dir)})

    summary = {
        "pack_assembler_version": 1,
        "session_dir": str(session_dir),
        "packs": len(packs),
        "review_items": review_items,
        "topics": topic_index,
        "strays_removed": sorted(strays_removed),
    }
    _write_json(session_dir / "pack_index.json", summary)
    return summary


def assemble_all_packs(output_dir: str | Path, *, copy_files: bool = True) -> dict:
    output_dir = Path(output_dir)
    final_root = output_dir / "final"
    summaries = []
    if not final_root.is_dir():
        return {"sessions": 0, "packs": 0, "review_items": [], "strays_removed": []}
    for session_dir in sorted(final_root.glob("*/*/*")):
        if not session_dir.is_dir():
            continue
        if not (session_dir / "QP").exists() and not (session_dir / "MS").exists():
            continue
        summaries.append(assemble_session_packs(session_dir, copy_files=copy_files))
    merged = {
        "sessions": len(summaries),
        "packs": sum(s.get("packs", 0) for s in summaries),
        "review_items": [item for s in summaries for item in s.get("review_items", [])],
        # Flattened so a caller holding only the merged summary can report what the (re)build
        # swept out of the packs. Kept as a LIST, not a set: two questions sweeping a file of
        # the same name are two files removed, and this list is what the audit counts.
        "strays_removed": sorted(name for s in summaries for name in s.get("strays_removed", [])),
        "session_summaries": summaries,
    }
    _write_json(output_dir / "question_pack_manifest.json", merged)
    return merged
