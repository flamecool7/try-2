"""College Board SAT/PSAT adapter.

The important SAT-specific rule is module awareness: question numbers restart
per module, so the segment id includes section + module + local question number.
Counts are read from each module heading (e.g. ``33 QUESTIONS``), never from the
CAIE ``MCQ_EXPECTED_COUNT`` constant.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from adapters.base import BoardAdapter, DocumentContext, Evidence
from adapters.common_text import line_ys, page_size, page_texts

_MODULE_HEAD = re.compile(r"Module\s*\n?\s*(\d+)\s*\n?\s*(Reading and Writing|Math)", re.I)
_QCOUNT = re.compile(r"(\d{1,3})\s+QUESTIONS", re.I)
_Q_LINE = re.compile(r"^\s*(\d{1,2})\s*$")


_DOT_RULE = re.compile(r"^[.\u2026\s]+$")


def _page_lines(ctx, page_index):
    """Layout lines of a page as ``(text, (x0, y0, x1, y1))``, content only."""
    from adapters.common_text import pages_from_layout

    pages = pages_from_layout(ctx)
    if not (0 <= page_index < len(pages)):
        return []
    lines = []
    for line in pages[page_index].get("lines") or []:
        txt = str(line.get("text", "")).strip()
        bbox = line.get("bbox") or []
        if txt and len(bbox) == 4:
            lines.append((txt, tuple(map(float, bbox))))
    return lines


_RULE_TEXT = re.compile(r"^[\s.\u2026\-\u2013\u2014~_|]+$")   # dotted/dashed rules printed as text

_COL0_X1, _COL1_X0 = 307.0, 311.0               # the two column boxes' inner edges
_COL_PAD = 34.0                                 # page-edge padding of both boxes


def _crosses_column_gap(txt, bbox) -> bool:
    """True when a real text line runs from one column into the other."""
    x0, _y0, x1, _y1 = bbox
    return not _RULE_TEXT.match(txt) and x0 < _COL0_X1 and x1 > _COL1_X0


def _page_is_full_width(lines, top, bottom, min_lines=3) -> bool:
    """True when THIS question's band is laid out across both columns.

    psat-nmsqt-practice-test-2 page 22 carries a single question whose figure
    caption, data table and passage all run past x 307 (text spans reach 351.0),
    so a single-column crop cut them mid-line - the same "content cut off" class
    as the phantom-marker defect fixed on 2026-09-21 with a solid-object
    crossing audit. Furniture never triggers this: the module heading sits at
    y 116-141 and the STOP banner at y 636+, both outside every question band,
    and rule-only text is ignored.
    """
    seen = 0
    for txt, (x0, y0, x1, y1) in lines:
        if y0 < top or y1 > bottom:
            continue
        if _crosses_column_gap(txt, (x0, y0, x1, y1)):
            seen += 1
            if seen >= min_lines:
                return True
    return False


_MODULE_END_BANNER = (
    re.compile(r"^if you finish before time is called", re.I),
    re.compile(r"^do not turn to any other module", re.I),
    re.compile(r"^stop$", re.I),
)


def _module_end_banner_top(lines):
    """Top y of the full-width "STOP / module ends here" banner, or None.

    The last page of every PSAT module prints that banner across BOTH columns
    (page 15: "STOP" at 636.6, the instruction lines to 704.9). A single-column
    question crop necessarily sliced it in half (measured 2026-09-21: 8 of 120
    crops had banner ink on a border), so the crop now stops above the banner
    instead of including a fragment of it. Banner detection is content-keyed,
    never positional.
    """
    tops = []
    for txt, (x0, y0, x1, y1) in lines:
        if any(pat.match(txt) for pat in _MODULE_END_BANNER):
            tops.append(y0)
    return min(tops) if tops else None


def _has_ink_to_the_left(lines, x0, y0, y1, col, column_windows=((34.0, 307.0), (311.0, 582.0))):
    """True when this number cannot be a question marker because it is content.

    On the PSAT maths pages a table of values prints its cells as standalone
    numbers: the value ``11`` of a cell sits at x=115.7, inside the column-0
    marker window, so it was taken for *question 11* and the crop bottom of Q10
    was drawn straight through that table (caught 2026-09-21 by re-cropping the
    real paper and measuring ink in the bottom rows of every payload). A question
    marker is the leftmost object of its own column - anything ending to its left
    in the same row, inside the same column, makes it content. Answer-choice
    labels (``B)``), axis/section signs and the dotted column rule are excluded
    by the same test or explicitly here.
    """
    height = max(1.0, y1 - y0)
    lo, hi = y0 + 0.25 * height, y0 + 0.75 * height
    col_lo, col_hi = column_windows[col]
    for txt, (bx0, by0, bx1, by1) in lines:
        if bx0 < col_lo or bx0 > col_hi:
            continue
        if _DOT_RULE.match(txt or ""):
            continue
        if bx1 <= x0 - 1.0 and by0 < hi and by1 > lo:
            return True
    return False


class Adapter(BoardAdapter):
    BOARD_ID = "SAT"
    BOARD_NAMES = ["College Board", "SAT", "PSAT"]
    CONFIG_FILE = "config/boards/sat.yaml"
    HAS_EXAMINER_REPORTS = False
    HAS_INSERTS = False

    def normalize_name(self, raw: str) -> str:
        return re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")

    def _hay(self, ctx: DocumentContext) -> str:
        return f"{ctx.filename}\n{ctx.first_page_text}\n{ctx.full_text}".lower()

    def identify_document(self, ctx: DocumentContext) -> List[Evidence]:
        hay = self._hay(ctx)
        out: List[Evidence] = []
        for token in ("college board", "psat", "sat suite", "practice test"):
            if token in hay:
                out.append(Evidence("board_signature", "board", self.BOARD_ID, 0.9, f"SAT/College Board token {token!r}", "document"))
                break
        return out

    def identify_subject(self, ctx: DocumentContext) -> List[Evidence]:
        low = self._hay(ctx)
        if "psat" in low:
            program = "PSAT_8_9" if "8/9" in low or "8-9" in low else "PSAT_NMSQT"
            return [Evidence("first_page_text", "program", program, 0.9, "program named in cover/filename", "document")]
        if "sat" in low:
            return [Evidence("first_page_text", "program", "SAT", 0.8, "SAT named in cover/filename", "document")]
        return []

    def identify_qualification(self, ctx: DocumentContext) -> List[Evidence]:
        return [Evidence("first_page_text", "qualification", "DIGITAL_SUITE", 0.8, "paper version of digital SAT suite practice material", "document")]

    def identify_session(self, ctx: DocumentContext) -> List[Evidence]:
        """Practice tests carry no administration session - and no date.

        Three decisions, all made 2026-09-21 (the same defect class as IB's, found
        there first):

        * the evidence FIELD is ``season``, which is what every consumer asks for
          (``adapters.associations._ask("identify_session", "season")``). Emitting
          ``"session"`` made this evidence invisible, so SAT documents carried an
          empty evidence list and could not say why their season was unknown.
        * the VALUE is ``Practice`` - the cover's own label for the document, in the
          same spirit as IB's ``SPECIMEN``. It is not a fabricated season: SAT
          practice tests genuinely have no session, and "Practice" is what the
          document calls itself.
        * the YEAR is deliberately still absent. A practice test is undated, so
          ``year`` stays UNKNOWN rather than being invented.
        """
        return [Evidence("first_page_text", "season", "Practice", 0.8,
                         "official practice-test material (no administration session)",
                         "document")]

    def identify_component(self, ctx: DocumentContext) -> List[Evidence]:
        mods = self._module_ranges(ctx)
        out: List[Evidence] = []
        for m in mods:
            out.append(Evidence("document_structure", "component", f"{m['section']}_M{m['module']}", 0.9, "module heading", f"page {m['start_page']+1}"))
        # Per-module ids above are for segmentation. Association needs a single
        # document-level label, so carry it alongside rather than replacing them.
        out.extend(self.identify_document_component(ctx))
        return out

    def identify_document_type(self, ctx: DocumentContext) -> List[Evidence]:
        low = self._hay(ctx)
        if "answer explanations" in low:
            return [Evidence("header_footer", "document_type", "SOLUTION_EXPLANATION", 0.9, "answer explanations text", "document")]
        # NOTE: the cover sets "Practice" and "Test# 1" on SEPARATE LINES, so a
        # literal "practice test" substring never matched and SAT documents were
        # reported as type UNKNOWN. Match across whitespace instead.
        # "answer explanations" above is the only competing practice-test artefact,
        # and it already returned early - so no extra body-token guard is needed.
        # (The previous guard required "module"/"questions", which live beyond the
        #  cover pages an identity pass reads, so the type came back UNKNOWN.)
        if re.search(r"practice\s+test", low):
            return [Evidence("header_footer", "document_type", "QP", 0.9, "practice-test cover", "document")]
        return []

    #: Document-level component for association. A SAT/PSAT paper spans FOUR
    #: modules (RWM1, RWM2, MATHM1, MATHM2), so per-module ``component`` evidence
    #: is the wrong granularity for grouping a paper with its mark scheme or for
    #: telling two different practice tests apart. Calibrated on the real covers:
    #:   "PSAT 8/9  Practice Test# 1"   -> PSAT_8_9_T1
    #:   "PSAT/NMSQT ... Practice Test# 2" -> PSAT_NMSQT_T2
    _PRACTICE_TEST_NO = re.compile(r"practice\s*\n?\s*test\s*#?\s*(\d{1,2})", re.I)

    def identify_document_component(self, ctx: DocumentContext) -> List[Evidence]:
        """One stable component label for the WHOLE document (association use)."""
        hay = self._hay(ctx)
        subject = self.identify_subject(ctx)
        program = ""
        for ev in subject:
            if getattr(ev, "field", None) == "program":
                program = str(ev.value)
                break
        if not program:
            return []
        m = self._PRACTICE_TEST_NO.search(hay)
        test_no = m.group(1) if m else ""
        value = f"{program}_T{test_no}" if test_no else program
        return [Evidence("document_structure", "document_component", value, 0.9,
                         f"{program} practice test {test_no or '?'} on cover", "document")]

    def identify_question_structure(self, ctx: DocumentContext) -> List[Evidence]:
        segs = self.segment(ctx)
        mods = self._module_ranges(ctx)
        out = [Evidence("document_structure", "question_count", len(segs), 0.85, "module-aware SAT segmentation", "document")]
        for m in mods:
            if m.get("declared_count"):
                out.append(Evidence("document_structure", "module_declared_count", m["declared_count"], 0.95, f"{m['section']} module {m['module']} heading declares count", f"page {m['start_page']+1}"))
        return out if segs else []

    def identify_mark_scheme(self, ctx: DocumentContext) -> List[Evidence]:
        return []

    def identify_examiner_report(self, ctx: DocumentContext) -> List[Evidence]:
        return []

    def segments_document(self) -> bool:
        return True

    def _module_ranges(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        texts = page_texts(ctx)
        mods: List[Dict[str, Any]] = []
        for i, text in enumerate(texts):
            m = _MODULE_HEAD.search(text)
            if not m:
                continue
            section = "RW" if "reading" in m.group(2).lower() else "MATH"
            qcnt = _QCOUNT.search(text)
            mods.append({
                "section": section,
                "module": int(m.group(1)),
                "start_page": i,
                "declared_count": int(qcnt.group(1)) if qcnt else None,
            })
        for idx, mod in enumerate(mods):
            mod["end_page"] = (mods[idx + 1]["start_page"] - 1) if idx + 1 < len(mods) else len(texts) - 1
        return mods

    def _question_positions(self, ctx: DocumentContext, page_index: int) -> List[Tuple[int, float, float, int]]:
        # Prefer layout line boxes so pages with multiple questions can be split vertically.
        # Return (question_number, y0, x0, column). SAT practice PDFs are two-column;
        # CAIE's left-margin-only detector is exactly what over-counted/duplicated here.
        out: List[Tuple[int, float, float, int]] = []
        lines = _page_lines(ctx, page_index)
        if lines:
            for txt, (x0, y0, x1, y1) in lines:
                if not re.fullmatch(r"\d{1,2}", txt):
                    continue
                if not (70 <= y0 <= 735):
                    continue
                # A question marker is the number printed inside the column's
                # solid black tab, so its x0 is fixed by the tab geometry: tabs
                # sit at 35.9/53.9 (column 0) and 313.6/331.6 (column 1), putting
                # the real marker text at x0 39.8-61 and 317.5-339 across both
                # practice books (measured 2026-09-21). The old 35-125 / 300-365
                # windows reached into question content, so table cells, answer
                # labels and graph axis numbers became phantom questions - the
                # graph labels of psat-8-9-practice-test-1 page 32 (x0 364.4-372.5)
                # became Q4..Q10 and closed Q3's crop at y 223.7 straight through
                # the plotted figure.
                if 36 <= x0 <= 66:
                    col = 0
                elif 311 <= x0 <= 343:
                    col = 1
                else:
                    continue
                # A marker owns the left edge of its column; numbers printed
                # inside a table or a figure have content to their left.
                if _has_ink_to_the_left(lines, x0, y0, y1, col):
                    continue
                out.append((int(txt), y0, x0, col))
        # De-duplicate same question number on the same page/column.
        dedup: Dict[tuple[int, int], Tuple[int, float, float, int]] = {}
        for item in sorted(out, key=lambda t: (t[3], t[1], t[0])):
            dedup.setdefault((item[0], item[3]), item)
        return sorted(dedup.values(), key=lambda t: (t[0], t[3], t[1]))

    def segment(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        mods = self._module_ranges(ctx)
        segments: List[Dict[str, Any]] = []
        for mod in mods:
            starts: List[Tuple[int, int, float, float, int]] = []
            for p in range(mod["start_page"], mod["end_page"] + 1):
                for qn, y, x, col in self._question_positions(ctx, p):
                    starts.append((qn, p, y, x, col))
            starts.sort(key=lambda t: (t[1], t[4], t[2]))
            # Keep only the current module's declared local question range and
            # enforce SAT module-local monotonic numbering. This removes Math
            # diagram/table labels such as stray 2, 3, 8, 20 without using CAIE
            # margin heuristics or a hardcoded count.
            declared = mod.get("declared_count")
            if declared:
                seq = []
                expected = 1
                for s in starts:
                    if s[0] == expected:
                        seq.append(s)
                        expected += 1
                        if expected > declared:
                            break
                starts = seq
            for idx, (qn, p, y, x, col) in enumerate(starts):
                w, h = page_size(ctx, p)
                next_top = None
                # Next question in the same page AND same column defines the bottom.
                for nxt in starts[idx + 1:]:
                    if nxt[1] == p and nxt[4] == col:
                        next_top = nxt[2]
                        break
                    if nxt[1] != p:
                        break
                # Page-furniture sweep (2026-09-21, 100 dpi ink bands): the last
                # column ink ends at 720.7 (worst page 46) and the footer row
                # ("Unauthorized copying..." / page number / "CONTINUE") occupies
                # 747.4-768.2, so the old h-44.0 = 748.0 shaved the top of that
                # footer on every last-of-module question. h-58.0 = 734.0 sits in
                # the empty window: 13pt below the worst content, 13pt above the
                # footer.
                bottom = (next_top - 8.0) if next_top else (h - 58.0)
                banner_top = _module_end_banner_top(_page_lines(ctx, p))
                if banner_top is not None:
                    # Never carry a fragment of the module-end banner into the
                    # crop; the last question's own ink ends >= 23pt above it.
                    bottom = min(bottom, banner_top - 8.0)
                top = max(54.0, y - 10.0)
                lines_of_page = _page_lines(ctx, p)
                if _page_is_full_width(lines_of_page, top, max(top + 20.0, bottom)):
                    # Wide layout: keep the whole printed width instead of one column.
                    x0, x1 = _COL_PAD, w - _COL_PAD
                elif col == 0:
                    # Column boxes must contain the whole printed column, tab
                    # included: the question-number tab (a solid black 17.9pt box)
                    # starts at x 35.9 in column 0 and at 313.6 in column 1, both
                    # of which the old 38.0/316.0 edges sliced by ~2.4pt, leaving
                    # the tab flush on the crop border. The right edge cleared only
                    # 574.0 while the column rule reaches 574.58 (page 37), so it
                    # sliced that rule too. Edges now sit 2-4pt into white space
                    # (no text lives left of 38.5 in column 0 or between 311 and
                    # 317.5 in column 1, and nothing but the footer lives right of
                    # 578.0), measured 2026-09-21.
                    x0, x1 = 34.0, min(307.0, w - 37.0)
                else:
                    x0, x1 = 311.0, w - 30.0
                rect = (x0, top, x1, max(top + 20.0, bottom))
                seg_id = f"PSAT_{mod['section']}M{mod['module']}_Practice_Q{qn}"
                segments.append({
                    "id": seg_id,
                    "question_number": qn,
                    "section": mod["section"],
                    "module": mod["module"],
                    "pages": [{"page_index": p, "rect": rect}],
                    "metadata": {"source_page": p + 1, "declared_module_count": declared, "module_aware": True},
                })
        return segments
