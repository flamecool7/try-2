"""College Board SAT Suite adapter."""
