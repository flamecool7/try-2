#!/usr/bin/env python3
"""Render ONE question of a question paper as a production pack, in its own process.

``tools/run_universal_batch.py`` renders a whole paper in one process. That is the normal path and
it is what every round has used -- but a 2 GB container cannot hold every tile of a paper whose last
question is a 25-mark essay with four ~100 MB tiles plus the tiles of the questions before it
(measured: AQA-74023-QP-JUN23, Q7, four tiles of 2280 x ~15,500 px). This entry point renders a named
question through exactly the same production helpers the batch uses --

    adapters.registry.get_adapter -> adapter.segment -> adapters.segment_geometry.render_segment_tiles
    -> save_rendered_segments -> validate_segments + validate_rendered_webps

-- and writes into the same ``final/<board>/<component>/<session>/<QP|MS>/<stem>/`` layout, merging
its segment, measurement and contract records into the files the batch already wrote for that paper.
Identity comes from the same ``adapters.associations`` reader the batch uses, so the pack's canonical
file id matches the one the batch would have given it.

Usage:

    python3 tools/render_question_pack.py --pdf papers/.../AQA-74023-QP-JUN23.PDF --question 7 \
        --output /tmp/out/p3 [--kind QP] [--note "why this ran alone"]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapters.associations import identify_document
from adapters.output_contracts import validate_rendered_webps, validate_segments
from adapters.registry import get_adapter
from adapters.segment_geometry import measure_top_band, release_memory, render_segment_tiles, save_rendered_segments
from PIL import Image
from tools.crop_noncaie_segments import build_context
from tools.run_universal_batch import (_canonical_file_id, _component_dir_name, _safe_name,
                                       _session_dir_name, _write_json)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--question", type=int, required=True)
    ap.add_argument("--output", required=True, help="the batch's --output directory")
    ap.add_argument("--kind", default="QP", choices=["QP", "MS"])
    ap.add_argument("--note", default="", help="recorded in the paper's audit")
    a = ap.parse_args()

    pdf = Path(a.pdf)
    out_dir = Path(a.output)
    ident = identify_document(str(pdf))
    ctx = build_context(pdf)
    adapter = get_adapter(ident.board)
    segments = adapter.segment_mark_scheme(ctx) if a.kind == "MS" else adapter.segment(ctx)
    wanted = [s for s in segments if int(s.get("question_number") or 0) == a.question]
    if len(wanted) != 1:
        print(f"refusing: {len(wanted)} segments numbered Q{a.question} in {pdf.name}")
        return 1
    seg = dict(wanted[0])
    # the same canonical name the batch's own render path would give it: the mark-scheme
    # crop carries the ``_MS`` suffix, which is also how ``pack_assembler`` pairs a
    # question's mark scheme with its question paper
    seg["id"] = _canonical_file_id(ident, a.question, "_MS" if a.kind == "MS" else "")
    paper_dir = (out_dir / "final" / ident.board / _component_dir_name(ident.component)
                 / _session_dir_name(ident.season, ident.year) / a.kind / _safe_name(pdf))
    paper_dir.mkdir(parents=True, exist_ok=True)

    rendered = render_segment_tiles(pdf, seg)
    written = save_rendered_segments(rendered, paper_dir)
    measurements = []
    for path in written:
        with Image.open(path) as img:
            measurements.append({"file": path.name, "width": img.width, "height": img.height,
                                 "top_band": measure_top_band(img)})
    del rendered
    release_memory()

    seg_path = paper_dir / "segments.json"
    old = json.loads(seg_path.read_text(encoding="utf-8")) if seg_path.exists() else []
    merged = [s for s in old if int(s.get("question_number") or 0) != a.question] + [seg]
    merged.sort(key=lambda s: int(s.get("question_number") or 0))
    _write_json(seg_path, merged)

    meas_path = paper_dir / "measurements.json"
    old_meas = json.loads(meas_path.read_text(encoding="utf-8")) if meas_path.exists() else []
    old_meas = [m for m in old_meas if m["file"] not in {n["file"] for n in measurements}]
    _write_json(meas_path, sorted(old_meas + measurements, key=lambda m: m["file"]))

    if ident.board == "AQA":
        from adapters.aqa.classification import classify_segments as _aqa_classify
        hints = _aqa_classify(ctx, [seg], str(getattr(ident, "component", "") or ""),
                              year=str(getattr(ident, "year", "") or ""),
                              season=str(getattr(ident, "season", "") or ""))
    else:
        from adapters.nonib_topics import classify_segments as _classify
        hints = _classify(ident.board, ctx, [seg], component=getattr(ident, "component", None))
    hint_path = paper_dir / "topic_hints.json"
    old_hints = json.loads(hint_path.read_text(encoding="utf-8")) if hint_path.exists() else []
    merged_hints = [h for h in old_hints
                    if int(h.get("question_number") or 0) != a.question] + hints
    merged_hints.sort(key=lambda h: int(h.get("question_number") or 0))
    _write_json(hint_path, merged_hints)

    issues = validate_segments(ident.board, [seg]) + validate_rendered_webps(written)
    status = "PASS" if not any(i.level == "ERROR" for i in issues) else "FAIL"
    report_path = paper_dir / "contract_report.json"
    old_report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
    _write_json(report_path, {"contract_version": 1, "board": ident.board, "status": status,
                              "issues": [i.__dict__ if hasattr(i, "__dict__") else str(i) for i in issues],
                              "rendered_alone": {"question": a.question, "note": a.note,
                                                 "previous_status": old_report.get("status")}})
    print(json.dumps({"status": status, "component": ident.component, "board": ident.board,
                      "question": a.question, "tiles": len(written),
                      "topic": [h.get("topic") for h in hints],
                      "engine": [h.get("engine") for h in hints],
                      "sizes": [(m["width"], m["height"], m["top_band"]) for m in measurements],
                      "output_dir": str(paper_dir)}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
