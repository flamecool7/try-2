#!/usr/bin/env python3
"""Build a provenance manifest for official/public non-CAIE proof PDFs.

The manifest is derived from files that were actually downloaded into the
workspace; URLs are recorded only when supplied by the caller or by the embedded
known official proof map below.  Missing URLs are kept as UNKNOWN rather than
invented.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Dict

KNOWN_OFFICIAL_URLS: Dict[str, str] = {
    "AQA-84621H-QP-JUN23.PDF": "https://filestore.aqa.org.uk/sample-papers-and-mark-schemes/2023/june/AQA-84621H-QP-JUN23.PDF",
    "AQA-84621H-MS-JUN23.PDF": "https://filestore.aqa.org.uk/sample-papers-and-mark-schemes/2023/june/AQA-84621H-MS-JUN23.PDF",
    "AQA-84621H-ER-JUN23.PDF": "https://filestore.aqa.org.uk/sample-papers-and-mark-schemes/2023/june/AQA-84621H-WRE-JUN23.PDF",
    "AQA-84621H-QP-NOV21.PDF": "https://filestore.aqa.org.uk/sample-papers-and-mark-schemes/2021/november/AQA-84621H-QP-NOV21.PDF",
    "9489_s24_qp_11_history.pdf": "https://www.cambridgeinternational.org/Images/673488-june-2024-question-paper-11.pdf",
    "9489_s24_qp_21_history.pdf": "https://www.cambridgeinternational.org/Images/673490-june-2024-question-paper-21.pdf",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def build_manifest(root: Path) -> dict:
    entries = []
    for p in sorted(root.rglob("*.pdf")) + sorted(root.rglob("*.PDF")):
        entries.append({
            "path": str(p),
            "bytes": p.stat().st_size,
            "sha256": sha256(p),
            "source_url": KNOWN_OFFICIAL_URLS.get(p.name, "UNKNOWN"),
            "source_status": "OFFICIAL_PUBLIC" if p.name in KNOWN_OFFICIAL_URLS else "REVIEW_REQUIRED",
        })
    return {
        "manifest_version": 1,
        "root": str(root),
        "entries": entries,
        "counts": {
            "total": len(entries),
            "official_public": sum(1 for e in entries if e["source_status"] == "OFFICIAL_PUBLIC"),
            "review_required": sum(1 for e in entries if e["source_status"] != "OFFICIAL_PUBLIC"),
        },
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root", nargs="?", default="papers/real_noncaie")
    ap.add_argument("--out", default="out_noncaie/source_manifest.json")
    args = ap.parse_args(argv)
    data = build_manifest(Path(args.root))
    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(data["counts"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
