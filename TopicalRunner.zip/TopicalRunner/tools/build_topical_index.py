#!/usr/bin/env python3
"""tools/build_topical_index.py — the app's question index, built from batch output.

    python3 tools/build_topical_index.py --batch-out /tmp/app_batch --out topical_index.json
    python3 tools/build_topical_index.py --batch-out A --batch-out B --out topical_index.json
    python3 tools/build_topical_index.py --set-topic "AQA|8461/1H|June 2023|Q7" Inheritance_variation_and_evolution
    python3 tools/build_topical_index.py --dismiss   "AQA|8462/1H|June 2023|Q9" --reason "composite by design"

Reads **the tree the batch already wrote**, in either of the two shapes this repository produces:

* universal (AQA / Edexcel / IB / SAT) — `final/<board>/<component>/<session>/PACKS/…` and
  `final/<board>/<component>/<session>/review_required/…`
* CAIE — `out/<Level>/<Subject_code>/paper-<N>/<Topic>/<Q-folder>/` with `metadata.json` + the QP and
  MS `.webp` crops beside it (the Cambridge pipeline's own layout, written by `main.py`)

Both layouts produce the *same row schema*, so the app browses one index regardless of board; the
row's `layout` field records which shape it came from and `component` carries the board's own
paper identity (``8461/1H`` / ``9702/22``).
`…/review_required/TOPIC_UNKNOWN/…`) and writes the index the UI lists from. It never re-crops,
re-classifies or re-orders anything: every row is the batch's own output plus, optionally, a user
override.

Rules (fail-closed; see `design/TOPICAL_BOOKLET_DESIGN.md` §1d.3):

* **HINT-only listable** — a row is `listable` only when its topic status is `HINT` with a real topic
  (or a user override says so) *and* a question crop exists. Flagged rows stay in the index for the
  Review screen but are never listable.
* **(board, code) must exist in the catalogue** (`subjects.json`) — otherwise the build exits 2
  **naming the gap** and writes nothing: there is no partially-built index.
* **`--reset`** — index *exactly* the `--batch-out` dirs you name, dropping rows that came from
  other sources. Without it the previous rows are kept (merge), so a caller that wants deterministic
  counts for one fixture asks for a reset instead of hoping the output file was empty.
* **Idempotent merge** — rows are keyed by question id and carry their `batch_out`; re-running with
  the same `--batch-out` set replaces exactly those rows and leaves rows from other batch outputs
  untouched. A row whose pack has disappeared from its source is dropped.
* **Overrides never modify batch output** — `topic_overrides.json` is read here and applied to the
  *index rows*; the batch's `metadata.json` keeps AQA's own verdict (`batch_topic` / `batch_status`
  are preserved in the row).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "topical_index.json"
DEFAULT_OVERRIDES = ROOT / "topic_overrides.json"
CATALOGUE = ROOT / "subjects.json"

PACK_SECTIONS = ("PACKS", "review_required")

#: Stored search text per row. Long enough for a full question, small enough that the
#: index stays a text file the app can read in one go (crops live in the batch output).
TEXT_LIMIT = 4000


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:                                              # noqa: BLE001
        return default


def _sha256_file(path: Path) -> Optional[str]:
    try:
        h = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def _rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except ValueError:
        return str(path)


def question_id(board: str, component: str, session: str, question_number: int) -> str:
    """Stable, human-readable id: ``AQA|8461/1H|June 2023|Q1``."""
    component = component or "UNKNOWN"
    session = session or "UNKNOWN"
    return f"{board}|{component}|{session}|Q{int(question_number)}"


def _catalogue_codes() -> Dict[str, set]:
    """board -> the set of codes the catalogue knows."""
    payload = _read_json(CATALOGUE, {}) or {}
    out: Dict[str, set] = {}
    for row in payload.get("subjects", []):
        code = str(row.get("code") or "").strip()
        if code:
            out.setdefault(str(row["board"]), set()).add(code)
    return out


def _catalogue_rows() -> Dict[Tuple[str, str], dict]:
    payload = _read_json(CATALOGUE, {}) or {}
    return {(str(r["board"]), str(r.get("code") or "")): r for r in payload.get("subjects", [])}


def _session_parts(session_dir: Path) -> Tuple[str, str, str]:
    """('June', '2023', 'June 2023') from the batch's ``June_2023`` session directory."""
    name = session_dir.name
    m = re.match(r"([A-Za-z]+)_(\d{4})$", name)
    if m:
        season, year = m.group(1), m.group(2)
        return season, year, f"{season} {year}"
    return "", "", name.replace("_", " ")


def _measurements(paper_dir: Path) -> Dict[str, dict]:
    rows = _read_json(paper_dir / "measurements.json", []) or []
    out = {}
    for row in rows:
        name = str(row.get("file") or "")
        out[name] = row
        #: the pack copies the crop as ``Q<N>.webp`` while the QP directory names it
        #: ``8461_1H_June_2023_Q<N>.webp`` -- key on the question number so the pixels are found
        m = re.search(r"_Q(\d+)(?:_p\d+of\d+)?\.webp$", name, re.I)
        if m:
            out.setdefault(f"Q{int(m.group(1))}.webp", row)
    return out


def _identity_for(root: Path, board: str, component_dir: str, session_dir: Path) -> Optional[dict]:
    """The batch's own identity + segment rows for a QP document (source pdf and its sha256)."""
    qp_root = session_dir / "QP"
    if not qp_root.is_dir():
        return None
    for paper_dir in sorted(p for p in qp_root.iterdir() if p.is_dir()):
        segments = _read_json(paper_dir / "segments.json", []) or []
        audit = _read_json(root / "universal_batch_audit.json", {}) or {}
        for ident in audit.get("identities", []):
            if Path(str(ident.get("path") or "")).stem != paper_dir.name:
                continue
            return {"paper_dir": paper_dir, "segments": segments, "identity": ident,
                    "measurements": _measurements(paper_dir)}
    return None


def _marks_for(segments: Iterable[dict], question_number: int) -> Optional[int]:
    """Marks when the batch recorded them (segments carry them for some boards) -- else null."""
    for seg in segments:
        if int(seg.get("question_number") or 0) != int(question_number):
            continue
        for key in ("marks", "total_marks"):
            if isinstance(seg.get(key), (int, float)):
                return int(seg[key])
        meta = seg.get("metadata") or {}
        for key in ("marks", "total_marks"):
            if isinstance(meta.get(key), (int, float)):
                return int(meta[key])
    return None


def _pdf_text(path: Path, pages: Optional[Iterable[int]] = None) -> str:
    """Extracted text for a source PDF (all pages, or just the given 1-based page numbers).

    Optional by design: no PyMuPDF, an unreadable or absent PDF, or an encrypted file returns "" --
    text is a convenience for search, never a reason to fail an index build.
    """
    try:
        import fitz                                                 # noqa: PLC0415 (optional)
    except Exception:                                               # noqa: BLE001
        return ""
    try:
        doc = fitz.open(path)
    except Exception:                                               # noqa: BLE001
        return ""
    try:
        wanted = [int(p) for p in pages] if pages else list(range(1, doc.page_count + 1))
        parts = []
        for number in wanted:
            if 1 <= number <= doc.page_count:
                parts.append(doc[number - 1].get_text("text"))
        return "\n".join(parts)
    except Exception:                                               # noqa: BLE001
        return ""
    finally:
        doc.close()


_OCR_UNAVAILABLE_NOTE = ("OCR requested but unavailable: the 'tesseract' binary and pytesseract "
                         "are both needed. Rows keep whatever their PDF text layer holds.")


def ocr_available() -> bool:
    try:
        import pytesseract                                          # noqa: PLC0415 (optional)
        pytesseract.get_tesseract_version()
        return True
    except Exception:                                               # noqa: BLE001
        return False


def ocr_image(path: Path, lang: str = "eng") -> str:
    """OCR one crop. Returns "" (never raises) when the runtime is absent or the image unreadable."""
    try:
        import pytesseract                                          # noqa: PLC0415
        from PIL import Image                                       # noqa: PLC0415
    except Exception:                                               # noqa: BLE001
        return ""
    try:
        with Image.open(path) as img:
            return pytesseract.image_to_string(img, lang=lang) or ""
    except Exception:                                               # noqa: BLE001
        return ""


_MARKS_IN_TEXT = re.compile(r"\[(\d{1,2})\]")
_MARKS_PROSE = re.compile(r"\((\d{1,2})\s*marks?\)", re.I)


def marks_from_text(text: str) -> Optional[int]:
    """Total marks a question states about itself -- Cambridge's ``[3]``, or ``(3 marks)``.

    The last bracket wins: a question that lists sub-parts ("(i) … [1]", "(ii) … [2]") totals the
    final marker, which is what the paper prints as the question total.
    """
    if not text:
        return None
    found = _MARKS_IN_TEXT.findall(text) or _MARKS_PROSE.findall(text)
    if not found:
        return None
    try:
        return int(found[-1])
    except (TypeError, ValueError):
        return None


_QUESTION_MARKER = re.compile(r"(?m)^\s*(\d{1,2})\s*(?=\S)")


def split_question_spans(text: str) -> Dict[int, str]:
    """``{question number: its text}`` for a CAIE question paper, from the paper's own numbering.

    Cambridge papers number questions ``1``, ``2`` … at the start of a line (sub-parts use ``(a)``,
    ``(i)``, so they never collide). This is a *heuristic* span, used only when the pipeline recorded
    no page map — callers label it as such rather than passing it off as exact.
    """
    if not text:
        return {}
    hits = [(int(m.group(1)), m.start()) for m in _QUESTION_MARKER.finditer(text)]
    if not hits:
        return {}
    spans: Dict[int, str] = {}
    for index, (number, start) in enumerate(hits):
        end = hits[index + 1][1] if index + 1 < len(hits) else len(text)
        body = text[start:end].strip()
        # a "1" that begins a mark-scheme-style list is short and number-like; question text is not
        if len(body) >= 24:
            spans.setdefault(number, body)
    return spans


def _caie_question_dirs(root: Path) -> List[Tuple[Path, Tuple[str, ...]]]:
    """(metadata.json, its path parts) for the CAIE layout: Level/Subject_code/paper-N/Topic/Q-folder.

    Also accepts ``Level/Subject_code/paper-N/Topic/review_required/Q-folder`` -- a question that
    had no mark scheme, classified into <Topic> and parked for review (indexed as flagged).
    """
    found: List[Tuple[Path, Tuple[str, ...]]] = []
    for meta in sorted(root.rglob("metadata.json")):
        parts = meta.relative_to(root).parts
        if len(parts) < 3 or not re.fullmatch(r"paper-\d+", parts[2]):
            continue
        if len(parts) == 6 or (len(parts) == 7 and parts[4] == "review_required"):
            found.append((meta, parts))
    return found


def _paper_key_from_filename(name: str) -> str:
    """``9702_s24_qp_22.pdf`` -> ``9702_s24_22``; anything else keeps its stem.

    The pipeline's keys are ``<code>_<season+yy>_<variant>``; a question-paper filename carries the
    same three pieces separated by ``_qp_``, so the key can be rebuilt without guessing at content.
    """
    stem = Path(name).stem.lower()
    parts = stem.split("_")
    if "qp" in parts:
        index = parts.index("qp")
        if index >= 2 and index + 1 < len(parts):
            return f"{parts[0]}_{parts[1]}_{parts[index + 1]}"
    return stem


def _caie_source_pdfs(root: Path) -> Dict[str, Path]:
    """{paper key: question-paper PDF} for a CAIE run, from the pipeline's own state.

    `main.py` records each paper's QP path in `pipeline.sqlite` (and `.pipeline_state.json`). Those
    paths may point at staging symlinks, so each is resolved to its real file and only survivors are
    returned; a key looks like ``9702_s24_22`` (code, season+year, variant).
    """
    found: Dict[str, Path] = {}

    def keep(key: str, raw: object) -> None:
        if not raw:
            return
        try:
            real = Path(str(raw)).resolve()
        except OSError:
            return
        if real.is_file():
            found.setdefault(key, real)

    # Preferred source: the durable map the app writes at batch time (name -> the user's real file).
    for name, raw in (_read_json(root / "index_sources.json", {}) or {}).items():
        lowered = Path(str(name)).name.lower()
        if "qp" in lowered and "ms" not in lowered:                  # question papers only
            keep(_paper_key_from_filename(str(name)), raw)
    state = _read_json(root / ".pipeline_state.json", {}) or {}
    for key, paper in (state.get("papers") or {}).items():
        if isinstance(paper, dict):
            keep(str(key), paper.get("qp_path"))
    database = root / "pipeline.sqlite"
    if database.is_file():
        try:
            import sqlite3                                          # noqa: PLC0415 (stdlib)
            with sqlite3.connect(f"file:{database}?mode=ro", uri=True) as conn:
                for key, path in conn.execute("SELECT paper_code, qp_path FROM state_papers"):
                    keep(str(key), path)
        except Exception:                                           # noqa: BLE001 - optional
            pass
    return found


def _caie_paper_key(code: str, season: str, year: str, variant: str) -> str:
    """``('9702', 'Summer', '2024', '22')`` -> ``9702_s24_22`` (the pipeline's own key shape)."""
    letter = (season or "?")[:1].lower()
    suffix = year[-2:] if len(year) >= 2 else year
    return f"{code}_{letter}{suffix}_{variant}".strip("_")


def _caie_subject_parts(subject_dir: str) -> Tuple[str, str]:
    """('Physics', '9702') from the CAIE out folder name ``Physics_9702``.

    The code is the last underscore-separated token when it looks like a CAIE code (four digits);
    anything else is left as the folder name with an empty code, which the catalogue gap check then
    reports rather than inventing an identity.
    """
    head, _, tail = subject_dir.rpartition("_")
    if head and re.fullmatch(r"\d{4}", tail):
        return head.replace("_", " "), tail
    return subject_dir.replace("_", " "), ""


def _caie_pixels(path: Path) -> Optional[list]:
    """[width, height] for a crop, or None when Pillow is unavailable/unreadable (never fatal)."""
    try:
        from PIL import Image                                   # noqa: PLC0415 (optional by design)
        with Image.open(path) as img:
            return [int(img.width), int(img.height)]
    except Exception:                                            # noqa: BLE001 - metadata is optional
        return None


CHECK_ME_CONFIDENCE = 0.5      # idea 11: below this the question is filed but marked "check me"


def _run_evidence(root: Path) -> Tuple[Dict[str, dict], Dict[str, List[str]]]:
    """Classifier audit records and P3 paper flags keyed by resolved question folder.

    ``metadata.json`` is the canonical 10-field contract, so confidence, the
    runner-up topic and paper flags come from the run's own side records:
    ``.classification_audit/*.jsonl`` and ``.run_report/papers/*.json``.
    """
    audit: Dict[str, dict] = {}
    for jl in sorted((root / ".classification_audit").glob("*.jsonl")):
        try:
            for line in jl.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                rec = json.loads(line)
                folder = str(rec.get("output_folder") or "")
                if folder:
                    audit[str(Path(folder).resolve())] = rec
        except Exception:
            continue
    flags: Dict[str, List[str]] = {}
    for pj in sorted((root / ".run_report" / "papers").glob("*.json")):
        rec = _read_json(pj, {}) or {}
        fl = list((rec.get("checks") or {}).get("flags") or [])
        if not fl:
            continue
        for q in rec.get("questions") or []:
            if q.get("folder"):
                flags[str((root / q["folder"]).resolve())] = fl
    return audit, flags


def _second_topic(rec: dict, first: str) -> Tuple[Optional[str], Optional[float]]:
    scores = rec.get("major_scores") or {}
    try:
        ranked = sorted(((float(v), k) for k, v in scores.items()), reverse=True)
    except Exception:
        return None, None
    runner = next(((v, k) for v, k in ranked if k != first and v > 0), None)
    if runner is None:
        return None, None
    top = next((v for v, k in ranked if k == first), ranked[0][0] if ranked else 0.0)
    return runner[1], (round(runner[0] / top, 3) if top else None)


def index_caie_out(root: Path, catalogue_codes: Dict[str, set], *, extract_text: bool = True,
                   ocr: bool = False) -> Tuple[List[dict], List[str], List[str]]:
    """(rows, gaps, notes) for a CAIE output tree written by `main.py`. Never writes anything."""
    rows: List[dict] = []
    gaps: List[str] = []
    notes: List[str] = []
    source_pdfs = _caie_source_pdfs(root)
    audit, paper_flags = _run_evidence(root)
    for meta_path, parts in _caie_question_dirs(root):
        level, subject_dir, paper_dir, topic_dir = parts[0], parts[1], parts[2], parts[3]
        meta = _read_json(meta_path, {}) or {}
        if not isinstance(meta, dict) or not meta:
            notes.append(f"{meta_path}: no readable metadata.json -- skipped (not indexed)")
            continue
        subject, code = _caie_subject_parts(subject_dir)
        if code and catalogue_codes and code not in catalogue_codes.get("CAIE", set()):
            gaps.append(f"CAIE {code} (folder {subject_dir}, {paper_dir})")
        paper_number = paper_dir.split("-", 1)[1]
        variant = str(meta.get("variant") or "").strip()
        component = f"{code or subject_dir}/{variant or paper_number}"
        season = str(meta.get("season") or "")
        year = str(meta.get("year") or "")
        session = f"{season} {year}".strip() or meta_path.parent.name
        raw_qn = str(meta.get("question_number") or "")
        digits = re.search(r"(\d+)", raw_qn)
        qn = int(digits.group(1)) if digits else 0
        topics = meta.get("topic")
        topic_name = (str(topics[0]) if isinstance(topics, list) and topics else str(topics or ""))
        topic_name = topic_name or "UNKNOWN"

        # Text for search. Cambridge papers here are scan-like, so the text layer is often empty:
        # the QP's own numbering gives a *heuristic* span (labelled as such), and a crop is OCR'd
        # only when the caller asked for it and the runtime is present.
        question_text, text_source, derived_marks = "", None, None
        if extract_text or ocr:
            source_pdf = source_pdfs.get(_caie_paper_key(code, season, year, variant))
            if source_pdf is not None:
                paper_text = _pdf_text(source_pdf)
                span = split_question_spans(paper_text).get(qn, "")
                if span:
                    question_text, text_source = span, "qp_heuristic"
                    derived_marks = marks_from_text(span)
        if not question_text and ocr:
            crop = next((p for p in sorted(meta_path.parent.glob("*.webp"))
                         if not p.stem.endswith("_MS")), None)
            if crop is not None:
                ocr_text = ocr_image(crop)
                if ocr_text.strip():
                    question_text, text_source = ocr_text, "ocr"
                    derived_marks = derived_marks or marks_from_text(ocr_text)

        siblings = sorted(p for p in meta_path.parent.glob("*.webp"))
        er = [p for p in siblings if re.search(r"_ER(?:_part\d+)?$", p.stem)]
        qp = [p for p in siblings if not p.stem.endswith("_MS") and p not in er
              and not re.search(r"_MS_part\d+$", p.stem)]
        ms = [p for p in siblings if p.stem.endswith("_MS") or re.search(r"_MS_part\d+$", p.stem)]
        rel_qp = [_rel(p, root) for p in qp]
        rel_ms = [_rel(p, root) for p in ms]
        rel_er = [_rel(p, root) for p in er]
        _folder_key = str(meta_path.parent.resolve())
        _arec = audit.get(_folder_key) or {}
        _conf = _arec.get("confidence")
        try:
            _conf = None if _conf is None else round(float(_conf), 3)
        except (TypeError, ValueError):
            _conf = None
        _second, _second_ratio = _second_topic(_arec, topic_name) if _arec else (None, None)
        _check_me = _conf is not None and _conf < CHECK_ME_CONFIDENCE
        # <Topic>/review_required/<Q>: classified from the QP alone (no mark scheme) -- keep the
        # topic, but flag the row for the Review screen instead of listing it.
        topic_review = len(parts) == 7 and parts[4] == "review_required"
        review_reasons = [] if rel_qp else ["MISSING_QP_CROP"]
        if topic_review:
            review_reasons.append("MISSING_MS")
        crop_sha = _sha256_file(qp[0]) if qp else None
        pixels = _caie_pixels(qp[0]) if qp else None
        rows.append({
            "id": question_id("CAIE", component, session, qn),
            "board": "CAIE",
            "qualification": level,
            "code": code,
            "subject": subject,
            "component": component,
            "season": season,
            "session": session,
            "question_number": qn,
            "canonical_question": str(meta.get("question_number") or f"Q{qn}"),
            "topic": topic_name,
            "status": "REVIEW_REQUIRED" if topic_review else "HINT",
            "confidence": _conf,
            "second_topic": _second,
            "second_topic_ratio": _second_ratio,
            "check_me": _check_me,
            "paper_flags": paper_flags.get(_folder_key, []),
            "engine": "caie_pipeline",
            "spec_reference": None,
            "secondary": [str(t) for t in topics[1:4]] if isinstance(topics, list) else [],
            "marks": derived_marks,
            "marks_source": "question_text" if derived_marks is not None else None,
            "text": question_text[:TEXT_LIMIT] if question_text else None,
            "text_source": text_source,
            "listable": bool(rel_qp) and not topic_review,
            "flagged": not bool(rel_qp) or topic_review,
            "review_reasons": review_reasons,
            "override": None,
            "batch_topic": topic_name,
            "batch_status": "REVIEW_REQUIRED" if topic_review else "HINT",
            "artifacts": {"qp": rel_qp, "ms": rel_ms, "er": rel_er},
            "source": {"pdf": None, "sha256": None, "crop_sha256": crop_sha, "pixels": pixels},
            "batch_out": str(root),
            "pack_dir": _rel(meta_path.parent, root),
            "layout": "caie",
        })
    return rows, gaps, notes


def index_batch_out(root: Path, catalogue_codes: Dict[str, set], *, extract_text: bool = True,
                    ocr: bool = False) -> Tuple[List[dict], List[str], List[str]]:
    """(rows, gaps, notes) for one batch output tree, in either layout.

    A root is normally one or the other (a universal run writes ``final/``, a CAIE run writes
    ``<Level>/<Subject_code>/paper-N/``), but both readers run and their rows are concatenated: a
    directory that holds both must not silently lose half its questions, and the "no final/ tree"
    note is only honest when neither reader found anything.
    """
    rows, gaps, notes = _index_universal_out(root, catalogue_codes, extract_text=extract_text, ocr=ocr)
    caie_rows, caie_gaps, caie_notes = index_caie_out(root, catalogue_codes,
                                                       extract_text=extract_text, ocr=ocr)
    if caie_rows:
        notes = [n for n in notes if "no 'final/' tree" not in n]
        rows, gaps, notes = rows + caie_rows, gaps + caie_gaps, notes + caie_notes
    return rows, gaps, notes


def _index_universal_out(root: Path, catalogue_codes: Dict[str, set], *, extract_text: bool = True,
                         ocr: bool = False) -> Tuple[List[dict], List[str], List[str]]:
    """(rows, gaps, notes) for one universal (AQA/Edexcel/IB/SAT) batch output tree. Never writes."""
    rows: List[dict] = []
    gaps: List[str] = []
    notes: List[str] = []
    final_root = root / "final"
    if not final_root.is_dir():
        return rows, gaps, [f"{root}: no 'final/' tree -- not a batch output?"]

    for board_dir in sorted(p for p in final_root.iterdir() if p.is_dir()):
        board = board_dir.name
        for component_dir in sorted(p for p in board_dir.iterdir() if p.is_dir()):
            for session_dir in sorted(p for p in component_dir.iterdir() if p.is_dir()):
                season, year, session = _session_parts(session_dir)
                ctx = _identity_for(root, board, component_dir.name, session_dir)
                component = str((ctx or {}).get("identity", {}).get("component") or "") or \
                    component_dir.name.replace("_", "/")
                code = component.split("/")[0].strip()
                if code and catalogue_codes and code not in catalogue_codes.get(board, set()):
                    gaps.append(f"{board} {code} (component {component}, {session})")
                segments = (ctx or {}).get("segments", [])
                measurements = (ctx or {}).get("measurements", {})
                source_pdf = str((ctx or {}).get("identity", {}).get("path") or "")
                source_sha = (ctx or {}).get("identity", {}).get("sha256")

                pack_dirs: List[Path] = []
                for section in PACK_SECTIONS:
                    section_root = session_dir / section
                    if not section_root.is_dir():
                        continue
                    for qdir in sorted(section_root.glob("*/Q*")):
                        if qdir.is_dir():
                            pack_dirs.append(qdir)
                if not pack_dirs:
                    continue

                for qdir in pack_dirs:
                    meta = _read_json(qdir / "metadata.json")
                    if not isinstance(meta, dict):
                        notes.append(f"{qdir}: no readable metadata.json -- skipped (not indexed)")
                        continue
                    qn = int(meta.get("question_number") or 0)
                    topic = dict(meta.get("topic") or {})
                    status = str(topic.get("status") or "REVIEW_REQUIRED")
                    topic_name = str(topic.get("topic") or "UNKNOWN")
                    # 2026-09-29 (CLS-178c): "in" was missing from this allowlist, so a
                    # question's attached insert crop (Q1_IN.webp, written by the batch and
                    # recorded in its metadata) was silently dropped when the index was
                    # built -- the file existed but no row, and therefore no screen, could
                    # ever name it. Keys the batch does not write simply stay empty.
                    artifacts = {k: [str(p) for p in (meta.get("artifacts") or {}).get(k, [])]
                                 for k in ("qp", "ms", "er", "in")}
                    rel_artifacts = {k: [self_rel(p, root) for p in v] for k, v in artifacts.items()}
                    qp_present = any((root / r).exists() for r in rel_artifacts["qp"])
                    # Text for search: the batch recorded this question's pages, so the paper's own
                    # text layer is sliced exactly -- or the crop is OCR'd when asked for and possible.
                    question_text, text_source = "", None
                    if extract_text:
                        segment = next((seg for seg in segments
                                        if int(seg.get("question_number") or 0) == qn), {})
                        if source_pdf and Path(source_pdf).is_file():
                            question_text = _pdf_text(Path(source_pdf), segment.get("pages") or [])
                            text_source = "pdf_pages" if question_text.strip() else None
                    if not question_text and ocr and rel_artifacts["qp"]:
                        ocr_text = ocr_image(root / rel_artifacts["qp"][0])
                        if ocr_text.strip():
                            question_text, text_source = ocr_text, "ocr"
                    review_reasons = sorted({str(r.get("reason")) for r in (meta.get("review_required") or [])})
                    crop_sha = None
                    pixels = None
                    if rel_artifacts["qp"]:
                        first = root / rel_artifacts["qp"][0]
                        crop_sha = _sha256_file(first)
                        m = measurements.get(first.name) or {}
                        if m:
                            pixels = [m.get("width"), m.get("height")]
                    row = {
                        "id": question_id(board, component, session, qn),
                        "board": board,
                        "qualification": "",
                        "code": code,
                        "subject": "",
                        "component": component,
                        "season": season,
                        "year": year,
                        "session": session,
                        "question_number": qn,
                        "canonical_question": str(meta.get("canonical_question") or f"Q{qn}"),
                        "topic": topic_name,
                        "status": status,
                        "confidence": float(topic.get("confidence") or 0.0),
                        "engine": str(topic.get("engine") or ""),
                        "spec_reference": (topic.get("spec_reference")
                                           or (topic.get("reference") or {}).get("spec_reference")),
                        # Lever 1 (2026-09-29): how this row stands against the board's own printed
                        # reference. "agree"/"adopted" = verified by the mark scheme's own column;
                        # "disagree" can never be listable (the runner already re-statused it);
                        # "unchecked" = not AQA, or the column could not be read -- claimed as
                        # nothing, never as verified.
                        "spec_ref_status": (str(topic.get("spec_ref_status"))
                                            if topic.get("spec_ref_status") else None),
                        "spec_ref": (topic.get("spec_ref")
                                     if isinstance(topic.get("spec_ref"), dict) else None),
                        "verified": str(topic.get("spec_ref_status") or "") in ("agree", "adopted"),
                        "classifier_topic": topic.get("classifier_topic"),
                        "review_reason": topic.get("review_reason"),
                        "secondary": list(topic.get("secondary") or [])[:3],
                        "marks": (_marks_for(segments, qn) if _marks_for(segments, qn) is not None
                                  else marks_from_text(question_text)),
                        "marks_source": ("segments" if _marks_for(segments, qn) is not None
                                         else ("question_text" if marks_from_text(question_text) is not None
                                               else None)),
                        "text": question_text[:TEXT_LIMIT] if question_text.strip() else None,
                        "text_source": text_source,
                        "listable": bool(status == "HINT" and topic_name and topic_name != "UNKNOWN"
                                         and qp_present),
                        "flagged": not (status == "HINT" and topic_name and topic_name != "UNKNOWN"),
                        "review_reasons": review_reasons,
                        "override": None,
                        "batch_topic": topic_name,
                        "batch_status": status,
                        "artifacts": rel_artifacts,
                        "source": {"pdf": source_pdf, "sha256": source_sha,
                                   "crop_sha256": crop_sha, "pixels": pixels},
                        "batch_out": str(root),
                        "pack_dir": _rel(qdir, root),
                    }
                    rows.append(row)
    rows.sort(key=lambda r: (r["board"], r["component"], r["session"], r["question_number"]))
    return rows, gaps, notes


def self_rel(path: str, root: Path) -> str:
    """Artifact path from metadata.json -> path relative to the batch output root.

    Two shapes reach this function. An absolute path (a batch run with an
    absolute ``--output``) is relativised against the root directly. A relative
    path is recorded against the *batch run's CWD*, so it may either already be
    root-relative (``final/AQA/...``) or carry the root prefix (``out_aqa/final/...``)
    when the run used a relative ``--output``. Both must resolve to the same
    on-disk file: previously the second shape was double-prefixed by the caller
    (``root / artifact``), every QP looked absent, and a perfectly good batch
    indexed as 0 listable / everything flagged -- a silent fail that looked like
    a review queue.
    """
    p = Path(path)
    if p.is_absolute():
        return _rel(p, root)
    try:
        return str(p.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


def load_overrides(path: Path) -> dict:
    data = _read_json(path, {}) or {}
    return {
        "schema": data.get("schema") or "topic_overrides/1",
        "overrides": dict(data.get("overrides") or {}),
        "dismissed": dict(data.get("dismissed") or {}),
    }


def save_overrides(path: Path, payload: dict) -> None:
    _atomic_write(path, payload)


def apply_overrides(rows: List[dict], overrides: dict) -> Tuple[List[dict], List[str]]:
    """Apply user overrides/dismissals to index rows. Returns (rows, anomalies)."""
    anomalies: List[str] = []
    by_id = {r["id"]: r for r in rows}
    for qid, payload in (overrides.get("overrides") or {}).items():
        row = by_id.get(qid)
        if row is None:
            anomalies.append(f"override for unknown question {qid}")
            continue
        topic = str((payload or {}).get("topic") or "").strip()
        if not topic:
            anomalies.append(f"override for {qid} has no topic")
            continue
        row["override"] = {"topic": topic, "at": (payload or {}).get("at"),
                           "note": (payload or {}).get("note") or ""}
        row["topic"] = topic
        row["status"] = "HINT"
        row["engine"] = "user_override"
        row["flag_reason"] = row.get("flag_reason") or "user_override"
        row["listable"] = bool(row["artifacts"]["qp"]) and any(
            (Path(row["batch_out"]) / p).exists() for p in row["artifacts"]["qp"])
        row["flagged"] = False
        if not row["listable"]:
            anomalies.append(f"override for {qid} applied but its question crop is missing")
    for qid, payload in (overrides.get("dismissed") or {}).items():
        row = by_id.get(qid)
        if row is None:
            anomalies.append(f"dismissal for unknown question {qid}")
            continue
        row["dismissed"] = {"reason": (payload or {}).get("reason") or "", "at": (payload or {}).get("at")}
        row["review_reasons"] = list(row.get("review_reasons") or []) + ["dismissed by reviewer"]
    return rows, anomalies


def set_topic(path: Path, qid: str, topic: str, note: str = "") -> dict:
    """Record a manual topic assignment (used by --set-topic and the API)."""
    data = load_overrides(path)
    data["overrides"][qid] = {"topic": topic, "at": _now(), "note": note}
    data["dismissed"].pop(qid, None)
    save_overrides(path, data)
    return data


def dismiss(path: Path, qid: str, reason: str = "") -> dict:
    data = load_overrides(path)
    data["dismissed"][qid] = {"reason": reason, "at": _now()}
    data["overrides"].pop(qid, None)
    save_overrides(path, data)
    return data


def clear(path: Path, qid: str) -> dict:
    data = load_overrides(path)
    data["overrides"].pop(qid, None)
    data["dismissed"].pop(qid, None)
    save_overrides(path, data)
    return data


def _atomic_write(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, indent=1, ensure_ascii=False) + "\n")
    os.replace(tmp, path)


def build(batch_outs: List[Path], out: Path, overrides_path: Path,
          previous: Optional[dict] = None, *, extract_text: bool = True,
          ocr: bool = False) -> Tuple[dict, List[str], List[str]]:
    """(payload, gaps, notes). ``gaps`` non-empty means: do not write."""
    catalogue = _catalogue_codes()
    catalogue_rows = _catalogue_rows()
    new_rows: List[dict] = []
    gaps: List[str] = []
    notes: List[str] = []
    if ocr and not ocr_available():
        # asked for and impossible: say so in the payload rather than quietly doing nothing
        notes.append(_OCR_UNAVAILABLE_NOTE)
    for root in batch_outs:
        rows, root_gaps, root_notes = index_batch_out(root, catalogue,
                                                       extract_text=extract_text, ocr=ocr)
        new_rows += rows
        gaps += root_gaps
        notes += root_notes
    if gaps:
        return {}, gaps, notes

    # enrich from the catalogue (subject/qualification), then apply overrides
    for row in new_rows:
        cat = catalogue_rows.get((row["board"], row["code"]))
        if cat:
            row["qualification"] = str(cat.get("qualification") or "")
            row["subject"] = str(cat.get("subject") or "")
            row["catalogue_status"] = str(cat.get("catalogue_status") or "")
    overrides = load_overrides(overrides_path)
    new_rows, anomalies = apply_overrides(new_rows, overrides)
    notes += anomalies

    # idempotent merge: replace exactly the sources being rebuilt
    rebuilt = {str(Path(p).resolve()) for p in batch_outs}
    kept = [r for r in (previous or {}).get("questions", [])
            if str(r.get("batch_out")) not in rebuilt
            and not any(str(r.get("batch_out")) == str(p) for p in batch_outs)]
    # re-apply overrides to kept rows too, so a manual assignment survives a single-source rebuild
    kept, kept_anomalies = apply_overrides(kept, overrides)
    notes += [a for a in kept_anomalies if "unknown question" not in a]

    rows = kept + new_rows
    seen: Dict[str, dict] = {}
    for row in rows:
        seen[row["id"]] = row                                   # last writer wins within a source
    rows = [seen[k] for k in sorted(seen)]
    rows.sort(key=lambda r: (r["board"], r["component"], r["session"], r["question_number"]))

    # Provenance has to be complete. The merge above keeps rows from sources that are *not* being
    # rebuilt in this call, so those sources belong in `inputs.batch_outs` too -- otherwise a later
    # rebuild with no explicit --batch-out (which is how the server applies an override) re-reads
    # only the last source, leaves the other rows untouched, and a *cleared* override stays baked
    # into its row: the index keeps saying `overridden` while the overrides file says nothing.
    sources: List[str] = [str(p) for p in batch_outs]
    for row in rows:
        origin = str(row.get("batch_out") or "")
        if origin and origin not in sources:
            sources.append(origin)

    by_board: Dict[str, int] = {}
    by_subject: Dict[str, int] = {}
    by_topic: Dict[str, int] = {}
    for row in rows:
        by_board[row["board"]] = by_board.get(row["board"], 0) + 1
        key = f"{row['board']} {row['code'] or '????'}"
        by_subject[key] = by_subject.get(key, 0) + 1
        by_topic[row["topic"]] = by_topic.get(row["topic"], 0) + 1

    payload = {
        "schema": "topical_index/1",
        "generated_by": "tools/build_topical_index.py",
        "generated_at": _now(),
        "inputs": {"batch_outs": sources,
                   "overrides": str(overrides_path),
                   "catalogue": str(CATALOGUE)},
        "counts": {
            "questions": len(rows),
            "listable": sum(1 for r in rows if r["listable"]),
            "flagged": sum(1 for r in rows if not r["listable"]),
            "unknown_topic": sum(1 for r in rows if r["topic"] in ("", "UNKNOWN")),
            "overridden": sum(1 for r in rows if r.get("override")),
            "dismissed": sum(1 for r in rows if r.get("dismissed")),
            "by_board": by_board, "by_subject": by_subject, "by_topic": by_topic,
        },
        "questions": rows,
        "flagged": [r["id"] for r in rows if not r["listable"]],
        "notes": notes,
    }
    return payload, [], notes


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--batch-out", action="append", default=[], help="batch output dir (repeatable)")
    ap.add_argument("--reset", action="store_true",
                    help="index exactly the given --batch-out dirs: drop rows already in --out that "
                         "came from other sources (default: idempotent merge keeps them)")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    ap.add_argument("--overrides", default=str(DEFAULT_OVERRIDES))
    ap.add_argument("--set-topic", nargs=2, metavar=("ID", "TOPIC"), action="append", default=[])
    ap.add_argument("--dismiss", metavar="ID", action="append", default=[])
    ap.add_argument("--reason", default="", help="reason recorded with --dismiss")
    ap.add_argument("--clear", metavar="ID", action="append", default=[])
    ap.add_argument("--json", action="store_true", help="print the payload")
    ap.add_argument("--no-text", action="store_true",
                    help="skip reading each question's words out of the source PDF (the search index "
                         "then has no `text`, which is only useful for a very slow disk)")
    ap.add_argument("--ocr", action="store_true",
                    help="OCR the crops for questions with no text layer (needs the tesseract binary; "
                         "scanned papers are the only reason to pay for this)")
    args = ap.parse_args(argv)

    overrides_path = Path(args.overrides)
    if args.set_topic or args.dismiss or args.clear:
        for qid, topic in args.set_topic:
            set_topic(overrides_path, qid, topic)
            print(f"[index] override {qid} -> {topic}")
        for qid in args.dismiss:
            dismiss(overrides_path, qid, args.reason)
            print(f"[index] dismissed {qid}")
        for qid in args.clear:
            clear(overrides_path, qid)
            print(f"[index] cleared {qid}")
        if not args.batch_out:
            return 0

    if not args.batch_out:
        print("[index] nothing to do: pass --batch-out (or --set-topic/--dismiss/--clear)")
        return 2
    out = Path(args.out)
    previous = {} if args.reset else (_read_json(out, {}) or {})
    if args.reset and Path(out).exists():
        print(f"[index] --reset: ignoring the {len((_read_json(out, {}) or {}).get('questions') or [])} "
              f"row(s) already in {out.name}")
    batch_outs = [Path(p) for p in args.batch_out]
    missing = [str(p) for p in batch_outs if not p.is_dir()]
    if missing:
        print(f"[index] batch output not found: {', '.join(missing)}")
        return 2

    payload, gaps, notes = build(batch_outs, out, overrides_path, previous,
                                 extract_text=not args.no_text, ocr=bool(args.ocr))
    if gaps:
        print("[index] FAIL-CLOSED -- these (board, code) pairs are not in subjects.json:")
        for gap in sorted(set(gaps)):
            print(f"    {gap}")
        print("[index] nothing written; add the subject to the catalogue first "
              "(tools/generate_subjects_catalogue.py)")
        return 2

    _atomic_write(out, payload)
    counts = payload["counts"]
    print(f"[index] wrote {out.name} -- {counts['questions']} questions "
          f"({counts['listable']} listable, {counts['flagged']} flagged, "
          f"{counts['overridden']} overridden, {counts['dismissed']} dismissed) "
          f"from {len(batch_outs)} batch output(s)")
    for note in notes:
        print(f"[index] note: {note}")
    if args.json:
        print(json.dumps(payload, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
