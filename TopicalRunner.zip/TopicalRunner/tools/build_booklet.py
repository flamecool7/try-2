#!/usr/bin/env python3
"""tools/build_booklet.py — assemble a printable booklet PDF from index rows.

    python3 tools/build_booklet.py --booklet booklet.json --index topical_index.json \\
        --out booklet.pdf

Reads a **booklet request** (the Builder's own file — see
`design/TOPICAL_BOOKLET_DESIGN.md` §1d.5) and the topical index, and writes:

* ``booklet.pdf``            — the assembled booklet;
* ``booklet.manifest.json``  — beside it: every entry's id, kind, page, rect, scale, the crop's
  sha256 and the source paper's sha256, plus a sha256 of the PDF itself.

Rules (binding):

* **Two pinned libraries, no new ones** — PyMuPDF assembles the pages, and Pillow decodes the
  batch's WEBP crops, which MuPDF 1.24.14 cannot read (measured; see ``_image_stream``); both are
  already pinned in ``requirements.txt``. No re-cropping: the crop is decoded losslessly into an
  in-memory PNG and embedded at its own pixel size. (Amended 2026-09-25: this bullet claimed PyMuPDF
  was the only dependency and that nothing converted with Pillow — three functions above the Pillow
  conversion it performs. Found by ``tools/dependency_check.py``'s claim check, and kept as written
  until then.)
* **Full resolution** — a crop is never upscaled; it is scaled *down* only when it cannot fit the
  printable area. The scale used is recorded per entry.
* **A question is never split** — each question starts a new page and its pages are contiguous; no
  other question's content can interleave with it. Two fits are offered for a crop taller than the
  printable area, because the real crops make this a *measured* trade-off, not a taste question:
  ``--fit one_page`` (default, the literal rule) scales the whole crop down to a single page, and
  ``--fit flow`` scales it to the page *width* (never upscaling) and continues it across consecutive
  pages, carrying the question's label. On the 8461/1H fixture the difference is stark — Q4 is
  2280 × 14922 px (≈ 4.8 A4 pages tall), so one-page fit needs **scale 0.053** (unreadable) while
  flow keeps **scale 1.0**. The tool prints a legibility warning whenever one-page fit falls below
  ``--min-scale`` (default 0.35) and *says* how many pages flow mode would use.
* **Answers** — ``none`` writes no answer pages, ``after_each`` writes each question's mark scheme
  immediately after it, ``end`` collects every mark scheme after the last question. A requested
  answer whose mark scheme is missing becomes a ``warnings`` row, never a silently thinner booklet.
* **Fail-closed** — an unknown question id, a missing crop, or a non-listable row (unless
  ``--allow-flagged`` is given) aborts the build with exit 2 and **no output file**.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]

PAGE_SIZES = {"A4": (595.276, 841.89), "A4_LANDSCAPE": (841.89, 595.276), "LETTER": (612.0, 792.0)}
ANSWER_MODES = ("none", "after_each", "end")


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:                                              # noqa: BLE001
        return default


def _sha256_file(path: Path) -> Optional[str]:
    try:
        h = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def _image_stream(path: Path) -> Tuple[bytes, int, int]:
    """(PNG bytes, width, height) for a batch crop.

    The repository's crops are WEBP and **PyMuPDF 1.24.14's MuPDF has no WEBP decoder** (measured:
    ``fitz.open("Q4.webp")`` -> "cannot find document handler", ``fitz.Pixmap`` -> "unknown image file
    format"). The decode therefore uses **Pillow**, which is already a pinned dependency of this
    repository, and hands PyMuPDF a lossless in-memory PNG: assembly stays PyMuPDF, and the
    dependency set is unchanged. ``save(deflate=True)`` then compresses the embedded stream
    (measured: 34 MP crop -> 1.6 MB PDF stream, against 102 MB uncompressed).
    """
    from PIL import Image                                            # pinned: Pillow==11.0.0

    with Image.open(path) as im:
        im.load()
        width, height = im.width, im.height
        buf = io.BytesIO()
        im.convert("RGB").save(buf, format="PNG", optimize=True)
    return buf.getvalue(), width, height


def _resolve(path_text: str, index_path: Path, batch_out: str = "") -> Optional[Path]:
    """Resolve a crop path: relative to its batch output root, else relative to the index."""
    p = Path(path_text)
    if p.is_absolute():
        return p if p.exists() else None
    if batch_out:
        cand = Path(batch_out) / p
        if cand.exists():
            return cand
    cand = index_path.parent / p
    return cand if cand.exists() else None


def build(booklet: Dict[str, Any], index: Dict[str, Any], index_path: Path, out_pdf: Path,
          allow_flagged: bool = False, fit: str = "one_page",
          min_scale: float = 0.35) -> Tuple[Optional[Path], Optional[dict], List[str], List[str]]:
    """(pdf_path, manifest, errors, warnings). ``errors`` non-empty means nothing was written."""
    import fitz                                                    # PyMuPDF -- already a dependency

    errors: List[str] = []
    warnings: List[str] = []
    rows = {str(r.get("id")): r for r in index.get("questions", [])}
    request = booklet or {}
    wanted = list(request.get("questions") or [])
    if not wanted:
        return None, None, ["booklet.json lists no questions"], warnings
    mode = str((request.get("answers") or "none")).lower()
    if mode not in ANSWER_MODES:
        return None, None, [f"answers must be one of {list(ANSWER_MODES)} (got {mode!r})"], warnings
    cover = bool((request.get("options") or {}).get("cover", True))
    total_marks = 0
    marks_line = ""
    size = str((request.get("options") or {}).get("page") or "A4").upper()
    if size not in PAGE_SIZES:
        return None, None, [f"unknown page size {size!r}; known: {sorted(PAGE_SIZES)}"], warnings
    margin = float((request.get("options") or {}).get("margin_pt") or 28.0)
    numbering = bool((request.get("options") or {}).get("numbering", True))
    if fit not in ("one_page", "flow"):
        return None, None, [f"--fit must be 'one_page' or 'flow' (got {fit!r})"], warnings

    plan: List[dict] = []
    for position, item in enumerate(wanted, start=1):
        qid = str((item or {}).get("id") or "")
        row = rows.get(qid)
        if row is None:
            errors.append(f"question {qid!r} is not in the index")
            continue
        if not row.get("listable") and not allow_flagged:
            errors.append(f"question {qid!r} is flagged ({row.get('status')}); "
                          f"assign a topic or pass --allow-flagged")
            continue
        qp = [a for a in (row.get("artifacts") or {}).get("qp", [])]
        ms = [a for a in (row.get("artifacts") or {}).get("ms", [])]
        if not qp:
            errors.append(f"question {qid!r} has no question crop")
            continue
        qp_path = _resolve(qp[0], index_path, str(row.get("batch_out") or ""))
        if qp_path is None:
            errors.append(f"question {qid!r}: crop {qp[0]} is missing on disk")
            continue
        ms_path = _resolve(ms[0], index_path, str(row.get("batch_out") or "")) if ms else None
        if mode != "none" and ms_path is None:
            warnings.append(f"{qid}: no mark scheme crop available ({mode}); answer page omitted")
        plan.append({"row": row, "qp": qp_path, "ms": ms_path, "note": item.get("note") or "",
                     "position": position})
    if errors:
        return None, None, errors, warnings

    doc = fitz.open()
    page_w, page_h = PAGE_SIZES[size]
    avail_w = page_w - 2 * margin
    avail_h = page_h - 2 * margin
    entries: List[dict] = []
    order: List[dict] = []
    for item in plan:
        order.append({"kind": "question", "item": item})
    if mode == "after_each":
        order = []
        for item in plan:
            order.append({"kind": "question", "item": item})
            if item["ms"]:
                order.append({"kind": "answer", "item": item})
    elif mode == "end":
        order += [{"kind": "answer", "item": item} for item in plan if item["ms"]]
    elif mode == "none":
        pass

    title = str(request.get("title") or "Question booklet")
    subtitle = str(request.get("subtitle") or "")
    #: Marks the booklet carries, when the index knows them. Computed here, before anything is
    #: drawn, so the cover and the manifest print the same number.
    total_marks = sum(int(item["row"].get("marks") or 0) for item in plan)
    marked = [item["row"] for item in plan if item["row"].get("marks")]
    marks_line = (f"{total_marks} marks from {len(marked)} of {len(plan)} question(s)"
                  if marked else "")
    cover_text = "\n".join(x for x in (title, subtitle) if x)
    if marks_line:
        cover_text = f"{cover_text}\n{marks_line}" if cover_text else marks_line

    for step in order:
        item = step["item"]
        row = item["row"]
        source = item["ms"] if step["kind"] == "answer" else item["qp"]
        stream, img_w, img_h = _image_stream(source)
        img_w, img_h = float(img_w), float(img_h)
        if fit == "flow":
            #: page-width fit (never upscaled); the crop continues on as many pages as it needs
            scale = min(1.0, avail_w / img_w)
        else:
            #: one-page fit: the whole crop is scaled until it fits, however small that gets
            scale = min(1.0, avail_w / img_w, avail_h / img_h)
        draw_w, draw_h = img_w * scale, img_h * scale
        slices = max(1, int(-(-draw_h // avail_h)))                       # ceil
        if fit == "one_page":
            slices = 1
        x0 = margin + max(0.0, (avail_w - draw_w) / 2.0)
        pages_used = []
        for slice_index in range(slices):
            page = doc.new_page(width=page_w, height=page_h)
            y0 = margin - slice_index * avail_h
            target = fitz.Rect(x0, y0, x0 + draw_w, y0 + draw_h)
            page.insert_image(target, stream=stream)
            pages_used.append(doc.page_count - 1)
        del stream
        page = doc[pages_used[-1]]
        target = fitz.Rect(x0, margin - (slices - 1) * avail_h,
                           x0 + draw_w, margin - (slices - 1) * avail_h + draw_h)
        header = []
        if step["kind"] == "question":
            if numbering:
                header.append(f"{item['position']}. {row.get('topic') or ''}".strip())
            header.append(f"{row.get('component')} · {row.get('session')} · "
                          f"{row.get('canonical_question')}")
        else:
            header.append(f"Mark scheme — {row.get('canonical_question')} "
                          f"({row.get('topic') or 'unclassified'})")
        label = "\n".join(h for h in header if h)
        if label:
            for k, pno in enumerate(pages_used):
                suffix = f" (cont. {k + 1}/{len(pages_used)})" if k else ""
                # multi-line labels start higher so the last line clears the crop
                doc[pno].insert_text((margin, margin - 6 - 10.5 * label.count("\n")),
                                     label + suffix, fontsize=9,
                                     color=(0.35, 0.35, 0.35))
        if step["kind"] == "question" and item["note"]:
            page.insert_text((margin, page_h - margin + 16), str(item["note"]), fontsize=8,
                             color=(0.45, 0.45, 0.45))
        entries.append({
            "index": len(entries) + 1,
            "id": row.get("id"), "kind": step["kind"], "topic": row.get("topic"),
            "component": row.get("component"), "session": row.get("session"),
            "question_number": row.get("question_number"),
            "source_pdf": (row.get("source") or {}).get("pdf"),
            "source_sha256": (row.get("source") or {}).get("sha256"),
            "crop": str(source), "crop_sha256": _sha256_file(source),
            "crop_pixels": [int(img_w), int(img_h)],
            "page": pages_used[0],
            "pages": pages_used,
            "rect": [round(v, 2) for v in (target.x0, target.y0, target.x1, target.y1)],
            "scale": round(scale, 6),
        })
        if step["kind"] == "question" and scale < min_scale:
            # The mode decides the wording: under --fit flow this *is* the flow scale, so advising
            # "re-run with --fit flow" would be advice already taken (and the scale it quotes as an
            # alternative would be the one on the page). Measured cold on the launcher's own option 4.
            flow_scale = min(1.0, avail_w / img_w)
            flow_pages = max(1, int(-(-(img_h * flow_scale) // avail_h)))
            if fit == "flow":
                warnings.append(
                    f"{row.get('id')}: flow fit keeps scale {scale:.3f} (< {min_scale}) over "
                    f"{slices} page(s) -- the crop is wider than the page allows; --fit flow is "
                    f"already in effect, so this is the legibility the crop itself permits")
            else:
                warnings.append(
                    f"{row.get('id')}: one-page fit needs scale {scale:.3f} (< {min_scale}); "
                    f"flow fit would keep scale {flow_scale:.3f} over {flow_pages} page(s) -- "
                    f"re-run with --fit flow if legibility matters more than one page per question")

    if not entries:
        return None, None, ["nothing to assemble: every requested question was skipped"], warnings

    out_pdf.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(out_pdf.parent), prefix=out_pdf.name, suffix=".tmp")
    os.close(fd)
    doc.save(tmp, deflate=True, garbage=3)
    doc.close()
    os.replace(tmp, out_pdf)

    manifest = {
        "schema": "booklet_manifest/1",
        "generated_by": "tools/build_booklet.py",
        "generated_at": _now(),
        "request": {"title": title, "subtitle": subtitle, "answers": mode,
                    "board": request.get("board"), "code": request.get("code"),
                    "questions": [i["row"]["id"] for i in plan]},
        "request_sha256": hashlib.sha256(
            json.dumps(request, sort_keys=True).encode("utf-8")).hexdigest(),
        "answers": mode,
        "fit": fit,
        "cover": bool(cover),
        "total_marks": total_marks,
        "marks_note": marks_line or None,
        "pdf": {"path": out_pdf.name, "sha256": _sha256_file(out_pdf),
                "bytes": out_pdf.stat().st_size,
                "pages": entries and max(max(e["pages"]) for e in entries) + 1},
        "entries": entries,
        "warnings": warnings,
        "cover_text": cover_text or None,
    }
    return out_pdf, manifest, [], warnings


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--booklet", required=True, help="booklet request JSON")
    ap.add_argument("--index", default=str(ROOT / "topical_index.json"))
    ap.add_argument("--out", default="", help="output PDF (default: booklet.pdf beside the request)")
    ap.add_argument("--manifest", default="", help="manifest path (default: <pdf>.manifest.json)")
    ap.add_argument("--allow-flagged", action="store_true",
                    help="include questions the classifier flagged (default: refuse)")
    ap.add_argument("--fit", choices=("one_page", "flow"), default="one_page",
                    help="one_page: the whole crop on one page (default, the literal rule); "
                         "flow: page-width scale, continued over consecutive pages")
    ap.add_argument("--min-scale", type=float, default=0.35,
                    help="warn when one-page fit falls below this scale (default 0.35)")
    args = ap.parse_args(argv)

    booklet_path = Path(args.booklet)
    request = _read_json(booklet_path)
    if not isinstance(request, dict):
        print(f"[booklet] cannot read a booklet request from {booklet_path}")
        return 2
    index_path = Path(args.index)
    index = _read_json(index_path, {}) or {}
    if not index.get("questions"):
        print(f"[booklet] index {index_path} is missing or empty; run tools/build_topical_index.py")
        return 2
    out_pdf = Path(args.out) if args.out else booklet_path.parent / "booklet.pdf"

    pdf, manifest, errors, warnings = build(request, index, index_path, out_pdf,
                                            allow_flagged=args.allow_flagged, fit=args.fit,
                                            min_scale=args.min_scale)
    if errors:
        print("[booklet] FAIL-CLOSED -- nothing written:")
        for err in errors:
            print(f"    {err}")
        return 2
    manifest_path = Path(args.manifest) if args.manifest else out_pdf.with_suffix(".manifest.json")
    manifest_path.write_text(json.dumps(manifest, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    counts = {"questions": sum(1 for e in manifest["entries"] if e["kind"] == "question"),
              "answers": sum(1 for e in manifest["entries"] if e["kind"] == "answer"),
              "pages": manifest["pdf"]["pages"]}
    print(f"[booklet] wrote {pdf} ({manifest['pdf']['bytes']} bytes, {counts['pages']} page(s)) "
          f"+ {manifest_path.name} -- {counts['questions']} question(s), {counts['answers']} answer(s), "
          f"answers={manifest['answers']}")
    for warn in warnings:
        print(f"[booklet] warning: {warn}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
