#!/usr/bin/env python3
"""tools/build_index_page.py - one self-contained topical index page (task 15 / ideas 17 + 19).

    python tools/build_index_page.py --output OUT_DIR [--html OUT_DIR/topical_index.html]
                                     [--no-thumbs] [--dup-threshold 4]

Subject -> topic -> every question, with a thumbnail of the crop, filterable by
year / paper / text, and badges for "check me" (low classifier confidence),
review_required and paper flags (P3 checks).  Works offline (thumbnails are
embedded as data URIs); open it straight from disk.

Cross-variant duplicates (idea 19): Cambridge often prints the same question in
two variants of one session (e.g. 9709/12 and 9709/32 share nothing, but
0625/41 and 0625/43 sometimes share a question).  Questions of the same
syllabus, session and paper number whose crops have near-identical perceptual
hashes (difference hash, Hamming distance <= threshold, similar height) are
grouped; the page shows "also in ..." and ``duplicates.json``-style data is
printed with ``--json``.
"""
from __future__ import annotations

import argparse
import html
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

from make_worksheet import index_rows  # noqa: E402


def _esc(v) -> str:
    return html.escape(str(v if v is not None else ""), quote=True)


def _crop_path(root: Path, row: dict) -> Optional[Path]:
    qp = (row.get("artifacts") or {}).get("qp") or []
    if not qp:
        return None
    p = Path(qp[0])
    p = p if p.is_absolute() else (root / p)
    if p.exists():
        return p
    parts = sorted(p.parent.glob(p.stem + "_part*" + p.suffix))
    return parts[0] if parts else None


def dhash(path: Path, size: int = 16) -> Optional[Tuple[int, int]]:
    """(64*4-bit difference hash of the top of the crop, crop height)."""
    try:
        from PIL import Image  # noqa: PLC0415
        with Image.open(path) as im:
            h = im.height
            top = im.convert("L").crop((0, 0, im.width, min(im.height, 1400)))
            small = top.resize((size + 1, size))
            px = list(small.tobytes())
    except Exception:
        return None
    bits = 0
    for r in range(size):
        for c in range(size):
            bits = (bits << 1) | (1 if px[r * (size + 1) + c] > px[r * (size + 1) + c + 1] else 0)
    return bits, h


def find_duplicates(root: Path, rows: List[dict], threshold: int = 4) -> Dict[str, List[str]]:
    """id -> ids of the same question in other variants of the same session/paper."""
    groups: Dict[Tuple[str, str, str], List[Tuple[str, int, int]]] = {}
    for row in rows:
        comp = str(row.get("component") or "")
        variant = comp.split("/")[-1]
        if not variant[:1].isdigit():
            continue
        crop = _crop_path(root, row)
        if crop is None:
            continue
        hv = dhash(crop)
        if hv is None:
            continue
        key = (str(row.get("code") or comp.split("/")[0]), str(row.get("session") or ""), variant[:1])
        groups.setdefault(key, []).append((str(row["id"]), hv[0], hv[1]))
    dup: Dict[str, List[str]] = {}
    for items in groups.values():
        for i, (ida, ha, hgt_a) in enumerate(items):
            for idb, hb, hgt_b in items[i + 1:]:
                if ida.split("|")[1] == idb.split("|")[1]:
                    continue                                    # same variant
                if abs(hgt_a - hgt_b) > 0.08 * max(hgt_a, hgt_b):
                    continue
                if bin(ha ^ hb).count("1") <= threshold:
                    dup.setdefault(ida, []).append(idb)
                    dup.setdefault(idb, []).append(ida)
    return dup


def build_page(root: Path, rows: List[dict], out: Path, *, thumbs: bool = True,
               dup_threshold: int = 4) -> Dict[str, int]:
    from core.run_report import _CSS, _thumb  # noqa: PLC0415
    dups = find_duplicates(root, rows, dup_threshold)
    years = sorted({m.group(1) for r in rows for m in [re.search(r"(\d{4})", str(r.get("session") or ""))] if m})
    papers = sorted({str(r.get("component") or "").split("/")[-1][:1] for r in rows} - {""})
    by_subject: Dict[str, Dict[str, List[dict]]] = {}
    for r in rows:
        subj = f"{r.get('code') or ''} {r.get('subject') or ''}".strip()
        by_subject.setdefault(subj, {}).setdefault(r.get("topic") or "UNKNOWN", []).append(r)
    blocks = []
    n_tiles = 0
    for subj in sorted(by_subject):
        topics = by_subject[subj]
        tparts = []
        for topic in sorted(topics):
            tiles = []
            for r in sorted(topics[topic], key=lambda x: (str(x.get("session", ""))[-4:], str(x.get("component")),
                                                         int(x.get("question_number") or 0))):
                y = re.search(r"(\d{4})", str(r.get("session") or ""))
                paper = str(r.get("component") or "").split("/")[-1][:1]
                crop = _crop_path(root, r)
                src = _thumb(crop, width=320, max_h=420) if (thumbs and crop) else ""
                badges = []
                if not r.get("listable"):
                    badges.append("<span class='tag r'>review</span>")
                if r.get("check_me"):
                    badges.append(f"<span class='tag r'>check me ({r.get('confidence')})</span>")
                if r.get("paper_flags"):
                    badges.append("<span class='tag f' title='" + _esc("; ".join(r["paper_flags"]))
                                  + "'>paper flag</span>")
                if r.get("second_topic"):
                    badges.append(f"<span class='tag'>also: {_esc(r['second_topic'])}</span>")
                if r["id"] in dups:
                    also = ", ".join(i.split("|")[1] for i in dups[r["id"]])
                    badges.append(f"<span class='tag'>same as {_esc(also)}</span>")
                rel = str(crop.relative_to(root)) if crop and str(crop).startswith(str(root)) else ""
                tiles.append(
                    f"<div class='tile' data-year='{_esc(y.group(1) if y else '')}' data-paper='{_esc(paper)}'>"
                    f"<div><b>{_esc(r.get('component'))} {_esc(r.get('session'))} "
                    f"{_esc(r.get('canonical_question'))}</b>"
                    + (f" <span class='small'>[{_esc(r.get('marks'))} marks]</span>" if r.get("marks") else "")
                    + f"</div><div>{''.join(badges)}</div>"
                    + (f"<a href='{_esc(rel)}'><img loading='lazy' src='{src}'></a>" if src else
                       (f"<a href='{_esc(rel)}'>open crop</a>" if rel else ""))
                    + "</div>")
                n_tiles += 1
            tparts.append(f"<details class='topic'><summary>{_esc(topic)} "
                          f"<span class='small'>({len(tiles)})</span></summary>"
                          f"<div class='grid'>{''.join(tiles)}</div></details>")
        blocks.append(f"<section class='subj'><h2>{_esc(subj)} <span class='small'>"
                      f"({sum(len(v) for v in topics.values())} questions)</span></h2>{''.join(tparts)}</section>")
    yopts = "".join(f"<option>{y}</option>" for y in years)
    popts = "".join(f"<option value='{p}'>Paper {p}</option>" for p in papers)
    page = f"""<!doctype html><html><head><meta charset="utf-8"><title>Topical index</title>
<style>{_CSS}
details.topic{{background:#fff;border:1px solid #dde1e8;border-radius:8px;margin:6px 0;padding:6px 10px}}
summary{{cursor:pointer;font-weight:600}} select{{padding:6px;margin:0 6px 0 0}}
.tile a{{text-decoration:none}}</style></head><body>
<h1>Topical index</h1><div class="sub">{len(rows)} questions &middot; {len(by_subject)} subject(s) &middot;
{len(dups)} question(s) appear in more than one variant</div>
<div><input id="q" placeholder="search topic / paper / session..."> <select id="y"><option value="">all years</option>{yopts}</select>
<select id="p"><option value="">all papers</option>{popts}</select>
<button onclick="for(const d of document.querySelectorAll('details'))d.open=true">expand all</button></div>
{''.join(blocks)}
<script>
function f(){{const q=document.getElementById('q').value.toLowerCase(),y=document.getElementById('y').value,p=document.getElementById('p').value;
for(const t of document.querySelectorAll('.tile')){{const ok=(!y||t.dataset.year==y)&&(!p||t.dataset.paper==p)&&(!q||t.closest('details').textContent.toLowerCase().includes(q));t.style.display=ok?'':'none';}}
for(const d of document.querySelectorAll('details.topic')){{const any=[...d.querySelectorAll('.tile')].some(t=>t.style.display!='none');d.style.display=any?'':'none';if(q||y||p)d.open=any;}}}}
for(const id of ['q','y','p'])document.getElementById(id).addEventListener('input',f);
</script></body></html>"""
    out.write_text(page, encoding="utf-8")
    return {"questions": len(rows), "tiles": n_tiles, "duplicates": len(dups)}


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--output", required=True, help="pipeline output folder")
    ap.add_argument("--html", default="", help="page path (default OUT/topical_index.html)")
    ap.add_argument("--no-thumbs", action="store_true")
    ap.add_argument("--dup-threshold", type=int, default=4)
    ap.add_argument("--json", action="store_true", help="print the duplicate groups as JSON")
    a = ap.parse_args(argv)
    root = Path(a.output).resolve()
    if not root.is_dir():
        print(f"[index-page] output folder not found: {root}")
        return 2
    rows = index_rows(root)
    out = Path(a.html) if a.html else root / "topical_index.html"
    stats = build_page(root, rows, out, thumbs=not a.no_thumbs, dup_threshold=a.dup_threshold)
    if a.json:
        print(json.dumps(find_duplicates(root, rows, a.dup_threshold), indent=2))
    print(f"[index-page] {stats['questions']} question(s), {stats['duplicates']} in cross-variant "
          f"duplicate groups -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
