#!/usr/bin/env python3
"""tools/make_worksheet.py - one-command topical worksheet (task 15 / idea 16).

    python tools/make_worksheet.py --output OUT_DIR --subject 9702 --topic Waves \\
        [--years 2019-2024] [--paper 2] [--answers end|after_each|none] \\
        [--include-secondary] [--include-review] [--fit flow] [--out worksheet.pdf]
    python tools/make_worksheet.py --output OUT_DIR --list            # subjects / topics / counts

Thin wrapper over the existing tools (no new layout code):
  1. ``tools/build_topical_index.build`` indexes the pipeline output folder,
  2. the rows are filtered by subject / topic / years / paper,
  3. ``tools/build_booklet.build`` lays out the printable PDF (questions, then the
     mark schemes at the back with ``--answers end``) and its manifest.

``--include-secondary`` also takes questions whose runner-up topic (from the
classifier audit) is the requested topic - cross-topic questions.  Questions
still in ``review_required`` are left out unless ``--include-review``.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

import build_booklet  # noqa: E402
import build_topical_index  # noqa: E402


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(text or "").lower())


def _years(spec: str) -> Optional[Tuple[int, int]]:
    if not spec:
        return None
    m = re.fullmatch(r"\s*(\d{4})\s*(?:[-:]\s*(\d{4}))?\s*", spec)
    if not m:
        raise SystemExit(f"--years must look like 2019 or 2019-2024 (got {spec!r})")
    a = int(m.group(1)); b = int(m.group(2) or a)
    return (min(a, b), max(a, b))


def index_rows(output_dir: Path, *, extract_text: bool = False) -> List[dict]:
    with tempfile.TemporaryDirectory() as tmp:
        payload, gaps, _notes = build_topical_index.build(
            [output_dir.resolve()], Path(tmp) / "index.json", Path(tmp) / "overrides.json",
            extract_text=extract_text)
    if gaps:
        print("[worksheet] note: index gaps (subjects missing from the catalogue): "
              + "; ".join(gaps[:5]))
        # index again without the catalogue check: a worksheet only needs the rows
        rows, _g, _n = build_topical_index.index_caie_out(output_dir.resolve(), {},
                                                          extract_text=extract_text)
        return rows
    return list(payload.get("questions") or [])


def select(rows: List[dict], *, subject: str, topic: str, years: Optional[Tuple[int, int]],
           paper: str, include_secondary: bool, include_review: bool) -> List[dict]:
    want_subject = _norm(subject)
    want_topic = _norm(topic)
    out = []
    for row in rows:
        if want_subject and want_subject not in (_norm(row.get("code")), _norm(row.get("subject")),
                                                 _norm(row.get("component", "").split("/")[0])):
            if want_subject not in _norm(row.get("subject")):
                continue
        main_hit = want_topic in (_norm(row.get("topic")),) or (want_topic and want_topic == _norm(row.get("batch_topic")))
        second_hit = include_secondary and want_topic and want_topic == _norm(row.get("second_topic"))
        if want_topic and not (main_hit or second_hit):
            continue
        if years:
            y = re.search(r"(\d{4})", str(row.get("session") or ""))
            if not y or not (years[0] <= int(y.group(1)) <= years[1]):
                continue
        if paper:
            comp = str(row.get("component") or "")
            variant = comp.split("/")[-1]
            if not variant.startswith(str(paper)):
                continue
        if not row.get("listable") and not include_review:
            continue
        if not (row.get("artifacts") or {}).get("qp"):
            continue
        out.append(row)
    out.sort(key=lambda r: (str(r.get("session", ""))[-4:], str(r.get("session", "")),
                            str(r.get("component", "")), int(r.get("question_number") or 0)))
    return out


def list_contents(rows: List[dict]) -> None:
    by: Dict[str, Dict[str, int]] = {}
    for r in rows:
        key = f"{r.get('code')} {r.get('subject')}"
        by.setdefault(key, {})
        by[key][r.get("topic") or "UNKNOWN"] = by[key].get(r.get("topic") or "UNKNOWN", 0) + 1
    for subj in sorted(by):
        print(subj)
        for t, n in sorted(by[subj].items()):
            print(f"    {n:4d}  {t}")


def make(output_dir: Path, *, subject: str, topic: str, years: str = "", paper: str = "",
         answers: str = "end", include_secondary: bool = False, include_review: bool = False,
         fit: str = "flow", out: Optional[Path] = None, title: str = "") -> int:
    rows = index_rows(output_dir)
    chosen = select(rows, subject=subject, topic=topic, years=_years(years), paper=paper,
                    include_secondary=include_secondary, include_review=include_review)
    if not chosen:
        print(f"[worksheet] no questions match subject={subject!r} topic={topic!r} "
              f"years={years or 'all'} paper={paper or 'all'} (try --list)")
        return 2
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", f"{subject}_{topic}_{years or 'all'}").strip("_")
    out = out or (output_dir / "worksheets" / f"{safe}.pdf")
    out.parent.mkdir(parents=True, exist_ok=True)
    index = {"questions": chosen}
    request = {
        "title": title or f"{subject} - {topic}" + (f" ({years})" if years else ""),
        "answers": answers,
        "questions": [{"id": r["id"]} for r in chosen],
        "options": {"cover": True, "page": "A4", "numbering": True, "margin_pt": 40},
    }
    index_path = out.with_suffix(".index.json")
    index_path.write_text(json.dumps(index, indent=2, default=str), encoding="utf-8")
    pdf, manifest, errors, warnings = build_booklet.build(
        request, index, index_path, out, allow_flagged=include_review, fit=fit)
    try:
        index_path.unlink()
    except OSError:
        pass
    # 2280px crops always map below 0.35 px->pt on A4: density, not legibility
    warnings = [w for w in warnings if "keeps scale" not in w]
    for w in warnings[:20]:
        print(f"[worksheet] warning: {w}")
    if errors:
        for e in errors[:20]:
            print(f"[worksheet] error: {e}")
        return 2
    n_sec = sum(1 for r in chosen if _norm(r.get("topic")) != _norm(topic))
    print(f"[worksheet] {len(chosen)} question(s)"
          + (f" ({n_sec} cross-topic)" if n_sec else "")
          + f", answers={answers} -> {pdf}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--output", required=True, help="pipeline output folder (the -o of the run)")
    ap.add_argument("--subject", default="", help="syllabus code or subject name, e.g. 9702")
    ap.add_argument("--topic", default="", help="topic folder name, e.g. Waves")
    ap.add_argument("--years", default="", help="2019 or 2019-2024")
    ap.add_argument("--paper", default="", help="paper number (first digit of the variant), e.g. 2")
    ap.add_argument("--answers", choices=build_booklet.ANSWER_MODES, default="end")
    ap.add_argument("--include-secondary", action="store_true",
                    help="also questions whose runner-up topic is --topic")
    ap.add_argument("--include-review", action="store_true",
                    help="also questions still in review_required")
    ap.add_argument("--fit", choices=("one_page", "flow"), default="flow")
    ap.add_argument("--title", default="")
    ap.add_argument("--out", default="", help="PDF path (default OUT/worksheets/<subject>_<topic>.pdf)")
    ap.add_argument("--list", action="store_true", help="list subjects and topics with counts")
    a = ap.parse_args(argv)
    output_dir = Path(a.output)
    if not output_dir.is_dir():
        print(f"[worksheet] output folder not found: {output_dir}")
        return 2
    if a.list:
        list_contents(index_rows(output_dir))
        return 0
    if not a.topic:
        print("[worksheet] --topic is required (use --list to see topics)")
        return 2
    return make(output_dir, subject=a.subject, topic=a.topic, years=a.years, paper=a.paper,
                answers=a.answers, include_secondary=a.include_secondary,
                include_review=a.include_review, fit=a.fit,
                out=Path(a.out) if a.out else None, title=a.title)


if __name__ == "__main__":
    sys.exit(main())
