#!/usr/bin/env python3
"""Universal board batch runner for adapter-backed papers.

This is a production-routing harness around existing pieces, not a crop-engine
rewrite.  It:

* indexes input PDFs by SHA-256 and official/source provenance when known,
* associates QP/MS/ER/insert documents by board/component/session/year,
* routes renderable QPs through the discovered board adapter,
* delegates final image geometry to adapters.segment_geometry, which in turn
  uses the locked Cambridge gold helpers,
* validates adapter metadata and WEBP output contracts, and
* writes one audit JSON plus a human-readable Markdown report.

Unknown/unsupported documents are recorded as REVIEW_REQUIRED instead of guessed.
IB and SAT are INCLUDED by default (2026-09-28): a folder holding an IB or SAT paper is processed
like any other board's, with no switch to tick. The switches survive as the way to *exclude* a board
(`--no-include-ib` / `--no-include-sat`), which is the opposite direction of the old gate.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.util
import json
import os
import re
import shutil
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List

import fitz
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapters.associations import associate_documents, identify_document, identify_document_from_text
from adapters.companion_segments import (extract_examiner_report_notes, extract_insert_sources,
                                       segment_examiner_report, segment_insert_sources,
                                       segment_mark_scheme)
from adapters.nonib_topics import classify_segments
from adapters.ocr_fallback import build_ocr_context
from adapters.output_contracts import validate_rendered_webps, validate_segments
from adapters.pack_assembler import assemble_all_packs
from adapters.registry import get_adapter
from adapters.render_cache import CACHE_FILENAME, RenderCache, encoder_tag, segment_key
from adapters.segment_geometry import (TARGET_WIDTH, WEBP_LOSSLESS_METHOD, exact_scale_for_segment,
                                       measure_top_band, measurement_for, release_memory,
                                       render_segment_tiles, save_rendered_segments)
from adapters.source_mapping import link_sources_to_questions
from tools.crop_noncaie_segments import build_context
from tools.noncaie_source_manifest import build_manifest as build_source_manifest

SUPPORTED_BATCH_BOARDS = {"AQA", "EDEXCEL"}
PENDING_VALIDATION_BOARDS = {"IB"}


def _safe_name(path: Path) -> str:
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in path.stem)[:120]


def _pdfs(input_dir: Path) -> List[Path]:
    seen = {}
    for pat in ("*.pdf", "*.PDF"):
        for p in input_dir.rglob(pat):
            seen[str(p.resolve())] = p
    return sorted(seen.values(), key=lambda p: str(p).lower())


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _has_usable_text_layer(path: Path, min_chars: int = 80) -> bool:
    try:
        with fitz.open(path) as doc:
            chars = 0
            for i in range(min(3, len(doc))):
                chars += len((doc[i].get_text("text") or "").strip())
                if chars >= min_chars:
                    return True
            return chars >= min_chars
    except Exception:
        return False


def _component_dir_name(value: str) -> str:
    value = value or "UNKNOWN"
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in value)[:80] or "UNKNOWN"


def _session_dir_name(season: str, year: str) -> str:
    return f"{season or 'UNKNOWN'}_{year or 'UNKNOWN'}"


def _canonical_file_id(ident, qn: int, suffix: str = "") -> str:
    component = _component_dir_name(getattr(ident, "component", "UNKNOWN"))
    season = getattr(ident, "season", "UNKNOWN") or "UNKNOWN"
    year = getattr(ident, "year", "UNKNOWN") or "UNKNOWN"
    stem = f"{component}_{season}_{year}_Q{qn}"
    return stem + suffix


#: Encoder settings tag for the crop cache; must match how save_rendered_segments writes.
CROP_ENCODER_TAG = encoder_tag(lossless=True, quality=95, method=WEBP_LOSSLESS_METHOD)


def _render_crops(pdf: Path, segments: List[Dict[str, Any]], dest: Path, *, pdf_sha256: str = "",
                  use_cache: bool = True, measurements: Dict[str, dict] | None = None,
                  counters: Dict[str, int] | None = None) -> List[Path]:
    """Render ``segments`` into ``dest``, reusing a recorded crop when nothing changed.

    The cache (adapters/render_cache.py) is keyed on the PDF's SHA-256, the segment's page
    rectangles, the effective scale, the target width and the encoder settings, so a hit is a
    crop the current code would have produced byte-for-byte. A miss renders through the locked
    geometry path and records the result. ``use_cache=False`` (``--no-cache``) bypasses lookups
    and writes.
    """

    if measurements is None:
        measurements = {}
    cache = None
    if use_cache and pdf_sha256 and segments:
        cache = RenderCache.load(dest / CACHE_FILENAME, pdf_sha256=pdf_sha256, encoder=CROP_ENCODER_TAG)
    written: List[Path] = []
    for seg in segments:
        scale = exact_scale_for_segment(seg)
        key = ""
        if cache is not None:
            key = segment_key(pdf_sha256, seg, scale=scale, target_width=TARGET_WIDTH, encoder=CROP_ENCODER_TAG)
            hit = cache.get(key)
            if hit:
                for record in hit:
                    path = dest / str(record["file"])
                    measurements[str(path)] = {field: record[field]
                                               for field in ("width", "height", "top_band", "top_band_ink")}
                    written.append(path)
                continue
        rendered = render_segment_tiles(pdf, seg, scale=scale,
                                        snap_width=TARGET_WIDTH if scale is not None else None)
        paths = save_rendered_segments(rendered, dest, measurements=measurements, method=WEBP_LOSSLESS_METHOD)
        written.extend(paths)
        if cache is not None:
            cache.put(key, [{"file": p.name, **measurement_for(measurements, p)} for p in paths])
        del rendered
        release_memory()
    if cache is not None:
        cache.save()
        if counters is not None:
            counters["cache_hits"] = counters.get("cache_hits", 0) + cache.hits
            counters["cache_misses"] = counters.get("cache_misses", 0) + cache.misses
    return written


def _render_qp(pdf: Path, ident, out_dir: Path, limit: int = 0, ctx=None, source_notes=None,
               pdf_sha256: str = "", use_cache: bool = True,
               ms_pdf: Path | None = None) -> Dict[str, Any]:
    board = ident.board
    adapter = get_adapter(board)
    if adapter is None:
        return {"status": "REVIEW_REQUIRED", "reason": f"no adapter for board {board}"}
    ctx = ctx or build_context(pdf)
    segments = adapter.segment(ctx)
    if limit:
        segments = segments[:limit]
    # Production-style final layout: board/component/session/QP/<source-stem>/
    # (the source-stem level prevents collisions when two official files share
    # the same component/session but differ by qualification tier or edition).
    paper_dir = (out_dir / "final" / board / _component_dir_name(ident.component)
                 / _session_dir_name(ident.season, ident.year) / "QP" / _safe_name(pdf))
    paper_dir.mkdir(parents=True, exist_ok=True)
    _write_json(paper_dir / "segments.json", segments)

    measurements: List[dict] = []
    measured: Dict[str, dict] = {}
    counters: Dict[str, int] = {}
    renderable: List[Dict[str, Any]] = []
    for seg in segments:
        if seg.get("metadata", {}).get("text_only") or not seg.get("pages"):
            continue
        seg = dict(seg)
        seg["id"] = _canonical_file_id(ident, int(seg.get("question_number", 0) or 0))
        renderable.append(seg)
    written = _render_crops(pdf, renderable, paper_dir, pdf_sha256=pdf_sha256,
                            use_cache=use_cache, measurements=measured, counters=counters)
    for path in written:
        m = measurement_for(measured, path)
        measurements.append({"file": path.name, "width": m["width"], "height": m["height"], "top_band": m["top_band"]})
    _write_json(paper_dir / "measurements.json", measurements)
    if board == "AQA":
        # AQA-to-CAIE depth (2026-09-23): AQA questions are classified by the Cambridge
        # TopicClassifier over the subject's profile in subjects_aqa/ (adapters/aqa/classification.py);
        # adapters.nonib_topics is the recorded fallback for a spec code without a profile.
        from adapters.aqa.classification import classify_segments as _aqa_classify
        topics = _aqa_classify(ctx, segments, str(getattr(ident, "component", "") or ""),
                               year=str(getattr(ident, "year", "") or ""), season=str(getattr(ident, "season", "") or ""))
    else:
        topics = classify_segments(board, ctx, segments, component=getattr(ident, "component", None))
    # AQA's own column (2026-09-29, lever 1): the mark scheme prints the specification node
    # carrying each question's marks. That is the board's own statement, so it is held
    # against the classifier here -- agree is recorded, an unambiguous node the classifier
    # did not name carries the routing, and a tie the classifier did not land in is flagged
    # for review with both topics kept. Non-AQA boards and unreadable papers claim nothing.
    spec_ref: Dict[str, int] = {}
    if board == "AQA" and ms_pdf is not None:
        from adapters.aqa.spec_refs import annotate_topics                       # noqa: PLC0415
        spec_ref = annotate_topics(topics, qp_pdf=pdf, ms_pdf=Path(ms_pdf),
                                   component=str(getattr(ident, "component", "") or ""))
    conflicts = [f"Q{t.get('question_number')} classifier={t.get('classifier_topic')} "
                 f"board={(t.get('spec_ref') or {}).get('topic')}"
                 for t in topics if t.get("spec_ref_status") == "disagree"]
    _write_json(paper_dir / "topic_hints.json", topics)
    source_links = link_sources_to_questions(ctx, segments, source_notes or [])
    if source_links:
        _write_json(paper_dir / "source_links.json", source_links)

    issues = validate_segments(board, segments) + validate_rendered_webps(written, measured)
    status = "PASS" if not any(i.level == "ERROR" for i in issues) else "FAIL"
    result = {
        "status": status,
        "cache_hits": counters.get("cache_hits", 0),
        "cache_misses": counters.get("cache_misses", 0),
        "board": board,
        "pdf": str(pdf),
        "output_dir": str(paper_dir),
        "segments": len(segments),
        "rendered": len(written),
        "all_width_2280_top_band_20": bool(written) and all(m["width"] == 2280 and m["top_band"] == 20 for m in measurements),
        "measurements": measurements,
        "topics": topics,
        "source_links": source_links,
        "topic_hints": sum(1 for t in topics if t.get("status") == "HINT"),
        "spec_ref_checked": spec_ref.get("checked", 0),
        "spec_ref_agree": spec_ref.get("agree", 0),
        "spec_ref_adopted": spec_ref.get("adopted", 0),
        "spec_ref_conflicts": conflicts,
        "contract_issues": [asdict(i) for i in issues],
    }
    _write_json(paper_dir / "contract_report.json", {
        "contract_version": 1,
        "board": board,
        "status": status,
        "issues": result["contract_issues"],
    })
    return result


def _mark_scheme_segments(ctx, board: str) -> List[Dict[str, Any]]:
    """Split a mark scheme with the BOARD ADAPTER when it owns a validated splitter.

    2026-09-23 (Biology 8461 finish): `_render_mark_scheme` used to call the generic
    ``adapters.companion_segments.segment_mark_scheme`` unconditionally, so the
    companion bundle's MS crops were produced by a different splitter than the one the
    board's own tests and ``adapters/ms_dispatch.py`` validate. On AQA that was a real
    defect, not a cosmetic one: the generic splitter anchors on visible ``Question N``
    headings, which an AQA sub-part table MS does not have, so it fell back to
    page-spanning regions and shipped crops with 500-2600 px of blank paper between
    the header and the table (measured on 8461/1H and 8462/1H June 2023). The adapter
    (``adapters/aqa/adapter.py::segment_mark_scheme``) keys off the sub-part table
    itself and is what ``tests/test_aqa_fix_round_geometry.py`` and
    ``tests/test_aqa_biology_8461.py`` pin.

    Policy is identical to ``adapters/ms_dispatch.py``: an adapter that declares
    ``segments_mark_scheme()`` is authoritative; anything else (no adapter, no
    declaration, an exception, or 0 segments) falls back to the generic splitter
    rather than leaving the mark scheme uncropped. Never returns a partial set
    silently -- the fallback is all-or-nothing per document.
    """
    adapter = get_adapter(board) if board else None
    if adapter is not None and getattr(adapter, "segments_mark_scheme", lambda: False)():
        try:
            segments = list(adapter.segment_mark_scheme(ctx) or [])
        except Exception:
            segments = []
        if segments:
            return segments
    return segment_mark_scheme(ctx, board)


def _render_mark_scheme(pdf: Path, ident, out_dir: Path, limit: int = 0,
                        pdf_sha256: str = "", use_cache: bool = True) -> Dict[str, Any]:
    ctx = build_context(pdf)
    segments = _mark_scheme_segments(ctx, getattr(ident, "board", ""))
    if limit:
        segments = segments[:limit]
    ms_dir = (out_dir / "final" / ident.board / _component_dir_name(ident.component)
              / _session_dir_name(ident.season, ident.year) / "MS" / _safe_name(pdf))
    ms_dir.mkdir(parents=True, exist_ok=True)
    _write_json(ms_dir / "segments.json", segments)
    measurements: List[dict] = []
    measured: Dict[str, dict] = {}
    counters: Dict[str, int] = {}
    renderable: List[Dict[str, Any]] = []
    for seg in segments:
        if not seg.get("pages"):
            continue
        seg = dict(seg)
        seg["id"] = _canonical_file_id(ident, int(seg.get("question_number", 0) or 0), "_MS")
        renderable.append(seg)
    # render_segment_tiles, not render_segment: a segment whose source region is more
    # than ~7.2x taller than it is wide cannot be one 2280 px WEBP (see
    # adapters/segment_geometry.render_segment_tiles) and ships as ordered tiles.
    written = _render_crops(pdf, renderable, ms_dir, pdf_sha256=pdf_sha256,
                            use_cache=use_cache, measurements=measured, counters=counters)
    for path in written:
        m = measurement_for(measured, path)
        measurements.append({"file": path.name, "width": m["width"], "height": m["height"], "top_band": m["top_band"]})
    _write_json(ms_dir / "measurements.json", measurements)
    issues = validate_rendered_webps(written, measured)
    status = "PASS" if segments and not any(i.level == "ERROR" for i in issues) else "REVIEW_REQUIRED"
    result = {
        "status": status,
        "cache_hits": counters.get("cache_hits", 0),
        "cache_misses": counters.get("cache_misses", 0),
        "board": ident.board,
        "pdf": str(pdf),
        "output_dir": str(ms_dir),
        "document_type": "MS",
        "segments": len(segments),
        "rendered": len(written),
        "all_width_2280_top_band_20": bool(written) and all(m["width"] == 2280 and m["top_band"] == 20 for m in measurements),
        "measurements": measurements,
        "contract_issues": [asdict(i) for i in issues],
    }
    _write_json(ms_dir / "contract_report.json", {"contract_version": 1, "board": ident.board, "status": status, "issues": result["contract_issues"]})
    return result


def _render_companion_crops(pdf: Path, segments: List[Dict[str, Any]], dest: Path,
                            ident, suffix: str, pdf_sha256: str = "",
                            use_cache: bool = True, counters: Dict[str, int] | None = None) -> List[Path]:
    """Render companion segments (ER question sections, insert/source sections) as webp crops.

    Deliberately the same geometry bridge the QP and MS paths use: one 2280 px-wide crop per
    section, tiled by the locked rule when a section is taller than the format allows. A section
    that cannot be rendered is skipped, never faked -- the caller reports the miss.
    """
    dest.mkdir(parents=True, exist_ok=True)
    renderable: List[Dict[str, Any]] = []
    for seg in segments:
        if not seg.get("pages"):
            continue
        seg = dict(seg)
        label = seg.get("label") or seg.get("canonical_question") or f"Q{seg.get('question_number')}"
        stem = "".join(c if c.isalnum() or c in "._-" else "_" for c in str(label))[:60] or "section"
        if suffix == "_ER":
            seg["id"] = _canonical_file_id(ident, int(seg.get("question_number") or 0), suffix)
        else:
            # an insert section is not a question: name it by its label so Q3's "Source B" is findable
            seg["id"] = f"{_safe_name(pdf)}_{stem}{suffix}"
        renderable.append(seg)
    return _render_crops(pdf, renderable, dest, pdf_sha256=pdf_sha256, use_cache=use_cache,
                         counters=counters if counters is not None else {})


def _write_insert_source_index(pdf: Path, ident, out_dir: Path, pdf_sha256: str = "",
                               use_cache: bool = True) -> Dict[str, Any]:
    ctx = build_context(pdf)
    sources = extract_insert_sources(ctx, getattr(ident, "board", ""))
    in_dir = (out_dir / "final" / ident.board / _component_dir_name(ident.component)
              / _session_dir_name(ident.season, ident.year) / "IN" / _safe_name(pdf))
    in_dir.mkdir(parents=True, exist_ok=True)
    # 2026-09-29 (CLS-178f, user rule): no .txt in the output tree unless it is an MCQ mark-scheme
    # sidecar. The insert's text used to be written as one `<label>.txt` per section; the same text
    # is carried by the manifest below (`source_index.json`), which is what anything would read.
    manifest = [asdict(src) for src in sources]
    _write_json(in_dir / "source_index.json", manifest)
    # sweep the sidecars an older version wrote into this document's own folder
    legacy_swept: List[str] = []
    for stale in sorted(in_dir.glob("*.txt")):
        try:
            stale.unlink()
            legacy_swept.append(stale.name)
        except OSError:                                                       # noqa: PERF203
            pass
    # Each labelled section also becomes its own crop, so a question that names "Source B" can carry
    # that section alone (2026-09-28, user request: each question gets its own insert section).
    sections = segment_insert_sources(ctx, getattr(ident, "board", ""))
    counters: Dict[str, int] = {}
    crops = _render_companion_crops(pdf, sections, in_dir / "SECTIONS", ident, "_IN",
                                    pdf_sha256=pdf_sha256, use_cache=use_cache, counters=counters)
    _write_json(in_dir / "insert_sections.json", [
        {"id": seg.get("id"), "label": seg.get("label"), "files": [p.name for p in crops
                                                                   if p.name.startswith(
                                                                       f"{_safe_name(pdf)}_"
                                                                       f"{''.join(c if c.isalnum() or c in '._-' else '_' for c in str(seg.get('label')))[:60]}_IN")],
         "pages": [sp.get("page_index") for sp in seg.get("pages") or []]}
        for seg in sections])
    return {
        "status": "PASS" if sources or crops else "REVIEW_REQUIRED",
        "cache_hits": counters.get("cache_hits", 0),
        "cache_misses": counters.get("cache_misses", 0),
        "board": ident.board,
        "pdf": str(pdf),
        "output_dir": str(in_dir),
        "document_type": "IN",
        "legacy_txt_swept": len(legacy_swept),
        "sources": len(sources),
        "labels": [s.canonical_question for s in sources],
        "section_crops": len(crops),
    }


def _write_examiner_report_notes(pdf: Path, ident, out_dir: Path, pdf_sha256: str = "",
                                 use_cache: bool = True) -> Dict[str, Any]:
    ctx = build_context(pdf)
    notes = extract_examiner_report_notes(ctx, getattr(ident, "board", ""))
    er_dir = (out_dir / "final" / ident.board / _component_dir_name(ident.component)
              / _session_dir_name(ident.season, ident.year) / "ER" / _safe_name(pdf))
    er_dir.mkdir(parents=True, exist_ok=True)
    # 2026-09-29 (CLS-178d, user rule): the examiner report ships as its CROP only -- no
    # per-question `_ER.txt` sidecar. Nothing is lost: the extracted text stays in this manifest,
    # which is also what the pack assembler reads (via _er_claimed_questions) to learn which
    # questions the report actually discusses.
    manifest = [asdict(note) for note in notes]
    _write_json(er_dir / "er_notes.json", manifest)
    # 2026-09-29 (CLS-178e): runs before CLS-178d wrote a `<stem>_Q<n>_ER.txt` beside each crop.
    # The report now ships as its crop only, and a re-run must not leave the older version's
    # sidecars behind looking like current output -- a stale tree re-run in testing kept all four.
    # Exactly the names this pass used to write, in the directory it owns.
    legacy_swept: List[str] = []
    for stale in sorted(er_dir.glob("*_Q*_ER.txt")):
        try:
            stale.unlink()
            legacy_swept.append(stale.name)
        except OSError:                                                       # noqa: PERF203
            pass
    # Per-question visual crops: the report section for Q3 lands as Q3_ER.webp beside the question.
    # The question numbers the report is allowed to claim come from the paper itself when the caller
    # knows them (`known_questions`), which is what stops a stray "Q7" in a summary table becoming a
    # seventh question folder.
    known = [int(n.question_number) for n in notes] or None
    sections = segment_examiner_report(ctx, getattr(ident, "board", ""), known_questions=known)
    counters: Dict[str, int] = {}
    crops = _render_companion_crops(pdf, sections, er_dir / "SECTIONS", ident, "_ER",
                                    pdf_sha256=pdf_sha256, use_cache=use_cache, counters=counters)
    _write_json(er_dir / "er_sections.json", [
        {"id": seg.get("id"), "question_number": seg.get("question_number"),
         "split_kind": (seg.get("metadata") or {}).get("split_kind"),
         "match_confidence": (seg.get("metadata") or {}).get("match_confidence"),
         "files": [p.name for p in crops if p.name == f"{_canonical_file_id(ident, int(seg.get('question_number') or 0), '_ER')}.webp"
                   or p.name.startswith(f"{_canonical_file_id(ident, int(seg.get('question_number') or 0), '_ER')}_part")],
         "pages": [sp.get("page_index") for sp in seg.get("pages") or []]}
        for seg in sections])
    return {
        "status": "PASS" if notes or crops else "REVIEW_REQUIRED",
        "cache_hits": counters.get("cache_hits", 0),
        "cache_misses": counters.get("cache_misses", 0),
        "board": ident.board,
        "pdf": str(pdf),
        "output_dir": str(er_dir),
        "document_type": "ER",
        "legacy_txt_swept": len(legacy_swept),
        "notes": len(notes),
        "questions": [n.question_number for n in notes],
        "section_crops": len(crops),
    }


def _free_mb_psutil() -> float:
    """Available memory in MB via psutil (installed with requirements.txt), or 0.0 if it is absent."""

    try:
        import psutil                                                    # noqa: PLC0415 -- optional
        return float(psutil.virtual_memory().available) / (1024.0 * 1024.0)
    except Exception:                                                    # noqa: BLE001 -- any failure
        return 0.0                                                       # means "try the next reader"


def _free_mb_proc() -> float:
    """Available memory in MB from /proc/meminfo -- Linux only."""

    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                return float(line.split()[1]) / 1024.0
    except (OSError, IndexError, ValueError):
        pass
    return 0.0


def _free_mb_windows() -> float:
    """Available physical memory in MB via GlobalMemoryStatusEx -- Windows only, stdlib only."""

    try:
        import ctypes                                                    # noqa: PLC0415
        if not hasattr(ctypes, "windll"):
            return 0.0

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return float(status.ullAvailPhys) / (1024.0 * 1024.0)
    except Exception:                                                    # noqa: BLE001 -- any failure
        pass
    return 0.0


def _free_mb() -> float:
    """Available memory in MB, from the first reader this platform answers (0.0 if none can).

    This used to read `/proc/meminfo` only, which meant **every Windows run was clamped to one
    worker**: `_free_mb()` returned 0.0, and both `auto_jobs` and `resolve_jobs` read an unknown
    figure as "assume one". psutil is installed by requirements.txt and answers everywhere; the
    /proc and Win32 readers are there for a machine where it is missing.
    """

    for probe in (_free_mb_psutil, _free_mb_proc, _free_mb_windows):
        value = probe()
        if value > 0:
            return value
    return 0.0


def resolve_jobs(requested: int, *, per_worker_mb: int = 0) -> int:
    """Clamp a requested worker count to what this machine can actually hold.

    One document's render owns the PDF raster, the assembled canvas and libwebp's lossless
    scratch at the same time (measured peak 743 MB for the whole 4-PDF demo; the 2 GB container
    was OOM-killed in an earlier full-suite run before ``release_memory`` existed). An explicit
    ``--jobs`` is therefore honoured up to what free RAM supports rather than up to the core
    count -- workers that wait on the encoder are still cheaper than an OOM -- and the RAM
    budget can be overridden with TOPICAL_WORKER_MB when a machine is known better.
    """

    if requested <= 1:
        return 1
    budget = _worker_budget_mb(per_worker_mb)
    free = _free_mb()
    by_ram = max(1, int(free // budget)) if free else 1
    resolved = max(1, min(int(requested), by_ram))
    if resolved < requested:
        print(f"[batch] --jobs {requested} clamped to {resolved}: {free:.0f} MB available, "
              f"{budget} MB per worker (set TOPICAL_WORKER_MB to override)")
    return resolved


def _worker_budget_mb(override: int = 0) -> int:
    if override:
        return int(override)
    #: Measured on the demo set (4 papers, 33 crops): a full *serial* run peaks near 800 MB, so a
    #: single worker needs roughly a quarter of that. The old 1100 MB figure came from the worst paper
    #: seen and had a side effect nobody wanted -- on a 2 GB box with ~1 GB free it clamped every run
    #: to one worker, so `--jobs 0` and even an explicit `--jobs 2` silently ran serially.
    try:
        return int(os.environ.get("TOPICAL_WORKER_MB", "400"))
    except ValueError:
        return 400


def auto_jobs(per_worker_mb: int = 0) -> int:
    """What this machine should run unattended: a core for the UI, and RAM that fits.

    "One core left for the UI" is right on a roomy machine and wrong on a small one: on two cores it
    meant the batch ran serially while the interface sat idle between its own 1 Hz polls, which is
    exactly the "everything is slow" case. So the rule keeps the free core only when there are three
    or more, and a two-core machine uses both -- still clamped by free RAM below.
    """

    cores = os.cpu_count() or 1
    by_cpu = min(cores, max(2, cores - 1))
    free = _free_mb()
    by_ram = max(1, int(free // _worker_budget_mb(per_worker_mb))) if free else 1
    return max(1, min(by_cpu, by_ram))


def _process_document(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Render one document end to end -- the unit of work for ``--jobs`` workers.

    Module level and argument-light so a process pool can run it: the payload carries the
    PDF path, its identity, the output root, the SHA-256 the crop cache keys on, and the
    pre-indexed insert sources a QP needs for explicit source labels.
    """

    pdf = Path(payload["pdf"])
    ident = payload["ident"]
    output_dir = Path(payload["output_dir"])
    sha = payload.get("pdf_sha256") or ""
    use_cache = bool(payload.get("use_cache", True))
    kind = ident.document_type
    if kind == "QP":
        result = _render_qp(pdf, ident, output_dir, limit=payload.get("limit", 0), ctx=payload.get("ctx"),
                            source_notes=payload.get("source_notes") or [], pdf_sha256=sha,
                            use_cache=use_cache, ms_pdf=payload.get("ms_pdf"))
        return {"kind": "render", "result": result}
    if kind == "MS":
        result = _render_mark_scheme(pdf, ident, output_dir, limit=payload.get("limit", 0),
                                     pdf_sha256=sha, use_cache=use_cache)
        return {"kind": "companion", "result": result, "review_reason": "MS question-level split not verified"}
    if kind == "ER":
        result = _write_examiner_report_notes(pdf, ident, output_dir, pdf_sha256=sha, use_cache=use_cache)
        return {"kind": "companion", "result": result, "review_reason": "ER question-level notes not verified"}
    if kind == "IN":
        result = _write_insert_source_index(pdf, ident, output_dir, pdf_sha256=sha, use_cache=use_cache)
        return {"kind": "companion", "result": result, "review_reason": "insert/source labels not verified"}
    return {"kind": kind, "result": None}


#: Severity labels for review entries and diagnostics (2026-09-29). The audit used to record one
#: flat "review" list, so "Tesseract is not installed" (an expected limitation of a test container)
#: sat beside "this board is unsupported" (an input problem) and a stale directory left by an
#: earlier run (housekeeping). Each entry now carries a ``severity`` beside its existing
#: status/reason, and the labels mean:
#:
#: * ``ERROR``                 -- something a caller has to fix: a render or contract failure.
#: * ``INPUT_CLASSIFICATION``  -- a document that was not routed (unknown board, indexed only).
#: * ``EXPECTED_LIMITATION``   -- a capability this environment does not have (no OCR engine, a
#:                               board deliberately excluded by a flag).
#: * ``STALE_ARTIFACT``        -- output left by an earlier run that could confuse packing.
SEVERITY_ERROR = "ERROR"
SEVERITY_INPUT = "INPUT_CLASSIFICATION"
SEVERITY_LIMITATION = "EXPECTED_LIMITATION"
SEVERITY_STALE = "STALE_ARTIFACT"


def _stale_qp_dirs(output_dir: Path) -> List[Path]:
    """QP document directories in the output tree that hold no question crops of their own.

    These are the leftovers that made a good paper ship zero packs (see ``_qp_doc_has_question_crops``):
    a run that classified a document differently, or a render that produced nothing, leaves a
    directory under ``QP/`` behind, and the pack assembler then sees two "question papers" in one
    session. Detection is read-only and reported; ``--prune-stale-dirs`` removes exactly these
    directories, and only these -- a directory holding even one question crop is never touched.
    """

    final_root = Path(output_dir) / "final"
    stale: List[Path] = []
    if not final_root.is_dir():
        return stale
    for qp_root in sorted(final_root.glob("*/*/*/QP")):
        if not qp_root.is_dir():
            continue
        for doc_dir in sorted(qp_root.iterdir()):
            if doc_dir.is_dir() and not _qp_doc_has_question_crops(doc_dir):
                stale.append(doc_dir)
    return stale


def prune_stale_dirs(output_dir: Path) -> Dict[str, Any]:
    """Remove QP directories that hold no question crops. Returns what was removed (and failures)."""

    removed: List[str] = []
    failed: List[Dict[str, str]] = []
    for path in _stale_qp_dirs(output_dir):
        try:
            shutil.rmtree(path)
            removed.append(str(path))
        except OSError as exc:
            failed.append({"path": str(path), "error": str(exc)})
    return {"removed": removed, "failed": failed}


def preflight(input_dir: Path, output_dir: Path, pdfs: List[Path]) -> Dict[str, Any]:
    """Check the run's preconditions before any paper is processed, and report every result.

    Written after a stretch where a mis-shaped fixture and a stale output directory each cost a full
    batch before anyone knew why. The checks are deliberately cheap and environment-level; a FATAL
    one (no papers, an unwritable output tree) stops the run with an exit code instead of producing
    an empty audit that looks like success. Everything else is reported and the run continues.
    """

    checks: List[Dict[str, Any]] = []

    def record(name: str, ok: bool, detail: str, *, fatal: bool = False) -> None:
        checks.append({"check": name, "ok": bool(ok), "detail": detail, "fatal": bool(fatal)})

    record("input_dir", input_dir.is_dir(), str(input_dir), fatal=True)
    record("papers", bool(pdfs), f"{len(pdfs)} PDF(s)", fatal=True)
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        probe = output_dir / ".write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        record("output_writable", True, str(output_dir), fatal=True)
    except OSError as exc:
        record("output_writable", False, f"{output_dir}: {exc}", fatal=True)
    missing_modules = [name for name in ("fitz", "PIL", "numpy")
                       if importlib.util.find_spec(name) is None]
    record("renderer_modules", not missing_modules,
           "fitz, PIL, numpy present" if not missing_modules else f"missing: {', '.join(missing_modules)}",
           fatal=True)
    try:
        import tempfile as _tempfile
        staging = Path(_tempfile.mkdtemp(prefix="preflight_", dir=str(output_dir)))
        staging.rmdir()
        record("staging_writable", True, str(output_dir))
    except OSError as exc:
        record("staging_writable", False, f"{output_dir}: {exc}")
    stale = _stale_qp_dirs(output_dir)
    record("no_stale_session_artifacts", not stale,
           "clean" if not stale else f"{len(stale)} stale QP directory(ies): "
                                     + ", ".join(p.name for p in stale[:4]))

    fatal = [c for c in checks if c["fatal"] and not c["ok"]]
    for check in checks:
        mark = "ok" if check["ok"] else ("FAIL" if check["fatal"] else "warn")
        print(f"[PRECHECK] {mark:4s} {check['check']}: {check['detail']}")
    return {"checks": checks, "ok": not fatal, "stale_dirs": [str(p) for p in stale],
            "failures": [c["check"] for c in fatal]}


def run_batch(input_dir: Path, output_dir: Path, include_sat: bool = True, include_ib: bool = True,
              limit_per_paper: int = 0, enable_ocr: bool = False, only_paths: Iterable[Path] | None = None,
              jobs: int = 1, use_cache: bool = True, prune_stale: bool = False) -> Dict[str, Any]:
    import time as _time

    started_at = _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())
    started_clock = _time.perf_counter()
    run_id = f"run-{_time.strftime('%Y%m%d-%H%M%S', _time.gmtime())}-{os.getpid()}"
    pdfs = _pdfs(input_dir)
    scoped = pdfs
    if only_paths is not None:
        # 2026-09-21 (guarded board path): the guarded runner hands a board-scoped
        # context over one subject at a time. Restricting the pass to exactly
        # those files keeps a mixed CAIE + non-CAIE input directory from being
        # processed twice (CAIE papers belong to run_guarded's own S2-S5).
        _want = {Path(p).resolve() for p in only_paths}
        scoped = [p for p in pdfs if p.resolve() in _want]
    # Preflight judges the INPUT DIRECTORY, never the caller's scope (2026-09-29). A scope restricted
    # to a file that is not there means "process nothing this pass", not "this folder has no papers":
    # filtering first made a scoped no-op indistinguishable from an empty input folder and refused
    # the whole run with a reduced audit that had no render counters. Caught by
    # tests/test_guarded_board_path.py, which scopes to a file that deliberately does not exist.
    report = preflight(input_dir, output_dir, pdfs)
    if prune_stale and report["stale_dirs"]:
        pruned = prune_stale_dirs(output_dir)
        print(f"[PRECHECK] pruned {len(pruned['removed'])} stale QP director(ies)"
              + (f", {len(pruned['failed'])} failed" if pruned["failed"] else ""))
        report["pruned"] = pruned
        report["stale_dirs"] = [p for p in report["stale_dirs"] if p not in pruned["removed"]]
    if not report["ok"]:
        # Fail before processing anything (2026-09-29). An empty audit that looks like a successful
        # run is worse than a refusal: the caller must be able to tell "nothing to do" from "done".
        print(f"[PRECHECK] refusing to run: {', '.join(report['failures'])}")
        audit = {"audit_version": 1, "run_id": run_id, "started": started_at,
                 "status": "PRECHECK_FAILED", "input_dir": str(input_dir), "output_dir": str(output_dir),
                 "preflight": report, "counts": {"pdfs": len(pdfs), "question_packs": 0}, "review": []}
        _write_json(output_dir / "universal_batch_audit.json", audit)
        _write_json(output_dir / "run_manifest.json", _run_manifest(run_id, started_at, 0.0, audit))
        return audit
    pdfs = scoped                       # preflights passed: process exactly the caller's scope
    output_dir.mkdir(parents=True, exist_ok=True)

    identities = []
    render_results = []
    companion_results = []
    review = []
    records = []

    # First pass: identity, optional OCR context, and fail-closed board gates.
    for pdf in pdfs:
        ctx = None
        used_ocr = False
        if not _has_usable_text_layer(pdf):
            if not enable_ocr:
                review.append({"path": str(pdf), "status": "REVIEW_REQUIRED", "severity": SEVERITY_LIMITATION,
                               "reason": "OCR_REQUIRED: no usable PDF text layer detected; rerun with --enable-ocr if OCR dependencies are installed"})
                continue
            ocr = build_ocr_context(pdf)
            if not ocr.available or ocr.ctx is None:
                review.append({"path": str(pdf), "status": "REVIEW_REQUIRED", "severity": SEVERITY_LIMITATION,
                               "reason": f"OCR_REQUIRED: {ocr.reason}"})
                continue
            ctx = ocr.ctx
            used_ocr = True
            ident = identify_document_from_text(pdf, ctx.first_page_text + "\n" + ctx.full_text, sha256=ctx.sha256)
        else:
            ident = identify_document(pdf)
        ident_dict = asdict(ident) | {"ocr_used": used_ocr}
        identities.append(ident_dict)
        if ident.board == "SAT" and not include_sat:
            review.append({"path": str(pdf), "status": "SKIPPED", "severity": SEVERITY_LIMITATION,
                           "reason": "SAT excluded by default"})
            continue
        if ident.board == "IB" and not include_ib:
            review.append({"path": str(pdf), "status": "SKIPPED", "severity": SEVERITY_LIMITATION,
                           "reason": "IB excluded for this run (--no-include-ib)"})
            continue
        allowed = ident.board in SUPPORTED_BATCH_BOARDS or (include_sat and ident.board == "SAT") or (include_ib and ident.board == "IB")
        if not allowed:
            # A recognised CAIE document is not an error, it is the wrong door: Cambridge papers
            # run through their own pipeline (main.py / the app's CAIE route, which detects and
            # attaches examiner reports). Saying so beats a bare "unsupported board", which reads
            # like the file was broken. Measured 2026-09-29: the old bare reason is what a CAIE
            # folder pointed at this tool used to produce -- when it was not silently filed as
            # AQA by the board heuristic instead.
            reason = (f"CAIE document — the Cambridge pipeline handles this paper "
                      f"(app option 1 / main.py); the universal router is non-CAIE by design"
                      if ident.board == "CAIE"
                      else f"unsupported_or_unknown_board={ident.board}")
            review.append({"path": str(pdf), "status": "REVIEW_REQUIRED", "severity": SEVERITY_INPUT,
                           "reason": reason})
            continue
        records.append({"pdf": pdf, "ident": ident, "ctx": ctx, "ocr_used": used_ocr})

    # Pre-index inserts/sources so QP rendering can attach explicit labels even
    # when the insert file sorts after the question paper.
    sources_by_key = {}
    for rec in records:
        ident = rec["ident"]
        if ident.document_type != "IN":
            continue
        ctx = rec["ctx"] or build_context(rec["pdf"])
        sources_by_key.setdefault(ident.association_key, []).extend(extract_insert_sources(ctx, ident.board))

    # The mark scheme of the same paper is an evidence source now (lever 1, 2026-09-29): the
    # AQA cross-check needs it beside the question paper, and association already knows which
    # MS belongs to which QP (same association_key). One MS per key is enough -- a second
    # mark scheme for the same component is a duplicate, not extra evidence.
    ms_by_key: Dict[str, str] = {}
    for rec in records:
        ident = rec["ident"]
        if ident.document_type == "MS" and ident.board == "AQA":
            ms_by_key.setdefault(ident.association_key, str(rec["pdf"]))

    # Second pass: render QPs, MS companions, ER notes, and IN source indexes. One document is
    # one task. --jobs > 1 hands the tasks to a process pool (documents are independent: each
    # owns its PDF, its output directory and its crop cache); OCR documents stay in-process
    # because an OCR context is not picklable, and --jobs 1 keeps today's serial order exactly.
    jobs = resolve_jobs(jobs)
    shas: Dict[Path, str] = {}
    for rec in records:
        pdf = rec["pdf"]
        try:
            shas[pdf] = hashlib.sha256(pdf.read_bytes()).hexdigest()
        except OSError:
            shas[pdf] = ""
    payloads: List[Dict[str, Any]] = []
    for rec in records:
        ident = rec["ident"]
        payloads.append({
            "pdf": str(rec["pdf"]), "ident": ident, "output_dir": str(output_dir),
            "limit": limit_per_paper, "ctx": rec["ctx"],
            "source_notes": list(sources_by_key.get(ident.association_key, [])),
            "pdf_sha256": shas.get(rec["pdf"], ""), "use_cache": use_cache,
            "ms_pdf": ms_by_key.get(ident.association_key),
        })
    in_process = [i for i, rec in enumerate(records) if rec["ctx"] is not None]
    poolable = [i for i, rec in enumerate(records) if rec["ctx"] is None]
    outcomes: Dict[int, Dict[str, Any]] = {}
    if jobs > 1 and len(poolable) > 1:
        from concurrent.futures import ProcessPoolExecutor
        print(f"[batch] rendering {len(poolable)} documents with {jobs} worker process(es)")
        with ProcessPoolExecutor(max_workers=jobs) as pool:
            for index, outcome in zip(poolable, pool.map(_process_document, [payloads[i] for i in poolable])):
                outcomes[index] = outcome
    else:
        for index in poolable:
            outcomes[index] = _process_document(payloads[index])
    for index in in_process:
        outcomes[index] = _process_document(payloads[index])
    cache_hits = cache_misses = 0
    for index, rec in enumerate(records):
        pdf = rec["pdf"]
        outcome = outcomes.get(index) or {"kind": rec["ident"].document_type, "result": None}
        result_counters = outcome.get("result") or {}
        cache_hits += int(result_counters.get("cache_hits", 0) or 0)
        cache_misses += int(result_counters.get("cache_misses", 0) or 0)
        if outcome.get("kind") == "render":
            result = outcome["result"]
            render_results.append(result)
            conflicts = (result or {}).get("spec_ref_conflicts") or []
            if conflicts:
                review.append({"path": str(pdf), "status": "REVIEW_REQUIRED",
                               "severity": SEVERITY_ERROR,
                               "reason": "topic conflicts with the mark scheme's own spec "
                                         "reference(s): " + "; ".join(conflicts)})
        elif outcome.get("kind") == "companion":
            result = outcome["result"]
            companion_results.append(result)
            if result is not None and result.get("status") != "PASS":
                review.append({"path": str(pdf), "status": "REVIEW_REQUIRED", "severity": SEVERITY_ERROR,
                               "reason": outcome.get("review_reason", "companion output not verified")})
        else:
            review.append({"path": str(pdf), "status": "INDEXED_ONLY", "severity": SEVERITY_INPUT,
                           "reason": f"document_type={outcome.get('kind')}"})

    insert_attach = _attach_insert_sections(output_dir)
    associations = associate_documents(pdfs)
    source_manifest = build_source_manifest(input_dir)
    pack_manifest = assemble_all_packs(output_dir, copy_files=True)

    for stale in report["stale_dirs"]:
        review.append({"path": stale, "status": "STALE_ARTIFACT", "severity": SEVERITY_STALE,
                       "reason": "QP directory holds no question crops; it made packing refuse the session "
                                 "in an earlier run. Delete it, or rerun with --prune-stale-dirs."})
    audit = {
        "audit_version": 1,
        "run_id": run_id,
        "started": started_at,
        "input_dir": str(input_dir),
        "output_dir": str(output_dir),
        "preflight": report,
        "counts": {
            "pdfs": len(pdfs),
            "jobs": jobs,
            "cache_hits": cache_hits,
            "cache_misses": cache_misses,
            "restricted_to": (len(pdfs) if only_paths is not None else 0),
            "identities": len(identities),
            "render_attempts": len(render_results),
            "render_pass": sum(1 for r in render_results if r.get("status") == "PASS"),
            "render_fail": sum(1 for r in render_results if r.get("status") == "FAIL"),
            "companion_attempts": len(companion_results),
            "companion_pass": sum(1 for r in companion_results if r.get("status") == "PASS"),
            "companion_review": sum(1 for r in companion_results if r.get("status") != "PASS"),
            "ms_segments": sum(int(r.get("segments", 0) or 0) for r in companion_results if r.get("document_type") == "MS"),
            "er_notes": sum(int(r.get("notes", 0) or 0) for r in companion_results if r.get("document_type") == "ER"),
            "insert_sources": sum(int(r.get("sources", 0) or 0) for r in companion_results if r.get("document_type") == "IN"),
            "insert_section_crops": sum(int(r.get("section_crops", 0) or 0) for r in companion_results if r.get("document_type") == "IN"),
            "er_section_crops": sum(int(r.get("section_crops", 0) or 0) for r in companion_results if r.get("document_type") == "ER"),
            # sidecars an older version left behind, removed by this run (CLS-178e)
            "er_legacy_txt_swept": sum(int(r.get("legacy_txt_swept", 0) or 0) for r in companion_results if r.get("document_type") == "ER"),
            "insert_legacy_txt_swept": sum(int(r.get("legacy_txt_swept", 0) or 0) for r in companion_results if r.get("document_type") == "IN"),
            "insert_attached": insert_attach.get("attached", 0),
            "er_attached": insert_attach.get("er_attached", 0),
            "spec_ref_checked": sum(int(r.get("spec_ref_checked", 0) or 0) for r in render_results),
            "spec_ref_agree": sum(int(r.get("spec_ref_agree", 0) or 0) for r in render_results),
            "spec_ref_adopted": sum(int(r.get("spec_ref_adopted", 0) or 0) for r in render_results),
            "spec_ref_conflicts": sum(len(r.get("spec_ref_conflicts") or []) for r in render_results),
            "review_items": len(review),
            "indexed_only": sum(1 for item in review if item.get("status") == "INDEXED_ONLY"),
            "review_required": sum(1 for item in review if item.get("status") == "REVIEW_REQUIRED"),
            "skipped": sum(1 for item in review if item.get("status") == "SKIPPED"),
            "ib_pending": sum(1 for item in review if "IB pending" in item.get("reason", "")),
            "ocr_required": sum(1 for item in review if "OCR_REQUIRED" in item.get("reason", "")),
            "text_layer_checked": len(pdfs),
            "question_packs": int(pack_manifest.get("packs", 0) or 0),
            "pack_review_items": len(pack_manifest.get("review_items", []) or []),
            "pack_strays_removed": len(pack_manifest.get("strays_removed", []) or []),
            "stale_artifacts": sum(1 for item in review if item.get("severity") == SEVERITY_STALE),
            "expected_limitations": sum(1 for item in review if item.get("severity") == SEVERITY_LIMITATION),
        },
        "identities": identities,
        "associations": associations,
        "source_manifest": source_manifest,
        "pack_manifest": pack_manifest,
        "render_results": render_results,
        "companion_results": companion_results,
        "companion_attachments": insert_attach,
        "review": review,
    }
    _write_json(output_dir / "universal_batch_audit.json", audit)
    _write_json(output_dir / "association_manifest.json", {"manifest_version": 1, "groups": associations})
    _write_json(output_dir / "source_manifest.json", source_manifest)
    _write_report(output_dir / "UNIVERSAL_BATCH_AUDIT.md", audit)
    audit["status"] = ("PASS" if not any(r.get("status") == "FAIL" for r in render_results)
                       else "FAIL")
    audit["seconds"] = round(_time.perf_counter() - started_clock, 2)
    _write_json(output_dir / "run_manifest.json", _run_manifest(run_id, started_at, audit["seconds"], audit))
    _write_json(output_dir / "universal_batch_audit.json", audit)
    return audit


def _run_manifest(run_id: str, started: str, seconds: float, audit: Dict[str, Any]) -> Dict[str, Any]:
    """One small file that answers *what was this run processing?* without reading the whole tree.

    The audit already carries every document, measurement and verdict, but it is large and shaped
    for verification. This is the read-me-first record: identity, timing, the boards and papers that
    were seen, the counters that matter, and where the output went.
    """

    counts = audit.get("counts") or {}
    identities = audit.get("identities") or []
    boards = sorted({str(item.get("board")) for item in identities if item.get("board")})
    return {
        "manifest_version": 1,
        "run_id": run_id,
        "started": started,
        "finished": _utc_now(),
        "seconds": seconds,
        "status": audit.get("status", "UNKNOWN"),
        "input_dir": audit.get("input_dir"),
        "output_dir": audit.get("output_dir"),
        "boards": boards,
        "papers": [{"path": item.get("path"), "board": item.get("board"),
                    "document_type": item.get("document_type"), "component": item.get("component"),
                    "season": item.get("season"), "year": item.get("year")} for item in identities],
        "counters": {key: counts.get(key) for key in
                     ("pdfs", "question_packs", "render_pass", "render_fail", "ms_segments",
                      "er_notes", "insert_sources", "insert_attached", "er_attached", "er_legacy_txt_swept",
                      "insert_legacy_txt_swept",
                      "pack_strays_removed",
                      "cache_hits", "cache_misses", "jobs", "stale_artifacts",
                      "expected_limitations", "review_items")},
        "preflight_ok": bool((audit.get("preflight") or {}).get("ok")),
    }


def _utc_now() -> str:
    import time as _time
    return _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())


def _qp_doc_has_question_crops(doc_dir: Path) -> bool:
    """True when this QP document directory holds at least one rendered question crop.

    The attach pass below only knows the output tree, not the identities behind it, and it used to
    write ``Q{n}_IN.webp`` / ``Q{n}_ER.webp`` into *every* directory under ``QP/``. A directory left
    behind by an earlier run (a document that has since been re-identified, or a render that
    produced nothing) therefore collected companion files, and the pack assembler then refused the
    whole session with MULTIPLE_QP_DOCUMENTS_IN_SESSION -- 0 packs from a perfectly good QP.
    A document directory with no question crops of its own has nothing to attach to.
    """

    if not doc_dir.is_dir():
        return False
    return any(path.suffix.lower() == ".webp" and "_Q" in path.name for path in doc_dir.iterdir())


def _attach_insert_sections(output_dir: Path) -> Dict[str, Any]:
    """Give every question the insert section its own text names, and its ER section.

    * **Insert** — a question paper's own text says "Source B", and the QP renderer already recorded
      which question mentioned which label (`source_links.json`). Those links are turned into files:
      the named section's crop is copied into the question's QP folder as ``Q{n}_IN.webp`` (several
      sections stitch vertically, exactly like the Cambridge insert engine does).
    * **Examiner report** — the report's per-question crops already sit beside each other in the
      session's ``ER/SECTIONS`` folder, named ``{component}_{season}_{year}_Q{n}_ER.webp``. This pass
      copies each question's own crop next to that question's QP folder as ``Q{n}_ER.webp``, so the
      pack assembler can file it with the pack.

    Nothing is guessed: a question with no recorded source link, or a question the report never
    addressed, gets no file -- the miss is counted and reported instead.
    """
    root = Path(output_dir)
    stats: Dict[str, Any] = {"attached": 0, "er_attached": 0, "questions_with_sources": 0,
                             "misses": [], "sessions": 0}
    final_root = root / "final"
    if not final_root.is_dir():
        return stats
    for session_dir in sorted(final_root.glob("*/*/*")):
        if not session_dir.is_dir():
            continue
        stats["sessions"] += 1
        # the crops sit under IN/<document>/SECTIONS and ER/<document>/SECTIONS (the document level
        # keeps two inserts or two reports for the same paper apart), so search the session's IN/ER
        # roots rather than one fixed path
        section_root = session_dir / "IN"
        er_section_root = session_dir / "ER"
        for qp_doc in sorted((session_dir / "QP").iterdir()) if (session_dir / "QP").is_dir() else []:
            if not _qp_doc_has_question_crops(qp_doc):
                continue
            links = _read_json(qp_doc / "source_links.json", []) or []
            for link in links:
                qn = link.get("question_number")
                if qn is None:
                    continue
                wanted = [str((s or {}).get("source", {}).get("canonical_question") or "")
                          for s in link.get("sources", [])]
                files: List[Path] = []
                for label in wanted:
                    if not label:
                        continue
                    stem = "".join(c if c.isalnum() or c in "._-" else "_" for c in label)[:60]
                    if section_root.is_dir():
                        files += sorted(section_root.rglob(f"*_{stem}_IN*.webp"))
                if not files:
                    if wanted:
                        stats["misses"].append({"question": qn, "labels": wanted,
                                                "reason": "no rendered section for these labels"})
                    continue
                stats["questions_with_sources"] += 1
                target = qp_doc / f"Q{int(qn)}_IN.webp"
                _stitch_or_copy(files, target)
                stats["attached"] += 1
        # examiner report sections -> Q{n}_ER.webp in the same per-question folder
        if er_section_root.is_dir():
            by_question: Dict[int, List[Path]] = {}
            for crop in sorted(er_section_root.rglob("*_ER*.webp")):
                m = re.search(r"_Q(\d+)_ER(?:_part\d+)?\.webp$", crop.name)
                if m:
                    by_question.setdefault(int(m.group(1)), []).append(crop)
            for qp_doc in sorted((session_dir / "QP").iterdir()) if (session_dir / "QP").is_dir() else []:
                if not _qp_doc_has_question_crops(qp_doc):
                    continue
                for qn, crops in sorted(by_question.items()):
                    _stitch_or_copy(crops, qp_doc / f"Q{qn}_ER.webp")
                    stats["er_attached"] += 1
    return stats


def _stitch_or_copy(parts: List[Path], target: Path) -> None:
    """One crop -> a copy; several -> stacked vertically at 2280 px wide (the insert-engine rule)."""
    if not parts:
        return
    if len(parts) == 1:
        shutil.copy2(parts[0], target)
        return
    images = [Image.open(p).convert("RGB") for p in parts]
    width = 2280
    gap = 20
    height = sum(max(1, round(im.height * width / im.width)) for im in images) + gap * (len(images) - 1)
    canvas = Image.new("RGB", (width, height), "white")
    y = 0
    for im in images:
        if im.width != width:
            im = im.resize((width, max(1, round(im.height * width / im.width))), Image.LANCZOS)
        canvas.paste(im, (0, y))
        y += im.height + gap
        im.close()
    from adapters.segment_geometry import save_rendered_segments     # noqa: PLC0415 (tiling rule)
    canvas.save(str(target), format="WEBP", quality=95, method=4)
    canvas.close()


def _write_report(path: Path, audit: Dict[str, Any]) -> None:
    lines = [
        "# Universal batch audit",
        "",
        f"Input: `{audit['input_dir']}`",
        f"Output: `{audit['output_dir']}`",
        "",
        "## Counts",
        "",
    ]
    for k, v in audit["counts"].items():
        lines.append(f"- {k}: {v}")
    lines += ["", "## Render results", ""]
    if not audit["render_results"]:
        lines.append("No renderable QPs were routed.")
    for r in audit["render_results"]:
        lines.append(f"- **{r.get('status')}** `{r.get('pdf')}` — board={r.get('board')}, segments={r.get('segments')}, rendered={r.get('rendered')}, width/top-band={r.get('all_width_2280_top_band_20')}")
        for issue in r.get("contract_issues", []):
            lines.append(f"  - {issue['level']}: {issue['segment_id']}: {issue['message']}")
    lines += ["", "## Companion results", ""]
    if not audit.get("companion_results"):
        lines.append("No MS/ER companions were rendered or extracted.")
    for r in audit.get("companion_results", []):
        if r.get("document_type") == "MS":
            lines.append(f"- **{r.get('status')}** `{r.get('pdf')}` — MS segments={r.get('segments')}, rendered={r.get('rendered')}, width/top-band={r.get('all_width_2280_top_band_20')}")
        elif r.get("document_type") == "ER":
            lines.append(f"- **{r.get('status')}** `{r.get('pdf')}` — ER notes={r.get('notes')}, questions={r.get('questions')}")
        elif r.get("document_type") == "IN":
            lines.append(f"- **{r.get('status')}** `{r.get('pdf')}` — insert/source labels={r.get('sources')}, labels={r.get('labels')}")
    lines += ["", "## Question packs", ""]
    pm = audit.get("pack_manifest", {})
    lines.append(f"- sessions: {pm.get('sessions', 0)}")
    lines.append(f"- packs: {pm.get('packs', 0)}")
    lines.append(f"- pack review items: {len(pm.get('review_items', []) or [])}")
    lines += ["", "## Review / indexed-only", ""]
    for item in audit["review"]:
        lines.append(f"- `{item['path']}` — {item['status']}: {item['reason']}")
    lines += ["", "## Association groups", ""]
    for key, group in sorted(audit["associations"].items()):
        docs = ", ".join(f"{k}:{len(v)}" for k, v in sorted(group.get("documents", {}).items()))
        lines.append(f"- `{key}` — {docs or 'no docs'}; review_required={group.get('review_required')}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv: List[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    # Both default to the folder that sits beside this script (2026-09-28): the script already has an
    # input/ and an output/ tree, so "scan input, write output" needs no arguments at all. The flags
    # stay for anyone pointing the run at another folder.
    _root = Path(__file__).resolve().parents[1]
    ap.add_argument("--input", default=str(_root / "input"),
                    help="Directory containing PDFs (default: the input/ folder beside the script)")
    ap.add_argument("--output", default=str(_root / "output"),
                    help="Workspace output directory (default: the output/ folder beside the script)")
    ap.add_argument("--include-sat", dest="include_sat", action="store_true", default=True,
                    help="Process SAT papers (DEFAULT ON; --no-include-sat skips them)")
    ap.add_argument("--no-include-sat", dest="include_sat", action="store_false",
                    help="Skip SAT papers in this run")
    ap.add_argument("--include-ib", dest="include_ib", action="store_true", default=True,
                    help="Process IB papers (DEFAULT ON; --no-include-ib skips them)")
    ap.add_argument("--no-include-ib", dest="include_ib", action="store_false",
                    help="Skip IB papers in this run")
    ap.add_argument("--limit-per-paper", type=int, default=0, help="Debug/proof limiter; 0 means all segments")
    ap.add_argument("--enable-ocr", action="store_true", help="Attempt optional Tesseract OCR for image-only PDFs; otherwise OCR_REQUIRED review")
    ap.add_argument("--jobs", type=int, default=1,
                    help="Documents to render at once (default 1; 0 picks automatically: one core left for the "
                         "caller and free RAM / ~1.1 GB per worker). One worker process per document, so the count "
                         "is clamped to what the machine can hold; TOPICAL_WORKER_MB overrides the per-worker RAM "
                         "budget. OCR documents always run in the main process.")
    ap.add_argument("--no-cache", dest="use_cache", action="store_false", default=True,
                    help="Ignore and do not write the per-document crop cache; every crop is rendered again")
    ap.add_argument("--prune-stale-dirs", dest="prune_stale", action="store_true",
                    help="Remove QP output directories that hold no question crops (leftovers from an "
                         "earlier run that would otherwise make packing refuse the session). Only "
                         "directories with zero question crops are removed.")
    args = ap.parse_args(argv)
    jobs = auto_jobs() if args.jobs == 0 else args.jobs
    audit = run_batch(Path(args.input), Path(args.output), include_sat=args.include_sat, include_ib=args.include_ib,
                      limit_per_paper=args.limit_per_paper, enable_ocr=args.enable_ocr,
                      jobs=jobs, use_cache=args.use_cache, prune_stale=args.prune_stale)
    print(json.dumps(audit["counts"], indent=2, sort_keys=True))
    if audit.get("status") == "PRECHECK_FAILED":
        return 2
    return 0 if audit["counts"]["render_fail"] == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
