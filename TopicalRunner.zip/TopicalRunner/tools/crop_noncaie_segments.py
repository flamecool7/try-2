#!/usr/bin/env python3
"""Crop real non-CAIE papers through board adapters + gold geometry bridge.

This is a verification utility, not a replacement pipeline. It prepares a
DocumentContext once, lets the selected adapter detect board-specific segment
boundaries, then renders those rectangles via adapters.segment_geometry.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import fitz
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapters.base import DocumentContext
from adapters.registry import get_adapter
from adapters.segment_geometry import measure_top_band, render_segments, save_rendered_segments


def build_context(pdf_path: Path) -> DocumentContext:
    h = __import__("hashlib").sha256(pdf_path.read_bytes()).hexdigest()
    pages = []
    full_parts = []
    first = ""
    with fitz.open(str(pdf_path)) as doc:
        for idx, page in enumerate(doc):
            text = page.get_text("text") or ""
            if idx == 0:
                first = text
            full_parts.append(text)
            lines = []
            raw = page.get_text("dict")
            for block in raw.get("blocks", []):
                for line in block.get("lines", []) or []:
                    spans = line.get("spans", []) or []
                    s = "".join(span.get("text", "") for span in spans).strip()
                    if not s:
                        continue
                    bbox = list(line.get("bbox", block.get("bbox", [0, 0, 0, 0])))
                    lines.append({"text": s, "bbox": bbox})
            pages.append({"page_index": idx, "size": [float(page.rect.width), float(page.rect.height)], "text": text, "lines": lines})
    return DocumentContext(
        path=str(pdf_path), filename=pdf_path.name, stem=pdf_path.stem, suffix=pdf_path.suffix,
        size_bytes=pdf_path.stat().st_size, sha256=h, page_count=len(pages),
        first_page_text=first, full_text="\f".join(full_parts), has_text_layer=bool("".join(full_parts).strip()),
        text_chars_per_page=[len(p.get("text", "")) for p in pages], layout={"pages": pages},
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--board", required=True, help="AQA, EDEXCEL or SAT")
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    pdf = Path(args.pdf)
    adapter = get_adapter(args.board)
    if adapter is None:
        raise SystemExit(f"No adapter for {args.board!r}")
    ctx = build_context(pdf)
    segments = adapter.segment(ctx)
    if args.limit:
        segments = segments[: args.limit]
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "segments.json").write_text(json.dumps(segments, indent=2), encoding="utf-8")
    # Render/save sequentially so long multi-page Edexcel questions do not keep
    # every assembled image resident on this ~2 GB sandbox at once.
    from adapters.segment_geometry import render_segment, save_rendered_segments
    import gc
    measurements = []
    for seg in segments:
        rendered_one = render_segment(pdf, seg)
        written = save_rendered_segments([rendered_one], out_dir)
        for path in written:
            with Image.open(path) as img:
                measurements.append({"file": path.name, "width": img.width, "height": img.height, "top_band": measure_top_band(img)})
        del rendered_one
        gc.collect()
    (out_dir / "measurements.json").write_text(json.dumps(measurements, indent=2), encoding="utf-8")
    ok = all(m["width"] == 2280 and m["top_band"] == 20 for m in measurements)
    print(json.dumps({"board": args.board.upper(), "pdf": str(pdf), "segments": len(segments), "all_width_2280_top_band_20": ok, "output": str(out_dir)}, indent=2))
    if measurements:
        print("first measurements:")
        for m in measurements[:10]:
            print(m)
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
