#!/usr/bin/env python3
"""tools/detect_subjects.py — cover-scan a folder of papers: what boards/subjects are in here?

    python3 tools/detect_subjects.py --input <dir> [--out detected_subjects.json] [--json]

**Cover scan only.** The first pages' text of every PDF (recursively) is handed to
``adapters.associations.identify_document`` — the same authority the batch pipeline uses — so a file
the batch could not route is a file this tool cannot route either. Nothing is inferred from the
folder name, and a file whose cover says nothing recognisable is reported as ``unrecognized`` with the
evidence that was actually found: this tool never guesses a board.

Exit status is **0** even when files are unrecognised (they are rows, not failures) — the caller
decides what to do with them. Exit 2 only when the input directory does not exist or holds no PDFs.

Years are normalised to four digits (``23`` → ``2023``) and every document carries a printed session
(``June 2023``). Subjects are grouped **board → qualification → subject**, with qualification/subject
resolved through ``subjects.json`` (the catalogue) when the printed component code is known there; a
recognised board whose code is not yet in the catalogue keeps its printed code and says so.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.config_loader import resolve_code_alias  # noqa: E402  (9-1 -> A*-G)

DEFAULT_OUT = ROOT / "detected_subjects.json"
CATALOGUE = ROOT / "subjects.json"

#: document types the batch can consume; anything else recognised is recorded but marked
PAPER_TYPES = ("QP", "MS", "ER", "IN")


def _catalogue_index() -> Dict[str, List[dict]]:
    """code -> catalogue rows, so a detected paper can be named by its subject."""
    out: Dict[str, List[dict]] = {}
    if not CATALOGUE.exists():
        return out
    try:
        payload = json.loads(CATALOGUE.read_text(encoding="utf-8"))
    except Exception:                                              # noqa: BLE001
        return out
    for row in payload.get("subjects", []):
        code = str(row.get("code") or "").strip()
        if code:
            out.setdefault(code, []).append(row)
    return out


def normalize_year(year: Any) -> str:
    """Four-digit year, or '' -- never a guess."""
    text = str(year or "").strip()
    if not text or text.upper() == "UNKNOWN":
        return ""
    #: four digits first: ``\d{2}|\d{4}`` matches the FIRST two digits of "2023" and would
    #: normalise June 2023 to "2020" (measured on AQA-84611H-QP-JUN23 -- the cover prints
    #: "Tuesday 16 May 2023" and "IB/M/Jun23/8461/1H").
    m = re.search(r"(\d{4}|\d{2})", text)
    if not m:
        return ""
    digits = m.group(1)
    if len(digits) == 2:
        # AQA/CAIE print 2-digit years only in publication codes; 20xx is the only century in use
        return f"20{digits}"
    return digits


def normalize_season(season: Any) -> str:
    text = str(season or "").strip()
    if not text or text.upper() == "UNKNOWN":
        return ""
    low = text.lower()
    for canonical in ("January", "March", "June", "November", "October", "May"):
        if low.startswith(canonical.lower()[:3]):
            return canonical
    return text


def session_label(season: str, year: str) -> str:
    if season and year:
        return f"{season} {year}"
    return year or season or "UNKNOWN"


def _subject_for(catalogue: Dict[str, List[dict]], code: str, qualification: str) -> Optional[dict]:
    rows = catalogue.get(code) or []
    if not rows:
        return None
    for row in rows:
        if qualification and str(row.get("qualification") or "").lower() == qualification.lower():
            return row
    return rows[0]


def detect(input_dir: Path) -> Dict[str, Any]:
    """Scan ``input_dir`` recursively; return the detection payload (never raises on content)."""
    from adapters.associations import identify_document            # imported late: keeps --help fast

    catalogue = _catalogue_index()
    pdfs = sorted({p.resolve() for pat in ("*.pdf", "*.PDF") for p in input_dir.rglob(pat)},
                  key=lambda p: str(p).lower())
    grouped: Dict[str, Dict[str, Any]] = {}
    unrecognized: List[Dict[str, Any]] = []
    scanned = 0

    for pdf in pdfs:
        scanned += 1
        try:
            ident = identify_document(pdf)
        except Exception as exc:                                    # noqa: BLE001 - a broken PDF is a row
            unrecognized.append({
                "file": pdf.name, "path": str(pdf), "reason": f"unreadable: {type(exc).__name__}",
                "evidence": [str(exc)[:200]], "sha256": None,
            })
            continue

        board = str(getattr(ident, "board", "UNKNOWN") or "UNKNOWN")
        doc_type = str(getattr(ident, "document_type", "UNKNOWN") or "UNKNOWN")
        component = str(getattr(ident, "component", "") or "")
        code = (component.split("/")[0] or "").strip()
        # Cambridge components are the paper half only ("01"); its covers carry
        # the syllabus half separately ("0980/01" -> 0980). Prefer that code so
        # the subject resolves instead of grouping every CAIE paper under "01".
        doc_syllabus = str(getattr(ident, "syllabus_code", "") or "").strip()
        if doc_syllabus and (not code or (code.isdigit() and len(code) < 4)):
            code = doc_syllabus
        season = normalize_season(getattr(ident, "season", ""))
        year = normalize_year(getattr(ident, "year", ""))
        evidence = list(getattr(ident, "evidence", []) or [])
        sha = getattr(ident, "sha256", None)

        if board == "UNKNOWN":
            unrecognized.append({
                "file": pdf.name, "path": str(pdf), "sha256": sha,
                "reason": f"board=UNKNOWN (confidence {float(getattr(ident, 'confidence', 0.0) or 0.0):.2f})",
                "evidence": evidence,
            })
            continue
        if doc_type not in PAPER_TYPES:
            unrecognized.append({
                "file": pdf.name, "path": str(pdf), "sha256": sha,
                "reason": f"board={board} but document_type={doc_type} is not a paper type {list(PAPER_TYPES)}",
                "evidence": evidence,
            })
            continue

        # 9-1 graded Cambridge codes (0980, 0984, 7156, ...) are the same
        # subject as their A*-G sibling, so resolve the catalogue row through
        # the alias table (the pipeline's own config lookup does the same).
        lookup_code = resolve_code_alias(code) if code else code
        row = _subject_for(catalogue, lookup_code, "") if code else None
        qualification = str((row or {}).get("qualification") or "")
        subject = str((row or {}).get("subject") or "")
        notes: List[str] = []
        if code and lookup_code != code:
            notes.append(f"{code} is the 9-1 graded twin of {lookup_code} "
                         f"(same syllabus, graded 9-1)")
        if code and row is None:
            notes.append(f"component code {code} is not in subjects.json yet")
        if not code:
            notes.append("the cover prints no component code; subject cannot be resolved")

        doc = {
            "file": pdf.name, "path": str(pdf), "document_type": doc_type,
            "component": component, "season": season, "year": year,
            "session": session_label(season, year),
            "confidence": float(getattr(ident, "confidence", 0.0) or 0.0),
            "sha256": sha, "evidence": evidence,
        }
        if notes:
            doc["notes"] = notes
        board_group = grouped.setdefault(board, {"board": board, "qualification": "", "subjects": {}})
        key = (qualification, code or "UNKNOWN", subject or "UNKNOWN")
        subj = board_group["subjects"].setdefault(key, {
            "code": code, "subject": subject, "qualification": qualification,
            "catalogue": (row or {}).get("catalogue_status") or ("UNKNOWN" if code else "NONE"),
            "documents": [],
        })
        subj["documents"].append(doc)

    boards = []
    for board in sorted(grouped):
        entry = grouped[board]
        subjects = []
        for key in sorted(entry["subjects"], key=lambda k: (k[0], k[1], k[2])):
            subj = entry["subjects"][key]
            subj["documents"].sort(key=lambda d: (d["session"], d["document_type"], d["file"]))
            subj["years"] = sorted({d["year"] for d in subj["documents"] if d["year"]})
            subj["document_types"] = sorted({d["document_type"] for d in subj["documents"]})
            subjects.append(subj)
        # a board's qualification is the common one when it is unambiguous, else '' (mixed board folder)
        quals = sorted({s["qualification"] for s in subjects if s["qualification"]})
        boards.append({"board": board, "qualification": quals[0] if len(quals) == 1 else "",
                       "subjects": subjects})

    recognized = sum(len(s["documents"]) for b in boards for s in b["subjects"])
    return {
        "schema": "detected_subjects/1",
        "generated_by": "tools/detect_subjects.py",
        "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "input": str(input_dir),
        "counts": {
            "scanned": scanned,
            "recognized": recognized,
            "unrecognized": len(unrecognized),
            "boards": len(boards),
            "subjects": sum(len(b["subjects"]) for b in boards),
        },
        "boards": boards,
        "unrecognized": unrecognized,
    }


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--input", required=True, help="directory to scan (recursive)")
    ap.add_argument("--out", default=str(DEFAULT_OUT), help="output JSON path")
    ap.add_argument("--json", action="store_true", help="print the payload to stdout as well")
    ap.add_argument("--quiet", action="store_true", help="print only the one-line summary")
    args = ap.parse_args(argv)

    input_dir = Path(args.input)
    if not input_dir.is_dir():
        print(f"[detect] input directory not found: {input_dir}")
        return 2

    payload = detect(input_dir)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)        # the other tools create their parents too;
    out.write_text(json.dumps(payload, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    # without this, `--out <fresh>\detected_subjects.json` raised FileNotFoundError and the report
    # never appeared (the launcher's option 1 writes into a data folder that may not exist yet)
    counts = payload["counts"]
    if counts["scanned"] == 0:
        print(f"[detect] no PDFs under {input_dir}")
        return 2
    if not args.quiet:
        for board in payload["boards"]:
            print(f"[detect] {board['board']}")
            for subj in board["subjects"]:
                print(f"    {subj['code'] or '????'} {subj['subject'] or '(unresolved subject)'} "
                      f"[{subj['catalogue']}] {len(subj['documents'])} document(s) "
                      f"{subj['document_types']} years={subj['years']}")
        for row in payload["unrecognized"]:
            print(f"[detect] UNRECOGNIZED {row['file']} -- {row['reason']}")
    print(f"[detect] scanned {counts['scanned']}, recognized {counts['recognized']} in "
          f"{counts['subjects']} subject(s) over {counts['boards']} board(s), "
          f"unrecognized {counts['unrecognized']} -> {out.name}")
    if args.json:
        print(json.dumps(payload, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
