#!/usr/bin/env python3
"""tools/booklet_docx.py — the booklet as an editable .docx (python-docx, already a dependency).

    python3 tools/booklet_docx.py --manifest <booklet.manifest.json> --out booklet.docx [--title T]

Reads the manifest `build_booklet.py` already writes (question ids, crops, answers mode) so the PDF
and the Word file can never disagree about what is in the booklet. Crops are placed at page width,
one question per block, with the answer image after it when the booklet was built with answers.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import List, Optional

ROOT = Path(__file__).resolve().parent.parent


def _docx_embeddable(crop: Path, work_dir: Path, register: List[Path]) -> Optional[Path]:
    """A path Word can actually embed: crops are `.webp`, which python-docx refuses outright.

    PNG/JPEG go straight through; anything else is converted once with Pillow into ``work_dir`` (the
    booklet's own output folder, so the images are inspectable rather than hidden in a temp dir).
    Returns None when neither route works -- the caller writes a visible placeholder, never a crash.
    """
    if crop.suffix.lower() in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff"):
        return crop
    try:
        from PIL import Image                                       # noqa: PLC0415
        work_dir.mkdir(parents=True, exist_ok=True)
        target = work_dir / f"{crop.stem}.png"
        if not target.is_file():
            with Image.open(crop) as img:
                img.convert("RGB").save(target, format="PNG")
        register.append(target)
        return target
    except Exception:                                               # noqa: BLE001 - reported upstream
        return None


def build(manifest_path: Path, out_path: Path, title: str = "") -> Path:
    """Write the .docx. Raises FileNotFoundError/ValueError -- the caller turns those into messages."""
    from docx import Document                                       # noqa: PLC0415
    from docx.shared import Inches, Pt                              # noqa: PLC0415

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    entries = manifest.get("entries") or []
    if not entries:
        raise ValueError(f"{manifest_path}: no entries to export")
    base = manifest_path.parent

    doc = Document()
    heading = title or (manifest.get("cover_text") or "").splitlines()[0] or "Question booklet"
    doc.add_heading(heading, level=0)
    subtitle = [line for line in (manifest.get("cover_text") or "").splitlines()[1:]]
    for line in subtitle:
        doc.add_paragraph(line)
    if manifest.get("marks_note"):
        doc.add_paragraph(str(manifest["marks_note"]))
    doc.add_paragraph(f"{sum(1 for e in entries if e.get('kind') == 'question')} question(s) · "
                      f"answers: {manifest.get('answers')} · fit: {manifest.get('fit')}")

    converted: List[Path] = []
    for position, entry in enumerate(entries, start=1):
        if entry.get("kind") == "answer":
            doc.add_heading("Mark scheme", level=3)
        crop = Path(str(entry.get("crop") or ""))
        if not crop.is_absolute():
            crop = base / crop
        if not crop.is_file():
            doc.add_paragraph(f"[missing crop: {crop.name}]")
            continue
        embed = _docx_embeddable(crop, out_path.parent, converted)
        if embed is None:
            doc.add_paragraph(f"[unreadable crop: {crop.name}]")
            continue
        paragraph = doc.add_paragraph()
        paragraph.add_run().add_picture(str(embed), width=Inches(6.3))
        doc.add_paragraph(f"Q{position} · {entry.get('id', '')}").runs[0].font.size = Pt(8)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    return out_path


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--title", default="")
    args = parser.parse_args(argv)
    try:
        out = build(Path(args.manifest), Path(args.out), args.title)
    except (OSError, ValueError) as exc:
        print(f"[booklet-docx] failed: {exc}", file=sys.stderr)
        return 1
    print(f"[booklet-docx] wrote {out} ({out.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
