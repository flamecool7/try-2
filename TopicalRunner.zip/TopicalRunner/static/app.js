/* Topical Bank + Booklet Builder — vanilla JS front end.
   Rules: every list on screen comes from fetch(); nothing about a subject, question or topic is
   hardcoded here. The server is the only source of truth (see design/TOPICAL_BOOKLET_DESIGN.md). */
'use strict';

const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const PERSIST_KEY = 'topical-bank/1';
const state = {
  catalogue: null,
  detection: null,
  index: null,
  draft: null,
  job: null,
  ai: null,                 // /api/ai/status: the Suggest topic button exists only when enabled
  aiBusy: {},               // row id -> true while a suggestion is in flight
  aiShown: {},              // row id -> the suggestion payload last returned for it
  filters: { board: '', subject: '', topic: '', session: '', year: '', sort: 'board',
             q: '', listable: true, shown: 60 },
};

/* ------------------------------------------------------------------ plumbing */
async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const text = await response.text();
  let payload;
  try { payload = text ? JSON.parse(text) : {}; } catch { payload = { error: text.slice(0, 300) }; }
  if (!response.ok) {
    const error = new Error(payload.error || `HTTP ${response.status}`);
    error.payload = payload;
    error.status = response.status;
    throw error;
  }
  return payload;
}

function toast(message, ms = 3600) {
  const el = $('#toast');
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.hidden = true; }, ms);
}

function empty(text) { return `<p class="empty">${esc(text)}</p>`; }

/* What each catalogue status means for *this* app, stated once. The statuses are the catalogue's
   own vocabulary (subjects.json); nothing here invents a board's capability, and an unrecognised
   status is shown verbatim with no interpretation. */
const READINESS = {
  PROFILE:       { label: 'profile',        note: "topics classify against this subject's own spec profile" },
  TAXONOMY_ONLY: { label: 'taxonomy only',  note: 'no spec profile yet — some questions may land in Review instead of a topic' },
  ADAPTER_ONLY:  { label: 'adapter only',   note: 'the adapter can render it, but the catalogue has no per-subject identity — indexing refuses until it does' },
  UNKNOWN:       { label: 'not catalogued', note: 'detected, but nothing can be attributed to it — indexing refuses and names the (board, code) gap' },
};
function readiness(status) {
  const key = String(status || 'UNKNOWN').toUpperCase();
  return READINESS[key] || { label: key.toLowerCase(), note: '' };
}

/* The crop URLs are served by /files/ from the batch output root; a row's artifact paths are
   relative to its own batch_out, which is what makes them addressable. */
function cropUrl(row, kind, i = 0) {
  const list = (row.artifacts || {})[kind] || [];
  return list[i] ? 'files/' + list[i] : '';
}

/* What pressing "Run" on this board will execute. The server routes CAIE through main.py and every
   other board through the universal router; this text mirrors that split rather than inventing one. */
function boardRunNote(board) {
  const name = String(board.board || '').toUpperCase();
  if (name === 'CAIE') {
    return 'Cambridge pipeline (main.py): crops + classifies + files every question into its paper\'s topics.';
  }
  if (name === 'IB') {
    return 'Universal router (IB is gated until official PDFs are supplied).';
  }
  return 'Universal router (run_universal_batch.py).';
}

/* One line per board: what the folder holds and what will happen when it is indexed. */
function readinessSummary(board) {
  const rows = board.subjects || [];
  if (!rows.length) return '';
  const counts = {};
  rows.forEach((s) => {
    const r = readiness(s.catalogue);
    counts[r.label] = (counts[r.label] || 0) + 1;
  });
  const parts = Object.entries(counts).map(([label, n]) => `${n} ${label}`);
  return `${rows.length} subject(s): ${esc(parts.join(' · '))}.`
    + (rows.some((s) => readiness(s.catalogue).label === 'not catalogued' || readiness(s.catalogue).label === 'adapter only')
      ? ' Indexing a board without per-subject identities is refused, with the gap named — the batch itself may still render crops.'
      : '');
}


/* ------------------------------------------------------------------ preferences */
/* Filters, theme and the open screen survive a reload: the app is used in long sittings, and
   re-picking the same board and topic every time was pure friction. */
function savePrefs() {
  try {
    localStorage.setItem(PERSIST_KEY, JSON.stringify({
      theme: document.documentElement.dataset.theme,
      screen: (location.hash || '#library').slice(1),
      filters: state.filters,
    }));
  } catch { /* private mode: preferences are a convenience, never a requirement */ }
}

function loadPrefs() {
  try {
    const saved = JSON.parse(localStorage.getItem(PERSIST_KEY) || '{}');
    if (saved.theme) document.documentElement.dataset.theme = saved.theme;
    if (saved.filters) state.filters = { ...state.filters, ...saved.filters };
    return saved;
  } catch {
    return {};
  }
}

/* ------------------------------------------------------------------ screens */
function showScreen(name) {
  $$('.tab').forEach((tab) => {
    const active = tab.dataset.screen === name;
    tab.classList.toggle('is-active', active);
    tab.setAttribute('aria-selected', String(active));
  });
  $$('.screen').forEach((screen) => screen.classList.toggle('is-active', screen.id === `screen-${name}`));
  if (location.hash !== `#${name}`) history.replaceState(null, '', `#${name}`);
  if (name === 'review') renderReview();
  if (name === 'tools') loadJobs();
  savePrefs();
}

/* The script's own input/ and output/ folders, from the server -- the run card shows them and every
   request falls back to them, so nothing has to be typed in. */
function standardFolders() {
  const health = state.health || {};
  return { input: health.input_dir || '', output: health.output_dir || '' };
}

function chosenFolders() {
  const std = standardFolders();
  const input = ($('#detect-input') || {}).value?.trim() || std.input;
  const output = ($('#batch-output') || {}).value?.trim() || std.output;
  return { input, output };
}

function paintFolders() {
  const { input, output } = standardFolders();
  const inEl = $('#input-path');
  const outEl = $('#output-path');
  if (inEl) inEl.textContent = input || 'input/';
  if (outEl) outEl.textContent = output || 'output/';
  const count = (state.health || {}).input_pdfs;
  const status = $('#detect-status');
  if (status && Number.isFinite(count)) {
    status.textContent = count
      ? `${count} PDF(s) waiting in ${input}`
      : `Nothing in ${input} yet — drop the question papers and mark schemes in, then hit "Build everything found".`;
  }
}

/* ------------------------------------------------------------------ library */
async function loadCatalogue() {
  if (!state.catalogue) state.catalogue = await api('/api/catalogue');
  return state.catalogue;
}

async function loadIndex(force = false) {
  if (!state.index || force) state.index = await api('/api/index');
  return state.index;
}

async function runDetection() {
  const { input } = chosenFolders();
  if (!input) { toast('The input folder is not known yet'); return; }
  const status = $('#detect-status');
  status.textContent = 'Scanning covers…';
  try {
    state.detection = await api(`/api/detection?input=${encodeURIComponent(input)}`);
    renderDetection();
    status.textContent = `Scanned ${state.detection.counts.scanned} file(s): `
      + `${state.detection.counts.recognized} recognized in ${state.detection.counts.subjects} subject(s), `
      + `${state.detection.counts.unrecognized} unrecognized.`;
  } catch (error) {
    const message = String(error.message || error);
    // The detector's refusal is exit 2 with "no PDFs under <dir>" on its tail; the server maps
    // exactly that to 422 but puts only the short reason ("detect_subjects.py exited 2") in
    // `error`. So read the whole response, not just its message -- otherwise the first state a
    // fresh install meets (the shipped `input/` is empty) rendered as "Detection failed".
    const refusal = error.status === 422 || /no PDFs/i.test(message)
      || /no PDFs/i.test(String((((error.payload || {}).log_tail) || []).join(" ")));
    if (refusal) {
      // The scan now runs by itself on open, so an empty `input/` is a state the user will meet
      // before they have dropped anything in. That is not a failure, and it must not read like one:
      // say what will happen next instead of showing a red error over an empty folder.
      status.textContent = `Nothing in ${input} yet — drop the papers in and they are picked up `
        + 'automatically.';
      $('#detect-results').innerHTML = empty('No papers to scan yet.');
      return;
    }
    status.textContent = '';
    $('#detect-results').innerHTML = empty(`Detection failed: ${message}`);
    toast(`Detection failed: ${message}`);
  }
}

function renderDetection() {
  const data = state.detection;
  if (!data) return;
  const boards = data.boards || [];
  $('#detect-results').innerHTML = boards.length ? boards.map((board) => `
    <div class="card">
      <h2>${esc(board.board)}${board.qualification ? ` · ${esc(board.qualification)}` : ''}
        <span class="pill ghost count">${board.subjects.length} subject(s)</span></h2>
      <p class="hint">${readinessSummary(board)}</p>
      <div class="row">
        <button class="btn primary" data-run-batch data-board="${esc(board.board)}"
          >Run ${esc(board.board)}${board.subjects.length > 1 ? ` (${board.subjects.length} subjects)` : ''}</button>
        <span class="hint">${esc(boardRunNote(board))}</span>
      </div>
      ${board.subjects.map((subject) => {
        const r = readiness(subject.catalogue);
        return `
        <div class="subject-row">
          <div class="meta">
            <strong>${esc(subject.subject || '(unresolved subject)')}
              <span class="pill ghost count" title="${esc(r.note)}">${esc(r.label)}</span></strong>
            <small>${esc(subject.code || '—')} · ${esc(subject.catalogue)} ·
              ${subject.documents.length} document(s) · ${esc((subject.document_types || []).join('/'))} ·
              ${esc((subject.years || []).join(', ') || 'year unknown')}</small>
            ${r.note ? `<small class="hint">${esc(r.note)}</small>` : ''}
          </div>
          <button class="btn" data-run-batch data-board="${esc(board.board)}">Run batch</button>
        </div>`;
      }).join('')}
    </div>`).join('') : empty('Nothing recognized yet — scan a folder above.');

  const junk = data.unrecognized || [];
  $('#unrecognized-card').innerHTML = junk.length ? `
    <div class="card">
      <h2>Not recognized <span class="pill ghost count">${junk.length}</span></h2>
      <p class="hint">These files are reported, never guessed at. They stay out of the batch.</p>
      <ul class="unrecognized">${junk.map((row) => `
        <li>${esc(row.file)} — ${esc(row.reason)}${row.evidence && row.evidence.length
          ? ` <span class="hint">(${esc(row.evidence.slice(0, 2).join('; '))})</span>` : ''}</li>`).join('')}
      </ul>
    </div>` : '';
}

/* Body of the launcher's options 3 and 6: rebuild the index over a folder, open that folder. */
async function rebuildIndex() {
  const dir = ($('#index-dir').value || '').trim() || chosenFolders().output;
  const status = $('#maint-status');
  if (!dir) { status.textContent = 'Name a batch output folder (or run a batch first).'; return; }
  status.textContent = `Indexing ${dir}…`;
  try {
    const ocr = !!($('#index-ocr') || {}).checked;      // the checkbox decides OCR; text is always read
    const payload = await api('/api/index', { method: 'POST',
                                              body: { batch_out: [dir], reset: false, ocr } });
    const c = payload.counts || {};
    status.textContent = `Index rebuilt: ${c.questions ?? 0} question(s), ${c.listable ?? 0} listable, `
      + `${c.flagged ?? 0} flagged.`;
    state.index = null;                       // the bank reads the index on next paint
    toast('Index rebuilt');
    await showScreen('bank');
  } catch (error) {
    status.textContent = `Could not index that folder: ${error.message}`;
  }
}

async function openOutputFolder() {
  const dir = ($('#index-dir').value || '').trim() || chosenFolders().output;
  const status = $('#maint-status');
  if (!dir) { status.textContent = 'Name a batch output folder first.'; return; }
  try {
    const out = await api('/api/reveal', { method: 'POST', body: { path: dir } });
    status.textContent = out.opened ? `Opened ${out.path} in your file manager.`
                                    : `${out.note || 'Could not open it.'} — path: ${out.path}`;
  } catch (error) {
    status.textContent = `Could not open that folder: ${error.message}`;
  }
}

async function buildFromBookletFile() {
  const path = ($('#booklet-path').value || '').trim();
  if (!path) { toast('Name a booklet.json file, or use Generate above'); return; }
  $('#generate-progress').innerHTML = '<p class="hint">Starting…</p>';
  try {
    const started = await api('/api/booklet', { method: 'POST',
      body: { booklet_path: path, fit: $('#booklet-fit').value } });
    await pollJob(started.job, 'booklet');
  } catch (error) {
    $('#generate-progress').innerHTML = empty(`Could not build from that file: ${error.message}`);
  }
}

async function startBatch(board) {
  const { input, output } = chosenFolders();          // the standard folders unless overridden
  const body = {};
  if (input) body.input = input;
  if (output) body.output = output;
  if (board) body.board = board;
  // IB and SAT run by default now, so the page sends nothing for them: the only way to skip a board is
  // to ask the tool directly (`--no-include-ib` on the command line). No checkbox, no accidental false.
  // the Cambridge pipeline's own default is production (full-auto); the switch only ever turns it off
  body.full_auto = !!($('#batch-full-auto') || {}).checked;
  const limit = parseInt(($('#batch-limit') || {}).value, 10);
  if (Number.isFinite(limit) && limit > 0) body.limit_per_paper = limit;   // low-memory runs
  const card = $('#run-card');
  card.innerHTML = `<div class="card"><h2>Batch ${board ? esc(board) : 'run — every board found'}</h2>
      <p class="hint">Starting…</p></div>`;
  try {
    const started = await api('/api/batch', { method: 'POST', body });
    card.innerHTML = `<div class="card"><h2>Batch ${board ? esc(board) : 'run — every board found'}
        <span class="pill ghost count">${esc(started.job)}</span></h2>
      <p class="hint">Output <code>${esc(started.output)}</code>.
        ${started.steps > 1 ? `${started.steps} board steps in one job.` : ''}
        Batches take minutes; this page polls.</p>
      <div class="progress"><i id="batch-bar"></i></div>
      <p class="hint" id="batch-facts">queued…</p>
      <pre class="log" id="batch-log"></pre></div>`;
    pollJob(started.job, 'batch');
  } catch (error) {
    card.innerHTML = `<div class="card"><h2>Batch failed to start</h2>${empty(error.message)}</div>`;
  }
}

/* ------------------------------------------------------------------ jobs */
async function pollJob(jobId, flavour) {
  const bar = flavour === 'batch' ? $('#batch-bar') : null;
  const facts = flavour === 'batch' ? $('#batch-facts') : $('#generate-progress');
  const log = flavour === 'batch' ? $('#batch-log') : $('#generated-log');
  try {
    const job = await api(`/api/jobs/${jobId}`);
    state.job = job;
    const chip = $('#job-chip');
    chip.hidden = false;
    chip.textContent = `${job.kind} · ${job.status}`;
    if (bar) {
      const progress = job.progress || {};
      const done = (progress.packs || 0) + (progress.flagged_packs || 0);
      const total = (progress.audit_counts || {}).question_packs || 0;
      bar.style.width = total ? `${Math.min(100, (done / total) * 100)}%` : (job.status === 'running' ? '35%' : '0%');
    }
    if (facts) {
      const progress = job.progress || {};
      facts.innerHTML = flavour === 'batch'
        ? `${esc(job.status)} · packs ${progress.packs || 0} (flagged ${progress.flagged_packs || 0}) · `
          + `mark schemes ${progress.mark_schemes || 0} · crops ${progress.crops || 0} · ${job.seconds}s`
        : `${esc(job.status)} · ${progress.entries || 0} page entries · ${job.seconds}s`;
    }
    if (log) log.textContent = (job.log_tail || []).join('\n');
    if (job.status === 'queued' || job.status === 'running') {
      setTimeout(() => pollJob(jobId, flavour), 900);
      return job;
    }
    chip.hidden = true;
    if (job.status === 'done') {
      await onJobDone(job, flavour);
    } else {
      toast(`${job.kind} job failed: ${job.error || 'see log'}`);
    }
    return job;
  } catch (error) {
    toast(`Job poll failed: ${error.message}`);
    return null;
  }
}

async function onJobDone(job, flavour) {
  if (flavour === 'batch') {
    const counts = (job.result || {}).counts || {};
    const index = (job.result || {}).index || {};
    const gaps = index.gap || [];
    if (gaps.length) {
      // the batch rendered, the index refused: show the refusal where the run was started
      const card = $('#run-card');
      card.insertAdjacentHTML('afterbegin', `<div class="card">
        <h2>Index refused (fail-closed) <span class="pill flagged">${gaps.length} gap(s)</span></h2>
        <p class="hint">The batch output is on disk and untouched. These (board, code) pairs have no
          identity in <code>subjects.json</code>, so nothing is attributed to a topic until they do.
          Add the subject with <code>tools/generate_subjects_catalogue.py</code>, then re-run the index.</p>
        <ul class="unrecognized">${gaps.map((g) => `<li>${esc(g)}</li>`).join('')}</ul></div>`);
      toast(`Batch done: ${counts.question_packs ?? '?'} packs · index refused`);
    } else {
      toast(`Batch done: ${counts.question_packs ?? '?'} packs, `
        + `index ${index.questions ?? '?'} questions (${index.flagged ?? '?'} flagged)`);
    }
    await loadIndex(true);
    renderBank();
    renderBuilder();
    // the run may have consumed or added papers: refresh the Library's own view of `input/` too, so the
    // next thing the user sees is what is on disk now rather than what was there when they clicked
    runDetection();
  } else {
    const result = job.result || {};
    $('#generate-progress').innerHTML = `
      <p class="hint">Done — ${esc(result.questions)} question(s), ${esc(result.pages)} page(s),
        answers ${esc(result.answers)}, fit ${esc(result.fit)}.
        ${(result.warnings || []).length ? `<br>${esc(result.warnings.length)} warning(s).` : ''}</p>
      <p><a class="btn primary" href="/api/booklet/${esc(job.job)}/pdf" target="_blank" rel="noopener">
        Open booklet PDF</a></p>
      <pre class="log" id="generated-log">${esc((job.log_tail || []).join('\n'))}</pre>`;
    toast('Booklet ready');
  }
}

/* ------------------------------------------------------------------ bank */
function boardPills() {
  const counts = {};
  (state.index?.questions || []).forEach((row) => { counts[row.board] = (counts[row.board] || 0) + 1; });
  const boards = Object.keys(counts).sort();
  $('#board-pills').innerHTML = [
    `<button class="pill ${state.filters.board ? '' : 'is-active'}" data-board="">All boards</button>`,
    ...boards.map((board) => `<button class="pill ${state.filters.board === board ? 'is-active' : ''}"
        data-board="${esc(board)}">${esc(board)} <span class="pill ghost count">${counts[board]}</span></button>`),
  ].join('');
}

function fillSelect(selector, rows, field, keepDefault = 'All') {
  const values = [...new Set(rows.map((row) => row[field]).filter(Boolean))].sort();
  const select = $(selector);
  const current = select.value;
  select.innerHTML = `<option value="">${keepDefault}</option>`
    + values.map((v) => `<option value="${esc(v)}">${esc(v)}</option>`).join('');
  if (values.includes(current)) select.value = current;
}

function filteredRows() {
  const f = state.filters;
  const rows = (state.index?.questions || []).filter((row) => {
    if (f.board && row.board !== f.board) return false;
    if (f.subject && row.subject !== f.subject) return false;
    if (f.topic && row.topic !== f.topic) return false;
    if (f.session && row.session !== f.session) return false;
    if (f.year && String(row.year || '') !== String(f.year)) return false;
    if (f.listable && !row.listable) return false;
    if (f.q && !haystack(row).includes(f.q.toLowerCase())) return false;
    return true;
  });
  const sort = f.sort || 'board';
  const by = {
    board: (r) => [r.board || '', r.component || '', r.session || '', r.question_number || 0],
    topic: (r) => [r.topic || '', r.board || '', r.question_number || 0],
    confidence: (r) => [-(Number(r.confidence) || 0), r.topic || ''],
    marks: (r) => [-(Number(r.marks) || 0), r.topic || ''],
  }[sort] || (() => 0);
  return rows.sort((a, b) => {
    const ka = by(a), kb = by(b);
    for (let i = 0; i < Math.max(ka.length, kb.length); i += 1) {
      const x = ka[i], y = kb[i];
      if (x === y) continue;
      return (typeof x === 'number' && typeof y === 'number') ? x - y : String(x).localeCompare(String(y));
    }
    return 0;
  });
}

/* What search matches: the topic and ids, plus the question's own text when the index holds it
   (extracted from the paper, or OCR'd) -- so "half-life" finds the question, not just its topic. */
function haystack(row) {
  return [row.topic, row.subject, row.code, row.component, row.session, row.id,
          row.canonical_question, row.text].filter(Boolean).join(' ').toLowerCase();
}

/* Declared-topic coverage from the server: what the syllabus lists vs what the bank holds. */
async function loadCoverage() {
  try {
    state.coverage = await api('/api/coverage');
  } catch (error) {
    state.coverage = null;
  }
  renderCoverage();
}

function renderCoverage() {
  const panel = $('#coverage-panel');
  const inline = $('#coverage-inline');
  if (!panel || !inline) return;
  const subjects = state.coverage?.subjects || [];
  if (!subjects.length) { inline.textContent = ''; panel.innerHTML = ''; return; }
  const declared = subjects.reduce((n, s) => n + s.declared.length, 0);
  const covered = subjects.reduce((n, s) => n + s.covered.length, 0);
  inline.textContent = declared ? `${covered}/${declared} declared topics have questions` : '';
  panel.innerHTML = subjects.map((s) => `
    <div class="coverage-subject">
      <h3>${esc(s.key)} <span class="pill ghost count">${s.questions} question(s)</span></h3>
      ${s.profile ? '' : '<p class="hint">No profile for this code — coverage cannot be measured.</p>'}
      <div class="coverage-chips">
        ${s.declared.map((t) => `<span class="pill ${s.counts[t] ? '' : 'empty'}"
            title="${s.counts[t] ? `${s.counts[t]} question(s)` : 'no questions yet'}">
            ${esc(t)}${s.counts[t] ? ` <b>${s.counts[t]}</b>` : ''}</span>`).join('')}
      </div>
      ${s.found_outside_profile.length ? `<p class="hint">Filed outside the profile's topics:
        ${esc(s.found_outside_profile.join(', '))}</p>` : ''}
    </div>`).join('');
}

function renderTree() {
  const rows = filteredRows();
  const bySubject = {};
  rows.forEach((row) => {
    const key = `${row.board} ${row.code || '????'} ${row.subject || ''}`.trim();
    bySubject[key] = bySubject[key] || {};
    bySubject[key][row.topic] = (bySubject[key][row.topic] || 0) + 1;
  });
  const keys = Object.keys(bySubject).sort();
  $('#syllabus-tree').innerHTML = keys.length ? keys.map((key) => `
    <h3>${esc(key)}</h3>
    ${Object.entries(bySubject[key]).sort().map(([topic, n]) =>
      `<button data-topic="${esc(topic)}" class="${state.filters.topic === topic ? 'is-active' : ''}">
        <span>${esc(topic)}</span><span>${n}</span></button>`).join('')}`).join('')
    : empty('No indexed questions yet — run a batch in Library.');
}

function renderBank() {
  if (!state.index) { $('#bank-cards').innerHTML = empty('Loading the index…'); return; }
  const sortSelect = $('#filter-sort');
  if (sortSelect) sortSelect.value = state.filters.sort || 'board';
  boardPills();
  fillSelect('#filter-subject', state.index.questions, 'subject');
  fillSelect('#filter-topic', state.index.questions, 'topic');
  fillSelect('#filter-session', state.index.questions, 'session');
  fillSelect('#filter-year', state.index.questions, 'year');
  renderTree();
  renderBankCards();
}

/** Trailing-edge debounce -- the standard "wait until the user stops typing" helper. */
function debounce(fn, ms) {
  let handle = null;
  return (...args) => {
    if (handle) clearTimeout(handle);
    handle = setTimeout(() => { handle = null; fn(...args); }, ms);
  };
}

/*: How many cards one screen paints. A bank of a thousand questions would otherwise build a thousand
   cards -- and request a thousand crop images -- every time a filter changed, which is what made
   typing in the search box feel like the app had stopped responding. The rest are one click away, and
   the count line says how many are hidden rather than pretending the bank is empty. */
const BANK_PAGE = 60;

/** Just the count line and the cards: the cheap half of renderBank, for a changed search query. */
function renderBankCards() {
  const rows = filteredRows();
  const total = (state.index.questions || []).length;
  const shown = Math.max(0, Math.min(state.filters.shown || BANK_PAGE, rows.length));
  const visible = rows.slice(0, shown);
  const hidden = rows.length - shown;
  const counts = ` · ${state.index.counts?.flagged ?? 0} flagged`
    + ` · ${state.index.counts?.overridden ?? 0} overridden`;
  $('#bank-count').textContent = (hidden > 0
    ? `showing ${shown} of ${rows.length} match(es) (${total} in the bank)`
    : `${rows.length} of ${total} question(s) shown`) + counts;
  $('#bank-cards').innerHTML = visible.length ? visible.map((row) => `
    <article class="qcard">
      <div class="thumb" data-preview="${esc(row.id)}">
        ${cropUrl(row, 'qp') ? `<img loading="lazy" alt="Question crop" src="${esc(cropUrl(row, 'qp'))}">` : ''}
      </div>
      <div class="body">
        <strong>${esc(row.topic || 'UNKNOWN')}</strong>
        <div class="facts">
          <span class="pill ghost count">${esc(row.component)}</span>
          <span class="pill ghost count">${esc(row.canonical_question)}</span>
          <span class="pill ghost count">${esc(row.session)}</span>
          <span class="pill status ${row.listable ? 'hint' : 'flagged'}">${row.listable ? 'HINT' : esc(row.status)}</span>
          ${row.verified ? `<span class="pill verified" title="The mark scheme's own spec reference agrees with this topic">&#10003; MS-verified</span>` : ''}
          ${row.override ? '<span class="pill ghost count">override</span>' : ''}
          ${row.marks ? `<span class="pill ghost count">${row.marks} marks</span>` : ''}
        </div>
        ${row.text ? `<p class="qtext">${esc(row.text.slice(0, 220))}${row.text.length > 220 ? '…' : ''}</p>` : ''}
        <span class="src">${esc(row.engine || '')}${row.confidence ? ` · conf ${Number(row.confidence).toFixed(2)}` : ''}${row.marks ? ` · ${row.marks} marks` : ''}${row.text_source ? ` · text: ${esc(row.text_source)}` : ''}</span>
        <div class="actions">
          <button class="btn" data-preview="${esc(row.id)}">Preview</button>
          <button class="btn ghost" data-add="${esc(row.id)}">Add</button>
        </div>
      </div>
    </article>`).join('') + moreButton(hidden) : empty('No questions match these filters.');
}

/** The "show more" control: honest about what is hidden, and gone when nothing is. */
function moreButton(hidden) {
  if (hidden <= 0) return '';
  return `<div class="more-row"><button class="btn ghost" data-show-more="1">Show `
    + `${Math.min(BANK_PAGE, hidden)} more <span class="src">(${hidden} still hidden)</span></button></div>`;
}

function closePreview() {
  // Three ways out always work: the Close button, the scrim/backdrop, and Escape. The dialog is
  // never modal-by-accident -- `hidden` is authoritative (see the [hidden] rule in styles.css).
  const modal = $('#preview');
  if (modal) modal.hidden = true;
}

function openPreview(id) {
  const row = (state.index?.questions || []).find((r) => r.id === id);
  if (!row) return;
  $('#preview-title').textContent = `${row.topic || 'UNKNOWN'} · ${row.canonical_question}`;
  $('#preview-sub').textContent = `${row.board} ${row.code} · ${row.component} · ${row.session}`
    + (row.verified ? ` · \u2713 verified against the mark scheme's own spec reference`
       : (row.classifier_topic && row.classifier_topic !== row.topic
          ? ` · classifier said ${row.classifier_topic}; the mark scheme says ${row.topic}`
          : ''))
    + ` · ${row.status}${row.confidence ? ` (${Number(row.confidence).toFixed(2)})` : ''}`;
  $('#preview-qp').innerHTML = cropUrl(row, 'qp') ? `<img alt="Question paper crop" src="${esc(cropUrl(row, 'qp'))}">` : empty('no crop');
  $('#preview-ms').innerHTML = cropUrl(row, 'ms') ? `<img alt="Mark scheme crop" src="${esc(cropUrl(row, 'ms'))}">` : empty('no mark scheme crop');
  $('#preview-add').dataset.add = id;
  $('#preview').hidden = false;
}

/* ------------------------------------------------------------------ builder */
let step = 1;
function setStep(next) {
  step = Math.max(1, Math.min(5, next));
  $$('#stepper li').forEach((li) => {
    const n = Number(li.dataset.step);
    li.classList.toggle('is-active', n === step);
    li.classList.toggle('is-done', n < step);
  });
  $$('.step-panel').forEach((panel) => panel.classList.toggle('is-active', Number(panel.dataset.panel) === step));
  if (step === 5) summarize();
}

async function loadDraft() {
  state.draft = await api('/api/draft');
  return state.draft;
}

async function addToDraft(id) {
  state.draft = await api('/api/draft', { method: 'POST', body: { add: [id] } });
  toast(`Added ${id.split('|').pop()} to the booklet draft`);
  renderBuilder();
}

function renderBuilder() {
  const catalog = state.catalogue;
  if (catalog) {
    const counts = {};
    (state.index?.questions || []).forEach((row) => {
      const key = `${row.board} ${row.code}`;
      counts[key] = counts[key] || { rows: 0, subject: row.subject, board: row.board, code: row.code };
      counts[key].rows += 1;
    });
    const keys = Object.keys(counts).sort();
    $('#builder-subjects').innerHTML = keys.length ? keys.map((key) => `
      <button class="pill ${state.draft?.code === counts[key].code && state.draft?.board === counts[key].board ? 'is-active' : ''}"
        data-subject="${esc(key)}">${esc(counts[key].board)} ${esc(counts[key].code)}
        <span class="pill ghost count">${counts[key].rows}</span></button>`).join('')
      : empty('Index the bank first — the builder lists only indexed subjects.');
    $('#builder-subject-hint').textContent = keys.length
      ? 'Subjects come from the topical index (the catalogue holds all 141 subjects).'
      : 'No indexed subjects yet.';
  }
  const draft = state.draft || { questions: [] };
  $('#booklet-title').value = draft.title || '';
  $('#booklet-subtitle').value = draft.subtitle || '';
  const answers = draft.answers || 'after_each';
  const radio = $(`input[name=answers][value="${answers}"]`);
  if (radio) radio.checked = true;
  const rows = draft.questions || [];
  $('#draft-list').innerHTML = rows.length ? rows.map((item, i) => {
    const row = (state.index?.questions || []).find((r) => r.id === item.id);
    return `<div class="draft-row">
      <span class="pill ghost count">${i + 1}</span>
      <div class="meta"><strong>${esc(row?.topic || 'UNKNOWN')}</strong>
        <small>${esc(item.id)}</small></div>
      <button class="btn ghost" data-move="${i}" data-dir="-1" ${i === 0 ? 'disabled' : ''}>↑</button>
      <button class="btn ghost" data-move="${i}" data-dir="1" ${i === rows.length - 1 ? 'disabled' : ''}>↓</button>
      <button class="btn ghost" data-drop="${esc(item.id)}">Remove</button>
    </div>`;
  }).join('') : empty('No questions picked yet — use “Add” on a card in the Question Bank.');
}

function summarize() {
  const draft = state.draft || { questions: [] };
  const rows = draft.questions || [];
  const estimated = rows.length * ((draft.answers || 'after_each') === 'none' ? 1 : 2);
  $('#generate-summary').innerHTML = `${esc(draft.title || 'Untitled booklet')} · `
    + `${rows.length} question(s) · answers ${esc(draft.answers || 'after_each')} · `
    + `≈${estimated} page(s) minimum`;
}

async function generate() {
  const draft = state.draft || { questions: [] };
  if (!draft.questions?.length) { toast('Pick at least one question'); setStep(3); return; }
  $('#generate-progress').innerHTML = '<p class="hint">Starting…</p>';
  try {
    const started = await api('/api/booklet', {
      method: 'POST',
      body: {
        schema: 'booklet_request/1',
        title: draft.title || 'Question booklet',
        subtitle: draft.subtitle || '',
        board: draft.board, code: draft.code,
        answers: draft.answers || 'after_each',
        questions: draft.questions,
        options: { page: 'A4', margin_pt: 28, numbering: true, fit: $('#booklet-fit').value },
      },
    });
    await pollJob(started.job, 'booklet');
  } catch (error) {
    $('#generate-progress').innerHTML = empty(`Could not start the booklet: ${error.message}`);
  }
}


/* ------------------------------------------------------------------ tools screen */
async function loadJobs() {
  const list = $('#jobs-list');
  if (!list) return;
  try {
    const payload = await api('/api/jobs');
    const jobs = payload.jobs || [];
    $('#jobs-count').textContent = String(jobs.length);
    list.innerHTML = jobs.length ? jobs.map((job) => `
      <div class="job-row">
        <div class="meta">
          <strong>${esc(job.kind)} <span class="pill status ${job.status === 'done' ? 'hint' : 'flagged'}">${esc(job.status)}</span></strong>
          <small>${esc(job.id)} · ${job.seconds}s${job.result?.steps > 1 ? ` · ${job.result.steps} steps` : ''}
            ${job.result?.index ? ` · ${job.result.index.questions} question(s) indexed` : ''}</small>
        </div>
        <div class="row">
          <button class="btn ghost" data-rerun="${esc(job.id)}">Re-run</button>
          <details><summary class="mini">log</summary>
            <pre class="log">${esc((job.log_tail || []).slice(-12).join('\n'))}</pre></details>
        </div>
      </div>`).join('') : empty('No jobs yet — run a batch in Library.');
  } catch (error) {
    list.innerHTML = empty(`Could not load jobs: ${error.message}`);
  }
}

async function rerunJob(id) {
  try {
    const started = await api(`/api/jobs/${id}/rerun`, { method: 'POST', body: {} });
    toast(`Re-running as ${started.job}`);
    showScreen('library');
  } catch (error) {
    toast(`Could not re-run: ${error.message}`);
  }
}

async function toggleWatch(start) {
  const status = $('#watch-status');
  try {
    if (!start) {
      const out = await api('/api/watch', { method: 'POST', body: { action: 'stop' } });
      status.textContent = out.watching ? 'Still watching.' : 'Stopped.';
      return;
    }
    const input = ($('#watch-input').value || '').trim() || standardFolders().input;
    if (!input) { status.textContent = 'The input folder is not known yet.'; return; }
    const out = await api('/api/watch', { method: 'POST',
      body: { input, output: chosenFolders().output || undefined, interval: 20 } });
    status.textContent = `Watching ${out.input} → ${out.output} every ${out.interval}s. New PDFs batch automatically.`;
  } catch (error) {
    status.textContent = `Watch failed: ${error.message}`;
  }
}

async function exportDocx() {
  const status = $('#export-status');
  status.textContent = 'Building DOCX from the current draft…';
  try {
    const draft = state.draft || { questions: [] };
    if (!draft.questions?.length) { status.textContent = 'The draft is empty — add questions in the Bank first.'; return; }
    const started = await api('/api/booklet', { method: 'POST', body: {
      schema: 'booklet_request/1', title: draft.title || 'Question booklet', subtitle: draft.subtitle || '',
      answers: draft.answers || 'after_each', questions: draft.questions, format: 'docx',
      options: { fit: $('#booklet-fit')?.value || 'flow' } } });
    const job = await waitForJob(started.job);
    const result = job.result || {};
    if (job.status !== 'done' || !result.docx) throw new Error(job.error || 'export failed');
    status.innerHTML = `DOCX ready: <a class="btn ghost" href="files/${esc(result.docx_batch_rel || '')}" download>download</a>`;
  } catch (error) {
    status.textContent = `DOCX export failed: ${error.message}`;
  }
}

async function waitForJob(id) {
  for (let i = 0; i < 240; i += 1) {
    const job = await api(`/api/jobs/${id}`);
    if (job.status === 'done' || job.status === 'failed') return job;
    await new Promise((r) => setTimeout(r, 1000));
  }
  return { status: 'failed', error: 'timed out' };
}

/* Add every question the filters currently show -- the one-by-one clicking was the slow part. */
async function addFilteredToDraft() {
  const rows = filteredRows().filter((row) => row.listable);
  if (!rows.length) { toast('Nothing shown to add'); return; }
  await addToDraft(rows.map((row) => row.id));
  toast(`Added ${rows.length} question(s) to the draft`);
}

async function randomSet() {
  const rows = filteredRows().filter((row) => row.listable);
  const pick = rows.sort(() => Math.random() - 0.5).slice(0, 10);
  if (!pick.length) { toast('Nothing shown to pick from'); return; }
  await addToDraft(pick.map((row) => row.id));
  toast(`Added a random ${pick.length} from the current filters`);
}

/* ------------------------------------------------------------------ review */
function renderReview() {
  const flagged = (state.index?.questions || []).filter((row) => !row.listable);
  $('#review-count').textContent = String(flagged.length);
  const topics = [...new Set((state.index?.questions || []).map((row) => row.topic).filter(Boolean))].sort();
  $('#review-list').innerHTML = flagged.length ? flagged.map((row) => `
    <article class="qcard">
      <div class="thumb" data-preview="${esc(row.id)}">
        ${cropUrl(row, 'qp') ? `<img loading="lazy" alt="Question crop" src="${esc(cropUrl(row, 'qp'))}">` : ''}
      </div>
      <div class="body">
        <strong>${esc(row.component)} ${esc(row.canonical_question)} · ${esc(row.session)}</strong>
        <div class="facts">
          <span class="pill status flagged">${esc(row.status)}</span>
          ${row.verified ? '<span class="pill verified">&#10003; MS-verified</span>' : ''}
          ${row.review_reason ? `<span class="pill ghost count">${esc(row.review_reason)}</span>` : ''}
          ${(row.review_reasons || []).map((r) => `<span class="pill ghost count">${esc(r)}</span>`).join('')}
        </div>
        <span class="src">classifier said ${esc(row.batch_topic || row.topic)}</span>
        <label class="field"><span>Assign topic</span>
          <select data-assign-select="${esc(row.id)}">
            <option value="">choose…</option>
            ${topics.map((t) => `<option value="${esc(t)}">${esc(t)}</option>`).join('')}
          </select></label>
        <div class="actions">
          <button class="btn primary" data-assign="${esc(row.id)}">Assign</button>
          <button class="btn ghost" data-dismiss="${esc(row.id)}">Dismiss</button>
          <button class="btn ghost" data-preview="${esc(row.id)}">Preview</button>
          ${state.ai?.enabled ? `<button class="btn ghost" data-suggest="${esc(row.id)}"
              title="Ask ${esc(state.ai.model || state.ai.provider)} for the three most likely topics from ${esc(row.board)} ${esc(row.code)}'s own list. Suggestions only — nothing is assigned for you."
              ${state.aiBusy[row.id] ? 'disabled' : ''}>${state.aiBusy[row.id] ? 'Asking…' : 'Suggest topic'}</button>` : ''}
        </div>
        ${state.ai?.enabled ? `<div class="ai" data-ai-slot="${esc(row.id)}">${suggestionBlock(row.id)}</div>` : ''}
      </div>
    </article>`).join('') : empty('Nothing flagged — every indexed question carries a topic.');
}

/* ------------------------------------------------------- review: suggest a topic
   The offline classifier is authoritative. This helper exists for the rows it would NOT claim
   (flagged above), and its output is a shortlist a reviewer clicks -- it never assigns. Server side
   the same rule is enforced in core/topic_suggest.refusal_for_row, so a stale page cannot ask about
   a row the classifier already owns. */
function suggestionBlock(id) {
  const payload = state.aiShown[id];
  if (!payload) return '';
  if (payload.error) return `<span class="src warn">${esc(payload.error)}</span>`;
  const when = payload.cached ? `cached ${esc(payload.created_utc || '')}` : esc(payload.created_utc || '');
  return `
    <div class="ai-candidates">
      ${(payload.suggestions || []).map((s) => `
        <button class="btn ghost ai-candidate" data-use-suggest="${esc(id)}" data-topic="${esc(s.topic)}"
                title="Fill the Assign control with this topic (nothing is submitted)">
          <strong>${esc(s.topic)}</strong>${s.reason ? `<span>${esc(s.reason)}</span>` : ''}
        </button>`).join('')}
    </div>
    <span class="src">via ${esc(payload.model || payload.provider || 'model')} · ${when}
      ${(payload.dropped || []).length ? ` · ignored ${payload.dropped.length} invented topic(s)` : ''}
      · suggestions only, nothing assigned</span>`;
}

function aiSlot(id) {
  return document.querySelector(`[data-ai-slot="${CSS.escape(id)}"]`);
}

async function suggestTopic(id) {
  if (state.aiBusy[id]) return;            // a second click must not bill the model twice
  state.aiBusy[id] = true;
  const slot = aiSlot(id);
  if (slot) slot.innerHTML = '<span class="src">asking the model…</span>';
  try {
    state.aiShown[id] = await api('/api/ai/suggest', { method: 'POST', body: { id } });
    toast(`Suggested ${state.aiShown[id].suggestions?.length || 0} topic(s) — nothing assigned`);
  } catch (error) {
    // the refusal messages are the feature: say exactly why (not configured / already claimed / no text)
    state.aiShown[id] = { error: error.message };
    toast(`No suggestion: ${error.message}`);
  } finally {
    state.aiBusy[id] = false;
    if (aiSlot(id)) aiSlot(id).innerHTML = suggestionBlock(id);
    // the button label ("Asking…") lives in the actions row, so repaint that card only
    const select = document.querySelector(`[data-assign-select="${CSS.escape(id)}"]`);
    const button = document.querySelector(`[data-suggest="${CSS.escape(id)}"]`);
    if (button) button.disabled = false;
    if (button) button.textContent = 'Suggest topic';
  }
}

/* Pre-fill, never submit: the reviewer still presses Assign. The candidate's topic may not be one of
   the options the select was built with (the select lists topics already present in the index), so it
   is added as an option first. */
function useSuggestion(id, topic) {
  const select = document.querySelector(`[data-assign-select="${CSS.escape(id)}"]`);
  if (!select) return;
  if (![...select.options].some((option) => option.value === topic)) {
    const option = document.createElement('option');
    option.value = topic;
    option.textContent = topic;
    select.appendChild(option);
  }
  select.value = topic;
  select.focus();
  select.classList.add('filled');
  toast(`Filled Assign with “${topic}” — press Assign to record it`);
}

async function assignTopic(id, topic) {
  return overrideRequest({ id, topic }, `Assigned ${topic}`);
}

async function dismissRow(id) {
  return overrideRequest({ id, dismiss: true, reason: 'dismissed in Review' }, 'Dismissed');
}

/* An override is written first and the index is rebuilt after it. If the rebuild refuses (a
   catalogue gap, or nothing to rebuild from), the override file is still on disk — say both facts
   rather than letting the rejection disappear. */
async function overrideRequest(body, success) {
  let written = null;
  try {
    written = await api('/api/overrides', { method: 'POST', body });
    toast(success);
  } catch (error) {
    showNotice('Override refused', `${error.message}${error.payload && error.payload.notes
      ? ` — ${(error.payload.notes || []).join('; ')}` : ''}`);
    return null;
  }
  try {
    await loadIndex(true);
  } catch (error) {
    showNotice('Override saved, index not rebuilt',
      `${error.message}${(error.payload?.notes || []).length ? ` — ${error.payload.notes.join('; ')}` : ''}. `
      + 'The override is in topic_overrides.json and applies on the next successful build.');
  }
  renderBank(); renderReview(); renderBuilder();
  return written;
}

function showNotice(title, message) {
  const host = $('#review-notice');
  if (!host) { toast(`${title}: ${message}`); return; }
  host.innerHTML = `<div class="card notice"><h2>${esc(title)}</h2><p class="hint">${esc(message)}</p></div>`;
}

/* ------------------------------------------------------------------ events */
function wire() {
  $$('.tab').forEach((tab) => tab.addEventListener('click', () => showScreen(tab.dataset.screen)));
  $('#theme-toggle').addEventListener('click', () => {
    const dark = document.documentElement.dataset.theme === 'dark';
    document.documentElement.dataset.theme = dark ? 'light' : 'dark';
    $('#theme-toggle').textContent = dark ? 'Dark' : 'Light';
    try { localStorage.setItem('theme', dark ? 'light' : 'dark'); } catch {}
  });

  $('#detect-btn').addEventListener('click', runDetection);
  const runAll = $('#run-all-btn');
  if (runAll) runAll.addEventListener('click', () => startBatch(''));
  const indexBtn = $('#index-btn');
  if (indexBtn) indexBtn.addEventListener('click', rebuildIndex);
  const openOut = $('#open-out-btn');
  if (openOut) openOut.addEventListener('click', openOutputFolder);
  const fromFile = $('#booklet-file-btn');
  if (fromFile) fromFile.addEventListener('click', buildFromBookletFile);
  const reset = $('#folders-reset');
  if (reset) reset.addEventListener('click', () => {
    $('#detect-input').value = '';
    $('#batch-output').value = '';
    $('#index-dir').value = '';
    $('#watch-input').value = '';
    paintFolders();
    toast('Using the standard input/ and output/ folders');
  });
  const watchStart = $('#watch-start');
  if (watchStart) watchStart.addEventListener('click', () => toggleWatch(true));
  const watchStop = $('#watch-stop');
  if (watchStop) watchStop.addEventListener('click', () => toggleWatch(false));
  const addFiltered = $('#add-filtered');
  if (addFiltered) addFiltered.addEventListener('click', addFilteredToDraft);
  const randomBtn = $('#random-set');
  if (randomBtn) randomBtn.addEventListener('click', randomSet);
  const coverageToggle = $('#coverage-toggle');
  if (coverageToggle) coverageToggle.addEventListener('click', async () => {
    const panel = $('#coverage-panel');
    panel.hidden = !panel.hidden;
    if (!panel.hidden && !state.coverage) await loadCoverage();
  });
  const docxBtn = $('#docx-btn');
  if (docxBtn) docxBtn.addEventListener('click', exportDocx);
  for (const id of ['filter-year', 'filter-sort']) {
    const el = $(`#${id}`);
    if (el) el.addEventListener('change', () => {
      state.filters[id === 'filter-year' ? 'year' : 'sort'] = el.value;
      savePrefs();
      renderBank();
    });
  }
  document.addEventListener('click', async (event) => {
    const rerun = event.target.closest('[data-rerun]');
    if (rerun) { event.preventDefault(); rerunJob(rerun.dataset.rerun); }
  });
  // keyboard: / focuses search, 1-5 switch screens, Escape closes the dialog (handled above)
  document.addEventListener('keydown', (event) => {
    if (event.target.matches('input, textarea, select')) return;
    if (event.key === '/') { event.preventDefault(); $('#filter-search')?.focus(); }
    const screens = { 1: 'library', 2: 'bank', 3: 'builder', 4: 'review', 5: 'tools' };
    if (screens[event.key]) showScreen(screens[event.key]);
  });
  $('#detect-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') runDetection(); });

  document.addEventListener('click', async (event) => {
    const target = event.target.closest('[data-board],[data-topic],[data-preview],[data-add],[data-run-batch],'
      + '[data-subject],[data-move],[data-drop],[data-assign],[data-dismiss],[data-next],[data-back],[data-close],'
      + '[data-suggest],[data-use-suggest],[data-show-more]');
    if (!target) return;
    if (target.dataset.close) { closePreview(); return; }
    if (target.dataset.board !== undefined && target.dataset.board !== null && target.hasAttribute('data-board')
        && !target.hasAttribute('data-run-batch')) {
      state.filters.board = target.dataset.board; renderBank(); return;
    }
    if (target.hasAttribute('data-run-batch')) { startBatch(target.dataset.board); return; }
    if (target.dataset.topic !== undefined && target.hasAttribute('data-topic')) {
      state.filters.topic = state.filters.topic === target.dataset.topic ? '' : target.dataset.topic;
      renderBank(); return;
    }
    if (target.hasAttribute('data-show-more')) {
      event.preventDefault();
      state.filters.shown = (state.filters.shown || BANK_PAGE) + BANK_PAGE;
      renderBankCards();
      return;
    }
    if (target.hasAttribute('data-suggest')) { event.preventDefault(); await suggestTopic(target.dataset.suggest); return; }
    if (target.hasAttribute('data-use-suggest')) {
      event.preventDefault();
      useSuggestion(target.dataset.useSuggest, target.dataset.topic);
      return;
    }
    if (target.hasAttribute('data-preview')) { openPreview(target.dataset.preview); return; }
    if (target.hasAttribute('data-add')) { await addToDraft(target.dataset.add); return; }
    if (target.hasAttribute('data-subject')) {
      const [board, code] = target.dataset.subject.split(' ');
      state.draft = await api('/api/draft', { method: 'POST', body: { board, code } });
      renderBuilder(); return;
    }
    if (target.hasAttribute('data-move')) {
      const index = Number(target.dataset.move), dir = Number(target.dataset.dir);
      const rows = [...(state.draft.questions || [])];
      const swap = index + dir;
      if (swap < 0 || swap >= rows.length) return;
      [rows[index], rows[swap]] = [rows[swap], rows[index]];
      state.draft = await api('/api/draft', { method: 'POST', body: { questions: rows } });
      renderBuilder(); return;
    }
    if (target.hasAttribute('data-drop')) {
      state.draft = await api('/api/draft', { method: 'POST', body: { remove: [target.dataset.drop] } });
      renderBuilder(); return;
    }
    if (target.hasAttribute('data-assign')) {
      const id = target.dataset.assign;
      const select = $(`[data-assign-select="${CSS.escape(id)}"]`);
      if (!select?.value) { toast('Choose a topic first'); return; }
      await assignTopic(id, select.value); return;
    }
    if (target.hasAttribute('data-dismiss')) { await dismissRow(target.dataset.dismiss); return; }
    if (target.dataset.next) { setStep(Number(target.dataset.next)); return; }
    if (target.dataset.back) { setStep(Number(target.dataset.back)); return; }
  });

  ['#filter-subject', '#filter-topic', '#filter-session'].forEach((sel) => {
    $(sel).addEventListener('change', () => {
      state.filters.subject = $('#filter-subject').value;
      state.filters.topic = $('#filter-topic').value;
      state.filters.session = $('#filter-session').value;
      renderBank();
    });
  });
  // Typing must not rebuild the dropdowns and the syllabus tree on every keystroke (they do not
  // depend on the query), and it must not run more often than a screen paints. Both fixes are here:
  // the cheap half of the render, and a 130 ms debounce so a fast typist gets one render, not eight.
  $('#filter-search').addEventListener('input', debounce(() => {
    state.filters.q = $('#filter-search').value;
    state.filters.shown = BANK_PAGE;
    renderBankCards();
  }, 130));
  $('#filter-listable').addEventListener('change', () => { state.filters.listable = $('#filter-listable').checked; renderBank(); });
  $('#bank-reset').addEventListener('click', () => {
    state.filters = { board: '', subject: '', topic: '', session: '', year: '', sort: 'board',
                      q: '', listable: true, shown: BANK_PAGE };
    $('#filter-search').value = ''; $('#filter-listable').checked = true;
    renderBank();
  });

  $('#stepper').addEventListener('click', (e) => {
    const li = e.target.closest('li[data-step]');
    if (li) setStep(Number(li.dataset.step));
  });
  $('#booklet-title').addEventListener('change', async () => {
    state.draft = await api('/api/draft', { method: 'POST', body: { title: $('#booklet-title').value } });
  });
  $('#booklet-subtitle').addEventListener('change', async () => {
    state.draft = await api('/api/draft', { method: 'POST', body: { subtitle: $('#booklet-subtitle').value } });
  });
  $$('input[name=answers]').forEach((radio) => radio.addEventListener('change', async () => {
    state.draft = await api('/api/draft', { method: 'POST', body: { answers: radio.value } });
    summarize();
  }));
  $('#generate-btn').addEventListener('click', generate);
  $('#preview-add').addEventListener('click', async (e) => {
    const id = e.target.closest('[data-add]')?.dataset.add;
    if (id) { await addToDraft(id); $('#preview').hidden = true; }
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePreview(); });
}

/* ------------------------------------------------------------------ boot */
async function boot() {
  const prefs = loadPrefs();
  try { document.documentElement.dataset.theme = localStorage.getItem('theme') || 'light'; } catch {}
  $('#theme-toggle').textContent = document.documentElement.dataset.theme === 'dark' ? 'Light' : 'Dark';
  wire();
  showScreen((location.hash || '#library').slice(1));
  try {
    // the script's own input/ and output/ folders: shown on the run card, used by every request
    state.health = await api('/api/health');
    paintFolders();
    // Scan the input folder on open, unprompted -- the user's rule is that the app reads whatever has
    // been dropped into `input/` without being asked. Deliberately NOT awaited: the scan runs while the
    // rest of the boot (catalogue, index, draft) loads, and its results land in the Library whenever
    // they arrive. The server caches the answer per folder fingerprint, so opening the app twice in a
    // row costs a directory walk, not a fresh detection.
    state.autoScan = runDetection();
    await loadCatalogue();
    // AI assist is opt-in: when it is not configured this returns enabled:false and the Review
    // screen simply has no Suggest button (the status hint says how to turn it on).
    try { state.ai = await api('/api/ai/status'); } catch { state.ai = { enabled: false }; }
    const index = await loadIndex();
    if (index.counts?.questions) {
      renderBank();
      renderBuilder();
      renderReview();
    } else {
      $('#bank-cards').innerHTML = empty('No index yet. In Library: scan a folder, run a batch, '
        + 'and the server indexes it automatically.');
      $('#review-list').innerHTML = empty('Nothing to review yet.');
      $('#builder-subjects').innerHTML = empty('Index the bank first.');
    }
    await loadDraft();
    renderBuilder();
  } catch (error) {
    toast(`Server not reachable: ${error.message}`);
    $('#bank-cards').innerHTML = empty('Could not reach the API. Is server.py running?');
  }
}

document.addEventListener('DOMContentLoaded', boot);
