#!/usr/bin/env python3
from pathlib import Path
"""
UNIVERSAL CAMBRIDGE EXAM TOPICAL GENERATOR - IGCSE + A-LEVEL
Official Syllabus Integration for 22 Subjects

Supports per prompt:
IGCSE: Chemistry 0620, Physics 0625, Biology 0610, Mathematics 0580,
       Computer Science 0478, Economics 0455, Business Studies 0450,
       Literature in English 0475, History 0470, ICT 0417, Geography 0460

A-Level: Chemistry 9701, Physics 9702, Mathematics 9709, Further Mathematics 9231,
         Computer Science 9618, Economics 9708, Business 9609,
         English Literature 9695, History 9489, Information Technology 9626,
         Geography 9696, Biology 9700 (extra)

Architecture:
Level → Subject → Syllabus Code → Syllabus Year → Official Topic Hierarchy
→ Question Classification → Detailed Topics → JSON → Major Topic → Point System → One Winning Folder → QP+MS WEBP → Validation

- Official Cambridge syllabus documents are source of truth
- Major topics = high-level official structure
- Detailed = sub-topics
- JSON topic[0] is the point-system routing winner; its exact unmodified string names the folder
- Point-based winner, single-folder, no duplication
- Syllabus-year awareness
- Universal cropping engine preserved
"""

import argparse

def print_banner():
    print("""
=================================================================
    UNIVERSAL CAMBRIDGE TOPICAL GENERATOR - OFFICIAL SYLLABUS
    IGCSE: 0620 Chem, 0625 Phys, 0610 Bio, 0580 Math, 0478 CS,
           0455 Econ, 0450 Business, 0475 Lit, 0470 Hist, 0417 ICT, 0460 Geog
    A-LEVEL: 9701 Chem (Ref), 9702 Phys, 9709 Math, 9231 Further Math,
             9618 CS, 9708 Econ, 9609 Business, 9695 Lit, 9489 Hist,
             9626 IT, 9696 Geog, 9700 Bio
=================================================================
    Official syllabus is source of truth - Major → Sub-topic hierarchy preserved
    Level → Code → Year → Config → Point Winner → JSON topic[0] → Exact Same Folder
=================================================================
""")

def main():
    parser = argparse.ArgumentParser(description="ExamVoid Topical Generator - Official Syllabus")
    parser.add_argument("--input", "-i", default=str(Path(__file__).resolve().parent / "input"),
                        help="Folder holding the PDFs (default: input/ beside this script)")
    parser.add_argument("--output", "-o", default=str(Path(__file__).resolve().parent / "output"),
                        help="Folder for the crops and packs (default: output/ beside this script)")
    parser.add_argument("--validate", action="store_true")
    parser.add_argument("--universal-batch", action="store_true",
                        help="Run the universal batch router (AQA/Edexcel/IB/SAT) instead of the Cambridge topical pipeline")
    parser.add_argument("--include-sat", dest="include_sat", action="store_true", default=True,
                        help="Process SAT papers (DEFAULT ON; --no-include-sat skips them)")
    parser.add_argument("--no-include-sat", dest="include_sat", action="store_false",
                        help="Skip SAT papers in this run")
    parser.add_argument("--include-ib", dest="include_ib", action="store_true", default=True,
                        help="Process IB papers (DEFAULT ON; --no-include-ib skips them)")
    parser.add_argument("--no-include-ib", dest="include_ib", action="store_false",
                        help="Skip IB papers in this run")
    parser.add_argument("--universal-limit-per-paper", type=int, default=0,
                        help="Debug/proof limiter for universal batch; 0 means all segments")
    parser.add_argument("--enable-ocr", action="store_true",
                        help="Attempt optional Tesseract OCR for image-only universal-batch PDFs")
    parser.add_argument("--clean", action="store_true")
    parser.add_argument("--demo", action="store_true", help="Generate demo for all required subjects (IGCSE+A-Level)")
    parser.add_argument("--demo-all", action="store_true", help="Generate demo for all configured Cambridge subjects")
    parser.add_argument("--dry-run", action="store_true", help="plan only (delegated)")
    parser.add_argument("--resume", action="store_true", help="skip completed bundles (delegated)")
    parser.add_argument("--retry-failed", action="store_true", help="retry FAILED bundles (delegated)")
    parser.add_argument("--workers", type=int, default=2, help="bounded workers (delegated)")
    parser.add_argument("--full-ram", action="store_true",
                        help="use full in-memory crop path; default is bundled low-RAM streaming")
    parser.add_argument("--full-auto", action="store_true", default=True,
                        help="DEFAULT ON: never route to review_required — crop + "
                             "categorize + sort everything")
    parser.add_argument("--no-full-auto", action="store_true", default=False,
                        help="Restore fail-closed review routing")
    parser.add_argument("--classification-memory", default=None,
                        help="SQLite indexed classification-memory path for the guarded production path")
    parser.add_argument("--write-high-confidence-memory", action="store_true", default=False,
                        help="OPT-IN buffered high-confidence memory writes after a paper completes")
    parser.add_argument("--memory-high-confidence-threshold", type=float, default=0.95,
                        help="minimum confidence for OPT-IN high-confidence memory writes")
    args = parser.parse_args()
    if not 0.0 <= float(args.memory_high_confidence_threshold) <= 1.0:
        parser.error("--memory-high-confidence-threshold must be between 0 and 1")

    if args.universal_batch:
        print_banner()
        print("[Main] running universal batch router (AQA / Edexcel / IB / SAT)")
        from tools.run_universal_batch import run_batch
        audit = run_batch(
            Path(args.input),
            Path(args.output),
            include_sat=args.include_sat,
            include_ib=args.include_ib,
            limit_per_paper=args.universal_limit_per_paper,
            enable_ocr=args.enable_ocr,
        )
        counts = audit.get("counts", {})
        print(f"[Main] universal batch counts: {counts}")
        if counts.get("render_fail", 0):
            return 1
        if counts.get("review_required", 0):
            return 2
        return 0

    # Mega-spec (2026-08-12): the guarded runner IS the production path. The
    # 600-line in-process body that used to sit behind --legacy was deleted on
    # 2026-09-22 (Phase B4: untested, undocumented, no .bat or doc used it);
    # main.py is a thin dispatcher: banner + --universal-batch + guarded delegation.
    print_banner()
    if args.demo or args.demo_all:
        # Demo PDFs are smoke fixtures for the guarded path (tools/demo_pdfs.py).
        input_dir = Path(args.input)
        input_dir.mkdir(parents=True, exist_ok=True)
        if not list(input_dir.rglob("*.pdf")):
            print("[Main] Demo mode: generating official-syllabus-based demo PDFs")
            from tools.demo_pdfs import generate_demo_pdfs
            generate_demo_pdfs(input_dir, all_subjects=args.demo_all)
    print("[Main] delegating to the guarded production path (run_guarded)")
    import run_guarded as _rg
    import sys as _sys
    argv = ["run_guarded.py", "--input", args.input, "--output", args.output]
    if args.clean:
        argv.append("--clean")
    # --validate here means "process AND validate": the guarded run stages
    # S0-S8 include final validation on every execution, so the flag is
    # intentionally not forwarded as audit-only (that would audit an empty
    # tree before processing). Audit-only usage: run_guarded --output O --validate.
    if args.validate:
        print("[Main] --validate: validation is built into every guarded run "
              "(stage S8); for audit-only use run_guarded --output O --validate")
    if args.dry_run:
        argv.append("--dry-run")
    if args.resume:
        argv.append("--resume")
    if args.retry_failed:
        argv.append("--retry-failed")
    if getattr(args, "full_auto", True):
        argv.append("--full-auto")
    if getattr(args, "no_full_auto", False):
        argv.append("--no-full-auto")
    if args.classification_memory:
        argv += ["--classification-memory", str(args.classification_memory)]
    if args.write_high_confidence_memory:
        argv.append("--write-high-confidence-memory")
    argv += ["--memory-high-confidence-threshold", str(args.memory_high_confidence_threshold)]
    if not args.full_ram:
        argv.append("--low-ram")
    argv += ["--workers", str(args.workers)]
    _sys.argv = argv
    _rg.main()
    return


if __name__ == "__main__":
    raise SystemExit(main() or 0)
