"""Engine #4 — question papers whose top-level units are "Exercise N" headings.

Older Cambridge language papers (e.g. 0510/0511 English as a Second Language up to
the 2010s) have no numbered top-level questions at all: each unit starts with a bold
left-margin heading ``Exercise 1`` … ``Exercise 7`` followed by a passage and lettered
parts (a), (b) … The locked vector engine looks for margin NUMBERS, so S2 reported
"0 questions" for these papers although the text layer is complete (measured on
0510_s11_qp_12/22 and 0510_s15_qp_12: headings at x0/width = 0.083).

Contract (same shape as the OCR engine #2 and the RTL engine #3):
  * ``should_handle(pdf)`` — engages only when the document carries at least two
    left-margin ``Exercise N`` headings. It is called only after the locked engine
    returned nothing, so papers the locked engine already splits never get here.
  * ``crop_exercise_paper(pdf, spool_dir, paper_code)`` — takes the contiguous
    Exercise 1..N sequence and hands it to the locked module's OWN segmenting /
    rendering / stitching / saving functions, so crop geometry, width and WebP output
    are the locked behaviour. Exercise N becomes question N. Returns the low-ram crop
    payloads S2→S5 already consume, or [] with the reason in ``last_reason()``.
"""
from __future__ import annotations

import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any, List, Optional, Tuple

import fitz  # PyMuPDF

from core.vector_first_cropper import (
    Marker, _looks_like_header_or_footer, extract_text_for_segment, image_ink_fraction,
    lines_from_page, render_clip, save_webp_tiled, segment_for_marker, stitch,
    trim_vertical_white,
)

EXERCISE_HEADING = re.compile(r"^\s*(?:Exercise|EXERCISE)\s+(\d{1,2})\s*$")
LEFT_MARGIN_MAX = 0.20          # same left-body limit the locked engine uses
MIN_HEADINGS = 2

_LAST_REASON = ""


def last_reason() -> str:
    return _LAST_REASON


def exercise_candidates(doc: fitz.Document) -> List[Marker]:
    out: List[Marker] = []
    for pno, page in enumerate(doc):
        width = max(1.0, float(page.rect.width))
        for line in lines_from_page(page):
            m = EXERCISE_HEADING.match(line.text)
            if not m or line.x0 / width > LEFT_MARGIN_MAX:
                continue
            if _looks_like_header_or_footer(line, page):
                continue
            number = int(m.group(1))
            if 1 <= number <= 30:
                out.append(Marker(number, pno, line.y0, line.y1, line.x0, line.text.strip(),
                                  1.2, "left-margin Exercise heading"))
    out.sort(key=lambda mk: (mk.page, mk.y0))
    return out


def exercise_markers(doc: fitz.Document) -> Tuple[List[Marker], List[Marker]]:
    """(selected contiguous Exercise 1..N sequence, all candidates)."""
    candidates = exercise_candidates(doc)
    selected: List[Marker] = []
    expected = 1
    for marker in candidates:
        if marker.number == expected:
            selected.append(marker)
            expected += 1
    return selected, candidates


def should_handle(pdf_path: str | Path) -> Tuple[bool, str]:
    try:
        with fitz.open(str(pdf_path)) as doc:
            selected, candidates = exercise_markers(doc)
    except Exception as exc:  # unreadable document: not ours to judge
        return False, f"unreadable ({type(exc).__name__})"
    if len(selected) < MIN_HEADINGS:
        return False, f"{len(candidates)} Exercise heading(s), no 1..N sequence of {MIN_HEADINGS}+"
    return True, f"Exercise 1..{len(selected)} headings"


def crop_exercise_paper(pdf_path: str | Path, *, spool_dir: Optional[Path] = None,
                        paper_code: str = "", quality: int = 95) -> List[Any]:
    """Crop an Exercise-structured paper with the locked renderer."""
    global _LAST_REASON
    pdf_path = Path(pdf_path)
    spool_root = Path(spool_dir) if spool_dir else pdf_path.parent
    crop_root = spool_root / "exercise_qp" / pdf_path.stem
    crop_root.mkdir(parents=True, exist_ok=True)
    out: List[Any] = []
    with fitz.open(str(pdf_path)) as doc:
        markers, candidates = exercise_markers(doc)
        if len(markers) < MIN_HEADINGS:
            _LAST_REASON = (f"EXERCISE_NO_SEQUENCE: {len(candidates)} heading(s) but no "
                            f"Exercise 1..N sequence")
            print(f"    [exercise] {_LAST_REASON}")
            return []
        print(f"    [exercise] headings: Exercise 1..{len(markers)} "
              f"({', '.join(f'Q{m.number}@p{m.page + 1}' for m in markers)})")
        for index, marker in enumerate(markers):
            next_marker = markers[index + 1] if index + 1 < len(markers) else None
            segments = segment_for_marker(doc, marker, next_marker)
            images = []
            pages: List[int] = []
            text_parts: List[str] = []
            for segment in segments:
                image = trim_vertical_white(render_clip(doc[segment.page], segment.y0, segment.y1))
                images.append(image)
                pages.append(segment.page + 1)
                text_parts.append(extract_text_for_segment(doc[segment.page], segment.y0, segment.y1))
            assembled = stitch(images)
            paths = save_webp_tiled(assembled, crop_root / f"Q{marker.number}.webp", quality=quality)
            text = "\n".join(part for part in text_parts if part)
            warnings: List[str] = []
            if image_ink_fraction(assembled) < 0.002:
                warnings.append("crop has almost no ink")
            out.append(SimpleNamespace(
                question_number=f"Q{marker.number}", number_int=marker.number,
                paper_code=paper_code,
                images=[], assembled_image=None,
                text=text, marks=sum(int(mm) for mm in re.findall(r"\[(\d+)\]", text)),
                pages=pages, needs_review=bool(warnings), qc_reasons=warnings,
                _spool_png=str(paths[0]), _spool_paths=[str(p) for p in paths],
                exercise_engine=True,
            ))
    _LAST_REASON = ""
    print(f"    [exercise] engine #4 extracted {len(out)} question(s) from {pdf_path.name} "
          f"(locked renderer, Exercise headings)")
    return out


# ---------------------------------------------------------------------------
# Engine #5 — "Section N" papers with no question numbers at all (7184 P2:
# "القسم 1" / "القسم 2", each a choice of essay titles (a)-(d) followed by
# blank answer pages).  Section N becomes question N; the crop runs from the
# heading to the first dotted answer line on that page (answer pages dropped).
# Engages only when every earlier engine returned nothing.
# ---------------------------------------------------------------------------
SECTION_HEADING = re.compile(
    r"^\s*(?:(?:Section|SECTION)\s+(?P<a>\d{1,2})|(?P<b>\d{1,2})\s*القسم|القسم\s*(?P<c>\d{1,2}))\s*$")
_DOTS = re.compile(r"^[.\u2026\s]{20,}$")


def section_markers(doc: fitz.Document) -> List[Marker]:
    found: List[Marker] = []
    for pno, page in enumerate(doc):
        if pno == 0:
            continue                                   # cover instructions
        for line in lines_from_page(page):
            m = SECTION_HEADING.match(line.text)
            if not m or _looks_like_header_or_footer(line, page):
                continue
            number = int(m.group("a") or m.group("b") or m.group("c"))
            found.append(Marker(number, pno, line.y0, line.y1, line.x0, line.text.strip(),
                                1.1, "Section heading"))
    found.sort(key=lambda mk: (mk.page, mk.y0))
    selected: List[Marker] = []
    for marker in found:
        if marker.number == len(selected) + 1 and (not selected or marker.page > selected[-1].page):
            selected.append(marker)
    return selected


def should_handle_sections(pdf_path: str | Path) -> Tuple[bool, str]:
    try:
        with fitz.open(str(pdf_path)) as doc:
            markers = section_markers(doc)
    except Exception as exc:
        return False, f"unreadable ({type(exc).__name__})"
    if len(markers) < MIN_HEADINGS:
        return False, f"{len(markers)} Section heading(s), no 1..N sequence of {MIN_HEADINGS}+"
    return True, f"Section 1..{len(markers)} headings"


def crop_section_paper(pdf_path: str | Path, *, spool_dir: Optional[Path] = None,
                       paper_code: str = "", quality: int = 95) -> List[Any]:
    global _LAST_REASON
    pdf_path = Path(pdf_path)
    spool_root = Path(spool_dir) if spool_dir else pdf_path.parent
    crop_root = spool_root / "section_qp" / pdf_path.stem
    crop_root.mkdir(parents=True, exist_ok=True)
    out: List[Any] = []
    with fitz.open(str(pdf_path)) as doc:
        markers = section_markers(doc)
        if len(markers) < MIN_HEADINGS:
            _LAST_REASON = "SECTION_NO_SEQUENCE: no Section 1..N heading sequence"
            return []
        print(f"    [section] headings: Section 1..{len(markers)} "
              f"({', '.join(f'Q{m.number}@p{m.page + 1}' for m in markers)})")
        for marker in markers:
            page = doc[marker.page]
            lines = [ln for ln in lines_from_page(page) if not _looks_like_header_or_footer(ln, page)]
            below = [ln for ln in lines if ln.y0 > marker.y1]
            dots = [ln.y0 for ln in below if _DOTS.match(ln.text)]
            content = [ln for ln in below if not _DOTS.match(ln.text)
                       and (not dots or ln.y0 < min(dots))]
            y1 = (max(ln.y1 for ln in content) + 6.0) if content else (marker.y1 + 20.0)
            # the heading may sit a few points below the first option line on
            # RTL pages (visual order); start at the highest line of the block
            y0 = min([marker.y0] + [ln.y0 for ln in content if ln.y0 < marker.y0]) - 6.0
            image = trim_vertical_white(render_clip(page, y0, y1))
            text = extract_text_for_segment(page, y0, y1)
            paths = save_webp_tiled(image, crop_root / f"Q{marker.number}.webp", quality=quality)
            warnings: List[str] = []
            if image_ink_fraction(image) < 0.002:
                warnings.append("crop has almost no ink")
            out.append(SimpleNamespace(
                question_number=f"Q{marker.number}", number_int=marker.number,
                paper_code=paper_code, images=[], assembled_image=None,
                text=text, marks=sum(int(mm) for mm in re.findall(r"\[(\d+)\]", text)),
                pages=[marker.page + 1], needs_review=bool(warnings), qc_reasons=warnings,
                _spool_png=str(paths[0]), _spool_paths=[str(p) for p in paths],
                exercise_engine=True,
            ))
    _LAST_REASON = ""
    print(f"    [section] engine #5 extracted {len(out)} question(s) from {pdf_path.name}")
    return out
