"""Engine #3 — right-to-left question papers whose numbers sit in the RIGHT margin (A17, 2026-09-22).

Cambridge mirrors the page for Arabic (0544) and Urdu (0539) papers: the top-level question
number is the same Arial-BoldMT 11 pt span it always is, but at ``x1 ≈ 0.905 × page width``;
marks ``[1]`` and the Total line move to the left. The locked vector engine
(``core/vector_first_cropper._qp_candidate``) only accepts numbers in the LEFT body margin
(``x0 / width <= 0.20``), so S2 reported "0 questions" for every RTL paper although the
text layer is complete (measured: docs/reports/2026-09-22-rtl-question-numbers-recon.md).

Contract (same shape as the OCR engine #2, A12):
  * ``should_handle(pdf)`` — engages ONLY when the document is RTL (≥ 30 % of its letters in
    the Arabic script blocks) AND the locked engine found no markers. LTR papers never reach
    this module; the locked cropper is not modified.
  * ``crop_rtl_paper(pdf, spool_dir, paper_code)`` — detects the mirrored markers, then hands
    them to the locked module's OWN segmenting / rendering / stitching / saving functions
    (``segment_for_marker``, ``render_clip``, ``trim_vertical_white``, ``stitch``,
    ``save_webp_tiled``), so crop geometry, 2280 px width, padding and WebP output are byte-
    for-byte the locked behaviour. Returns the low-ram crop payloads the S2→S5 flow already
    consumes, or [] with the reason in ``last_reason()`` — an empty list is a refusal, not
    success.

Marker rule (all measured on the real 0544 / 0539 files):
  * a digit-only span, bold, whose right edge is at ≥ 86 % of the page width, not in the
    header/footer bands (same filter as the locked engine);
  * Cambridge top-level numbering never restarts. A right-margin number LOWER than the next
    expected one opens a sub-list (0544 p9: a matching exercise numbered 1…8 in the identical
    style); a candidate equal to the expected number inside that sub-list is skipped until a
    Total line (``[Total: N]`` / ``[N: ]المجموع``, left margin) or the end of that page closes
    it. This keeps 0544 at its 6 questions (= its 6 Total lines = 45 marks) and 0539 at its 22
    (its 6 Total lines close sections, not questions), without a per-subject table.
"""
from __future__ import annotations

import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any, List, Optional, Tuple

import fitz  # PyMuPDF

from core.vector_first_cropper import (
    Marker, TextLine, _looks_like_header_or_footer, detect_markers, extract_text_for_segment,
    image_ink_fraction, lines_from_page, render_clip, save_webp_tiled, segment_for_marker,
    stitch, trim_vertical_white,
)

RTL_BLOCKS = re.compile(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]")
RTL_SHARE_MIN = 0.30
RIGHT_MARGIN_MIN = 0.86          # span x1 / page width
NUMBER_SPAN = re.compile(r"^\s*(\d{1,3})\s*$")
TOTAL_LINE = re.compile(r"\[\s*\d{1,3}\s*:?\s*\]|\[\s*[^\]\d]{0,20}:\s*\d{1,3}\s*\]|\[\s*\d{1,3}\s*:\s*\]")

_LAST_REASON = ""


def last_reason() -> str:
    return _LAST_REASON


def rtl_share(doc: fitz.Document) -> float:
    """Share of alphabetic characters that belong to the Arabic script blocks."""
    letters = 0
    rtl = 0
    for page in doc:
        for ch in page.get_text():
            if ch.isalpha():
                letters += 1
                if RTL_BLOCKS.match(ch):
                    rtl += 1
    return (rtl / letters) if letters else 0.0


def should_handle(pdf_path: str | Path) -> Tuple[bool, str]:
    """(True, why) only for an RTL text-layer document the locked engine cannot split."""
    try:
        with fitz.open(str(pdf_path)) as doc:
            share = rtl_share(doc)
            if share < RTL_SHARE_MIN:
                return False, f"RTL share {share:.2f} < {RTL_SHARE_MIN:.2f}"
            markers, _pages, _warnings = detect_markers(doc, "qp")
            if markers:
                return False, f"RTL share {share:.2f} but the locked engine already found {len(markers)} marker(s)"
            return True, f"RTL share {share:.2f}; locked left-margin engine found 0 markers"
    except Exception as exc:  # noqa: BLE001 - a gate must never raise into S2
        return False, f"gate error {type(exc).__name__}: {exc}"


def _right_margin_number_spans(page: fitz.Page) -> List[dict]:
    width = float(page.rect.width)
    out: List[dict] = []
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                match = NUMBER_SPAN.match(str(span.get("text", "")))
                if not match:
                    continue
                x0, y0, x1, y1 = (float(v) for v in span["bbox"])
                if x1 / width < RIGHT_MARGIN_MIN:
                    continue
                font = str(span.get("font", ""))
                bold = "bold" in font.lower() or bool(int(span.get("flags", 0)) & 16)
                if not bold:
                    continue
                probe = TextLine(text=match.group(1), x0=x0, y0=y0, x1=x1, y1=y1)
                if _looks_like_header_or_footer(probe, page):
                    continue
                out.append({"number": int(match.group(1)), "x0": x0, "y0": y0, "x1": x1, "y1": y1, "font": font})
    return out


def _total_lines(page: fitz.Page) -> List[float]:
    """y0 of the bracketed Total lines in the left margin (``[5: ]المجموع``, ``[Total: 8]``)."""
    width = float(page.rect.width)
    found: List[float] = []
    for line in lines_from_page(page):
        text = line.text.strip()
        if line.x0 / width > 0.12:
            continue
        if re.fullmatch(r"\[\d+\]\s*\.*", text):
            continue  # a marks tag such as "[1] ......" is not a Total line
        if "[" in text and ":" in text and re.search(r"\d", text):
            found.append(line.y0)
    return found


def rtl_markers(doc: fitz.Document) -> Tuple[List[Marker], List[Marker]]:
    """(selected 1..N sequence, all right-margin candidates) for an RTL document."""
    candidates: List[Marker] = []
    totals: List[Tuple[int, float]] = []
    for pno, page in enumerate(doc):
        for y in _total_lines(page):
            totals.append((pno, y))
        spans = _right_margin_number_spans(page)
        if not spans:
            continue
        page_lines = lines_from_page(page)
        for span in spans:
            if not 1 <= span["number"] <= 150:
                continue
            # The 11 pt number sits a few points BELOW the top of its 18 pt Nastaliq /
            # Naskh stem row. Start the question at the top of that row (any text line
            # overlapping the number vertically), otherwise the previous crop keeps a
            # sliver of this stem and this crop loses it. Same idea as the locked
            # engine's "margin number often sits below the stem" same-row rule.
            row_top = span["y0"]
            width = float(page.rect.width)
            for line in page_lines:
                # the stem row: starts at most 12 pt above the number, ends at the
                # number's right edge or before it, and lies to its left (not the
                # far-left vertical "DO NOT WRITE IN THIS MARGIN" strip, whose box
                # spans the whole page height). Line heights are NOT used: the
                # garbled Urdu font reports boxes 100+ pt tall for one text row.
                if not (span["y0"] - 12.0 <= line.y0 <= span["y0"] + 2.0):
                    continue
                if line.x0 >= span["x0"] or line.x1 > span["x1"] + 1.0:
                    continue
                if line.x1 < span["x0"] - 0.6 * width:
                    continue
                row_top = min(row_top, line.y0)
            candidates.append(Marker(span["number"], pno, row_top, span["y1"], span["x0"],
                                     str(span["number"]), 1.15, "right-margin bold numeric span"))
    candidates.sort(key=lambda m: (m.page, m.y0))

    selected: List[Marker] = []
    expected = 1
    sublist_open: Optional[Tuple[int, float]] = None
    for marker in candidates:
        if selected and marker.number < expected:
            # numbering restarted below the running count: a sub-list, not a question
            if sublist_open is None:
                sublist_open = (marker.page, marker.y0)
            continue
        if marker.number != expected:
            continue
        if sublist_open is not None:
            closed = marker.page > sublist_open[0] or any(
                sublist_open < (p, y) < (marker.page, marker.y0) for p, y in totals)
            if not closed:
                continue
            sublist_open = None
        selected.append(marker)
        expected += 1
    return selected, candidates


def crop_rtl_paper(pdf_path: str | Path, *, spool_dir: Optional[Path] = None,
                   paper_code: str = "", quality: int = 95) -> List[Any]:
    """Crop an RTL paper with the locked renderer driven by the mirrored markers."""
    global _LAST_REASON
    pdf_path = Path(pdf_path)
    spool_root = Path(spool_dir) if spool_dir else pdf_path.parent
    crop_root = spool_root / "rtl_qp" / pdf_path.stem
    crop_root.mkdir(parents=True, exist_ok=True)
    out: List[Any] = []
    with fitz.open(str(pdf_path)) as doc:
        markers, candidates = rtl_markers(doc)
        if not markers:
            _LAST_REASON = (f"RTL_NO_SEQUENCE: {len(candidates)} right-margin numeric span(s) "
                            f"but no 1..N sequence")
            print(f"    [rtl] {_LAST_REASON}")
            return []
        print(f"    [rtl] mirrored markers: 1..{len(markers)} from {len(candidates)} right-margin "
              f"span(s) ({', '.join(f'Q{m.number}@p{m.page + 1}' for m in markers)})")
        for index, marker in enumerate(markers):
            next_marker = markers[index + 1] if index + 1 < len(markers) else None
            segments = segment_for_marker(doc, marker, next_marker)
            images = []
            pages: List[int] = []
            text_parts: List[str] = []
            for segment in segments:
                image = trim_vertical_white(render_clip(doc[segment.page], segment.y0, segment.y1))
                images.append(image)
                pages.append(segment.page + 1)
                text_parts.append(extract_text_for_segment(doc[segment.page], segment.y0, segment.y1))
            assembled = stitch(images)
            paths = save_webp_tiled(assembled, crop_root / f"Q{marker.number}.webp", quality=quality)
            text = "\n".join(part for part in text_parts if part)
            warnings: List[str] = []
            if image_ink_fraction(assembled) < 0.002:
                warnings.append("crop has almost no ink")
            out.append(SimpleNamespace(
                question_number=f"Q{marker.number}", number_int=marker.number,
                paper_code=paper_code,
                images=[], assembled_image=None,
                text=text, marks=sum(int(mm) for mm in re.findall(r"\[(\d+)\]", text)),
                pages=pages, needs_review=bool(warnings), qc_reasons=warnings,
                _spool_png=str(paths[0]), _spool_paths=[str(p) for p in paths],
                rtl_engine=True,
            ))
    _LAST_REASON = ""
    print(f"    [rtl] engine #3 extracted {len(out)} question(s) from {pdf_path.name} "
          f"(locked renderer, mirrored markers)")
    return out
