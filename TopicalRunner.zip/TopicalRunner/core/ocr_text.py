"""OCR text for classification when a PDF's text layer is junk (idea 13, 2026-10-01).

Offline only (local Tesseract). Used ONLY to give the classifier readable
words; crops, folders and metadata are untouched. When Tesseract, pytesseract
or the needed language pack is missing, everything behaves exactly as before
(one log line says what to install).

Trigger: the subject's topic keywords are written in a non-Latin script
(Urdu, Hindi, Arabic, Chinese, ...) but the question's extracted text contains
almost none of that script - the custom-font case (0539 / 9686 P2 Urdu).
"""
from __future__ import annotations

import re
import shutil
from typing import Dict, Iterable, List, Optional, Tuple

_SCRIPTS = {
    "arabic": re.compile(r"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]"),
    "devanagari": re.compile(r"[\u0900-\u097F]"),
    "bengali": re.compile(r"[\u0980-\u09FF]"),
    "tamil": re.compile(r"[\u0B80-\u0BFF]"),
    "thai": re.compile(r"[\u0E00-\u0E7F]"),
    "han": re.compile(r"[\u4E00-\u9FFF\u3400-\u4DBF]"),
    "kana": re.compile(r"[\u3040-\u30FF]"),
    "hangul": re.compile(r"[\uAC00-\uD7AF]"),
    "greek": re.compile(r"[\u0370-\u03FF]"),
    "cyrillic": re.compile(r"[\u0400-\u04FF]"),
}
# script -> (subject-name word, tesseract language) ; first match wins, last is default
_LANGS = {
    "arabic": [("urdu", "urd"), ("persian", "fas"), ("farsi", "fas"), ("", "ara")],
    "devanagari": [("marathi", "mar"), ("nepali", "nep"), ("", "hin")],
    "bengali": [("", "ben")],
    "tamil": [("", "tam")],
    "thai": [("", "tha")],
    "han": [("traditional", "chi_tra"), ("", "chi_sim")],
    "kana": [("", "jpn")],
    "hangul": [("", "kor")],
    "greek": [("", "ell")],
    "cyrillic": [("", "rus")],
}
MIN_SCRIPT_SHARE = 0.25   # below this share of expected-script letters the text layer is junk
_WARNED: set = set()


def expected_script(keywords: Iterable[str]) -> Optional[str]:
    counts: Dict[str, int] = {}
    letters = 0
    for kw in keywords or ():
        for ch in str(kw):
            if not ch.isalpha():
                continue
            letters += 1
            for name, rx in _SCRIPTS.items():
                if rx.match(ch):
                    counts[name] = counts.get(name, 0) + 1
                    break
    if not counts or letters == 0:
        return None
    name, n = max(counts.items(), key=lambda kv: kv[1])
    return name if n / letters >= 0.5 else None


def script_share(text: str, script: str) -> float:
    rx = _SCRIPTS.get(script)
    letters = [c for c in str(text or "") if c.isalpha()]
    if rx is None or not letters:
        return 0.0
    return sum(1 for c in letters if rx.match(c)) / len(letters)


def tesseract_lang(script: str, subject: str = "") -> str:
    low = (subject or "").lower()
    for word, lang in _LANGS.get(script, []):
        if not word or word in low:
            return lang
    return ""


def ocr_ready(lang: str) -> Tuple[bool, str]:
    if shutil.which("tesseract") is None:
        return False, "Tesseract not installed (optional; install it for junk-font papers)"
    try:
        import pytesseract
        langs = set(pytesseract.get_languages(config=""))
    except Exception as exc:
        return False, f"pytesseract unavailable ({type(exc).__name__}); pip install pytesseract"
    if lang not in langs:
        return False, f"Tesseract language pack '{lang}' missing (e.g. tesseract-ocr-{lang})"
    return True, ""


class PageOCR:
    """Per-paper page OCR cache (each page is OCR'd at most once)."""

    def __init__(self, pdf_path, lang: str, dpi: int = 200):
        self.pdf_path = str(pdf_path)
        self.lang = lang
        self.dpi = dpi
        self._pages: Dict[int, str] = {}

    def page_text(self, index0: int) -> str:
        if index0 in self._pages:
            return self._pages[index0]
        text = ""
        try:
            import fitz
            import pytesseract
            from PIL import Image
            with fitz.open(self.pdf_path) as doc:
                if 0 <= index0 < len(doc):
                    pix = doc[index0].get_pixmap(dpi=self.dpi)
                    img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
                    text = pytesseract.image_to_string(img, lang=self.lang)
                    del img, pix
        except Exception:
            text = ""
        self._pages[index0] = text
        return text

    def question_text(self, pages: List[int]) -> str:
        pages = [int(p) for p in (pages or []) if p is not None]
        if not pages:
            return ""
        zero_based = min(pages) == 0
        return "\n".join(self.page_text(p if zero_based else p - 1) for p in sorted(set(pages)))


def maybe_ocr_questions(matched, qp_pdf, config, log=print) -> int:
    """Replace junk QP text with OCR text for classification. Returns #questions OCR'd."""
    try:
        kws = [k for v in (getattr(config, "classification_keywords", None) or {}).values() for k in (v or ())]
        script = expected_script(kws)
        if script is None or qp_pdf is None:
            return 0
        junk = [m for m in matched
                if script_share(getattr(getattr(m, "qp", None), "text", "") or "", script) < MIN_SCRIPT_SHARE]
        if not junk:
            return 0
        lang = tesseract_lang(script, getattr(config, "subject", "") or "")
        ok, why = ocr_ready(lang)
        if not ok:
            key = (lang, why)
            if key not in _WARNED:
                _WARNED.add(key)
                log(f"    [ocr] {len(junk)} question(s) have an unreadable {script} text layer; "
                    f"OCR skipped: {why}")
            return 0
        ocr = PageOCR(qp_pdf, lang)
        n = 0
        for m in junk:
            qp = getattr(m, "qp", None)
            text = ocr.question_text(getattr(qp, "pages", None) or [])
            if script_share(text, script) >= MIN_SCRIPT_SHARE:
                qp.text = text
                n += 1
        if n:
            log(f"    [ocr] {n}/{len(junk)} question(s) re-read with Tesseract ({lang}) for classification")
        return n
    except Exception as exc:
        log(f"    [ocr] skipped ({type(exc).__name__}: {exc})")
        return 0
