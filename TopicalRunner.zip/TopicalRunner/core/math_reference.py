"""Cambridge Mathematics reference-topic loaders.

9709 and 9231 use their approved paper-reference files; 0580 and 0606 use
question-level official topic arrays.  Returned folder names are always the
configured names-only topic strings; numeric syllabus identifiers are never
introduced into routing names.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
import re
from typing import Dict, List, Sequence

REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Mathematics_9709 References.txt"
_HEADING = re.compile(r"\(P([1-6])\)\s*$")


@lru_cache(maxsize=1)
def load_9709_reference() -> Dict[int, List[str]]:
    """Load the uploaded reference file, preserving each topic string exactly."""
    if not REFERENCE_PATH.exists():
        raise FileNotFoundError(f"Mathematics 9709 reference missing: {REFERENCE_PATH}")
    sections: Dict[int, List[str]] = {}
    current_paper: int | None = None
    for raw_line in REFERENCE_PATH.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current_paper = int(heading.group(1))
            sections.setdefault(current_paper, [])
            continue
        if current_paper is None:
            raise ValueError(f"Topic before P1–P6 heading in {REFERENCE_PATH}: {line!r}")
        # The file's literal topic spelling is canonical; never title-case,
        # replace underscores, or otherwise transform it.
        sections[current_paper].append(line)
    if set(sections) != {1, 2, 3, 4, 5, 6}:
        raise ValueError("Mathematics 9709 reference must define exactly P1 through P6")
    if any(not topics for topics in sections.values()):
        raise ValueError("Every Mathematics 9709 paper section must contain topics")
    return sections


def allowed_topics_for_paper(paper_number: int) -> List[str]:
    return list(load_9709_reference().get(int(paper_number), []))


# Matching aliases are classification evidence only. Values always come from
# the reference file and are returned unchanged.
_TOPIC_KEYWORDS = {
    "Quadratics": ("quadratic", "quadratics", "discriminant", "roots", "completing the square", "complete the square", "completed square", "set of values", "inequality", "inequalities", "vertex", "repeated root", "equal roots"),
    "Functions": ("function", "functions", "domain", "range", "composite", "inverse function", "modulus", "mapping", "mappings", "asymptote", "asymptotes", "intercept", "intercepts", "|"),
    "Coordinate_geometry": ("coordinate geometry", "coordinate", "coordinates", "gradient", "straight line", "circle", "circles", "centre", "center", "radius", "chord", "chords", "slope", "slopes", "intercept", "intercepts", "origin", "intersect", "intersects", "intersecting"),
    "Trigonometry": ("trigonometry", "trigonometric", "sin", "cos", "tan", "sinx", "cosx", "tanx", "siny", "cosy", "tany", "sine rule", "cosine rule", "sine", "cosine", "arcsin", "arccos", "arctan"),
    "Series": ("series", "sequence", "sequences", "arithmetic progression", "geometric progression", "nth term", "common difference", "common ratio", "ap", "gp", "arithmetic mean", "geometric mean", "sum", "binomial", "expansion", "pascal", "sigma", "σ", "convergent", "converges", "recurring decimal"),
    "Differentiation": ("differentiation", "differentiate", "derivative", "derivatives", "calculus", "dy/dx", "stationary", "gradient of the curve", "turning point", "maximum point", "minimum point", "parametric", "chain rule", "product rule", "quotient rule", "slope", "slopes", "curve", "curves", "intersect", "intersects", "intersecting", "implicit"),
    "Integration": ("integration", "integrate", "integral", "integrals", "area under", "shaded region", "area of the shaded", "area enclosed", "trapezium rule", "area bounded", "substitution", "curve", "curves", "intersect", "intersects", "intersecting", "∫"),
    "Circular_measure": ("circular measure", "radian", "radians", "arc length", "arc", "arcs", "sector", "sectors", "segment", "minor segment", "major segment"),
    "Algebra": ("algebra", "quadratic", "polynomial", "polynomials", "factorise", "factorises", "factorised", "factorising", "factorize", "factorizes", "factorized", "factorizing", "inequality", "inequalities", "binomial", "expansion", "pascal", "valid", "validity", # 2026-09-29 (CLS-178): the bare pipe is NOT evidence. A locus question
    # with three modulus expressions (|z − 2 + 3i| and friends) handed Algebra six
    # points and beat "argand" + "complex numbers". The letter- and digit-anchored
    # forms ("|x", "|2".."|9") still catch genuine modulus-function questions.
    "set of values", "|x", "|2", "|3", "|4", "|5", "|6", "|7", "|8", "|9", "factor of", "fraction", "fractions", "remainder", "divide", "divides", "divided", "dividing", "surd", "surds", "rationalise", "rationalize", "√", "∛"),
    "Logarithmic_and_exponential_functions": ("logarithm", "log", "logx", "lnx", "lg", "exponential", "exponentially", "e^", "indices", "ˣ"),
    "Numerical_solution_of_equations": ("numerical", "iteration", "root", "solve equation", "converges"),
    "Vectors": ("vector", "vectors", "parallel", "perpendicular", "magnitude", "collinear", "vertices", "origin", "cartesian equation", "skew", "intersect", "intersects", "intersecting", "coincident"),
    "Differential_equations": ("differential equation", "differential equations", "dy/dx", "proportional"),
    "Complex_numbers": ("complex number", "complex numbers", "argand", "imaginary", "modulus", "argument", "locus", "loci", "de moivre", "bi", "xi", "yi", "ai", "ci", "di", "iy", "i|", "origin"),
    "Forces_and_equilibrium": ("force", "forces", "equilibrium", "resultant", "friction", "frictional", "smooth", "rough", "weight", "weights", "resolving", "resolve", "tension", "thrust", "reaction", "light", "inextensible", "string", "upwards", "upward", "downwards", "downward", "sloping"),
    "Kinematics_of_motion_in_a_straight_line": ("kinematics", "kinematic", "velocity", "velocities", "acceleration", "accelerate", "accelerates", "accelerated", "accelerating", "decelerate", "decelerates", "decelerated", "decelerating", "retardation", "rest", "displacement", "speed", "projectile", "projectiles", "overtake", "overtakes", "overtook", "overtaking", "particle", "particles", "distance", "travel", "travels", "travelled", "travelling", "upwards", "upward", "downwards", "downward", "m/s", "m/s²", "m/s^2", "ms⁻²", "m s⁻²", "fall", "falls", "falling", "fell", "fallen"),
    "Momentum": ("momentum", "impulse", "collision", "restitution", "impact", "rebound", "collide", "collides", "collided", "colliding", "rest"),
    "Newton's_laws_of_motion": ("newton", "newton's law", "newtons law", "pulley", "pulleys", "mass", "masses", "acceleration", "accelerate", "accelerates", "accelerated", "accelerating", "decelerate", "decelerates", "decelerated", "decelerating", "retardation", "rest", "smooth", "rough", "tow", "towed", "towing", "particle", "particles", "tension", "thrust", "reaction", "light", "inextensible", "string", "upwards", "upward", "downwards", "downward", "resistance", "kg", "m/s²", "m/s^2", "ms⁻²", "m s⁻²", "fall", "falls", "falling", "fell", "fallen"),
    "Energy_work_and_power": ("energy", "power", "efficiency", "watt", "watts", "joule", "joules", "kilowatt", "kilojoule", "resistance", "j", "w", "m/s", "fall", "falls", "falling", "fell", "fallen"),
    "Representation_of_data": ("histogram", "box plot", "data", "scatter", "frequency", "frequencies", "median", "quartile", "quartiles", "mode", "modal", "mean", "range", "outlier", "outliers", "percentile", "percentiles"),
    "Permutations_and_combinations": ("permutation", "permutations", "combination", "combinations", "arrangement", "arrangements", "npr", "ncr", "factorial", "factorials", "choose", "chooses", "choosing", "chosen"),
    "Probability": ("probability", "probabilities", "event", "events", "venn", "coin", "coins", "dice", "die", "toss", "tosses", "tossed", "throw", "throws", "threw", "thrown", "heads", "head", "tails", "tail", "biased", "fair", "dependent", "random", "p("),
    "Discrete_random_variables": ("discrete random", "probability distribution", "expectation", "variance", "var(", "random variable", "e(", "p(", "b(", "bin(", "geo("),
    "The_normal_distribution": ("normal distribution", "normal", "normally", "standard deviation", "mean", "μ", "standardise", "standardize", "z", "n(", "p("),
    "Continuous_random_variables": ("continuous random", "density function", "probability density", "mode", "median", "pdf", "cdf", "p(", "u(", "e(", "var(", "variance", "random variable"),
    "Hypothesis_tests": ("hypothesis", "hypotheses", "significance", "critical region", "one-tailed", "one tailed", "two-tailed", "two tailed", "h0", "h1", "h₀", "h₁"),
    "Linear_combinations_of_random_variables": ("linear combination", "linear combinations", "random variables", "random variable", "variance", "var(", "e(", "p(", "independent", "normally distributed", "normal distribution"),
    "Sampling_and_estimation": ("sampling", "estimate", "estimation", "underestimate", "overestimate", "sample", "samples", "population", "x-bar"),
    "The_Poisson_distribution": ("poisson", "rate", "rates", "calls", "variance", "var(", "e(", "p(", "po(", "μ", "λ", "random variable"),
}


# Distinctive terms outrank broad shared words such as "force" or "data".
# This affects only evidence scoring; returned names still come verbatim from
# the reference file.
# A historical reference spelling contains a comma in the official phrase;
# the shipped folder profile uses the same name-only topic without punctuation
# so it remains a safe routing key.  Classification returns the profile key.
#
# 2026-09-29 (CLS-178, found by the golden set): three real 9709/33 June 2026
# questions were misrouted at full confidence because NOTATION letters scored as
# vocabulary. Q4 "cos(2θ – 45°) + i sin(2θ – 45°) + 1 = 0" -> Complex_numbers
# (three bare "i" beat sin+cos); Q6 "Use the substitution u = √x ... ∫ cos ..."
# -> Trigonometry via the "cos" in the integrand; Q7 "square roots of 3 – 20√7 i ...
# Cartesian form x + iy" -> Vectors via "cartesian"+"j". The bare i/j/z and bare
# "cartesian" entries are gone; "the substitution" is a decisive Integration phrase.
# The papers are pinned in tests/golden/ and rescored by tools/golden_set.py --score.
_REFERENCE_TOPIC_ALIASES = {
    "Energy,_work_and_power": "Energy_work_and_power",
}


# 2026-09-27 (CLS-24): specificity recalibrated to neutral. The old boosts
# (Newton/Poisson/Normal x3, DE/Complex/Vectors x2) were calibrated for the
# sparse pre-CLS-24 tables; with the expanded tables + decisive-phrase
# bonuses they multiplied SHARED evidence (rest/fall, mu/variance, mean,
# pipes, dy/dx) and bullied every tie. Validated by the 149-probe suite.
_TOPIC_SPECIFICITY = {}


def _count_bounded(haystack: str, keyword: str) -> int:
    """Letter-boundary occurrence count for one keyword/phrase.

    2026-09-27 (CLS-24): bare ``str.count`` matched inside larger words and
    misrouted real questions (``using``/``constant`` fired ``sin``/``tan``
    -> Trigonometry; ``second`` fired ``sec`` -> Trigonometry; ``roots``
    fired ``root``; ``momentum`` fired ``moment``; ``triangle`` fired
    ``angle``; ...). Keywords now match only at letter boundaries. A
    trailing ``*`` marks an intentional stem (left-bound, right-open:
    ``estimat*`` matches estimate/estimation/underestimate).
    """
    kw = str(keyword or '').strip().lower()
    if not kw:
        return 0
    # Boundaries only apply at letter edges: notation keywords such as e(,
    # p(, var(, |2 or m/s^2 end/start in non-letters and must match there
    # ("E(X)" has a letter after the paren — a trailing (?![a-z]) would
    # make it unmatchable). The non-letter edge is itself the boundary.
    def _left(s):
        return r'(?<![a-z])' if s[:1] in 'abcdefghijklmnopqrstuvwxyz' else ''
    def _right(s):
        return r'(?![a-z])' if s[-1:] in 'abcdefghijklmnopqrstuvwxyz' else ''
    if kw.endswith('*'):
        stem = kw[:-1]
        if not stem:
            return 0
        return len(re.findall(_left(stem) + re.escape(stem) + r'[a-z]*',
                              haystack, re.IGNORECASE))
    return len(re.findall(_left(kw) + re.escape(kw) + _right(kw),
                          haystack, re.IGNORECASE))


_TRIG_FALLBACK_RE = re.compile(
    r'(?<![a-z])(sin|cos|tan|sine|cosine|tangent|sec|cot|cosec|'
    r'pythagoras|pythagorean)(?![a-z])', re.IGNORECASE)
_STATS_A_RE = re.compile(
    r'(?<![a-z])(median|mode|modal|bimodal|frequency|frequencies)(?![a-z])',
    re.IGNORECASE)
_STATS_B_RE = re.compile(r'(?<![a-z])(probability|probabilities)(?![a-z])',
                          re.IGNORECASE)
_STATS_C_RE = re.compile(r'(?<![a-z])mean(?![a-z])', re.IGNORECASE)


def _score_text_against(topics, keywords, specificity, haystack: str) -> dict:
    # 2026-08-13: line-break tokens inside maths formulas extract as "tan\ntan\n";
    # normalise all whitespace so multi-word keywords still match.
    # 2026-09-27 (CLS-24): letter-boundary counting (see _count_bounded).
    haystack = re.sub(r"\s+", " ", haystack)
    return {
        topic: sum(_count_bounded(haystack, keyword) for keyword in keywords.get(topic, ()))
        * specificity.get(topic, 1)
        for topic in topics
    }


def _fuse_diagram(scores: dict, diagram: dict | None) -> dict:
    """Deterministic diagram-signal fusion (spec Fix 8). Signals only ever ADD
    evidence for official topics; they never invent unlisted topics.

    - angle arcs / sectors / greek letters        -> Trigonometry, Circular_measure
    - a lone plain triangle is NOT trigonometry evidence (spec: 'A plain
      triangle is not enough') — it only counts alongside arcs or trig text.
    - vector arrows                               -> Vectors (9709/9231) or
      Transformations_and_vectors (0580)
    - force arrows                                -> Forces / Mechanics topics
    - axes + plotted curve                        -> Coordinate_geometry /
      Algebra_and_graphs
    - histogram-style bar blocks                  -> Representation_of_data /
      Statistics
    """
    if not diagram:
        return scores
    scores = dict(scores)
    arcs = int(diagram.get("angle_arcs", 0))
    sectors = int(diagram.get("sectors", 0))
    triangles = int(diagram.get("triangles", 0))
    arrows = int(diagram.get("vector_arrows", 0))
    force = int(diagram.get("force_arrows", 0))
    axes_curve = int(diagram.get("axes_with_curve", 0))
    bars = int(diagram.get("bar_blocks", 0))
    greek = int(diagram.get("greek_labels", 0))
    normal = int(diagram.get("normal_curves", 0))
    trees = int(diagram.get("probability_trees", 0))

    def bump(names, weight):
        for name in names:
            for key in scores:
                # Exact match, or underscore-suffix ('vectors' -> 'Vectors' and
                # 'Transformations_and_vectors', but 'geometry' must NOT leak
                # into 'Coordinate_geometry').
                kl = key.lower()
                if kl == name.lower() or kl.endswith("_" + name.lower()):
                    scores[key] += weight
    # 2026-08-13 (corpus-hardened): diagram bumps are CONSTANT and small.
    # Count-scaled weights (2 + arcs) amplified text-glyph noise on real
    # crops (a single stray arc added 3+ points, dwarfing text evidence).
    # Only multi-signal or structurally strong evidence bumps a topic now.
    if greek:
        bump(["trigonometry", "circular_measure"], 1)
    if arcs >= 2 and triangles >= 1 and greek >= 1:
        # RS-17 multi-signal contract: drawn angle arcs + a triangle + a
        # greek/angle label = a genuine trig figure (corpus-hardened 2026-08-13:
        # plain noise arcs without an angle label must NOT bump trigonometry).
        bump(["trigonometry", "circular_measure", "geometry"], 3)
        bump(["trigonometry"], 1)
    if force:
        bump(["forces_and_equilibrium", "newton's_laws_of_motion",
              "kinematics_of_motion_in_a_straight_line", "mechanics"], 2)
    # 2026-08-13: plain arrow counting is NOT used — 3D-solid edges trigger
    # the arrowhead heuristic (cuboid Q21 emitted 13 "arrows"). Real vector
    # questions carry "vector"/"arrow" wording, which the base keywords and
    # phrase bonuses already handle. force_arrows stays (text-gated).
    if axes_curve:
        bump(["coordinate_geometry", "algebra_and_graphs"], 2)
    if bars >= 3:
        bump(["representation_of_data", "statistics"], 2)
    if normal:
        bump(["the_normal_distribution"], 3)
    if trees:
        bump(["probability"], 2)
    venn = int(diagram.get("venn_diagram", 0))
    if venn:
        bump(["probability"], 2)
    return scores


_FORMULA_NOTATION_CHARS = "θπ°αβλφΔΣμ"
# 2026-08-13: the DEGREE sign opens the evidence gate (angle questions) but
# must NOT count as trig greek-notation — geometry questions with angles were
# being pulled into near-ties with Trigonometry (0580 Q13 cyclic quadrilateral).
_NOTATION_BUMP_CHARS = "θπαβλφΔΣμ"


def _text_gate_open(raw_text: str, scores: dict) -> bool:
    """Spec Fix 8 multi-signal contract: a topic is only routable when the
    question TEXT / formula-notation layer carries at least one signal
    (keyword hit or math notation like θ/π/°). Pixel-diagram signals ALONE
    never route a question — diagram-only input is REVIEW_REQUIRED."""
    if any(v > 0 for v in scores.values()):
        return True
    return any(ch in raw_text for ch in _FORMULA_NOTATION_CHARS)


def _merge_text_notation(diagram: dict | None, raw_text: str) -> dict:
    d = dict(diagram or {})
    d["greek_labels"] = int(d.get("greek_labels", 0)) + sum(
        raw_text.count(ch) for ch in _NOTATION_BUMP_CHARS)
    return d


def _apply_phrase_bonuses(scores: dict, raw_text: str, bonus_map: dict[str, Sequence[str]], weight: int = 2) -> dict:
    """Boost distinctive, low-collision phrases that are stronger than the base
    keyword lists. The bonuses only ever strengthen an already-configured topic;
    they never invent a new routing name."""
    haystack = f" {re.sub(r'\s+', ' ', raw_text.lower())} "
    boosted = dict(scores)
    for topic, phrases in bonus_map.items():
        if topic not in boosted:
            continue
        hits = sum(_count_bounded(haystack, phrase) for phrase in phrases)
        if hits:
            boosted[topic] += hits * weight
    return boosted


def _pick_best_topic(ordered_topics: Sequence[str], scores: dict[str, float]) -> str | None:
    """Choose a math topic conservatively.

    Accuracy target: prefer abstaining on weak near-ties rather than forcing a
    wrong folder. Reference order still resolves confident ties only after the
    ambiguity gates say the winner is clear enough.
    """
    ranking = [(scores.get(topic, 0.0), idx, topic) for idx, topic in enumerate(ordered_topics)]
    ranking.sort(key=lambda row: (-row[0], row[1]))
    if not ranking or ranking[0][0] <= 0:
        return None
    best, _idx, winner = ranking[0]
    runner = ranking[1][0] if len(ranking) > 1 else 0.0
    gap = best - runner
    # Hard tie between multiple candidate topics -> review_required.
    if runner == best and best > 0:
        return None
    # Low-evidence / close-score outputs are more likely to be wrong than to be
    # safely auto-routed. Let the caller send them to review_required.
    # 2026-08-13 (corpus-calibrated, RS-41 round 2): a SINGLE topic with
    # evidence and NO competitor routes ("logarithm", "binomial expansion",
    # "velocity" were all being rejected at best=1, runner=0 — measured on the
    # 0606_s24 corpus). Rejection now requires a real competitor.
    if best < 2 and runner > 0 and gap <= 1:
        return None
    if best < 5 and runner > 0 and gap <= 1 and (runner / best) >= 0.8:
        return None
    return winner


# ── RS-24 (2026-08-14, real-paper finding 0580_s24_qp_41 Q9): full-auto must
# never leave a math question winnerless. Q9 is a composite/inverse function
# question whose OCR text is character-fragmented ("f", "(", "3" on separate
# lines) — "function" never appears, so the evidence gate stays closed and the
# paper bundle crashed with "Classification has no valid assigned topic".
# Under force (full-auto) the math routers now:
#   1. pick the best near-miss topic when SOME topic scored;
#   2. fall back to math-notation heuristics when nothing scored
#      (f(x)/g(x)/f⁻¹/gh notation -> the functions topic; θ/π/° notation ->
#      trigonometry/circular measure; digits+units -> Number, ...);
#   3. as an absolute last resort return the first topic in syllabus order
#      (only reachable when the crop text is empty/garbage).
_FUNCTION_NOTATION_RE = re.compile(
    r"\b[fgh]\s*\(\s*[x0-9]|⁻?\s*1\s*\)|\b[fg]\s*[gh]\s*\(",
    re.IGNORECASE,
)
# 2026-09-27 (CLS-24): bounded "inverse" — bare "inverse" matched inside
# "inversely" ("inversely proportional" is DE formation, not functions).
_INVERSE_NOTATION_RE = re.compile(r"[fgh]⁻?\^?\s*-\s*1\b|(?<![a-z])inverse(?![a-z])", re.IGNORECASE)
# RS-24: Cambridge math QP text extraction frequently scrambles function
# notation into character columns ("f(x)" -> "f", "=", "( )x" on separate
# lines), so no adjacency ever matches. Standalone single-letter identifiers
# f/g/h TOGETHER with a "Find" command and [n] mark tokens are a reliable
# functions-question signature (single letters as identifiers occur nowhere
# else in IGCSE/A-Level maths papers).
_SCRAMBLED_FUNCTION_RE = re.compile(r"\b[fgh]\b", re.IGNORECASE)
_MARK_TOKEN_RE = re.compile(r"\[\s*\d{1,2}\s*\]")
# RS-25: 0606 differentiation questions ("Find d/dx(...)") whose notation gets
# scrambled into character columns ("d", "dd" on their own lines). Only fires
# when ALL of: "find" command, mark tokens, a standalone x, a standalone
# d/dd token, AND "exact form" (the stem's closing phrase) are present — so
# subpart-(d) questions and surd "exact form" asks never match.
_D_TOKEN_RE = re.compile(r"(?<![a-z])d{1,2}(?![a-z])", re.IGNORECASE)
_X_TOKEN_RE = re.compile(r"(?<![a-z])x(?![a-z])", re.IGNORECASE)


def _is_scrambled_differentiation(text: str) -> bool:
    low = text.lower()
    return ("find" in low and "exact form" in low
            and _MARK_TOKEN_RE.search(text)
            and _X_TOKEN_RE.search(text)
            and _D_TOKEN_RE.search(text))


def _math_force_topic(text: str, topics: Sequence[str],
                      scores: dict[str, float],
                      functions_topic: str | None = None) -> str | None:
    """Deterministic full-auto fallback for math questions (never None)."""
    # 1. best near-miss
    ranked = [(scores.get(t, 0.0), i, t) for i, t in enumerate(topics)]
    ranked.sort(key=lambda r: (-r[0], r[1]))
    if ranked and ranked[0][0] > 0:
        return ranked[0][2]
    # 2. notation heuristics
    low = text.lower()
    # 2026-09-27 (CLS-24): the functions branch must respect the paper gate —
    # it used to return e.g. "Functions" on papers whose allowed list lacks it.
    if functions_topic and functions_topic in topics:
        if (_FUNCTION_NOTATION_RE.search(text)
                or _INVERSE_NOTATION_RE.search(low)
                # scrambled-notation signature: standalone f/g/h identifiers +
                # "find" command + mark tokens (real 0580_s24_qp_41 Q9).
                or ("find" in low
                    and _SCRAMBLED_FUNCTION_RE.search(text)
                    and _MARK_TOKEN_RE.search(text))):
            return functions_topic
    if any(ch in text for ch in ("θ", "π", "°")):
        if "Trigonometry" in topics:
            return "Trigonometry"
        if "Circular_measure" in topics:
            return "Circular_measure"
    # 2026-09-27 (CLS-24): bounded trig fallback — the old unbounded
    # ``"sin" in low`` matched "using", "constant" matched "tan", and any
    # binomial question with those words routed to Trigonometry.
    if _TRIG_FALLBACK_RE.search(low):
        if "Trigonometry" in topics:
            return "Trigonometry"
    # 2026-09-27 (CLS-24): bounded stats fallback, split by affinity.
    # median/mode/frequency are averages evidence (Representation-first);
    # probability keeps its own target; mean stays averages-first.
    if _STATS_A_RE.search(low):
        for t in ("Statistics", "Representation_of_data",
                  "Continuous_random_variables", "Probability"):
            if t in topics:
                return t
    if _STATS_B_RE.search(low):
        for t in ("Probability", "Statistics"):
            if t in topics:
                return t
    if _STATS_C_RE.search(low):
        for t in ("Statistics", "Representation_of_data", "Probability"):
            if t in topics:
                return t
    # 3. absolute last resort: first topic in official syllabus order
    return topics[0] if topics else None


_9709_PHRASE_BONUSES = {
    "Quadratics": ("parabola", "turning point", "roots are equal", "equal roots", "range of values", "α and β", "α, β"),
    "Functions": ("one-one", "one to one", "one-to-one", "composite function", "inverse function"),
    "Coordinate_geometry": ("equation of the line", "midpoint", "perpendicular", "parallel", "tangent to the circle", "normal to the circle", "point of intersection"),
    "Trigonometry": ("identity", "identities", "trigonometric equation", "double angle", "sec", "cosec", "cot", "unit circle", "inverse sin", "inverse cos", "inverse tan", "principal value"),
    "Circular_measure": ("radians", "sector area", "small-angle", "small angle"),
    "Differentiation": ("stationary point", "second derivative", "tangents", "tangent", "normal to the curve", "gradient of the curve", "rate of change", "chain rule", "product rule", "quotient rule", "point of intersection", "differentiate", "differentiation", "dy/dx"),
    "Integration": ("definite integral", "area between", "volume of revolution", "shaded region", "area of the shaded", "integration by parts", "by parts", "point of intersection", "integrate", "integration", "∫", "the substitution"),
    "Algebra": ("modulus", "partial fractions", "binomial expansion", "binomial theorem", "pascal's triangle", "coefficient of x", "quotient", "remainder when", "factor theorem", "remainder theorem", "proper fraction", "improper fraction", "α and β", "α, β"),
    "Logarithmic_and_exponential_functions": ("natural logarithm", "ln", "exponential growth", "exponential decay", "laws of logarithms", "laws of indices"),
    "Numerical_solution_of_equations": ("show that there is a root", "use an iteration", "iterative formula", "change of sign"),
    "Complex_numbers": ("argand diagram", "de moivre", "de moivre's theorem", "locus in the argand plane", "modulus-argument form", "modulus of", "i|",
                              # 2026-09-29 (CLS-178): the phrases a real complex-number
                              # question uses, now that the bare letter "i" is gone.
                              "modulus and argument", "argument of z", "real and imaginary",
                              "imaginary part", "imaginary parts"),
    "Forces_and_equilibrium": ("equilibrium", "resultant force", "three forces", "inclined plane", "coefficient of friction"),
    "Kinematics_of_motion_in_a_straight_line": ("speed-time graph", "displacement-time graph", "velocity-time graph", "distance-time graph", "constant acceleration"),
    "Momentum": ("coefficient of restitution", "impulse", "collision", "direct impact", "conservation of momentum"),
    "Newton's_laws_of_motion": ("newton's second law", "mass times acceleration", "connected particles", "find the mass", "accelerating force", "produced by"),
    "Energy_work_and_power": ("work done", "kinetic energy", "gravitational potential energy", "power output", "conservation of energy", "gain in kinetic", "gain in potential", "loss of kinetic", "loss of potential", "gain in energy", "loss of energy", "by a force"),
    "Representation_of_data": ("cumulative frequency", "box-and-whisker", "stem-and-leaf", "scatter diagram", "interquartile range", "modal class", "of the data"),
    "Permutations_and_combinations": ("npr", "ncr", "distinct arrangements", "number of ways", "in how many ways"),
    "Probability": ("venn diagram", "conditional probability", "independent events", "tree diagram", "mutually exclusive", "without replacement", "with replacement", "pack of cards", "sample space", "probability tree", "at random"),
    "Discrete_random_variables": ("expected value", "variance of x", "probability mass", "binomial distribution", "geometric distribution", "number of trials", "sum of squares", "discrete random"),
    "The_normal_distribution": ("standard normal", "z-value", "z score", "z-score", "normal approximation", "continuity correction"),
    "Continuous_random_variables": ("probability density function", "density curve", "uniform distribution", "rectangular distribution", "cumulative distribution function", "continuous random"),
    "Hypothesis_tests": ("null hypothesis", "alternative hypothesis", "critical value", "p-value", "test statistic", "type i error", "type 1 error", "type ii error", "type 2 error", "hypothesis test", "hypothesis testing"),
    "Linear_combinations_of_random_variables": ("x + y", "ax + by", "combined random variables", "expected value"),
    "Sampling_and_estimation": ("unbiased estimator", "unbiased estimate", "sampling distribution", "confidence interval", "central limit", "large sample", "random sample", "sample variance"),
    "The_Poisson_distribution": ("poisson process", "occur at random", "occur randomly", "rare events"),
    "Series": ("sum to infinity", "sum to n", "binomial expansion", "binomial theorem", "pascal's triangle", "coefficient of x", "σ"),
    "Vectors": ("position vector", "scalar product", "vector product", "direction vector", "angle between", "unit vector", "dot product", "parametric equation", "parametric equations", "shortest distance", "point of intersection"),
    "Differential_equations": ("separation of variables", "particular solution", "general solution", "integrating factor", "proportional to"),
}


def classify_9709_question(text: str, paper_number: int, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Choose one valid topic from the filename-selected reference section.

    Returns None when there is NO deterministic evidence (spec: never fall back
    to an alphabetical/first topic — the caller routes to REVIEW_REQUIRED),
    and also when only pixels speak (diagram-only -> REVIEW_REQUIRED).
    ``force=True`` (full-auto, RS-24) never returns None: near-miss ->
    notation heuristics -> first allowed topic."""
    allowed = allowed_topics_for_paper(paper_number)
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(allowed, _TOPIC_KEYWORDS, _TOPIC_SPECIFICITY, haystack)
    text_scores = _apply_phrase_bonuses(text_scores, text, _9709_PHRASE_BONUSES)
    if not _text_gate_open(text, text_scores):
        if force:
            return _math_force_topic(text, allowed, text_scores,
                                     functions_topic="Functions")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    raw_topic = _pick_best_topic(allowed, scores)
    if raw_topic is None and force:
        raw_topic = _math_force_topic(text, allowed, text_scores,
                                      functions_topic="Functions")
    if raw_topic is None:
        return None
    # Reference order resolves confident outcomes; return the configured folder
    # key when an official reference spelling contains punctuation that the
    # profile deliberately flattened.
    return _REFERENCE_TOPIC_ALIASES.get(raw_topic, raw_topic)

FURTHER_9231_REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Further_Mathematics_9231 Reference.txt"


def _load_paper_reference(path: Path) -> Dict[int, List[str]]:
    if not path.exists():
        raise FileNotFoundError(f"Mathematics reference missing: {path}")
    sections: Dict[int, List[str]] = {}
    current: int | None = None
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current = int(heading.group(1)); sections.setdefault(current, [])
        elif current is None:
            raise ValueError(f"Topic before paper heading in {path}: {line!r}")
        else:
            sections[current].append(line)
    return sections


@lru_cache(maxsize=1)
def load_9231_reference() -> Dict[int, List[str]]:
    sections = _load_paper_reference(FURTHER_9231_REFERENCE_PATH)
    if set(sections) != {1, 2, 3, 4} or any(not values for values in sections.values()):
        raise ValueError("Further Mathematics 9231 reference must define P1 through P4")
    return sections


# The shipped 9231 reference text predates the final config-safe routing names
# in two places and omits the dedicated Hooke's-law major from P3.  Canonicalise
# those spellings here so question routing, folder names, and config validation
# all agree on one output vocabulary.
_9231_REFERENCE_TOPIC_ALIASES = {
    "Inference_using_normal_and_t-distributions": "Inference_using_normal_and_t_distributions",
    "Non-parametric_tests": "Non_parametric_tests",
}


def _canonical_9231_topic(topic: str) -> str:
    return _9231_REFERENCE_TOPIC_ALIASES.get(topic, topic)


@lru_cache(maxsize=None)
def _allowed_9231_topics_for_paper(paper_number: int) -> List[str]:
    allowed = [_canonical_9231_topic(t) for t in load_9231_reference().get(int(paper_number), [])]
    if int(paper_number) == 3 and "Hooke's_law" not in allowed:
        try:
            idx = allowed.index("Linear_motion_under_a_variable_force")
        except ValueError:
            idx = len(allowed)
        allowed.insert(idx, "Hooke's_law")
    return allowed


def reference_topics_for_subject_paper(syllabus_code: str, paper_number: int) -> List[str]:
    """Return canonical routing topics for a staging paper."""
    code = str(syllabus_code)
    if code == "9709":
        return allowed_topics_for_paper(paper_number)
    if code == "9231":
        return list(_allowed_9231_topics_for_paper(int(paper_number)))
    return []
# ---------------------------------------------------------------------------
# IGCSE Mathematics 0580 — official topic areas (2025–2027 syllabus, topic
# names verbatim). Question-level routing per mega-spec Fix 8: text + formula
# evidence first, deterministic diagram fusion, REVIEW_REQUIRED on no-evidence.
MATH_0580_TOPICS: List[str] = [
    "Number",
    "Algebra_and_graphs",
    "Coordinate_geometry",
    "Geometry",
    "Mensuration",
    "Trigonometry",
    "Transformations_and_vectors",
    "Probability",
    "Statistics",
]

_0580_TOPIC_KEYWORDS = {
    "Number": ("number", "numbers", "integer", "integers", "fraction", "fractions", "percentage", "decimal", "decimals", "ratio", "ratios", "standard form", "prime", "primes", "factor", "factors", "interest", "estimat*", "bound", "bounds", "currency", "currencies", "proportion", "proportional", "exponential", "exponentially", "depreciat*", "appreciat*", "digit", "digits", "decimal places", "decimal place", "significant figures", "significant figure", "round", "rounded", "rounding", "reciprocal", "reciprocal of", "square root", "cube root", "square number", "square numbers", "cube number", "cube numbers", "composite number", "ordinary number", "exchange rate", "profit", "loss", "discount", "tax", "hire purchase", "growth", "decay", "direct proportion", "inverse proportion", "inversely", "directly proportional", "inversely proportional", "average speed", "speed"),
    "Algebra_and_graphs": ("algebra", "expand", "expanded", "expanding", "factorise", "factorises", "factorised", "factorising", "factorize", "factorizes", "factorized", "factorizing", "expression", "expressions", "simplify", "simplified", "simplifying", "solve the equation", "quadratic", "sequence", "sequences", "nth term", "inequalit*", "formula", "formulas", "formulae", "equation", "equations", "graph of", "sketch", "function", "functions", "composite function", "inverse function", "composite", "to the power", "indices", "index", "term", "terms", "root", "roots", "completing the square", "parabola", "simultaneous", "substitution", "elimination", "brackets", "cubic function", "cubic graph", "cubic equation", "reciprocal function", "reciprocal graph", "turning point", "range of values", "number line", "linear", "linear inequality", "linear equation", "solve the inequality", "plot the graph", "plot the points", "translation of the graph", "reflection of the graph", "stretch", "stretched", "stretching", "substitute", "substituted", "shade", "shaded", "shading", "unwanted region", "required region"),
    "Coordinate_geometry": ("gradient", "straight line", "coordinates", "coordinate", "midpoint", "parallel to", "perpendicular", "equation of the line", "y-intercept", "y intercept", "intercept", "intercepts", "origin", "line", "lines", "horizontal line", "vertical line", "distance", "distance between", "distance formula", "collinear", "parallel lines", "x-axis", "y-axis", "x axis", "y axis", "equation of"),
    "Geometry": ("angle", "angles", "polygon", "polygons", "congruent", "congruence", "similar", "similarity", "circle theorem", "circle theorems", "chord", "chords", "tangent", "tangents", "construction", "bisector", "bisectors", "symmetry", "interior angle", "exterior angle", "intercepted", "intercepting", "locus", "loci", "cyclic", "triangle", "triangles", "quadrilateral", "quadrilaterals", "trapezium", "trapezoid", "parallelogram", "parallelograms", "rhombus", "rectangle", "rectangles", "pentagon", "hexagon", "octagon", "corresponding", "corresponding angles", "alternate", "alternate angles", "co-interior angles", "vertically opposite", "complementary angles", "supplementary angles", "reflex", "kite", "kites", "rotational symmetry", "construct", "constructed", "compass", "compasses"),
    "Mensuration": ("area", "perimeter", "volume", "surface area", "circumference", "radius", "diameter", "length of arc", "sector", "sectors", "prism", "cylinder", "cone", "sphere", "pyramid", "segment", "arc", "arcs", "cube", "cubes", "hemisphere", "slant height", "capacity", "net of", "in terms of pi", "in terms of π", "take pi to be", "π"),
    "Trigonometry": ("trigonometr*", "sin", "cos", "tan", "sinx", "cosx", "tanx", "siny", "cosy", "tany", "sine rule", "cosine rule", "bearing", "bearings", "angle of elevation", "angle of depression", "pythagoras", "sine", "cosine", "tangent of", "hypotenuse", "three-figure bearing", "three figure bearing"),
    "Transformations_and_vectors": ("transformation", "transformations", "translation", "rotation", "reflection", "enlargement", "vector", "vectors", "matrix", "matrices", "column vector", "scale factor", "magnitude", "scalar", "scalar multiple", "position vector", "displacement", "displacement vector", "determinant", "inverse matrix", "identity matrix", "image", "object", "mirror", "mirror line", "reflect", "reflects", "reflected", "reflecting", "rotate", "rotates", "rotated", "rotating", "translate", "translates", "translated", "translating", "enlarge", "enlarges", "enlarged", "enlarging"),
    "Probability": ("probability", "probabilities", "event", "events", "outcome", "outcomes", "tree diagram", "expected number", "without replacement", "venn diagram", "venn", "set notation", "coin", "coins", "toss", "tossed", "dice", "die", "spinner", "bag", "bags", "ball", "balls", "card", "cards", "deck", "sample space", "mutually exclusive", "independent events", "chance", "chances", "fair", "biased", "with replacement", "universal set", "complement", "subset", "intersection", "union"),
    "Statistics": ("mean", "median", "mode", "range of", "histogram", "cumulative frequency", "scatter", "bar chart", "pie chart", "frequency table", "frequencies", "interquartile", "box plot", "standard deviation", "modal", "average", "data", "frequency", "frequency polygon", "frequency density", "class", "class interval", "class boundary", "class boundaries", "quartile", "lower quartile", "upper quartile", "correlation", "positive correlation", "negative correlation", "line of best fit", "outlier", "outliers", "sample", "survey", "tally", "pictogram", "stem-and-leaf", "stem and leaf", "Σ"),
}

_0580_TOPIC_SPECIFICITY = {
    "Coordinate_geometry": 2,
    "Transformations_and_vectors": 2,
    "Trigonometry": 2,
}

_0580_PHRASE_BONUSES = {
    "Number": ("surd", "surds", "surd form", "upper bound", "lower bound", "compound interest", "percentage change", "as a fraction", "recurring decimal", "decreases exponentially", "increases exponentially", "calculate.", "simplify the ratio", "simplify the fraction", "square root", "cube root"),
    "Algebra_and_graphs": ("simultaneous equation", "simultaneous equations", "nth term", "graphical solution", "rearrange the formula", "variation", "factorise completely", "inequalities that define", "unshaded region", "reciprocal function", "reciprocal graph", "range of values", "number line", "translation of the graph", "reflection of the graph"),
    "Coordinate_geometry": ("equation of the line", "distance between", "midpoint", "gradient of ab", "perpendicular bisector"),
    "Geometry": ("locus", "construction", "circle theorem", "interior angle", "exterior angle", "cyclic quadrilateral", "congruent", "similar to", "perpendicular bisector", "lines of symmetry", "line of symmetry"),
    "Mensuration": ("surface area", "composite solid", "arc length", "volume of", "cross-sectional area", "cuboid", "semicircle", "area of triangle", "area of the triangle", "area of the", "in terms of pi", "in terms of π"),
    "Trigonometry": ("sine rule", "cosine rule", "angle of elevation", "angle of depression", "bearing", "pythagoras", "sinx", "cosx", "tanx", "tangent of"),
    "Transformations_and_vectors": ("image of", "under enlargement", "matrix transformation", "column vector", "centre of enlargement", "reflection in", "rotation about", "translation by", "enlargement by"),
    "Probability": ("relative frequency", "without replacement", "tree diagram", "expected number", "sample space"),
    "Statistics": ("cumulative frequency curve", "box plot", "histogram", "scatter diagram", "interquartile range", "line of best fit"),
}


def classify_0580_question(text: str, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Question-level 0580 routing into the 9 official topic areas.

    Deterministic: keyword evidence x specificity, diagram fusion, ties resolve
    by official syllabus order. No evidence -> None (caller: REVIEW_REQUIRED).
    ``force=True`` (full-auto) never returns None: near-miss -> notation
    heuristics -> syllabus-order first topic (RS-24).
    """
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(MATH_0580_TOPICS, _0580_TOPIC_KEYWORDS,
                                      _0580_TOPIC_SPECIFICITY, haystack)
    # 2026-08-13: distinctive phrases ("cuboid", "cyclic quadrilateral") are
    # evidence too — apply before the gate so they can open it.
    text_scores = _apply_phrase_bonuses(text_scores, text, _0580_PHRASE_BONUSES)
    if not _text_gate_open(text, text_scores):
        if force:
            # RS-24: functions live under Algebra_and_graphs in 0580; f(x)/g(x)
            # /f⁻¹ notation with no other evidence still routes there.
            return _math_force_topic(text, MATH_0580_TOPICS, text_scores,
                                     functions_topic="Algebra_and_graphs")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    winner = _pick_best_topic(MATH_0580_TOPICS, scores)
    if winner is None and force:
        winner = _math_force_topic(text, MATH_0580_TOPICS, text_scores,
                                   functions_topic="Algebra_and_graphs")
    return winner


# ---------------------------------------------------------------------------
# IGCSE Additional Mathematics 0606 — official topic names for the
# 2025–2027 syllabus.  These are deliberately flattened routing names: the
# numeric syllabus identifiers stay in the profile metadata, never in output
# folders.  Text/formula evidence is required; diagram-only evidence remains
# REVIEW_REQUIRED just like the other mathematics profiles.
MATH_0606_TOPICS: List[str] = [
    "Functions",
    "Quadratic_functions",
    "Factors_of_polynomials",
    "Equations_inequalities_and_graphs",
    "Simultaneous_equations",
    "Logarithmic_and_exponential_functions",
    "Straight_line_graphs",
    "Coordinate_geometry_of_the_circle",
    "Circular_measure",
    "Trigonometry",
    "Permutations_and_combinations",
    "Series",
    "Vectors_in_two_dimensions",
    "Calculus",
]

_0606_TOPIC_KEYWORDS = {
    "Functions": ("function", "functions", "domain", "range", "inverse function", "composite function", "modulus function", "mapping", "mappings", "one-to-one", "one to one", "many-to-one", "inverse", "composite", "fg", "gf"),
    "Quadratic_functions": ("quadratic", "discriminant", "completing the square", "maximum", "minimum", "parabola", "turning point", "quadratic function", "quadratic equation", "quadratic formula", "equal roots", "repeated root", "repeated roots", "distinct roots", "real roots", "no real roots", "values of k", "range of values of k", "line of symmetry", "symmetry", "tangent to the curve", "curve", "curves", "intersect", "intersects"),
    "Factors_of_polynomials": ("polynomial", "polynomials", "factor theorem", "remainder theorem", "factorise", "factorises", "factorised", "factorising", "factorize", "factorizes", "factorized", "factorizing", "cubic", "quartic", "cubic equation", "cubic function", "quartic equation", "remainder", "factor", "factors", "coefficient", "comparing coefficients"),
    "Equations_inequalities_and_graphs": ("equation", "equations", "inequality", "inequalities", "graphical solution", "solve graphically", "modulus equation", "set of values", "linear inequality", "linear inequalities", "linear equation", "linear equations", "number line", "range of values", "graphical method", "shade", "shaded", "shaded region", "unwanted region", "quadratic inequality"),
    "Simultaneous_equations": ("simultaneous equations", "elimination", "substitution", "simultaneous", "pair of equations"),
    "Logarithmic_and_exponential_functions": ("logarithm", "logarithmic", "ln", "lnx", "exponential", "laws of logarithms", "exponential equation", "growth", "decay", "single logarithm", "log", "logx", "lg", "base 10", "exponential function", "logarithmic function", "logarithms", "change of base", "base 2", "base e"),
    "Straight_line_graphs": ("gradient", "midpoint", "length", "y = mx + c", "parallel", "perpendicular", "collinear", "intercept", "intercepts", "origin", "line", "lines", "straight line", "equation of the line", "equation of", "perpendicular bisector", "linear law", "linearise", "linearize", "distance", "angle between"),
    "Coordinate_geometry_of_the_circle": ("coordinate geometry of the circle", "equation of a circle", "radius", "radii", "tangent to the circle", "circle", "circles", "centre", "center", "origin", "diameter", "chord", "chords", "circumference", "normal to the circle", "intersect", "intersects"),
    "Circular_measure": ("circular measure", "radian", "radians", "arc length", "sector area", "sector", "radius", "radii", "arc", "arcs", "angle", "angles", "perimeter"),
    "Trigonometry": ("trigonometry", "trigonometric", "sine", "cosine", "tangent", "sec", "cosec", "cot", "identity", "identities", "general solution", "amplitude", "period", "sin", "cos", "tan", "sinx", "cosx", "tanx", "siny", "cosy", "tany", "solve the equation", "angle", "angles", "trigonometric function", "cast diagram", "cast", "quadrant", "quadrants"),
    "Permutations_and_combinations": ("permutation", "permutations", "combination", "combinations", "factorial", "factorials", "arrangement", "arrangements", "arranged", "selection", "npr", "ncr", "repetition", "committee", "seated", "in a row", "digit", "digits"),
    "Series": ("series", "sequence", "sequences", "arithmetic progression", "geometric progression", "common difference", "common ratio", "nth term", "sum to n terms", "sum to infinity", "binomial expansion", "expansion", "ascending powers", "binomial", "coefficient", "binomial theorem", "convergent", "converges", "divergent", "term", "first term", "arithmetic", "geometric", "recurring"),
    "Vectors_in_two_dimensions": ("vector", "vectors", "magnitude", "unit vector", "position vector", "column vector", "parallel vectors", "displacement vector", "velocity vector", "direction of the vector"),
    "Calculus": ("calculus", "differentiation", "differentiate", "derivative", "derivatives", "dy/dx", "stationary point", "integration", "integrate", "integral", "integrals", "area under the curve", "constant of integration", "rate of change", "in terms of t", "distance travelled", "gradient of the curve", "equation of the curve", "with respect to", "velocity is", "acceleration is", "displacement is", "maximum point", "minimum point", "turning point of the curve", "find the derivative", "integration of", "differentiate with", "∫", "tangent to the curve", "equation of the tangent", "gradient of the tangent", "normal to the curve", "equation of the normal", "normal", "chain rule", "product rule", "quotient rule", "increasing function", "decreasing function", "small change", "small changes", "area between", "gradient function"),
                # RS-25 (2026-08-14): removed false-positive keywords — "exact
                # form" is a command phrase used by surds/trig/algebra
                # questions everywhere, "particle" is a bare noun, and bare
                # "velocity"/"acceleration"/"displacement" fire on simple
                # speed-distance-time algebra. Replaced with calculus-context
                # phrases: motion questions in 0606 are calculus, but only
                # when the wording signals it (rates, "in terms of t",
                # distance travelled by integration, gradient of a curve).
}

_0606_TOPIC_SPECIFICITY = {
    "Coordinate_geometry_of_the_circle": 2,
    "Circular_measure": 2,
    "Trigonometry": 2,
    "Vectors_in_two_dimensions": 2,
    "Calculus": 2,
}

_0606_PHRASE_BONUSES = {
    "Functions": ("composite function", "inverse function", "one-to-one", "modulus function", "mapping"),
    "Quadratic_functions": ("completing the square", "turning point", "axis of symmetry", "roots are equal", "tangent to the curve", "range of values of k"),
    "Factors_of_polynomials": ("factor theorem", "remainder theorem", "cubic polynomial", "quartic polynomial"),
    "Equations_inequalities_and_graphs": ("solve graphically", "graphical solution", "modulus equation", "inequality", "range of values", "number line"),
    "Simultaneous_equations": ("simultaneous equations", "elimination", "substitution"),
    "Logarithmic_and_exponential_functions": ("laws of logarithms", "natural logarithm", "exponential growth", "exponential decay"),
    "Straight_line_graphs": ("y = mx + c", "linear law", "linearise", "linearize", "gradient and intercept", "equation of the line", "equation of", "angle between"),
    "Coordinate_geometry_of_the_circle": ("equation of a circle", "tangent to the circle", "radius and centre", "center", "normal to the circle"),
    "Circular_measure": ("radian", "sector area", "arc length", "small-angle", "small angle"),
    "Trigonometry": ("sec", "cosec", "cot", "compound angle", "general solution", "amplitude", "period"),
    "Permutations_and_combinations": ("npr", "ncr", "ordered", "unordered", "distinct arrangements"),
    "Series": ("sum to infinity", "binomial expansion", "common ratio", "common difference"),
    "Vectors_in_two_dimensions": ("position vector", "unit vector", "parallel vectors", "column vector"),
    "Calculus": ("rate of change", "second derivative", "stationary point", "area under the curve", "constant of integration", "differentiate", "differentiation", "integrate", "integration", "dy/dx", "∫", "tangent to the curve", "equation of the tangent"),
}


def classify_0606_question(text: str, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Route one 0606 question into one official major topic or None."""
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(MATH_0606_TOPICS, _0606_TOPIC_KEYWORDS,
                                      _0606_TOPIC_SPECIFICITY, haystack)
    if not _text_gate_open(text, text_scores):
        if force:
            if _is_scrambled_differentiation(text):
                return "Calculus"
            return _math_force_topic(text, MATH_0606_TOPICS, text_scores,
                                     functions_topic="Functions")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    scores = _apply_phrase_bonuses(scores, text, _0606_PHRASE_BONUSES)
    winner = _pick_best_topic(MATH_0606_TOPICS, scores)
    if winner is None and force:
        winner = _math_force_topic(text, MATH_0606_TOPICS, text_scores,
                                   functions_topic="Functions")
    return winner


# ---------------------------------------------------------------------------
# A-Level Further Mathematics 9231 — reference-file vocabulary, question-level
# routing (same contract as 9709).
_9231_TOPIC_KEYWORDS = {
    "Matrices": ("matrix", "matrices", "determinant", "inverse matrix", "eigenvalue", "eigenvalues", "eigenvector", "eigenvectors", "characteristic equation", "transformation matrix", "singular matrix", "identity matrix"),
    "Polar_coordinates": ("polar", "pole", "initial line", "polar curve", "area enclosed by", "cardioid"),
    "Proof_by_induction": ("induction", "prove by induction", "inductive", "divisibility", "divisible by"),
    "Rational_functions_and_graphs": ("rational function", "asymptote", "asymptotes", "oblique", "vertical asymptote", "horizontal asymptote", "sketch the graph"),
    "Roots_of_polynomial_equations": ("roots of", "root", "roots", "polynomial", "polynomials", "sum of the roots", "product of the roots", "cubic equation", "quadratic equation", "quartic", "repeated root", "double root"),
    "Summation_of_series": ("summation", "sum of the series", "sigma", "σ", "method of differences", "partial fractions", "sum to n terms", "nth term"),
    "Vectors": ("vector", "vectors", "cross product", "scalar product", "plane", "planes", "line of intersection", "normal", "direction vector", "position vector", "vector equation", "angle between", "shortest distance"),
    "Complex_numbers": ("complex", "argand", "modulus", "argument", "de moivre", "real part", "imaginary part", "conjugate", "locus", "loci", "exponential form", "roots of unity", "cube roots"),
    "Differential_equations": ("differential equation", "particular integral", "complementary function", "second order", "first order", "general solution", "variables separable", "integrating factor", "auxiliary equation", "separating variables"),
    "Differentiation": ("derivative", "derivatives", "differentiation", "differentiate", "differentiating", "dy/dx", "implicit", "parametric", "maclaurin", "tangent", "normal", "stationary point", "point of inflection", "point of inflexion"),
    "Hyperbolic_functions": ("hyperbolic", "sinh", "cosh", "tanh", "arsinh", "arcosh", "artanh", "inverse hyperbolic"),
    "Integration": ("integration", "integrating", "integrated", "integral", "integrals", "reduction formula", "arc length", "surface of revolution", "∫", "integration by parts", "area under the curve", "area bounded by", "volume of revolution"),
    "Circular_motion": ("circular motion", "angular speed", "angular velocity", "centripetal", "revolutions", "conical pendulum", "banked", "banked track", "vertical circle", "horizontal circle", "tension"),
    "Equilibrium_of_a_rigid_body": ("rigid body", "equilibrium", "moment", "moments", "centre of mass", "lamina", "tension", "friction", "rough", "smooth", "coefficient of friction", "normal reaction", "toppling", "resultant force", "resolving", "resolve", "beam", "ladder"),
    "Hooke's_law": ("hooke's law", "elastic spring", "elastic string", "spring", "springs", "modulus of elasticity", "natural length", "extension", "elastic potential energy", "work done", "stretched", "compressed", "load", "extends", "stretching"),
    "Linear_motion_under_a_variable_force": ("variable force", "simple harmonic", "shm", "oscillation", "oscillations", "oscillating", "oscillate", "resistance proportional", "differential equation", "terminal velocity", "damped", "amplitude", "frequency", "period of oscillation"),
    "Momentum": ("momentum", "impulse", "collision", "restitution", "conservation of momentum", "elastic collision", "inelastic collision", "direct impact", "oblique impact", "coefficient of restitution"),
    "Motion_of_a_projectile": ("projectile", "trajectory", "greatest height", "range on", "time of flight", "angle of projection", "horizontal range", "maximum height", "equation of trajectory", "vertical motion", "horizontal motion", "projected", "parabola"),
    "Continuous_random_variables": ("continuous random", "density function", "cumulative distribution", "probability density function", "pdf", "expected value", "expectation", "variance", "median", "cumulative distribution function", "uniform distribution", "exponential distribution", "mu", "sigma", "μ", "σ"),
    "Inference_using_normal_and_t_distributions": ("t-distribution", "t distribution", "confidence interval", "normal distribution", "pooled", "population mean", "sample mean", "μ", "σ", "hypothesis test", "null hypothesis", "alternative hypothesis", "significance level", "critical region", "critical value", "type i error", "type ii error", "unbiased estimate", "one-tailed", "two-tailed", "degrees of freedom", "central limit theorem", "variance", "t-test", "paired t-test", "z test", "z-test", "p-value", "p value", "mu", "sigma"),
    "Non_parametric_tests": ("non-parametric", "non parametric", "sign test", "wilcoxon",
        "rank", "ranks", "ranked", "median", "paired sample", "distribution-free",
        "rank sum", "signed-rank", "signed rank",
        # shared testing vocabulary, as in Chi_squared_tests above
        "significance level", "null hypothesis", "alternative hypothesis", "hypothesis test",
        "test statistic", "critical region", "one-tailed", "two-tailed"),
    "Probability_generating_functions": ("probability generating", "pgf", "generating function", "sum of independent random variables", "probability generating function"),
    # 2026-09-29 (CLS-178b, real 9231/41 Q2): a paper writes "whether the reliability of
    # the service is independent of the bus company", not "test for independence", so the
    # textbook phrase never fired and the question routed on "significance level" alone.
    # The testing vocabulary every hypothesis test shares is repeated here (as it is in
    # Non_parametric_tests) so that shared words cannot decide a route on their own.
    "Chi_squared_tests": ("chi-squared", "chi squared", "chi squared test", "goodness of fit",
        "contingency", "contingency table", "test for independence", "test for association",
        "independent of", "association",
        "significance level", "null hypothesis", "alternative hypothesis", "hypothesis test",
        "test statistic", "critical region", "one-tailed", "two-tailed"),
}

_9231_TOPIC_SPECIFICITY = {
    "Hooke's_law": 3,
    "Probability_generating_functions": 2,
    # 2026-09-29 (CLS-178b): the x3 on the two testing topics was calibrated when their
    # keyword lists were sparse. Now that they carry the vocabulary every hypothesis test
    # shares, a multiplier turns ONE shared word into three points and bullies the specific
    # evidence of another topic (real 9231/41 Q5: "t-test" + "significance level" scored 2
    # for inference while "significance level" alone scored 3 for chi-squared and
    # non-parametric -- a hard tie that fell to review). Same reasoning as the CLS-24
    # removal from the 9709 table: distinctive wording carries them without it.
}

_9231_PHRASE_BONUSES = {
    "Matrices": ("characteristic equation", "inverse matrix", "determinant"),
    "Polar_coordinates": ("polar curve", "pole", "initial line"),
    "Proof_by_induction": ("assume true for n = k", "true for n = k + 1", "prove by induction"),
    "Rational_functions_and_graphs": ("oblique asymptote", "vertical asymptote", "rational function"),
    "Roots_of_polynomial_equations": ("sum of the roots", "product of the roots", "polynomial equation"),
    "Summation_of_series": ("method of differences", "summation of series", "sigma notation", "partial fractions"),
    "Vectors": ("vector equation", "cross product", "scalar product", "plane through"),
    "Complex_numbers": ("argand diagram", "de moivre", "modulus-argument"),
    "Differential_equations": ("auxiliary equation", "complementary function", "particular integral"),
    "Differentiation": ("implicit differentiation", "parametric differentiation", "second derivative", "maclaurin series"),
    "Hyperbolic_functions": ("sinh", "cosh", "tanh", "hyperbolic identity"),
    "Integration": ("reduction formula", "surface of revolution", "arc length", "volume of revolution", "integration by parts"),
    "Circular_motion": ("centripetal", "angular speed", "angular velocity"),
    "Equilibrium_of_a_rigid_body": ("rigid body", "centre of mass", "center of mass", "lamina", "moment", "taking moments", "in equilibrium", "resolving forces"),
    "Hooke's_law": ("hooke's law", "elastic spring", "elastic string", "natural length", "modulus of elasticity"),
    "Linear_motion_under_a_variable_force": ("simple harmonic motion", "simple harmonic", "shm", "variable force", "resistance proportional"),
    "Momentum": ("coefficient of restitution", "impulse", "collision"),
    "Motion_of_a_projectile": ("trajectory", "greatest height", "projectile", "time of flight"),
    "Continuous_random_variables": ("cumulative distribution", "density function", "continuous random variable", "probability density function"),
    # 2026-09-29 (CLS-178b): "null hypothesis" was dropped -- it is vocabulary every
    # hypothesis test shares, and a bonus is worth double, so it let the inference topic
    # win a three-way tie on shared wording alone. The rest are its own phrases.
    "Inference_using_normal_and_t_distributions": ("t-distribution", "confidence interval",
        "population mean", "sample mean"),
    "Non_parametric_tests": ("sign test", "wilcoxon", "rank sum", "non-parametric"),
    "Probability_generating_functions": ("probability generating function", "pgf"),
    "Chi_squared_tests": ("goodness of fit", "contingency table", "chi-squared"),
}


def classify_9231_question(text: str, paper_number: int, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Question-level 9231 routing within the filename-selected paper section."""
    allowed = _allowed_9231_topics_for_paper(int(paper_number))
    if not allowed:
        return None
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(allowed, _9231_TOPIC_KEYWORDS, _9231_TOPIC_SPECIFICITY, haystack)
    if not _text_gate_open(text, text_scores):
        if force:
            return _math_force_topic(text, allowed, text_scores,
                                     functions_topic="Matrices")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    scores = _apply_phrase_bonuses(scores, text, _9231_PHRASE_BONUSES)
    winner = _pick_best_topic(allowed, scores)
    if winner is None and force:
        winner = _math_force_topic(text, allowed, text_scores,
                                   functions_topic="Matrices")
    return winner
