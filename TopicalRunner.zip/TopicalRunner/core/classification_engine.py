"""Verified multi-pass topic decision for the TopicClassifier (offline, deterministic).

The point-based scorer in :mod:`core.classifier` stays the first classifier
(pass A).  This module adds a verification layer that decides the final topic
from several *independent* views of the same question and resolves any
disagreement by explicit pairwise verification — never by a plain vote and
never by trusting one confidence number.

Everything is derived at runtime from the subject's own canonical taxonomy
(``major_topics`` / ``detailed_topics`` / ``mapping`` /
``classification_keywords`` / ``syllabus_vocab.json`` / ``paper_topics``).  The
topic corpus is only read; no topic is ever invented, renamed, merged or split,
and the final answer is always one of the canonical topics the paper allows.

Passes
------
A  existing curated-keyword point scorer (``_classify_question_base``).
B  syllabus-definition retrieval: stemmed phrase evidence from the whole
   question against topic definitions (names + curated terms + syllabus
   vocabulary), IDF-weighted over the subject's topics.
C  primary-skill pass: only what the candidate is actually asked to do — the
   question sentence(s) / command clauses and the mark scheme — with
   discriminative evidence only, weighted by the marks of each subpart.

Decision
--------
* all passes agree                    -> accept (cheap path) after sanity checks;
* a pass disagrees                    -> pairwise verification of the contested
  pair on *discriminative* evidence only ("why A", "why not B");
* three different answers             -> round-robin verification between the
  three candidates, then a final check of the survivor against pass A;
* anything invalid / malformed / no positive evidence -> keep pass A's topic.

The engine only ever changes ``winning_major`` (and puts the winner's detailed
topic first in ``detailed_topics``).  Tiers, scores, confidence, reasoning
format and every other field are untouched.  Any internal error returns the
original result unchanged, so classification can never crash the pipeline.
"""
from __future__ import annotations

import math
import re
from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

ENGINE_VERSION = "verified-multipass/2026-09-30"

# ---------------------------------------------------------------------------
# Tunables (fixed constants; chosen on the development set, validated on a
# separate held-out set).
# ---------------------------------------------------------------------------
W_NAME = 1.6            # topic / detailed-topic name phrase
W_NAME_WORD = 0.4       # content word that occurs in exactly one topic name of the subject
W_KEYWORD = 1.0         # curated classification keyword
W_VOCAB = 0.6           # syllabus vocabulary phrase confirmed by the topic's own keywords/name
W_VOCAB_UNCONFIRMED = 0.3   # vocabulary phrase with no support in the topic's keywords/name
POLLUTED_SIZE_RATIO = 2.5   # vocab list >2.5x the subject median ...
POLLUTED_CONFIRMED = 1.01   # oversized vocab lists are mined appendix noise: keep only confirmed terms (size alone decides)
KW_CONFLICT_FACTOR = 0.35   # curated term the syllabus itself places under another topic
MAX_GRAM = 4
LEN_BONUS = 0.6         # extra weight per additional word of a matched phrase (specificity)

ROLE_ASK = 1.0          # the question sentence / command clause
ROLE_CONTEXT = 0.45     # scenario / stem context
ROLE_OPTION = 0.2       # MCQ options (distractors are mostly wrong on purpose)
ROLE_MS = 0.55          # mark-scheme evidence
ROLE_INTRO = 0.35       # structured-question preamble before (a)
ROLE_GIVEN = 0.15       # a sentence that only supplies data / defines a symbol

MARGIN_CONSENSUS = 0.10  # B and C both disagree with A
MARGIN_SINGLE = 0.45     # only one independent pass disagrees with A
MARGIN_ROUND = 0.30      # three-way disagreement: survivor vs A
MIN_KEYWORD_COVERAGE = 0.5    # engine must be able to read >=50% of the subject's curated keywords
MAX_NON_LATIN_SHARE = 0.4     # questions mostly written in another script are left to the base scorer
OVERRIDE_CONFIDENCE_CAP = 0.5  # overridden decisions are never 'high confidence'
STRICT_MIN_MARGIN = 0.0  # final rigorous check: challenger must hold at least equal strong evidence

_BOILERPLATE_RE = re.compile(
    r"(?:do\s+not\s+)?(?:w?r?ite\s+in\s+this\s+ma(?:rgin)?)|\bdo\s+not\s+w\w*\b|"
    r"©\s*ucles\s*\d*|\[turn over\]?|\bpermission to reproduce\b.*$|\d{4}/\d{2}/[a-z]/[a-z]/\d{2}|"
    r"\.{3,}|…+",
    re.IGNORECASE,
)
_OPTION_LINE_RE = re.compile(r"(?m)^\s*([A-D])\s*$")
_SUBPART_RE = re.compile(r"(?<![a-z0-9])\((?:[a-h]|i{1,3}|iv|v|vi{0,3})\)")
_MARK_RE = re.compile(r"\[(\d{1,2})\]")
_SENT_SPLIT_RE = re.compile(r"(?<=[.?!])\s+|\n\s*\n")
_WORD_RE = re.compile(r"[a-z][a-z0-9]*")
_GIVEN_VALUE = r"(?:[a-z\u0370-\u03ff]{1,2}\d?|[\d.]+(?:\s*[\u00d7x]\s*10\S*)?(?:\s*[\w/\-\u2013\u2212\u00b0%]{1,6}){0,3})"
_GIVEN_RE = re.compile(
    r"^(?:the\s+)?[a-z][\w\s,()\-]{0,60}?\s(?:is|are|=|has|have)\s+(?:an?\s+)?(?:[\w\-]+\s+){0,3}?"
    + _GIVEN_VALUE + r"(?:\s*(?:,|and)\s*(?:an?\s+)?(?:[\w\-]+\s+){0,3}?" + _GIVEN_VALUE + r")*\s*\.?$"
    r"|^(?:take|assume|use)\b.{0,80}\b(?:as|to\s+be|is|=)\b"
    r"|^where\s+\S{1,3}\s+is\b",
    re.IGNORECASE,
)
_COMMAND_RE = re.compile(
    r"\b(?:which|what|how|why|when|define|state|explain|describe|calculate|determine|"
    r"deduce|suggest|show|identify|name|outline|compare|estimate|predict|sketch|draw|"
    r"complete|write|construct|give|discuss|evaluate|derive|use)\b",
    re.IGNORECASE,
)

_STOPWORDS = frozenset("""
a an the of and or to in on at by for from with without into onto as is are was were be been being
this that these those it its their there which what when where why how who whom whose than then so
such very more most less least much many each every any some all both either neither not no nor only
same other another own also can could may might must shall should will would do does did done has
have had use used using uses show shown shows diagram diagrams fig figure table graph graphs row rows
statement statements correct incorrect true false following answer answers value values total mark
marks question questions give given explain describe calculate determine suggest name identify
complete draw define deduce outline compare estimate write sketch predict discuss evaluate find
about approximately between during after before over under near key possible possibly likely
one two three four five six seven eight nine ten i ii iii iv vi vii viii ix x
learner learners candidate candidates student students teacher experiment investigation
cambridge syllabus core supplement including include includes included example examples eg ie etc
they them their theirs we us our you your he him his she her hers itself themselves
""".split())

# Primary-skill cues: generic, subject-independent patterns for skills that
# are often asked without naming their topic.  They inject *concept phrases*
# which are then resolved against the subject's own topic definitions, so a
# cue can only ever support a canonical topic that actually defines it.
_SKILL_CUES: Sequence[Tuple[re.Pattern, Tuple[str, ...]]] = (
    (re.compile(r"\bexpress(?:ed)?\s+in\b|\bin\s+(?:si\s+)?base\s+units\b|\bconvert(?:ed)?\b.{0,30}\binto\b",
                re.IGNORECASE), ("base units", "prefixes", "units")),
    (re.compile(r"±|\bpercentage\s+uncertaint|\buncertaint", re.IGNORECASE), ("uncertainty", "percentage uncertainty")),
    (re.compile(r"\bhomogene", re.IGNORECASE), ("homogeneity", "base units")),
    (re.compile(r"\bempirical formula\b|\bmolecular formula\b|\bmoles?\s+of\b|\bmol\s*dm", re.IGNORECASE),
     ("mole", "amount of substance")),
)


# ---------------------------------------------------------------------------
# Text utilities
# ---------------------------------------------------------------------------
def _stem(word: str) -> str:
    w = word
    if len(w) <= 3:
        return w
    if w.endswith("ies") and len(w) > 4:
        w = w[:-3] + "y"
    elif w.endswith(("sses", "xes", "ches", "shes")):
        w = w[:-2]
    elif w.endswith("s") and not w.endswith(("ss", "us", "is")):
        w = w[:-1]
    for suf, rep in (("isation", "ise"), ("ization", "ise"), ("ational", "ate"), ("ation", "ate"),
                     ("ising", "ise"), ("izing", "ise"), ("ised", "ise"), ("ized", "ise"),
                     ("ing", ""), ("eed", "eed"), ("ied", "y"), ("ed", ""), ("ly", "")):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: len(w) - len(suf)] + rep
            break
    if w.endswith("e") and len(w) > 4:
        w = w[:-1]
    return w


def _clean(text: str) -> str:
    t = (text or "").replace("\u2019", "'").replace("\u2018", "'")
    t = re.sub(r"[\ue000-\uf8ff]", " ", t)          # private-use glyphs from PDF symbol fonts
    return _BOILERPLATE_RE.sub(" ", t)


def _stems(text: str) -> List[str]:
    t = text.lower().replace("'s", "").replace("-", " ").replace("\u2013", " ").replace("\u2014", " ")
    out = []
    for w in _WORD_RE.findall(t):
        if len(w) < 2 or w in _STOPWORDS or w.isdigit():
            continue
        out.append(_stem(w))
    return out


def _gram(phrase: str) -> Tuple[str, ...]:
    return tuple(_stems(phrase))


def _grams(stems: Sequence[str]) -> Iterable[Tuple[str, ...]]:
    n = len(stems)
    for i in range(n):
        for k in range(1, MAX_GRAM + 1):
            if i + k > n:
                break
            yield tuple(stems[i:i + k])


def _len_bonus(g: Tuple[str, ...]) -> float:
    return 1.0 + LEN_BONUS * (len(g) - 1)


# ---------------------------------------------------------------------------
# Canonical topic profiles (built once per classifier, read-only corpus)
# ---------------------------------------------------------------------------
class TopicProfiles:
    """Isolated internal representation of the canonical taxonomy."""

    def __init__(self, classifier) -> None:
        cfg = classifier.config
        self.majors: List[str] = list(getattr(cfg, "major_topics", []) or [])
        self.mapping: Dict[str, str] = dict(getattr(cfg, "mapping", {}) or {})
        detailed = list(getattr(cfg, "detailed_topics", []) or [])
        keywords = dict(getattr(cfg, "classification_keywords", {}) or {})
        vocab = dict(getattr(classifier, "_syllabus_vocab", {}) or {})
        # How much of the curated evidence this engine can actually read (the
        # tokenizer is Latin-script); subjects whose keywords are written in
        # other scripts (Mandarin, Urdu, ...) are left to the base scorer.
        _all_kw = [k for ks in keywords.values() for k in (ks or []) if isinstance(k, str) and k.strip()]
        self.keyword_coverage = (sum(1 for k in _all_kw if _stems(k)) / len(_all_kw)) if _all_kw else 1.0
        self.details_of: Dict[str, List[str]] = defaultdict(list)
        for d in detailed:
            self.details_of[self.mapping.get(d, d)].append(d)
        # Three separate evidence sources per gram (each {topic: weight}):
        #   kw   curated classification keywords (what pass A scores),
        #   syl  the syllabus itself: topic names + trusted syllabus vocabulary,
        #   and the merged view used by pass C / the verifier, in which the
        #   syllabus placement of a term wins over a conflicting curated list.
        kw_w: Dict[Tuple[str, ...], Dict[str, float]] = defaultdict(dict)
        syl_w: Dict[Tuple[str, ...], Dict[str, float]] = defaultdict(dict)
        det_w: Dict[Tuple[str, ...], Dict[str, float]] = defaultdict(dict)

        def put(store, g, key, w):
            if w > store[g].get(key, 0.0):
                store[g][key] = w

        # Vocabulary trust: syllabus_vocab.json is phrase-mined from the syllabus
        # text and some lists absorbed appendix material (practical skills,
        # glossary).  Trust is derived at runtime; the files are never modified.
        curated_grams = set()
        own_stems: Dict[str, set] = {}
        for det in detailed:
            st = set(_stems(det.replace("_", " "))) | set(_stems(self.mapping.get(det, det).replace("_", " ")))
            for kw in keywords.get(det, []) or []:
                g = _gram(str(kw))
                st |= set(g)
                if g:
                    curated_grams.add(g)
            own_stems[det] = st

        def trusted(term: str, det: str) -> bool:
            g = _gram(term)
            return bool(g) and (g in curated_grams or bool(set(g) & own_stems.get(det, set())))

        sizes = sorted(len(vocab.get(d, []) or []) for d in detailed if vocab.get(d))
        median = sizes[len(sizes) // 2] if sizes else 0
        self.polluted_vocab = []
        for d in detailed:
            terms = vocab.get(d, []) or []
            if median and len(terms) > POLLUTED_SIZE_RATIO * median:
                ratio = sum(1 for t in terms if trusted(str(t), d)) / len(terms)
                if ratio < POLLUTED_CONFIRMED:
                    self.polluted_vocab.append(d)

        # A single name word is evidence only when it is unique to one topic name
        # ("compounds", "organic", "chemistry" ... in several names are not).
        name_word_topics: Dict[Tuple[str, ...], set] = defaultdict(set)
        for name in set(self.majors) | set(detailed):
            for x in name.replace("_", " ").split():
                g = _gram(x)
                if g:
                    name_word_topics[g].add(self.mapping.get(name, name))

        for major in self.majors:
            for det in (self.details_of.get(major) or [major]):
                for name in {det, major}:
                    human = name.replace("_", " ")
                    words = [(_gram(x), W_NAME_WORD) for x in human.split()
                             if _gram(x) and len(name_word_topics.get(_gram(x), ())) == 1]
                    for g, w in [(_gram(human), W_NAME)] + words:
                        if g and len(g) <= MAX_GRAM:
                            put(syl_w, g, major, w); put(kw_w, g, major, w); put(det_w, g, det, w)
                for kw in keywords.get(det, []) or []:
                    g = _gram(str(kw))
                    if g and len(g) <= MAX_GRAM:
                        put(kw_w, g, major, W_KEYWORD); put(det_w, g, det, W_KEYWORD)
                polluted = det in self.polluted_vocab
                for term in vocab.get(det, []) or []:
                    g = _gram(str(term))
                    if not g or len(g) > MAX_GRAM:
                        continue
                    if trusted(str(term), det):
                        w = W_VOCAB
                    elif polluted:
                        continue
                    else:
                        w = W_VOCAB_UNCONFIRMED
                    put(syl_w, g, major, w); put(det_w, g, det, w)

        merged: Dict[Tuple[str, ...], Dict[str, float]] = defaultdict(dict)
        syl_topics_of = {g: set(tm) for g, tm in syl_w.items()}
        for g in set(kw_w) | set(syl_w):
            placed = {t for t, w in syl_w.get(g, {}).items() if w >= W_VOCAB}
            for t, w in syl_w.get(g, {}).items():
                put(merged, g, t, w)
            for t, w in kw_w.get(g, {}).items():
                if placed and t not in syl_topics_of.get(g, set()):
                    w = w * KW_CONFLICT_FACTOR          # syllabus places this term elsewhere
                put(merged, g, t, w)
        self.major_w = merged
        self.kw_w = dict(kw_w)
        self.syl_w = dict(syl_w)
        self.detail_w = det_w
        n = max(len(self.majors), 1)
        self.idf: Dict[Tuple[str, ...], float] = {}
        self.syl_idf: Dict[Tuple[str, ...], float] = {}
        norm = math.log(1.0 + n)
        # A single word is only as specific as its spread: the number of topics
        # that use the stem anywhere in their definitions ("wavelength" also
        # lives inside several other topics' phrases even if listed bare once).
        spread: Dict[str, set] = defaultdict(set)
        for g, tm in self.major_w.items():
            for w in g:
                spread[w].update(tm)
        self.stem_spread = {w: len(ts) for w, ts in spread.items()}

        def _idf(g, tm):
            df = len(tm)
            if len(g) == 1:
                df = max(df, self.stem_spread.get(g[0], df))
            return math.log(1.0 + n / df) / norm

        for g, tm in self.major_w.items():
            self.idf[g] = _idf(g, tm)
        for g, tm in self.syl_w.items():
            self.syl_idf[g] = _idf(g, tm)
        self.max_df_discriminative = max(2, int(round(n * 0.2)))
        self._partners = self._confusion_partners()

    def _confusion_partners(self) -> Dict[str, List[str]]:
        mass: Dict[str, float] = defaultdict(float)
        shared: Dict[Tuple[str, str], float] = defaultdict(float)
        for g, tm in self.major_w.items():
            idf = self.idf[g]
            tops = sorted(tm)
            for t in tops:
                mass[t] += idf
            if 2 <= len(tops) <= 4:
                for i, a in enumerate(tops):
                    for b in tops[i + 1:]:
                        shared[(a, b)] += idf
        partners: Dict[str, List[Tuple[float, str]]] = defaultdict(list)
        for (a, b), s in shared.items():
            denom = min(mass[a], mass[b]) or 1.0
            partners[a].append((s / denom, b))
            partners[b].append((s / denom, a))
        return {t: [b for _s, b in sorted(v, key=lambda x: (-x[0], x[1]))[:3]] for t, v in partners.items()}

    def partners(self, topic: str) -> List[str]:
        return list(self._partners.get(topic, []))


def profiles_for(classifier) -> TopicProfiles:
    prof = getattr(classifier, "_verified_topic_profiles", None)
    if prof is None:
        prof = TopicProfiles(classifier)
        classifier._verified_topic_profiles = prof
    return prof


# ---------------------------------------------------------------------------
# Question view: what is asked vs scenario vs distractors, per subpart
# ---------------------------------------------------------------------------
class QuestionView:
    """Segments of one question with a role weight and a mark weight."""

    def __init__(self, qp_text: str, qp_marks: int, ms_text: str, is_mcq: bool) -> None:
        self.units: List[dict] = []   # {"marks": float, "segments": [(stems, role_w)]}
        text = _clean(qp_text)
        text = re.sub(r"^\s*\d{1,2}\s+", "", text, count=1)        # leading question number
        self.is_mcq = bool(is_mcq)
        if self.is_mcq:
            self._build_mcq(text)
        else:
            self._build_structured(text, qp_marks)
        self.ms_segments: List[Tuple[List[str], float]] = []
        ms = _clean(ms_text or "")
        if ms.strip() and not self.is_mcq:
            for line in re.split(r"\n+", ms):
                st = _stems(line)
                if st:
                    self.ms_segments.append((st, ROLE_MS))

    @staticmethod
    def _sentences(block: str) -> List[str]:
        return [s for s in (x.strip() for x in _SENT_SPLIT_RE.split(block.replace("\n", " \n"))) if s]

    def _build_mcq(self, text: str) -> None:
        m = _OPTION_LINE_RE.search(text)
        stem, options = (text[: m.start()], text[m.start():]) if m else (text, "")
        sentences = self._sentences(stem)
        ask_idx = [i for i, s in enumerate(sentences) if "?" in s]
        if not ask_idx:
            ask_idx = [i for i, s in enumerate(sentences) if _COMMAND_RE.search(s)][-1:] or [len(sentences) - 1]
        last_ask = ask_idx[-1] if ask_idx else -1
        segs: List[Tuple[List[str], float]] = []
        for i, s in enumerate(sentences):
            if i in ask_idx:
                role = ROLE_ASK
            elif _GIVEN_RE.search(s.strip()):
                role = ROLE_GIVEN                  # data / symbol definitions are not the skill
            elif i > last_ask >= 0:
                role = ROLE_CONTEXT * 0.8          # table header after the question sentence
            else:
                role = ROLE_CONTEXT
            segs.append((_stems(s), role))
            segs.extend(self._cue_segments(s, role))
        if options:
            segs.append((_stems(options), ROLE_OPTION))
        self.units.append({"marks": 1.0, "segments": segs})

    def _build_structured(self, text: str, qp_marks: int) -> None:
        cuts = [m.start() for m in _SUBPART_RE.finditer(text)]
        blocks = []
        if cuts:
            if text[: cuts[0]].strip():
                blocks.append(("intro", text[: cuts[0]]))
            for i, c in enumerate(cuts):
                blocks.append(("part", text[c: cuts[i + 1] if i + 1 < len(cuts) else len(text)]))
        else:
            blocks.append(("part", text))
        intro_segs: List[Tuple[List[str], float]] = []
        for kind, block in blocks:
            if kind == "intro":
                for s in self._sentences(block):
                    intro_segs.append((_stems(s), ROLE_INTRO))
                continue
            marks = sum(int(x) for x in _MARK_RE.findall(block)) or 0
            segs: List[Tuple[List[str], float]] = []
            for s in self._sentences(block):
                if _GIVEN_RE.search(s.strip()):
                    role = ROLE_GIVEN
                else:
                    role = ROLE_ASK if _COMMAND_RE.search(s) else ROLE_CONTEXT
                segs.append((_stems(s), role))
                segs.extend(self._cue_segments(s, role))
            if not any(st for st, _r in segs):
                continue
            self.units.append({"marks": float(marks), "segments": segs})
        # subparts without an explicit mark share whatever is left of the total
        known = sum(u["marks"] for u in self.units)
        missing = [u for u in self.units if u["marks"] <= 0]
        if missing:
            left = max(float(qp_marks or 0) - known, float(len(missing)))
            for u in missing:
                u["marks"] = left / len(missing)
        if intro_segs:
            if self.units:
                self.units[0]["segments"] = intro_segs + self.units[0]["segments"]
            else:
                self.units.append({"marks": float(qp_marks or 1), "segments": intro_segs})
        if not self.units:
            self.units.append({"marks": 1.0, "segments": [(_stems(text), ROLE_CONTEXT)]})

    @staticmethod
    def _cue_segments(sentence: str, role: float) -> List[Tuple[List[str], float]]:
        out = []
        for pat, phrases in _SKILL_CUES:
            if pat.search(sentence):
                for p in phrases:
                    out.append((_stems(p), role * 0.9))
        return out

    def all_segments(self) -> Iterable[Tuple[List[str], float, float]]:
        """(stems, role weight, unit mark share)."""
        total = sum(u["marks"] for u in self.units) or 1.0
        for u in self.units:
            share = u["marks"] / total
            for st, role in u["segments"]:
                yield st, role, share
        for st, role in self.ms_segments:
            yield st, role, 1.0 / max(len(self.units), 1)


# ---------------------------------------------------------------------------
# Passes
# ---------------------------------------------------------------------------
def _segment(stems: Sequence[str], store) -> List[Tuple[str, ...]]:
    """Greedy longest-match: each stretch of text counts once, as its most specific phrase."""
    out: List[Tuple[str, ...]] = []
    i, n = 0, len(stems)
    while i < n:
        for k in range(min(MAX_GRAM, n - i), 0, -1):
            g = tuple(stems[i:i + k])
            if g in store:
                out.append(g)
                i += k
                break
        else:
            i += 1
    return out


def _matches(prof: TopicProfiles, stems: Sequence[str]) -> Iterable[Tuple[Tuple[str, ...], Dict[str, float]]]:
    for g in _segment(stems, prof.major_w):
        yield g, prof.major_w[g]


def _pass_retrieval(prof: TopicProfiles, view: QuestionView, allowed: Sequence[str]) -> Dict[str, float]:
    """Pass B: whole-question retrieval against the syllabus text only (names + trusted vocabulary)."""
    allowed_set = set(allowed)
    acc: Dict[Tuple[str, ...], float] = defaultdict(float)
    for st, role, _share in view.all_segments():
        for g in _segment(st, prof.syl_w):
            acc[g] += role
    scores: Dict[str, float] = defaultdict(float)
    for g, tf in acc.items():
        sat = tf / (tf + 0.8)                         # BM25-style saturation
        base = sat * prof.syl_idf[g] * _len_bonus(g)
        for t, w in prof.syl_w[g].items():
            if t in allowed_set:
                scores[t] += base * w
    return dict(scores)


def _pass_primary_skill(prof: TopicProfiles, view: QuestionView, allowed: Sequence[str]) -> Dict[str, float]:
    """Pass C: what the candidate must do — ask/command clauses + MS, discriminative terms, by marks."""
    allowed_set = set(allowed)
    scores: Dict[str, float] = defaultdict(float)
    total_marks = sum(u["marks"] for u in view.units) or 1.0
    units = [(u["marks"] / total_marks, u["segments"]) for u in view.units]
    if view.ms_segments:
        units.append((0.35, view.ms_segments))
    for share, segs in units:
        local: Dict[str, float] = defaultdict(float)
        for st, role in segs:
            if role < ROLE_CONTEXT * 0.99 and role not in (ROLE_MS,):
                continue                               # options / intro do not define the skill
            for g, tm in _matches(prof, st):
                if len(tm) > prof.max_df_discriminative:
                    continue
                base = role * prof.idf[g] * _len_bonus(g)
                for t, w in tm.items():
                    if t in allowed_set:
                        local[t] += base * w
        tot = sum(local.values())
        if tot <= 0:
            continue
        for t, v in local.items():
            scores[t] += share * v / tot * min(1.0, tot / 1.5)
    return dict(scores)


def _ranked(scores: Dict[str, float]) -> List[Tuple[str, float]]:
    return sorted(((t, s) for t, s in scores.items() if s > 0 and math.isfinite(s)), key=lambda kv: (-kv[1], kv[0]))


def _verify_pair(prof: TopicProfiles, view: QuestionView, a: str, b: str) -> dict:
    """Discriminative comparison of two canonical topics ("why a / why not b")."""
    ea = eb = 0.0
    why_a: Dict[str, float] = defaultdict(float)
    why_b: Dict[str, float] = defaultdict(float)
    shared: set = set()
    for st, role, share in view.all_segments():
        weight = role * (0.5 + share)
        for g, tm in _matches(prof, st):
            wa, wb = tm.get(a, 0.0), tm.get(b, 0.0)
            if not wa and not wb:
                continue
            if wa and wb:
                shared.add(" ".join(g))
            v = weight * prof.idf[g] * _len_bonus(g)
            d = wa - wb                                   # shared terms count only by source strength
            if d > 0:
                ea += v * d
                why_a[" ".join(g)] += v * d
            elif d < 0:
                eb += v * -d
                why_b[" ".join(g)] += v * -d
    margin = (ea - eb) / (ea + eb + 1.0)
    top = lambda d: [k for k, _v in sorted(d.items(), key=lambda kv: (-kv[1], kv[0]))[:5]]
    return {"a": a, "b": b, "evidence_a": round(ea, 3), "evidence_b": round(eb, 3),
            "margin_a_over_b": round(margin, 4), "why_a": top(why_a), "why_not_b": top(why_b),
            "shared_non_discriminating": sorted(shared)[:8]}


def _is_strong(prof: TopicProfiles, g: Tuple[str, ...], topic: str) -> bool:
    """Specific evidence: a multi-word syllabus/keyword phrase, or a discriminative curated keyword."""
    tm = prof.major_w.get(g, {})
    if topic not in tm or len(tm) > prof.max_df_discriminative:
        return False
    if len(g) >= 2 and tm[topic] >= W_VOCAB:
        return True
    return prof.kw_w.get(g, {}).get(topic, 0.0) >= W_KEYWORD and tm[topic] >= W_KEYWORD * 0.99


def _strict_margin(prof: TopicProfiles, view: QuestionView, a: str, b: str) -> dict:
    """Final high-rigour check on strong evidence only (location-weighted, options excluded)."""
    ea = eb = 0.0
    sa, sb = set(), set()
    for st, role, share in view.all_segments():
        if role <= ROLE_OPTION:
            continue
        weight = role * (0.5 + share)
        for g, tm in _matches(prof, st):
            ga, gb = _is_strong(prof, g, a), _is_strong(prof, g, b)
            if ga and not gb:
                ea += weight * prof.idf[g] * _len_bonus(g); sa.add(" ".join(g))
            elif gb and not ga:
                eb += weight * prof.idf[g] * _len_bonus(g); sb.add(" ".join(g))
    return {"strong_a": sorted(sa)[:6], "strong_b": sorted(sb)[:6],
            "strict_margin_a_over_b": round((ea - eb) / (ea + eb + 1.0), 4)}


def _non_latin_share(text: str) -> float:
    letters = [ch for ch in text if ch.isalpha()]
    if not letters:
        return 0.0
    return sum(1 for ch in letters if ord(ch) > 0x24F) / len(letters)


def _challenger_has_question_support(prof, qp, view, challenger: str, incumbent: str) -> bool:
    qv = QuestionView(getattr(qp, "text", "") or "", int(getattr(qp, "marks", 0) or 0), "", view.is_mcq)
    if _positive_evidence(prof, qv, incumbent) <= 0.0:
        return True
    return _positive_evidence(prof, qv, challenger) > 0.0


def _positive_evidence(prof: TopicProfiles, view: QuestionView, topic: str) -> float:
    ev = 0.0
    for st, role, _share in view.all_segments():
        if role <= ROLE_OPTION:
            continue
        for g, tm in _matches(prof, st):
            if topic in tm and len(tm) <= prof.max_df_discriminative:
                ev += role * prof.idf[g] * tm[topic]
    return ev


# ---------------------------------------------------------------------------
# Classification view of the question text
# ---------------------------------------------------------------------------
# End-of-paper reference material that extraction appends to the LAST question
# (copyright notice, data sheet, Periodic Table).  It names every element /
# constant and would otherwise count as topic evidence.  Only the text used for
# classification is trimmed; the pipeline's question object is never modified.
_REFERENCE_START_RE = re.compile(
    r"(?:Permission to reproduce items where third-party owned material"
    r"|Important values, constants and standards"
    r"|The Periodic Table of (?:the )?Elements"
    r"|NOTES FOR USE IN QUALITATIVE ANALYSIS)", re.I)


# Optional-section papers (e.g. Geography options) print the heading of the
# NEXT option ("Coastal environments  If answering this option, answer
# Question 4 and ...") below the last question of the current option, so it is
# captured as the tail of that question and names the wrong topic.  A heading
# at the very start of a question belongs to that question and is kept.
_TRAILING_OPTION_HEADING_RE = re.compile(
    r"(?:\[\s*\d+\s*\]|[.?!:])\s*([^\[\].?!:]{0,120}?)\s*If answering this (?:option|section)\b.*$", re.I | re.S)


# Choice papers (e.g. English composition) print "OR" and the NEXT section's
# title ("OR / Narrative writing") after each option; only uppercase margin
# boilerplate may follow it.
_TRAILING_OR_HEADING_RE = re.compile(
    r"\n[ \t]*OR[ \t]*\n[ \t]*[A-Z][A-Za-z ,'\u2019\-]{2,60}[ \t]*(?:\n[^a-z\n]*)?\s*$")

# Chinese essay papers print a short topic heading (e.g. "\u6c61\u67d3") above each
# question; the splitter leaves the NEXT question's heading on its own line
# after the previous question's final sentence.
_TRAILING_CJK_HEADING_RE = re.compile(
    "(?<=[\u3002\uff1f\uff01?!])[ \\t]*\\n\\s*[\u4e00-\u9fff]{2,8}[ \\t]*$")

# Same layout in alphabetic-language essay papers: the next question's short
# topic title (e.g. "L\u2019ordre public") trails the previous question's final
# sentence on its own line. Only a short capitalised line with no sentence
# punctuation or mark brackets is treated as a heading.
_TRAILING_TITLE_LINE_RE = re.compile(
    "(?<=[.?!\u00bb])[ \\t]*(?:\\n[ \\t]*)+([A-Z\u00c0-\u00de][^\\n.?!:;\\[\\]()0-9]{2,50}?)[ \\t]*$")

# Paper-level instruction for the NEXT block of questions ("Questions 7-8 are
# based on the piece of drama that you have devised ...") printed after the
# previous question's mark allocation is captured as that question's tail.
_TRAILING_BLOCK_INSTRUCTION_RE = re.compile(
    "(?<=\\])\\s*Questions?\\s+\\d{1,2}\\s*(?:[\u2013\u2014\\-]|to|and)\\s*\\d{1,2}\\s+(?:are|is)\\s+(?:based\\s+on|about)\\b.*$",
    re.I | re.S)


# History papers print the NEXT depth study's heading ("DEPTH STUDY B:
# GERMANY, 1918-1945") after the previous question's mark allocation.
_TRAILING_DEPTH_STUDY_RE = re.compile(
    r"(?<=\])\s*(?:\d{1,2}\s+)?DEPTH\s+STUDY\s+[A-Z]\s*:.*$", re.S)


# "[Total: 25]" (Hindi papers: "[\u092a\u0942\u0930\u094d\u0923\u093e\u0902\u0915 8]", often extracted with stray glyphs)
# closes a question; whatever the splitter attached after it is the next
# exercise's heading/passage or page furniture, not this question.
_TOTAL_MARK_RE = re.compile("\\[\\s*(?:Total\\s*:?|\u092a\u0942[^\\]\\s]{1,6}\u0915)\\s*\\d{1,3}\\s*\\]", re.I)


def _strip_after_total(text: str, number=None) -> str:
    m = _TOTAL_MARK_RE.search(text)
    if not m or m.start() < 15 or m.end() >= len(text):
        return text
    after = text[m.end():]
    before = text[:m.end()]
    # A mis-split capture can instead START with the previous question's tail:
    # then the question's own number follows the marker (after margin text).
    # If both halves open with the number (a numbered list item was taken for
    # the question start), the substantive, longer half is the question.
    if number and re.match(r"[A-Z\s]{0,200}?(?<![\w.])" + re.escape(str(number)) + r"\s", after):
        if not re.match(r"\s*" + re.escape(str(number)) + r"\s", text) or len(after) > len(before):
            return after.lstrip()
    return text[:m.end()]


def _strip_trailing_option_heading(text: str) -> str:
    m = _TRAILING_OPTION_HEADING_RE.search(text)
    if m and m.start(1) >= 40:
        return text[:m.start(1)].rstrip()
    m = _TRAILING_OR_HEADING_RE.search(text)
    if m and m.start() >= 15:
        return text[:m.start()].rstrip()
    m = _TRAILING_CJK_HEADING_RE.search(text)
    if m and m.start() >= 15:
        return text[:m.start()].rstrip()
    m = _TRAILING_TITLE_LINE_RE.search(text)
    if m and m.start() >= 15 and len(m.group(1).split()) <= 6:
        return text[:m.start()].rstrip()
    m = _TRAILING_BLOCK_INSTRUCTION_RE.search(text)
    if m and m.start() >= 15:
        return text[:m.start()].rstrip()
    m = _TRAILING_DEPTH_STUDY_RE.search(text)
    if m and m.start() >= 15:
        return text[:m.start()].rstrip()
    return text


def strip_reference_material(text: str, number=None) -> str:
    if not text:
        return text
    text = _strip_trailing_option_heading(_strip_after_total(text, number))
    m = _REFERENCE_START_RE.search(text)
    if not m or m.start() < 15:        # never blank a question that *is* about the table
        return text
    return text[:m.start()]


_AR_LETTER = re.compile(r"[\u0621-\u064A]")
_AR_LAM_ALEF_HAMZA = re.compile(r"\u0627([\u0622\u0623\u0625])\u0644")
_AR_LAM_ALEF = re.compile(r"\u0627\u0651\u0644")
_AR_MARKS = re.compile(r"[\u064B-\u0652\u0670\u0640]")


def normalize_arabic(text: str) -> str:
    """Repair RTL extraction artefacts so Arabic keywords can match.

    PDF extraction emits the lam-alef ligatures reversed (``ا+أ+ل`` for
    ``ال+أ``, ``ا+ّ+ل`` for ``لا``) and keeps harakat/tatweel inside words,
    which breaks exact keyword matching.  Only used for the classification
    view; non-Arabic text is returned unchanged.
    """
    if not isinstance(text, str) or not _AR_LETTER.search(text):
        return text
    out = _AR_LAM_ALEF_HAMZA.sub(lambda m: "\u0627\u0644" + m.group(1), text)
    out = _AR_LAM_ALEF.sub("\u0644\u0627", out)
    return _AR_MARKS.sub("", out)


_DEV_LETTER = re.compile("[\u0900-\u097f]")
# Legacy Devanagari fonts extract each half-form conjunct (e.g. the reph in
# "\u092a\u0930\u094d\u092f\u091f\u0928") as a stray Latin-1/Latin-Extended glyph inside the word.
_DEV_JUNK = re.compile("(?<=[\u0900-\u097f])[\u00a0-\u02ff]+(?=[\u0900-\u097f])")
_DEV_HALF = re.compile("[\u0915-\u0939\u0958-\u095f]\u093c?\u094d[\u200c\u200d]?")


def devanagari_skeleton(text: str) -> str:
    """Drop consonant+virama half-forms so damaged and intact conjuncts compare equal."""
    return _DEV_HALF.sub("", text)


def normalize_devanagari(text: str) -> str:
    """Classification-view repair for Devanagari extracted from legacy fonts.

    Removes stray glyphs that stand in for half-form conjuncts, then reduces
    every conjunct to its final consonant (see ``devanagari_skeleton``); the
    keyword matcher accepts the same skeleton form.  Non-Devanagari text is
    returned unchanged.
    """
    if not isinstance(text, str) or not _DEV_LETTER.search(text):
        return text
    return devanagari_skeleton(_DEV_JUNK.sub("", text))


_AR_WORD = re.compile("[\u0621-\u063a\u0641-\u065f\u0670-\u06d3]+")   # letters/marks, no punctuation or tatweel
# Urdu (Nastaliq) PDFs sometimes extract every word in visual glyph order, so
# the letters of each word arrive permuted.  \u06ba (noon ghunna) and \u06d2 (bari ye) are
# word-final-only letters in Urdu: a word that STARTS with one of them cannot
# occur in correctly ordered text, and Arabic text never contains them.
_UR_FINAL_ONLY = ("\u06ba", "\u06d2")
_UR_NORMAL = ("\u0645\u06cc\u06ba", "\u06c1\u06d2", "\u06a9\u06d2", "\u0646\u06c1\u06cc\u06ba", "\u06a9\u06cc", "\u06a9\u0627")


def _anagram_index(vocab):
    index, clash = {}, set()
    for kw in vocab or ():
        for w in _AR_WORD.findall(str(kw)):
            if len(w) < 3:
                continue
            key = "".join(sorted(w))
            if key in index and index[key] != w:
                clash.add(key)
            index[key] = w
    for key in clash:              # ambiguous anagrams are never "restored"
        index.pop(key, None)
    return index


def restore_urdu_visual_order(text: str, vocab=None) -> str:
    """Re-spell permuted Urdu words as the config keyword they are an exact anagram of."""
    if not isinstance(text, str) or not vocab or "\u06ba" not in text and "\u06d2" not in text:
        return text
    tokens = _AR_WORD.findall(text)
    scrambled = sum(1 for w in tokens if w.startswith(_UR_FINAL_ONLY))
    normal = sum(tokens.count(w) for w in _UR_NORMAL)
    if scrambled < 1 or normal * 3 >= scrambled:
        return text
    index = _anagram_index(vocab)
    if not index:
        return text
    return _AR_WORD.sub(lambda m: index.get("".join(sorted(m.group())), m.group())
                        if len(m.group()) >= 3 else m.group(), text)


# Older CAIE PDFs (roughly pre-2015) render the integral sign from a symbol
# font that text extraction returns as a lone "ä"/"ã"/"ò".  Restore it only as
# a standalone token in text that also carries a differential (dx, dt, dθ...),
# so ordinary words (German/French/Portuguese) are never touched.
_INTEGRAL_GLYPH = re.compile(r"(?<![^\W\d_])[äãò](?![^\W\d_])")
_DIFFERENTIAL = re.compile(r"(?<![A-Za-z])d\s?[xtuyθrv](?![A-Za-z])")


_LIGATURES = str.maketrans({"\ufb00": "ff", "\ufb01": "fi", "\ufb02": "fl",
                            "\ufb03": "ffi", "\ufb04": "ffl", "\ufb05": "st", "\ufb06": "st",
                            # Typographic apostrophes -> ASCII, so keywords such as
                            # "hess's law" / "two's complement" match "Hess’s law".
                            "\u2019": "'", "\u2018": "'", "\u02bc": "'"})


def expand_ligatures(text: str) -> str:
    """Typographic ligatures (common in older PDFs) -> plain letters, so
    'signiﬁcance' matches the keyword 'significance'; curly apostrophes -> '."""
    return text.translate(_LIGATURES) if text else text


def restore_integral_sign(text: str) -> str:
    if not text or not _INTEGRAL_GLYPH.search(text) or not _DIFFERENTIAL.search(text):
        return text
    return _INTEGRAL_GLYPH.sub("∫", text)


# Language comprehension papers print each exercise as a header ("Exercice 2
# Questions 21-29", "Zweite Aufgabe, Fragen 21-30", "Ejercicio 2 Preguntas
# 21-30") followed by the reading passage, and extraction appends that block to
# the PREVIOUS question (after its "[Total: N]").  The one-line questions of
# the exercise then carry no theme words, while the carrier question is scored
# on the wrong passage.  Classification-only: the carrier's view drops the
# block and the questions of that range are scored with the passage as context.
_EXERCISE_RANGE_RE = re.compile(
    r"\b(?:Questions?|Preguntas|Fragen|Domande|Perguntas|Quest\u00f5es)\s+"
    r"(\d{1,2})\s*[\u2013\u2014\-]\s*(\d{1,2})\b", re.I)
_EXERCISE_PASSAGE_MAX = 4000


def split_exercise_passage(text, number):
    """Return (own_text, [(first, last, passage), ...]) for exercise headers in ``text``.

    A header whose range lies after ``number`` belongs to a later exercise and is
    cut from ``own_text``; a header covering ``number`` is the question's own.
    """
    if not isinstance(text, str) or not text:
        return text, []
    found = []
    cut = None
    for m in _EXERCISE_RANGE_RE.finditer(text):
        a, b = int(m.group(1)), int(m.group(2))
        if not (0 < a < b <= a + 40):
            continue
        nxt = _EXERCISE_RANGE_RE.search(text, m.end())
        passage = text[m.start(): nxt.start() if nxt else len(text)][:_EXERCISE_PASSAGE_MAX]
        found.append((a, b, passage))
        if cut is None and isinstance(number, int) and a > number:
            cut = m.start()
    own = text[:cut] if cut is not None and cut > 0 else text
    return own, found


# A-Level language reading papers print the passages in an insert; the
# vocabulary items ("trouvez dans le Texte 1 le mot qui correspond...") then
# carry no theme words, while the comprehension questions on the same text
# do.  Questions citing the same text share each other's wording as context.
_TEXT_REF_RE = re.compile(r"(?:\b(?:Texte|Texto|Testo|Text)\s*([12])\b|\u77ed\u6587([\u4e00\u4e8c]))")
_TEXT_REF_MAX = 1500


def _text_reference_context(memory, key, number, own):
    refs = set()
    for m in _TEXT_REF_RE.finditer(own or ""):
        refs.add(m.group(1) or ("1" if m.group(2) == "\u4e00" else "2"))
    if not refs:
        return []
    store = memory.setdefault(key + ("text_refs",), {})
    snippet = re.sub(r"\s+", " ", re.sub(r"[.\u2026]{3,}", " ", own))[:_TEXT_REF_MAX]
    for r in refs:
        store.setdefault(r, {})[number] = snippet
    out = []
    for r in sorted(refs):
        for n, t in sorted(store.get(r, {}).items()):
            if n != number and t not in out:
                out.append(t)
    return out


def apply_exercise_context(memory, matched_question, view):
    """Record exercise passages seen in this question; return ``view`` with them applied."""
    qp = getattr(view, "qp", None)
    text = getattr(qp, "text", None)
    if not isinstance(text, str):
        return view
    number = getattr(matched_question, "number_int", None)
    if not isinstance(number, int) or isinstance(number, bool) or number <= 0:
        return view
    key = (str(getattr(matched_question, "full_qp_code", "") or getattr(matched_question, "paper_code", "")),
           str(getattr(matched_question, "variant", "")), str(getattr(matched_question, "year", "")))
    own, found = split_exercise_passage(text, number)
    if found:
        store = memory.setdefault(key, {})
        for a, b, passage in found:
            # Merge, never overwrite: a seeded listening transcript block for
            # the same range is the richer evidence; the QP instruction line is
            # appended to it.
            cur = store.get((a, b))
            store[(a, b)] = (cur + "\n" + passage) if cur else passage
    covering = [(a, b) for (a, b) in memory.get(key, {}) if a <= number <= b]
    if covering:
        # B7-listening (2026-10-01): remember each question's own wording so a
        # weak-signal sibling can pool the whole exercise block (one passage =
        # one theme) as second-chance evidence.
        blocks = memory.setdefault(key + ("blocks",), {})
        snip = re.sub(r"\s+", " ", own)[:700]
        for ab in covering:
            blocks.setdefault(ab, {})[number] = snip
    context = [p for (a, b), p in memory.get(key, {}).items()
               if a <= number <= b and p not in own]
    context += _text_reference_context(memory, key, number, own)
    if own == text and not context:
        return view
    import copy as _copy
    mq = _copy.copy(view)
    qp2 = _copy.copy(qp)
    qp2.text = own + ("\n" + "\n".join(context) if context else "")
    mq.qp = qp2
    return mq


# B7-listening (2026-10-01): a listening/reading exercise is ONE passage with ONE
# theme, but individual MCQ stems can be a single line with no theme words at
# all ("Wer hat Sonja eine Nachricht geschickt?").  When such a question scores
# weakly on its own, the siblings in the same exercise block carry the theme.
BLOCK_POOL_TOP_SCORE_MAX = 8.0


def block_pool_view(memory, matched_question, view, max_chars: int = 4000):
    """Return ``view`` with the sibling questions' text of the covering exercise
    block appended, or ``view`` unchanged when no block evidence exists."""
    qp = getattr(view, "qp", None)
    text = getattr(qp, "text", None)
    number = getattr(matched_question, "number_int", None)
    if not isinstance(text, str) or not isinstance(number, int) or number <= 0:
        return view
    key = (str(getattr(matched_question, "full_qp_code", "") or getattr(matched_question, "paper_code", "")),
           str(getattr(matched_question, "variant", "")), str(getattr(matched_question, "year", "")))
    blocks = memory.get(key + ("blocks",), {})
    parts: list[str] = []
    for (a, b), passage in memory.get(key, {}).items():
        if a <= number <= b and passage not in parts:
            parts.append(passage)  # the exercise instruction line itself
    # Listening transcript blocks (seeded separately; too noisy to attach to
    # every question, perfect as second-chance evidence).
    for (a, b), passage in memory.get(key + ("transcript",), {}).items():
        if a <= number <= b and passage not in parts:
            parts.append(passage)
    for (a, b), snips in blocks.items():
        if a <= number <= b:
            for n in sorted(snips):
                if n != number and snips[n] not in parts:
                    parts.append(snips[n])
    pooled = "\n".join(parts)[:max_chars]
    if not pooled:
        return view
    import copy as _copy
    mq = _copy.copy(view)
    qp2 = _copy.copy(qp)
    qp2.text = text + "\n" + pooled
    mq.qp = qp2
    return mq


def classification_view(matched_question, vocab=None):
    """Shallow proxy of ``matched_question`` whose qp.text excludes reference pages."""
    import copy as _copy
    qp = getattr(matched_question, "qp", None)
    text = getattr(qp, "text", None)
    if not isinstance(text, str):
        return matched_question
    number = getattr(matched_question, "number_int", None)
    if not isinstance(number, int) or isinstance(number, bool) or number <= 0:
        number = None
    trimmed = normalize_devanagari(normalize_arabic(strip_reference_material(text, number)))
    trimmed = restore_urdu_visual_order(trimmed, vocab)
    trimmed = restore_integral_sign(expand_ligatures(trimmed))
    if trimmed is text or trimmed == text:
        return matched_question
    mq = _copy.copy(matched_question)
    qp2 = _copy.copy(qp)
    qp2.text = trimmed
    mq.qp = qp2
    return mq


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
def refine(classifier, matched_question, result, mark_scheme_text: str = "", force_winner: bool = False):
    """Return ``result`` with a verified ``winning_major``; never raises."""
    try:
        return _refine(classifier, matched_question, result, mark_scheme_text, force_winner)
    except Exception as exc:  # pragma: no cover - defensive: never break the pipeline
        try:
            result.verification = {"engine": ENGINE_VERSION, "status": "error_kept_base",
                                   "error": f"{type(exc).__name__}: {exc}"[:300]}
        except Exception:
            pass
        return result


def _allowed_topics(classifier, result) -> List[str]:
    majors = list(getattr(classifier.config, "major_topics", []) or [])
    scope = (getattr(result, "evidence_summary", None) or {}).get("paper_scope") or {}
    paper_number = scope.get("paper_number")
    paper_topics = (getattr(classifier.config, "data", {}) or {}).get("paper_topics") or {}
    allowed = list(paper_topics.get(str(paper_number), []) or []) if paper_number else []
    allowed = [t for t in allowed if t in majors] or majors
    if scope.get("detailed_scope_enforced") and scope.get("allowed_detailed_topics"):
        mapping = getattr(classifier.config, "mapping", {}) or {}
        det_majors = {mapping.get(d, d) for d in scope["allowed_detailed_topics"]}
        allowed = [t for t in allowed if t in det_majors] or allowed
    return allowed


def _is_math_subject(classifier) -> bool:
    try:
        from .math_category import is_mathematics_subject
        cfg = classifier.config
        return bool(is_mathematics_subject(getattr(cfg, "subject", "") or "", str(getattr(cfg, "syllabus_code", "") or "")))
    except Exception:
        return False


def _refine(classifier, matched_question, result, mark_scheme_text: str, force_winner: bool):
    base_topic = getattr(result, "winning_major", "") or ""
    record = {"engine": ENGINE_VERSION, "base_topic": base_topic, "final_topic": base_topic,
              "changed": False, "status": "kept_base", "path": []}
    # --- sanity gates: only refine a normal scored/forced decision -----------
    summary = getattr(result, "evidence_summary", None)
    if not base_topic or not isinstance(summary, dict) or "direct_topic_scores_before_memory" not in summary:
        record["status"] = "not_applicable"        # review routing / special routes stay exactly as they are
        result.verification = record
        return result
    allowed = _allowed_topics(classifier, result)
    if _is_math_subject(classifier):
        # maths questions are short and notation-heavy: the retrieval /
        # primary-skill passes measured less reliable than the base scorer
        # (0607 held-out), so the base decision stands.
        record["status"] = "not_applicable"
        record["path"].append("mathematics->keep_base")
        result.verification = record
        return result
    if base_topic not in allowed or len(allowed) < 2:
        record["status"] = "not_applicable"
        result.verification = record
        return result

    prof = profiles_for(classifier)
    qp = getattr(matched_question, "qp", None)
    qtext = getattr(qp, "text", "") or ""
    if prof.keyword_coverage < MIN_KEYWORD_COVERAGE or _non_latin_share(qtext) > MAX_NON_LATIN_SHARE:
        record["status"] = "not_applicable"
        record["path"].append("script_not_readable->keep_base")
        # The set-text choice rubric is a structural cue, readable in any script.
        settext = _set_text_essay_topic(matched_question, allowed)
        if settext and settext != base_topic:
            record["path"].append(f"set_text_essay_prior->{settext}")
            view = QuestionView(qtext, int(getattr(qp, "marks", 0) or 0), mark_scheme_text or "",
                                str(getattr(matched_question, "paper_format", "") or "").upper() == "MCQ")
            _apply(classifier, result, base_topic, settext, prof, view)
            record.update({"final_topic": settext, "changed": True, "status": "verified_override"})
        result.verification = record
        return result
    view = QuestionView(getattr(qp, "text", "") or "", int(getattr(qp, "marks", 0) or 0),
                        mark_scheme_text or "",
                        str(getattr(matched_question, "paper_format", "") or "").upper() == "MCQ")

    # --- independent passes --------------------------------------------------
    a_scores = {t: float(s) for t, s in (getattr(result, "major_topic_scores", {}) or {}).items() if t in allowed}
    b_scores = _pass_retrieval(prof, view, allowed)
    c_scores = _pass_primary_skill(prof, view, allowed)
    passes = {"A_keyword_scorer": a_scores, "B_definition_retrieval": b_scores, "C_primary_skill": c_scores}
    tops: Dict[str, Optional[str]] = {}
    for name, sc in passes.items():
        rk = _ranked(sc)
        # structural validation of every pass output: canonical, allowed, finite
        top = rk[0][0] if rk and rk[0][0] in allowed else None
        if name == "A_keyword_scorer":
            top = base_topic
        tops[name] = top
        record.setdefault("passes", {})[name] = {
            "topic": top, "competitors": [t for t, _s in rk[:4] if t != top][:3],
            "scores": {t: round(s, 3) for t, s in rk[:4]}}
    a = base_topic
    b, c = tops["B_definition_retrieval"], tops["C_primary_skill"]
    record["candidates"] = sorted({x for x in (a, b, c) if x} | {t for t in prof.partners(a) if t in allowed})

    # --- decision ------------------------------------------------------------
    final = a
    if (b in (None, a)) and (c in (None, a)):
        record["path"].append("agreement" if b == a and c == a else "agreement_with_abstention")
    elif b and c and b == c:
        v = _verify_pair(prof, view, b, a)
        record["verifications"] = [v]
        record["path"].append("B+C_disagree_with_A->verify")
        if v["margin_a_over_b"] >= MARGIN_CONSENSUS:
            final = b
    elif (b is None or b == a) != (c is None or c == a):
        x = c if (b is None or b == a) else b
        v = _verify_pair(prof, view, x, a)
        record["verifications"] = [v]
        record["path"].append("single_dissent->verify")
        if v["margin_a_over_b"] >= MARGIN_SINGLE:
            final = x
    else:
        trio = [a, b, c]
        wins = {t: 0.0 for t in trio}
        vs = []
        for i in range(3):
            for j in range(i + 1, 3):
                v = _verify_pair(prof, view, trio[i], trio[j])
                vs.append(v)
                m = v["margin_a_over_b"]
                wins[trio[i]] += m
                wins[trio[j]] -= m
        survivor = sorted(trio, key=lambda t: (-wins[t], t != a, t))[0]
        record["path"].append("three_way->round_robin")
        if survivor != a:
            v = _verify_pair(prof, view, survivor, a)
            vs.append(v)
            if v["margin_a_over_b"] >= MARGIN_ROUND:
                final = survivor
        record["verifications"] = vs

    # --- final rigorous checks before accepting a change -------------------
    if final != a:
        strict = _strict_margin(prof, view, final, a)
        record["strict_verification"] = strict
        checks = {
            "canonical_and_allowed": final in allowed,
            "positive_evidence": _positive_evidence(prof, view, final) > 0.0,
            # ...and when the question text itself supports the incumbent, the
            # challenger needs some support there too: mark-scheme front matter
            # (e.g. "Section A – Christianity, Section B – Islam") alone is not
            # evidence about this question.
            "question_text_evidence": _challenger_has_question_support(prof, qp, view, final, a),
            # the challenger must not be beaten on specific evidence by the incumbent
            "not_outweighed_on_strong_evidence": strict["strict_margin_a_over_b"] >= STRICT_MIN_MARGIN,
        }
        record["final_checks"] = checks
        if not all(checks.values()):
            record["path"].append("final_check_failed->keep_A")
            final = a
    # --- structural prior: combined-science MCQ papers are sectioned --------
    section = _section_order_topic(classifier, matched_question, view, allowed)
    if section and section != final:
        record["path"].append(f"section_order_prior->{section}")
        final = section
    settext = _set_text_essay_topic(matched_question, allowed)
    if settext and settext != final:
        record["path"].append(f"set_text_essay_prior->{settext}")
        final = settext
    if final != a:
        _apply(classifier, result, a, final, prof, view)
        record.update({"final_topic": final, "changed": True, "status": "verified_override"})
    else:
        record["status"] = "verified_base"
    result.verification = record
    return result


# Cambridge combined / co-ordinated science multiple-choice papers print their
# 40 questions in three blocks: Biology, then Chemistry, then Physics (block
# edges fall at 13/14 and 27/28).  Questions at or next to an edge are left to
# the content passes so a shifted boundary can never force a wrong topic.
_SECTION_MAJORS = ("Biology", "Chemistry", "Physics")
_SECTION_BANDS = ((1, 12, "Biology"), (15, 26, "Chemistry"), (29, 40, "Physics"))


def _section_order_topic(classifier, matched_question, view: QuestionView, allowed) -> Optional[str]:
    majors = list(getattr(classifier.config, "major_topics", []) or [])
    if sorted(majors) != sorted(_SECTION_MAJORS) or not view.is_mcq:
        return None
    if getattr(classifier.config, "board", "") not in ("", None) and \
            str(getattr(classifier.config, "board", "")).upper() not in ("CAIE", "CIE", "CAMBRIDGE"):
        return None
    # The paper may be flagged MCQ from its component number alone (older
    # 0653/0654 Paper 2 was structured theory).  CAIE multiple-choice items
    # never carry mark allocations, so a "[n]" mark means it is not MCQ.
    qp_text = str(getattr(getattr(matched_question, "qp", None), "text", "") or "")
    if re.search(r"\[\s*\d{1,2}\s*\]", qp_text):
        return None
    m = re.search(r"\d+", str(getattr(matched_question, "question_number", "") or ""))
    if not m:
        return None
    n = int(m.group())
    for lo, hi, topic in _SECTION_BANDS:
        if lo <= n <= hi:
            return topic if topic in allowed else None
    return None


# Language A-Level literature papers: each set-text question prints the
# choice instruction ("Choisissez soit la partie (a) soit la partie (b)",
# "Waehlen Sie entweder (a) oder (b)", "Conteste la pregunta (a) o la pregunta
# (b)", "...任选其一") together with the essay length ("500 a 600 mots").  The
# printed extract is about anything (families, war, love), so its vocabulary
# must not decide the topic.  Both cues are required.
_SET_TEXT_TOPIC = "Literature_and_the_arts"
_SET_TEXT_CHOICE_RE = re.compile(
    r"(?:choisissez\s+soit|w\u00e4hlen\s+sie\s+entweder|contest[ae]\s+la\s+pregunta\s+\(a\)\s+o"
    r"|responda\s+(?:\u00e0\s+)?(?:pergunta\s+)?\(a\)\s+ou|scegli|\u4efb\u9009\u5176\u4e00)", re.I)
_SET_TEXT_LENGTH_RE = re.compile(
    r"(?:\d{3}\s*(?:\u00e0|bis|y|a|e)\s*\d{3}\s*(?:mots|w\u00f6rtern|palabras|palavras|parole)"
    r"|\d{3}\s*\u5230\s*\d{3}\s*\u5b57)", re.I)


# Older papers (before the word-count line was printed) state the full
# either/or choice instead: "soit la partie (a) soit la partie (b)",
# "entweder (a) oder (b)", "la pregunta (a) o la pregunta (b)",
# "从问题 (a) 或问题 (b) 中任选其一".
_SET_TEXT_FULL_CHOICE_RE = re.compile(
    r"(?:soit\s+(?:la\s+partie\s+)?\(a\)\s+soit\s+(?:la\s+partie\s+)?\(b\)"
    r"|entweder\s+\(a\)\s+oder\s+\(b\)"
    r"|la\s+pregunta\s+\(a\)\s+o\s+la\s+pregunta\s+\(b\)"
    r"|\u95ee\u9898\s*\(a\)\s*\u6216\u95ee\u9898\s*\(b\)\s*\u4e2d\u4efb\u9009\u5176\u4e00)", re.I)


def _set_text_essay_topic(matched_question, allowed) -> Optional[str]:
    if _SET_TEXT_TOPIC not in allowed:
        return None
    qp_text = str(getattr(getattr(matched_question, "qp", None), "text", "") or "")[:600]
    if _SET_TEXT_CHOICE_RE.search(qp_text) and (
            _SET_TEXT_LENGTH_RE.search(qp_text) or _SET_TEXT_FULL_CHOICE_RE.search(qp_text)):
        return _SET_TEXT_TOPIC
    return None


def _apply(classifier, result, old: str, new: str, prof: TopicProfiles, view: QuestionView) -> None:
    """Change the winner only; keep every other field and the <=4 detailed-topic invariant."""
    scope = (getattr(result, "evidence_summary", None) or {}).get("paper_scope") or {}
    allowed_det = set(scope.get("allowed_detailed_topics") or []) if scope.get("detailed_scope_enforced") else None
    dets = [d for d in (prof.details_of.get(new) or [new]) if allowed_det is None or d in allowed_det] or [new]
    if len(dets) > 1:
        score: Dict[str, float] = defaultdict(float)
        for st, role, _share in view.all_segments():
            for g in _grams(st):
                for d, w in prof.detail_w.get(g, {}).items():
                    if d in dets:
                        score[d] += role * prof.idf.get(g, 0.0) * w
        dets = sorted(dets, key=lambda d: (-score.get(d, 0.0), d))
    lead = dets[0]
    existing = [d for d in (getattr(result, "detailed_topics", []) or []) if d != lead]
    result.detailed_topics = ([lead] + existing)[:4]
    result.winning_major = new
    # A verified override came out of a disagreement: never let the base
    # scorer's confidence (which was for the *old* topic) certify the new one,
    # so it can never be stored as a known-correct / high-confidence example.
    try:
        result.confidence = min(float(result.confidence), OVERRIDE_CONFIDENCE_CAP)
    except Exception:
        pass
    try:
        result.reasoning = f"{result.reasoning} | verified override: {old} -> {new} ({ENGINE_VERSION})"
    except Exception:
        pass
