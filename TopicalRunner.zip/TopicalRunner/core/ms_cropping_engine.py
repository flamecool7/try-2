"""
MS Cropping Engine - LOCKED Gold-Standard Exact Copy from GitHub

ABSOLUTE RULE: COPY AND USE THE MARK SCHEME CROPPING MECHANISM EXACTLY AS IT EXISTS IN THE GITHUB REPOSITORY.

GitHub source: Topical_Generation_Final.zip / cambridge_qb/ms_crop.py + markscheme_split.py + markscheme.py

This file is MINIMAL INTEGRATION layer - no enhancements, no optimization, no refactoring, no redesign.

QP cropper and MS cropper MUST remain separate:
- QP -> existing approved QP cropper (question_split.py -> CroppingEngine)
- MS -> exact GitHub MS cropper (this file)

Only permitted changes: import paths, file paths, dependency handling, I/O connections.
NO changes to crop boundaries, whitespace handling, padding, page detection, question detection, etc.

Original GitHub implementation preserved exactly in:
- core/ms_crop_gold.py (exact copy of ms_crop.py)
- core/markscheme_split_gold.py (exact copy of markscheme_split.py)
- core/markscheme_gold.py (exact copy of markscheme.py)
- core/pdf_io_gold.py, converter_gold.py (dependencies)

This wrapper only adapts I/O to universal generator's CroppedQuestion format.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Dict
from dataclasses import dataclass
from PIL import Image

# Ensure original_reference and core gold files are importable
sys.path.insert(0, str(Path(__file__).parent.parent / "original_reference"))
sys.path.insert(0, str(Path(__file__).parent))

try:
    # Import EXACT gold-standard MS cropping implementation - no modifications
    from core.ms_crop_gold import crop_to_mark_box as gold_crop_to_mark_box
    from core.markscheme_split_gold import split_structured_mark_scheme as gold_split_structured
    from core.markscheme_gold import process_mark_schemes as gold_process_mark_schemes, lookup_mark_scheme as gold_lookup
    GOLD_MS_AVAILABLE = True
except Exception as e:
    print(f"[MSCroppingEngine] Gold-standard MS import failed: {e}")
    GOLD_MS_AVAILABLE = False

# Also try original_reference path
try:
    if not GOLD_MS_AVAILABLE:
        sys.path.insert(0, str(Path(__file__).parent.parent / "original_reference"))
        from cambridge_qb.ms_crop import crop_to_mark_box as gold_crop_to_mark_box
        from cambridge_qb.markscheme_split import split_structured_mark_scheme as gold_split_structured
        from cambridge_qb.markscheme import process_mark_schemes as gold_process_mark_schemes
        GOLD_MS_AVAILABLE = True
except Exception as e:
    print(f"[MSCroppingEngine] Fallback gold MS import failed: {e}")

try:
    import fitz
    HAS_FITZ = True
except ImportError:
    try:
        import pymupdf as fitz
        HAS_FITZ = True
    except ImportError:
        HAS_FITZ = False

@dataclass
class MSCroppedQuestion:
    question_number: str
    number_int: int
    paper_code: str
    images: List[Image.Image]
    assembled_image: Image.Image = None
    text: str = ""
    marks: int = 0
    pages: List[int] = None

class MSCroppingEngine:
    """
    MS Cropping Engine - EXACT GitHub implementation, no enhancements
    Uses gold-standard ms_crop + markscheme_split exactly as in GitHub repo
    """

    def __init__(self, target_width=2280, quality=95, dpi=200):
        # Use same target width as QP for consistency, but MS cropper crops tightly to black border
        # per gold-standard ms_crop.py: it finds outer black border rectangle and crops tightly
        # with small margin 1px, no fixed crop values
        self.target_width = target_width
        self.quality = quality
        self.dpi = dpi

    def process_paper(self, pdf_path: Path, expected_questions=None) -> List[MSCroppedQuestion]:
        """
        Process MS paper using EXACT GitHub implementation
        No enhancements, no optimization, no refactoring
        """
        pdf_path = Path(pdf_path)
        print(f"[MSCroppingEngine] Processing {pdf_path.name} with GOLD-STANDARD MS engine (LOCKED)")

        if not GOLD_MS_AVAILABLE:
            # FAIL-CLOSED (defect 5): this engine never fabricated crops — the old
            # log line lied about a "dummy". Loud, explicit stop instead.
            print(f"[MSCroppingEngine] ❌ Gold MS engine not importable — 0 MS crops for {pdf_path.name}; paper must NOT be marked complete")
            return []

        try:
            # Use gold-standard split_structured_mark_scheme - EXACT COPY from GitHub
            # This is based on structure observed across nine official 2025 mark schemes
            # - Answer content organised into tables headed Question | Answer | Marks
            # - Header band bounded by two long horizontal rules
            # - Previous question ends at header's top rule, following starts at bottom rule
            # - Direct transition without header separated by long horizontal rule above new label
            # - No question-paper fixed crop, no automatic cut through whitespace at arbitrary coordinate
            # - Output only when all required boundaries are structural table rules and sequence complete

            images_by_question, diagnostics = gold_split_structured(
                pdf_path,
                dpi=self.dpi,
                expected_question_numbers=expected_questions,
            )

            print(f"[MSCroppingEngine] Gold-standard MS extracted {len(images_by_question)} questions from {pdf_path.name}")
            if diagnostics:
                print(f"  Diagnostics: found={diagnostics.markers_found}, missing={diagnostics.missing_questions}, unexpected={diagnostics.unexpected_questions}")
                for note in diagnostics.split_notes[:10]:
                    print(f"  [ms-split] {note}")
                for warning in diagnostics.warnings[:10]:
                    print(f"  [ms-warning] {warning}")

            if not images_by_question:
                # The original structured MS cropper found no structural boxes.
                # Do not substitute QP cropping or fabricate question numbers.
                return []

            results = []
            for qnum, img in sorted(images_by_question.items()):
                # Apply tight crop to black border per gold-standard ms_crop.py - EXACT COPY
                try:
                    cropped = gold_crop_to_mark_box(
                        img,
                        dark_threshold=150,
                        col_threshold=0.45,
                        gap_tol=12,
                        margin=1,
                    )
                except Exception as e:
                    print(f"[MSCroppingEngine] crop_to_mark_box failed for Q{qnum}: {e}, using original")
                    cropped = img

                try:
                    number_int = int(qnum)
                except Exception as e:
                    number_int = int(''.join(filter(str.isdigit, str(qnum))) or 0)

                results.append(MSCroppedQuestion(
                    question_number=f"Q{number_int}" if number_int else f"Q{qnum}",
                    number_int=number_int,
                    paper_code=pdf_path.stem,
                    images=[cropped],
                    assembled_image=cropped,
                    text=f"Mark scheme for question {qnum}",
                    marks=0,
                    pages=[],
                ))

            return results

        except Exception as e:
            print(f"[MSCroppingEngine] Gold-standard MS processing failed for {pdf_path.name}: {e}")
            import traceback
            traceback.print_exc()
            return []

    def extract_mcq_answers(self, pdf_path: Path) -> Dict[int, str]:
        """IGCSE paper-format round (user decision mcq_ms=letters).

        Extract the answer grid from an MCQ mark scheme -> {question_int:
        letter "A".."D"}. THIN ADAPTER ONLY: parsing is delegated to the
        LOCKED gold parser (core/markscheme_gold.py::_parse_mcq_answers) over
        pages rendered by core/pdf_io.py::render_pdf_with_rotation_info —
        exactly the call pattern gold process_mark_schemes() itself uses for
        MCQ papers. No new parsing logic lives here. No MS images are produced
        (there is nothing to crop in a bare grid); the letters ride in
        metadata.json (ms_answer) instead of an MS webp.
        """
        pdf_path = Path(pdf_path)
        print(f"[MSCroppingEngine] Extracting MCQ answer grid from {pdf_path.name} (LOCKED gold MCQ parser)")
        if not GOLD_MS_AVAILABLE:
            # FAIL-CLOSED — same contract as process_paper
            print(f"[MSCroppingEngine] ❌ Gold MS engine not importable - 0 MCQ answers for {pdf_path.name}; paper must NOT be marked complete")
            return {}
        try:
            from core.markscheme_gold import _parse_mcq_answers as _gold_parse_mcq
            from core.pdf_io import render_pdf_with_rotation_info as _render_rot
            images, _scale, _rotations, doc = _render_rot(pdf_path, dpi=self.dpi)
            try:
                answers = _gold_parse_mcq(doc, images)
            finally:
                doc.close()
                del images
            print(f"[MSCroppingEngine] MCQ grid: {len(answers)} answers from {pdf_path.name}")
            return dict(answers)
        except Exception as e:
            print(f"[MSCroppingEngine] MCQ answer extraction failed for {pdf_path.name}: {e}")
            import traceback
            traceback.print_exc()
            return {}


# ---------------------------------------------------------------------------
# A20 (2026-09-26) fat-MS dpi step-down. The LOCKED MSCroppingEngine class
# above is byte-unchanged; this module-level section only picks the dpi the
# caller's engine is constructed with. dpi is and always was a caller-owned
# runtime parameter (every production site already passes dpi=150 instead of
# the class default 200) — no crop-boundary, detection, or whitespace logic
# is involved. Proof: 0470_s26_ms_11 (77 pages) splits 18/18 with zero
# missing at dpi=100 (719MB peak) where dpi=150 needs ~1.4GB and is
# SIGKILLed on the 1984MB reference box; crop text stays fully legible.
# ---------------------------------------------------------------------------

# Budgets measured on the 1984MB reference box (engine peaks 282/452/765MB
# at 10/20/38 pages at dpi=150: ~17.2MB/page + ~110MB fixed; dpi=100 peaks
# 719MB on the full 77-page 0470 MS; a worker past ~1313MB anon-rss is
# SIGKILLed — see run_guarded's _MAX_WORKER_RSS_MB calibration). Single
# source of truth — run_guarded's S3 and bundle_worker honor these too.
MS_FAT_SPOOL_MIN_PAGES = 28   # S3 parks QP pixels before the MS leg above this
MS_FAT_DPI_MIN_PAGES = 40     # engine dpi steps 150 -> MS_FAT_DPI above this
MS_FAT_DPI = 100              # stepped-down dpi (18/18 verified, 719MB peak)
MS_FAT_REFUSE_MIN_PAGES = 96  # above this even dpi=100 exceeds the box: the
                              # caller must route graceful QP-only review.


def ms_pdf_page_count(pdf_path) -> int:
    """Page count for the fat-MS thresholds. Fail-closed to the smallest
    footprint (a huge number -> stepped-down dpi, and past the refuse line
    the caller routes QP-only review): if the count cannot be read, a
    whole-paper render at full dpi must not be risked."""
    try:
        import fitz
        doc = fitz.open(str(pdf_path))
        try:
            return len(doc)
        finally:
            doc.close()
    except Exception:
        return 10 ** 9


def ms_engine_for(ms_pdf_path=None, target_width=2280, quality=95):
    """Construct the caller's MS engine, stepping dpi down for fat papers.

    Thin papers get the historical dpi=150 engine (byte-identical behavior);
    papers over MS_FAT_DPI_MIN_PAGES get dpi=MS_FAT_DPI so the locked
    whole-paper render fits the box. Papers past MS_FAT_REFUSE_MIN_PAGES
    still get an engine (callers refuse gracefully before using it).
    """
    pages = ms_pdf_page_count(ms_pdf_path) if ms_pdf_path is not None else 0
    if pages > MS_FAT_DPI_MIN_PAGES:
        name = Path(ms_pdf_path).name if ms_pdf_path is not None else "?"
        print(f"[MSCroppingEngine] {name}: {pages} pages > "
              f"{MS_FAT_DPI_MIN_PAGES} -> dpi={MS_FAT_DPI} engine (A20 "
              f"fat-MS step-down; locked splitter unchanged)")
        return MSCroppingEngine(target_width=target_width, quality=quality,
                                dpi=MS_FAT_DPI)
    return MSCroppingEngine(target_width=target_width, quality=quality,
                            dpi=150)

