"""
Legacy portrait-era structured mark-scheme splitter (RS-16 subject coverage).

WHY THIS EXISTS
---------------
The LOCKED gold MS splitter (core/markscheme_split_gold.py, called by the
never-touch core/ms_cropping_engine.py b69285ee…) was built on the structure
of nine official **2025** mark schemes: landscape pages whose
"Question | Answer | Marks" header band is bounded by two long horizontal
rules. Cambridge's **portrait-era** AS/A-Level mark schemes (observed on the
s15 fixtures for 9700 / 9701 / 9702 / 9709) use a different printed grammar:
portrait pages, a "Question | Mark Scheme | Mark | Total" four-column table,
question markers like "1" / "2" in a narrow first column, sub-part rows
"(a)", "(b)(i)" in the SAME column, and no long header-rule pair. The gold
engine correctly finds zero structural boxes there and fails closed.

This module is the additive era-twin: it NEVER replaces the gold path (the
caller tries gold first and only falls here when gold returns nothing), it
never fabricates a boundary it cannot ground in the printed marker column,
and — decisive — it VALIDATES its split against the top-level question
numbers already proven out of the question paper by the locked QP splitter
(expected_top_numbers). If reality disagrees with the paper, it returns
nothing and the run keeps its old fail-closed behaviour.

GEOMETRY CONTRACT (same as gold): returns one header-free upright PIL image
per top-level question, merged across page turns, tight-cropped to the
surrounding table border when one is detectable (gold-crop, same helper,
with the same loud fallback to the unboxed image).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .pdf_io import render_pdf_with_rotation_info, _upright_bbox

# first column of the legacy table holds markers like:
#   1        (top-level start)
#   2 (a)    (top-level + first sub-part, same row)
# sub-part-only rows ((a), (b)(i), (ii)…) carry no bare number and can never
# open a new block. Bare page numbers are excluded by the column-x band and
# the footer band (detect_header_y/detect_footer_y from the locked pdf_io).
_NUM_WORD = re.compile(r"^\(?(\d{1,2})\)?\s*(\(([a-z]|[ivx]+)(\(([ivx]+)\))?)?\)?$")
_HEADER_VOCAB = ("mark scheme",)
_MARKS_COL_HINTS = ("mark", "total", "marks")
_QCOL_HINT = re.compile(r"^question$", re.I)

PAD_TOP_PT = 4.0   # headroom above a marker's own glyph box
# top-level markers sit in the left third of the content area in every
# portrait-era layout observed (9700/9701/9702 tables, 9709 margin numbers)
_QUESTION_HEADING_SPAN = re.compile(r"^Question\s+(\d{1,2})$")
BAND_X_LO = 0.04
BAND_X_HI = 0.32


@dataclass
class LegacySplitDiagnostics:
    markers_found: List[int] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    split_notes: List[str] = field(default_factory=list)
    valid: bool = False


# Old answer-text mark schemes (e.g. 0417/0525 2015) have no outer mark box:
# crop_to_mark_box then locks onto a small table INSIDE the answer and drops
# the question number, the [n] marks column, a table column or the answer
# text above the table. Keep the tight box unless it cuts away real text
# BESIDE it (within its rows) or a text block ABOVE it; ink below the box
# (a stray border / next-row fragment, 0580 portrait tables) stays trimmed.
_BOX_LOST_TEXT_PX = 150         # ~one printed question number / "[1]" at 150 dpi
_TEXT_ROWS_MIN = 8              # a horizontal rule is 1-3 rows, a text line >= 8
_SIDE_REACH_PX = 150            # marks column / question number sit within ~1 inch
                                # of the box; page-edge specks further out are ignored
_BORDER_PX = 4                  # anti-aliased thickness of the box border itself
_PAGE_EDGE_PX = 40              # outer page strip: watermarks / binding marks


def _mark_box_coords(img, dark_threshold, col_threshold, gap_tol, margin):
    from .ms_crop_gold import (
        _find_left_right_borders, _largest_vertical_run, _row_and_col_profiles,
    )
    rgb = img if img.mode == "RGB" else img.convert("RGB")
    dark, col_density = _row_and_col_profiles(rgb, dark_threshold)
    left, right = _find_left_right_borders(col_density, col_threshold)
    if left is None or right is None or right - left < 20:
        return None, dark
    top, bottom = _largest_vertical_run(dark[:, left] | dark[:, right], gap_tol)
    if top is None:
        return None, dark
    w, h = rgb.size
    return (max(0, left - margin), max(0, top - margin),
            min(w - 1, right + margin), min(h - 1, bottom + margin)), dark


def _trim_rows(img, threshold: int = 150, margin: int = 4):
    gray = img.convert("L").point(lambda v: 255 if v < threshold else 0)
    bbox = gray.getbbox()
    if not bbox:
        return img
    top = max(0, bbox[1] - margin)
    bottom = min(img.height, bbox[3] + margin)
    return img.crop((0, top, img.width, bottom))


def _side_ink(band, x0, x1):
    """Dark pixels beside the box (left/right), within _SIDE_REACH_PX of it.
    Ink whose contiguous column run reaches the outer page strip is a
    watermark / ribbon / binding mark, not lost content, and is ignored."""
    w = band.shape[1]
    cols = band.sum(axis=0)
    total = 0
    for lo, hi in ((max(0, x0 - _SIDE_REACH_PX), x0 - _BORDER_PX),
                   (x1 + 1 + _BORDER_PX, min(w, x1 + 1 + _SIDE_REACH_PX))):
        x = lo
        while x < hi:
            if cols[x] == 0:
                x += 1
                continue
            a = x
            while x < w and cols[x] > 0:
                x += 1
            b = x                                   # run [a, b) over the full row
            while a > 0 and cols[a - 1] > 0:
                a -= 1
            if a >= _PAGE_EDGE_PX and b <= w - _PAGE_EDGE_PX:
                total += int(cols[max(a, lo):min(b, hi)].sum())
    return total


def _safe_mark_box(img, box_fn, *, dark_threshold=150, col_threshold=0.45,
                   gap_tol=12, margin=1):
    boxed = box_fn(img, dark_threshold=dark_threshold, col_threshold=col_threshold,
                   gap_tol=gap_tol, margin=margin)
    try:
        coords, dark = _mark_box_coords(img, dark_threshold, col_threshold, gap_tol, margin)
    except Exception:
        return boxed
    if coords is None:
        return boxed
    x0, y0, x1, y1 = coords
    band = dark[y0:y1 + 1]
    side = _side_ink(band, x0, x1)
    above = dark[:y0]
    above_px = int(above.sum())
    above_rows = int((above.sum(axis=1) > 0).sum())
    if side > _BOX_LOST_TEXT_PX or (above_px > _BOX_LOST_TEXT_PX and above_rows >= _TEXT_ROWS_MIN):
        return _trim_rows(img)
    return boxed


def _page_words_upright(page) -> List[Tuple[str, float, float, float, float]]:
    out = []
    for raw in page.get_text("words"):
        x0, y0, x1, y1, text, *_ = raw
        t = (text or "").strip()
        if not t:
            continue
        (ux0, uy0), (ux1, uy1) = _upright_bbox(x0, y0, x1, y1, page)
        out.append((t, ux0, uy0, ux1, uy1))
    return out


def _vocab_ok(doc) -> bool:
    blob = " ".join((pg.get_text("text") or "").lower() for pg in doc)
    return any(v in blob for v in _HEADER_VOCAB)


_STRIP_WORDS = {"mark", "scheme", "syllabus", "paper", "cambridge", "international"}


def _band_top(page) -> float:
    """Content top for a portrait-era MS page.

    pdf_io.detect_header_y keys on footer/turn-over signs and returns 0 for
    these top syllabus strips, so add the era-specific rule: the line(s)
    carrying mark/scheme/syllabus/paper/cambridge tokens in the top 14% of
    the page (plus anything above them, e.g. a watermark slug) are running
    header, never question content.
    """
    from .pdf_io import detect_header_y
    lo = detect_header_y(page)
    H = float(page.rect.height)
    if H <= 0:
        return lo
    strip_bottom = None
    for raw in page.get_text("words"):
        x0, y0, x1, y1, text, *_ = raw
        t = (text or "").strip().lower().strip("|")
        if not t or y0 > 0.14 * H:
            continue
        # NOTE: no bare-digit clause — a continuation page's top content row
        # can begin with a number INSIDE the 14% zone and must survive.
        if t in _STRIP_WORDS or "dynamicpapers" in t:
            strip_bottom = y1 if strip_bottom is None else max(strip_bottom, y1)
    if strip_bottom is not None:
        lo = max(lo, strip_bottom + 2.0)
    return lo


def _digit_span_candidates(doc) -> List[dict]:
    """Every left-band span that could be a marker, with its type signature."""
    from .pdf_io import detect_footer_y, detect_header_y
    out = []
    for pi, page in enumerate(doc):
        if pi == 0 and len(doc) > 2:
            continue  # cover page
        rect = page.rect
        top = detect_header_y(page)
        bottom = detect_footer_y(page)
        for blk in page.get_text("dict")["blocks"]:
            for ln in blk.get("lines", []):
                for sp in ln.get("spans", []):
                    t = (sp.get("text") or "").strip()
                    # Some writers set "Question 1" as ONE span (0544_s15_ms_42);
                    # others split "Question " / "1" (0525_s15_ms_42, which the
                    # bare-number rule already handles). Treat the whole-span
                    # heading as its number, same signature/run rules apply.
                    _heading = _QUESTION_HEADING_SPAN.match(t)
                    if _heading:
                        t = _heading.group(1)
                    if len(t) > 6 or not any(c.isdigit() for c in t):
                        continue
                    if not _NUM_WORD.match(t):
                        continue
                    x0, y0, x1, y1 = sp["bbox"]
                    if not (BAND_X_LO * rect.width <= x0 <= BAND_X_HI * rect.width):
                        continue
                    if y1 < top - 2 or y0 > bottom + 2:
                        continue
                    out.append({"q": int(_NUM_WORD.match(t).group(1)), "pi": pi,
                                "y0": y0, "x0": x0,
                                "size": round(float(sp.get("size", 0)), 1),
                                "font": sp.get("font", ""),
                                "heading": bool(_heading)})
    out.sort(key=lambda c: (c["pi"], c["y0"]))
    return out


def _collect_markers(doc):
    """Pick the ONE (font, size, x0-tight-cluster) signature whose tokens form
    a strict 1..N run. Equation digits share neither the marker font nor its
    x0 in the observed grammars; a signature that fails the run test loses.
    Returns (markers, warnings, signature-note)."""
    cands = _digit_span_candidates(doc)
    if not cands:
        return [], ["no left-band digit candidates at all"], ""
    groups = {}
    for c in cands:
        groups.setdefault((c["font"], c["size"]), []).append(c)
    best = None
    for (font, size), items in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        first1 = next((c for c in items if c["q"] == 1), None)
        if first1 is None:
            continue
        xc = first1["x0"]
        tight = [c for c in items if abs(c["x0"] - xc) <= 6.0]
        ded = []
        for c in tight:
            if not ded or c["q"] != ded[-1]["q"]:
                ded.append(c)
            elif c.get("heading") and not ded[-1].get("heading"):
                # "1 General Marking Principles" precedes "Question 1": the
                # explicit heading is the real start of the question.
                ded[-1] = c
        seq = [c["q"] for c in ded]
        if seq == list(range(1, len(seq) + 1)) and len(seq) >= 1:
            cand = (len(seq), ded, f"font={font} size={size} x0≈{xc:.1f}")
            if best is None or cand[0] > best[0]:
                best = cand
    if best is None:
        seqs = [[c["q"] for c in v] for v in groups.values()]
        longest = max(seqs, key=len)
        return [], [f"no (font,size,x0) signature forms a strict 1..N run "
                    f"(longest group: {longest[:14]}…)"], ""
    markers = [(c["q"], c["pi"], c["y0"]) for c in best[1]]
    return markers, [], f"marker signature: {best[2]}"


_TOTAL_FOR_Q = r"\[?\s*Total\s+(?:marks\s+)?for\s+Question\s+{q}\b"


def _last_question_end(doc, last_q: int, last_pi: int) -> Tuple[int, float]:
    """(page, y_pt) where the final question's block ends.

    The final question may run over several pages (0544_s15_ms_42 Q3: pages
    6-14).  It ends at its own ``[Total for Question N ...]`` line when the
    scheme prints one; otherwise at the footer of the last page that still
    carries text (trailing blank pages excluded)."""
    import re as _re
    from .pdf_io import detect_footer_y
    pat = _re.compile(_TOTAL_FOR_Q.format(q=int(last_q)), _re.I)
    for p in range(last_pi, len(doc)):
        for block in doc[p].get_text("dict").get("blocks", []):
            for line in block.get("lines", []):
                text = "".join(span.get("text", "") for span in line.get("spans", []))
                if pat.search(text):
                    y = float(line["bbox"][3]) + 4.0
                    return p, min(y, detect_footer_y(doc[p]))
    end = last_pi
    for p in range(len(doc) - 1, last_pi, -1):
        if len(doc[p].get_text().strip()) > 80:
            end = p
            break
    return end, detect_footer_y(doc[end])


def split_legacy_portrait_ms(pdf_path, *, dpi: int = 150,
                             expected_top_numbers: Optional[List[int]] = None,
                             ) -> Tuple[Dict[int, "Image.Image"], LegacySplitDiagnostics]:
    """Split a portrait-era structured MS into per-question header-free images.

    Returns ({}, diagnostics) — never guesses — when the document is not the
    legacy layout, when no marker column exists, when the marker sequence is
    not a clean 1..N run, or when the QP-proven expectation disagrees.
    """
    from PIL import Image  # pillow
    diag = LegacySplitDiagnostics()
    images, scale, _rots, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    try:
        images = [im.convert("RGB") for im in images]
        if not _vocab_ok(doc):
            diag.warnings.append("no legacy header vocabulary ('mark scheme') — not a legacy MS")
            return {}, diag
        markers, warns, sig_note = _collect_markers(doc)
        diag.warnings.extend(warns)
        if not markers:
            diag.warnings.append("no strict marker run found (see signature note) — refusing to split")
            return {}, diag
        diag.split_notes.append(sig_note)
        seq = [q for q, _pi, _y in markers]
        if seq != list(range(1, len(seq) + 1)):
            diag.warnings.append(f"marker sequence {seq[:12]} is not a strict 1..{len(seq)} run")
            return {}, diag
        diag.markers_found = seq
        if expected_top_numbers:
            want = sorted(set(int(n) for n in expected_top_numbers))
            if want != seq:
                diag.warnings.append(
                    f"legacy split {seq} != QP-proven top-level questions {want} — refusing")
                return {}, diag

        # block boundaries: marker row top .. next marker row top (y in pt,
        # mapped through render scale), continuing across page turns; the last
        # question runs to its page's content bottom. EVERY page slice is
        # banded by the running-header / footer bands (portrait-era pages put
        # the syllabus strip on top and the ©/turn-over line at the bottom;
        # they are never question content).
        from .pdf_io import detect_footer_y, detect_header_y
        bounds: List[Tuple[int, int, float]] = list(markers)
        last_q, last_pi, _ = markers[-1]
        bounds.append((0,) + _last_question_end(doc, last_q, last_pi))
        diag.valid = True

        pieces: Dict[int, List["Image.Image"]] = {q: [] for q in seq}
        for idx in range(len(bounds) - 1):
            q, pi, y0 = bounds[idx]
            _qn, pj, y1 = bounds[idx + 1]
            for p in range(pi, pj + 1):
                img = images[p]
                pg = doc[p]
                lo_pt = _band_top(pg)               # running-header band bottom
                hi_pt = detect_footer_y(pg)         # footer band top
                if p == pi:
                    lo_pt = max(lo_pt, y0 - PAD_TOP_PT)
                if p == pj:
                    hi_pt = min(hi_pt, y1)
                y_top = int(round(lo_pt * scale))
                y_bot = int(round(min(pg.rect.height, hi_pt) * scale))
                if y_bot - y_top < 8:
                    continue
                pieces[q].append(img.crop((0, y_top, img.width, y_bot)))
                diag.split_notes.append(f"Q{q}: page {p + 1} rows {y_top}:{y_bot}px")
        out: Dict[int, "Image.Image"] = {}
        for q in seq:
            chunks = pieces[q]
            if not chunks:
                diag.warnings.append(f"Q{q}: no pixels assembled")
                return {}, LegacySplitDiagnostics(warnings=diag.warnings)
            if len(chunks) == 1:
                merged = chunks[0]
            else:
                w = max(c.width for c in chunks)
                h = sum(c.height for c in chunks)
                merged = Image.new("RGB", (w, h), "white")
                y = 0
                for c in chunks:
                    merged.paste(c, (0, y))
                    y += c.height
            out[q] = merged
        # same tight-crop as the gold engine (same helper, same loud fallback):
        # trim whitespace/empty bands around the content rectangle.
        try:
            from .ms_crop_gold import crop_to_mark_box as _box
        except Exception:
            try:
                from cambridge_qb.ms_crop import crop_to_mark_box as _box
            except Exception:
                _box = None
        if _box is not None:
            for q in list(out):
                try:
                    out[q] = _safe_mark_box(out[q], _box, dark_threshold=150,
                                            col_threshold=0.45, gap_tol=12, margin=1)
                except Exception as e:
                    diag.warnings.append(f"Q{q}: tight-crop fallback ({e})")
        return out, diag
    finally:
        doc.close()


def split_portrait_column_ms(pdf_path, *, dpi: int = 150,
                             expected_top_numbers: Optional[List[int]] = None,
                             ) -> Tuple[Dict[int, "Image.Image"], LegacySplitDiagnostics]:
    """Split the older portrait IGCSE table grammar by its printed Q column.

    Some IGCSE Mathematics 0580 mark schemes use a simple ``Question | Answer
    | Mark`` table with no long horizontal rules and no repeated table header on
    continuation pages.  The locked landscape splitter correctly returns only
    the structurally proven first page in that case.  This fallback is allowed
    only when every QP-proven top-level number appears exactly once in the
    narrow printed Question column; it never uses arbitrary page fractions or
    answer-option numbers as boundaries.
    """
    from PIL import Image
    from .pdf_io import detect_footer_y

    diag = LegacySplitDiagnostics()
    images, scale, _rots, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    try:
        if not _vocab_ok(doc):
            diag.warnings.append("no mark-scheme header vocabulary")
            return {}, diag
        expected = sorted(set(int(n) for n in (expected_top_numbers or [])))
        if not expected:
            diag.warnings.append("QP-proven expected numbers are required")
            return {}, diag

        # The portrait IGCSE grammar puts top-level labels at about x=56 pt;
        # page numbers and table values are in other columns.  Keep exact
        # integer words only, below the running header.
        labels = []
        for pi, page in enumerate(doc):
            width = float(page.rect.width)
            height = float(page.rect.height)
            # This grammar repeats a compact header at roughly 64–70pt;
            # _band_top can mistake the word "mark" in a content row for a
            # continuation header, so cap the header floor for this strict
            # portrait-column mode.
            top = min(_band_top(page), 70.0)
            for raw in page.get_text("words"): 
                x0, y0, x1, y1, text, *_ = raw
                value = str(text or "").strip()
                if not re.fullmatch(r"\d{1,2}", value):
                    continue
                number = int(value)
                if number not in expected:
                    continue
                if x0 > width * 0.13:
                    continue
                if y0 < max(top + 2.0, height * 0.075):
                    continue
                labels.append((number, pi, float(y0)))

        labels.sort(key=lambda item: (item[1], item[2]))
        # Reject duplicates or missing numbers.  This is the fail-closed proof
        # that distinguishes the Question column from a numeric answer row.
        if [q for q, _p, _y in labels] != expected:
            diag.warnings.append(
                f"portrait Question-column labels {[q for q, _p, _y in labels]} "
                f"do not equal QP-proven {expected} — refusing"
            )
            return {}, diag

        diag.markers_found = expected
        diag.valid = True
        pieces: Dict[int, List[Image.Image]] = {q: [] for q in expected}

        for idx, (question, start_page, start_y) in enumerate(labels):
            if idx + 1 < len(labels):
                _next_q, end_page, end_y = labels[idx + 1]
            else:
                end_page = len(doc) - 1
                end_y = detect_footer_y(doc[end_page])
            for page_index in range(start_page, end_page + 1):
                page = doc[page_index]
                image = images[page_index]
                page_top = min(_band_top(page), 70.0)
                page_bottom = detect_footer_y(page)
                if page_bottom <= page_top or page_bottom > float(page.rect.height):
                    page_bottom = float(page.rect.height) - 12.0
                y0 = page_top if page_index != start_page else max(page_top, start_y - PAD_TOP_PT)
                y1 = page_bottom
                if page_index == end_page:
                    y1 = min(y1, end_y)
                top_px = max(0, int(round(y0 * scale)))
                bottom_px = min(image.height, int(round(y1 * scale)))
                if bottom_px - top_px < 8:
                    continue
                pieces[question].append(image.crop((0, top_px, image.width, bottom_px)))
                diag.split_notes.append(
                    f"Q{question}: page {page_index + 1} rows {top_px}:{bottom_px}px"
                )

        out: Dict[int, Image.Image] = {}
        for question in expected:
            chunks = pieces[question]
            if not chunks:
                diag.valid = False
                diag.warnings.append(f"Q{question}: no pixels assembled")
                return {}, diag
            if len(chunks) == 1:
                merged = chunks[0]
            else:
                width = max(chunk.width for chunk in chunks)
                height = sum(chunk.height for chunk in chunks)
                merged = Image.new("RGB", (width, height), "white")
                cursor = 0
                for chunk in chunks:
                    merged.paste(chunk, (0, cursor))
                    cursor += chunk.height
            out[question] = merged

        try:
            from .ms_crop_gold import crop_to_mark_box as _box
        except Exception:
            _box = None
        if _box is not None:
            for question in list(out):
                try:
                    out[question] = _safe_mark_box(
                        out[question], _box, dark_threshold=150,
                        col_threshold=0.45, gap_tol=12, margin=1,
                    )
                except Exception as exc:
                    diag.warnings.append(f"Q{question}: tight-crop fallback ({exc})")
        return out, diag
    finally:
        doc.close()


# ---------------------------------------------------------------------------
# Page-per-question boxed grammar (older IGCSE theory schemes, e.g.
# 0610_s11_ms_21): no Question/Answer/Marks header at all; every question is
# one bordered box that starts a new page with its number as the first word
# and closes with "[Total: N]".
# ---------------------------------------------------------------------------
_PPQ_LABEL = re.compile(r"^(\d{1,2})(?:\(|$)")
_PPQ_HEADER_WORDS = {"page", "syllabus", "paper", "mark", "scheme", "scheme:"}


def split_page_per_question_ms(pdf_path, *, dpi: int = 150,
                               expected_top_numbers: Optional[List[int]] = None,
                               ) -> Tuple[Dict[int, "Image.Image"], LegacySplitDiagnostics]:
    """Split a scheme whose questions each START a page.  Accepted only when
    the first content word of the question pages is exactly the QP-proven
    sequence 1..N (continuation pages carry no leading number) and every
    question's pages contain a ``[Total`` line; otherwise ({}, diag)."""
    from PIL import Image
    from .markscheme_split_gold import _words_upright, _all_horizontal_rules

    diag = LegacySplitDiagnostics()
    expected = sorted(set(int(n) for n in (expected_top_numbers or [])))
    if len(expected) < 2:
        diag.warnings.append("page-per-question: needs >= 2 QP-proven questions")
        return {}, diag
    images, scale, _rots, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    try:
        pages = []           # (page_index, label or None, top_pt, bottom_pt, has_total)
        for pi, page in enumerate(doc):
            words = _words_upright(page)
            if not words:
                continue
            height = float(page.rect.height)
            head = [w for w in words
                    if w.y0 < height * 0.15 and w.text.strip(":").lower() in _PPQ_HEADER_WORDS]
            if not head:
                continue                       # cover / notes pages have no running strip
            strip_top = min(w.y0 for w in head)
            strip_words = [w for w in words if strip_top - 2 <= w.y0 <= strip_top + 30]
            content_top = max(w.y1 for w in strip_words) + 2.0
            copyright_y = [w.y0 for w in words if w.text.startswith("©")]
            footer = min(copyright_y) - 2.0 if copyright_y else height - 30.0
            body = [w for w in words if content_top < w.y0 < footer]
            if not body:
                continue
            first = min(body, key=lambda w: (round(w.y0), w.x0))
            m = _PPQ_LABEL.match(first.text)
            label = int(m.group(1)) if m else None
            rules = _all_horizontal_rules(page, images[pi])
            above = [r for r in rules if content_top - 4 <= r <= first.y0 - 0.5]
            below = [r for r in rules if r <= footer]
            top = max(above) - 1.0 if above else first.y0 - 6.0
            last_word = max(w.y1 for w in body)
            bottom = max([r for r in below if r >= last_word - 1.0] or [last_word + 6.0]) + 2.0
            has_total = any(w.text.lstrip("[").lower().startswith("total") for w in body)
            pages.append((pi, label, top, min(bottom, footer), has_total))

        labelled = [p for p in pages if p[1] is not None]
        if not labelled or labelled[0][1] != expected[0]:
            diag.warnings.append("page-per-question: first question page not found")
            return {}, diag
        start = pages.index(labelled[0])
        groups: Dict[int, List[tuple]] = {}
        order: List[int] = []
        for entry in pages[start:]:
            if entry[1] is not None:
                if entry[1] in groups:
                    diag.warnings.append(f"page-per-question: label {entry[1]} repeats")
                    return {}, diag
                groups[entry[1]] = [entry]
                order.append(entry[1])
            else:
                groups[order[-1]].append(entry)
        if order != expected:
            diag.warnings.append(
                f"page-per-question: page-leading labels {order} != QP-proven {expected}")
            return {}, diag
        missing_total = [q for q in order if not any(e[4] for e in groups[q])]
        if missing_total:
            diag.warnings.append(f"page-per-question: no [Total] line for {missing_total}")
            return {}, diag

        out: Dict[int, "Image.Image"] = {}
        for q in order:
            parts = []
            for pi, _label, top, bottom, _t in groups[q]:
                img = images[pi]
                y0 = max(0, int(round(top * scale)))
                y1 = min(img.height, int(round(bottom * scale)))
                if y1 - y0 >= 8:
                    parts.append(img.crop((0, y0, img.width, y1)))
            if not parts:
                diag.warnings.append(f"page-per-question: Q{q} has no pixels")
                return {}, diag
            if len(parts) == 1:
                out[q] = parts[0]
            else:
                canvas = Image.new("RGB", (max(p.width for p in parts),
                                           sum(p.height for p in parts)), "white")
                y = 0
                for p in parts:
                    canvas.paste(p, (0, y))
                    y += p.height
                out[q] = canvas
        diag.markers_found = order
        diag.valid = True
        diag.split_notes.append(
            f"page-per-question: Q{order[0]} page {groups[order[0]][0][0] + 1}, "
            f"{len(order)} questions")
        return out, diag
    finally:
        doc.close()


# ---------------------------------------------------------------------------
# Section-heading schemes (0500 P1 style): each question's material starts at
# a standalone bold "Question N" heading and may run over many pages (answer
# tables, notes, full-page marking-criteria grids).  Accepted only when the
# heading sequence is exactly the QP-proven list.
# ---------------------------------------------------------------------------
_QHEAD_RE = re.compile(r"^Question\s+(\d{1,3})$")


def _page_body_bounds(page, words) -> Tuple[float, float]:
    """(content_top, footer_top) in points: below the running header strip,
    above the copyright / page-number footer."""
    height = float(page.rect.height)
    head = [w for w in words if w.y0 < height * 0.10]
    top = (max(w.y1 for w in head) + 3.0) if head else height * 0.06
    foot = [w.y0 for w in words if w.y0 > height * 0.88]
    bottom = (min(foot) - 3.0) if foot else height * 0.94
    return top, bottom


def _trim_bottom(img, pad: int = 12):
    """Drop the empty white space at the bottom of a page piece."""
    import numpy as np
    arr = np.asarray(img.convert("L"))
    ink = np.where((arr < 200).sum(axis=1) > 2)[0]
    if ink.size == 0:
        return img
    return img.crop((0, 0, img.width, min(img.height, int(ink[-1]) + pad)))


def _stack(parts):
    from PIL import Image
    parts = [_trim_bottom(p) for p in parts]
    if len(parts) == 1:
        return parts[0]
    canvas = Image.new("RGB", (max(p.width for p in parts), sum(p.height for p in parts)), "white")
    y = 0
    for p in parts:
        canvas.paste(p, (0, y))
        y += p.height
    return canvas


def _line_items(page):
    """[(x0, y0, y1, text, bold)] per text line."""
    out = []
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            text = "".join(s.get("text", "") for s in spans).strip()
            if not text:
                continue
            bold = any(("bold" in str(s.get("font", "")).lower()) or (int(s.get("flags", 0)) & 16)
                       for s in spans if str(s.get("text", "")).strip())
            out.append((float(line["bbox"][0]), float(line["bbox"][1]),
                        float(line["bbox"][3]), text, bold))
    return out


def split_question_heading_ms(pdf_path, *, dpi: int = 150,
                              expected_top_numbers: Optional[List[int]] = None,
                              ) -> Tuple[Dict[int, "Image.Image"], LegacySplitDiagnostics]:
    """Split on standalone bold "Question N" headings (left margin).  The
    heading sequence must equal the QP-proven list exactly; each question runs
    from its heading to the next heading (or the last content page)."""
    from .markscheme_split_gold import _words_upright

    diag = LegacySplitDiagnostics()
    expected = sorted(set(int(n) for n in (expected_top_numbers or [])))
    if not expected:
        diag.warnings.append("question-heading: no QP-proven questions")
        return {}, diag
    images, scale, _rots, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    try:
        heads = []                                  # (page, y0, number)
        bounds = []
        for pi, page in enumerate(doc):
            words = _words_upright(page)
            bounds.append(_page_body_bounds(page, words) if words else (0.0, float(page.rect.height)))
            width = float(page.rect.width)
            for x0, y0, _y1, text, bold in _line_items(page):
                m = _QHEAD_RE.match(text)
                if m and bold and x0 < width * 0.15:
                    heads.append((pi, y0, int(m.group(1))))
        order = [h[2] for h in heads]
        if order != expected:
            diag.warnings.append(f"question-heading: headings {order} != QP-proven {expected}")
            return {}, diag
        out: Dict[int, "Image.Image"] = {}
        last_page = len(doc) - 1
        for i, (pi, y0, q) in enumerate(heads):
            if i + 1 < len(heads):
                end_pi, end_y = heads[i + 1][0], heads[i + 1][1] - 4.0
            else:
                end_pi, end_y = last_page, bounds[last_page][1]
            parts = []
            for p in range(pi, end_pi + 1):
                top = (y0 - 4.0) if p == pi else bounds[p][0]
                bottom = end_y if p == end_pi else bounds[p][1]
                bottom = min(bottom, bounds[p][1])
                img = images[p]
                a, b = max(0, int(round(top * scale))), min(img.height, int(round(bottom * scale)))
                if b - a >= 8:
                    parts.append(img.crop((0, a, img.width, b)))
            if not parts:
                diag.warnings.append(f"question-heading: Q{q} has no pixels")
                return {}, diag
            out[q] = _stack(parts)
        diag.markers_found = order
        diag.valid = True
        diag.split_notes.append(f"question-heading: {len(order)} 'Question N' sections")
        return out, diag
    finally:
        doc.close()


# ---------------------------------------------------------------------------
# Generic level-descriptor schemes (0475 Literature): no question-specific
# content at all, just "All questions are marked out of 25" and one band /
# level table.  Every question gets that same table as its mark scheme.
# Refused whenever ANY question label is present in the scheme.
# ---------------------------------------------------------------------------
_LEVEL_LINE_RE = re.compile(r"^(?:Level|Band)\s+\d{1,2}\b")
_ANY_QLABEL_RE = re.compile(r"^(?:Question\s+\d{1,3}\b|\d{1,2}\s*\([a-z]{1,3}\)|\d{1,2}\s*$)")
_GENERIC_START_RE = re.compile(
    r"all questions are marked out of|band descriptors|level descriptors table|assessment objectives",
    re.IGNORECASE)


def split_generic_level_ms(pdf_path, *, dpi: int = 150,
                           expected_top_numbers: Optional[List[int]] = None,
                           ) -> Tuple[Dict[int, "Image.Image"], LegacySplitDiagnostics]:
    from .markscheme_split_gold import _words_upright

    diag = LegacySplitDiagnostics()
    expected = sorted(set(int(n) for n in (expected_top_numbers or [])))
    if not expected:
        diag.warnings.append("generic-levels: no QP-proven questions")
        return {}, diag
    images, scale, _rots, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    try:
        level_lines = 0
        start = None
        bounds = []
        for pi, page in enumerate(doc):
            words = _words_upright(page)
            top, bottom = _page_body_bounds(page, words) if words else (0.0, float(page.rect.height))
            bounds.append((top, bottom))
            width = float(page.rect.width)
            text = page.get_text()
            if pi >= 1 and re.search(r"generic marking principles|subject specific general marking",
                                     text, re.IGNORECASE):
                continue                         # boilerplate pages before the grid
            for x0, y0, _y1, t, _bold in _line_items(page):
                if not (top < y0 < bottom):
                    continue
                if _LEVEL_LINE_RE.match(t):
                    level_lines += 1
                    if start is None:
                        start = pi
                elif x0 < width * 0.15 and _ANY_QLABEL_RE.match(t) and pi >= 1:
                    # a bare number in the left column could be a level mark;
                    # a "1(a)" / "Question 1" label means question content exists
                    if not re.fullmatch(r"\d{1,2}", t):
                        diag.warnings.append(f"generic-levels: question label {t!r} on page {pi + 1}")
                        return {}, diag
            if start is None and pi >= 1 and _GENERIC_START_RE.search(text):
                start = pi
        if level_lines < 3 or start is None:
            diag.warnings.append(f"generic-levels: no level/band table ({level_lines} level lines)")
            return {}, diag
        parts = []
        for p in range(start, len(doc)):
            img = images[p]
            a = max(0, int(round(bounds[p][0] * scale)))
            b = min(img.height, int(round(bounds[p][1] * scale)))
            if b - a >= 8:
                parts.append(img.crop((0, a, img.width, b)))
        grid = _stack(parts)
        diag.markers_found = list(expected)
        diag.valid = True
        diag.split_notes.append(
            f"generic-levels: pages {start + 1}-{len(doc)} shared by all {len(expected)} questions")
        return {q: grid for q in expected}, diag
    finally:
        doc.close()
