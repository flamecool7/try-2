"""Opt-in topic suggestions for the Review queue -- the offline classifier's second opinion.

The user's ask (2026-09-29): *"can the classifier use you?"* -- answered as a **button**, not an
automation. The generator's own classifier stays authoritative; this module exists so a reviewer
looking at a row it could not place can ask a language model for a ranked shortlist, and then make
the same decision they would have made by hand.

**What is guaranteed, and why each guarantee is here:**

* **Opt-in, off by default.** With no configuration the provider is ``none``: nothing is called, the
  UI does not render the button, and ``suggest`` raises ``AiUnavailable``. A shipped build never
  reaches the network on its own.
* **Never re-litigates a confident verdict.** ``refusal_for_row`` refuses any row the offline
  classifier already claims (a listable ``HINT`` with a real topic), so the model is asked exactly
  where the offline engine abstained -- REVIEW_REQUIRED, TOPIC_UNKNOWN, or a row held back for a
  missing crop.
* **Never auto-assigns.** This module returns candidates. It does not touch the index, an override
  file, or a pack; assignment remains the reviewer's click in the dialog that already exists.
* **The subject's own topic list, and nothing else.** The prompt carries one question's text plus
  the topic names of that row's subject profile, and any topic the model returns that is not in that
  list is dropped and reported (``dropped``) rather than shown as a plausible-looking invention.
* **Cheap to repeat.** Results are cached by question-text hash (folded together with provider,
  model and the topic list), so revisiting a row does not re-bill a hosted model, and each cached
  entry keeps the model id and timestamp that produced it -- the suggestion is recorded *beside* the
  offline verdict rather than replacing it.
* **Two shapes, one interface.** ``ollama`` (a local server's ``/api/chat``) and ``openai`` (any
  OpenAI-compatible ``/v1/chat/completions``: hosted APIs, vLLM, LM Studio, llama.cpp server). Both
  go through ``urllib`` -- the shipped build gains no dependency.

Configuration is read from the environment first (so a launcher can set it without editing files),
then ``<data_dir>/ai_assist.json``::

    {"provider": "ollama", "model": "qwen2.5:7b", "base_url": "http://127.0.0.1:11434"}

    TOPICAL_AI_PROVIDER=openai TOPICAL_AI_MODEL=gpt-4o-mini \\
    TOPICAL_AI_BASE_URL=https://api.openai.com TOPICAL_AI_API_KEY=sk-... python server.py

The API key is never logged, never written into the cache, and never returned by ``/api/ai/status``
(which reports only whether one is present).
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Sequence

#: Providers this module can talk to. ``none`` is the shipped default: no button, no calls.
PROVIDERS = ("none", "ollama", "openai")
DEFAULT_MODELS = {"ollama": "llama3.1", "openai": "gpt-4o-mini"}
DEFAULT_BASE_URLS = {"ollama": "http://127.0.0.1:11434", "openai": "https://api.openai.com"}

#: One question and one topic list -- small prompts on purpose: a reviewer's row, not a paper.
MAX_SUGGESTIONS = 3
MAX_REASON_CHARS = 160
#: The question text sent for one row is capped; a cropped question is short by construction, and a
#: cap keeps a pathological row (a whole page of text) from turning into a large request.
MAX_QUESTION_CHARS = 4000
#: Cache bound: oldest entries are dropped once this many questions are remembered.
MAX_CACHE_ENTRIES = 500

#: What the UI shows when the feature is switched off, so "no button" is never a mystery.
DISABLED_HINT = (
    "AI assist is off. To enable the Suggest topic button, set a provider in "
    "<data-dir>/ai_assist.json or export TOPICAL_AI_PROVIDER=ollama (local) or "
    "TOPICAL_AI_PROVIDER=openai with TOPICAL_AI_API_KEY (hosted)."
)


class AiUnavailable(RuntimeError):
    """No provider is configured -- the caller should say so, not attempt a call."""


class AiError(RuntimeError):
    """The provider was asked and failed (transport, HTTP status, or unusable output)."""


@dataclass(frozen=True)
class AiConfig:
    provider: str = "none"
    model: str = ""
    base_url: str = ""
    api_key: str = field(default="", repr=False)
    timeout: float = 60.0
    source: str = "default"

    @property
    def enabled(self) -> bool:
        return self.provider in ("ollama", "openai")

    def public(self) -> Dict[str, Any]:
        """The status payload: shape and model, never the key itself."""

        return {
            "enabled": self.enabled,
            "provider": self.provider,
            "model": self.model if self.enabled else "",
            "base_url": self.base_url if self.enabled else "",
            "key_present": bool(self.api_key),
            "timeout": self.timeout,
            "configured_by": self.source,
            "hint": "" if self.enabled else DISABLED_HINT,
        }


def _env(name: str) -> str:
    return (os.environ.get(name) or "").strip()


def load_config(data_dir: str | Path | None = None) -> AiConfig:
    """Environment first, then ``<data_dir>/ai_assist.json``, then the shipped default (off).

    Environment wins because a launcher or a shell can flip the feature for one run without editing
    anything the user owns; the file wins over nothing, and its absence is not an error.
    """

    payload: Dict[str, Any] = {}
    source = "default"
    if data_dir is not None:
        path = Path(data_dir) / "ai_assist.json"
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                source = str(path)
            else:
                payload = {}
        except (OSError, ValueError):
            payload = {}

    provider = _env("TOPICAL_AI_PROVIDER") or str(payload.get("provider") or "none")
    provider = provider.strip().lower()
    if provider not in PROVIDERS:
        provider = "none"
    model = _env("TOPICAL_AI_MODEL") or str(payload.get("model") or "")
    base_url = _env("TOPICAL_AI_BASE_URL") or str(payload.get("base_url") or "")
    api_key = _env("TOPICAL_AI_API_KEY") or str(payload.get("api_key") or "")
    timeout_raw = _env("TOPICAL_AI_TIMEOUT") or payload.get("timeout") or 60
    try:
        timeout = max(5.0, float(timeout_raw))
    except (TypeError, ValueError):
        timeout = 60.0
    if _env("TOPICAL_AI_PROVIDER") or _env("TOPICAL_AI_MODEL") or _env("TOPICAL_AI_BASE_URL"):
        source = "environment"
    if provider != "none":
        model = model or DEFAULT_MODELS.get(provider, "")
        base_url = (base_url or DEFAULT_BASE_URLS.get(provider, "")).rstrip("/")
    return AiConfig(provider=provider, model=model, base_url=base_url, api_key=api_key,
                    timeout=timeout, source=source)


def subject_topics(board: str, code: str) -> List[str]:
    """The topic names of one subject profile -- the only topics a suggestion may use.

    Resolution goes through the same board adapters the batch classifier uses, so the list offered
    to the model is exactly the list the offline engine scored against. An unknown code returns an
    empty list, which the caller reports instead of sending an open-ended prompt.
    """

    board = str(board or "").upper()
    code = str(code or "")
    if not code:
        return []
    try:
        if board == "AQA":
            from adapters.aqa.classification import load_profile
        elif board == "EDEXCEL":
            from adapters.edexcel.classification import load_profile
        elif board == "IB":
            from adapters.ib.classification import load_profile
        else:
            return []
        config, _classifier = load_profile(code)
    except Exception:                                    # noqa: BLE001 - a missing profile is data, not a crash
        return []
    topics = list(getattr(config, "major_topics", None) or [])
    return [str(topic) for topic in topics if topic]


def question_sha(text: str) -> str:
    return sha256((text or "").strip().encode("utf-8")).hexdigest()


def topics_sha(topics: Sequence[str]) -> str:
    return sha256("\n".join(sorted(str(t) for t in topics)).encode("utf-8")).hexdigest()


def refusal_for_row(row: Mapping[str, Any] | None) -> str | None:
    """Why this row must not be sent to a model -- or ``None`` when it may be.

    * A row the offline classifier claims (listable ``HINT`` with a real topic and no review reasons)
      is refused: the design rule is that a confident verdict is never re-litigated.
    * A row with no question text is refused with a different message, because "nothing to send" is
      a different problem from "not allowed to send".
    """

    if not row:
        return "no such row in the index"
    topic = str(row.get("topic") or "").strip()
    status = str(row.get("status") or "").strip()
    reasons = [str(r) for r in (row.get("review_reasons") or []) if r]
    claimed = (bool(row.get("listable")) and status == "HINT"
               and topic and topic != "UNKNOWN" and not reasons)
    if claimed:
        confidence = row.get("confidence")
        shown = f"{topic} at confidence {float(confidence):.2f}" if isinstance(confidence, (int, float)) \
            else topic
        return (f"the offline classifier already claims this question ({shown}); suggestions are "
                f"only offered for rows it would not claim")
    if not str(row.get("text") or "").strip():
        return ("the index holds no question text for this row, so there is nothing to send; rebuild "
                "the index (POST /api/index) and try again")
    return None


def build_prompt(question_text: str, topics: Sequence[str], *, board: str = "", code: str = "",
                 component: str = "", question_number: Any = None) -> List[Dict[str, str]]:
    """The two messages sent for one row: a fixed instruction and the row's own material."""

    topic_lines = "\n".join(f"- {topic}" for topic in topics)
    system = (
        "You place an exam question into exactly one topic from a fixed list.\n"
        "Rules:\n"
        f"1. Answer with JSON only: {{\"suggestions\": [{{\"topic\": \"<name from the list>\", "
        f"\"reason\": \"<one short line>\"}}]}}, at most {MAX_SUGGESTIONS} entries, best first.\n"
        "2. Every \"topic\" value must be copied verbatim from the list. Never invent, translate or "
        "reword a topic.\n"
        "3. If the list genuinely cannot express the question, return fewer entries -- never a "
        "topic outside the list.\n"
        "4. The reason is one line, at most 15 words, about the evidence in the question itself."
    )
    header = f"Subject: {board} {code}".strip()
    if component:
        header += f" | component {component}"
    if question_number:
        header += f" | question {question_number}"
    user = (
        f"{header}\n\nTopic list (choose only from these):\n{topic_lines}\n\n"
        f"Question text:\n{question_text.strip()[:MAX_QUESTION_CHARS]}\n\n"
        "Return the JSON object now."
    )
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


#: A transport takes (url, payload, headers, timeout) and returns the decoded JSON body. Injected in
#: tests; the default uses urllib so the shipped build needs no extra dependency.
Transport = Callable[[str, Dict[str, Any], Dict[str, str], float], Dict[str, Any]]


def _urllib_transport(url: str, payload: Dict[str, Any], headers: Dict[str, str], timeout: float) -> Dict[str, Any]:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=body, method="POST",
                                     headers={"Content-Type": "application/json", **headers})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:   # noqa: S310 - operator-configured URL
            raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:300] if exc.fp else ""
        raise AiError(f"{exc.code} from the model endpoint: {detail or exc.reason}") from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise AiError(f"could not reach the model endpoint ({exc}); if this is a local model, is it "
                      f"running?") from exc
    try:
        return json.loads(raw)
    except ValueError as exc:
        raise AiError(f"the model endpoint returned non-JSON: {raw[:160]!r}") from exc


def _call_provider(config: AiConfig, messages: List[Dict[str, str]], transport: Transport | None = None) -> str:
    """Return the model's raw text content for one prompt."""

    send = transport or _urllib_transport
    if config.provider == "ollama":
        body = send(f"{config.base_url}/api/chat",
                    {"model": config.model, "messages": messages, "stream": False, "format": "json"},
                    {}, config.timeout)
        content = ((body.get("message") or {}).get("content")
                   or body.get("response") or "")
        if not str(content).strip():
            raise AiError("the local model returned no content")
        return str(content)
    if config.provider == "openai":
        headers = {"Authorization": f"Bearer {config.api_key}"} if config.api_key else {}
        body = send(f"{config.base_url}/v1/chat/completions",
                    {"model": config.model, "messages": messages, "temperature": 0,
                     "response_format": {"type": "json_object"}},
                    headers, config.timeout)
        choices = body.get("choices") or []
        content = ((choices[0].get("message") or {}).get("content") if choices else "") or ""
        if not str(content).strip():
            raise AiError("the model endpoint returned no content")
        return str(content)
    raise AiUnavailable(DISABLED_HINT)


def parse_suggestions(content: str, topics: Sequence[str]) -> Dict[str, Any]:
    """Turn the model's text into validated candidates.

    Anything outside the subject's own topic list is dropped and reported. A response that is not
    JSON at all, or that carries no usable candidate, raises ``AiError`` -- the caller surfaces it
    rather than showing an empty list that looks like "the model had no opinion".
    """

    allowed = {str(topic) for topic in topics}
    text = (content or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text.split("\n", 1)[1] if "\n" in text else text
    try:
        payload = json.loads(text)
    except ValueError as exc:
        raise AiError(f"the model did not answer with JSON: {text[:160]!r}") from exc
    if not isinstance(payload, dict):
        raise AiError("the model answered with JSON that is not an object")
    raw = payload.get("suggestions")
    if isinstance(raw, dict):
        raw = [raw]
    if not isinstance(raw, list):
        raise AiError("the model's JSON has no 'suggestions' list")

    suggestions: List[Dict[str, str]] = []
    dropped: List[str] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        topic = str(item.get("topic") or "").strip()
        if not topic:
            continue
        if topic not in allowed:
            # Case/underscore-insensitive match against the real list, then drop it: a suggestion
            # must be one of the subject's own topics, never a plausible-looking invention.
            match = next((t for t in allowed
                          if t.lower() == topic.lower()
                          or t.lower() == topic.lower().replace(" ", "_")), None)
            if match is None:
                dropped.append(topic)
                continue
            topic = match
        if topic in seen:
            continue
        seen.add(topic)
        reason = " ".join(str(item.get("reason") or "").split())[:MAX_REASON_CHARS]
        suggestions.append({"topic": topic, "reason": reason})
        if len(suggestions) >= MAX_SUGGESTIONS:
            break
    if not suggestions:
        detail = f" (the model named topics outside the subject list: {', '.join(dropped[:3])})" if dropped else ""
        raise AiError(f"the model returned no usable topic{detail}")
    return {"suggestions": suggestions, "dropped": dropped}


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def cache_key(config: AiConfig, *, question_text: str, topics: Sequence[str]) -> str:
    return sha256("|".join([config.provider, config.model, topics_sha(topics),
                            question_sha(question_text)]).encode("utf-8")).hexdigest()


def load_cache(path: str | Path) -> Dict[str, Any]:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    entries = payload.get("entries") if isinstance(payload, dict) else None
    return entries if isinstance(entries, dict) else {}


def save_cache(path: str | Path, entries: Dict[str, Any], *, limit: int = MAX_CACHE_ENTRIES) -> None:
    ordered = sorted(entries.items(), key=lambda kv: str((kv[1] or {}).get("created_utc") or ""))
    trimmed = dict(ordered[-limit:])
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps({"schema": "ai_suggestions/1", "entries": trimmed}, indent=2,
                              sort_keys=True), encoding="utf-8")
    os.replace(tmp, target)


def suggest(*, config: AiConfig, question_text: str, topics: Sequence[str], board: str = "", code: str = "",
            component: str = "", question_number: Any = None, row_id: str = "",
            cache_path: str | Path | None = None, transport: Transport | None = None,
            refresh: bool = False) -> Dict[str, Any]:
    """Top-3 candidates for one flagged question, cached by question-text hash.

    Returns ``suggestions`` (validated), ``dropped`` (topics the model invented), and the provenance
    the design requires beside the offline verdict: ``provider``, ``model``, ``created_utc`` and
    ``cached``. Raises ``AiUnavailable`` when no provider is configured and ``AiError`` when the
    provider was asked and failed.
    """

    if not config.enabled:
        raise AiUnavailable(DISABLED_HINT)
    if not str(question_text or "").strip():
        raise ValueError("question_text is empty; refusing to send an empty question")
    if not topics:
        raise ValueError("no topic list for this subject; refusing to send an open-ended prompt")

    entries = load_cache(cache_path) if cache_path else {}
    key = cache_key(config, question_text=question_text, topics=topics)
    if cache_path and not refresh:
        hit = entries.get(key)
        if isinstance(hit, dict) and hit.get("suggestions"):
            return {**{k: hit.get(k) for k in ("suggestions", "dropped", "provider", "model",
                                               "created_utc")},
                    "cached": True, "question_sha": question_sha(question_text),
                    "topics_considered": len(topics)}

    parsed = parse_suggestions(
        _call_provider(config, build_prompt(question_text, topics, board=board, code=code,
                                            component=component, question_number=question_number),
                       transport=transport),
        topics)
    result = {
        "suggestions": parsed["suggestions"],
        "dropped": parsed["dropped"],
        "provider": config.provider,
        "model": config.model,
        "created_utc": _utc_now(),
        "cached": False,
        "question_sha": question_sha(question_text),
        "topics_considered": len(topics),
    }
    if cache_path:
        entries[key] = {k: result[k] for k in ("suggestions", "dropped", "provider", "model",
                                               "created_utc", "question_sha")}
        entries[key]["row_id"] = row_id
        entries[key]["board"] = board
        entries[key]["code"] = code
        entries[key]["question_number"] = question_number
        save_cache(cache_path, entries)
    return result
