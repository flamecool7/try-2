#!/usr/bin/env python3
"""Confidence-gated Cambridge PDF question cropper.

This is a standalone replacement prototype for the crop stage.  It deliberately
fails closed: it never invents questions when detection is uncertain.  It uses
PDF text/vector geometry before rasterisation, renders only the final clip, and
keeps all page segments for multi-page questions.

Supported proof paths:
* QP: top-level question detection for text-backed Cambridge PDFs.
* MS/ER: conservative question-label analysis for pairing/coverage evidence.

This module is not a claim that one heuristic can perfectly crop every future
Cambridge layout.  Unsupported or ambiguous layouts are reported as REVIEW.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Optional

import fitz  # PyMuPDF
import numpy as np
from PIL import Image

TARGET_WIDTH = 2280
WEBP_MAX_DIM = 16383
DEFAULT_TOP_GUARD_PT = 12.0
DEFAULT_BOUNDARY_GAP_PT = 5.0
BODY_TOP_PT = 60.0
BODY_BOTTOM_FRACTION = 0.94
BODY_SIDE_MARGIN_PT = 24.0

PAPER_RE = re.compile(
    r"(?P<code>\d{4})[_-](?P<season>[msw])(?P<yy>\d{2})[_-]"
    r"(?P<kind>qp|ms|er)(?:[_-](?P<variant>\d{1,3}))?",
    re.IGNORECASE,
)
HEADER_CODE_RE = re.compile(r"\b(?P<code>\d{4})\s*/\s*(?P<component>\d{1,3})\b")
QP_MARKER_RE = re.compile(
    # A19 (2026-09-26): a period followed by a digit is a wrapped decimal
    # value (``6.7 x 10^5 ...``), never a Cambridge top-level question label
    # (9702_m26_qp_22: false Q6/Q9/Q1 split Q5 across two crops). Genuine
    # ``6.`` / ``6. (a)`` labels still match via ``\.(?!\d)``.
    r"^\s*(?:(?:question|q)\s*)?(?P<number>\d{1,3})"
    r"(?:\.(?!\d)|(?=\s)|$)(?P<rest>.*)$",
    re.IGNORECASE,
)
# Literature papers label the top-level question as "Either 1(a)" / "Or 2(b)".
# The number is the question; the (a)/(b) alternative stays inside that crop.
LITERATURE_ALT_RE = re.compile(
    r"^\s*(?:either|or)\s+(?P<number>\d{1,3})\s*\([a-z]\)",
    re.IGNORECASE,
)
MS_LABEL_RE = re.compile(
    # A19 (2026-09-26): same decimal guard as QP_MARKER_RE — ``6.7 x 10^5``
    # value rows in a mark scheme are not question labels.
    r"^\s*(?P<number>\d{1,3})(?!\.\d)(?:\s*\([a-zivx]{1,4}\))?"
    r"(?:\s*\([a-zivx]{1,4}\))?\s*(?P<rest>.*)$",
    re.IGNORECASE,
)
ER_QUESTION_RE = re.compile(r"^\s*question\s+(?P<number>\d{1,3})\b", re.IGNORECASE)
# A new section instruction ends the previous question. It must not be cropped
# into that question, and it must not swallow the numbered question that follows.
SECTION_HEADING_RE = re.compile(
    r"^(?:section\s+[a-z0-9]{1,4}\b"
    r"|answer\s+(?:any|one|two|three|four|all|the following)\b.*\b(?:section|questions?)\b)",
    re.IGNORECASE,
)
BLANK_PAGE_RE = re.compile(r"^blank\s+page$", re.IGNORECASE)
COPYRIGHT_RE = re.compile(
    r"permission to reproduce|copyright acknowledgement|to avoid the issue of disclosure",
    re.IGNORECASE,
)
# A19 (2026-09-26): standalone continuation-desk furniture printed below the
# last question's answer space (9709_m26_qp_12 p15) — never question content.
ADDITIONAL_PAGE_RE = re.compile(r"^additional\s+(lined\s+)?pages?$", re.IGNORECASE)
ADDITIONAL_PAGE_INFO_RE = re.compile(r"if you use the following.{0,60}?pages?\b", re.IGNORECASE)


@dataclass(frozen=True)
class PaperIdentity:
    path: str
    code: str
    season: str
    year: str
    kind: str
    variant: str = ""

    @property
    def paper_key(self) -> str:
        return f"{self.code}_{self.season}{self.year[-2:]}_{self.variant}"


@dataclass(frozen=True)
class TextLine:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def width(self) -> float:
        return self.x1 - self.x0


@dataclass(frozen=True)
class Marker:
    number: int
    page: int
    y0: float
    y1: float
    x0: float
    text: str
    score: float
    reason: str


@dataclass
class Segment:
    page: int
    y0: float
    y1: float


@dataclass
class CropResult:
    number: int
    image_paths: list[str]
    pages: list[int]
    marker_text: str
    confidence: float
    status: str
    text_chars: int
    text: str = ""
    ink_fraction: float = 0.0
    width: int = 0
    height: int = 0
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DocumentAnalysis:
    identity: PaperIdentity
    page_count: int
    page_text_chars: list[int]
    markers: list[Marker]
    selected_numbers: list[int]
    warnings: list[str]
    elapsed_ms: float

    def to_dict(self) -> dict:
        data = asdict(self)
        data["identity"] = asdict(self.identity)
        data["markers"] = [asdict(marker) for marker in self.markers]
        return data


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_identity(path: Path) -> PaperIdentity:
    match = PAPER_RE.search(path.stem)
    if not match:
        raise ValueError(f"Cannot parse Cambridge paper identity from {path.name}")
    yy = int(match.group("yy"))
    year = str(2000 + yy if yy < 50 else 1900 + yy)
    return PaperIdentity(
        path=str(path),
        code=match.group("code"),
        season=match.group("season").lower(),
        year=year,
        kind=match.group("kind").lower(),
        variant=match.group("variant") or "",
    )


def lines_from_page(page: fitz.Page) -> list[TextLine]:
    lines: list[TextLine] = []
    data = page.get_text("dict")
    for block in data.get("blocks", []):
        if block.get("type") != 0:
            continue
        for raw_line in block.get("lines", []):
            spans = raw_line.get("spans", [])
            if not spans:
                continue
            text = "".join(str(span.get("text", "")) for span in spans).strip()
            if not text:
                continue
            x0 = min(float(span["bbox"][0]) for span in spans)
            y0 = min(float(span["bbox"][1]) for span in spans)
            x1 = max(float(span["bbox"][2]) for span in spans)
            y1 = max(float(span["bbox"][3]) for span in spans)
            lines.append(TextLine(text=text, x0=x0, y0=y0, x1=x1, y1=y1))
    return sorted(lines, key=lambda line: (line.y0, line.x0))


def _looks_like_header_or_footer(line: TextLine, page: fitz.Page) -> bool:
    text = line.text.lower()
    h = float(page.rect.height)
    if line.y1 < h * 0.055:
        return True
    if line.y0 > h * 0.955:
        return True
    if "turn over" in text or "do not write" in text:
        return True
    if "©" in line.text or "uc les" in text or "ucles" in text:
        return True
    if re.search(r"\b\d{4}/\d{1,3}/[a-z]/[a-z]/\d{2}\b", text):
        return True
    if re.search(r"\bpage\s+\d+\s+of\s+\d+\b", text):
        return True
    return False


def _next_line(lines: list[TextLine], index: int) -> Optional[TextLine]:
    return lines[index + 1] if index + 1 < len(lines) else None


def _has_prose_letters(text: str) -> bool:
    """True for Latin or non-Latin letters. A-Za-z alone drops Hindi, Urdu and Arabic stems."""
    return any(ch.isalpha() for ch in text)


def _qp_candidate(line: TextLine, page: fitz.Page, lines: list[TextLine], index: int) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    literature = LITERATURE_ALT_RE.match(line.text)
    if literature:
        number = int(literature.group("number"))
        if 1 <= number <= 150:
            return Marker(
                number, -1, line.y0, line.y1, line.x0, line.text, 1.35,
                "either/or question label",
            )
    match = QP_MARKER_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None

    # Cambridge QP top-level labels are normally in the left body margin.
    # This excludes page headers, tables and answer options in the right body.
    relative_x = line.x0 / max(1.0, float(page.rect.width))
    if relative_x > 0.20:
        return None
    rest = match.group("rest").strip()
    # A19 (2026-09-26): figure/dimension labels (``9 cm``) are not question
    # labels (9709_m26_qp_12 p4). True same-line stems start with a capital
    # word or a subpart — never a lowercase word, a multi-char unit, or a
    # bare symbol — and no stem is a bare unit token, so neither guard can
    # reject a genuine marker. Single-capital units stay unguarded at line
    # start (``A`` is also the article) and are only rejected when bare.
    if re.match(
        r"^(?:cm|mm|km|kg|mg|ms|mol|ev|pa|kpa|hz|khz|mhz|ghz|[msg]|[°%Ω])\b",
        rest,
        re.IGNORECASE,
    ):
        return None
    if re.fullmatch(
        r"(?:[A-ZΩ]|cm|mm|km|kg|mg|g|ms|s|mol|ev|pa|kpa|hz|khz|mhz|ghz|°C?|%)\.?",
        rest,
        re.IGNORECASE,
    ):
        return None
    # A19: displayed-equation fragments (``2 = βCV 2``) are not question
    # labels (9702_m26_qp_52 p2: a false Q2 truncated Q1 and polluted Q2).
    # True same-line stems start with a word or a subpart, never an
    # operator or relation symbol.
    if re.match(r"^[=+\-±×÷*/<>&|≈∝√∫∑∂∞∅∈∏¬∧∨∩∪≤≥≠≡\u2212]", rest):
        return None
    # A20 (2026-09-26): wrapped instruction/value fragments start lowercase
    # (``3 significant figures.`` — 9709_s26_qp_33 p3 stole Q3 and slivered
    # Q2 to 22px). BUT French listening answers are lowercase phrases at
    # the margin (``15 voyage en ballon`` — 0520_s26_qp_12), so the guard
    # only fires past the margin: true labels measure rel_x 0.083 on every
    # sampled paper, body-indent wraps at 0.12+.
    if rest and rest[0].isalpha() and rest[0].islower() and relative_x > 0.10:
        return None
    # A20: diagram/stem-and-leaf keys (``3 represents 23 items`` —
    # 9231_s26_qp_41 p2) are not question labels. A stem never starts with
    # the bare third-person verb (imperative stems read ``Represent ...``).
    if re.match(r"represents\b", rest, re.IGNORECASE):
        return None
    next_line = _next_line(lines, index)
    next_text = next_line.text if next_line else ""

    # A line containing only a number is often followed by a formula/diagram
    # block before the prose question stem.  Look ahead a few lines, but only
    # accept a number-only marker when it is genuinely in the far-left margin.
    lookahead = " ".join(line.text for line in lines[index + 1:index + 10])
    # A margin number often sits a point or two below the stem on the same row,
    # so the stem sorts before the number and a forward-only look misses it.
    same_row = " ".join(
        other.text for other in lines
        if other is not line and other.x0 > line.x0 and abs(other.y0 - line.y0) <= 12
    )
    # A20 (2026-09-26): a bare digit beside digit/table cells is a
    # stem-leaf/table row, not a label (9231_s26_qp_41 p2 stem column
    # ``2``..``7`` at rel_x 0.14 faked Q2-Q7 and swallowed the paper into
    # Q7). Margin-qualified like the lowercase guard: true bare markers
    # (rel_x 0.083, e.g. beside diagram debris) are kept.
    if (not rest and same_row.strip() and relative_x > 0.10
            and re.match(r"[\d|]", same_row.strip())):
        return None
    nearby_text = f"{next_text} {lookahead} {same_row}"
    has_prose = _has_prose_letters(rest) or _has_prose_letters(nearby_text)
    if not has_prose:
        return None
    if not rest and relative_x > 0.15:
        return None
    if rest and re.fullmatch(r"[\d\s.,:+\-/%]+", rest):
        return None

    score = 1.0
    reason = "left-margin marker with nearby prose"
    if relative_x <= 0.12:
        score += 0.15
    if re.match(r"^(?:question|q)", line.text, re.IGNORECASE):
        score += 0.20
        reason = "explicit question marker"
    if not rest:
        score -= 0.05
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, score, reason)


def _ms_candidate(line: TextLine, page: fitz.Page, lines: list[TextLine], index: int) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    match = MS_LABEL_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None
    relative_x = line.x0 / max(1.0, float(page.rect.width))
    if relative_x > 0.24:
        return None
    # Mark-scheme labels are often at the left of the answer table.  Avoid
    # generic principles and arithmetic rows by requiring either a subpart,
    # explicit question wording, or a line at a table/question-column position.
    rest = match.group("rest").strip()
    has_subpart = bool(re.match(r"^\s*\d+\s*\(", line.text))
    next_line = _next_line(lines, index)
    nearby = (rest + " " + (next_line.text if next_line else "")).lower()
    if not has_subpart and not re.search(r"[A-Za-z]", nearby) and not re.search(r"\b[abcd]\b", nearby):
        return None
    score = 0.65 + (0.15 if has_subpart else 0.0)
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, score, "mark-scheme label")


def _er_candidate(line: TextLine, page: fitz.Page) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    match = ER_QUESTION_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, 0.85, "explicit examiner-report heading")


def raw_markers(doc: fitz.Document, kind: str) -> tuple[list[Marker], list[int]]:
    markers: list[Marker] = []
    page_text_chars: list[int] = []
    for page_index, page in enumerate(doc):
        lines = lines_from_page(page)
        page_text_chars.append(sum(len(line.text) for line in lines))
        for index, line in enumerate(lines):
            if kind == "qp":
                candidate = _qp_candidate(line, page, lines, index)
            elif kind == "ms":
                candidate = _ms_candidate(line, page, lines, index)
            else:
                candidate = _er_candidate(line, page)
            if candidate is not None:
                markers.append(
                    Marker(
                        number=candidate.number,
                        page=page_index,
                        y0=candidate.y0,
                        y1=candidate.y1,
                        x0=candidate.x0,
                        text=candidate.text,
                        score=candidate.score,
                        reason=candidate.reason,
                    )
                )
    return markers, page_text_chars


def select_qp_sequence(markers: list[Marker]) -> list[Marker]:
    """Select the strongest contiguous 1..N QP sequence.

    Cambridge QPs are sequential at top level.  This rejects page numbers,
    table values and repeated decorative labels without guessing across gaps.
    """
    if not markers:
        return []
    by_number: dict[int, list[Marker]] = {}
    for marker in markers:
        by_number.setdefault(marker.number, []).append(marker)
    for values in by_number.values():
        values.sort(key=lambda marker: (marker.page, marker.y0, -marker.score))

    firsts = by_number.get(1, [])
    if not firsts:
        return []
    best: list[Marker] = []
    for first in firsts:
        sequence = [first]
        cursor = (first.page, first.y0)
        expected = 2
        while expected in by_number:
            candidates = [
                marker for marker in by_number[expected]
                if (marker.page, marker.y0) > cursor
            ]
            if not candidates:
                break
            # Document order is the primary signal.  Answer-option numbers
            # later in the paper can have a slightly higher local score than
            # the true top-level label (e.g. an option row ``4 N`` after Q4),
            # and choosing by score can jump past Q5 and create one enormous
            # final crop.  Pick the earliest valid marker; score only breaks
            # an exact-coordinate tie.
            chosen = min(candidates, key=lambda marker: (marker.page, marker.y0, -marker.score))
            sequence.append(chosen)
            cursor = (chosen.page, chosen.y0)
            expected += 1
        if len(sequence) > len(best):
            best = sequence
        elif len(sequence) == len(best) and sequence and sum(x.score for x in sequence) > sum(x.score for x in best):
            best = sequence
    return best


def select_label_sequence(markers: list[Marker]) -> list[Marker]:
    """Conservative MS/ER sequence selection; deduplicate repeated labels."""
    if not markers:
        return []
    # Keep the first occurrence of each question number in document order.
    selected: list[Marker] = []
    seen: set[int] = set()
    for marker in sorted(markers, key=lambda value: (value.page, value.y0)):
        if marker.number in seen:
            continue
        seen.add(marker.number)
        selected.append(marker)
    return selected


def detect_markers(doc: fitz.Document, kind: str) -> tuple[list[Marker], list[int], list[str]]:
    markers, page_text_chars = raw_markers(doc, kind)
    warnings: list[str] = []
    if kind == "qp":
        selected = select_qp_sequence(markers)
        if not selected:
            warnings.append("No contiguous top-level QP sequence beginning at Q1 was found")
        elif len(selected) < 2:
            warnings.append("Only one QP marker found; review required")
        all_numbers = [marker.number for marker in selected]
    else:
        selected_markers = select_label_sequence(markers)
        all_numbers = [marker.number for marker in selected_markers]
        if not selected_markers:
            warnings.append(f"No conservative {kind.upper()} question labels found")
        selected = selected_markers
    return selected, page_text_chars, warnings


def _is_section_heading(line: TextLine) -> bool:
    text = re.sub(r"\s+", " ", line.text).strip()
    if not text or len(text) > 90:
        return False
    return bool(SECTION_HEADING_RE.match(text))


def _is_admin_line(line: TextLine) -> bool:
    text = line.text.strip()
    # A19: Additional-page desk furniture is admin, not question content
    # (lets trailing lined Additional-page sheets trim like blank pages).
    norm = re.sub(r"\s+", " ", text)
    return bool(
        BLANK_PAGE_RE.match(text)
        or COPYRIGHT_RE.search(text)
        or ADDITIONAL_PAGE_RE.match(norm)
        or ADDITIONAL_PAGE_INFO_RE.search(norm)
    )


def _is_page_furniture(line: TextLine) -> bool:
    """Page number, barcode, copyright line, or the BLANK PAGE label."""
    text = line.text.strip()
    if not text or _is_admin_line(line):
        return True
    if re.fullmatch(r"\d{1,3}", text):
        return True
    alnum = sum(ch.isalnum() for ch in text)
    if len(text) >= 6 and alnum / len(text) < 0.55:
        return True
    lowered = text.lower()
    if "ucles" in lowered or text.startswith("©") or "cambridge assessment" in lowered:
        return True
    if re.search(r"\b\d{4}/\d{1,3}/", lowered):
        return True
    return False


def _page_is_trailing_admin(page: fitz.Page) -> bool:
    """True for a blank page, a copyright-only back page, or an empty page.

    Cambridge prints the copyright block on the blank page. That block is not
    question content. A question page that only mentions blank pages in its
    instructions does not have a standalone ``BLANK PAGE`` line.
    """
    lines = lines_from_page(page)
    if any(BLANK_PAGE_RE.match(line.text.strip()) for line in lines):
        return True
    body = [
        line for line in lines
        if not _looks_like_header_or_footer(line, page) and not _is_page_furniture(line)
    ]
    return not body


def _page_has_blank_label(page: fitz.Page) -> bool:
    """True when the page carries a standalone publisher BLANK PAGE label.

    A19 (2026-09-26): such a page holds no question content by publisher
    assertion, so it can be skipped even mid-span (unlike the broader
    trailing-admin test, this can never match a figure-only content page).
    """
    return any(BLANK_PAGE_RE.match(line.text.strip()) for line in lines_from_page(page))


def _first_section_heading(doc: fitz.Document, marker: Marker, next_marker: Optional[Marker]) -> Optional[tuple[int, float]]:
    end_page = next_marker.page if next_marker is not None else len(doc) - 1
    end_y = next_marker.y0 if next_marker is not None else float("inf")
    for page_index in range(marker.page, end_page + 1):
        page = doc[page_index]
        for line in lines_from_page(page):
            if page_index == marker.page and line.y0 <= marker.y0 + 1.0:
                continue
            if page_index == end_page and line.y0 >= end_y - 1.0:
                continue
            if _looks_like_header_or_footer(line, page):
                continue
            if _is_section_heading(line):
                return page_index, line.y0
    return None


def _has_question_content_above(page: fitz.Page, y: float) -> bool:
    for line in lines_from_page(page):
        if line.y1 >= y - 2.0:
            continue
        if _looks_like_header_or_footer(line, page) or _is_section_heading(line) or _is_admin_line(line):
            continue
        if re.fullmatch(r"\d{1,3}", line.text.strip()):
            continue
        return True
    return False


def _is_unusual_imposition(text: str) -> bool:
    value = text.strip()
    if len(value) < 8:
        return False
    alnum = sum(ch.isalnum() for ch in value)
    ascii_count = sum(ord(ch) < 128 for ch in value)
    return alnum / len(value) < 0.55 or ascii_count / len(value) < 0.70


def _last_content_y(page: fitz.Page) -> float:
    """Bottom of the last real question ink, not the footer barcode or blank tail.

    A19 (2026-09-26): back-matter runs to the bottom of the page, so the cut
    is the FIRST back-matter line (permission/copyright paragraph, BLANK PAGE
    label, Additional-page notice) — matching only paragraph openers left the
    wrapped continuation lines inside the crop (9702_m26_qp_22 Q7).
    """
    height = float(page.rect.height)
    # Footer rules, barcodes and corner crop-marks sit in the bottom band.
    # A diagram that is actually part of the question is above that band.
    footer_band = height * 0.90
    last = BODY_TOP_PT
    ceiling = height
    for line in lines_from_page(page):
        text = re.sub(r"\s+", " ", line.text).strip()
        if (COPYRIGHT_RE.search(text) or BLANK_PAGE_RE.match(text)
                or ADDITIONAL_PAGE_RE.match(text)
                or ADDITIONAL_PAGE_INFO_RE.search(text)):
            ceiling = min(ceiling, line.y0)
    for line in lines_from_page(page):
        if _looks_like_header_or_footer(line, page) or _is_page_furniture(line):
            continue
        if _is_unusual_imposition(line.text):
            continue
        if line.y0 >= footer_band:
            continue
        last = max(last, line.y1)
    try:
        for item in page.get_drawings():
            rect = item.get("rect")
            if rect is None:
                continue
            y0 = float(rect.y0)
            y1 = float(rect.y1)
            if y0 >= footer_band or y1 >= height * 0.96:
                continue
            if y1 >= BODY_TOP_PT:
                last = max(last, y1)
        for info in page.get_image_info():
            bbox = info.get("bbox")
            if not bbox:
                continue
            y0, y1 = float(bbox[1]), float(bbox[3])
            if y0 >= footer_band:
                continue
            if y1 >= BODY_TOP_PT:
                last = max(last, y1)
    except Exception:
        pass
    cap = min(height - 2.0, last + 12.0)
    if ceiling < height:
        # Never cross into back-matter, even via the descender pad.
        cap = min(cap, ceiling - 2.0)
    return cap


def page_body_bottom(page: fitz.Page) -> float:
    h = float(page.rect.height)
    bottom = h * BODY_BOTTOM_FRACTION
    # Cambridge PDFs often contain imposition barcodes/gibberish text just
    # above the printed footer.  Detect that vector text and end before it;
    # this is safer than painting pixels after the crop has been made.
    try:
        for word in page.get_text("words"):
            x0, y0, x1, y1, text, *_ = word
            if y0 < h * 0.82:
                continue
            value = str(text or "")
            alnum = sum(char.isalnum() for char in value)
            ascii_count = sum(ord(char) < 128 for char in value)
            unusual = len(value) >= 8 and (
                alnum / max(1, len(value)) < 0.55
                or ascii_count / max(1, len(value)) < 0.70
            )
            footerish = "turn over" in value.lower() or value in {"©", "UCLES"}
            if unusual:
                bottom = min(bottom, float(y0) - 4.0)
            elif footerish:
                bottom = min(bottom, float(y0) - 2.0)
    except Exception:
        pass
    return max(h * 0.78, bottom)


def page_clip_bounds(page: fitz.Page) -> tuple[float, float]:
    """Remove the printed do-not-write margin strips before rasterisation."""
    width = float(page.rect.width)
    left = BODY_SIDE_MARGIN_PT
    right = max(left + 10.0, width - BODY_SIDE_MARGIN_PT)
    try:
        words = page.get_text("words")
        left_margin = any(float(word[0]) < width * 0.08 and "margin" in str(word[4]).lower() for word in words)
        right_margin = any(float(word[0]) > width * 0.92 and "margin" in str(word[4]).lower() for word in words)
        if left_margin:
            left = max(left, width * 0.04)
        if right_margin:
            right = min(right, width - width * 0.04)
    except Exception:
        pass
    return left, right


def _question_end(doc: fitz.Document, marker: Marker, next_marker: Optional[Marker], start_y: float) -> tuple[int, float]:
    """End this question before a section heading, the next question, or a blank tail.

    ``start_y`` is on the marker's own page. It must not be used as a floor on
    a later page: that was pulling Section B and the next question into Q1.
    """
    heading = _first_section_heading(doc, marker, next_marker)
    if heading is not None:
        heading_page, heading_y = heading
        if heading_page > marker.page and not _has_question_content_above(doc[heading_page], heading_y):
            end_page = heading_page - 1
            return end_page, page_body_bottom(doc[end_page])
        end_y = max(2.0, heading_y - DEFAULT_BOUNDARY_GAP_PT)
        if heading_page == marker.page:
            end_y = max(start_y + 2.0, end_y)
        return heading_page, end_y
    if next_marker is not None:
        starts_new_page = (
            next_marker.page > marker.page
            and next_marker.y0 <= BODY_TOP_PT + 25.0
        )
        if starts_new_page:
            end_page = next_marker.page - 1
            # A19 (2026-09-26): trailing blank/admin pages between two
            # questions belong to neither (9702_m26_qp_22 p12 rode into
            # Q5/Q6). Mirrors the last-question trailing-admin loop below.
            while end_page > marker.page and _page_is_trailing_admin(doc[end_page]):
                end_page -= 1
            return end_page, page_body_bottom(doc[end_page])
        end_y = next_marker.y0 - DEFAULT_BOUNDARY_GAP_PT
        if next_marker.page == marker.page:
            end_y = max(start_y + 2.0, end_y)
        return next_marker.page, end_y
    end_page = len(doc) - 1
    while end_page > marker.page and _page_is_trailing_admin(doc[end_page]):
        end_page -= 1
    return end_page, _last_content_y(doc[end_page])


def segment_for_marker(doc: fitz.Document, marker: Marker, next_marker: Optional[Marker]) -> list[Segment]:
    segments: list[Segment] = []
    start_page = marker.page
    start_y = max(0.0, marker.y0 - DEFAULT_TOP_GUARD_PT)
    end_page, end_y = _question_end(doc, marker, next_marker, start_y)
    if end_page < start_page:
        end_page = start_page
        end_y = page_body_bottom(doc[start_page])

    for page_index in range(start_page, end_page + 1):
        if (page_index != start_page and page_index != end_page
                and _page_has_blank_label(doc[page_index])):
            continue
        page = doc[page_index]
        y0 = start_y if page_index == start_page else BODY_TOP_PT
        y1 = end_y if page_index == end_page else page_body_bottom(page)
        y0 = max(0.0, min(y0, float(page.rect.height)))
        y1 = max(y0 + 2.0, min(y1, float(page.rect.height)))
        segments.append(Segment(page=page_index, y0=y0, y1=y1))
    # A19: drop near-empty non-start bands (narrower than one text line) — a
    # trailing sheet gelded by _last_content_y (9709_m26_qp_12 p16) must not
    # ride along as a sliver. The start band and any sole band are never
    # dropped, so no question content can be lost here.
    if len(segments) > 1:
        segments = [
            seg for i, seg in enumerate(segments)
            if i == 0 or (seg.y1 - seg.y0) >= 8.0
        ]
    return segments


def render_clip(page: fitz.Page, y0: float, y1: float) -> Image.Image:
    x0, x1 = page_clip_bounds(page)
    rect = fitz.Rect(x0, y0, x1, y1)
    scale = TARGET_WIDTH / max(1.0, x1 - x0)
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=rect, alpha=False)
    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    if image.width != TARGET_WIDTH:
        image = image.resize(
            (TARGET_WIDTH, max(1, round(image.height * TARGET_WIDTH / image.width))),
            Image.Resampling.LANCZOS,
        )
    return image


def trim_vertical_white(image: Image.Image, pad: int = 16) -> Image.Image:
    gray = np.asarray(image.convert("L"))
    ink = gray < 248
    rows = np.flatnonzero(ink.any(axis=1))
    if rows.size == 0:
        return image

    # Registration bars and rotated margin warnings can form a short, dense
    # ink run right at a page clip's top edge.  A real text line at this scale
    # is taller and is followed by content without a large blank gap.  Remove
    # only the very specific short-run pattern; otherwise keep all ink.
    dark = gray < 200
    row_counts = dark.sum(axis=1)
    active = row_counts > max(3, int(image.width * 0.0008))
    runs: list[tuple[int, int]] = []
    index = 0
    while index < len(active):
        if not active[index]:
            index += 1
            continue
        end = index
        while end < len(active) and active[end]:
            end += 1
        runs.append((index, end - 1))
        index = end
    trim_top = int(rows[0])
    if len(runs) >= 2:
        first_start, first_end = runs[0]
        second_start, _second_end = runs[1]
        first_height = first_end - first_start + 1
        gap = second_start - first_end - 1
        first_density = float(row_counts[first_start:first_end + 1].mean()) / max(1, image.width)
        if first_start <= 1 and first_height <= 40 and gap >= 8 and first_density >= 0.08:
            trim_top = second_start
    top = max(0, trim_top - pad)
    bottom = min(image.height, int(rows[-1]) + pad + 1)
    if bottom <= top:
        return image
    return image.crop((0, top, image.width, bottom))


def stitch(parts: list[Image.Image], gap: int = 18) -> Image.Image:
    if not parts:
        raise ValueError("Cannot stitch zero image segments")
    width = max(image.width for image in parts)
    normalised: list[Image.Image] = []
    for image in parts:
        if image.width != width:
            image = image.resize((width, max(1, round(image.height * width / image.width))), Image.Resampling.LANCZOS)
        normalised.append(image)
    height = sum(image.height for image in normalised) + gap * (len(normalised) - 1)
    canvas = Image.new("RGB", (width, height), "white")
    y = 0
    for index, image in enumerate(normalised):
        canvas.paste(image, (0, y))
        y += image.height
        if index + 1 < len(normalised):
            y += gap
    return canvas


def save_webp_tiled(image: Image.Image, destination: Path, quality: int = 92) -> list[Path]:
    """Save the crop the loader will reopen.

    A WebP cannot store a question taller than 16383px without scaling, and
    scaling here would later be stretched back to 2280px and fail the width
    check. Those crops are spooled as one PNG. Mark-scheme files are scaled
    into one WebP by the final saver, not split into ``_partN``.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    if image.width <= WEBP_MAX_DIM and image.height <= WEBP_MAX_DIM:
        image.save(destination, format="WEBP", quality=quality, method=4)
        return [destination]
    if "_MS" in destination.stem:
        scale = min(WEBP_MAX_DIM / max(1, image.width), WEBP_MAX_DIM / max(1, image.height))
        fitted = image.resize(
            (max(1, int(image.width * scale)), max(1, int(image.height * scale))),
            Image.Resampling.LANCZOS,
        )
        fitted.save(destination, format="WEBP", quality=quality, method=4)
        return [destination]
    png = destination.with_suffix(".png")
    image.save(png, format="PNG")
    return [png]


def image_ink_fraction(image: Image.Image) -> float:
    gray = np.asarray(image.convert("L"))
    return float((gray < 245).mean())


def extract_text_for_segment(page: fitz.Page, y0: float, y1: float) -> str:
    return (page.get_text("text", clip=fitz.Rect(0, y0, page.rect.width, y1)) or "").strip()


class CambridgeCropper:
    def __init__(self, output_root: Path, quality: int = 92):
        self.output_root = Path(output_root)
        self.quality = quality

    def analyze(self, pdf_path: Path, kind: Optional[str] = None) -> DocumentAnalysis:
        started = time.perf_counter()
        identity = parse_identity(pdf_path)
        if kind:
            identity = PaperIdentity(identity.path, identity.code, identity.season, identity.year, kind, identity.variant)
        with fitz.open(pdf_path) as doc:
            markers, page_text_chars, warnings = detect_markers(doc, identity.kind)
            selected_numbers = [marker.number for marker in markers]
            page_count = len(doc)
        return DocumentAnalysis(
            identity=identity,
            page_count=page_count,
            page_text_chars=page_text_chars,
            markers=markers,
            selected_numbers=selected_numbers,
            warnings=warnings,
            elapsed_ms=round((time.perf_counter() - started) * 1000, 2),
        )

    def crop_qp(self, pdf_path: Path) -> tuple[DocumentAnalysis, list[CropResult]]:
        analysis = self.analyze(pdf_path, kind="qp")
        started = time.perf_counter()
        results: list[CropResult] = []
        with fitz.open(pdf_path) as doc:
            markers = analysis.markers
            paper_dir = self.output_root / f"{analysis.identity.code}_{analysis.identity.season}{analysis.identity.year[-2:]}_{analysis.identity.variant}"
            for index, marker in enumerate(markers):
                next_marker = markers[index + 1] if index + 1 < len(markers) else None
                segments = segment_for_marker(doc, marker, next_marker)
                images: list[Image.Image] = []
                pages: list[int] = []
                text_parts: list[str] = []
                for segment in segments:
                    image = render_clip(doc[segment.page], segment.y0, segment.y1)
                    image = trim_vertical_white(image)
                    images.append(image)
                    pages.append(segment.page + 1)
                    text_parts.append(extract_text_for_segment(doc[segment.page], segment.y0, segment.y1))
                assembled = stitch(images)
                destination = paper_dir / f"Q{marker.number}.webp"
                paths = save_webp_tiled(assembled, destination, quality=self.quality)
                ink = image_ink_fraction(assembled)
                confidence = min(1.0, marker.score / 1.35)
                warnings: list[str] = []
                if len(segments) > 1:
                    warnings.append(f"multi-page question: {len(segments)} segments")
                if assembled.height < 80:
                    warnings.append("crop height is unusually small")
                if ink < 0.0005:
                    warnings.append("crop has very little ink")
                if not text_parts or not "".join(text_parts).strip():
                    warnings.append("no extractable text in crop")
                status = "PASS" if confidence >= 0.70 and ink >= 0.0005 and text_parts else "REVIEW"
                results.append(
                    CropResult(
                        number=marker.number,
                        image_paths=[str(path) for path in paths],
                        pages=pages,
                        marker_text=marker.text,
                        confidence=round(confidence, 3),
                        status=status,
                        text_chars=len(" ".join(text_parts)),
                        text="\n".join(text_parts),
                        ink_fraction=round(ink, 6),
                        width=assembled.width,
                        height=assembled.height,
                        warnings=warnings,
                    )
                )
        return analysis, results

    def analyze_non_qp(self, pdf_path: Path) -> DocumentAnalysis:
        return self.analyze(pdf_path, kind=parse_identity(pdf_path).kind)


def write_manifest(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def validate_crop_files(results: Iterable[CropResult]) -> list[str]:
    errors: list[str] = []
    for result in results:
        if result.status not in {"PASS", "REVIEW"}:
            errors.append(f"Q{result.number}: invalid status {result.status}")
        if result.width != TARGET_WIDTH:
            errors.append(f"Q{result.number}: width={result.width}, expected {TARGET_WIDTH}")
        if not result.image_paths:
            errors.append(f"Q{result.number}: no image files")
        for raw_path in result.image_paths:
            path = Path(raw_path)
            if not path.exists():
                errors.append(f"Q{result.number}: missing {path}")
                continue
            try:
                with Image.open(path) as image:
                    image.verify()
                with Image.open(path) as image:
                    if image.width != TARGET_WIDTH:
                        errors.append(f"Q{result.number}: {path.name} width={image.width}")
            except Exception as exc:
                errors.append(f"Q{result.number}: invalid image {path}: {exc}")
    return errors


def main() -> int:
    parser = __import__("argparse").ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--kind", choices=["qp", "ms", "er"], default=None)
    parser.add_argument("--output", type=Path, default=Path("crop_output"))
    parser.add_argument("--manifest", type=Path, default=None)
    args = parser.parse_args()
    cropper = CambridgeCropper(args.output)
    identity = parse_identity(args.pdf)
    if (args.kind or identity.kind) == "qp":
        analysis, results = cropper.crop_qp(args.pdf)
        errors = validate_crop_files(results)
        payload = {
            "tool": "cambridge_cropper",
            "source": str(args.pdf),
            "source_sha256": sha256_file(args.pdf),
            "analysis": analysis.to_dict(),
            "crops": [result.to_dict() for result in results],
            "validation_errors": errors,
            "passed": not errors and bool(results),
        }
    else:
        analysis = cropper.analyze_non_qp(args.pdf)
        payload = {
            "tool": "cambridge_cropper",
            "source": str(args.pdf),
            "source_sha256": sha256_file(args.pdf),
            "analysis": analysis.to_dict(),
            "validation_errors": [],
            "passed": bool(analysis.selected_numbers),
        }
    manifest = args.manifest or args.output / "manifest.json"
    write_manifest(manifest, payload)
    print(json.dumps(payload, indent=2))
    return 0 if payload["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
