#!/usr/bin/env python3
"""Confidence-gated Cambridge PDF question cropper.

This is a standalone replacement prototype for the crop stage.  It deliberately
fails closed: it never invents questions when detection is uncertain.  It uses
PDF text/vector geometry before rasterisation, renders only the final clip, and
keeps all page segments for multi-page questions.

Supported proof paths:
* QP: top-level question detection for text-backed Cambridge PDFs.
* MS/ER: conservative question-label analysis for pairing/coverage evidence.

This module is not a claim that one heuristic can perfectly crop every future
Cambridge layout.  Unsupported or ambiguous layouts are reported as REVIEW.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Optional

import fitz  # PyMuPDF
import numpy as np
from PIL import Image

TARGET_WIDTH = 2280
WEBP_MAX_DIM = 16383
DEFAULT_TOP_GUARD_PT = 12.0
DEFAULT_BOUNDARY_GAP_PT = 5.0
BODY_TOP_PT = 60.0
BODY_BOTTOM_FRACTION = 0.94
BODY_SIDE_MARGIN_PT = 24.0

PAPER_RE = re.compile(
    r"(?P<code>\d{4})[_-](?P<season>[msw])(?P<yy>\d{2})[_-]"
    r"(?P<kind>qp|ms|er)(?:[_-](?P<variant>\d{1,3}))?",
    re.IGNORECASE,
)
HEADER_CODE_RE = re.compile(r"\b(?P<code>\d{4})\s*/\s*(?P<component>\d{1,3})\b")
QP_MARKER_RE = re.compile(
    # A19 (2026-09-26): a period followed by a digit is a wrapped decimal
    # value (``6.7 x 10^5 ...``), never a Cambridge top-level question label
    # (9702_m26_qp_22: false Q6/Q9/Q1 split Q5 across two crops). Genuine
    # ``6.`` / ``6. (a)`` labels still match via ``\.(?!\d)``.
    r"^\s*(?:(?:question|q)\s*)?(?P<number>\d{1,3})"
    r"(?:\.(?!\d)|(?=\s)|$)(?P<rest>.*)$",
    re.IGNORECASE,
)
# Literature papers label the top-level question as "Either 1(a)" / "Or 2(b)".
# The number is the question; the (a)/(b) alternative stays inside that crop.
LITERATURE_ALT_RE = re.compile(
    r"^\s*(?:either|or)\s+(?P<number>\d{1,3})\s*\([a-z]\)",
    re.IGNORECASE,
)
# 0475/0477 style: "Either 1 Read this poem ..." (no part letter) on one line,
# or "Either"/"Or" and a bare "1" as two separate lines on the same row.
LITERATURE_ALT_STEM_RE = re.compile(
    r"^\s*(?:Either|Or|EITHER|OR)\s+(?:[*\u2020\u2021]\s*)?(?P<number>\d{1,3})"
    r"(?:\s+(?=[A-Z\u201c\u2018\"'(])|$)"
)
LITERATURE_ALT_WORD_RE = re.compile(r"^\s*(?:Either|Or|EITHER|OR)\s*$")
MS_LABEL_RE = re.compile(
    # A19 (2026-09-26): same decimal guard as QP_MARKER_RE — ``6.7 x 10^5``
    # value rows in a mark scheme are not question labels.
    r"^\s*(?P<number>\d{1,3})(?!\.\d)(?:\s*\([a-zivx]{1,4}\))?"
    r"(?:\s*\([a-zivx]{1,4}\))?\s*(?P<rest>.*)$",
    re.IGNORECASE,
)
ER_QUESTION_RE = re.compile(r"^\s*question\s+(?P<number>\d{1,3})\b", re.IGNORECASE)
# A new section instruction ends the previous question. It must not be cropped
# into that question, and it must not swallow the numbered question that follows.
SECTION_HEADING_RE = re.compile(
    # Real headings only: 'Section B', 'SECTION A', 'Section 3: ...'; body
    # prose such as 'section is from 300380' (0460) or 'Section X of the
    # journey' (0625) must not end the previous question.
    r"^(?:(?-i:(?:Section|SECTION)\s+(?:[A-Z]{1,2}|\d{1,2}|[IVX]{1,4})\b(?!\s+[a-z]))"
    r"|answer\s+(?:any|one|two|three|four|all|the following)\b.*\b(?:section|questions?)\b"
    # B6 (9694 P4): the documents follow the questions, each under a
    # standalone 'DOCUMENT 1' / 'DOCUMENT 4A' heading (full line only).
    r"|document\s+\d{1,2}[a-z]?\s*$"
    # B6 (0410 P1): listening-group headings 'Music A2', 'Music B3 (World
    # Focus: ...)' introduce the stimulus of the NEXT questions.
    r"|music\s+[a-e]\d\b"
    # B6 (0510/0511 P2 listening): standalone 'Exercise 5' + its rubric
    # introduce the next questions (full line only).
    r"|exercise\s+\d{1,2}\s*$)",
    re.IGNORECASE,
)
BLANK_PAGE_RE = re.compile(r"^blank\s+page$", re.IGNORECASE)
COPYRIGHT_RE = re.compile(
    r"permission to reproduce|copyright acknowledgement|to avoid the issue of disclosure",
    re.IGNORECASE,
)
# A19 (2026-09-26): standalone continuation-desk furniture printed below the
# last question's answer space (9709_m26_qp_12 p15) — never question content.
ADDITIONAL_PAGE_RE = re.compile(r"^additional\s+(lined\s+)?pages?$", re.IGNORECASE)
ADDITIONAL_PAGE_INFO_RE = re.compile(r"if you use the following.{0,60}?pages?\b", re.IGNORECASE)


@dataclass(frozen=True)
class PaperIdentity:
    path: str
    code: str
    season: str
    year: str
    kind: str
    variant: str = ""

    @property
    def paper_key(self) -> str:
        return f"{self.code}_{self.season}{self.year[-2:]}_{self.variant}"


@dataclass(frozen=True)
class TextLine:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def width(self) -> float:
        return self.x1 - self.x0


@dataclass(frozen=True)
class Marker:
    number: int
    page: int
    y0: float
    y1: float
    x0: float
    text: str
    score: float
    reason: str


@dataclass
class Segment:
    page: int
    y0: float
    y1: float


@dataclass
class CropResult:
    number: int
    image_paths: list[str]
    pages: list[int]
    marker_text: str
    confidence: float
    status: str
    text_chars: int
    text: str = ""
    ink_fraction: float = 0.0
    width: int = 0
    height: int = 0
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DocumentAnalysis:
    identity: PaperIdentity
    page_count: int
    page_text_chars: list[int]
    markers: list[Marker]
    selected_numbers: list[int]
    warnings: list[str]
    elapsed_ms: float

    def to_dict(self) -> dict:
        data = asdict(self)
        data["identity"] = asdict(self.identity)
        data["markers"] = [asdict(marker) for marker in self.markers]
        return data


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_identity(path: Path) -> PaperIdentity:
    match = PAPER_RE.search(path.stem)
    if not match:
        raise ValueError(f"Cannot parse Cambridge paper identity from {path.name}")
    yy = int(match.group("yy"))
    year = str(2000 + yy if yy < 50 else 1900 + yy)
    return PaperIdentity(
        path=str(path),
        code=match.group("code"),
        season=match.group("season").lower(),
        year=year,
        kind=match.group("kind").lower(),
        variant=match.group("variant") or "",
    )


def lines_from_page(page: fitz.Page) -> list[TextLine]:
    lines: list[TextLine] = []
    data = page.get_text("dict")
    for block in data.get("blocks", []):
        if block.get("type") != 0:
            continue
        for raw_line in block.get("lines", []):
            spans = raw_line.get("spans", [])
            if not spans:
                continue
            text = "".join(str(span.get("text", "")) for span in spans).strip()
            if not text:
                continue
            x0 = min(float(span["bbox"][0]) for span in spans)
            y0 = min(float(span["bbox"][1]) for span in spans)
            x1 = max(float(span["bbox"][2]) for span in spans)
            y1 = max(float(span["bbox"][3]) for span in spans)
            lines.append(TextLine(text=text, x0=x0, y0=y0, x1=x1, y1=y1))
    return sorted(lines, key=lambda line: (line.y0, line.x0))


def _looks_like_header_or_footer(line: TextLine, page: fitz.Page) -> bool:
    text = line.text.lower()
    h = float(page.rect.height)
    if line.y1 < h * 0.055:
        return True
    if line.y0 > h * 0.955:
        return True
    if "turn over" in text or "do not write" in text:
        return True
    if "©" in line.text or "uc les" in text or "ucles" in text:
        return True
    if re.search(r"\b\d{4}/\d{1,3}/[a-z]/[a-z]/\d{2}\b", text):
        return True
    if re.search(r"\bpage\s+\d+\s+of\s+\d+\b", text):
        return True
    return False


def _next_line(lines: list[TextLine], index: int) -> Optional[TextLine]:
    return lines[index + 1] if index + 1 < len(lines) else None


def _has_prose_letters(text: str) -> bool:
    """True for Latin or non-Latin letters. A-Za-z alone drops Hindi, Urdu and Arabic stems."""
    return any(ch.isalpha() for ch in text)


def _qp_candidate(line: TextLine, page: fitz.Page, lines: list[TextLine], index: int) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    literature = LITERATURE_ALT_RE.match(line.text)
    if literature:
        number = int(literature.group("number"))
        if 1 <= number <= 150:
            return Marker(
                number, -1, line.y0, line.y1, line.x0, line.text, 1.35,
                "either/or question label",
            )
    page_w = max(1.0, float(page.rect.width))
    stem = LITERATURE_ALT_STEM_RE.match(line.text)
    if stem and line.x0 / page_w <= 0.20 and 1 <= int(stem.group("number")) <= 150:
        return Marker(
            int(stem.group("number")), -1, line.y0, line.y1, line.x0, line.text, 1.35,
            "either/or question label",
        )
    if re.fullmatch(r"\d{1,3}", line.text.strip()) and line.x0 / page_w <= 0.25:
        # Bare number with an "Either"/"Or" word just left of it on the same row.
        for other in lines:
            if (other is not line and LITERATURE_ALT_WORD_RE.match(other.text)
                    and other.x1 <= line.x0 + 1.0 and line.x0 - other.x1 <= 40.0
                    and abs(other.y0 - line.y0) <= 3.0 and other.x0 / page_w <= 0.15):
                number = int(line.text.strip())
                if 1 <= number <= 150:
                    return Marker(
                        number, -1, other.y0, max(line.y1, other.y1), other.x0,
                        f"{other.text.strip()} {line.text.strip()}", 1.35,
                        "either/or question label",
                    )
    match = QP_MARKER_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None

    # Cambridge QP top-level labels are normally in the left body margin.
    # This excludes page headers, tables and answer options in the right body.
    relative_x = line.x0 / max(1.0, float(page.rect.width))
    if relative_x > 0.20:
        return None
    rest = match.group("rest").strip()
    # A19 (2026-09-26): figure/dimension labels (``9 cm``) are not question
    # labels (9709_m26_qp_12 p4). True same-line stems start with a capital
    # word or a subpart — never a lowercase word, a multi-char unit, or a
    # bare symbol — and no stem is a bare unit token, so neither guard can
    # reject a genuine marker. Single-capital units stay unguarded at line
    # start (``A`` is also the article) and are only rejected when bare.
    if re.match(
        r"^(?:cm|mm|km|kg|mg|ms|mol|ev|pa|kpa|hz|khz|mhz|ghz|[msg]|[°%Ω])\b",
        rest,
        re.IGNORECASE,
    ):
        return None
    if re.fullmatch(
        r"(?:[A-ZΩ]|cm|mm|km|kg|mg|g|ms|s|mol|ev|pa|kpa|hz|khz|mhz|ghz|°C?|%)\.?",
        rest,
        re.IGNORECASE,
    ):
        return None
    # A19: displayed-equation fragments (``2 = βCV 2``) are not question
    # labels (9702_m26_qp_52 p2: a false Q2 truncated Q1 and polluted Q2).
    # True same-line stems start with a word or a subpart, never an
    # operator or relation symbol.
    if re.match(r"^[=+\-±×÷*/<>&|≈∝√∫∑∂∞∅∈∏¬∧∨∩∪≤≥≠≡\u2212]", rest):
        return None
    # A20 (2026-09-26): wrapped instruction/value fragments start lowercase
    # (``3 significant figures.`` — 9709_s26_qp_33 p3 stole Q3 and slivered
    # Q2 to 22px). BUT French listening answers are lowercase phrases at
    # the margin (``15 voyage en ballon`` — 0520_s26_qp_12), so the guard
    # only fires past the margin: true labels measure rel_x 0.083 on every
    # sampled paper, body-indent wraps at 0.12+.
    if rest and rest[0].isalpha() and rest[0].islower() and relative_x > 0.10:
        return None
    # A20: diagram/stem-and-leaf keys (``3 represents 23 items`` —
    # 9231_s26_qp_41 p2) are not question labels. A stem never starts with
    # the bare third-person verb (imperative stems read ``Represent ...``).
    if re.match(r"represents\b", rest, re.IGNORECASE):
        return None
    next_line = _next_line(lines, index)
    next_text = next_line.text if next_line else ""

    # A line containing only a number is often followed by a formula/diagram
    # block before the prose question stem.  Look ahead a few lines, but only
    # accept a number-only marker when it is genuinely in the far-left margin.
    lookahead = " ".join(line.text for line in lines[index + 1:index + 10])
    # A margin number often sits a point or two below the stem on the same row,
    # so the stem sorts before the number and a forward-only look misses it.
    same_row = " ".join(
        other.text for other in lines
        if other is not line and other.x0 > line.x0 and abs(other.y0 - line.y0) <= 12
    )
    # A20 (2026-09-26): a bare digit beside digit/table cells is a
    # stem-leaf/table row, not a label (9231_s26_qp_41 p2 stem column
    # ``2``..``7`` at rel_x 0.14 faked Q2-Q7 and swallowed the paper into
    # Q7). Margin-qualified like the lowercase guard: true bare markers
    # (rel_x 0.083, e.g. beside diagram debris) are kept.
    if (not rest and same_row.strip() and relative_x > 0.10
            and re.match(r"[\d|]", same_row.strip())):
        return None
    nearby_text = f"{next_text} {lookahead} {same_row}"
    has_prose = _has_prose_letters(rest) or _has_prose_letters(nearby_text)
    if not has_prose:
        return None
    if not rest and relative_x > 0.15:
        return None
    if rest and re.fullmatch(r"[\d\s.,:+\-/%]+", rest):
        return None

    score = 1.0
    reason = "left-margin marker with nearby prose"
    if relative_x <= 0.12:
        score += 0.15
    if re.match(r"^(?:question|q)", line.text, re.IGNORECASE):
        score += 0.20
        reason = "explicit question marker"
    if not rest:
        score -= 0.05
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, score, reason)


def _ms_candidate(line: TextLine, page: fitz.Page, lines: list[TextLine], index: int) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    match = MS_LABEL_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None
    relative_x = line.x0 / max(1.0, float(page.rect.width))
    if relative_x > 0.24:
        return None
    # Mark-scheme labels are often at the left of the answer table.  Avoid
    # generic principles and arithmetic rows by requiring either a subpart,
    # explicit question wording, or a line at a table/question-column position.
    rest = match.group("rest").strip()
    has_subpart = bool(re.match(r"^\s*\d+\s*\(", line.text))
    next_line = _next_line(lines, index)
    nearby = (rest + " " + (next_line.text if next_line else "")).lower()
    if not has_subpart and not re.search(r"[A-Za-z]", nearby) and not re.search(r"\b[abcd]\b", nearby):
        return None
    score = 0.65 + (0.15 if has_subpart else 0.0)
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, score, "mark-scheme label")


def _er_candidate(line: TextLine, page: fitz.Page) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    match = ER_QUESTION_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, 0.85, "explicit examiner-report heading")


# Program-listing line numbers (0478 P2 pseudocode: "1 Large = 9999" ... "9 PRINT
# Large") are bare numbers set in a monospace font in the left margin. A 1..9
# listing then outruns the real 1..6 question sequence. Cambridge never sets a
# question number in a monospace font, so such lines are not question markers.
_MONOSPACE_FONT_RE = re.compile(r"courier|mono|consol", re.I)


def _monospace_number_lines(page) -> set:
    keys = set()
    for block in page.get_text("dict").get("blocks", []):
        for line in block.get("lines", []):
            spans = [s for s in line.get("spans", []) if str(s.get("text", "")).strip()]
            if not spans:
                continue
            first = spans[0]
            if (re.fullmatch(r"\d{1,3}", str(first.get("text", "")).strip())
                    and _MONOSPACE_FONT_RE.search(str(first.get("font", "")))):
                keys.add((round(float(first["bbox"][0])), round(float(first["bbox"][1]))))
    return keys


def raw_markers(doc: fitz.Document, kind: str) -> tuple[list[Marker], list[int]]:
    markers: list[Marker] = []
    page_text_chars: list[int] = []
    for page_index, page in enumerate(doc):
        lines = lines_from_page(page)
        page_text_chars.append(sum(len(line.text) for line in lines))
        mono_keys = _monospace_number_lines(page) if kind == "qp" else set()
        for index, line in enumerate(lines):
            if kind == "qp":
                if (round(line.x0), round(line.y0)) in mono_keys:
                    continue
                candidate = _qp_candidate(line, page, lines, index)
            elif kind == "ms":
                candidate = _ms_candidate(line, page, lines, index)
            else:
                candidate = _er_candidate(line, page)
            if candidate is not None:
                markers.append(
                    Marker(
                        number=candidate.number,
                        page=page_index,
                        y0=candidate.y0,
                        y1=candidate.y1,
                        x0=candidate.x0,
                        text=candidate.text,
                        score=candidate.score,
                        reason=candidate.reason,
                    )
                )
    return markers, page_text_chars


_INDENT_TOLERANCE_PT = 8.0


def _walk_qp_sequence(
    first: Marker, by_number: dict[int, list[Marker]], column_aware: bool
) -> list[Marker]:
    sequence = [first]
    cursor = (first.page, first.y0)
    expected = 2
    while expected in by_number:
        candidates = [
            marker for marker in by_number[expected]
            if (marker.page, marker.y0) > cursor
        ]
        if not candidates:
            break
        # Document order is the primary signal.  Answer-option numbers
        # later in the paper can have a slightly higher local score than
        # the true top-level label (e.g. an option row ``4 N`` after Q4),
        # and choosing by score can jump past Q5 and create one enormous
        # final crop.  Pick the earliest valid marker; score only breaks
        # an exact-coordinate tie.
        chosen = min(candidates, key=lambda marker: (marker.page, marker.y0, -marker.score))
        if column_aware:
            # Top-level labels share one left column per page side (booklets
            # mirror margins, so odd and even pages are compared separately).
            # A candidate clearly INDENTED from that column is a numbered
            # list inside a question (0452_s15_qp_12: adjustment notes 1-5
            # at x=71 inside Q4, label column x=50).  Less-indented
            # candidates (right-aligned "10") are never skipped.
            column = {placed.page % 2: placed.x0 for placed in sequence}
            ref = column.get(chosen.page % 2)
            if ref is not None and chosen.x0 > ref + _INDENT_TOLERANCE_PT:
                aligned = [
                    m for m in candidates
                    if m.page % 2 in column and abs(m.x0 - column[m.page % 2]) <= _INDENT_TOLERANCE_PT
                ]
                if aligned:
                    chosen = min(aligned, key=lambda marker: (marker.page, marker.y0, -marker.score))
        sequence.append(chosen)
        cursor = (chosen.page, chosen.y0)
        expected += 1
    return sequence


def _column_outliers(sequence: list[Marker]) -> int:
    """Markers off their page-side's majority label column (> tolerance)."""
    out = 0
    for side in (0, 1):
        xs = sorted(m.x0 for m in sequence if m.page % 2 == side)
        if not xs:
            continue
        mode = max(xs, key=lambda x: sum(abs(y - x) <= _INDENT_TOLERANCE_PT for y in xs))
        out += sum(abs(x - mode) > _INDENT_TOLERANCE_PT for x in xs)
    return out


def select_qp_sequence(markers: list[Marker]) -> list[Marker]:
    """Select the strongest contiguous 1..N QP sequence.

    Cambridge QPs are sequential at top level.  This rejects page numbers,
    table values and repeated decorative labels without guessing across gaps.
    """
    if not markers:
        return []
    by_number: dict[int, list[Marker]] = {}
    for marker in markers:
        by_number.setdefault(marker.number, []).append(marker)
    for values in by_number.values():
        values.sort(key=lambda marker: (marker.page, marker.y0, -marker.score))

    firsts = by_number.get(1, [])
    if not firsts:
        return []
    best: list[Marker] = []
    for first in firsts:
        sequence = _walk_qp_sequence(first, by_number, column_aware=False)
        # The column-aligned walk replaces the plain one only when it is at
        # least as long, so the longest-sequence choice itself never changes;
        # it only corrects detours through an indented numbered list.
        aligned = _walk_qp_sequence(first, by_number, column_aware=True)
        if len(aligned) >= len(sequence):
            sequence = aligned
        if len(sequence) > len(best):
            best = sequence
        elif len(sequence) == len(best) and sequence:
            # Equal length: the top-level sequence spans the paper, an inner
            # numbered list starts part-way through (0452_s15_qp_12 notes
            # 1-5 start on page 9, the real Q1 on page 2).  Score decides
            # only between sequences with the same page span.
            span_new = sequence[-1].page - sequence[0].page
            span_best = best[-1].page - best[0].page
            if span_new > span_best:
                best = sequence
            elif span_new == span_best:
                # Same span: a top-level sequence keeps one label column; a
                # chain that detours through a numbered table/key (0610_s15
                # qp_31 dichotomous-key rows "1 (a)".."4" at x=61 vs label
                # column x=50) is ragged.  Column consistency decides before
                # score.
                off_new, off_best = _column_outliers(sequence), _column_outliers(best)
                if off_new < off_best or (
                    off_new == off_best
                    and sum(x.score for x in sequence) > sum(x.score for x in best)
                ):
                    best = sequence
    return _prefer_label_column(markers, best)


def _prefer_label_column(markers: list[Marker], best: list[Marker]) -> list[Marker]:
    """B4 numbered-list guard.

    An indented numbered list inside one question (9706_s25_qp_22: notes
    "1".."7" at x=72 on page 4) can out-number the real top-level labels
    (bold "1".."4" at x=50 across pages 2-14).  When the walk restricted to
    the outermost label column spans MORE pages than the chosen sequence and
    the chosen sequence leaves that column with weaker markers, the column
    sequence is the top level.
    """
    if len(best) < 2:
        return best
    xmin = min(m.x0 for m in markers)
    column = sorted((m for m in markers if abs(m.x0 - xmin) <= 6.0),
                    key=lambda m: (m.page, m.y0))
    seq: list[Marker] = []
    for m in column:
        if m.number == len(seq) + 1 and (not seq or (m.page, m.y0) > (seq[-1].page, seq[-1].y0)):
            seq.append(m)
    if len(seq) < 2 or [m.number for m in seq] == [m.number for m in best[:len(seq)]] and \
            all(a is b for a, b in zip(seq, best)):
        return best
    off = [m for m in best if m.x0 > xmin + 10.0]
    if not off:
        return best
    span_seq = seq[-1].page - seq[0].page
    span_best = best[-1].page - best[0].page
    # A column sequence that covers at least as much of the paper with at
    # least as many questions is strictly cleaner (9709_s24_qp_12: the "2" of
    # "(2 + ax)^5" at x=77 under Q1 displaced the real Q2 at x=50 on p4).
    if span_seq < span_best or (span_seq == span_best and len(seq) < len(best)):
        return best
    if min(m.score for m in seq) < max(m.score for m in off):
        return best
    return seq


def select_label_sequence(markers: list[Marker]) -> list[Marker]:
    """Conservative MS/ER sequence selection; deduplicate repeated labels."""
    if not markers:
        return []
    # Keep the first occurrence of each question number in document order.
    selected: list[Marker] = []
    seen: set[int] = set()
    for marker in sorted(markers, key=lambda value: (value.page, value.y0)):
        if marker.number in seen:
            continue
        seen.add(marker.number)
        selected.append(marker)
    return selected


_MARK_ALLOC_RE = re.compile(r"\[\s*(?:total\s*:?\s*)?\d{1,3}\s*\]", re.IGNORECASE)


def _text_between(doc: fitz.Document, a: Marker, b: Marker) -> str:
    parts: list[str] = []
    for page_index in range(a.page, b.page + 1):
        for line in lines_from_page(doc[page_index]):
            if page_index == a.page and line.y0 < a.y0 - 0.5:
                continue
            if page_index == b.page and line.y0 >= b.y0 - 0.5:
                continue
            parts.append(line.text)
    return " ".join(parts)


def _drop_numbered_passages(doc: fitz.Document, markers: list[Marker]) -> list[Marker]:
    """B6 numbered-passage guard (9694 P2/P4 passages, 0470 P2 source lists).

    A source or passage with numbered paragraphs restarts at 1 part-way
    through the paper and runs 1, 2, 3 ... with no mark allocation between
    the numbers.  Top-level questions always carry a mark ('[2]') before the
    next label, so such a run is never the question sequence: drop it.
    """
    ordered = sorted(markers, key=lambda m: (m.page, m.y0))
    ones = [m for m in ordered if m.number == 1]
    if len(ones) < 2:
        return markers
    # MCQ papers carry no per-question marks: the rule cannot apply.
    n_marks = sum(len(_MARK_ALLOC_RE.findall(page.get_text())) for page in doc)
    if n_marks < 3:
        return markers
    baseline = select_qp_sequence(markers)
    first_id = id(baseline[0]) if baseline else None
    drop: set[int] = set()
    for start in ones[1:]:
        if id(start) == first_id:
            continue  # the chosen sequence itself starts here: never a passage
        run = [start]
        for m in ordered:
            if (m.page, m.y0) <= (run[-1].page, run[-1].y0):
                continue
            if m.number == run[-1].number + 1 and m.page - start.page <= 1:
                run.append(m)
            elif m.page - start.page > 1:
                break
        if len(run) < 3:
            continue
        if any(_MARK_ALLOC_RE.search(_text_between(doc, x, y)) for x, y in zip(run, run[1:])):
            continue
        drop.update(id(m) for m in run)
    if not drop:
        return markers
    kept = [m for m in markers if id(m) not in drop]
    return kept if any(m.number == 1 for m in kept) else markers


def detect_markers(doc: fitz.Document, kind: str) -> tuple[list[Marker], list[int], list[str]]:
    markers, page_text_chars = raw_markers(doc, kind)
    warnings: list[str] = []
    if kind == "qp":
        selected = select_qp_sequence(_drop_numbered_passages(doc, markers))
        if not selected:
            warnings.append("No contiguous top-level QP sequence beginning at Q1 was found")
        elif len(selected) < 2:
            warnings.append("Only one QP marker found; review required")
    else:
        selected_markers = select_label_sequence(markers)
        if not selected_markers:
            warnings.append(f"No conservative {kind.upper()} question labels found")
        selected = selected_markers
    return selected, page_text_chars, warnings


def _is_section_heading(line: TextLine) -> bool:
    text = re.sub(r"\s+", " ", line.text).strip()
    if not text or len(text) > 90:
        return False
    return bool(SECTION_HEADING_RE.match(text))


def _is_admin_line(line: TextLine) -> bool:
    text = line.text.strip()
    # A19: Additional-page desk furniture is admin, not question content
    # (lets trailing lined Additional-page sheets trim like blank pages).
    norm = re.sub(r"\s+", " ", text)
    return bool(
        BLANK_PAGE_RE.match(text)
        or COPYRIGHT_RE.search(text)
        or ADDITIONAL_PAGE_RE.match(norm)
        or ADDITIONAL_PAGE_INFO_RE.search(norm)
    )


def _is_page_furniture(line: TextLine) -> bool:
    """Page number, barcode, copyright line, or the BLANK PAGE label."""
    text = line.text.strip()
    if not text or _is_admin_line(line):
        return True
    if re.fullmatch(r"\d{1,3}", text):
        return True
    alnum = sum(ch.isalnum() for ch in text)
    if len(text) >= 6 and alnum / len(text) < 0.55:
        return True
    lowered = text.lower()
    if "ucles" in lowered or text.startswith("©") or "cambridge assessment" in lowered:
        return True
    if re.search(r"\b\d{4}/\d{1,3}/", lowered):
        return True
    return False


_MARK_TAIL_RE = re.compile(r"\[\s*(?:total\s*:?\s*)?\d{1,3}\s*\]\s*$", re.IGNORECASE)


def _is_footer_imposition(line: TextLine, page: fitz.Page) -> bool:
    """Scrambled imposition-barcode text in the footer band (s24+ papers:
    'ĬÛú¾...').  Accented letters count as alphanumeric, so the generic
    furniture test misses it; restricted to the bottom band so real
    non-Latin question text (Urdu, Hindi, Chinese) is never skipped."""
    return line.y0 >= float(page.rect.height) * 0.90 and _is_unusual_imposition(line.text)


def _is_marked_answer_line(line: TextLine) -> bool:
    """An answer-dots line that carries the mark allocation ('..... [8]')."""
    t = line.text.strip()
    return bool(_MARK_TAIL_RE.search(t)) and t.count(".") + t.count("\u2026") >= 10


def _page_is_trailing_admin(page: fitz.Page) -> bool:
    """True for a blank page, a copyright-only back page, or an empty page.

    Cambridge prints the copyright block on the blank page. That block is not
    question content. A question page that only mentions blank pages in its
    instructions does not have a standalone ``BLANK PAGE`` line.
    """
    lines = lines_from_page(page)
    if any(BLANK_PAGE_RE.match(line.text.strip()) for line in lines):
        return True
    # B6 (0460_s25_qp_22): from an 'Additional pages' heading down, the page is
    # spare answer space; its wrapped notice line is not question content.
    # The copyright paragraph wraps onto lines the per-line test misses
    # (9717_w24_qp_32 p8), so everything from its first line down is admin too.
    extra_cut = min((line.y0 for line in lines
                     if ADDITIONAL_PAGE_RE.match(re.sub(r"\s+", " ", line.text).strip())
                     or ADDITIONAL_PAGE_INFO_RE.search(re.sub(r"\s+", " ", line.text))
                     or COPYRIGHT_RE.search(line.text)),
                    default=None)
    body = [
        line for line in lines
        if not _looks_like_header_or_footer(line, page) and not _is_page_furniture(line)
        and not _is_footer_imposition(line, page)
        and not (extra_cut is not None and line.y0 >= extra_cut - 1.0)
    ]
    if body:
        return False
    # B6 guard: dots, '[3]' and figures all read as furniture to the text
    # test, so a working/graph page would look empty.  A mark allocation or
    # a figure in the body means it is question content.
    h = float(page.rect.height)
    floor = extra_cut if extra_cut is not None else h * 0.90
    mark_floor = extra_cut if extra_cut is not None else h * 0.955
    for line in lines:
        if (BODY_TOP_PT - 4.0 <= line.y0 < mark_floor
                and (_MARK_ALLOC_RE.search(line.text)
                     or re.match(r"^\s*\((?:[a-h]|i{1,3}|iv|vi{0,3}|ix|x)\)\s*[A-Za-z]", line.text))
                and not _looks_like_header_or_footer(line, page)):
            return False
    try:
        for info in page.get_image_info():
            x0, y0, x1, y1 = info.get("bbox", (0, 0, 0, 0))
            if y0 >= BODY_TOP_PT and y1 <= floor and (x1 - x0) > 40 and (y1 - y0) > 40:
                return False
        # A graph/figure is many thin strokes: test their union, ignoring the
        # margin bars and anything outside the body.
        ux0 = uy0 = float("inf"); ux1 = uy1 = float("-inf")
        w = float(page.rect.width)
        for item in page.get_drawings():
            r = item.get("rect")
            if r is None or r.y0 < BODY_TOP_PT or r.y1 > floor or r.x1 < 45 or r.x0 > w - 45:
                continue
            ux0, uy0, ux1, uy1 = min(ux0, r.x0), min(uy0, r.y0), max(ux1, r.x1), max(uy1, r.y1)
        if ux1 - ux0 > 60 and uy1 - uy0 > 60:
            return False
    except Exception:
        pass
    return True


def _page_has_blank_label(page: fitz.Page) -> bool:
    """True when the page carries a standalone publisher BLANK PAGE label.

    A19 (2026-09-26): such a page holds no question content by publisher
    assertion, so it can be skipped even mid-span (unlike the broader
    trailing-admin test, this can never match a figure-only content page).
    """
    return any(BLANK_PAGE_RE.match(line.text.strip()) for line in lines_from_page(page))


def _first_section_heading(doc: fitz.Document, marker: Marker, next_marker: Optional[Marker]) -> Optional[tuple[int, float]]:
    end_page = next_marker.page if next_marker is not None else len(doc) - 1
    end_y = next_marker.y0 if next_marker is not None else float("inf")
    for page_index in range(marker.page, end_page + 1):
        page = doc[page_index]
        for line in lines_from_page(page):
            if page_index == marker.page and line.y0 <= marker.y0 + 1.0:
                continue
            if page_index == end_page and line.y0 >= end_y - 1.0:
                continue
            if _looks_like_header_or_footer(line, page):
                continue
            if _is_section_heading(line):
                return page_index, line.y0
    return None


def _has_question_content_above(page: fitz.Page, y: float) -> bool:
    for line in lines_from_page(page):
        if line.y1 >= y - 2.0:
            continue
        if _looks_like_header_or_footer(line, page) or _is_section_heading(line) or _is_admin_line(line):
            continue
        if re.fullmatch(r"\d{1,3}", line.text.strip()):
            continue
        return True
    return False


def _is_unusual_imposition(text: str) -> bool:
    value = text.strip()
    if len(value) < 8:
        return False
    alnum = sum(ch.isalnum() for ch in value)
    ascii_count = sum(ord(ch) < 128 for ch in value)
    return alnum / len(value) < 0.55 or ascii_count / len(value) < 0.70


def _last_content_y(page: fitz.Page, include_answer_lines: bool = False) -> float:
    """Bottom of the last real question ink, not the footer barcode or blank tail.

    A19 (2026-09-26): back-matter runs to the bottom of the page, so the cut
    is the FIRST back-matter line (permission/copyright paragraph, BLANK PAGE
    label, Additional-page notice) — matching only paragraph openers left the
    wrapped continuation lines inside the crop (9702_m26_qp_22 Q7).
    """
    height = float(page.rect.height)
    # Footer rules, barcodes and corner crop-marks sit in the bottom band.
    # A diagram that is actually part of the question is above that band.
    footer_band = height * 0.90
    last = BODY_TOP_PT
    ceiling = height
    low_mark = False
    for line in lines_from_page(page):
        text = re.sub(r"\s+", " ", line.text).strip()
        if (COPYRIGHT_RE.search(text) or BLANK_PAGE_RE.match(text)
                or ADDITIONAL_PAGE_RE.match(text)
                or ADDITIONAL_PAGE_INFO_RE.search(text)):
            ceiling = min(ceiling, line.y0)
    for line in lines_from_page(page):
        _t = re.sub(r"\s+", " ", line.text).strip()
        _is_mark = bool(_MARK_TAIL_RE.search(_t)) and (
            _is_marked_answer_line(line) or _MARK_TAIL_RE.sub("", _t).strip(" .\u2026") == "")
        if include_answer_lines and _ANSWER_DOTS_RE.match(_t) and not _looks_like_header_or_footer(line, page):
            _is_mark = True
        if (_is_mark and line.y1 <= min(ceiling, height * 0.955)
                and not _is_footer_imposition(line, page)):
            # B6 (9626_w24_qp_32 Q10, 0460_s25_qp_22 Q6): the answer lines
            # down to the '[8]' / '[Total: 8]' are part of the question; dots
            # alone read as furniture and Cambridge sets the total low on the
            # page (inside the footer band but above the copyright line).
            last = max(last, line.y1)
            low_mark = low_mark or line.y1 > footer_band
            continue
        if _looks_like_header_or_footer(line, page) or _is_page_furniture(line):
            continue
        if _is_unusual_imposition(line.text):
            continue
        if line.y0 >= footer_band:
            continue
        last = max(last, line.y1)
    try:
        for item in page.get_drawings():
            rect = item.get("rect")
            if rect is None:
                continue
            y0 = float(rect.y0)
            y1 = float(rect.y1)
            if y0 >= footer_band or y1 >= height * 0.96:
                continue
            if y1 >= BODY_TOP_PT:
                last = max(last, y1)
        for info in page.get_image_info():
            bbox = info.get("bbox")
            if not bbox:
                continue
            y0, y1 = float(bbox[1]), float(bbox[3])
            if y0 >= footer_band:
                continue
            if y1 >= BODY_TOP_PT:
                last = max(last, y1)
    except Exception:
        pass
    cap = min(height - 2.0, last + 12.0)
    if low_mark:
        # Never pad past the printed footer (page_body_bottom stops above it
        # and render_clip whites out the barcode glyphs).
        cap = min(cap, max(last + 2.0, page_body_bottom(page)))
    if ceiling < height:
        # Never cross into back-matter, even via the descender pad.
        cap = min(cap, ceiling - 2.0)
    return cap


def _imposition_junk_boxes(page: fitz.Page) -> list[tuple[float, float, float, float]]:
    """Bounding boxes of the imposition barcode text in the footer zone."""
    h = float(page.rect.height)
    out = []
    try:
        for word in page.get_text("words"):
            x0, y0, x1, y1, text, *_ = word
            if y0 < h * 0.82:
                continue
            value = str(text or "")
            if re.fullmatch(r"[.\u2026_\-\u2013\u2014]+", value):
                continue
            alnum = sum(char.isalnum() for char in value)
            ascii_count = sum(ord(char) < 128 for char in value)
            if len(value) >= 8 and (alnum / max(1, len(value)) < 0.55
                                    or ascii_count / max(1, len(value)) < 0.70):
                out.append((float(x0), float(y0), float(x1), float(y1)))
    except Exception:
        pass
    return out


def page_body_bottom(page: fitz.Page) -> float:
    bottom = _page_body_bottom_base(page)
    # The imposition barcode can start ABOVE the last real line of a page
    # (0625_s24_qp_42 p9: barcode text from y=778 at x=171, "[2]" at 769-780
    # and "[Total: 8]" at 791-802 at x>500).  Extend the body to real content
    # below the cut (never past the printed footer); render_clip paints the
    # barcode glyphs white so the crop stays clean.
    # 2026-10-01: the same holds WITHOUT a barcode: the fixed 94% line cut
    # the last line of 9618_s24_qp_22 p7 ("[3]" at 781.7-793.9, cut 791.4).
    junk = _imposition_junk_boxes(page)
    h = float(page.rect.height)
    try:
        words = page.get_text("words")
    except Exception:
        return bottom
    footer_top = h * 0.965
    for x0, y0, x1, y1, text, *_ in words:
        value = str(text or "").strip()
        if y0 >= h * 0.82 and ("turn" in value.lower() or value in {"\u00a9", "UCLES"}
                              or re.search(r"\d{4}/\d{1,2}/", value)):
            footer_top = min(footer_top, float(y0))
    left, right = page_clip_bounds(page)
    extra = bottom
    for x0, y0, x1, y1, text, *_ in words:
        if y1 <= bottom or y0 >= footer_top - 2.0 or x1 < left or x0 > right:
            continue
        if any(abs(x0 - j[0]) < 0.5 and abs(y0 - j[1]) < 0.5 for j in junk):
            continue
        if "margin" in str(text).lower():
            continue
        value = str(text or "")
        if len(value) >= 8 and (sum(c.isalnum() for c in value) / len(value) < 0.55
                                or sum(ord(c) < 128 for c in value) / len(value) < 0.70):
            continue  # imposition gibberish, never content
        if re.fullmatch(r"\*?\s*\d{10,}\s*\*?", value) or value.strip() in {"*", "PMT"}:
            continue  # barcode digits / watermark
        extra = max(extra, float(y1) + 3.0)
    return min(extra, footer_top) if extra > bottom else bottom


def _page_body_bottom_base(page: fitz.Page) -> float:
    h = float(page.rect.height)
    bottom = h * BODY_BOTTOM_FRACTION
    # Cambridge PDFs often contain imposition barcodes/gibberish text just
    # above the printed footer.  Detect that vector text and end before it;
    # this is safer than painting pixels after the crop has been made.
    try:
        for word in page.get_text("words"):
            x0, y0, x1, y1, text, *_ = word
            if y0 < h * 0.82:
                continue
            value = str(text or "")
            if re.fullmatch(r"[.\u2026_\-\u2013\u2014]+", value):
                continue  # answer lines are content, not imposition junk (0625_s24_qp_42 Q5/Q10)
            alnum = sum(char.isalnum() for char in value)
            ascii_count = sum(ord(char) < 128 for char in value)
            unusual = len(value) >= 8 and (
                alnum / max(1, len(value)) < 0.55
                or ascii_count / max(1, len(value)) < 0.70
            )
            footerish = "turn over" in value.lower() or value in {"©", "UCLES"}
            if unusual:
                bottom = min(bottom, float(y0) - 4.0)
            elif footerish:
                bottom = min(bottom, float(y0) - 2.0)
    except Exception:
        pass
    return max(h * 0.78, bottom)


def page_clip_bounds(page: fitz.Page) -> tuple[float, float]:
    """Remove the printed do-not-write margin strips before rasterisation."""
    width = float(page.rect.width)
    left = BODY_SIDE_MARGIN_PT
    right = max(left + 10.0, width - BODY_SIDE_MARGIN_PT)
    try:
        words = page.get_text("words")
        left_margin = any(float(word[0]) < width * 0.08 and "margin" in str(word[4]).lower() for word in words)
        right_margin = any(float(word[0]) > width * 0.92 and "margin" in str(word[4]).lower() for word in words)
        if left_margin:
            left = max(left, width * 0.04)
        if right_margin:
            right = min(right, width - width * 0.04)
    except Exception:
        pass
    return left, right


_LEAD_IN_CLOSE_RE = re.compile(r"(?:[?.!:)\]]|\[\s*\d+\s*\]|\[Total:?\s*\d+\]|\.{6,})\s*$")


_CONTEXT_LINE_RE = re.compile(r"^you\s+(?:will\s+)?hear\b", re.IGNORECASE)


def lead_in_heading_y(page: fitz.Page, marker: Marker) -> Optional[float]:
    """Top of whatever introduces ``marker`` on its page: a styled B5 heading,
    or (B6, 0510/0511 P2) a 'You will hear ...' context sentence of <= 2 lines
    directly above the label, following a closed previous question."""
    styled = _styled_lead_in_y(page, marker)
    context = _context_lead_in_y(page, marker)
    tops = [y for y in (styled, context) if y is not None]
    return min(tops) if tops else None


def _context_lead_in_y(page: fitz.Page, marker: Marker) -> Optional[float]:
    rows = sorted((ln for ln in lines_from_page(page)
                   if ln.y1 <= marker.y0 - 1.0 and ln.y0 >= BODY_TOP_PT - 4.0
                   and not _looks_like_header_or_footer(ln, page) and not _is_page_furniture(ln)
                   and not _MARGIN_NOTE_RE.search(ln.text)),
                  key=lambda ln: ln.y0)
    if not rows or marker.y0 - rows[-1].y1 > 40.0:
        return None
    for k in (1, 2):
        if len(rows) < k:
            break
        first = rows[-k]
        if _CONTEXT_LINE_RE.match(first.text.strip()):
            if k == 2 and rows[-1].y0 - first.y1 > 6.0:
                return None
            if len(rows) > k:
                prev = rows[-k - 1]
                if first.y0 - prev.y1 < 8.0 or not _LEAD_IN_CLOSE_RE.search(prev.text.strip()):
                    return None
            return first.y0
    return None


def _styled_lead_in_y(page: fitz.Page, marker: Marker) -> Optional[float]:
    """B5: y0 of a topic/section heading that introduces ``marker``.

    9716 P3 prints an italic topic ("L'ordre public") above each essay title,
    0470 P4 a bold capitalised "DEPTH STUDY B: GERMANY, 1918-45".  Those lines
    belong to the NEXT question, not the tail of the previous one.  Accepted
    only for 1-2 short styled lines (bold / italic / all caps) ending <= 40pt
    above the marker, preceded by a visible gap and by a line that closes the
    previous question ('?', '.', '[N]', '[Total: N]', answer dots) or by
    nothing at all on the page body.
    """
    try:
        blocks = page.get_text("dict")["blocks"]
    except Exception:
        return None
    rows = []
    for block in blocks:
        for line in block.get("lines", []):
            spans = [sp for sp in line.get("spans", []) if sp.get("text", "").strip()]
            if not spans:
                continue
            text = " ".join(sp["text"].strip() for sp in spans).strip()
            y0, y1 = float(line["bbox"][1]), float(line["bbox"][3])
            styled = all(("bold" in sp.get("font", "").lower() or "italic" in sp.get("font", "").lower()
                          or "oblique" in sp.get("font", "").lower()
                          or (int(sp.get("flags", 0)) & (2 | 16))) for sp in spans)
            rows.append((y0, y1, text, styled, float(line["bbox"][0])))
    body_top = BODY_TOP_PT
    above = sorted((r for r in rows if r[1] <= marker.y0 - 1.0 and r[0] >= body_top - 4.0
                    and not re.fullmatch(r"\d{1,3}", r[2])), key=lambda r: r[0])
    if not above:
        return None
    # merge fragments on the same visual row
    merged: list[list] = []
    for r in above:
        if merged and abs(r[0] - merged[-1][0]) < 2.5:
            merged[-1][1] = max(merged[-1][1], r[1]); merged[-1][2] += " " + r[2]
            merged[-1][3] = merged[-1][3] and r[3]
            merged[-1][4] = min(merged[-1][4], r[4])
        else:
            merged.append(list(r))
    heading: list[list] = []
    idx = len(merged) - 1
    if marker.y0 - merged[idx][1] > 40.0:
        return None
    while idx >= 0 and len(heading) < 2:
        y0, y1, text, styled, x0 = merged[idx]
        ok_text = (3 <= len(text) <= 80 and not text.endswith("?") and not re.search(r"\[\s*\d+\s*\]", text)
                   and not re.match(r"^[\d(\u2022\u25cf]", text) and not re.fullmatch(r"[.\u2026\s]+", text))
        letters = [ch for ch in text if ch.isalpha()]
        caps = len(letters) >= 4 and all(ch.isupper() for ch in letters)
        if not re.search(r"[^\W\d_]{3,}", text):
            ok_text = False                      # MCQ option rows "A $7056 B ..."
        # B6 (9717 P3): obfuscated fonts hide bold/italic; a short topic line
        # set exactly in the question-label column (body text is indented)
        # with no closing punctuation is the same kind of heading.
        aligned = (abs(x0 - float(marker.x0)) <= 2.5 and len(text) <= 60
                   and len(text.split()) <= 10 and not re.search(r"[.?!:;,]$", text))
        if not ok_text or not (styled or caps or aligned):
            break
        if heading and heading[-1][0] - y1 > 6.0:
            break
        heading.append(merged[idx]); idx -= 1
    if not heading:
        return None
    top = heading[-1][0]
    if idx >= 0:
        prev = merged[idx]
        if top - prev[1] < 8.0 or not _LEAD_IN_CLOSE_RE.search(prev[2]):
            return None
    return top


def _question_end(doc: fitz.Document, marker: Marker, next_marker: Optional[Marker], start_y: float) -> tuple[int, float]:
    """End this question before a section heading, the next question, or a blank tail.

    ``start_y`` is on the marker's own page. It must not be used as a floor on
    a later page: that was pulling Section B and the next question into Q1.
    """
    heading = _first_section_heading(doc, marker, next_marker)
    if heading is not None:
        heading_page, heading_y = heading
        if any(abs(ln.y0 - heading_y) < 0.5 and GROUP_HEADING_RE.match(re.sub(r"\s+", " ", ln.text).strip())
               for ln in lines_from_page(doc[heading_page])):
            heading_y = _group_block_top(doc[heading_page], heading_y)
        if heading_page > marker.page and not _has_question_content_above(doc[heading_page], heading_y):
            end_page = heading_page - 1
            return end_page, page_body_bottom(doc[end_page])
        end_y = max(2.0, heading_y - DEFAULT_BOUNDARY_GAP_PT)
        if heading_page == marker.page:
            end_y = max(start_y + 2.0, end_y)
        return heading_page, end_y
    if next_marker is not None:
        starts_new_page = (
            next_marker.page > marker.page
            and next_marker.y0 <= BODY_TOP_PT + 25.0
        )
        if starts_new_page:
            end_page = next_marker.page - 1
            # A19 (2026-09-26): trailing blank/admin pages between two
            # questions belong to neither (9702_m26_qp_22 p12 rode into
            # Q5/Q6). Mirrors the last-question trailing-admin loop below.
            while end_page > marker.page and _page_is_trailing_admin(doc[end_page]):
                end_page -= 1
            return end_page, page_body_bottom(doc[end_page])
        end_y = next_marker.y0 - DEFAULT_BOUNDARY_GAP_PT
        _lead = lead_in_heading_y(doc[next_marker.page], next_marker)
        if _lead is not None:
            end_y = min(end_y, _lead - DEFAULT_BOUNDARY_GAP_PT)
        if next_marker.page == marker.page:
            end_y = max(start_y + 2.0, end_y)
        return next_marker.page, end_y
    end_page = len(doc) - 1
    while end_page > marker.page and (_page_is_trailing_admin(doc[end_page])
                                      or _page_is_answer_lines_only(doc[end_page])):
        end_page -= 1
    # B6: pages that are nothing but spare ruled lines were dropped above; on
    # the remaining last page the answer lines ARE the question's answer
    # space (as page_body_bottom gives every other question), so they count.
    return end_page, _last_content_y(doc[end_page], include_answer_lines=True)


def _answer_page_lines(page: fitz.Page):
    """(text lines, dotted lines) ignoring furniture, margin notes and the
    copyright block (everything from the first copyright line down)."""
    lines = lines_from_page(page)
    cut = min((ln.y0 for ln in lines if COPYRIGHT_RE.search(ln.text)), default=None)
    text, dots = [], []
    for line in lines:
        t = line.text.strip()
        if cut is not None and line.y0 >= cut - 1.0:
            continue
        if _is_marked_answer_line(line) and not _looks_like_header_or_footer(line, page):
            # B6 (0460_s25_qp_22 Q6): '..... [4]' ends the question's answer
            # space, so it is content and the trim never cuts above it.
            text.append(line)
        elif _ANSWER_DOTS_RE.match(t):
            dots.append(line)
        elif not (_is_page_furniture(line) or _MARGIN_NOTE_RE.search(t)
                  or _is_footer_imposition(line, page)
                  or re.fullmatch(r"\[?\s*turn\s+over\s*\]?", t, re.IGNORECASE)):
            text.append(line)
    return text, dots


def _end_before_trailing_answer_lines(page: fitz.Page) -> Optional[float]:
    text, dots = _answer_page_lines(page)
    if not text or len(dots) < 5:
        return None
    last = max(ln.y1 for ln in text)
    trailing = [ln for ln in dots if ln.y0 > last]
    if len(trailing) < 5 or len(trailing) != len(dots):
        return None
    return last + 6.0


_ANSWER_DOTS_RE = re.compile(r"^[.\u2026_\s]{12,}$")
_MARGIN_NOTE_RE = re.compile(r"do\s+not\s+write\s+in\s+this\s+margin", re.IGNORECASE)


def _page_is_answer_lines_only(page: fitz.Page) -> bool:
    """A trailing page of the last question that is nothing but ruled answer
    lines (9716 P3: ten lined pages after the essay titles)."""
    text, dots = _answer_page_lines(page)
    if not text:
        return len(dots) >= 5
    # B6 (9717 P3 p3): an answer sheet headed by a one/two-line instruction
    # ('Schreiben Sie die Nummer der ... Frage').  Never a real continuation:
    # no mark, no part label, every text line above >= 20 ruled lines.
    if len(text) <= 2 and len(dots) >= 20 and max(t.y1 for t in text) < min(d.y0 for d in dots):
        if not any(_MARK_ALLOC_RE.search(t.text) or re.match(r"^\s*\(?[a-z]{1,4}\)", t.text)
                   or re.match(r"^\s*\d{1,2}\b", t.text) for t in text):
            return True
    return False


GROUP_HEADING_RE = re.compile(r"^(?:music\s+[a-e]\d\b|exercise\s+\d{1,2}\s*$)", re.IGNORECASE)


def _group_heading_y(page: fitz.Page, marker: Marker) -> Optional[float]:
    """B6: y0 of a listening-group heading above ``marker`` on its page; the
    heading, its instructions and printed score are this question's stimulus."""
    if GROUP_HEADING_RE.match(re.sub(r"\s+", " ", marker.text or "").strip()):
        return None  # the marker IS a heading (exercise_heading_engine)
    lines = lines_from_page(page)
    ys = [line.y0 for line in lines
          if line.y1 <= marker.y0 - 1.0 and GROUP_HEADING_RE.match(re.sub(r"\s+", " ", line.text).strip())]
    if not ys:
        return None
    top = max(ys)
    # Only the FIRST question of the group takes the stimulus: another
    # question label between the heading and this marker means it is taken.
    for line in lines:
        if (top < line.y0 < marker.y0 - 1.0 and abs(line.x0 - marker.x0) <= 3.0
                and re.match(r"^(?:question\s+)?\d{1,2}\b", line.text.strip(), re.IGNORECASE)):
            return None
    return _group_block_top(page, top)


def _group_block_top(page: fitz.Page, heading_y: float) -> float:
    """Extend a group heading up through an unnumbered intro block above it
    (0410 P1 set work: 'Wagner: The Mastersingers ..., Overture' + listening
    note above 'Music D3').  Stops at any label, answer dots or mark."""
    top = heading_y
    for line in sorted(lines_from_page(page), key=lambda ln: -ln.y0):
        if line.y0 >= heading_y - 0.5 or line.y0 < BODY_TOP_PT - 4.0:
            continue
        if _looks_like_header_or_footer(line, page) or _is_page_furniture(line) or _is_footer_imposition(line, page):
            continue
        t = line.text.strip()
        if (re.match(r"^(?:question\s+)?\d{1,2}\b", t, re.IGNORECASE) or _MARK_ALLOC_RE.search(t)
                or _ANSWER_DOTS_RE.match(t)
                or re.match(r"^\(?[a-z]{1,4}\)", t)):
            break
        top = line.y0
    return top


def _stimulus_start(doc: fitz.Document, prev_marker: Marker, marker: Marker) -> Optional[tuple[int, float]]:
    """B6: a section/group heading on an EARLIER page than ``marker`` where the
    previous question already ends (0510 P1 'Exercise 2' reading text, 9694
    P2 'Section B' passage): the stimulus starts this question instead of
    belonging to nobody."""
    heading = _first_section_heading(doc, prev_marker, marker)
    if heading is None or heading[0] >= marker.page:
        return None
    hp, hy = heading
    if any(abs(ln.y0 - hy) < 0.5 and GROUP_HEADING_RE.match(re.sub(r"\s+", " ", ln.text).strip())
           for ln in lines_from_page(doc[hp])):
        hy = _group_block_top(doc[hp], hy)
    return hp, max(0.0, hy - DEFAULT_BOUNDARY_GAP_PT)


def segment_for_marker(doc: fitz.Document, marker: Marker, next_marker: Optional[Marker],
                       prev_marker: Optional[Marker] = None) -> list[Segment]:
    segments: list[Segment] = []
    start_page = marker.page
    start_y = max(0.0, marker.y0 - DEFAULT_TOP_GUARD_PT)
    _lead = lead_in_heading_y(doc[start_page], marker)
    if _lead is not None:
        start_y = max(0.0, min(start_y, _lead - DEFAULT_BOUNDARY_GAP_PT))
    _group = _group_heading_y(doc[start_page], marker)
    if _group is not None:
        start_y = max(0.0, min(start_y, _group - DEFAULT_BOUNDARY_GAP_PT))
    end_page, end_y = _question_end(doc, marker, next_marker, start_y)
    if end_page < start_page:
        end_page = start_page
        end_y = page_body_bottom(doc[start_page])
    if prev_marker is not None and _group is None and prev_marker.page < marker.page:
        _stim = _stimulus_start(doc, prev_marker, marker)
        if _stim is not None:
            start_page, start_y = _stim

    for page_index in range(start_page, end_page + 1):
        if (page_index != start_page and page_index != end_page
                and _page_has_blank_label(doc[page_index])):
            continue
        page = doc[page_index]
        y0 = start_y if page_index == start_page else BODY_TOP_PT
        y1 = end_y if page_index == end_page else page_body_bottom(page)
        y0 = max(0.0, min(y0, float(page.rect.height)))
        y1 = max(y0 + 2.0, min(y1, float(page.rect.height)))
        segments.append(Segment(page=page_index, y0=y0, y1=y1))
    # A19: drop near-empty non-start bands (narrower than one text line) — a
    # trailing sheet gelded by _last_content_y (9709_m26_qp_12 p16) must not
    # ride along as a sliver. The start band and any sole band are never
    # dropped, so no question content can be lost here.
    if len(segments) > 1:
        segments = [
            seg for i, seg in enumerate(segments)
            if i == 0 or (seg.y1 - seg.y0) >= 8.0
        ]
    return segments


def render_clip(page: fitz.Page, y0: float, y1: float) -> Image.Image:
    x0, x1 = page_clip_bounds(page)
    rect = fitz.Rect(x0, y0, x1, y1)
    scale = TARGET_WIDTH / max(1.0, x1 - x0)
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=rect, alpha=False)
    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    junk = [j for j in _imposition_junk_boxes(page) if j[3] > y0 and j[1] < y1]
    if junk:
        base = _page_body_bottom_base(page)
        if y1 > base + 1.0:
            # Extended footer strip (see page_body_bottom): keep only real
            # words; barcode glyphs and registration marks become white.
            band_top = max(y0, base)
            keep = []
            for wx0, wy0, wx1, wy1, text, *_ in page.get_text("words"):
                if wy1 <= band_top or wy0 >= y1:
                    continue
                if any(abs(wx0 - j[0]) < 0.5 and abs(wy0 - j[1]) < 0.5 for j in junk):
                    continue
                if "margin" in str(text).lower():
                    continue
                keep.append((wx0, wy0, wx1, wy1))
            top_px = max(0, int((band_top - y0) * scale))
            band = image.crop((0, top_px, image.width, image.height))
            clean = Image.new("RGB", band.size, "white")
            for wx0, wy0, wx1, wy1 in keep:
                box = (max(0, int((wx0 - x0) * scale) - 3), max(0, int((wy0 - band_top) * scale) - 3),
                       min(band.width, int((wx1 - x0) * scale) + 3),
                       min(band.height, int((wy1 - band_top) * scale) + 3))
                if box[2] > box[0] and box[3] > box[1]:
                    clean.paste(band.crop(box), box[:2])
            image.paste(clean, (0, top_px))
    if image.width != TARGET_WIDTH:
        image = image.resize(
            (TARGET_WIDTH, max(1, round(image.height * TARGET_WIDTH / image.width))),
            Image.Resampling.LANCZOS,
        )
    return image


def trim_vertical_white(image: Image.Image, pad: int = 16) -> Image.Image:
    gray = np.asarray(image.convert("L"))
    ink = gray < 248
    rows = np.flatnonzero(ink.any(axis=1))
    if rows.size == 0:
        return image

    # Registration bars and rotated margin warnings can form a short, dense
    # ink run right at a page clip's top edge.  A real text line at this scale
    # is taller and is followed by content without a large blank gap.  Remove
    # only the very specific short-run pattern; otherwise keep all ink.
    dark = gray < 200
    row_counts = dark.sum(axis=1)
    active = row_counts > max(3, int(image.width * 0.0008))
    runs: list[tuple[int, int]] = []
    index = 0
    while index < len(active):
        if not active[index]:
            index += 1
            continue
        end = index
        while end < len(active) and active[end]:
            end += 1
        runs.append((index, end - 1))
        index = end
    trim_top = int(rows[0])
    if len(runs) >= 2:
        first_start, first_end = runs[0]
        second_start, _second_end = runs[1]
        first_height = first_end - first_start + 1
        gap = second_start - first_end - 1
        first_density = float(row_counts[first_start:first_end + 1].mean()) / max(1, image.width)
        if first_start <= 1 and first_height <= 40 and gap >= 8 and first_density >= 0.08:
            trim_top = second_start
    top = max(0, trim_top - pad)
    bottom = min(image.height, int(rows[-1]) + pad + 1)
    if bottom <= top:
        return image
    return image.crop((0, top, image.width, bottom))


def stitch(parts: list[Image.Image], gap: int = 18) -> Image.Image:
    if not parts:
        raise ValueError("Cannot stitch zero image segments")
    width = max(image.width for image in parts)
    normalised: list[Image.Image] = []
    for image in parts:
        if image.width != width:
            image = image.resize((width, max(1, round(image.height * width / image.width))), Image.Resampling.LANCZOS)
        normalised.append(image)
    height = sum(image.height for image in normalised) + gap * (len(normalised) - 1)
    canvas = Image.new("RGB", (width, height), "white")
    y = 0
    for index, image in enumerate(normalised):
        canvas.paste(image, (0, y))
        y += image.height
        if index + 1 < len(normalised):
            y += gap
    return canvas


def save_webp_tiled(image: Image.Image, destination: Path, quality: int = 92) -> list[Path]:
    """Save the crop the loader will reopen.

    A WebP cannot store a question taller than 16383px without scaling, and
    scaling here would later be stretched back to 2280px and fail the width
    check. Those crops are spooled as one PNG. Mark-scheme files are scaled
    into one WebP by the final saver, not split into ``_partN``.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    if image.width <= WEBP_MAX_DIM and image.height <= WEBP_MAX_DIM:
        image.save(destination, format="WEBP", quality=quality, method=4)
        return [destination]
    if "_MS" in destination.stem:
        scale = min(WEBP_MAX_DIM / max(1, image.width), WEBP_MAX_DIM / max(1, image.height))
        fitted = image.resize(
            (max(1, int(image.width * scale)), max(1, int(image.height * scale))),
            Image.Resampling.LANCZOS,
        )
        fitted.save(destination, format="WEBP", quality=quality, method=4)
        return [destination]
    png = destination.with_suffix(".png")
    image.save(png, format="PNG")
    return [png]


def image_ink_fraction(image: Image.Image) -> float:
    gray = np.asarray(image.convert("L"))
    return float((gray < 245).mean())


def extract_text_for_segment(page: fitz.Page, y0: float, y1: float) -> str:
    return (page.get_text("text", clip=fitz.Rect(0, y0, page.rect.width, y1)) or "").strip()


class CambridgeCropper:
    def __init__(self, output_root: Path, quality: int = 92):
        self.output_root = Path(output_root)
        self.quality = quality

    def analyze(self, pdf_path: Path, kind: Optional[str] = None) -> DocumentAnalysis:
        started = time.perf_counter()
        identity = parse_identity(pdf_path)
        if kind:
            identity = PaperIdentity(identity.path, identity.code, identity.season, identity.year, kind, identity.variant)
        with fitz.open(pdf_path) as doc:
            markers, page_text_chars, warnings = detect_markers(doc, identity.kind)
            selected_numbers = [marker.number for marker in markers]
            page_count = len(doc)
        return DocumentAnalysis(
            identity=identity,
            page_count=page_count,
            page_text_chars=page_text_chars,
            markers=markers,
            selected_numbers=selected_numbers,
            warnings=warnings,
            elapsed_ms=round((time.perf_counter() - started) * 1000, 2),
        )

    def crop_qp(self, pdf_path: Path) -> tuple[DocumentAnalysis, list[CropResult]]:
        analysis = self.analyze(pdf_path, kind="qp")
        results: list[CropResult] = []
        with fitz.open(pdf_path) as doc:
            markers = analysis.markers
            paper_dir = self.output_root / f"{analysis.identity.code}_{analysis.identity.season}{analysis.identity.year[-2:]}_{analysis.identity.variant}"
            for index, marker in enumerate(markers):
                next_marker = markers[index + 1] if index + 1 < len(markers) else None
                prev_marker = markers[index - 1] if index > 0 else None
                segments = segment_for_marker(doc, marker, next_marker, prev_marker)
                images: list[Image.Image] = []
                pages: list[int] = []
                text_parts: list[str] = []
                for segment in segments:
                    image = render_clip(doc[segment.page], segment.y0, segment.y1)
                    image = trim_vertical_white(image)
                    images.append(image)
                    pages.append(segment.page + 1)
                    text_parts.append(extract_text_for_segment(doc[segment.page], segment.y0, segment.y1))
                assembled = stitch(images)
                destination = paper_dir / f"Q{marker.number}.webp"
                paths = save_webp_tiled(assembled, destination, quality=self.quality)
                ink = image_ink_fraction(assembled)
                confidence = min(1.0, marker.score / 1.35)
                warnings: list[str] = []
                if len(segments) > 1:
                    warnings.append(f"multi-page question: {len(segments)} segments")
                if assembled.height < 80:
                    warnings.append("crop height is unusually small")
                if ink < 0.0005:
                    warnings.append("crop has very little ink")
                if not text_parts or not "".join(text_parts).strip():
                    warnings.append("no extractable text in crop")
                status = "PASS" if confidence >= 0.70 and ink >= 0.0005 and text_parts else "REVIEW"
                results.append(
                    CropResult(
                        number=marker.number,
                        image_paths=[str(path) for path in paths],
                        pages=pages,
                        marker_text=marker.text,
                        confidence=round(confidence, 3),
                        status=status,
                        text_chars=len(" ".join(text_parts)),
                        text="\n".join(text_parts),
                        ink_fraction=round(ink, 6),
                        width=assembled.width,
                        height=assembled.height,
                        warnings=warnings,
                    )
                )
        return analysis, results

    def analyze_non_qp(self, pdf_path: Path) -> DocumentAnalysis:
        return self.analyze(pdf_path, kind=parse_identity(pdf_path).kind)


def write_manifest(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def validate_crop_files(results: Iterable[CropResult]) -> list[str]:
    errors: list[str] = []
    for result in results:
        if result.status not in {"PASS", "REVIEW"}:
            errors.append(f"Q{result.number}: invalid status {result.status}")
        if result.width != TARGET_WIDTH:
            errors.append(f"Q{result.number}: width={result.width}, expected {TARGET_WIDTH}")
        if not result.image_paths:
            errors.append(f"Q{result.number}: no image files")
        for raw_path in result.image_paths:
            path = Path(raw_path)
            if not path.exists():
                errors.append(f"Q{result.number}: missing {path}")
                continue
            try:
                with Image.open(path) as image:
                    image.verify()
                with Image.open(path) as image:
                    if image.width != TARGET_WIDTH:
                        errors.append(f"Q{result.number}: {path.name} width={image.width}")
            except Exception as exc:
                errors.append(f"Q{result.number}: invalid image {path}: {exc}")
    return errors


def main() -> int:
    parser = __import__("argparse").ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--kind", choices=["qp", "ms", "er"], default=None)
    parser.add_argument("--output", type=Path, default=Path("crop_output"))
    parser.add_argument("--manifest", type=Path, default=None)
    args = parser.parse_args()
    cropper = CambridgeCropper(args.output)
    identity = parse_identity(args.pdf)
    if (args.kind or identity.kind) == "qp":
        analysis, results = cropper.crop_qp(args.pdf)
        errors = validate_crop_files(results)
        payload = {
            "tool": "cambridge_cropper",
            "source": str(args.pdf),
            "source_sha256": sha256_file(args.pdf),
            "analysis": analysis.to_dict(),
            "crops": [result.to_dict() for result in results],
            "validation_errors": errors,
            "passed": not errors and bool(results),
        }
    else:
        analysis = cropper.analyze_non_qp(args.pdf)
        payload = {
            "tool": "cambridge_cropper",
            "source": str(args.pdf),
            "source_sha256": sha256_file(args.pdf),
            "analysis": analysis.to_dict(),
            "validation_errors": [],
            "passed": bool(analysis.selected_numbers),
        }
    manifest = args.manifest or args.output / "manifest.json"
    write_manifest(manifest, payload)
    print(json.dumps(payload, indent=2))
    return 0 if payload["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
