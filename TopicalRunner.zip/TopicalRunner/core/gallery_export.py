"""Self-contained HTML gallery export for the question bank (moved out of `server.py`, 2026-09-28).

`tools/dependency_check.py` enforces the design contract that **`server.py` is stdlib only** — it is the
process the user runs, and it must start on a bare Python. The gallery export needs Pillow to re-encode
each crop to JPEG (a 27-question bank becomes a file you can email rather than a 20 MB monster), so the
export lives here, in a repository-local module the server imports lazily. The server stays stdlib; this
module is checked as part of the app surface like every other local import, and Pillow is pinned in
`requirements.txt` (`Pillow==11.0.0`) for the tools that already require it.

Everything degrades: with no Pillow (or an unreadable crop) the image is embedded as raw WebP base64,
and a crop that cannot be read at all is skipped with a note in the page, never a crash.
"""

from __future__ import annotations

import time
from typing import Any, Dict


def html_escape(value: str) -> str:
    """Minimal HTML escaping for the gallery export (the page is user-facing, not a template engine)."""
    return (str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def build_gallery_html(payload: dict, app: App, *, title: str = "Topical question bank",
                       max_width: int = 900) -> str:
    """One self-contained HTML file: crops embedded as data URIs, no server, no external files.

    Crops are re-encoded to JPEG at ``max_width`` -- a 27-question bank becomes a file you can email
    rather than a 20 MB monster. Anything unreadable is skipped with a note in the page, never a crash.
    """
    import base64                                                   # noqa: PLC0415 (stdlib)
    import io                                                       # noqa: PLC0415

    def embed(rel: str) -> str:
        for root in app.roots:
            candidate = (root / rel)
            if not candidate.is_file():
                continue
            try:
                from PIL import Image                               # noqa: PLC0415
                with Image.open(candidate) as img:
                    img = img.convert("RGB")
                    if img.width > max_width:
                        img = img.resize((max_width, int(img.height * max_width / img.width)))
                    buffer = io.BytesIO()
                    img.save(buffer, format="JPEG", quality=78)
                return "data:image/jpeg;base64," + base64.b64encode(buffer.getvalue()).decode()
            except Exception:                                       # noqa: BLE001
                try:
                    return "data:image/webp;base64," + base64.b64encode(candidate.read_bytes()).decode()
                except OSError:
                    return ""
        return ""

    cards = []
    for row in payload.get("questions") or []:
        qp = embed((row.get("artifacts") or {}).get("qp", [""])[0]) if (row.get("artifacts") or {}).get("qp") else ""
        ms = embed((row.get("artifacts") or {}).get("ms", [""])[0]) if (row.get("artifacts") or {}).get("ms") else ""
        cards.append(f"""
  <article>
    <h3>{html_escape(str(row.get('topic') or 'UNKNOWN'))} <small>{html_escape(str(row.get('canonical_question') or ''))}</small></h3>
    <p class="meta">{html_escape(str(row.get('board')))} {html_escape(str(row.get('code') or ''))}
      · {html_escape(str(row.get('session') or ''))} · {html_escape(str(row.get('component') or ''))}</p>
    {f'<img alt="question" src="{qp}">' if qp else '<p class="meta">no crop</p>'}
    {f'<details><summary>Mark scheme</summary><img alt="mark scheme" src="{ms}"></details>' if ms else ''}
  </article>""")
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>{html_escape(title)}</title>
<style>
 body {{ font: 15px -apple-system, system-ui, sans-serif; margin: 24px; background: #f6f7f9; color: #12141a; }}
 h1 {{ font-size: 20px; }} .meta {{ color: #666; font-size: 13px; margin: 2px 0 8px; }}
 article {{ background: #fff; border: 1px solid #e3e5ea; border-radius: 10px; padding: 14px; margin: 14px 0; }}
 img {{ width: 100%; height: auto; border: 1px solid #e3e5ea; border-radius: 6px; }}
 h3 {{ margin: 0; font-size: 15px; }} h3 small {{ color: #666; font-weight: 400; }}
</style></head><body>
<h1>{html_escape(title)}</h1>
<p class="meta">{len(cards)} question(s) · generated {time.strftime('%Y-%m-%d %H:%M')} ·
 self-contained (images embedded)</p>
{''.join(cards)}
</body></html>"""
