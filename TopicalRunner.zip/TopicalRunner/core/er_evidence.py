"""Examiner-report text as classification evidence (P4, 2026-10-01).

Read-only and offline. When a question has NO substantive mark-scheme text
(no MS supplied, generic level-of-response grid, unreadable MS), the per-
question commentary from the session's examiner report is a good second
source of subject vocabulary ("candidates who used the equation for elastic
potential energy ..."). It is only ever passed to the classifier through the
existing ``mark_scheme_text`` argument and never written anywhere.

Lookup: ``<code>_<s|w|m><yy>_er*.pdf`` anywhere under the run's input folder.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, Optional

_QP_RE = re.compile(r"(\d{4})_([smw])(\d{2})_qp_?(\d{1,2})", re.I)
_CACHE: Dict[str, Optional[object]] = {}
_FILES: Dict[str, list] = {}


def _er_files(input_dir: Path) -> list:
    try:
        import os
        key = (f"{input_dir}|{Path(input_dir).stat().st_mtime_ns}|"
               f"{len(os.listdir(input_dir))}")  # new downloads invalidate
    except OSError:
        key = str(input_dir)
    if key not in _FILES:
        try:
            _FILES[key] = [p for p in Path(input_dir).rglob("*")
                           if p.is_file() and p.suffix.lower() == ".pdf"
                           and re.search(r"_er(?:_\d+)?$", p.stem, re.I)]
        except OSError:
            _FILES[key] = []
    return _FILES[key]


def find_er_pdf(qp_full_code: str, input_dir) -> Optional[Path]:
    m = _QP_RE.search(qp_full_code or "")
    if not m or not input_dir:
        return None
    code, ses, yy, comp = m.group(1), m.group(2).lower(), m.group(3), m.group(4)
    want = f"{code}_{ses}{yy}_er"
    hits = [p for p in _er_files(Path(input_dir)) if p.stem.lower().startswith(want)]
    if not hits:
        return None
    # A per-component report (…_er_22) beats the whole-session report.
    for p in hits:
        if p.stem.lower() == f"{want}_{comp}":
            return p
    hits.sort(key=lambda p: len(p.stem))
    return hits[0]


def question_comments(qp_full_code: str, input_dir=None, er_path=None,
                      qp_path=None) -> Dict[str, str]:
    """{"1": text, ...} for this QP's component, or {} (never raises).

    Search order: an explicit ``er_path``, then ``input_dir``, then the QP's folder."""
    try:
        path = Path(er_path) if er_path and Path(er_path).is_file() else None
        if path is None and input_dir:
            path = find_er_pdf(qp_full_code, input_dir)
        if path is None and qp_path:
            path = find_er_pdf(qp_full_code, Path(qp_path).parent)
        if path is None:
            return {}
        key = str(path)
        if key not in _CACHE:
            from .examiner_report import ExaminerReportParser
            _CACHE[key] = ExaminerReportParser.parse_pdf(path)
        doc = _CACHE[key]
        if doc is None:
            return {}
        comp = _QP_RE.search(qp_full_code).group(4)
        comps = getattr(doc, "component_reports", {}) or {}
        rep = comps.get(comp) or comps.get(comp.zfill(2))
        if rep is None:
            return {}
        return {str(k): str(v or "") for k, v in (rep.question_comments or {}).items()}
    except Exception:
        return {}


def text_for(comments: Dict[str, str], question_number) -> str:
    m = re.search(r"\d+", str(question_number or ""))
    if not m:
        return ""
    return comments.get(str(int(m.group(0))), "")
