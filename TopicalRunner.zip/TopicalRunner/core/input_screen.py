"""Input screening: set aside files that are named *.pdf but are not PDFs.

Why this exists
---------------
Past-paper sites serve an HTML "not found / coming soon" page for documents
that are not published yet (e.g. ``0606_s26_ms_23.pdf`` or ``0606_s26_er.pdf``
a few weeks after a session).  A bulk download saves that HTML page with a
``.pdf`` name.  Before this screen, such a file made the paper's worker crash
(``FileDataError: Failed to open file``) and a fake examiner report stopped the
whole run at S6, so the batch ended with error code 1.

What it does
------------
Every ``*.pdf`` under the input folder is checked **before** anything else
reads it:

* the first 1 KB must contain the ``%PDF`` signature, and
* PyMuPDF must open it with at least one page (when PyMuPDF is available).

A file that fails is *moved* (never deleted) to ``<input>/_not_a_pdf/`` and its
extension is changed (``.html`` for web pages, ``.bad`` otherwise) so no
scanner ever picks it up again.  The run then treats that document as simply
missing: a QP without its MS goes to ``<Topic>/review_required/``, a missing
ER is skipped, etc.  A short report is written to
``<output>/not_a_pdf_inputs.txt``.

Nothing here can raise: screening problems are reported and ignored.
"""
from __future__ import annotations

import shutil
import time
from pathlib import Path
from typing import List, Tuple

QUARANTINE_DIRNAME = "_not_a_pdf"
REPORT_NAME = "not_a_pdf_inputs.txt"


def _why_not_pdf(path: Path) -> str | None:
    """Return a reason string if *path* is not a usable PDF, else None."""
    try:
        size = path.stat().st_size
        if size == 0:
            return "empty file (0 bytes)"
        with open(path, "rb") as fh:
            head = fh.read(1024)
    except OSError as e:
        return f"cannot read file ({e.__class__.__name__})"
    if b"%PDF" not in head:
        low = head.lstrip().lower()
        if low.startswith(b"<!doctype html") or low.startswith(b"<html") or b"<html" in low[:300]:
            return "web page (HTML) saved with a .pdf name — document not published / download failed"
        return "no %PDF signature — not a PDF"
    try:
        import fitz  # PyMuPDF
    except Exception:
        return None  # signature OK and no way to check deeper: accept
    try:  # keep MuPDF's per-object complaints out of the console
        _prev = fitz.TOOLS.mupdf_display_errors()
        fitz.TOOLS.mupdf_display_errors(False)
    except Exception:
        _prev = None
    try:
        return _open_check(fitz, path)
    finally:
        if _prev is not None:
            try:
                fitz.TOOLS.mupdf_display_errors(_prev)
                fitz.TOOLS.reset_mupdf_warnings()
            except Exception:
                pass


def _open_check(fitz, path: Path) -> str | None:
    try:
        doc = fitz.open(str(path))
        try:
            if doc.page_count < 1:
                return "PDF has no pages"
            if getattr(doc, "is_repaired", False):
                # MuPDF had to rebuild the xref: usually a truncated /
                # half-finished download. Accept only if pages really load.
                chars, bad = 0, 0
                for i in range(doc.page_count):
                    try:
                        page = doc.load_page(i)
                        chars += len(page.get_text("text").strip())
                        chars += 1000 * len(page.get_images())
                    except Exception:
                        bad += 1
                if bad or chars == 0:
                    return "damaged / incomplete PDF (truncated download?) — pages cannot be read"
        finally:
            doc.close()
    except Exception as e:
        return f"damaged PDF — cannot be opened ({e.__class__.__name__})"
    return None


def screen_input_pdfs(input_dir, output_dir=None, *, quiet: bool = False) -> List[Tuple[str, str, str]]:
    """Move non-PDF ``*.pdf`` files out of the way. Returns [(name, reason, new_path)]."""
    moved: List[Tuple[str, str, str]] = []
    try:
        input_dir = Path(input_dir)
        if not input_dir.is_dir():
            return moved
        candidates = [p for p in input_dir.rglob("*")
                      if p.is_file() and p.suffix.lower() == ".pdf"
                      and QUARANTINE_DIRNAME not in p.relative_to(input_dir).parts]
        qdir = input_dir / QUARANTINE_DIRNAME
        for p in sorted(candidates):
            reason = _why_not_pdf(p)
            if not reason:
                continue
            ext = ".html" if reason.startswith("web page") else ".bad"
            qdir.mkdir(parents=True, exist_ok=True)
            rel_parent = p.parent.relative_to(input_dir)
            prefix = "" if str(rel_parent) in ("", ".") else "__".join(rel_parent.parts) + "__"
            dest = qdir / f"{prefix}{p.stem}{ext}"
            n = 2
            while dest.exists():
                dest = qdir / f"{prefix}{p.stem}_{n}{ext}"
                n += 1
            try:
                shutil.move(str(p), str(dest))
            except OSError as e:
                # Could not move (read-only/locked). Report it; downstream
                # stages still guard themselves.
                reason = f"{reason}; could not move it ({e.__class__.__name__})"
                dest = p
            moved.append((str(p.relative_to(input_dir)), reason, str(dest)))
        if moved:
            if not quiet:
                print(f"[input-screen] {len(moved)} file(s) named .pdf are not real PDFs — set aside, "
                      f"treated as missing (run continues):")
                for name, reason, dest in moved:
                    print(f"    - {name}: {reason}")
                print(f"  moved to: {qdir}")
            if output_dir is not None:
                try:
                    out = Path(output_dir)
                    out.mkdir(parents=True, exist_ok=True)
                    lines = [f"not_a_pdf_inputs — {time.strftime('%Y-%m-%d %H:%M:%S')}",
                             "These files were named .pdf but are not PDFs (usually an HTML",
                             "'not found' page for a document that is not published yet).",
                             "They were moved aside and the run continued without them.",
                             "Download the real PDF and put it back in the input folder to use it.", ""]
                    lines += [f"{name}\n    reason: {reason}\n    now at: {dest}" for name, reason, dest in moved]
                    (out / REPORT_NAME).write_text("\n".join(lines) + "\n", encoding="utf-8")
                except OSError:
                    pass
    except Exception as e:  # screening must never break a run
        if not quiet:
            print(f"[input-screen] skipped ({e.__class__.__name__}: {e})")
    return moved
