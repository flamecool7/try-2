"""Engine #2: OCR boundary engine for image-only question papers (2026-09-21).

Authorised by the user as a *separate* engine ("Build it as a separate OCR
boundary engine"), for image-only documents only. It is deliberately narrow:

WHAT THIS ENGINE OWNS
    Finding question BOUNDARIES in a paper with no usable text layer, by
    combining OCR line boxes (Tesseract word/line confidences) with the ink
    profile of the rendered page. Nothing else.

WHAT IT DELIBERATELY REUSES (never reimplements)
    * the locked vector engine ``core/question_split.py`` is untouched - this
      module is only reached when that engine has no text to work with;
    * assembly: ``core.multipage_optimizer.assemble_multipage_question`` (the
      gold assembler - 30 px interpage gap, exact-2280 width, content-preservation
      validation);
    * saving: the caller's ``OutputManager`` (20 px verified white top band,
      LANCZOS, WEBP) - this module never writes a file;
    * the OCR runtime: ``adapters/ocr_fallback`` (tesseract + pytesseract
      availability, and the same ``image_to_data`` shape used for identification).

THE REVIEW POSTURE (explicit, not implied)
    OCR is evidence, never truth. Every crop carries ``needs_review`` and a
    ``qc_reasons`` list; the guarded runner routes any crop whose reasons start
    with ``OCR_`` into ``review_required/<reason>/`` instead of a topic folder.
    A boundary is only considered clean when it has an explicit question-number
    marker, a verified ink-free gap of at least ``MIN_QUESTION_GAP_PX`` rows, and
    a mean OCR word confidence at or above ``MIN_OCR_CONF``. Anything else is
    named in the reasons list: the failure mode this engine must never have is
    silently cutting a question in half and calling it clean.

Real subject (the paper that motivated it): ``9686 Urdu ... 04.pdf`` - 3 pages,
0 chars of text layer, one 1600x2263 PNG per page. Before this engine, S1
identified it (cover corroboration) and S2 failed by name ("0 questions").
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import fitz
import numpy as np
from PIL import Image

# --------------------------------------------------------------------------- #
# Constants (all measured or conventional - none guessed)
# --------------------------------------------------------------------------- #
TARGET_WIDTH = 2280
#: A page with at most this many extractable characters has no usable text layer.
IMAGE_ONLY_MAX_CHARS = 40
#: Ink-free rows accepted as a real inter-question boundary.
MIN_QUESTION_GAP_PX = 28
#: Keep at least this much verified whitespace below a cut.
CUT_MARGIN_PX = 8
#: Grey level below which a pixel counts as ink.
INK_THRESHOLD = 200
#: Mean OCR word confidence required for a clean boundary.
MIN_OCR_CONF = 55.0
#: A question-number marker is a small integer in this range; higher is a mark
#: allocation or a page number, not a question.
MAX_MARKER_VALUE = 80
#: Ink fraction below which a page is blank (matches the gold pdf_io semantics).
BLANK_INK_FRAC = 0.002
#: Cover/instruction page vocabulary (both scripts: this is an Urdu paper).
_COVER_RE = re.compile(
    r"(cambridge\s+international|you\s+must\s+answer|answer\s+booklet|"
    r"invigilators|read\s+these\s+instructions|information\s+for\s+candidates|"
    r"this\s+document\s+has\s+\d+\s+pages)",
    re.IGNORECASE,
)
_BLANK_NOTICE_RE = re.compile(
    r"(blank\s+page|page\s+(?:is\s+)?(?:intentionally\s+)?left\s+blank|"
    r"یہ\s+صفحہ\s+خالی|خالی\s+صفحہ)",
    re.IGNORECASE,
)

_INSTRUCTIONS_RE = re.compile(
    r"(instructions|information|blank\s+page|"
    r"ہدایات|معلومات|جوابی\s+کتابچے)",
    re.IGNORECASE,
)
#: Top/bottom fraction of a page always treated as furniture (header/footer).
FURNITURE_BAND = 0.06
#: Question numbers never live outside this vertical span of the page. Real
#: evidence: a footer page number ("5" at 93% height, right margin) is short,
#: integral and hugs a margin - i.e. it passes every other marker rule, and was a
#: false boundary on the formula-dense 9231 Winter 2025 paper.
# Measured marker row on real CAIE papers: y=207..250px of a 3225px page
# (6.4-7.8%) - just under the header furniture. The previous 0.08 floor (258px)
# sat BELOW that row and silently rejected real question numbers (their merged
# marker line's centre measured 237px on 9231 Winter 2025). The ceiling keeps
# the footer page number out (measured centre 2965px = 91.9%).
MARKER_ZONE = (0.05, 0.90)

# Digit-column readings are trusted only above this confidence (measured: real
# markers 95-96, every false positive 55 or below - see _marker_column_lines).
MIN_COLUMN_CONF = float(os.environ.get("GUARDED_OCR_COLUMN_CONF", "70") or 70)
#: Width of the margin strips OCR'd separately just to isolate question numbers.
MARGIN_STRIP_FRAC = 0.16
#: Digits are script-independent; the English model reads bare integers best.
DIGIT_LANGS = "eng"
#: A question whose content reaches within this many rows of the content end is
#: treated as continuing onto the next page.
OPEN_TAIL_PX = 24

#: Eastern Arabic-Indic and Urdu digit forms -> ASCII, so numbering compares.
_DIGIT_MAP = str.maketrans(
    "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩",
    "01234567890123456789",
)
#: A question mark starts with a small integer: "1", "1.", "Q1", or - the real
#: CAIE shape measured on 9231 Winter 2025 - "1 (a) Use standard results ...", i.e.
#: the number is the FIRST TOKEN of the line that opens the question. Whether a
#: given integer really is a question number is decided by position (margin),
#: vertical zone and, above all, document-level monotonic numbering.
_MARKER_RE = re.compile(r"^\s*(?:q(?:uestion)?\s*)?(?P<n>\d{1,2})(?=$|\s|[.)،۔:ـ])",
                        re.IGNORECASE)
#: Furniture/printer text that must never enter a question crop.
_FURNITURE_RE = re.compile(
    r"(turn\s+over|do\s+not\s+write|permission\s+to\s+reproduce|ucles|university\s+of\s+cambridge|"
    r"\[?\s*turn\s+over|blank\s+page|www\.|https?://|©|copyright|"
    r"^\s*page\s+\d+\s*$|^\s*\d{4}/\d{2}\b|"
    r"\bDFD\b|\*?\s*\d{9,}\s*\*?)",     # barcode row: long digit run
    re.IGNORECASE,
)


def _strip_markers(img: Image.Image, langs: str = DIGIT_LANGS) -> List[_Line]:
    """Question numbers read from the page's own MARGIN STRIPS.

    On formula-dense papers Tesseract merges a question number into the line of
    formulae beside it, so a whole-page pass loses the number exactly where a
    boundary decision needs it most. The strips are narrow (16% of the width), so
    OCR of the number column alone is cheap and isolates the digits. Both margins
    are read: papers are printed LTR (number on the left) and RTL Urdu papers put
    it on the right.
    """
    out: List[_Line] = []
    h, w = img.height, img.width
    strip_w = int(w * MARGIN_STRIP_FRAC)
    # WINDOWED, not full height: Tesseract loses short lines inside a 3000px-tall
    # 365px-wide strip (measured - the full-height pass silently dropped real
    # question numbers that a 700px crop read at 83% confidence), while 1100px
    # windows with a 100px overlap keep the layout analyser sane. A window also
    # bounds the peak: one strip window is ~1.6MB instead of ~14MB.
    # psm 6 ("uniform block") vs the default psm 3: measured on 9231 Winter 2025,
    # a lone question number at the left margin is DISCARDED as noise by the default
    # segmentation (page 12's "6" and page 14's "7" never reached the candidate
    # list, which broke the paper's numbering run at 5), while psm 6 reads them every
    # time ('6', '7', '1', '2' across four real pages). The strip is a single column
    # of text, which is exactly psm 6's assumption.
    strip_psm = int(os.environ.get("GUARDED_OCR_STRIP_PSM", "6") or 6)
    window = int(os.environ.get("GUARDED_OCR_STRIP_WINDOW", "1100") or 1100)
    overlap = int(window * 0.1)
    step = max(1, window - overlap)
    for side in ("left", "right"):
        offset = 0 if side == "left" else w - strip_w
        top = 0
        while top < h:
            bottom = min(top + window, h)
            if bottom - top < 40:
                break
            strip = img.crop((offset, top, offset + strip_w, bottom))
            try:
                lines = _ocr_lines(strip, langs, psm=strip_psm)
            except Exception:
                lines = []
            finally:
                del strip
            for line in lines:
                x0, y0, x1, y1 = line.bbox
                out.append(_Line(text=line.text, conf=line.conf, words=line.words,
                                 bbox=(x0 + offset, y0 + top, x1 + offset, y1 + top)))
            if bottom >= h:
                break
            top += step
    out.extend(_marker_column_lines(img, langs))
    return out


def _marker_column_lines(img: Image.Image, langs: str = DIGIT_LANGS) -> List[_Line]:
    """Read the DIGIT COLUMN beside each margin, one character at a time.

    The wide strips above are the general detector; this is the specialist for the
    measured failure they kept having. A question number printed alone in the
    margin is a single small glyph, and Tesseract's default segmentation treats it
    as noise: with the whole 365px strip it read '1','2','4','5' and lost '3','6','7'
    on a real paper. Restricted to the digit column (0.072-0.10 of the width, which
    the measurements put between the registration mark and the barcode row) and
    told to expect only digits, the same pages read every number, cleanly.

    RTL papers mirror the column. The whitelist carries ASCII *and* Urdu digits so
    an Urdu paper is not silently crippled; reading stays cheap (one narrow column,
    ~500px windows).
    """
    import pytesseract
    digit_chars = "0123456789" + "\u06f0\u06f1\u06f2\u06f3\u06f4\u06f5\u06f6\u06f7\u06f8\u06f9"
    psm = int(os.environ.get("GUARDED_OCR_COLUMN_PSM", "6") or 6)
    window = int(os.environ.get("GUARDED_OCR_COLUMN_WINDOW", "500") or 500)
    config = f"--psm {psm} -c tessedit_char_whitelist={digit_chars}"
    h, w = int(img.height), int(img.width)
    cols = ((0.072, 0.100), (1.0 - 0.100, 1.0 - 0.072))
    out: List[_Line] = []
    step = max(1, int(window * 0.85))
    for frac0, frac1 in cols:
        x0, x1 = int(w * frac0), int(w * frac1)
        if x1 - x0 < 8:
            continue
        top = 0
        while top < h:
            bottom = min(top + window, h)
            if bottom - top < 40:
                break
            crop = img.crop((x0, top, x1, bottom))
            try:
                data = pytesseract.image_to_data(crop, lang=langs, config=config,
                                                 output_type=pytesseract.Output.DICT)
            except Exception:
                data = {}
            finally:
                del crop
            for i, text in enumerate(data.get("text", []) if data else []):
                text = str(text or "").strip()
                value = marker_value(text)
                if value is None:
                    continue
                try:
                    conf = float(data["conf"][i])
                except (KeyError, TypeError, ValueError):
                    conf = 0.0
                # Confidence floor, and it is a MEASURED separation, not a taste:
                # on real 9231 pages the true marker reads 95/96/96 in this column
                # while every false positive found here (the CAIE right column's
                # 0/55 misreads and all four right-margin digits on the Urdu scan,
                # 0/20/22/37) sits far below. Without it the Urdu instructions page
                # produced a "question 1" out of a page-number digit - fabrication,
                # which is the one outcome this engine must never produce.
                if conf < MIN_COLUMN_CONF:
                    continue
                bx0 = x0 + int(data["left"][i])
                by0 = top + int(data["top"][i])
                bx1 = bx0 + int(data["width"][i])
                by1 = by0 + int(data["height"][i])
                out.append(_Line(text=text, conf=conf, words=[(text, conf)],
                                 bbox=(bx0, by0, bx1, by1)))
            if bottom >= h:
                break
            top += step
    return out


def _in_marker_zone(line: _Line, page_height: int) -> bool:
    y_center = (line.bbox[1] + line.bbox[3]) / 2.0
    return page_height * MARKER_ZONE[0] <= y_center <= page_height * MARKER_ZONE[1]


def classify_page(mask: np.ndarray, lines: Sequence["_Line"], page_index: int,
                  page_count: int, *, has_marker: bool) -> str:
    """One page's role: cover / instructions / blank / question / unknown.

    ``has_marker`` is the document-level verdict (after monotonic reconciliation),
    not a raw scan: a page is a QUESTION page only when its number was accepted
    into the paper's numbering.

    The real subject of this engine (``9686 Urdu ... 04.pdf``) is a *partial*
    scan: 3 of its declared 8 pages, and all three are cover, instructions and a
    blank page - there is no question content in the file at all. An engine that
    invents boundaries there would be worse than one that finds none, so page
    roles are classified explicitly and a paper with no question page is refused
    by name instead of producing a single "question" that is really the cover.
    """
    frac = float(mask.mean()) if mask.size else 0.0
    if frac < BLANK_INK_FRAC:
        return "blank"
    if has_marker:
        return "question"
    height = int(mask.shape[0])
    text = "\n".join(ln.text for ln in lines)
    body = [ln for ln in lines if not line_is_furniture(ln, height)]
    # A page whose only body text is the "BLANK PAGE" notice is a blank page. This
    # is its OWN rule: sharing the instructions regex used to make any page of
    # instructions-only text (a real Urdu instructions page) come back "blank".
    notice_pool = body or [ln for ln in lines if (ln.text or "").strip()]
    if notice_pool and all(_BLANK_NOTICE_RE.search(ln.text) for ln in notice_pool):
        return "blank"
    if page_index == 0 and _COVER_RE.search(text):
        return "cover"
    if _INSTRUCTIONS_RE.search(text):
        return "instructions"
    if frac < BLANK_INK_FRAC * 10 and len(lines) <= 3:
        return "blank"
    return "unknown"


def ocr_languages() -> str:
    """Best available OCR language string for this document family."""
    explicit = (os.environ.get("GUARDED_OCR_LANGS") or "").strip()
    if explicit:
        return explicit
    try:
        import pytesseract
        installed = set(pytesseract.get_languages(config=""))
    except Exception:
        return "eng"
    if "urd" in installed and "eng" in installed:
        return "urd+eng"
    if "urd" in installed:
        return "urd"
    return "eng"


def ocr_disabled() -> bool:
    return (os.environ.get("GUARDED_OCR") or "").strip() == "0"


def ocr_available() -> Tuple[bool, str]:
    """Availability of the OCR runtime, with a human reason either way."""
    if ocr_disabled():
        return False, "OCR disabled by GUARDED_OCR=0"
    from adapters.ocr_fallback import ocr_available as _avail
    return _avail()


# --------------------------------------------------------------------------- #
# Document-level gate
# --------------------------------------------------------------------------- #
def document_is_image_only(pdf_path: str | Path, *, probe_pages: int = 0) -> Tuple[bool, str]:
    """(is_image_only, reason) by reading the real text layer, never the filename.

    ``probe_pages=0`` means all pages. A document counts as image-only when no
    page carries more than ``IMAGE_ONLY_MAX_CHARS`` characters of extractable
    text - i.e. the locked vector engine has nothing to split on.
    """
    path = Path(pdf_path)
    try:
        with fitz.open(path) as doc:
            count = len(doc) if not probe_pages else min(len(doc), probe_pages)
            per_page = []
            for i in range(count):
                per_page.append(len(doc[i].get_text().strip()))
    except Exception as exc:
        return False, f"could not read text layer: {exc}"
    if not per_page:
        return False, "document has no pages"
    worst = max(per_page)
    if worst <= IMAGE_ONLY_MAX_CHARS:
        return True, (f"no usable text layer ({sum(per_page)} chars over {len(per_page)} "
                      f"pages, max {worst})")
    return False, f"text layer present (max {worst} chars/page)"


def should_handle(pdf_path: str | Path) -> Tuple[bool, str]:
    """Should this document go to the OCR boundary engine at all?"""
    ok, reason = ocr_available()
    if not ok:
        return False, f"OCR unavailable: {reason}"
    image_only, why = document_is_image_only(pdf_path)
    if not image_only:
        return False, f"not image-only: {why}"
    return True, why


# --------------------------------------------------------------------------- #
# Page rasterisation + OCR
# --------------------------------------------------------------------------- #
@dataclass
class _Line:
    text: str
    bbox: Tuple[float, float, float, float]   # x0, y0, x1, y1 in raster px
    conf: float
    words: List[Tuple[str, float]] = field(default_factory=list)


@dataclass
class _Region:
    y0: int
    y1: int
    marker: Optional[int] = None          # question number read on this region
    marker_text: str = ""
    conf: float = 0.0
    tight: bool = False                   # cut had < MIN_QUESTION_GAP_PX verified white
    text: str = ""


def _render_page(page: "fitz.Page", target_width: int) -> Image.Image:
    """Render one page as RGB exactly ``target_width`` px wide (locked width)."""
    rect = page.rect
    src_w = float(rect.width) or 1.0
    zoom = target_width / src_w
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
    img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    if img.width != target_width:                     # rounding safety
        new_h = int(round(img.height * (target_width / img.width)))
        img = img.resize((target_width, new_h), Image.LANCZOS)
    return img


def _ocr_lines(img: Image.Image, langs: str, psm: Optional[int] = None) -> List[_Line]:
    """OCR one rendered page into line boxes with confidences (raster pixels).

    Tesseract refuses very large single images; a page rendered at 2280 px wide
    is far below any limit, so no tiling is needed. Failures return [] and the
    caller turns that into named review reasons, never into a silent pass.
    """
    import pytesseract
    config = f"--psm {int(psm)}" if psm else ""
    try:
        data = pytesseract.image_to_data(img, lang=langs, config=config,
                                         output_type=pytesseract.Output.DICT)
    except Exception:
        return []
    grouped: Dict[Tuple[int, int, int], List[int]] = {}
    n = len(data.get("text", []))
    for i in range(n):
        text = str(data["text"][i] or "").strip()
        if not text:
            continue
        key = (int(data.get("block_num", [0])[i] or 0),
               int(data.get("par_num", [0])[i] or 0),
               int(data.get("line_num", [0])[i] or 0))
        grouped.setdefault(key, []).append(i)

    lines: List[_Line] = []
    for _key, idxs in grouped.items():
        idxs.sort(key=lambda i: float(data["left"][i]))
        words, confs = [], []
        xs0, ys0, xs1, ys1 = [], [], [], []
        for i in idxs:
            text = str(data["text"][i] or "").strip()
            if not text:
                continue
            try:
                conf = float(data["conf"][i])
            except Exception:
                conf = -1.0
            words.append((text, conf))
            if conf >= 0:
                confs.append(conf)
            x = float(data["left"][i]); y = float(data["top"][i])
            w = float(data["width"][i]); h = float(data["height"][i])
            xs0.append(x); ys0.append(y); xs1.append(x + w); ys1.append(y + h)
        if not words:
            continue
        lines.append(_Line(
            text=" ".join(w for w, _c in words),
            bbox=(min(xs0), min(ys0), max(xs1), max(ys1)),
            conf=(sum(confs) / len(confs)) if confs else 0.0,
            words=words,
        ))
    lines.sort(key=lambda ln: (ln.bbox[1], ln.bbox[0]))
    return lines


# --------------------------------------------------------------------------- #
# Markers, furniture, ink profile
# --------------------------------------------------------------------------- #
def marker_value(line_text: str) -> Optional[int]:
    """The question number on this line, or None when the line is not a marker."""
    norm = line_text.translate(_DIGIT_MAP)
    m = _MARKER_RE.match(norm)
    if not m:
        return None
    raw = m.group("n") or m.group("n2")
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    if value < 1 or value > MAX_MARKER_VALUE:
        return None
    return value


def line_is_furniture(line: _Line, page_height: int) -> bool:
    """Header/footer/printer text: never part of a question crop."""
    if _FURNITURE_RE.search(line.text or ""):
        return True
    band = page_height * FURNITURE_BAND
    y0, y1 = line.bbox[1], line.bbox[3]
    if y1 <= band or y0 >= page_height - band:
        # ...only when the line is short: a tall page's real first line can sit
        # near the top, and a long text line there is content, not furniture.
        return len((line.text or "").split()) <= 8
    return False


def ink_rows(img: Image.Image) -> np.ndarray:
    """Boolean per-row ink mask (True where the row contains ink)."""
    gray = np.asarray(img.convert("L"))
    return (gray < INK_THRESHOLD).any(axis=1)


def _gap_above(mask: np.ndarray, y: int, limit: int) -> int:
    """Length of the ink-free run ending just above row ``y`` (capped by limit)."""
    run = 0
    i = y - 1
    while i >= 0 and run < limit:
        if mask[i]:
            break
        run += 1
        i -= 1
    return run


def _content_band(mask: np.ndarray, lines: Sequence[_Line], page_height: int) -> Tuple[int, int]:
    """[top, bottom) rows that hold question content (furniture excluded)."""
    rows = np.flatnonzero(mask)
    if rows.size == 0:
        return 0, page_height
    top = int(rows[0])
    bottom = int(rows[-1]) + 1
    band = int(page_height * FURNITURE_BAND)
    for line in lines:
        if not line_is_furniture(line, page_height):
            continue
        ly0, ly1 = int(line.bbox[1]), int(line.bbox[3])
        if ly1 <= band:
            top = max(top, ly1 + CUT_MARGIN_PX)
        elif ly0 >= page_height - band:
            bottom = min(bottom, ly0 - CUT_MARGIN_PX)
    # The always-furniture bands, used only to clamp.
    top = max(top, 0)
    bottom = min(bottom, page_height)
    if bottom - top < 40:
        return int(rows[0]), int(rows[-1]) + 1
    return top, bottom


def is_marker_line(line: _Line, page_height: int, page_width: int,
                   *, margin_left: Optional[float] = None,
                   margin_right: Optional[float] = None,
                   band: Optional[Tuple[int, int]] = None) -> bool:
    """Is this OCR line a question-number marker?

    Evidence required: the line's first token is a small integer, it is not
    furniture, it starts AT the page's own left content margin (or ends at the
    right one for RTL papers), and it sits inside the content band - never in the
    header/footer furniture zone where the page number lives.
    """
    if line_is_furniture(line, page_height):
        return False
    if marker_value(line.text) is None:
        return False
    if band is not None and not (band[0] <= (line.bbox[1] + line.bbox[3]) / 2.0 <= band[1]):
        return False
    if margin_left is None or margin_right is None:
        # No margin estimate available: fall back to the outer thirds.
        x_center = (line.bbox[0] + line.bbox[2]) / 2.0
        return (x_center <= page_width * 0.35) or (x_center >= page_width * 0.65)
    tol = 45.0
    return (line.bbox[0] <= margin_left + tol) or (line.bbox[2] >= margin_right - tol)


def looks_like_text(line: _Line, *, min_words: int = 2) -> bool:
    """Is this OCR line real prose rather than a rule/barcode/margin artefact?

    Measured junk that had to be excluded from margin estimation: a footer ruler
    ("| s |") and a rotated margin warning ("NISYVW SIHL NI SLIM LON OG"). Both are
    nominally "lines" with several words; neither is text.
    """
    text = (line.text or "").strip()
    if not text:
        return False
    alnum = sum(1 for ch in text if ch.isalnum())
    if alnum / max(len(text), 1) < 0.5:
        return False
    solid = sum(1 for w in text.split() if sum(1 for ch in w if ch.isalnum()) >= 2)
    return solid >= min_words


def page_margins(lines: Sequence[_Line], page_height: int) -> Tuple[float, float]:
    """(left, right) content margins of a page, from its own non-furniture lines.

    The real question number is the leftmost object on its line, so measuring the
    page's own margin is what separates "1 (a) Use standard results" from a
    formula that happens to start with a digit further into the page.
    """
    # Only real TEXT lines set the margin: a stray glyph, a rotated margin
    # warning or a barcode fragment is not where a question number lives, and one
    # such line is enough to move the estimate and reject every true marker (the
    # measured failure: a barcode at x=136 made the real "1 (a) ..." at x=193 look
    # like it was not at the margin).
    # A margin estimate must ignore the page's outer furniture band: rotated
    # "DO NOT WRITE IN THIS MARGIN" warnings come back from the strip pass as
    # garbled text ("NISYVW SIHL NI SLIM LON OG" at x=29) and footer rules come
    # back as junk ("| s |" at x=136). Either one moves the estimate leftwards and
    # rejects every real marker. Only lines whose centre sits in the central band
    # of the page can set a content margin.
    width = max((ln.bbox[2] for ln in lines), default=0.0)
    centred = [ln for ln in lines
               if looks_like_text(ln) and not line_is_furniture(ln, page_height)
               and width and 0.15 * width <= (ln.bbox[0] + ln.bbox[2]) / 2.0 <= 0.85 * width]
    body = centred or [ln for ln in lines
                       if looks_like_text(ln) and not line_is_furniture(ln, page_height)]
    if not body:
        return 0.0, 0.0
    return (min(ln.bbox[0] for ln in body), max(ln.bbox[2] for ln in body))


def _markers(lines: Sequence[_Line], page_height: int, page_width: int,
             extra: Optional[Sequence[_Line]] = None,
             band: Optional[Tuple[int, int]] = None) -> List[_Line]:
    """Candidate question-number lines on one page (all filters applied).

    ``extra`` carries the margin-strip pass, where the number is often isolated in
    the OCR output ("1 (a) ..." with conf 83-95) instead of being merged into the
    formula line beside it.
    """
    margin_left, margin_right = page_margins(list(lines) + list(extra or []), page_height)
    pool = list(lines) + list(extra or [])
    out: List[_Line] = []
    seen: List[Tuple[float, int]] = []
    for ln in pool:
        if marker_value(ln.text) is None:
            continue
        if not is_marker_line(ln, page_height, page_width, margin_left=margin_left,
                              margin_right=margin_right, band=band):
            continue
        if not _in_marker_zone(ln, page_height):
            continue
        key = (round(ln.bbox[1], 1), marker_value(ln.text))
        if key in seen:          # the same number seen by both passes
            continue
        seen.append(key)
        out.append(ln)
    out.sort(key=lambda ln: ln.bbox[1])
    return out


def reconcile_numbering(candidates: Sequence[Tuple[int, "_Line"]]
                        ) -> Tuple[List[Tuple[int, "_Line"]], List[Tuple[int, "_Line"]]]:
    """Keep the strictly increasing 1..n run; report the candidates it dropped.

    This runs over the WHOLE DOCUMENT, in page order - not per page. Per-page
    reconciliation was a real bug: a formula that happens to start with "1" on a
    continuation page would restart the count and invent a question. Document
    level, the same line can never match the expected number, because the paper's
    own numbering has already moved past it.
    """
    kept: List[Tuple[int, "_Line"]] = []
    dropped: List[Tuple[int, "_Line"]] = []
    expected = 1
    for page_index, line in candidates:
        if marker_value(line.text) == expected:
            kept.append((page_index, line))
            expected += 1
        else:
            dropped.append((page_index, line))
    return kept, dropped


# --------------------------------------------------------------------------- #
# Region detection
# --------------------------------------------------------------------------- #
def _text_in_span(lines: Sequence[_Line], y0: float, y1: float,
                  page_height: int) -> Tuple[str, float]:
    inside = [ln for ln in lines
              if not line_is_furniture(ln, page_height) and y0 <= (ln.bbox[1] + ln.bbox[3]) / 2.0 < y1]
    if not inside:
        return "", 0.0
    text = "\n".join(ln.text for ln in inside)
    confs, weights = 0.0, 0
    for ln in inside:
        nw = max(1, len(ln.words))
        confs += ln.conf * nw
        weights += nw
    return text, (confs / weights if weights else 0.0)


def detect_regions(mask: np.ndarray, lines: Sequence[_Line],
                   kept: Sequence[_Line], band: Tuple[int, int]):
    """-> (regions, leading) for one page.

    ``leading`` is the strip from the content top down to the cut before the FIRST
    marker. On a page whose first question starts lower down, that strip is the
    tail of the question that began on the previous page - dropping it would cut a
    real question in half (this was 29% of question-page ink rows on the real
    9231 paper before it was attached).

    Split one page into question regions (marker-anchored, gap-refined).

    ``kept`` are this page's accepted question numbers; a page without any is not
    a question page and gets no regions (its rows may still be attached as a
    continuation segment by the caller).
    """
    if not kept:
        return [], None
    height = int(mask.shape[0])
    top, bottom = band
    regions: List[_Region] = []
    for i, line in enumerate(kept):
        nxt = kept[i + 1] if i + 1 < len(kept) else None
        start = int(line.bbox[1])
        gap = _gap_above(mask, start, int(height))
        tight_start = gap < MIN_QUESTION_GAP_PX
        y0 = start if tight_start else start - max(gap - CUT_MARGIN_PX, 0)
        y0 = max(top, y0)
        if nxt is None:
            y1 = bottom
            tight_next = False
        else:
            nxt_start = int(nxt.bbox[1])
            gap_next = _gap_above(mask, nxt_start, int(height))
            tight_next = gap_next < MIN_QUESTION_GAP_PX
            y1 = max(y0 + 1, nxt_start if tight_next else nxt_start - (gap_next - CUT_MARGIN_PX))
        text, conf = _text_in_span(lines, y0, y1, height)
        regions.append(_Region(y0=int(y0), y1=int(min(y1, bottom)),
                               marker=marker_value(line.text),
                               marker_text=line.text.strip(), conf=conf,
                               tight=tight_start or tight_next, text=text))
    regions = [r for r in regions if r.y1 - r.y0 >= 40]
    leading = None
    if regions and regions[0].y0 - top >= 40:
        lead_y1 = regions[0].y0
        lead_text, lead_conf = _text_in_span(lines, top, lead_y1, height)
        leading = _Region(y0=int(top), y1=int(lead_y1), marker=None,
                          conf=lead_conf, text=lead_text)
    return regions, leading


def _region_open_at_bottom(mask: np.ndarray, region: _Region, band: Tuple[int, int]) -> bool:
    """Does this region's content run into the page bottom (= continues on next)?"""
    return (band[1] - region.y1) <= OPEN_TAIL_PX


# --------------------------------------------------------------------------- #
# Public: crop an image-only paper
# --------------------------------------------------------------------------- #
def analyze(pdf_path: str | Path, *, langs: Optional[str] = None, page_limit: int = 0,
            target_width: int = TARGET_WIDTH) -> Dict[str, Any]:
    """Boundary analysis: pages -> candidates -> document numbering -> questions.

    Three passes, in this order, because each depends on the previous one:

    1. render + OCR every page (full page AND the two margin strips), and collect
       question-number CANDIDATES with the page's own content band and margins;
    2. reconcile the candidates into ONE strictly increasing 1..n run for the
       whole document - this is what stops a formula that starts with "1" on a
       continuation page from inventing a question;
    3. cut regions only on accepted numbers, and attach markerless pages as
       continuation segments of an open question (never as new questions).

    A page is a question page only when its number survived step 2.
    """
    langs = langs or ocr_languages()
    path = Path(pdf_path)
    pages: List[Dict[str, Any]] = []
    notes: List[str] = []
    with fitz.open(path) as doc:
        total = len(doc)
        count = total if not page_limit else min(total, page_limit)
        for idx in range(count):
            img = _render_page(doc[idx], target_width)
            line_objs = _ocr_lines(img, langs)
            strip = _strip_markers(img)
            mask = ink_rows(img)
            band = _content_band(mask, line_objs, img.height)
            candidates = _markers(line_objs, img.height, img.width, extra=strip, band=band)
            # Flat-peak discipline: a 20-page paper at 2280px is ~450MB of rasters,
            # which is how this box ran out of memory. Geometry is all the analysis
            # needs afterwards - the ink ROW mask is ~3KB per page, and rasters are
            # re-rendered on demand when the crops are actually assembled.
            pages.append({"index": idx, "image": None, "lines": line_objs,
                          "strip": strip, "candidates": candidates, "band": band,
                          "mask": mask, "height": img.height, "width": img.width})
            del img

    # A number is unique in a paper, so the same value seen by both passes (full
    # page + margin strip) is ONE candidate: keep the most confident reading.
    best_by_value: Dict[int, Tuple[int, "_Line"]] = {}
    for page in pages:
        for line in page["candidates"]:
            value = int(marker_value(line.text) or 0)
            current = best_by_value.get(value)
            if current is None or line.conf > current[1].conf:
                best_by_value[value] = (page["index"], line)
    flat = [best_by_value[v] for v in sorted(best_by_value)]
    flat.sort(key=lambda t: (t[0], t[1].bbox[1]))
    kept, dropped = reconcile_numbering(flat)
    kept_pages = {pi for pi, _ln in kept}
    dropped_by_page: Dict[int, List[int]] = {}
    for pi, ln in dropped:
        dropped_by_page.setdefault(pi, []).append(int(marker_value(ln.text) or 0))

    for page in pages:
        page["kept"] = [ln for pi, ln in kept if pi == page["index"]]
        page["role"] = classify_page(page["mask"], page["lines"], page["index"], count,
                                     has_marker=page["index"] in kept_pages)
        if page["kept"]:
            page["regions"], page["leading"] = detect_regions(
                page["mask"], page["lines"], page["kept"], page["band"])
        else:
            page["regions"], page["leading"] = [], None
        # (no raster is retained: see the note where pages are collected)

    questions: List[Dict[str, Any]] = []
    open_q: Optional[Dict[str, Any]] = None
    for page in pages:
        index = page["index"]
        leading = page.get("leading")
        if leading is not None:
            if open_q is not None:
                open_q["segments"].append((index, leading.y0, leading.y1))
                open_q["pages"].append(index)
                open_q["texts"].append(leading.text)
                open_q["confs"].append(leading.conf)
                open_q["reasons"].add("OCR_CONTINUATION_UNMARKED")
            else:
                notes.append(f"p{index + 1}: {leading.y1 - leading.y0} ink rows above the "
                             f"first marker with no open question to continue")
        if page["regions"]:
            candidates_regions = page["regions"]
        elif page["role"] in ("unknown",):
            top, bottom = page["band"]
            text, conf = _text_in_span(page["lines"], top, bottom, page["height"])
            candidates_regions = [_Region(y0=top, y1=bottom, marker=None, conf=conf, text=text)]
            if open_q is None:
                notes.append(f"p{index + 1}=unmarked page skipped (no open question to continue)")
                candidates_regions = []
        else:
            candidates_regions = []

        for region in candidates_regions:
            if region.marker is None:
                if open_q is None:
                    notes.append(f"p{index + 1}: unmarked region skipped")
                    continue
                open_q["segments"].append((index, region.y0, region.y1))
                open_q["pages"].append(index)
                open_q["texts"].append(region.text)
                open_q["confs"].append(region.conf)
                open_q["reasons"].add("OCR_CONTINUATION_UNMARKED")
                if region.tight:
                    open_q["reasons"].add("OCR_TIGHT_BOUNDARY")
                if not _region_open_at_bottom(page["mask"], region, page["band"]):
                    open_q["open"] = False
                    questions.append(open_q)
                    open_q = None
                continue
            if open_q is not None:
                open_q["open"] = False
                questions.append(open_q)
                open_q = None
            reasons = set()
            if region.tight:
                reasons.add("OCR_TIGHT_BOUNDARY")
            if not (region.text or "").strip():
                reasons.add("OCR_TEXT_EMPTY")
            if region.conf and region.conf < MIN_OCR_CONF:
                reasons.add(f"OCR_LOW_CONFIDENCE({region.conf:.0f})")
            if dropped_by_page.get(index):
                reasons.add(f"OCR_DROPPED_CANDIDATE({sorted(set(dropped_by_page[index]))})")
            open_q = {
                "number": int(region.marker),
                "segments": [(index, region.y0, region.y1)],
                "pages": [index],
                "texts": [region.text],
                "confs": [region.conf],
                "reasons": reasons,
                "expected_next": int(region.marker) + 1,
                "open": _region_open_at_bottom(page["mask"], region, page["band"]),
            }
            if open_q["open"]:
                continue
            questions.append(open_q)
            open_q = None
    if open_q is not None:
        open_q["open"] = False
        questions.append(open_q)

    roles = [p["role"] for p in pages]
    role_note = ", ".join(f"p{p['index'] + 1}={p['role']}" for p in pages)
    if not questions:
        if not any(r == "question" for r in roles):
            reason = (f"OCR_NO_QUESTION_PAGE: no page carries question numbering "
                      f"({role_note})" + (f"; candidates dropped: {sorted(set(v for l in dropped_by_page.values() for v in l))}"
                                          if dropped_by_page else ""))
        else:
            reason = f"OCR_NO_BOUNDARY: question page(s) present but no usable region ({role_note})"
        return {"pages": pages, "questions": [], "langs": langs, "page_count": count,
                "roles": roles, "reason": reason, "notes": notes}
    return {"pages": pages, "questions": questions, "langs": langs, "page_count": count,
            "roles": roles, "notes": notes,
            "reason": f"{len(questions)} question region(s) from {role_note}"}


def crop_image_only_paper(
    pdf_path: str | Path,
    *,
    target_width: int = TARGET_WIDTH,
    langs: Optional[str] = None,
    page_limit: int = 0,
    paper_code: str = "",
    spool_dir: Optional[Path] = None,
) -> List[Any]:
    """Crop an image-only paper into ``CroppedQuestion`` objects.

    Returns [] when the engine cannot help (no OCR runtime, no regions). An empty
    return is NOT success: callers keep their own failure path and name the paper
    there. Assembly uses the locked gold assembler; saving is the caller's job.
    """
    ok, why = ocr_available()
    if not ok:
        print(f"    [ocr] unavailable: {why}")
        return []
    from core.cropping_engine import CroppedQuestion   # the pipeline's crop contract
    from core.multipage_optimizer import assemble_multipage_question

    analysis = analyze(pdf_path, langs=langs, page_limit=page_limit, target_width=target_width)
    questions = analysis["questions"]
    if not questions:
        global _LAST_REASON
        _LAST_REASON = analysis.get("reason", "")
        print(f"    [ocr] boundary analysis produced no questions ({analysis['reason']})")
        return []
    _LAST_REASON = ""
    crops: List[Any] = []
    spooled = 0
    doc = fitz.open(str(pdf_path))
    for q in questions:
        slices = []
        for page_idx, y0, y1 in q["segments"]:
            # Re-render on demand: one page raster live at a time, instead of all
            # twenty (the difference between ~25MB and ~450MB of peak).
            page_img = _render_page(doc[page_idx], target_width)
            slices.append(page_img.crop((0, max(0, int(y0)), page_img.width,
                                         min(page_img.height, int(y1)))))
            del page_img
        assembled = assemble_multipage_question(slices, target_width=target_width) \
            if slices else None
        if assembled is None:
            continue
        reasons = sorted(q["reasons"])
        if len(q["pages"]) > 1:
            reasons.append(f"OCR_MULTIPAGE_JOIN({len(q['pages'])} pages)")
        if page_limit and analysis["page_count"] < _pdf_page_count(pdf_path):
            reasons.append("OCR_PAGE_LIMIT")
        text = "\n".join(t for t in q["texts"] if t)
        crop = CroppedQuestion(
            question_number=f"Q{q['number']}",
            number_int=int(q["number"]),
            paper_code=paper_code,
            images=slices,
            assembled_image=assembled,
            text=text,
            marks=0,
            pages=list(dict.fromkeys(q["pages"])),
            needs_review=bool(reasons),
            qc_reasons=reasons,
        )
        if spool_dir is not None:
            # Park the pixels immediately (PNG is pixel-exact, so the WebP written
            # at save time is unchanged) and drop every raster this crop holds. The
            # caller's _unspool/_release loop then behaves exactly as it does for
            # the locked vector path. Without this, seven assembled crops of a real
            # paper - one of them 2280x16351 - are alive at once (~400MB+).
            try:
                path = Path(spool_dir) / f"ocr_{int(q['number']):03d}.png"
                assembled.save(path, format="PNG")
                crop._spool_png = str(path)
                crop.assembled_image = None
                crop.images = []
                spooled += 1
            except Exception as exc:            # spooling is an optimisation, never a gate
                print(f"    [ocr] spool failed for Q{q['number']} ({exc}); keeping it in memory")
        crops.append(crop)
        del assembled, slices
    for note in analysis.get("notes") or []:
        print(f"    [ocr] note: {note}")
    if spooled:
        print(f"    [ocr] spooled {spooled} crop payload(s) -> {Path(spool_dir).name}/ (PNG pixel-exact)")
    doc.close()
    if crops:
        clean = sum(1 for c in crops if not c.needs_review)
        print(f"    [ocr] boundary engine: {len(crops)} question(s) from "
              f"{analysis['page_count']} image-only page(s); {clean} clean, "
              f"{len(crops) - clean} flagged for review "
              f"(langs={analysis['langs']})")
    return crops


#: Verdict of the most recent ``crop_image_only_paper`` call, for callers that
#: need to report WHY an image-only paper produced nothing (S2's failure line).
_LAST_REASON = ""


def last_reason() -> str:
    return _LAST_REASON


def _pdf_page_count(pdf_path: str | Path) -> int:
    try:
        with fitz.open(pdf_path) as doc:
            return len(doc)
    except Exception:
        return 0
