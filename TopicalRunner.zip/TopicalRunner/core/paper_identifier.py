"""
Paper Identifier - Universal component
Identifies paper metadata from filename and header.
Now supports IGCSE + A-Level levels.
Supports BOTH naming conventions:
- Standard: 9701_m26_qp_22.pdf , 0620_m26_qp_42.pdf
- Real-world 2026: 9701 Chemistry March 2026 Question Paper 12.pdf,
               9706 Accounting March 2026 Question Paper 12.pdf,
               9701 Chemistry March 2026 Mark Scheme 12.pdf (if present)

Level inference:
- 05xx, 06xx -> IGCSE
- 97xx -> A-Level
"""

import re
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# Pattern 1: Standard short format: 9701_m26_qp_22, 0620_s23_ms_42, 9701_m26_er_22
# Examiner Reports are compilation documents and commonly have no component
# suffix (for example, 9709_s22_er.pdf).  Detect this definitive ``_er`` file
# type before the component-paper pattern below so it can never be treated as
# a QP or mark scheme.
# Extended season tokens (final-upgrade Issue 7, 2026-08-10, approved):
# single letters PLUS the compound/full-word forms found in real-world
# filenames (m-j, summer, spring, specimen, ...). Longest-first alternation
# so 'm' never eats the head of 'mj' or 'march'.
_SEASON_TOKEN = (
    r'(?:february[_-]?march|feb[_-]?mar|may[_-]?june|october[_-]?november'
    r'|specimen|spec|summer|winter|spring|march|may|june'
    r'|m_j|m-j|o_n|o-n|f_m|f-m|mj|on|fm|sp|[msw])'
)
# Normalise any extended token onto the canonical single letter.
_SEASON_TOKEN_NORM = {
    'mj': 's', 'summer': 's', 'may': 's', 'june': 's',
    'may-june': 's', 'may_june': 's',
    'on': 'w', 'o_n': 'w', 'o-n': 'w', 'winter': 'w',
    'october-november': 'w', 'october_november': 'w',
    'fm': 'm', 'f_m': 'm', 'f-m': 'm', 'spring': 'm', 'march': 'm',
    'february-march': 'm', 'february_march': 'm',
    'feb-mar': 'm', 'feb_mar': 'm', 'sp': 'sp', 'spec': 'sp', 'specimen': 'sp',
}

def _norm_season_letter(token) -> str:
    """Map a (possibly extended) season token to the canonical letter."""
    if not token:
        return 'm'
    t = str(token).lower()
    if t in _SEASON_TOKEN_NORM:
        return _SEASON_TOKEN_NORM[t]
    return t if t in ('m', 's', 'w', 'f', 'j', 'n', 'sp') else 'm'

# A18 (2026-09-22): Cambridge specimen naming as published (pastpapers.co / papacambridge
# "Syllabus & Specimen" folders): 0620_y23_sp_2.pdf / 0620_y23_sm_2.pdf / 0620_y23_si_2.pdf —
# "y23" = the syllabus for examination from 2023, sp/sm/si = specimen paper / specimen mark
# scheme / specimen insert, then the component. The CAIE grammar rejected these outright, so
# the files fell through to the board adapters and a Cambridge specimen pair was identified
# as "AQA-0620-02" (board_path, rendered 0, sm -> REVIEW_REQUIRED) on every batch pass.
SPECIMEN_PATTERN = re.compile(
    r'^(?P<code>\d{4})[_-]y(?P<year>\d{2})[_-](?P<type>sp|sm|si)(?:[_-]?(?P<variant>\d{1,2}))?$',
    re.IGNORECASE
)
_SPECIMEN_TYPE = {"sp": "qp", "sm": "ms", "si": "insert"}

EXAMINER_REPORT_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')?[_-]?(?P<year>\d{2})[_-]?(?P<type>er)(?:[_-]?(?P<variant>\d{1,2}))?$',
    re.IGNORECASE
)

# Issue 7 additive patterns: year-first ("9701_2024_s_er.pdf") and
# type-first ("9701_er_s24.pdf") real-world ER arrangements.
EXAMINER_REPORT_YEAR_FIRST_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<year_full>20\d{2})[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')[_-]?(?P<type>er)(?:[_-]?(?P<variant>\d{1,2}))?$',
    re.IGNORECASE
)
EXAMINER_REPORT_TYPE_FIRST_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<type>er)[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')(?P<year>\d{2})$',
    re.IGNORECASE
)

PAPER_PATTERN = re.compile(
    r'(?P<code>\d{4})[_-]?(?P<season_letter>' + _SEASON_TOKEN + r')?[_-]?(?P<year>\d{2})[_-]?(?P<type>qp|ms|er|ir|gt|in|ci|sf|insert)[_-]?(?P<variant>\d{1,2})?',
    re.IGNORECASE
)

# Pattern 2: Real-world long format: "9701 Chemistry March 2026 Question Paper 12.pdf"
# Also handles: "9706 Accounting March 2026 Insert 32.pdf", "9700 Biology March 2026 Confidential Instructions 33.pdf", "9701 Chemistry March 2026 Examiner Report 22.pdf"
LONG_PATTERN = re.compile(
    r'(?P<code>\d{4})'                     # 9701
    r'[^0-9]*?'                            # any non-digit between code and month
    r'(?P<month>January|February(?:[-_ ]?March)?|March|April|May(?:[-_ ]?June)?|June|July|August|September|October(?:[-_ ]?November)?|November|December|Jan|Feb(?:[-_ ]?Mar)?|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov)'  # Month/session
    r'[^A-Za-z0-9]*?(?P<year_full>\d{4})'             # 2026
    r'[^A-Za-z]*?'                         # separator
    r'(?P<type_long>Question(?:[-_ ]+Paper)|Mark(?:[-_ ]+Scheme)|Insert(?:[-_ ]+Booklet)?|Source(?:[-_ ]+Booklet)?|Sourcebooklet|Resource(?:[-_ ]+Booklet)?|Stimulus(?:[-_ ]+Booklet)?|Confidential(?:[-_ ]+Instructions)|Supporting(?:[-_ ]+File)|Examiner(?:[-_ ]+Report)|Principal(?:[-_ ]+Examiner[-_ ]+Report)|qp|ms|er|ci|ir|in|sf|Paper)'  # Type
    r'\s*(?P<variant>\d{1,2})?',           # Variant e.g., 12, 22, 42
    re.IGNORECASE
)

# Month to season letter mapping
MONTH_TO_SEASON = {
    'january': 'm', 'jan': 'm',
    'february': 'm', 'february march': 'm', 'feb-march': 'm', 'feb_march': 'm', 'feb': 'm', 'feb mar': 'm', 'feb-mar': 'm',
    'march': 'm', 'mar': 'm',
    'april': 'm',  # rare, treat as spring
    'may': 's', 'may june': 's', 'may-june': 's', 'may_june': 's',
    'june': 's', 'jun': 's',
    'july': 's', 'jul': 's',
    'august': 's', 'aug': 's',
    'september': 's', 'sep': 's',
    'october': 'w', 'october november': 'w', 'october-november': 'w', 'october_november': 'w', 'oct': 'w',
    'november': 'w', 'nov': 'w',
    'december': 'w', 'dec': 'w',
}

# ---------------------------------------------------------------------------
# Loose fallback (non-standard naming, 2026-08-15, maintainer-directed).
# Some real-world files do not follow the canonical
# {code}_{season}{year}_{type}_{component} order yet still carry the syllabus
# code and an unambiguous type marker (qp / ms / er / gt / ir / in / ci /
# insert / ...).  The loose matcher extracts the FIRST 4-digit code and the
# FIRST type marker wherever they appear; season/year are recovered from
# month/season/year tokens when present, else from the PDF cover text
# (cover fallback).  The component (variant) is optional everywhere.
# ---------------------------------------------------------------------------

# Long-form type phrases, most specific first (matched before the short
# tokens so 'insert' / 'confidential instructions' can never be eaten by the
# bare 'in' token, and one-word compounds like 'questionpaper' resolve).
_LOOSE_TYPE_PHRASES = [
    ("confidential_instructions", "ci"),
    ("confidential instructions", "ci"),
    ("supporting files", "sf"),
    ("supporting file", "sf"),
    ("questionpaper", "qp"),
    ("question_paper", "qp"),
    ("question paper", "qp"),
    ("markscheme", "ms"),
    ("mark_scheme", "ms"),
    ("marking scheme", "ms"),
    ("mark scheme", "ms"),
    ("principal examiner report", "er"),
    ("examiner_report", "er"),
    ("examinerreport", "er"),
    ("examiner report", "er"),
    ("grade thresholds", "gt"),
    ("grade threshold", "gt"),
    ("source booklet", "insert"),
    ("sourcebooklet", "insert"),
    ("resource booklet", "insert"),
    ("stimulus booklet", "insert"),
    ("insert booklet", "insert"),
    ("case study booklet", "insert"),
    ("insert", "insert"),
]

# Short type tokens.  Letter-boundary aware so 'er' inside 'paper'/'summer',
# 'in' inside 'instructions', 'ms' inside 'forms', etc. never match, while
# digit-adjacent forms like '9701gt' still do.  'er'/'in' are the riskiest
# and are therefore tried LAST.
_LOOSE_TYPE_TOKENS = [
    ("qp", "qp"), ("ms", "ms"), ("gt", "gt"),
    ("ir", "ir"), ("ci", "ci"), ("sf", "sf"),
    ("er", "er"), ("in", "in"),
]
_INSERT_MARKER_RE = re.compile(
    r"(?<![a-z])(?:insert(?:[ _-]+booklet)?|source[ _-]*booklet|"
    r"sourcebooklet|resource[ _-]*booklet|stimulus[ _-]*booklet|"
    r"case[ _-]*study[ _-]*booklet|in|ir|ci|sf)(?![a-z])",
    re.IGNORECASE,
)


def _detect_loose_type(name_lower: str):
    """Return the paper-type code detected anywhere in a non-standard name,
    or None when no unambiguous marker is present."""
    for phrase, ptype in _LOOSE_TYPE_PHRASES:
        if phrase in name_lower:
            return ptype
    # Insert-sidecar markers take precedence over a preceding ``qp`` token in
    # suffix names such as ``9706_s25_qp_12_in.pdf``.
    if _INSERT_MARKER_RE.search(name_lower):
        return "insert"
    for token, ptype in _LOOSE_TYPE_TOKENS:
        if re.search(r'(?<![a-z])' + re.escape(token) + r'(?![a-z])', name_lower):
            return ptype
    # bare "paper N" / "component N" (no "question"/"mark" qualifier) implies a
    # question paper — the only Cambridge document type commonly named "paper"
    # alone with a number (e.g. "chemistry 9701 paper 4.pdf").
    if re.search(r'(?<![a-z])paper\s*\d', name_lower):
        return "qp"
    return None


def _loose_season_year(name_lower: str):
    """Best-effort (season_letter, year_short) from arbitrary text.
    Season comes from month names / season words / a season-letter+year
    token (``s24``); year comes ONLY from a season-letter+2-digit token or
    a 4-digit ``20xx`` — a bare 2-digit number is never treated as a year
    (it is far more likely a component).  Either may be None."""
    season = None
    for month, letter in MONTH_TO_SEASON.items():
        if month in name_lower:
            season = letter
            break
    if season is None:
        for tok, letter in (("summer", "s"), ("winter", "w"),
                            ("spring", "m"), ("specimen", "sp")):
            if tok in name_lower:
                season = letter
                break
    year = None
    m_sy = re.search(r'(?<![a-z])[swm](\d{2})(?!\d)', name_lower)
    if m_sy:
        season = season or m_sy.group(0)[0]
        year = m_sy.group(1)
    m_yr = re.search(r'(?<!\d)(20\d{2})(?!\d)', name_lower)
    if m_yr:
        year = year or m_yr.group(1)[2:]
    return season, year


def _loose_variant(name_lower: str, ptype: str, year_short):
    """Recover the component (variant) from a non-standard name.
    Priority: digits attached to the type marker (space/underscore/dash
    separated), then 'paper/component N', then the trailing 1-2 digit
    number.  Never returns the year."""
    if ptype and ptype != "insert":
        for pat in (re.escape(ptype) + r'[\s_-]?(\d{1,2})(?!\d)',
                    r'(\d{1,2})[\s_-]?' + re.escape(ptype)):
            m = re.search(pat, name_lower)
            if m and m.group(1) != year_short:
                return m.group(1)
    m = re.search(r'\b(?:paper|component)\s*(\d{1,2})\b', name_lower)
    if m and m.group(1) != year_short:
        return m.group(1)
    m = re.search(r'(?<!\d)(\d{1,2})(?!\d)[^0-9]*$', name_lower)
    if m and m.group(1) != year_short:
        return m.group(1)
    return ""


def _cover_season_year(pdf_path):
    """Recover (season_letter, year_short) from the PDF first-page text.
    Lazy fitz import (heavy) — returns (None, None) when unavailable."""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        try:
            import pymupdf as fitz
        except ImportError:
            return None, None
    try:
        doc = fitz.open(str(pdf_path))
        if len(doc) == 0:
            doc.close()
            return None, None
        text = (doc[0].get_text("text") or "").lower()
        doc.close()
    except Exception:
        return None, None
    season = None
    if re.search(r'\b(?:february|march|feb/mar|feb|mar)\b', text):
        season = "m"
    elif re.search(r'\b(?:october|november|oct/nov|oct|nov)\b', text):
        season = "w"
    elif re.search(r'\b(?:may|june|july|august|sep)\b', text):
        season = "s"
    elif re.search(r'\bspecimen\b', text):
        season = "sp"
    year = None
    m = re.search(r'\b(20\d{2})\b', text)
    if m:
        year = m.group(1)[2:]
    return season, year


SEASON_MAP = {
    'm': 'Spring',  # Feb/March
    's': 'Summer',  # May/June
    'w': 'Winter',  # Oct/Nov
    'f': 'Spring',
    'j': 'Summer',
    'n': 'Winter',
    'sp': 'Specimen',  # extended tokens (final-upgrade Issue 7)
}

LEVEL_BY_PREFIX = {
    '04': 'IGCSE',
    '05': 'IGCSE',
    '06': 'IGCSE',
    # 09xx = IGCSE 9-1 graded codes (0983 CS, 0971 Chemistry, ...)
    '09': 'IGCSE',
    '96': 'A-Level',
    '97': 'A-Level',
    '92': 'A-Level',
    '94': 'A-Level',   # History 9489, Art & Design 9479, Drama 9482, Music 9483, ...
    '90': 'A-Level',   # Law 9084, English Language 9093, ...
    '86': 'A-Level',   # A-Level language syllabi (8682 French, 8686 Urdu, 8695 Lang&Lit, ...)
    '80': 'A-Level',   # AS-Level-only syllabi (8021 English General Paper, 8027/8028/8022 ...)
}

def _full_year_from_short(year_short: str | int) -> int:
    """Interpret Cambridge two-digit session years as modern exam years.

    ExamVoid's supported corpus is modern (2015 onward), so treating ``50``
    as 2050 keeps future sessions working instead of wrapping them to 1950.
    Four-digit years are returned unchanged.
    """
    value = str(year_short).strip()
    if len(value) == 4 and value.isdigit():
        return int(value)
    if value.isdigit():
        return 2000 + int(value)
    # RS-62: was `return 2024`. A non-numeric session token carries no year, and
    # returning a plausible one is exactly the silent fabrication §36 forbids.
    # Callers already guard this with try/except and record the field as
    # fabricated; raising makes the absence impossible to miss.
    raise ValueError(f"cannot derive a year from session token {year_short!r}")


def infer_level_from_code(syllabus_code: str) -> str:
    code = str(syllabus_code)
    for prefix, level in LEVEL_BY_PREFIX.items():
        if code.startswith(prefix):
            return level
    if code.startswith('9') and not code.startswith('09'):
        return 'A-Level'
    return 'IGCSE'


def _content_mcq_signal(pdf_path: Path) -> bool:
    """Detect an MCQ paper from its own title/instructions when a syllabus
    code is missing from the static registry.

    This is an identity/format check only; it does not alter any cropper.  The
    explicit paper-level title plus answer-sheet/options language avoids
    mistaking a structured paper that merely contains a multiple-choice
    sub-question for an MCQ component.
    """
    try:
        import fitz
    except Exception:
        try:
            import pymupdf as fitz
        except Exception:
            return False
    try:
        doc = fitz.open(str(pdf_path))
        text = ""
        for index, page in enumerate(doc):
            text += (page.get_text("text") or "") + "\n"
            if index >= 2:
                break
        doc.close()
    except Exception:
        return False
    low = re.sub(r"\s+", " ", text.lower())
    explicit_title = bool(re.search(
        r"\bpaper\s*[1-9]\s*(?:[-–—:]\s*)?multiple\s*[- ]?choice\b",
        low,
    )) or "multiple choice question paper" in low
    answer_sheet = "answer sheet" in low or "record your choice" in low
    options = bool(re.search(
        r"four possible answers.{0,180}\b[a-d]\b",
        low,
    )) or "a, b, c and d" in low
    return explicit_title and (answer_sheet or options)


# ---------------------------------------------------------------------------
# Overseer IGCSE-format spec (approved). Component map verbatim from the spec;
# validated against the real fixture corpus (0620_s16 / 9701_s15 / 0580_s15).
# ---------------------------------------------------------------------------
IGCSE_COMPONENT_MAP = {
    # Sciences 0610/0620/0625: Papers 1 AND 2 are MCQ (core / extended)
    "0610": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "MCQ", "22": "MCQ", "23": "MCQ",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED",
             "51": "PRACTICAL", "52": "PRACTICAL", "53": "PRACTICAL",
             "61": "ATP", "62": "ATP", "63": "ATP"},
    "0620": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "MCQ", "22": "MCQ", "23": "MCQ",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED",
             "51": "PRACTICAL", "52": "PRACTICAL", "53": "PRACTICAL",
             "61": "ATP", "62": "ATP", "63": "ATP"},
    "0625": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "MCQ", "22": "MCQ", "23": "MCQ",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED",
             "51": "PRACTICAL", "52": "PRACTICAL", "53": "PRACTICAL",
             "61": "ATP", "62": "ATP", "63": "ATP"},
    # Mathematics 0580 / Additional 0606: NO MCQ papers
    "0580": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED",
             "31": "STRUCTURED", "32": "STRUCTURED", "33": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED"},
    "0606": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    # Economics 0455: Paper 1 only is MCQ
    "0455": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    # Business / Accounting / CS / Geography: NO MCQ papers
    "0450": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0452": {"11": "MCQ", "12": "MCQ", "13": "MCQ",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0478": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0460": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED",
             "41": "STRUCTURED", "42": "STRUCTURED", "43": "STRUCTURED"},
    # History: essay / source-based
    "0470": {"11": "ESSAY", "12": "ESSAY", "13": "ESSAY",
             "21": "ESSAY", "22": "ESSAY", "23": "ESSAY",
             "41": "ESSAY", "42": "ESSAY", "43": "ESSAY"},
    # English Language
    "0500": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    "0522": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
    # Sociology
    "0495": {"11": "STRUCTURED", "12": "STRUCTURED", "13": "STRUCTURED",
             "21": "STRUCTURED", "22": "STRUCTURED", "23": "STRUCTURED"},
}

# Per-code {paper_number: format} DERIVED from IGCSE_COMPONENT_MAP (single
# source of truth).  Cambridge keeps adding variant digits (14, 15, 19, 24,
# 34, ...); a component's PAPER NUMBER (second-to-last digit) decides its
# format when the exact code is not enumerated, so those variants never
# silently default to STRUCTURED (e.g. 0620 "15" -> Paper 1 -> MCQ, "54" ->
# Paper 5 -> PRACTICAL, "64" -> Paper 6 -> ATP).
def _component_paper_number_local(component) -> int:
    """Paper number encoded in a Cambridge component code.

    Two distinct encodings exist and must not be conflated:

    1. **Paper+variant pair** (the overwhelmingly common case): a 2-digit code
       ``<paper><variant>`` such as ``22`` -> Paper 2, ``31`` -> Paper 3. The
       paper number is the SECOND-TO-LAST digit.

    2. **Zero-padded paper number**: some syllabuses publish papers as
       ``01``/``02``/``03``/``04`` with a single mark scheme each and NO variant
       digit. Verified example: 9686 (Urdu) ships ``9686_s20_qp_02/03/04``.
       Here ``04`` means Paper 4, and the old ``digits[-2]`` rule returned
       ``0`` — silently mapping every paper onto a non-existent Paper 0.

    The discriminator is the leading zero: a component whose digit string starts
    with ``0`` cannot be a paper+variant pair, because no Cambridge paper is
    numbered 0. Every other code keeps its historical interpretation, so the 18
    components enumerated in IGCSE_COMPONENT_MAP (11..63, none zero-prefixed)
    resolve exactly as before — see tests/test_component_paper_number.py.
    """
    digits = "".join(c for c in str(component) if c.isdigit())
    if not digits:
        return 0
    # Encoding 2: zero-padded paper number ("04" -> 4, not paper 0).
    if digits.startswith("0") and len(digits) >= 2:
        return int(digits)
    # Encoding 1: <paper><variant> ("22" -> 2).
    return int(digits[-2]) if len(digits) >= 2 else int(digits[0])


_PAPER_FORMAT_MAP = {}
for _code, _compmap in IGCSE_COMPONENT_MAP.items():
    _pm = {}
    for _comp, _fmt in _compmap.items():
        _pn = _component_paper_number_local(_comp)
        _pm.setdefault(_pn, _fmt)
    _PAPER_FORMAT_MAP[_code] = _pm

# Expected question counts — ADVISORY ONLY (approved: never a gate).
# Evidence status recorded per entry:
#   40 MCQ: MEASURED from real MS answer grids (0620_s16_ms_21/22, 9701_s15_ms_12
#           all parse exactly 40 rows).
#   30 (0455 MCQ): Cambridge-published fixed structure; no fixture this round.
#   Structured/essay/practical counts: VARY BY SESSION — the spec's table
#   claimed e.g. 0580=10 but the real 0580_s15_qp_22 shows ~21-24 question
#   anchors. Honest value: None (not asserted).
# (IGCSE_QUESTION_COUNT retired — see mcq_registry receipt D4)

# Unified-MCQ round: _ALEVEL_MCQ_P1_SYLLABI / ALEVEL_MCQ_QUESTION_COUNT /
# IGCSE_QUESTION_COUNT are RETIRED — the registry is the single authority
# (RULE 1). Measured-count provenance lives in core/mcq_registry.py (D4).


def resolve_paper_format(syllabus_code: str, variant: str, year=None) -> str:
    """Unified-MCQ round (approved Q1=adopt_hybrid): mcq_registry.is_mcq is
    the SINGLE MCQ authority (RULE 1). IGCSE_COMPONENT_MAP is now consulted
    ONLY for non-MCQ formats (STRUCTURED/PRACTICAL/ATP/ESSAY — truthful
    folder names). The legacy A-Level variant-first-digit rule is RETIRED:
    identical for 9701/9702/9700/9708 P1; deltas 9608/9696 only, both inert
    (no configs/fixtures) — receipts in core/mcq_registry.py.

    Cambridge keeps adding variant digits (14, 15, 19, 24, 34, ...): a
    component is resolved by its PAPER NUMBER (second-to-last digit) when the
    exact code is not enumerated, so those variants never silently default to
    the wrong format."""
    from .mcq_registry import is_mcq
    code = str(syllabus_code or "")
    var = str(variant or "")
    if is_mcq(code, var, year):
        return "MCQ"
    if year is not None and is_mcq(code, var):
        # component became MCQ in a later syllabus (mcq_registry.MCQ_SINCE_YEAR);
        # this session predates it -> structured written paper
        return "STRUCTURED"
    cmap = IGCSE_COMPONENT_MAP.get(code)
    if cmap is not None:
        exact = cmap.get(var)
        if exact is not None:
            return exact
        # paper-number fallback for Cambridge-added variant digits
        pn = _component_paper_number_local(var)
        pf = _PAPER_FORMAT_MAP.get(code, {}).get(pn)
        if pf is not None:
            return pf
        return "STRUCTURED"
    return "STRUCTURED"


def expected_question_count(syllabus_code: str, paper_format: str,
                            variant: str = ""):
    """Advisory oracle. None = not asserted (never a gate).
    Unified-MCQ round: MCQ counts come from mcq_registry (RULE 1)."""
    if paper_format == "MCQ":
        from .mcq_registry import get_expected_question_count
        return get_expected_question_count(str(syllabus_code or ""),
                                           str(variant or ""))
    return None

@dataclass
class PaperInfo:
    file_path: Path
    syllabus_code: str
    year: str  # "2026"
    year_short: str  # "26"
    season: str  # "Spring", "Summer", "Winter"
    season_letter: str  # "m", "s", "w"
    paper_type: str  # "qp" or "ms" or "insert"
    variant: str  # "22" or "42"
    full_code: str  # "9701_m26_qp_22" or "0620_m26_qp_42"
    level: str  # "IGCSE" or "A-Level"
    subject_guess: Optional[str] = None
    original_name: str = ""  # Store original filename for debugging
    # Overseer IGCSE-format spec: filled by __post_init__ (covers every
    # construction site: standard / long-format / year-first / ER).
    paper_format: Optional[str] = None       # MCQ / STRUCTURED / ESSAY / PRACTICAL / ATP
    is_mcq: Optional[bool] = None
    expected_question_count: Optional[int] = None  # advisory; None = not asserted
    # --- Identity provenance (RS-62 / Universal Engine Milestone 3) ----------
    # This module resolves identity from the FILENAME plus a cover-text fallback.
    # These fields record how much of the result is actually evidenced, so a
    # downstream consumer can tell a parsed fact from an invented one. The
    # authoritative multi-source fusion (filename vs PDF text vs OCR vs board
    # signature, with IDENTITY_CONFLICT -> REVIEW_REQUIRED) lives in
    # universal/identity/ and never mutates this class.
    #
    # Defaults are chosen so every existing construction site keeps working
    # unchanged and reports the honest value for its path: a filename that parsed
    # cleanly really was resolved from the filename.
    identity_status: str = "FILENAME_RESOLVED"   # FILENAME_RESOLVED | ADAPTER_RESOLVED | REVIEW_REQUIRED
    identity_sources: List[str] = field(default_factory=lambda: ["filename"])
    # Non-CAIE boards only (A3/A4, 2026-09-21). None means "this module's own
    # CAIE filename grammar parsed it". Set by the adapter fallback below, and
    # read by core.subject_detector so another board's paper can never be
    # claimed by the CAIE subject/level heuristics.
    board: Optional[str] = None
    identity_evidence: Dict[str, Any] = field(default_factory=dict)
    # Fields whose value was NOT evidenced by filename or document content and
    # was filled from a hardcoded default. Never empty-by-accident: the loose
    # fallback path records each one it invents.
    fabricated_fields: List[str] = field(default_factory=list)

    def __post_init__(self):
        if self.paper_type == "er":
            self.paper_format = "ER"
            self.is_mcq = False
            return
        fmt = resolve_paper_format(self.syllabus_code, self.variant, self.year)
        # Registry first; content fallback catches compatible subjects whose
        # paper-format table was not yet enumerated (for example Accounting
        # files from a new syllabus edition). This reads only the PDF text
        # layer and never touches cropping geometry.
        if fmt != "MCQ" and self.paper_type in {"qp", "ms"}:
            if _content_mcq_signal(self.file_path):
                fmt = "MCQ"
        self.paper_format = fmt
        self.is_mcq = (fmt == "MCQ")
        self.expected_question_count = expected_question_count(
            self.syllabus_code, fmt, self.variant)

    def to_dict(self):
        return {
            "syllabus_code": self.syllabus_code,
            "year": self.year,
            "season": self.season,
            "type": self.paper_type,
            "variant": self.variant,
            "paper_format": self.paper_format,
            "is_mcq": self.is_mcq,
            "expected_question_count": self.expected_question_count,
            "full_code": self.full_code,
            "level": self.level,
            "original_name": self.original_name,
            "identity_status": self.identity_status,
            "identity_sources": list(self.identity_sources),
            "fabricated_fields": list(self.fabricated_fields),
        }

# --------------------------------------------------------------------------- #
# Cover corroboration (2026-09-21)
# --------------------------------------------------------------------------- #
# A CAIE identity used to rest on the filename alone. For an image-only paper that
# is the ONLY evidence in existence - there is no text layer to check - so the
# identity was unfalsifiable. This pass reads the document's own cover: the printed
# text layer when there is one (a few ms) and OCR when there is not, and asks the
# cover to corroborate (or refute) the filename. Nothing is ever copied FROM the
# filename onto the cover's authority: the filename identity stands unless the
# cover refutes it, in which case the document goes to REVIEW_REQUIRED and the
# conflict is recorded. A cover that cannot be read records why, out loud.
_COVER_MIN_TEXT_LAYER_CHARS = 40
_COVER_OCR_MAX_PAGES = 1          # the cover carries code + session line
_COVER_OCR_DPI = 150              # measured: reads "9686/04 ... May/June 2026" on the
                                  # real image-only 9686 Urdu paper
_COVER_CACHE: Dict[Any, Any] = {}  # (path, mtime_ns, size) -> (text, source); OCR is
                                   # seconds per page, so memoise across a run

# Mon th tokens that belong to each filename season letter. Used ONLY to decide
# whether a cover refutes a filename - never to write a season.
_SEASON_TOKENS = {
    "m": ("february", "feb", "march", "mar", "feb/march", "feb/mar", "spring"),
    "s": ("may", "june", "jun", "july", "jul", "may/june", "may/jun", "summer"),
    "w": ("october", "oct", "november", "nov", "oct/nov", "winter"),
    "sp": ("specimen", "spec/"),
    "f": ("february", "feb", "march", "mar", "spring"),
    "j": ("may", "june", "jun", "summer"),
    "n": ("october", "oct", "november", "nov", "winter"),
}


def _read_cover_text(pdf_path, *, allow_ocr: bool = True, ocr_max_pages: int = _COVER_OCR_MAX_PAGES,
                     ocr_dpi: int = _COVER_OCR_DPI):
    """First-page text of a document: the printed layer, else OCR.

    Returns ``(text, source)`` with source in ``{"text_layer", "ocr", "none"}``.
    OCR is only attempted when the printed text layer is unusable, so ordinary
    papers pay nothing for this.
    """
    path = Path(pdf_path)
    try:
        key = (str(path.resolve()), path.stat().st_mtime_ns, path.stat().st_size)
    except OSError:
        key = None
    if key is not None and key in _COVER_CACHE:
        return _COVER_CACHE[key]

    text = ""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        try:
            import pymupdf as fitz
        except ImportError:
            fitz = None
    if fitz is not None:
        try:
            with fitz.open(str(path)) as doc:
                if len(doc):
                    text = doc[0].get_text("text") or ""
        except Exception:
            text = ""

    result = None
    if len(text.strip()) >= _COVER_MIN_TEXT_LAYER_CHARS:
        result = (text, "text_layer")
    else:
        ocr_reason = "OCR not attempted"
        if allow_ocr:
            try:
                from adapters.ocr_fallback import build_ocr_context
                res = build_ocr_context(path, max_pages=ocr_max_pages, dpi=ocr_dpi)
                ocr_reason = res.reason
                if res.available and res.ctx and (res.ctx.first_page_text or "").strip():
                    result = (res.ctx.first_page_text, "ocr")
            except Exception as exc:                      # noqa: BLE001
                ocr_reason = f"OCR failed: {type(exc).__name__}: {exc}"
        if result is None:
            result = (text, "none")
            _COVER_CACHE.setdefault(("__reason__", str(path)), ocr_reason)
    if key is not None:
        _COVER_CACHE[key] = result
    return result


def cover_ocr_reason(pdf_path) -> str:
    """Why the cover could not be read (for the identity record). Advisory."""
    _read_cover_text(pdf_path)
    return str(_COVER_CACHE.get(("__reason__", str(Path(pdf_path))), "cover not readable"))


def _season_year_from_text(text: str):
    """(season_letter, year_short) from arbitrary cover text. Either may be None."""
    low = (text or "").lower()
    season = None
    for month, letter in MONTH_TO_SEASON.items():
        if month in low:
            season = letter
            break
    if season is None:
        for tok, letter in (("summer", "s"), ("winter", "w"), ("spring", "m"),
                            ("specimen", "sp")):
            if tok in low:
                season = letter
                break
    year = None
    m = re.search(r'\b(20\d{2})\b', low)
    if m:
        year = m.group(1)[2:]
    return season, year


def _corroborate_identity_from_cover(info: "PaperInfo", path: Path) -> "PaperInfo":
    """Let the document's own cover corroborate or refute a filename identity."""
    evidence = dict(info.identity_evidence or {})
    if "ocr" in (info.identity_sources or []):
        # The parse already read the cover through OCR (loose-naming path).
        evidence.setdefault("cover_corroboration", "read_during_parse")
        info.identity_evidence = evidence
        return info

    text, source = _read_cover_text(path)
    evidence["cover_source"] = source
    if source == "none":
        evidence["cover_corroboration"] = f"unavailable: {cover_ocr_reason(path)}"
        info.identity_evidence = evidence
        return info

    low = (text or "").lower()
    code = str(info.syllabus_code or "")
    code_visible = bool(code) and bool(re.search(rf"(?<!\d){re.escape(code)}(?!\d)", low))
    season_letter = str(info.season_letter or "")
    def _visible(tok: str) -> bool:
        # Word-bounded: a bare substring match made "mar" hit "mark" and "may" hit
        # "May" inside unrelated words, which then never refuted anything.
        return bool(re.search(rf"\b{re.escape(tok)}\b", low))

    seen = {letter for letter, toks in _SEASON_TOKENS.items()
            if any(_visible(tok) for tok in toks)}

    if source == "ocr":
        info.identity_sources = list(info.identity_sources or []) + ["ocr"]
    evidence["cover_code_visible"] = code_visible
    evidence["cover_seasons_seen"] = sorted(seen)

    conflicts = []
    # A cover that names a DIFFERENT real syllabus is a hard refutation: the
    # filename is the only thing claiming this code, and only a known code counts
    # (so a barcode digit run or a stray number can never refute anything).
    try:
        from .config_loader import KNOWN_CODE_MAP as _codes
        known = set(_codes)
    except Exception:                                     # noqa: BLE001
        known = set()
    cover_codes = {tok for tok in re.findall(r"(?<!\d)(\d{4})(?!\d)", low)
                   if tok in known}
    if code and cover_codes:
        evidence["cover_syllabus_codes"] = sorted(cover_codes)
        if code not in cover_codes:
            conflicts.append(f"syllabus: filename {code} vs cover {sorted(cover_codes)}")
    if code_visible is False and code:
        # Advisory only: covers print the code in different places, and some
        # barcodes are raster-only, so absence is weak evidence.
        evidence["cover_corroboration"] = "code_not_visible"
    if season_letter and seen and season_letter not in seen:
        conflicts.append(f"session: filename {season_letter!r} vs cover {sorted(seen)}")
    if code_visible and season_letter in seen:
        evidence["cover_corroboration"] = "match"
    elif conflicts:
        evidence["cover_corroboration"] = "conflict - " + "; ".join(conflicts)
        info.identity_status = "REVIEW_REQUIRED"
        info.fabricated_fields = list(info.fabricated_fields or [])
    elif "cover_corroboration" not in evidence:
        evidence["cover_corroboration"] = "code_visible" if code_visible else "inconclusive"
    info.identity_evidence = evidence
    return info


def _parse_paper_filename_body(file_path: str | Path) -> Optional[PaperInfo]:
    """Parse paper info from filename including level - supports both short and long formats"""
    path = Path(file_path)
    name = path.stem
    name_lower = name.lower()
    original_name = path.name

    # Examiner Report priority: a filename ending in _er (with an optional
    # component) is always an ER.  It is intentionally parsed before QP/MS
    # patterns; the suffix identifies only the file type, while normal ER
    # matching later verifies its applicable paper/component.
    er_match = EXAMINER_REPORT_PATTERN.search(name_lower)
    er_code = er_season_raw = er_year_short = er_variant = None
    if er_match:
        er_code = er_match.group('code')
        er_season_raw = er_match.group('season_letter')
        er_year_short = er_match.group('year')
        er_variant = er_match.group('variant') or ""
    else:
        # Additive arrangements (final-upgrade Issue 7): year-first then type-first
        my = EXAMINER_REPORT_YEAR_FIRST_PATTERN.search(name_lower)
        if my:
            er_code = my.group('code')
            er_season_raw = my.group('season_letter')
            er_year_short = my.group('year_full')[-2:]
            er_variant = my.group('variant') or ""
        else:
            mt = EXAMINER_REPORT_TYPE_FIRST_PATTERN.search(name_lower)
            if mt:
                er_code = mt.group('code')
                er_season_raw = mt.group('season_letter')
                er_year_short = mt.group('year')
                er_variant = ""
    if er_code is not None:
        code = er_code
        season_letter = _norm_season_letter(er_season_raw)
        year_short = er_year_short
        variant = er_variant
        try:
            full_year = _full_year_from_short(year_short)
        except Exception:
            return None   # RS-62: unidentifiable session, never a defaulted year
        from .config_loader import KNOWN_CODE_MAP
        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=SEASON_MAP.get(season_letter, 'Summer'),
            season_letter=season_letter,
            paper_type="er",
            variant=variant,
            full_code=f"{code}_{season_letter}{year_short}_er" + (f"_{variant}" if variant else ""),
            level=infer_level_from_code(code),
            subject_guess=KNOWN_CODE_MAP.get(code),
            original_name=original_name,
        )

    # A18: Cambridge specimen files (see SPECIMEN_PATTERN). Season token 'sp' and the
    # 'Specimen' season name already exist in this module; only the y-prefixed year form
    # and the sp/sm/si type letters were missing. Same PaperInfo shape as Pattern 1.
    sp_match = SPECIMEN_PATTERN.match(name_lower)
    if sp_match:
        code = sp_match.group('code')
        year_short = sp_match.group('year')
        ptype = _SPECIMEN_TYPE[sp_match.group('type').lower()]
        variant = sp_match.group('variant') or ""
        try:
            full_year = _full_year_from_short(year_short)
        except Exception:
            return None
        from .config_loader import KNOWN_CODE_MAP
        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=SEASON_MAP['sp'],
            season_letter='sp',
            paper_type=ptype,
            variant=variant,
            full_code=f"{code}_sp{year_short}_{ptype}" + (f"_{variant}" if variant else ""),
            level=infer_level_from_code(code),
            subject_guess=KNOWN_CODE_MAP.get(code),
            original_name=original_name,
        )

    # Try Pattern 1 first (standard component papers)
    # If an insert marker appears anywhere in a non-long filename (including
    # suffix forms such as ``..._qp_12_insert.pdf``), skip the QP/MS pattern
    # and let the loose insert parser preserve the sidecar identity.
    m = None if _INSERT_MARKER_RE.search(name_lower) else PAPER_PATTERN.search(name_lower)
    if m:
        code = m.group('code')
        season_letter = _norm_season_letter(m.group('season_letter'))
        year_short = m.group('year')
        ptype = m.group('type').lower()
        variant = m.group('variant') or ""

        try:
            y_int = int(year_short)
            full_year = _full_year_from_short(year_short)
        except Exception:
            # RS-62: this branch used to call _full_year_from_short a second time
            # with the identical argument — a retry that could only ever repeat
            # the failure, and which previously fell through to a hardcoded 2024.
            # A session token with no digits carries no year, so the honest result
            # is "this filename is not identifiable" (None), which routes the file
            # to review rather than dating it inventively.
            return None

        season = SEASON_MAP.get(season_letter, 'Summer')
        full_code = f"{code}_{season_letter}{year_short}_{ptype}" + (f"_{variant}" if variant else "")
        level = infer_level_from_code(code)

        from .config_loader import KNOWN_CODE_MAP
        subject_guess = KNOWN_CODE_MAP.get(code)

        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=season,
            season_letter=season_letter,
            paper_type=ptype,
            variant=variant,
            full_code=full_code,
            level=level,
            subject_guess=subject_guess,
            original_name=original_name,
        )

    # Try Pattern 2: Long real-world format
    m2 = LONG_PATTERN.search(name)
    if m2:
        code = m2.group('code')
        month_raw = re.sub(r"[-_]+", " ", m2.group('month').lower())
        year_full_str = m2.group('year_full')
        type_long = re.sub(r"[-_]+", " ", m2.group('type_long').lower())
        is_variantless_doc = any(k in type_long for k in ("examiner", "principal", "report", "threshold", "gt"))
        variant = m2.group('variant') or ("" if is_variantless_doc else "12")  # default if missing

        # Map month to season letter
        season_letter = MONTH_TO_SEASON.get(month_raw, 'm')
        season = SEASON_MAP.get(season_letter, 'Spring')

        # Map type_long to qp/ms/sidecar.  The normalisation above lets
        # ``Question-Paper``, ``Question_Paper``, and short ``qp`` forms share
        # the same branch.
        if "question paper" in type_long or type_long == "qp":
            ptype = "qp"
        elif "mark scheme" in type_long or "marking scheme" in type_long or type_long == "ms":
            ptype = "ms"
        elif "examiner report" in type_long or "principal examiner" in type_long or type_long == "er":
            ptype = "er"
        elif any(token in type_long for token in ("insert", "source booklet", "sourcebooklet", "resource booklet", "stimulus booklet")) or type_long in {"in", "ir", "sf"}:
            ptype = "insert"
        elif "confidential" in type_long or type_long == "ci":
            ptype = "ci"
        elif "supporting" in type_long:
            ptype = "sf"
        else:
            ptype = "qp"

        try:
            full_year = int(year_full_str)
            year_short = f"{full_year % 100:02d}"
        except Exception as e:
            full_year = 2026
            year_short = "26"

        full_code = f"{code}_{season_letter}{year_short}_{ptype}" + (f"_{variant}" if variant else "")
        level = infer_level_from_code(code)

        from .config_loader import KNOWN_CODE_MAP
        subject_guess = KNOWN_CODE_MAP.get(code)

        return PaperInfo(
            file_path=path,
            syllabus_code=code,
            year=str(full_year),
            year_short=year_short,
            season=season,
            season_letter=season_letter,
            paper_type=ptype,
            variant=variant,
            full_code=full_code,
            level=level,
            subject_guess=subject_guess,
            original_name=original_name,
        )

    # Loose fallback: syllabus code + type marker in arbitrary arrangement
    # (non-standard naming).  Only fires when the canonical patterns above
    # all missed; requires BOTH a 4-digit code and a type marker, so random
    # PDFs (notes, scans, ...) still fail-closed to None.
    m_code = re.search(r'(?<![0-9])(\d{4})(?![0-9])', name_lower)
    if m_code:
        code = m_code.group(1)
        ptype = _detect_loose_type(name_lower)
        if ptype:
            # Mask the syllabus code out of the name before extracting
            # season/year/variant so its digits can never be misread as a
            # component or year (e.g. the trailing '01' of '9701_ms').
            extras = name_lower.replace(code, "XXXX")
            season_letter, year_short = _loose_season_year(extras)
            variant = _loose_variant(extras, ptype, year_short)
            # Recover session/year from the PDF cover text when the name
            # carried neither (maintainer-selected cover fallback).
            # RS-62: this path previously invented `season="s"` and `year="24"`
            # when neither the filename nor the cover text carried a session, which
            # silently dated unidentifiable papers as Summer 2024 (observed in
            # Milestone-1 testing on a real 2026 paper). The defaults are retained
            # ONLY so folder naming and manifest keys stay well-formed, and every
            # invented field is now recorded on the PaperInfo so the document is
            # routed to REVIEW_REQUIRED instead of entering the bank unnoticed.
            invented: List[str] = []
            sources: List[str] = ["filename"]
            if season_letter is None or year_short is None:
                c_season, c_year = _cover_season_year(path)
                if c_season or c_year:
                    sources.append("cover_text")
                if season_letter is None:
                    season_letter = c_season
                    if season_letter is None:
                        season_letter = "s"
                        invented.append("season")
                if year_short is None:
                    year_short = c_year
                    if year_short is None:
                        year_short = "24"
                        invented.append("year")
            try:
                y_int = int(year_short)
                full_year = _full_year_from_short(year_short)
            except Exception:
                full_year = 2024
                if "year" not in invented:
                    invented.append("year")
            season = SEASON_MAP.get(season_letter, 'Summer')
            full_code = f"{code}_{season_letter}{year_short}_{ptype}" + (f"_{variant}" if variant else "")
            from .config_loader import KNOWN_CODE_MAP
            return PaperInfo(
                file_path=path,
                syllabus_code=code,
                year=str(full_year),
                year_short=year_short,
                season=season,
                season_letter=season_letter,
                paper_type=ptype,
                variant=variant,
                full_code=full_code,
                level=infer_level_from_code(code),
                subject_guess=KNOWN_CODE_MAP.get(code),
                original_name=original_name,
                identity_status=("REVIEW_REQUIRED" if invented
                                 else "FILENAME_RESOLVED"),
                identity_sources=sources,
                identity_evidence={
                    "parse_path": "loose_filename_fallback",
                    "cover_text_consulted": "cover_text" in sources,
                },
                fabricated_fields=invented,
            )

    return None


#: (path, size, mtime) -> (board, evidence line) for the document-board check below. The check
#: runs at most once per report per process: an ER is asked once by identification and again by
#: the guarded pipeline's routing/verdict reader, which has its own cache for the same reason.
_CONTENT_BOARD_CACHE: dict = {}


def _adopt_content_board_for_examiner_reports(info: "PaperInfo", path: Path) -> "PaperInfo":
    """An examiner report says its own board; the CAIE filename grammar cannot.

    The grammar identifies a Cambridge paper by SHAPE (4-digit code + session + year + type) and
    leaves ``board`` unset, which every consumer reads as "CAIE". A report renamed into that shape
    therefore rode the Cambridge stages -- measured 2026-09-29: the AQA ER fixture copied to
    ``8462_s23_er.pdf`` was typed CAIE syllabus 8462 (a real Cambridge code) and the run failed at
    S1 with the report stuck in review.

    So the document is asked (``adapters.associations.identify_document`` -- the same authority the
    universal path uses) and a board it names is adopted only when the parse has none. An identity
    the adapter resolved is never overwritten, which is the rule the association merge already
    follows. Reports only: the QP/MS grammar is corroborated by the cover/season machinery, and
    re-boarding a genuine Cambridge question paper on a text heuristic is not worth the risk.
    """
    if str(getattr(info, "paper_type", "") or "") != "er":
        return info
    if getattr(info, "board", None):
        return info                      # adapter-resolved (non-CAIE) or already stated: leave it
    try:
        key = None
        try:
            st = path.stat()
            key = (str(path), st.st_size, int(st.st_mtime))
        except OSError:
            pass
        if key is not None and key in _CONTENT_BOARD_CACHE:
            board, line = _CONTENT_BOARD_CACHE[key]
        else:
            from adapters.associations import identify_document
            ident = identify_document(path)
            board = str(ident.board or "").upper()
            line = next((str(e) for e in (ident.evidence or []) if "board_signature" in str(e)), "")
            if key is not None:
                _CONTENT_BOARD_CACHE[key] = (board, line)
    except Exception:                                     # noqa: BLE001 - identification never dies here
        return info
    evidence = dict(info.identity_evidence or {})
    if board in ("CAIE", "CIE"):
        evidence.setdefault("document_board", "CAIE (confirmed from the document)")
        info.board = "CAIE"      # explicit rather than implied by an empty field
    elif board and board != "UNKNOWN":
        info.board = board
        info.identity_sources = list(info.identity_sources or []) + ["document_board"]
        evidence["document_board"] = (f"{board} (from the document: {line or 'board signature'})")
    info.identity_evidence = evidence
    return info


def parse_paper_filename(file_path: str | Path) -> Optional[PaperInfo]:
    """Filename parse + cover corroboration (2026-09-21).

    The filename grammar stays the identity authority; the cover is asked to
    corroborate it. See _corroborate_identity_from_cover for the conflict rule.
    """
    info = _parse_paper_filename_body(file_path)
    if info is None:
        return None
    try:
        info = _corroborate_identity_from_cover(info, Path(file_path))
    except Exception as exc:                              # noqa: BLE001
        # Corroboration is an ADDITIONAL check: never let it turn a parsed paper
        # into an unparsed one. The failure is recorded on the identity instead.
        info.identity_evidence = dict(info.identity_evidence or {},
                                      cover_corroboration=f"error: {type(exc).__name__}: {exc}")
    # Last, and reports only: ask the document which board it is (see the helper).
    return _adopt_content_board_for_examiner_reports(info, Path(file_path))

_NON_CAIE_SEASON_LETTER = {
    "june": "s", "may": "s", "summer": "s",
    "november": "w", "nov": "w", "winter": "w", "october": "w",
    "march": "m", "february": "m",
}


def _safe_token(value: str) -> str:
    """Filename-safe token: no slashes/colons (these end up in output paths)."""
    return re.sub(r"[^A-Za-z0-9]+", "-", str(value or "")).strip("-") or "UNKNOWN"


# Non-CAIE identity posture (2026-09-21). The CAIE tables - paper format, the
# content MCQ signal, the expected question count - are a Cambridge construct.
# They are deliberately NOT applied to another board's paper: forcing the posture
# here, in one place, means the live identification and the manifest replay can
# never disagree about what a board paper is.
NON_CAIE_IDENTITY_OVERRIDES = {
    "paper_format": "STRUCTURED",
    "is_mcq": False,
    "expected_question_count": None,
}


def apply_non_caie_identity_overrides(info: "PaperInfo") -> "PaperInfo":
    """Give a non-CAIE PaperInfo its board-native identity posture.

    Called by identify_non_caie_paper() when a paper is identified live, and
    replayed by core.batch_manifest when a paper is rebuilt from the manifest
    cache, so both paths return the same object. A cached board paper that came
    back with CAIE-derived fields (an ER reconstructed as paper_format 'STRUCTURED'
    vs 'ER', or a QP whose is_mcq flipped because of the content signal) would be
    exactly the silent identity drift the manifest's fail-closed check exists to
    prevent.
    """
    for field_name, value in NON_CAIE_IDENTITY_OVERRIDES.items():
        setattr(info, field_name, value)
    return info


def identify_non_caie_paper(file_path: str | Path) -> Optional[PaperInfo]:
    """Identify a paper this module's CAIE filename grammar rejects.

    Why this exists (2026-09-21): ``identify_papers_in_dir`` was the *only* front
    door into the guarded pipeline, and it is filename-driven CAIE grammar. Every
    non-CAIE paper was therefore dropped here - which meant the board dispatch
    (adapters, spooling, the whole non-CAIE cropping path) was unreachable from
    ``run_guarded`` no matter how well it worked in isolation: a real AQA trio
    produced "0 papers" and the run stopped at S1.

    Order and honesty rules:

    * the CAIE grammar runs FIRST and is never overridden - this is only reached
      for files it could not parse at all;
    * identity comes from the board adapters (``adapters.associations``), the same
      authority the cropping dispatch uses, so identity and cropping cannot
      disagree. Filenames are still never trusted;
    * a paper is only accepted when board, document type AND component are all
      evidenced. Anything less returns None and keeps the old
      "flag for review" behaviour, because a half-identified paper is worse than
      a refused one;
    * the CAIE-only tables (paper format, MCQ detection, expected question count)
      are deliberately NOT applied to another board's paper: ``is_mcq`` is forced
      False so no CAIE MCQ sidecar can ever be generated for it, and the expected
      question count stays None (advisory, unasserted).
    """
    try:
        from adapters.associations import identify_document
    except Exception:
        return None
    try:
        ident = identify_document(file_path)
    except Exception:
        return None

    board = str(ident.board or "UNKNOWN")
    dtype = str(ident.document_type or "UNKNOWN").upper()
    component = str(ident.component or "UNKNOWN")
    if board in ("UNKNOWN", "CAIE", "CIE") or "UNKNOWN" in (dtype, component):
        return None

    type_map = {"QP": "qp", "MS": "ms", "ER": "er", "IN": "insert", "INSERT": "insert"}
    paper_type = type_map.get(dtype)
    if paper_type is None:
        return None

    year = str(ident.year or "UNKNOWN")
    year_short = year[2:] if len(year) == 4 else year
    season = str(ident.season or "UNKNOWN")
    season_letter = _NON_CAIE_SEASON_LETTER.get(season.strip().lower(), "u")

    # Board-prefixed so a non-CAIE code can never collide with a CAIE syllabus.
    code = _safe_token(f"{board}-{component}")
    variant = "NA"
    try:
        from adapters.pipeline_dispatch import build_document_context
        from adapters.registry import get_adapter
        adapter = get_adapter(board)
        ctx = build_document_context(file_path, max_pages=3)
        for ev in adapter.identify_component(ctx):
            if getattr(ev, "field", "") == "paper_number" and ev.value:
                variant = _safe_token(ev.value)
                break
    except Exception:
        pass

    path = Path(file_path)
    info = PaperInfo(
        file_path=path,
        syllabus_code=code,
        year=year,
        year_short=year_short,
        season=season,
        season_letter=season_letter,
        paper_type=paper_type,
        variant=variant,
        full_code=f"{code}_{season_letter}{year_short}_{paper_type}_{variant}",
        level="Unknown",
        subject_guess=None,
        original_name=path.name,
        identity_status="ADAPTER_RESOLVED",
        identity_sources=["board_adapter"],
        board=board,
    )
    return apply_non_caie_identity_overrides(info)


def identify_papers_in_dir(input_dir: str | Path) -> list[PaperInfo]:
    """Scan directory for papers - supports both formats"""
    input_dir = Path(input_dir)
    papers = []
    # Case-insensitive extension scan keeps Windows ``.PDF`` uploads and
    # future renamed files from disappearing before identity parsing.
    for file in input_dir.rglob("*"):
        if not file.is_file() or file.suffix.lower() != ".pdf":
            continue
        info = parse_paper_filename(file)
        if not info:
            # Second chance, non-CAIE only. See identify_non_caie_paper().
            info = identify_non_caie_paper(file)
        if info:
            # Only include qp and ms for main processing, but keep insert/ci as separate?
            # For now include all that parsed, but main.py will filter
            papers.append(info)
        else:
            print(f"[PaperIdentifier] Could not parse filename: {file.name} - flag for review")
    return papers
