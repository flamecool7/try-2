"""Per-run quality checks and HTML reports (task 15 / P3, ideas 5-8).

Three pieces, all best-effort (a reporting problem never fails a paper):

* ``paper_checks(...)`` - computed inside the paper worker after S5:
    - mark-total cross-check: the QP cover's "The total mark for this paper is N"
      against the sum of the per-question ``[N]`` allocations (all-questions
      papers only; choice papers such as "Answer two questions" are skipped),
    - QP <-> MS question-count agreement.
  Mismatches are FLAGS: the questions are still filed into their topics as
  normal. Flags live ONLY at run level - the per-paper record
  ``<out>/.run_report/papers/<paper>.json``, ``<out>/.run_report/flags.json``
  and ``run_report.html`` - so question folders keep the exact output
  contract (``metadata.json`` = the canonical 10 fields, crops, nothing else).
* ``build_reports(output_root, failures)`` - called by the parent at run end:
    - ``run_report.html``: every paper, question counts, review_required counts
      with reasons, flags, ER coverage, failures,
    - ``qa_gallery.html``: one thumbnail per question crop for a quick visual
      sweep (catches bad splits in seconds).
  ``python -m core.run_report <output_dir>`` rebuilds both from disk.
"""
from __future__ import annotations

import base64
import html
import io
import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

REPORT_DIR = ".run_report"
COVER_TOTAL_RE = re.compile(r"total\s+mark\s+for\s+this\s+paper\s+is\s+(\d{1,3})", re.IGNORECASE)
ANSWER_ALL_RE = re.compile(r"answer\s+all\s+(?:the\s+)?questions", re.IGNORECASE)
CHOICE_RE = re.compile(
    r"answer\s+(?:one|two|three|four|five|any|either)\b|\bsection\s+[a-d]\b.*\bsection\s+[a-d]\b"
    r"|choose\s+(?:one|two)|\bEITHER\b", re.IGNORECASE | re.DOTALL)
MARK_RE = re.compile(r"\[\s*(\d{1,2})\s*\]")
TOTAL_MARK_RE = re.compile(r"\[\s*Total\s*:?\s*(\d{1,3})\s*\]", re.IGNORECASE)


# ---------------------------------------------------------------- checks ---
def cover_info(qp_pdf: str | Path) -> Dict[str, Any]:
    """Cover total and whether the paper is answer-all (first two pages)."""
    out: Dict[str, Any] = {"cover_total": None, "answer_all": False, "choice": False}
    try:
        import fitz  # noqa: PLC0415
        with fitz.open(str(qp_pdf)) as doc:
            text = "\n".join(doc[i].get_text() for i in range(min(2, len(doc))))
    except Exception:
        return out
    text = re.sub(r"\s+", " ", text)
    m = COVER_TOTAL_RE.search(text)
    if m:
        out["cover_total"] = int(m.group(1))
    out["answer_all"] = bool(ANSWER_ALL_RE.search(text))
    out["choice"] = bool(CHOICE_RE.search(text)) and not out["answer_all"]
    return out


def question_marks(text: str) -> int:
    """Marks printed in one question crop: a ``[Total: N]`` wins, else the sum
    of the ``[N]`` allocations."""
    text = text or ""
    totals = [int(x) for x in TOTAL_MARK_RE.findall(text)]
    if totals:
        return totals[-1]
    return sum(int(x) for x in MARK_RE.findall(text))


def paper_checks(qp_pdf, qp_crops: Iterable[Any], *, ms_count: Optional[int],
                 is_mcq: bool = False) -> Dict[str, Any]:
    crops = list(qp_crops)
    info = cover_info(qp_pdf)
    per_q = {str(getattr(c, "question_number", "")): question_marks(getattr(c, "text", "") or "")
             for c in crops}
    total = len(crops) if is_mcq else sum(per_q.values())
    flags: List[str] = []
    mark_check = "not checked"
    cover = info["cover_total"]
    if cover is None:
        mark_check = "not checked (no cover total)"
    elif info["choice"]:
        mark_check = "not checked (choice paper)"
    elif not is_mcq and (total == 0 or any(v == 0 for v in per_q.values())):
        mark_check = "not checked (some questions print no [N] marks)"
    elif total == cover:
        mark_check = f"ok ({total}/{cover})"
    else:
        mark_check = f"MISMATCH: questions add to {total}, cover says {cover}"
        flags.append(f"mark_total_mismatch: questions add to {total}, cover total is {cover}"
                     " (a question may be missing or split wrongly)")
    if ms_count is not None and ms_count != len(crops):
        flags.append(f"question_count_mismatch: QP has {len(crops)} question(s), "
                     f"mark scheme has {ms_count}")
    return {"cover_total": cover, "marks_sum": total, "per_question_marks": per_q,
            "mark_check": mark_check, "answer_all": info["answer_all"], "flags": flags}


def write_paper_record(output_root: str | Path, base_key: str, record: Dict[str, Any]) -> None:
    try:
        d = Path(output_root) / REPORT_DIR / "papers"
        d.mkdir(parents=True, exist_ok=True)
        record = dict(record, base_key=base_key, written=time.strftime("%Y-%m-%d %H:%M:%S"))
        (d / f"{base_key}.json").write_text(json.dumps(record, indent=2, default=str),
                                             encoding="utf-8")
    except Exception as exc:  # reporting never fails a paper
        print(f"    [report] could not write paper record: {exc}")


# --------------------------------------------------------------- reports ---
_CSS = """
body{font:14px/1.45 system-ui,Segoe UI,Arial,sans-serif;margin:24px;color:#1d2330;background:#f6f7f9}
h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 8px}
.sub{color:#5b6475;margin-bottom:18px}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin:14px 0}
.card{background:#fff;border:1px solid #dde1e8;border-radius:8px;padding:10px 16px;min-width:120px}
.card b{display:block;font-size:22px}
table{border-collapse:collapse;width:100%;background:#fff;border:1px solid #dde1e8}
th,td{padding:6px 9px;border-bottom:1px solid #eceef2;text-align:left;vertical-align:top}
th{background:#eef1f5;font-weight:600;position:sticky;top:0}
.ok{color:#137333}.warn{color:#a15c00}.bad{color:#b3261e;font-weight:600}
.small{font-size:12px;color:#5b6475}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px}
.tile{background:#fff;border:1px solid #dde1e8;border-radius:8px;padding:8px}
.tile img{width:100%;display:block;border:1px solid #eee}
.tile.review{border-color:#e3a008}.tile.flag{border-color:#b3261e}
.sub2{display:flex;gap:6px;margin-top:6px}.sub2 figure{margin:0;flex:1}
.sub2 figcaption{font-size:11px;color:#555}
.tag{display:inline-block;font-size:11px;padding:1px 6px;border-radius:9px;background:#eef1f5;margin-right:4px}
.tag.r{background:#fff3cd}.tag.f{background:#fde2e1}
input{padding:6px 10px;width:320px;border:1px solid #cfd5df;border-radius:6px;margin:8px 0}
"""


def _esc(v: Any) -> str:
    return html.escape(str(v), quote=True)


def _load_records(root: Path) -> List[Dict[str, Any]]:
    out = []
    for p in sorted((root / REPORT_DIR / "papers").glob("*.json")):
        try:
            out.append(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            continue
    return out


def _er_coverage(root: Path, rec: Dict[str, Any]) -> str:
    folders = [q.get("folder") for q in rec.get("questions", []) if q.get("folder")]
    if not folders:
        return ""
    have = 0
    for f in folders:
        p = root / f
        if p.is_dir() and any(p.glob("*_ER*.webp")):
            have += 1
    return f"{have}/{len(folders)}" if have else "-"


def _thumb(path: Path, width: int = 360, max_h: int = 520) -> str:
    try:
        from PIL import Image  # noqa: PLC0415
        files = [path] if path.exists() else sorted(path.parent.glob(path.stem + "_part*" + path.suffix))
        if not files:
            return ""
        with Image.open(files[0]) as im:
            im = im.convert("RGB")
            h = round(im.height * width / im.width)
            im = im.resize((width, max(1, h)))
            if im.height > max_h:
                im = im.crop((0, 0, width, max_h))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=70)
        return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return ""


CHECK_CONF = 0.40    # calibrated winner-vs-runner-up confidence below this ...
CHECK_RATIO = 0.85   # ... or runner-up score within 15% of the winner -> "check me"


def check_me(root: Path) -> List[Dict[str, Any]]:
    """Close-call topic decisions from ``.classification_audit`` (top-2 topics).

    Report-only: filing and metadata.json are never changed.
    """
    last: Dict[tuple, Dict[str, Any]] = {}
    for p in sorted((root / ".classification_audit").glob("*.jsonl")):
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in lines:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if r.get("assigned_topic"):
                last[(r.get("paper"), r.get("question_number"))] = r
    out: List[Dict[str, Any]] = []
    for (paper, q), r in sorted(last.items(), key=lambda kv: (str(kv[0][0]), str(kv[0][1]))):
        ranked = sorted(((float(v or 0), k) for k, v in (r.get("major_scores") or {}).items()), reverse=True)
        conf = r.get("confidence")
        conf = float(conf) if isinstance(conf, (int, float)) else 1.0
        ratio = ranked[1][0] / ranked[0][0] if len(ranked) > 1 and ranked[0][0] > 0 else 0.0
        if conf >= CHECK_CONF and ratio < CHECK_RATIO:
            continue
        folder = str(r.get("output_folder") or "")
        try:
            folder = str(Path(folder).resolve().relative_to(root.resolve()))
        except (ValueError, OSError):
            pass
        out.append({"paper": paper, "question": q, "topic": r.get("assigned_topic"),
                    "runner_up": next((k for v, k in ranked if k != r.get("assigned_topic") and v > 0), ""),
                    "confidence": round(conf, 3), "score_ratio": round(ratio, 3),
                    "folder": folder, "outcome": r.get("outcome", "")})
    return out


def build_reports(output_root: str | Path, failures: Optional[List[Dict[str, Any]]] = None,
                  *, gallery_limit: int = 3000) -> Dict[str, str]:
    root = Path(output_root)
    records = _load_records(root)
    failures = list(failures or [])
    if not failures:
        for p in sorted((root / "paper_failures").glob("*/summary.json")):
            try:
                failures.append(json.loads(p.read_text(encoding="utf-8")))
            except Exception:
                pass
    n_q = sum(len(r.get("questions", [])) for r in records)
    n_rev = sum(sum(1 for q in r.get("questions", []) if q.get("review")) for r in records)
    n_flag = sum(1 for r in records if r.get("checks", {}).get("flags"))
    stamp = time.strftime("%Y-%m-%d %H:%M")
    checks = check_me(root)
    check_map = {(c["paper"], str(c["question"]).lstrip("Q")): c for c in checks}
    crow = "".join(
        f"<tr><td>{_esc(c['paper'])} {_esc(c['question'])}</td><td>{_esc(c['topic'])}</td>"
        f"<td>{_esc(c['runner_up'] or '(no other evidence)')}</td><td>{c['confidence']:.2f}</td><td>{c['score_ratio']:.2f}</td>"
        f"<td class='small'>{_esc(c['folder'])}</td></tr>" for c in checks)

    rows = []
    for r in sorted(records, key=lambda x: (x.get("subject", ""), x.get("base_key", ""))):
        qs = r.get("questions", [])
        rev = [q for q in qs if q.get("review")]
        reasons = sorted({q.get("review_reason") or "review" for q in rev})
        ch = r.get("checks", {}) or {}
        mc = ch.get("mark_check", "")
        cls = "bad" if mc.startswith("MISMATCH") else ("ok" if mc.startswith("ok") else "small")
        flags = "<br>".join(_esc(f) for f in ch.get("flags", [])) or '<span class="ok">-</span>'
        rows.append(
            f"<tr><td>{_esc(r.get('base_key'))}<div class='small'>{_esc(r.get('subject', ''))}</div></td>"
            f"<td>{_esc(r.get('qp_count', ''))}</td><td>{_esc(r.get('ms_count', '-'))}</td>"
            f"<td>{len(qs)}</td>"
            f"<td class='{'warn' if rev else 'ok'}'>{len(rev)}"
            + (f"<div class='small'>{_esc('; '.join(reasons))}</div>" if rev else "") + "</td>"
            f"<td class='{cls}'>{_esc(mc)}</td><td>{_esc(_er_coverage(root, r))}</td>"
            f"<td>{flags}</td></tr>")
    frows = "".join(
        f"<tr><td>{_esc(f.get('base_key') or f.get('paper') or '')}</td>"
        f"<td>{_esc(f.get('kind', 'failed'))}</td><td>{_esc(f.get('worker_exit_code', f.get('exit_code', '')))}</td>"
        f"<td>{_esc(str(f.get('reason', ''))[:400])}</td></tr>" for f in failures)
    report = f"""<!doctype html><html><head><meta charset="utf-8"><title>Run report</title>
<style>{_CSS}</style></head><body>
<h1>TopicalRunner run report</h1><div class="sub">{_esc(root)} &middot; built {stamp}</div>
<div class="cards"><div class="card"><b>{len(records)}</b>papers</div>
<div class="card"><b>{n_q}</b>questions saved</div>
<div class="card"><b class="{'warn' if n_rev else 'ok'}">{n_rev}</b>in review_required</div>
<div class="card"><b class="{'bad' if n_flag else 'ok'}">{n_flag}</b>papers flagged</div>
<div class="card"><b class="{'warn' if checks else 'ok'}">{len(checks)}</b>check me (close call)</div>
<div class="card"><b class="{'bad' if failures else 'ok'}">{len(failures)}</b>failed / partial</div></div>
<p class="small">Flags never change filing: flagged questions are in their topic folders as normal; the flag list
is here and in <code>.run_report/flags.json</code>. Open <a href="qa_gallery.html">qa_gallery.html</a> for a thumbnail of every crop.</p>
<h2>Papers</h2><input placeholder="filter..." oninput="for(const r of document.querySelectorAll('#p tbody tr'))r.style.display=r.textContent.toLowerCase().includes(this.value.toLowerCase())?'':'none'">
<table id="p"><thead><tr><th>Paper</th><th>QP qs</th><th>MS qs</th><th>Saved</th><th>Review</th>
<th>Mark total</th><th>ER</th><th>Flags</th></tr></thead><tbody>{''.join(rows) or '<tr><td colspan=8>no paper records</td></tr>'}</tbody></table>
<h2>Check me &mdash; close topic calls</h2><p class="small">Filed under the winning topic as normal; the runner-up
is the next most likely topic (confidence &lt; {CHECK_CONF:.2f} or runner-up score &ge; {CHECK_RATIO:.0%} of the winner). Also in <code>.run_report/check_me.json</code>.</p>
<table><thead><tr><th>Question</th><th>Filed topic</th><th>Runner-up</th><th>Confidence</th><th>Score ratio</th><th>Folder</th></tr></thead>
<tbody>{crow or '<tr><td colspan=6 class="ok">none</td></tr>'}</tbody></table>
<h2>Failures</h2><table><thead><tr><th>Paper</th><th>Kind</th><th>Exit</th><th>Reason</th></tr></thead>
<tbody>{frows or '<tr><td colspan=4 class="ok">none</td></tr>'}</tbody></table>
</body></html>"""
    (root / "run_report.html").write_text(report, encoding="utf-8")
    try:
        flags = [{"paper": r.get("base_key"), "subject": r.get("subject"),
                  "flags": r.get("checks", {}).get("flags", []),
                  "mark_check": r.get("checks", {}).get("mark_check"),
                  "questions": [q.get("folder") for q in r.get("questions", [])]}
                 for r in records if r.get("checks", {}).get("flags")]
        (root / REPORT_DIR).mkdir(parents=True, exist_ok=True)
        (root / REPORT_DIR / "flags.json").write_text(json.dumps(flags, indent=2), encoding="utf-8")
        (root / REPORT_DIR / "check_me.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
    except OSError:
        pass

    tiles = []
    for r in sorted(records, key=lambda x: (x.get("subject", ""), x.get("base_key", ""))):
        flagged = bool(r.get("checks", {}).get("flags"))
        for q in r.get("questions", []):
            if len(tiles) >= gallery_limit:
                break
            folder = root / q.get("folder", "")
            src = _thumb(folder / f"{folder.name}.webp")
            if not src:
                continue
            extra = ""
            for suffix, label in (("_MS", "MS"), ("_ER", "ER")):
                t = _thumb(folder / f"{folder.name}{suffix}.webp", width=175, max_h=240)
                if t:
                    extra += (f"<figure><figcaption>{label}</figcaption>"
                              f"<img loading='lazy' src='{t}'></figure>")
            klass = "flag" if flagged else ("review" if q.get("review") else "")
            tags = (f"<span class='tag'>{_esc(q.get('topic') or '-')}</span>"
                    + ("<span class='tag r'>review</span>" if q.get("review") else "")
                    + ("<span class='tag f'>flag</span>" if flagged else ""))
            _c = check_map.get((r.get("base_key"), str(q.get("q", "")).lstrip("Q")))
            if _c:
                tags += (f"<span class='tag r'>check: {_esc(_c['runner_up'])}?</span>" if _c["runner_up"]
                         else "<span class='tag r'>check: low confidence</span>")
            tiles.append(f"<div class='tile {klass}'><div><b>{_esc(r.get('base_key'))} "
                         f"{_esc(q.get('q'))}</b></div><div>{tags}</div>"
                         f"<img loading='lazy' src='{src}'>"
                         + (f"<div class='sub2'>{extra}</div>" if extra else "")
                         + f"<div class='small'>{_esc(q.get('folder'))}</div></div>")
    gallery = f"""<!doctype html><html><head><meta charset="utf-8"><title>QA gallery</title>
<style>{_CSS}</style></head><body><h1>QA gallery</h1>
<div class="sub">{len(tiles)} crop(s) &middot; top of each question crop &middot; amber = review_required, red = paper flagged</div>
<input placeholder="filter by paper / topic..." oninput="for(const t of document.querySelectorAll('.tile'))t.style.display=t.textContent.toLowerCase().includes(this.value.toLowerCase())?'':'none'">
<div class="grid">{''.join(tiles)}</div></body></html>"""
    (root / "qa_gallery.html").write_text(gallery, encoding="utf-8")
    return {"report": str(root / "run_report.html"), "gallery": str(root / "qa_gallery.html")}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python -m core.run_report <output_dir>")
        sys.exit(2)
    print(build_reports(sys.argv[1]))
