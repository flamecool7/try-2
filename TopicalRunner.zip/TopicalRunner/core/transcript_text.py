"""transcript_text.py — listening-transcript evidence (accuracy push, 2026-10-01).

CAIE ships the listening recordings' spoken text as a separate TRANSCRIPT pdf
(``<series>_qr_<variant>.pdf``, e.g. ``0525_s25_qr_12.pdf``).  The question
paper's one-line MCQ stems carry almost no topic signal; the transcript does
("zwei Interviews mit Nora und Emil über Nachbarn", "Radiosendung über die
Gartenschau").  Blocks are keyed by the same exercise ranges the QP prints, so
they slot straight into the exercise-context memory.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

_RANGE_RE = re.compile(
    r"\b(?:Questions?|Preguntas|Fragen|Domande|Perguntas|Questões)\s+"
    r"(\d{1,2})\s*[–—-]\s*(\d{1,2})\b", re.I)

# Transcript headers use language-specific range grammar that the QP-side
# regex does not cover:
#   FR  "Questions 1 à 8"          ES  "Preguntas 1 a 8"
#   ZH  "问题1至5"                  AR  "8–1 … الأسئلة من" (visually reversed)
_RANGE_FR_ES_RE = re.compile(
    r"\b(?:Questions?|Preguntas)\s+(\d{1,2})\s+(?:à|a|bis)\s+(\d{1,2})\b", re.I)
_RANGE_ZH_RE = re.compile(r"问题\s*(\d{1,2})\s*至\s*(\d{1,2})")
_RANGE_AR_RE = re.compile(
    r"(\d{1,2})\s*[–—-]\s*(\d{1,2})[^\n\d]{0,25}(?:األسئلة|الأسئلة|القسم)")

_BLOCK_MAX = 4000


def _range_matches(text: str):
    """Yield (position, first, last) for every exercise-range header."""
    for rx, swap in ((_RANGE_RE, False), (_RANGE_FR_ES_RE, False),
                     (_RANGE_ZH_RE, False), (_RANGE_AR_RE, True)):
        for m in rx.finditer(text):
            a, b = int(m.group(1)), int(m.group(2))
            if swap:
                a, b = b, a
            if 0 < a < b <= a + 40:
                yield m.start(), a, b


def find_transcript(input_dir: Optional[Path], qp_stem: str) -> Optional[Path]:
    """``0525_s25_qp_12`` -> ``<input_dir>/0525_s25_qr_12.pdf`` if present."""
    if input_dir is None:
        return None
    m = re.match(r"(.+?)_qp_(\d{2})$", qp_stem)
    if not m:
        return None
    base, var = m.groups()
    for cand in (f"{base}_qr_{var}.pdf", f"{base}_qr_{int(var)}.pdf"):
        p = Path(input_dir) / cand
        if p.exists():
            return p
    return None


def transcript_blocks(path: Path) -> List[Tuple[int, int, str]]:
    """Split a transcript into (first, last, text) exercise blocks.

    Duplicate ranges (a header printed twice, or a continuation header) are
    merged into one block so the whole exercise's spoken text stays together.
    """
    import fitz

    with fitz.open(str(path)) as doc:
        text = "".join(page.get_text() for page in doc)
    return parse_transcript_text(text)


def parse_transcript_text(text: str) -> List[Tuple[int, int, str]]:
    """Block-splitter for transcript text (separated for unit testing)."""
    hits = sorted(_range_matches(text))
    merged: Dict[Tuple[int, int], str] = {}
    for i, (pos, a, b) in enumerate(hits):
        end = hits[i + 1][0] if i + 1 < len(hits) else len(text)
        chunk = text[pos:end]
        key = (a, b)
        merged[key] = (merged.get(key, "") + "\n" + chunk)[:_BLOCK_MAX]
    return [(a, b, t) for (a, b), t in sorted(merged.items())]
