Drop question papers and mark schemes here. run.bat reads this folder.
