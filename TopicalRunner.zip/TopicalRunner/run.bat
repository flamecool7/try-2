@echo off
setlocal EnableExtensions DisableDelayedExpansion
title ExamVoid Topical Generator

rem ============================================================================
rem ExamVoid Topical Generator -- the one and only Windows launcher.
rem
rem PROVENANCE AND SCOPE (2026-09-29, user directive): this is the ONLY .bat in
rem the tree. It absorbed the two former menus -- the six-feature console menu
rem and the topical six-step menu -- and it launches the web app itself, which
rem is what the user asked for. The three examiner-report downloader launchers
rem are gone with the rest: that subsystem is deliberately excluded from this
rem build, and its tools still run directly as Python
rem (see docs/notes/ER_DOWNLOADER_README.txt).
rem
rem   no arguments  -> this menu
rem   any arguments -> forwarded to run_pipeline.py untouched
rem                    e.g.  run.bat --dry-run --input in --output out
rem
rem Every action below is one of the repository's own commands; nothing here
rem invents behaviour. tools/launcher_check.py and tools/bat_check.py read this
rem file as text and hold every command and every flag to that tool's own
rem --help, because Windows batch cannot be executed by the test suite.
rem ============================================================================

rem --- 1. work from the folder this file lives in -----------------------------
cd /d "%~dp0"
if errorlevel 1 (
    echo   [ERROR] Could not switch to the project folder: "%~dp0"
    echo   Move the extracted project to a writable local folder and try again.
    goto FATAL
)

rem --- 2. the project must be complete ---------------------------------------
if not exist "server.py" (
    echo   [ERROR] server.py is missing: this launcher must sit in the project root.
    goto FATAL
)
if not exist "run_pipeline.py" (
    echo   [ERROR] run_pipeline.py is missing: extract the complete ZIP first.
    goto FATAL
)

rem --- 3. find Python: project venv first, then the system -------------------
set "PYTHON_EXE="
set "PYTHON_ARGS="
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=.venv\Scripts\python.exe"
if not defined PYTHON_EXE if exist "venv\Scripts\python.exe" set "PYTHON_EXE=venv\Scripts\python.exe"
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where py.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
    if defined PYTHON_EXE set "PYTHON_ARGS=-3"
)
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)
if not defined PYTHON_EXE (
    echo   [ERROR] Python 3 was not found: not in .venv\ or venv\, and not on PATH.
    echo   Install Python 3.10+ with "Add python.exe to PATH" ticked, then run this again.
    goto FATAL
)

rem --- 4. folders this launcher reads and writes -----------------------------
if not defined TOPICAL_PORT set "TOPICAL_PORT=8765"
if not defined TOPICAL_DATA set "TOPICAL_DATA=%CD%\_app_data"
if not defined TOPICAL_BATCH_OUT set "TOPICAL_BATCH_OUT=%CD%\output"
set "IN_DIR=%CD%\input"
set "OUT_DIR=%TOPICAL_BATCH_OUT%"
if not exist "%TOPICAL_DATA%" mkdir "%TOPICAL_DATA%" 2>nul
if not exist "%TOPICAL_DATA%" (
    echo   [ERROR] Could not create the data folder: "%TOPICAL_DATA%"
    echo   Set TOPICAL_DATA to a folder this user can write to, then run this again.
    goto FATAL
)
if not exist "%IN_DIR%" mkdir "%IN_DIR%" 2>nul

rem --- 5. arguments go straight to the pipeline -------------------------------
if not "%~1"=="" goto FORWARD

rem --- 6. soft dependency check: warn, never block ----------------------------
"%PYTHON_EXE%" %PYTHON_ARGS% -c "import fitz, PIL, numpy" >nul 2>nul
if errorlevel 1 (
    echo   [WARN] Some Python packages are not installed yet; the build options
    echo          stay unavailable until this succeeds once:
    echo              "%PYTHON_EXE%" -m pip install -r requirements.txt
    echo.
)

rem --- 7. the menu ------------------------------------------------------------
color 0B
:MENU
cls
echo.
echo   ======================================================================
echo      E X A M V O I D   T O P I C A L   G E N E R A T O R
echo   ======================================================================
echo      Project   %CD%
echo      Python    %PYTHON_EXE% %PYTHON_ARGS%
echo      Input     %IN_DIR%
echo      Output    %OUT_DIR%
echo   ======================================================================
echo.
echo      THE APP
echo      ------------------------------------------------------------------
echo        1   Start the app ......... browser plus the local server window
echo        2   Open the output folder
echo.
echo      BUILD      input folder to output folder
echo      ------------------------------------------------------------------
echo        3   Build topic packs ..... IB and SAT are included automatically
echo        4   Scan the input folder for subjects
echo        5   Build or update the topical index
echo        6   Build a booklet from a booklet.json
echo        7   Clean the output folder and build again
echo.
echo      CHECK
echo      ------------------------------------------------------------------
echo        8   Validate the output
echo        9   Validate the subject configurations
echo       10   Demo every configured subject
echo.
echo      MORE
echo      ------------------------------------------------------------------
echo       11   Full control menu ..... audit, statistics, benchmark, settings
echo        0   Exit
echo.
set "CHOICE="
set /p "CHOICE=     Choice: "
if "%CHOICE%"=="1" goto APP
if "%CHOICE%"=="2" goto OPENOUT
if "%CHOICE%"=="3" goto BATCH
if "%CHOICE%"=="4" goto SCAN
if "%CHOICE%"=="5" goto INDEX
if "%CHOICE%"=="6" goto BOOKLET
if "%CHOICE%"=="7" goto CLEAN
if "%CHOICE%"=="8" goto VALIDATE
if "%CHOICE%"=="9" goto CONFIGS
if "%CHOICE%"=="10" goto DEMO
if "%CHOICE%"=="11" goto CONTROL
if "%CHOICE%"=="0" goto END
echo.
echo      That is not one of the options. Pick a number from the list.
call :STOPPAUSE
goto MENU

rem ============================================================================
rem  THE APP
rem ============================================================================
:APP
echo.
echo   Starting the app on http://127.0.0.1:%TOPICAL_PORT%
echo     data folder   %TOPICAL_DATA%
echo     batch output  %TOPICAL_BATCH_OUT%
echo.
echo   The server opens in its own window; close that window to stop the app.
echo   Leave it running while you browse the packs in your browser.
echo.
start "ExamVoid Topical App" cmd /k ""%PYTHON_EXE%" %PYTHON_ARGS% server.py --host 127.0.0.1 --port %TOPICAL_PORT% --data-dir "%TOPICAL_DATA%" --root "%TOPICAL_BATCH_OUT%""
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:%TOPICAL_PORT%/"
call :STOPPAUSE
goto MENU

:OPENOUT
if not exist "%OUT_DIR%" (
    echo.
    echo   There is no output folder yet: %OUT_DIR%
    echo   Option 3 builds the packs and creates it.
    call :STOPPAUSE
    goto MENU
)
start "" explorer "%OUT_DIR%"
goto MENU

rem ============================================================================
rem  BUILD
rem ============================================================================
:BATCH
call :NEED_PDFS
if errorlevel 1 goto MENU
call :RUN_BATCH
goto MENU

:SCAN
echo.
echo   Scanning %IN_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% tools\detect_subjects.py --input "%IN_DIR%" --out "%TOPICAL_DATA%\detected_subjects.json"
echo.
echo   Report: %TOPICAL_DATA%\detected_subjects.json
call :STOPPAUSE
goto MENU

:INDEX
echo.
echo   Indexing %OUT_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% tools\build_topical_index.py --batch-out "%OUT_DIR%" --out "%TOPICAL_DATA%\topical_index.json"
echo.
echo   Index: %TOPICAL_DATA%\topical_index.json
call :STOPPAUSE
goto MENU

:BOOKLET
echo.
set "REQUEST="
set "OUT_PDF="
set /p "REQUEST=     Booklet request JSON [%TOPICAL_DATA%\draft_booklet.json]: "
if not defined REQUEST set "REQUEST=%TOPICAL_DATA%\draft_booklet.json"
set /p "OUT_PDF=     Write the PDF to [%TOPICAL_DATA%\booklet.pdf]: "
if not defined OUT_PDF set "OUT_PDF=%TOPICAL_DATA%\booklet.pdf"
echo.
"%PYTHON_EXE%" %PYTHON_ARGS% tools\build_booklet.py --booklet "%REQUEST%" --index "%TOPICAL_DATA%\topical_index.json" --out "%OUT_PDF%" --fit flow
echo.
echo   PDF: %OUT_PDF%
call :STOPPAUSE
goto MENU

:CLEAN
echo.
echo   This deletes everything in %OUT_DIR% and builds it again from %IN_DIR%.
set "CONFIRM="
set /p "CONFIRM=     Delete the output and build again? Type Y to continue: "
if /I not "%CONFIRM%"=="Y" goto MENU
call :NEED_PDFS
if errorlevel 1 goto MENU
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
if exist "%OUT_DIR%" (
    echo.
    echo   [ERROR] Could not delete %OUT_DIR%
    echo   A file in it is open in another program - close it and try again.
    call :STOPPAUSE
    goto MENU
)
call :RUN_BATCH
goto MENU

rem ============================================================================
rem  CHECK
rem ============================================================================
:VALIDATE
echo.
echo   Validating %OUT_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% run_guarded.py --validate --output "%OUT_DIR%"
if errorlevel 1 (
    echo.
    echo   [ERROR] Validation reported problems. The output above names them.
    call :STOPPAUSE
    goto MENU
)
echo.
echo   [OK] Validation completed.
call :STOPPAUSE
goto MENU

:CONFIGS
echo.
echo   Validating every subject configuration
"%PYTHON_EXE%" %PYTHON_ARGS% -c "from core.config_loader import validate_all_configs; print(validate_all_configs())"
if errorlevel 1 (
    echo.
    echo   [ERROR] Configuration validation failed. The report above names every problem.
    call :STOPPAUSE
    goto MENU
)
echo.
echo   [OK] Configuration validation completed.
call :STOPPAUSE
goto MENU

:DEMO
echo.
echo   Building a demo for every configured subject into %OUT_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% main.py --input "%IN_DIR%" --output "%OUT_DIR%" --demo --demo-all --clean --validate
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" (
    echo.
    echo   [OK] Demo completed. Opening %OUT_DIR%
    start "" explorer "%OUT_DIR%"
    call :STOPPAUSE
    goto MENU
)
echo.
echo   [ERROR] The demo returned error code %APP_EXIT%. The output above has the details.
call :STOPPAUSE
goto MENU

rem ============================================================================
rem  MORE
rem ============================================================================
:CONTROL
echo.
echo   Opening the full control menu. Exit it to come back here.
echo.
"%PYTHON_EXE%" %PYTHON_ARGS% run_pipeline.py --menu
call :STOPPAUSE
goto MENU

rem ============================================================================
rem  Helpers. Each one owns exactly one command, so the menu never repeats it.
rem ============================================================================
:RUN_BATCH
echo.
echo   Building topic packs
echo     from  %IN_DIR%
echo     into  %OUT_DIR%
echo.
"%PYTHON_EXE%" %PYTHON_ARGS% tools\run_universal_batch.py --input "%IN_DIR%" --output "%OUT_DIR%" --jobs 0 --prune-stale-dirs
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" (
    echo.
    echo   [OK] Batch completed. Opening %OUT_DIR%
    start "" explorer "%OUT_DIR%"
    call :STOPPAUSE
    exit /b 0
)
if "%APP_EXIT%"=="2" (
    echo.
    echo   [WARN] Batch completed with review_required items - something did not render
    echo          cleanly. Opening %OUT_DIR% so you can see which.
    start "" explorer "%OUT_DIR%"
    call :STOPPAUSE
    exit /b 0
)
echo.
echo   [ERROR] The batch returned error code %APP_EXIT%. The output above has the details.
call :STOPPAUSE
exit /b %APP_EXIT%

:NEED_PDFS
if exist "%IN_DIR%\*.pdf" exit /b 0
if exist "%IN_DIR%\*.PDF" exit /b 0
echo.
echo   Nothing to do yet: there are no PDFs in %IN_DIR%
echo   Put the question papers, mark schemes, inserts and examiner reports there,
echo   then choose this option again. Or drop them in and press 3.
call :STOPPAUSE
exit /b 1

:STOPPAUSE
echo.
echo   Press any key to go back to the menu...
pause >nul
exit /b 0

rem ============================================================================
rem  Command-line use, diagnostics, and the two ways out
rem ============================================================================
:FORWARD
"%PYTHON_EXE%" %PYTHON_ARGS% run_pipeline.py %*
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" goto END
echo.
echo   [ERROR] run_pipeline.py returned error code %APP_EXIT%.
echo   Press any key to close this window...
pause >nul
goto END

:FATAL
echo.
echo   Press any key to close this window...
pause >nul
exit /b 1

:END
endlocal
exit /b 0
