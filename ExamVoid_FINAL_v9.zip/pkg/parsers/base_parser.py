"""Abstract base for all paper-format parsers (Overseer rebuild spec, Step 2).

Dataclasses and pair() contract per spec, verbatim semantics:

* every QP question lacking a mark scheme -> needs_review + parse_error
* every mark scheme lacking a question -> parse_error (orphan)

Repo vocabulary reconciliation (approved decision): parser-level
``needs_review`` means "we cannot pair this" and is REPORTED as such;
where files land on disk continues to follow the locked RS-5 routing
(Uncategorized / Uncategorized_No_MS sentinels). The two vocabularies meet
in the orchestrator (Step 7), never inside parsers.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import fitz
from PIL import Image


@dataclass
class ParsedQuestion:
    question_num: str
    text: str
    crop_image: Optional[Image.Image]
    page_start: int
    page_end: int
    y_start: float
    y_end: float
    has_diagram: bool
    sub_parts: List[str] = field(default_factory=list)
    total_marks: int = 0


@dataclass
class ParsedMarkScheme:
    question_num: str
    answer: str                              # letter for MCQ
    crop_image: Optional[Image.Image]        # image for structured
    marking_points: List[str] = field(default_factory=list)
    total_marks: int = 0
    ms_type: str = "structured"              # "mcq" or "structured"


@dataclass
class ParseResult:
    questions: Dict[str, ParsedQuestion]
    mark_schemes: Dict[str, ParsedMarkScheme]
    parse_errors: List[str] = field(default_factory=list)
    needs_review: List[str] = field(default_factory=list)  # need human check
    parser_used: str = ""


class BaseParser(ABC):
    @abstractmethod
    def parse_qp(
        self,
        pages: List[fitz.Page],
        page_images: List[Image.Image],
        scale_x: float,
        scale_y: float,
    ) -> Dict[str, ParsedQuestion]:
        ...

    @abstractmethod
    def parse_ms(
        self,
        pages: List[fitz.Page],
        page_images: List[Image.Image],
        scale_x: float,
        scale_y: float,
    ) -> Dict[str, ParsedMarkScheme]:
        ...

    def pair(
        self,
        questions: Dict[str, ParsedQuestion],
        mark_schemes: Dict[str, ParsedMarkScheme],
    ) -> ParseResult:
        errors: List[str] = []
        needs_review: List[str] = []

        # Check every question has a mark scheme
        for qnum in questions:
            if qnum not in mark_schemes:
                needs_review.append(qnum)
                errors.append(f"Q{qnum}: no mark scheme found")

        # Check no orphan mark schemes
        for qnum in mark_schemes:
            if qnum not in questions:
                errors.append(f"MS Q{qnum}: no matching question")

        return ParseResult(
            questions=questions,
            mark_schemes=mark_schemes,
            parse_errors=errors,
            needs_review=needs_review,
            parser_used=self.__class__.__name__,
        )
