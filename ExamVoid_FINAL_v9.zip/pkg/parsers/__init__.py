"""Paper-format parsers — one class per Cambridge paper format.

Step 2 ships the abstract base + pairing contract only (Overseer spec).
Concrete parsers arrive at Steps 5/6/9 as composition adapters over the
locked gold modules — never copies of them (the question_split triplet,
ms_cropping_engine, converter and webp settings stay byte-locked).
"""
