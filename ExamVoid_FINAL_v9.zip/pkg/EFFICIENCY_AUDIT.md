# EFFICIENCY AUDIT — Overseer "Strategic Efficiency Audit" + "6 Upgrades" specs
### Executed 2026-08-10. Evidence in `/home/user/test-crops/eff-bench/`.

Both specs arrived markdown-linkification-corrupted (**misfire #10**): phantom modules
`cambridge_qb.pipeline/markscheme/topics_enhanced/metadata/organize/output_validator`,
wrong call signatures (`split_questions(page_images, pages, meta, sx, sy)` —
real: `split_questions(pdf_path, dpi=, paper_code=, cfg=, webp_dir=)`),
`[pool.map](http://pool.map)`, `*process*single_paper` → `_process_single_paper`,
`state.papers[...] = **import**(...)`, quality preset `92` vs locked `95`.
Every upgrade was mapped onto the real, locked codebase; nothing was applied blind.

---

## The 6 upgrades — applied in order, each confirmed before the next

| # | Upgrade | Status | Evidence |
|---|---|---|---|
| U1 | Parallel paper processing | ✅ PORTED with RAM guard — new `pipeline.py` | Guard table below; `GUARDED_CHILD_NO_STATE=1` child mode in `run_guarded.py`; parent owns `.pipeline_state.json` (no concurrent writers); per-worker logs at `output/.worker_logs/` |
| U2 | Zero intermediate disk writes | ✅ PARTIALLY TRUE → real bug found & fixed | MS path already pure in-memory (`pdf_io.py:98`). **QP path leaked an undeleted `qp_pages_*` tempdir per paper** (locked triplet has no `rmtree`): BEFORE `1 dir / 6 webps / 1517KB orphaned` → AFTER `0 dirs`, crops byte-identical (`a6a284304c876acb`). Fix lives in `cropping_engine.py` (owned scratch dir, `/dev/shm` when writable, `finally: rmtree`). Locked splitter untouched. DPI/quality/method untouched. |
| U3 | Module-level regex | ✅ ONE real site fixed | Hot loops were already module-level (locked triplet, examiner_report, paper_*). The one genuine hotspot: `classifier.py:453` per-keyword compile (15,170 compiles → 82 per process). `_keyword_pattern` lru_cache; findall equivalence proven for all 82 real keywords; end-to-end classifications byte-path-identical to approved m25/w25 baselines. **Honest gain ≈ 0.6ms/question (CPython's re cache already deduped).** |
| U4 | Global taxonomy cache | ✅ REAL equivalent implemented | `TaxonomyLoader` never existed; **but** `load_subject_config_by_code_and_level` re-parsed ALL 23 config.jsons on every call (115 json.loads per 5 calls, 24.7ms → 0 loads, 2.4ms warm). `_CONFIG_TREE_CACHE` keyed on (path,mtime,size) — edit-invalidation proven. Spec's "fork shares cache" claim false for spawn processes; ours caches per worker process. |
| U5 | tqdm progress bar | ✅ APPLIED as optional dependency | `tqdm>=4.65.0` added to requirements; bar renders live with per-paper postfix (`9700_m25_22 rc=0 saved=6 25s`); ImportError → loud plain-lines fallback. |
| U6 | gc + memory logging | ✅ ALREADY STRONG → extended | main.py had 4× gc.collect; worker now also `gc.collect()` + `[mem] RSS at worker end` line immediately before `WORKER-RESULT` (measured 777–815MB post-sweep). `psutil>=5.9.0` listed optional; runner reads /proc natively. |

### RAM-guard decision table (pure function, `pipeline.guard_decision`)
| MemAvailable | requested | concurrency | note |
|---|---|---|---|
| 900–1286MB (this box) | any | 1 | floor of 1; sequential RS-2 path proven at this pressure |
| 2600MB | 2 / 4 | 2 / 2 | fits / clamped |
| 8200MB | 2 / 4 | 2 / 4 | full parallel engages |
| 16400MB | auto(1 for 2-core) / 4 | 1 / 4 | cpu_count//2 default honored |

## Tier-audit leftovers (first spec) — verdicts
- **U1-tier claims (2–5x)**: unreachable on 2-core/1984MB — 2 workers × 933MB measured RSS = guaranteed OOM-137 (full-mode OOM actually reproduced during baseline: `exit=-9 SIGKILL`). On ≥8GB machines the guard allows real concurrency.
- **Batch WebP save (q92/m4)**: REJECTED — conflicts with locked quality 95; per-question outputs are already sequential; encode dominates.
- **Lazy reference detection**: REJECTED — locked triplet + pristine chemistry_reference; CROPPING_LOCK documents the proven cover-page regression.
- **State skip / grouping / gc**: ALREADY SATISFIED (main.py:174-176 RESUME-SKIP loud; matcher.group_papers main.py:129; gc ×4 + subprocess isolation).

## Benchmark (spec's own format, 9700 m25 A-Level Biology, 6 questions + ER)
```
Single worker:            93.3s   (pre-upgrade baseline run_guarded: 93.0s)
Parallel workers (auto):  92.3s   Speedup: 1.01x   (guard clamped 1: physics, not code)
CPU cores detected:       2
Peak memory:              933MB worker RSS; parent <160MB; end 1187MB free
Errors:                   none (exit 0, ALL GREEN, 2-paper run 124s wall)
tqdm visible:             yes
```

## Regression gate (the part that matters)
- 33/33 webps shared with the RS-2 approved tree: **byte-identical**
- 9/9 shared metadata.json: **identical** (uuid id excluded)
- Classifications == approved baselines exactly (m25: Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5 Genetics; w25: Q1/Q2 Cell_Structure, Q3/Q5 Genetics, Q4 Cell_Membranes, Q6 Physiology)
- Resume-gate: second invocation returns instantly (`Skipped 1 already-completed papers`)
- **Gate catch**: RS-2 evidence tree found to have only 9/12 question folders (validator test rig deleted 3 during that session) — discrepancy explained, not introduced by these patches.
- Locked/pristine files byte-unchanged: triplet (00cc779e), multipage pair (c384248b), ms_cropping_engine (9a1dc1e8), webp_utils (f865edff), examiner_report (972e68d3), er_question_crops (b93ad5f2), validation (2a62f1ce), output_manager (1ae25f9d), converter.py (DPI untouched).

## Pending lock amendments (⏸️ awaiting approval — NOT yet written)
- CROPPING_LOCK Am-6: `core/cropping_engine.py` new hash (U2 scratch-dir + leak fix; behavior-neutral, proven byte-identical crops)
- CLASSIFICATION_LOCK CLS-3: `core/classifier.py` new hash (U3 lru_cache; equivalence proven)
- ROUTING_STATE_LOCK RS-4: `run_guarded.py` new hash (U1 child-state mode + U6 end-sweep) + NEW records: `pipeline.py`, `core/config_loader.py` (U4)
- requirements.txt: +tqdm, +psutil(optional) — not a locked file
- Still outstanding from before: RS-3 (`core/quality_scorer.py` 5dd491d8…) and the Uncategorized directive's 4 open decisions.
