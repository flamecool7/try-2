"""Bundle worker (Overseer batch-infrastructure spec, Phase 4 — honest port
onto the REAL locked per-paper stages).

The spec's worker called a fictional API stack (converter.render_pdf_to_images,
question_split.split_questions(qp_images, pages, ...), markscheme.parse_markscheme,
topics_enhanced.classify, organize.route_question, webp_utils.save_question_crop —
the same hallucinated names pipeline.py's docstring lists), never saved MS
crops, and hard-required examiner_report.webp per question. Instead of faking
that, this worker drives the production machinery — the exact stage function
the guarded runner uses (run_guarded.run_paper_stages): locked gold QP/MS
cropping, MCQ answer-grid letters (RS-7), locked classifier, locked
OutputManager routing, locked on-disk stage checks — with the OutputManager
rooted INSIDE the bundle's staging directory (spec rule 6: never write
directly to final output during processing).

Spec rules honoured:
  4  workers receive pre-built bundle args (explicit file paths from the DB)
     and NEVER rescan the input directory;
  5  workers load only THEIR subject's config
     (config_loader.load_subject_config_by_code_and_level), never all 23;
  6  all writes go to <output>/.staging/bundle_<key>/ first;
  7  bundle COMPLETE only after every question saved + validated + committed;
  8  failed bundles keep their staging directory (worker_log.txt included);
  9  the SQLite database is the single source of truth for batch state
     (the per-run .pipeline_state.json inside staging is throwaway scratch
     the real stage function insists on having — it is never committed);
 10  .pipeline_state.json in the REAL output is untouched by batch runs.
"""

import gc
import json
import logging
import traceback
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _validate_staging(staging_root: Path) -> list:
    """Validate staged output before commit (honest replacement of the spec's
    _validate_staging, which hard-required examiner_report.webp on every
    question — that would force-review every ER-less bundle).

    Rules enforced = the production output contract:
      * every question folder has exactly one QP webp, 2280px wide
        (multi-part QP twins use the _partN suffix — count bits-by-stem);
      * metadata.json parses and carries 2280-independent fields the locked
        schema requires (delegated to FinalValidator at batch level; here we
        check parse + question_number);
      * an MS webp UNLESS the folder is a legitimate MS-less home:
        a valid `*_MS.txt` letter sidecar (MCQ components), or an
        review_required no_markscheme sentinel.
    Returns list of error strings; empty = all good.
    """
    from PIL import Image

    errors = []
    q_folders = [p for p in staging_root.rglob("*")
                 if p.is_dir() and "_Q" in p.name
                 and p.name.rsplit("_Q", 1)[1].isdigit()]
    if not q_folders:
        errors.append(f"no question folders staged under {staging_root}")
        return errors
    for folder in sorted(q_folders):
        webps = [w for w in folder.glob("*.webp") if "_ER" not in w.name]
        qp_webps = [w for w in webps if "_MS" not in w.name]
        ms_webps = [w for w in webps if w.name.endswith("_MS.webp")]
        if len(qp_webps) != 1:
            errors.append(f"{folder.name}: expected 1 QP webp, found {len(qp_webps)}")
        else:
            try:
                with Image.open(qp_webps[0]) as im:
                    if im.width != 2280:
                        errors.append(f"{folder.name}: QP width {im.width}px != 2280px")
            except Exception as e:
                errors.append(f"{folder.name}: QP image error: {e}")
        meta_path = folder / "metadata.json"
        if not meta_path.exists():
            errors.append(f"{folder.name}: metadata.json missing")
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception as e:
            errors.append(f"{folder.name}: metadata.json invalid: {e}")
            continue
        if ms_webps:
            continue
        # MS-less homes are legal ONLY in these two shapes. User requirement
        # (2026-08-14): metadata.json carries no MCQ flags — the answer
        # letter lives in the `*_MS.txt` sidecar.
        from .mcq_output import valid_ms_sidecar as _valid_sidecar
        ms_txts = sorted(folder.glob("*_MS.txt"))
        topic = meta.get("topic")
        sentinel = topic[0] if isinstance(topic, list) and topic else None
        if ms_txts and _valid_sidecar(ms_txts[0].read_text(encoding="utf-8")):
            pass  # MCQ letter or QP-only placeholder = MS-less home
        elif sentinel == "review_required_no_ms":
            pass
        else:
            errors.append(f"{folder.name}: no MS webp and not an MS-less home (valid _MS.txt / no_markscheme)")
    return errors


def _commit_and_register(db, bundle_id, bundle_key, staging_root, output_dir,
                         writer, qc_review_reason=None):
    """Move staged question-tree files to the real output (via StagedWriter)
    and register questions + artifacts in the database.
    Returns (ok, committed_folders, errors)."""
    final_paths = []
    for p in sorted(staging_root.rglob("*")):
        if not p.is_file():
            continue
        if p.name.startswith(".") or p.name in (
            "worker_log.txt", "failure_report.txt", "pipeline.sqlite",
            "pipeline.sqlite-wal", "pipeline.sqlite-shm",
        ):
            # Worker scratch/state is never an output artifact. The parent DB
            # owns batch state; the final tree must contain only question assets.
            continue
        rel = p.relative_to(staging_root)
        final_paths.append((str(rel), str(output_dir / rel)))

    committed = writer.commit(bundle_key, staging_root, final_paths)
    if not committed:
        return False, [], ["staging commit failed (destination conflict or I/O error)"]

    # Register questions/artifacts from the COMMITTED tree (real bytes only)
    from PIL import Image
    committed_folders = set()
    q_found = 0
    for src_rel, dest_abs in final_paths:
        dest = Path(dest_abs)
        if not dest.exists():
            continue
        folder = dest.parent
        committed_folders.add(folder)
    for folder in sorted(committed_folders):
        meta = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        topic = meta.get("topic")
        topic0 = topic[0] if isinstance(topic, list) and topic else ""
        folder_rel = str(folder.relative_to(output_dir))
        needs_review = ("review_required" in folder.parts)
        q_id = db.register_question(
            bundle_id=bundle_id,
            question_num=str(meta.get("question_number", folder.name.rsplit("_", 1)[-1])),
            topic_assigned=topic0,
            folder_path=folder_rel,
            needs_review=needs_review,
        )
        q_found += 1
        for webp in sorted(folder.glob("*.webp")):
            name = webp.name
            kind = "ms" if name.endswith("_MS.webp") else ("er" if "_ER" in name else "qp")
            try:
                with Image.open(webp) as im:
                    w, h = im.size
            except Exception:
                w = h = None
            db.register_artifact(
                question_id=q_id, kind=kind,
                path=str(webp.relative_to(output_dir)),
                width_px=w, height_px=h, file_size=webp.stat().st_size,
            )
    return True, sorted(str(f.relative_to(output_dir)) for f in committed_folders), []


def process_bundle(args: dict) -> dict:
    """
    Process one complete QP/MS(/ER) bundle end-to-end through the REAL
    locked stages, inside staging, then commit + register.

    Standalone function safe for multiprocessing: receives a pre-built
    bundle dict from preflight/the DB and loads only its own subject config.
    Returns status dict.
    """
    bundle_key = args["bundle_key"]
    bundle_id = args["bundle_id"]
    qp_path = Path(args["qp_path"]) if args.get("qp_path") else None
    ms_path = Path(args["ms_path"]) if args.get("ms_path") else None
    output_dir = Path(args["output_dir"])
    db_path = Path(args["db_path"])
    syllabus_code = args["syllabus_code"]
    subject = args["subject"]
    level = args["level"]
    year = args.get("year", "")
    quiet = bool(args.get("quiet_worker"))

    from .database import Database
    from .staged_writer import StagedWriter

    db = Database(db_path)
    writer = StagedWriter(output_dir)

    # Resume short-circuit: constant-time identity check (spec rule 9)
    if db.bundle_is_complete(bundle_key):
        return {"status": "already_complete", "bundle_key": bundle_key}

    staging_path = writer.get_staging_path(bundle_key)

    # Worker stdout → staging log when running pooled (readable alongside
    # preserved staging on failure; live prints when workers==1)
    log_fh = None
    if quiet:
        import contextlib
        import sys
        log_fh = open(staging_path / "worker_log.txt", "w", encoding="utf-8", errors="replace")
        sys.stdout = contextlib.redirect_stdout(log_fh).__enter__()
        sys.stderr = contextlib.redirect_stderr(log_fh).__enter__()

    try:
        # ── Input verification (fail-closed) ─────────────────────────
        if qp_path is None or not qp_path.exists():
            raise FileNotFoundError(f"QP input missing for {bundle_key}: {qp_path}")
        if ms_path is not None and not ms_path.exists():
            raise FileNotFoundError(f"MS input missing for {bundle_key}: {ms_path}")

        db.mark_bundle_processing(bundle_id)

        # ── Identity WITHOUT rescanning the input dir (rule 4) ───────
        from .paper_identifier import parse_paper_filename
        qp_info = parse_paper_filename(qp_path)
        ms_info = parse_paper_filename(ms_path) if ms_path is not None else None
        if qp_info is None:
            raise ValueError(f"cannot re-identify QP {qp_path.name}")
        if ms_path is not None and ms_info is None:
            raise ValueError(f"cannot re-identify MS {ms_path.name}")

        # ── This subject's config ONLY (rule 5) ──────────────────────
        from .config_loader import load_subject_config_by_code_and_level
        year_full = str(year)
        if len(year_full) == 2 and year_full.isdigit():
            year_full = "20" + year_full
        config = load_subject_config_by_code_and_level(
            syllabus_code, level, year_full
        )
        if config is None:
            raise ValueError(
                f"no approved subject config for {syllabus_code}/{level}/{year_full}"
            )

        # ── Real locked stages, rooted inside staging (rule 6) ───────
        import sys as _sys
        proj_root = str(Path(__file__).resolve().parent.parent)
        if proj_root not in _sys.path:
            _sys.path.insert(0, proj_root)
        from types import SimpleNamespace
        from run_guarded import Gate, StageAbort, run_paper_stages
        from core.cropping_engine import CroppingEngine
        from core.ms_cropping_engine import MSCroppingEngine
        from core.qp_ms_matcher import QPMSMatcher
        from core.output_manager import OutputManager
        from core.pipeline_state import PipelineState

        cropping_engine = CroppingEngine(target_width=2280, quality=95, dpi=75)
        ms_engine = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
        gate = Gate(staging_path)
        # Throwaway scratch state living INSIDE staging (never committed) —
        # run_paper_stages requires it; the DB is the batch source of truth.
        state = PipelineState.load_or_create(
            staging_path, subject=subject, syllabus_code=syllabus_code, level=level,
        )
        output_mgr = OutputManager(output_root=staging_path)

        local_status, local_error, saved_n = "failed", "worker did not finish", 0
        try:
            run_args = SimpleNamespace(
                low_ram=bool(args.get("low_ram", True)),
                full_auto=bool(args.get("full_auto", False)),
                output=str(staging_path),
            )
            saved_n = run_paper_stages(
                gate, run_args, bundle_key, qp_info, ms_info, subject, config,
                state, cropping_engine, ms_engine, QPMSMatcher(), output_mgr,
            )
        except StageAbort as e:
            local_status, local_error = "failed", f"stage gate abort: {e}"
        except SystemExit as e:
            local_status, local_error = "failed", f"stage runner exited: code {e.code}"
        else:
            rec = state.papers.get(bundle_key)
            if rec is not None:
                st = rec.status.value if hasattr(rec.status, "value") else str(rec.status)
                local_status = "complete" if st == "complete" else "review_or_failed"
                local_error = rec.error_message or getattr(rec, "review_reason", "") or ""
            else:
                local_status, local_error = "failed", "no local record"

        # ── Verdict mapping (local scratch verdict -> batch DB verdict) ──
        review_markers = ("QC needs_review", "MISSING_MS", "CROP_EMPTY")
        commit_ok_shapes = ("complete",) + tuple(review_markers)

        review_folders = [
            p for p in staging_path.rglob("*")
            if p.is_dir() and "review_required" in p.parts
        ]
        if local_status == "complete" and review_folders:
            verdict = "review_required"
            local_error = (
                f"{len(review_folders)} question folder(s) require review; "
                "bundle output is preserved but not marked complete"
            )
        elif local_status == "complete":
            verdict = "complete"
        elif local_status == "review_or_failed":
            # PipelineState has an explicit REVIEW_REQUIRED status even when
            # the crops themselves live in normal topic folders (for example,
            # a paper year outside the verified syllabus editions).
            verdict = "review_required"
            local_error = local_error or "bundle marked REVIEW_REQUIRED by guarded stages"
        elif any(m in local_error for m in review_markers):
            verdict = "review_required"
        else:
            verdict = "failed"

        stage_errors = []
        if local_status in {"complete", "review_or_failed"} or any(
                m in local_error for m in commit_ok_shapes[1:]):
            # CROP_EMPTY stages nothing worth committing; fail review-closed.
            has_questions = any(
                d.is_dir() and "_Q" in d.name
                for d in staging_path.rglob("*")
            )
            if has_questions:
                stage_errors = _validate_staging(staging_path)
                if stage_errors:
                    for err in stage_errors:
                        logger.warning(f"Validation: {err}")
                    db.mark_bundle_review(
                        bundle_id, f"{len(stage_errors)} staging validation issues: "
                                   f"{stage_errors[0]}")
                    _finish(log_fh)
                    return {"status": "review_required", "bundle_key": bundle_key,
                            "errors": stage_errors}

                ok, committed, commit_errors = _commit_and_register(
                    db, bundle_id, bundle_key, staging_path, output_dir, writer)
                if not ok:
                    db.mark_bundle_failed(bundle_id, "Staging commit failed: "
                                          + "; ".join(commit_errors))
                    writer.rollback(bundle_key, staging_path, preserve=True)
                    _finish(log_fh)
                    return {"status": "failed", "bundle_key": bundle_key,
                            "error": "commit_failed"}

                rec = state.papers.get(bundle_key)
                # Local record counts are zero on review paths (mark_failed
                # never sets them) — fall back to the runner's own saved_n
                # and then the committed-folder count. Never report 0 beside
                # a committed tree.
                found = ((rec.questions_found if rec is not None else 0) or 0) \
                        or saved_n or len(committed)
                saved = ((rec.questions_saved if rec is not None else 0) or 0) \
                        or saved_n or len(committed)
                if verdict == "review_required":
                    # Crops committed; humans must triage. DB truthfully says so —
                    # and the counts stay visible in progress reporting.
                    db.set_bundle_counts(bundle_id, found, saved)
                    db.mark_bundle_review(bundle_id, local_error)
                else:
                    db.mark_bundle_complete(
                        bundle_id, questions_found=found, questions_saved=saved)
                _finish(log_fh)
                return {"status": verdict, "bundle_key": bundle_key,
                        "questions": saved, "needs_review": [],
                        **({"reason": local_error} if verdict == "review_required" else {})}

        # failed / nothing committable
        db.mark_bundle_failed(bundle_id, local_error or "unknown worker failure")
        writer.rollback(bundle_key, staging_path, preserve=True)
        gc.collect()
        _finish(log_fh)
        return {"status": verdict if verdict != "complete" else "failed",
                "bundle_key": bundle_key,
                "error": local_error or "unknown worker failure"}

    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"Bundle {bundle_key} failed: {e}")
        try:
            db.mark_bundle_failed(bundle_id, str(e), tb)
        except Exception:
            logger.error(f"DB mark_bundle_failed also failed for {bundle_key}")
        writer.rollback(bundle_key, staging_path, preserve=True)
        gc.collect()
        _finish(log_fh)
        return {"status": "failed", "bundle_key": bundle_key,
                "error": str(e), "trace": tb}


def _finish(log_fh):
    if log_fh is not None:
        import sys
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
        log_fh.close()
