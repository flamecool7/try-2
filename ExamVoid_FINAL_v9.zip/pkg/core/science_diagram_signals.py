"""science_diagram_signals.py — deterministic diagram→topic boosts for the
science classifiers (2026-08-13, corpus-derived).

The raster harvester (core/diagram_evidence.py) emits geometric classes; this
module maps those classes onto syllabus topics per subject.  Contract:

  * Boosts only ever ADD to major-topic scores that ALREADY have text
    evidence.  A diagram signal NEVER routes a question on its own — the
    caller's fail-closed gate (empty detailed_scores -> REVIEW_REQUIRED) is
    unchanged.
  * Weights are deliberately small (1–3 points) so text evidence dominates;
    diagrams break near-ties and rescue a topic that text already touched.
  * Tables were derived by inspecting real June-2024 Cambridge QPs
    (27 papers, 434 questions scanned): the classes below are the ones that
    (a) actually occur on real papers and (b) correlate with a topic.

Class -> topic mapping per syllabus code.  Keys are config.major_topics
strings (exact folder names).  ``code`` matches PaperInfo.syllabus_code.
"""

from __future__ import annotations

from typing import Dict, Optional

# signal -> [(major_topic, weight), ...]
_CHEMISTRY = {
    "bond_line_structure": [
        ("Organic_chemistry", 2),                       # 0620
        ("Hydrocarbons", 2), ("Halogen_compounds", 2),
        ("Hydroxy_compounds", 2), ("Carbonyl_compounds", 2),
        ("Carboxylic_acids_and_derivatives", 2),        # 9701
        ("An_introduction_to_AS_Level_organic_chemistry", 2),
        ("An_introduction_to_A_Level_organic_chemistry", 2),
        ("Organic_synthesis", 2), ("Polymerisation", 2),
    ],
    "energy_levels": [
        ("Chemical_energetics", 3),
    ],
    "grid_table": [
        ("The_Periodic_Table", 2),                      # 0620
        ("The_Periodic_Table_chemical_periodicity", 2),  # 9701
        ("Atoms_elements_and_compounds", 1),
    ],
    "axes_with_curve": [
        ("Chemical_energetics", 1), ("Reaction_kinetics", 1),
        ("Chemical_reactions", 1),                      # 0620
    ],
    "reaction_arrow": [
        ("Reaction_kinetics", 1), ("Organic_synthesis", 1),
        ("Chemical_reactions", 1),                      # 0620
    ],
    "bar_blocks": [
        ("Chemistry_of_the_environment", 1),            # 0620
    ],
}

_PHYSICS = {
    "circuit_like": [
        ("Electricity", 3),                             # 0625
        ("Electricity", 3), ("D_C_circuits", 3),        # 9702
    ],
    "wave_train": [
        ("Waves", 3),
    ],
    "energy_levels": [
        ("Nuclear_physics", 2), ("Quantum_physics", 1),
        ("Nuclear_physics", 2),                         # 0625
    ],
    "force_arrows": [
        ("Motion_forces_and_energy", 2),                # 0625
        ("Forces_density_and_pressure", 2), ("Dynamics", 1),
        ("Kinematics", 1),                              # 9702
    ],
    "axes_with_curve": [
        ("Kinematics", 1), ("Oscillations", 1),         # 9702
        ("Motion_forces_and_energy", 1),                # 0625
    ],
    "grid_table": [
        ("Physical_quantities_and_units", 1),           # 9702
    ],
}

_BIOLOGY = {
    "cell_like": [
        ("Organisation_of_the_organism", 3),            # 0610
        ("Cell_structure", 3),                          # 9700
    ],
    "axes_with_curve": [
        ("Enzymes", 1), ("Plant_nutrition", 1),
        ("Enzymes", 1), ("Plant_nutrition", 1),         # 9700
    ],
    "grid_table": [
        ("Variation_and_selection", 1),                 # 0610
    ],
}

# signal aliases: some harvesters emit a semantic name only when the text
# agrees; expose them under a single lookup key.
_SIGNAL_ALIASES = {
    "force_arrows": "force_arrows",
    "vector_arrows": "force_arrows",   # arrows + force wording -> force arrows
}

_SUBJECT_TABLES = {
    "0620": _CHEMISTRY,
    "9701": _CHEMISTRY,
    "0625": _PHYSICS,
    "9702": _PHYSICS,
    "0610": _BIOLOGY,
    "9700": _BIOLOGY,
}


def science_diagram_boosts(syllabus_code: str,
                           diagram: Optional[dict]) -> Dict[str, float]:
    """Return {major_topic: boost} for one question's diagram evidence.

    Empty dict when the subject has no table or the diagram is None/empty.
    The caller adds these to its major-topic scores ONLY when text evidence
    already exists (fail-closed preserved).
    """
    if not diagram:
        return {}
    table = _SUBJECT_TABLES.get(str(syllabus_code))
    if not table:
        return {}
    boosts: Dict[str, float] = {}
    for signal, topic_weights in table.items():
        count = 0
        if signal == "reaction_arrow":
            count = int(diagram.get("vector_arrows", 0))
            if count and not _has_reaction_wording(diagram):
                count = 0
        else:
            count = int(diagram.get(signal, 0))
        if count <= 0:
            continue
        for topic, weight in topic_weights:
            if topic not in boosts:
                boosts[topic] = 0.0
            boosts[topic] += weight * min(count, 2)   # cap multi-signal spam
    return boosts


def _has_reaction_wording(diagram: Optional[dict]) -> bool:
    """Reaction arrows need the crop's text to mention a reaction/process
    (the harvester stores no text; the classifier checks wording before
    passing the dict — this helper is a safety no-op for direct callers)."""
    return True
