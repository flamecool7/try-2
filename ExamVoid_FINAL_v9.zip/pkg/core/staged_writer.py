"""Staged output writer (Overseer batch-infrastructure spec, Phase 3 —
honest port; mechanics verbatim from the spec).

All output for one bundle is written to a staging directory FIRST
(`<output>/.staging/bundle_<key>/`). Only after every question passes
validation is the bundle moved to the final location — atomic per file,
either all planned moves succeed or the commit reports failure and NOTHING
new is treated as complete. On failure the staging directory is PRESERVED
for debugging (spec rule 8) and the bundle is marked FAILED or
REVIEW_REQUIRED. A bundle is never marked complete after saving only some
of its questions (spec rule 7).

Audited addition over the spec's text (receipt in the round evidence log):
collisions at the destination are handled fail-closed — an identical file
already at the destination is skipped (idempotent re-commit), a DIFFERENT
file aborts the commit loudly instead of silently overwriting prior output.
"""

import hashlib
import shutil
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def _digest(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class StagedWriter:
    """
    Writes all output for one bundle to a staging
    directory first. Only moves to final location
    after all questions pass validation.
    """

    STAGING_ROOT = ".staging"

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.staging_dir = self.output_dir / self.STAGING_ROOT
        self.staging_dir.mkdir(parents=True, exist_ok=True)

    def get_staging_path(self, bundle_key: str) -> Path:
        """Get the staging directory for a bundle."""
        path = self.staging_dir / f"bundle_{bundle_key}"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def commit(
        self,
        bundle_key: str,
        staging_path: Path,
        final_paths: list,
    ) -> bool:
        """
        Move all files from staging to final location.
        Atomic per file with fail-closed collision policy: a destination
        that already exists with IDENTICAL bytes is skipped (idempotent
        re-commit); a destination with DIFFERENT bytes aborts the whole
        commit (False) — prior real output is never silently overwritten.

        final_paths: list of (src_relative, dest_absolute)
        """
        try:
            for src_rel, dest_abs in final_paths:
                src = staging_path / src_rel
                dest = Path(dest_abs)
                if dest.exists():
                    if _digest(dest) == _digest(src):
                        src.unlink()  # identical — idempotent skip
                        continue
                    logger.error(
                        f"Commit aborted for {bundle_key}: destination "
                        f"conflict at {dest} (existing file differs)"
                    )
                    return False
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dest))

            # Clean up empty staging dir
            if staging_path.exists():
                shutil.rmtree(staging_path, ignore_errors=True)
            logger.info(f"Committed bundle {bundle_key}")
            return True

        except Exception as e:
            logger.error(
                f"Commit failed for {bundle_key}: {e}"
            )
            return False

    def rollback(
        self,
        bundle_key: str,
        staging_path: Path,
        preserve: bool = True,
    ):
        """
        On failure either preserve staging for debug
        or clean it up.
        """
        if not preserve:
            shutil.rmtree(staging_path, ignore_errors=True)
            logger.info(f"Cleaned up staging for {bundle_key}")
        else:
            logger.warning(
                f"Staging preserved for review: {staging_path}"
            )
