"""mcq_output.py — unified MCQ output helpers (Overseer unified-MCQ spec,
STEP 2; approved decision Q2=additive, Q3=literal, Q4=adapt).

_MS.txt contract (RULES 2/3): exactly one letter A/B/C/D + newline; an EMPTY
file is written when the answer is None/invalid — the file is NEVER skipped
(approved literal reading). The validator flags empty/invalid files as
visible issues, and cross-checks a non-empty letter against metadata.

DEVIATION RECEIPTS (approved additive decision — why the spec's full
metadata writer is NOT ported as-is):
  M1  The spec's `write_mcq_metadata()` builds a THIN 12-field dict and would
      REPLACE the locked rich metadata schema (json_generator canonical
      fields + CLS-5 additive keys; webp hashes/dimensions/topic scores).
      Under Q2=additive, metadata writing stays in OutputManager.save_question
      and MCQ fields arrive via `mcq_metadata_fields()` — two ADDITIVE keys:
      question_type="MCQ" and correct_answer=<letter> (or "" per RULE 5).
      The locked `ms_answer` key is KEPT (validator exemptions R9/R10 and
      bundle_worker verdict reads consume it); correct_answer is its
      exact-mirror alias.
  M2  The spec's file naming `{paper_code}_Q{n}_MS.txt` (9701_s24_11_Q7…)
      conflicts with the locked on-disk base convention
      `{variant}_{Season}_{Year}_Q{n}`. _MS.txt follows the LOCKED base
      (e.g. 22_Spring_2025_Q5_MS.txt) — validators glob `*_MS.txt` so both
      work, but existing banks stay byte-compatible only with the locked
      base. `build_mcq_question_id()` is kept for ID-string semantics and
      tests.
  M3  Spec corruption receipts: `cambridge_qb.mcq_registry` import, `-&gt;`,
      `&gt;`, `*...*` italics-as-code, `[f.name](http://…)`,
      `ms_[path.read](http://path.read)_text` — all de-linkified on write.
  M4  FORBIDDEN_FIELDS kept from the spec for API parity; with additive
      fields they never match anything (documented no-op here).
"""

import json
import logging
from pathlib import Path
from typing import Optional

from .mcq_registry import is_mcq  # noqa: F401  (re-export; RULE 1 single source)

logger = logging.getLogger(__name__)

VALID_ANSWERS = {"A", "B", "C", "D"}

# Placeholder _MS.txt marker for QP-only mode (no MS supplied): the question
# is classified and saved with a sidecar that validators recognise as a
# legal MS-less home, distinct from a real MCQ letter. Never a fabricated
# mark scheme.
PLACEHOLDER_MS_CONTENT = "MS_UNAVAILABLE"


def is_placeholder_ms(content: str) -> bool:
    return str(content).strip().upper() == PLACEHOLDER_MS_CONTENT


def valid_ms_sidecar(content: str) -> bool:
    """True when a _MS.txt sidecar content is legal: a real A-D letter OR
    the QP-only placeholder marker."""
    c = str(content).strip().upper()
    return c in VALID_ANSWERS or c == PLACEHOLDER_MS_CONTENT

FORBIDDEN_FIELDS = {
    "topic_details",
    "primary",
    "secondary",
    "needs_review",
    "topic_scores",
}


def write_mcq_ms(
    folder_path: Path,
    question_id: str,
    answer: Optional[str],
) -> Path:
    """Write the single-letter mark scheme file for one MCQ question.

    One letter + newline; EMPTY when the answer is None/invalid (RULE 3:
    never skip writing). Callers: OutputManager's two MCQ write branches —
    `question_id` is the LOCKED on-disk base name (receipt M2).
    """
    dest = Path(folder_path) / f"{question_id}_MS.txt"

    if answer is None:
        dest.write_text("", encoding="utf-8")
        logger.warning(
            f"No answer available for {question_id}. Empty _MS.txt written."
        )
        return dest

    answer_clean = str(answer).strip().upper()
    if answer_clean not in VALID_ANSWERS:
        logger.error(
            f"Invalid MCQ answer '{answer}' for {question_id}. "
            f"Expected A/B/C/D. Writing empty file."
        )
        dest.write_text("", encoding="utf-8")
        return dest

    dest.write_text(answer_clean + "\n", encoding="utf-8")
    logger.debug(f"MCQ MS written: {dest} -> {answer_clean}")
    return dest


def mcq_metadata_fields(correct_answer: Optional[str]) -> dict:
    """The additive MCQ metadata keys (receipt M1 — used by the locked
    OutputManager writer; RULE 5: question_type + correct_answer)."""
    letter = (str(correct_answer).strip().upper()
              if correct_answer is not None else "")
    if letter not in VALID_ANSWERS:
        letter = ""
    return {
        "question_type": "MCQ",
        "correct_answer": letter,   # exact alias of locked ms_answer
    }


def validate_mcq_ms_file(ms_path: Path) -> bool:
    """Validate an existing _MS.txt: must exist, contain exactly one letter
    A/B/C/D (trailing newline allowed), nothing else."""
    ms_path = Path(ms_path)
    if not ms_path.exists():
        return False
    content = ms_path.read_text(encoding="utf-8").strip()
    if content not in VALID_ANSWERS:
        logger.warning(
            f"Invalid MCQ MS content in {ms_path}: "
            f"'{content}' (expected A/B/C/D)"
        )
        return False
    return True


def build_mcq_question_id(paper_code: str, question_num: int) -> str:
    """Canonical MCQ question ID string, e.g. "9701_s24_11_Q7" (receipt M2:
    ID semantics only — on-disk bases keep the locked convention)."""
    return f"{paper_code}_Q{question_num}"
