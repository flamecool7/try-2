#!/usr/bin/env python3
"""state_mirror.py — RS-13 state-mirror parity layer (state→SQLite cutover, phase 1).

Maintainer mandate 2026-08-11 ("Implement EVERYTHING", recommended options apply).
Dual-write: every `PipelineState.save()` keeps writing the locked, authoritative
`.pipeline_state.json` EXACTLY as before (atomic tmp+replace), and additionally
mirrors the same snapshot into `<output_root>/pipeline.sqlite` — the RS-8 batch
database — so the pending cutover can be validated by COMPARISON, not by hope.

Design pins (fail-closed where it matters, never destructive):
  M1  JSON remains the sole authority. A mirror FAILURE never fails a run —
      it prints a loud [state-mirror] WARNING (JSON byte-content is written
      before the mirror call is even attempted).
  M2  Parity verification is strict: `verify_parity` compares every mirrored
      scalar and per-paper field against the in-memory state and reports the
      exact drift set. Callers may choose to gate on it (run_guarded S8 does).
  M3  Lazy DDL only (CREATE TABLE IF NOT EXISTS) — `core/database.py` is NOT
      amended (RS-10 precedent for ms_fetch_log). WAL + busy_timeout so batch
      workers can mirror concurrently.
  M4  Idempotent UPSERTs keyed on (run_id) / (run_id, paper_code): re-saves
      converge to the latest snapshot; stale rows for deleted paper codes are
      reconciled per save (a run's paper set is append-only in practice).
"""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path
from typing import TYPE_CHECKING, Dict, List, Tuple

if TYPE_CHECKING:  # pragma: no cover
    from .pipeline_state import PipelineState

DB_NAME = "pipeline.sqlite"

_DDL = """
CREATE TABLE IF NOT EXISTS state_runs (
    run_id TEXT PRIMARY KEY,
    subject TEXT NOT NULL,
    syllabus_code TEXT NOT NULL,
    level TEXT NOT NULL,
    started_at REAL NOT NULL,
    total_questions INTEGER NOT NULL,
    total_errors INTEGER NOT NULL,
    mirrored_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS state_papers (
    run_id TEXT NOT NULL,
    paper_code TEXT NOT NULL,
    qp_path TEXT NOT NULL,
    ms_path TEXT,
    er_path TEXT,
    status TEXT NOT NULL,
    questions_found INTEGER NOT NULL,
    questions_saved INTEGER NOT NULL,
    error_message TEXT NOT NULL,
    started_at REAL NOT NULL,
    completed_at REAL NOT NULL,
    PRIMARY KEY (run_id, paper_code)
);
CREATE INDEX IF NOT EXISTS idx_state_papers_status ON state_papers(status);
"""


def _db_path(output_dir: Path) -> Path:
    return Path(output_dir) / DB_NAME


def _connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path), timeout=10.0)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA busy_timeout=10000;")
    return conn


def mirror_state_to_db(state: "PipelineState", output_dir: Path) -> Dict[str, int]:
    """Dual-write the snapshot. Returns counters (for tests/logs).

    Raises on DB errors — the caller (PipelineState.save) catches and warns.
    """
    db = _db_path(output_dir)
    now = time.time()
    with _connect(db) as conn:
        conn.executescript(_DDL)
        conn.execute(
            """INSERT INTO state_runs
               (run_id, subject, syllabus_code, level, started_at,
                total_questions, total_errors, mirrored_at)
               VALUES (?,?,?,?,?,?,?,?)
               ON CONFLICT(run_id) DO UPDATE SET
                 subject=excluded.subject, syllabus_code=excluded.syllabus_code,
                 level=excluded.level, started_at=excluded.started_at,
                 total_questions=excluded.total_questions,
                 total_errors=excluded.total_errors, mirrored_at=excluded.mirrored_at""",
            (state.run_id, state.subject, state.syllabus_code, state.level,
             state.started_at, state.total_questions, state.total_errors, now),
        )
        live = []
        for code, r in state.papers.items():
            live.append(code)
            conn.execute(
                """INSERT INTO state_papers
                   (run_id, paper_code, qp_path, ms_path, er_path, status,
                    questions_found, questions_saved, error_message,
                    started_at, completed_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(run_id, paper_code) DO UPDATE SET
                     qp_path=excluded.qp_path, ms_path=excluded.ms_path,
                     er_path=excluded.er_path, status=excluded.status,
                     questions_found=excluded.questions_found,
                     questions_saved=excluded.questions_saved,
                     error_message=excluded.error_message,
                     started_at=excluded.started_at,
                     completed_at=excluded.completed_at""",
                (state.run_id, code, r.qp_path, r.ms_path, r.er_path,
                 r.status.value, r.questions_found, r.questions_saved,
                 r.error_message, r.started_at, r.completed_at),
            )
        if live:
            marks = ",".join("?" for _ in live)
            conn.execute(
                f"DELETE FROM state_papers WHERE run_id=? AND paper_code NOT IN ({marks})",
                (state.run_id, *live),
            )
        else:
            conn.execute("DELETE FROM state_papers WHERE run_id=?", (state.run_id,))
    return {"papers_mirrored": len(live)}


def verify_parity(state: "PipelineState", output_dir: Path) -> Tuple[bool, List[str]]:
    """Compare the in-memory snapshot against the DB mirror field-by-field.

    Returns (ok, drift_lines). ok=False only when the mirror EXISTS but
    disagrees; a missing DB/table is reported as drift too (caller decides).
    """
    drift: List[str] = []
    db = _db_path(output_dir)
    if not db.exists():
        return False, ["mirror DB absent"]
    with _connect(db) as conn:
        try:
            run = conn.execute(
                "SELECT subject, syllabus_code, level, started_at, "
                "total_questions, total_errors FROM state_runs WHERE run_id=?",
                (state.run_id,),
            ).fetchone()
        except sqlite3.OperationalError:
            return False, ["state_runs table absent (mirror never wrote)"]
        if run is None:
            drift.append(f"run {state.run_id} missing from mirror")
        else:
            exp = (state.subject, state.syllabus_code, state.level,
                   state.started_at, state.total_questions, state.total_errors)
            labels = ("subject", "syllabus_code", "level", "started_at",
                      "total_questions", "total_errors")
            for lab, got, want in zip(labels, run, exp):
                if got != want:
                    drift.append(f"run.{lab}: db={got!r} != json={want!r}")
        rows = conn.execute(
            """SELECT paper_code, qp_path, ms_path, er_path, status,
                      questions_found, questions_saved, error_message,
                      started_at, completed_at
               FROM state_papers WHERE run_id=?""",
            (state.run_id,),
        ).fetchall() if run is not None or not drift else []
    db_codes = {r[0] for r in rows}
    json_codes = set(state.papers)
    for missing_in_db in sorted(json_codes - db_codes):
        drift.append(f"paper {missing_in_db} missing from mirror")
    for extra_in_db in sorted(db_codes - json_codes):
        drift.append(f"paper {extra_in_db} stale in mirror")
    for row in rows:
        code = row[0]
        if code not in state.papers:
            continue
        r = state.papers[code]
        exp = (code, r.qp_path, r.ms_path, r.er_path, r.status.value,
               r.questions_found, r.questions_saved, r.error_message,
               r.started_at, r.completed_at)
        labels = ("paper_code", "qp_path", "ms_path", "er_path", "status",
                  "questions_found", "questions_saved", "error_message",
                  "started_at", "completed_at")
        for lab, got, want in zip(labels, row, exp):
            if got != want:
                drift.append(f"{code}.{lab}: db={got!r} != json={want!r}")
    return (not drift, drift)
