"""ms_fetcher.py — online missing mark scheme resolver (Overseer spec).

Opt-in only via --fetch-missing-ms. Never runs automatically. All downloads
are verified BEFORE use; any verification failure -> REVIEW_REQUIRED, never
into the pipeline. Every attempt is logged to ms_fetch_log (url, source,
sha256, timestamp). Rate limiting of 2s between requests is mandatory.

PREMISE RECEIPTS (audited against the REAL code BEFORE writing):
  * The spec targeted the fictional `cambridge_qb` package (same
    hallucination busted in the batch round). Real home: core/ms_fetcher.py,
    CLI wiring in run_pipeline.py (RS-8), report method on Preflight (RS-8).
  * db contract verified REAL: database at <output>/pipeline.sqlite (spec
    matches batch_runner.py EXACTLY), bundles has all columns the spec
    queries, get_pending_bundles() LEFT JOINs files -> ms_path comes from
    ms_file_id, so updating ms_file_id is SUFFICIENT for the next run to
    consume a fetched MS.
  * requirements phase is a NO-OP: requests>=2.31.0 already listed.

FIXES APPLIED ON WRITE (spec bugs, receipted):
  F1  markdown corruption de-linkified (family: [x](http://y), *it* markers,
      &gt;/&lt;/&amp;, -&gt;). Spec's own module would not even parse.
  F2  _update_bundle_ms: spec used `INSERT OR REPLACE INTO files` — REPLACE
      is DELETE+INSERT (mints a new rowid, the exact orphan-FK bug class
      receipted in RS-8) and NULLs the identity columns. Ported to
      Database.register_file (id-preserving UPSERT, single-source sha256).
      bundles.ms_file_id UPDATE stays raw SQL here because Database has no
      post-hoc ms setter and database.py is RS-8 LOCKED (not amended).
  F3  resolve_all passed "', '.join([])" as the review reason (empty).
      Now passes result.error (the verifier's actual failure_reasons).
  F4  _check_session: 'sp' (specimen) seasons had no season words -> ANY
      specimen MS could never verify. Specimen now checks the year only.
  F5  print_manifest_report: LEFT JOIN ms_fetch_log crashes when the table
      does not exist yet. ensure_fetch_log is called first (idempotent).
  F6  Dry-run attempts are NOT written to ms_fetch_log (RULE 3 covers real
      downloads; dry-run rows would poison the report's MAX(id) latest-fetch
      join).
  F7  resolve_all's early-return summary lacked the "review" key ->
      normalised to a constant shape.
  F8  RULE 7: missing `requests` -> the EXACT required message
      "Install requests: pip install requests>=2.31.0".
  F9  year_4 = "20"+year_short kept as the spec wrote it; receipted
      limitation: pre-2000 papers are out of scope for URL building.
"""

from __future__ import annotations

import hashlib
import logging
import re
import sqlite3
import time
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import List, Optional
from urllib.parse import urljoin

from .database import Database, sha256 as _file_sha256  # RS-8 single-source

logger = logging.getLogger(__name__)

# ── CONSTANTS ──────────────────────────────────────────

# Mega-spec Fix 6 (2026-08-12): allowed source ORDER is contractual —
#   1. Cambridge International official, 2. pastpapers.co,
#   3. other explicitly-approved,  else REVIEW_REQUIRED.
# 'papers.co' is NOT and must never be a source (spec, verbatim).
# The official slot attempts Cambridge's public programme pages; they are
# HTML without %PDF magic for legacy sessions, fail verification fast, and
# honestly fall through to pastpapers.co. No fabricated URLs, no guessing.
SOURCES = [
    {
        "name":     "cambridge_international_official",
        "base_url": "https://www.cambridgeinternational.org/",
        "priority": 1,
    },
    {
        "name":     "pastpapers.co",
        "base_url": "https://pastpapers.co/",
        "priority": 2,
    },
]

REQUEST_TIMEOUT = 30            # seconds per request
REQUEST_DELAY = 2.0             # seconds between requests (RULE 5: mandatory)
MAX_RETRIES = 2                 # retries per source
MAX_FILE_SIZE = 50_000_000      # 50MB max download

PDF_MAGIC_BYTES = b"%PDF"
MIN_PDF_SIZE = 5_000            # 5KB minimum real PDF

SEASON_TO_CODE = {
    "s": "s", "mj": "s", "m_j": "s", "summer": "s", "may": "s", "june": "s",
    "w": "w", "on": "w", "o_n": "w", "winter": "w", "october": "w", "november": "w",
    "m": "m", "fm": "m", "f_m": "m", "spring": "m", "march": "m",
    "sp": "sp", "z": "sp", "y": "sp", "spec": "sp", "specimen": "sp",
}

REQUESTS_MISSING_MSG = "Install requests: pip install requests>=2.31.0"


@dataclass
class FetchResult:
    """Result of one MS fetch attempt."""
    success:      bool
    bundle_key:   str
    source:       str
    url:          str
    local_path:   Optional[Path]
    sha256:       Optional[str]
    error:        Optional[str]
    verified:     bool
    retrieved_at: float


@dataclass
class VerificationResult:
    """Result of PDF identity verification."""
    passed:            bool
    is_pdf:            bool
    syllabus_matches:  bool
    component_matches: bool
    session_matches:   bool
    is_markscheme:     bool
    opens_cleanly:     bool
    failure_reasons:   List[str]


# Cambridge's public past-paper page slugs.  These are page indexes, not
# guessed PDF filenames: the official page is parsed for an exact year/season/
# component mark-scheme link before the approved mirror candidates are tried.
OFFICIAL_PAGE_SLUGS = {
    "0610": "cambridge-igcse-biology-0610",
    "0620": "cambridge-igcse-chemistry-0620",
    "0625": "cambridge-igcse-physics-0625",
    "0580": "cambridge-igcse-mathematics-0580",
    "0606": "cambridge-igcse-additional-mathematics-0606",
    "0478": "cambridge-igcse-computer-science-0478",
    "0455": "cambridge-igcse-economics-0455",
    "0450": "cambridge-igcse-business-studies-0450",
    "0475": "cambridge-igcse-literature-in-english-0475",
    "0470": "cambridge-igcse-history-0470",
    "0417": "cambridge-igcse-information-and-communication-technology-0417",
    "0460": "cambridge-igcse-geography-0460",
    "9700": "cambridge-international-as-and-a-level-biology-9700",
    "9701": "cambridge-international-as-and-a-level-chemistry-9701",
    "9702": "cambridge-international-as-and-a-level-physics-9702",
    "9709": "cambridge-international-as-and-a-level-mathematics-9709",
    "9231": "cambridge-international-as-and-a-level-further-mathematics-9231",
    "9618": "cambridge-international-as-and-a-level-computer-science-9618",
    "9708": "cambridge-international-as-and-a-level-economics-9708",
    "9609": "cambridge-international-as-and-a-level-business-9609",
    "9695": "cambridge-international-as-and-a-level-english-literature-9695",
    "9489": "cambridge-international-as-and-a-level-history-9489",
    "9626": "cambridge-international-as-and-a-level-information-technology-9626",
    "9696": "cambridge-international-as-and-a-level-geography-9696",
}

SEASON_PAGE_WORDS = {
    "s": ("may", "june", "summer"),
    "w": ("october", "november", "winter"),
    "m": ("february", "march", "spring"),
    "sp": ("specimen", "sample"),
}


class _OfficialLinkParser(HTMLParser):
    """Collect anchor text and hrefs without adding a BeautifulSoup runtime dependency."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self._href = None
        self._text = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        attrs = dict(attrs)
        self._href = attrs.get("href")
        self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.links.append((self._href, " ".join(self._text)))
            self._href = None
            self._text = []


# ══════════════════════════════════════════════════════
# LAYER 1: URL BUILDER
# ══════════════════════════════════════════════════════

class URLBuilder:
    """Builds candidate URLs for mark scheme PDFs (multiple patterns per
    source because hosting sites use inconsistent formats)."""

    def build_official_index_url(self, syllabus_code: str) -> Optional[str]:
        slug = OFFICIAL_PAGE_SLUGS.get(str(syllabus_code))
        if not slug:
            return None
        return f"https://www.cambridgeinternational.org/programmes-and-qualifications/{slug}/past-papers/"

    def build_pastpapers_co(
        self,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
    ) -> List[str]:
        """Candidate pastpapers.co URLs (directory structure varies).

        The first two legacy patterns are retained for compatibility.  The
        third is the currently working CAIE directory layout, including the
        session folder; this is important because some older mirror URLs serve
        a truncated or wrong-identity PDF under the same filename.
        """
        base = "https://pastpapers.co"
        season_n = SEASON_TO_CODE.get(season.lower(), season)
        year_4 = "20" + year_short            # F9: pre-2000 out of scope
        filename = f"{syllabus_code}_{season_n}{year_short}_ms_{component}.pdf"

        level_paths = {
            "9": "a-level",
            "0": "igcse",
            "2": "o-level", "4": "o-level", "5": "o-level", "7": "o-level",
        }
        level_path = level_paths.get(syllabus_code[0], "a-level")
        page_level = "A-Level" if level_path == "a-level" else "IGCSE"
        subject_slug = {
            "0610": "Biology", "0620": "Chemistry", "0625": "Physics",
            "0580": "Mathematics", "0606": "Additional-Mathematics",
            "0478": "Computer-Science", "0455": "Economics",
            "0450": "Business-Studies", "0475": "Literature-in-English",
            "0470": "History", "0417": "ICT", "0460": "Geography",
            "9700": "Biology", "9701": "Chemistry", "9702": "Physics",
            "9709": "Mathematics", "9231": "Further-Mathematics",
            "9618": "Computer-Science", "9708": "Economics",
            "9609": "Business", "9695": "English-Literature",
            "9489": "History", "9626": "Information-Technology",
            "9696": "Geography",
        }.get(str(syllabus_code), "")
        season_folder = {
            "s": "May-June", "w": "October-November",
            "m": "February-March", "sp": "Specimen",
        }.get(season_n, season_n)
        canonical = (
            f"{base}/caie/{page_level}/{subject_slug}-{syllabus_code}/"
            f"{year_4}-{season_folder}/{filename}"
            if subject_slug else ""
        )

        urls = [
            f"{base}/cie/{level_path}/{syllabus_code}/{year_4}/{filename}",
            f"{base}/cie/{level_path}/{syllabus_code}/{filename}",
        ]
        if canonical:
            urls.append(canonical)
        urls.append(f"{base}/download/{syllabus_code}/{filename}")
        return urls

    @staticmethod
    def extract_official_ms_urls(
        html: str,
        page_url: str,
        syllabus_code: str,
        season: str,
        year_short: str,
        component: str,
    ) -> List[str]:
        """Extract exact MS PDF links from a Cambridge past-papers page.

        The page is only an index; the returned href must be a PDF and its
        anchor must independently identify the year, session, component, and
        mark-scheme artifact.  Ambiguous links are ignored rather than guessed.
        """
        parser = _OfficialLinkParser()
        try:
            parser.feed(html)
        except Exception:
            return []
        year_4 = "20" + str(year_short)
        season_n = SEASON_TO_CODE.get(str(season).lower(), str(season).lower())
        season_words = SEASON_PAGE_WORDS.get(season_n, ())
        component_re = re.compile(
            rf"(?:\bpaper|\bcomponent)[ _-]*0?{re.escape(str(component))}\b|"
            rf"[_-]ms[_-]?0?{re.escape(str(component))}(?:[_-]|\.)|"
            rf"[_-]0?{re.escape(str(component))}(?:[_-]|\.)",
            re.IGNORECASE,
        )
        # The first alternative covers human-readable anchor text; the latter
        # two cover filenames such as ``9701_s24_ms_22.pdf``.
        found = []
        for raw_href, raw_text in parser.links:
            if not raw_href:
                continue
            href = urljoin(page_url, raw_href)
            haystack = f"{raw_text} {href}".lower()
            if ".pdf" not in href.lower():
                continue
            if "mark scheme" not in haystack and "mark-scheme" not in haystack:
                continue
            if year_4 not in haystack and str(year_short) not in haystack:
                continue
            if season_words and not any(word in haystack for word in season_words):
                continue
            if not component_re.search(haystack):
                # A few official pages use a bare 'Paper 22' label while the
                # href carries only an opaque Images id.  Accept that exact
                # human label, but never a bare 'Paper 2' substring.
                if not re.search(rf"\bpaper\s*0?{re.escape(str(component))}\b", haystack, re.IGNORECASE):
                    continue
            if href not in found:
                found.append(href)
        return found

    def build_all(
        self,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
    ) -> List[dict]:
        """All candidate URLs across allowed sources -> [{source, url}].

        The official entry is an index page resolved at fetch time; the
        approved mirror candidates follow in priority order.  Four candidates
        are retained so dry-run output remains stable and bounded.
        """
        past = self.build_pastpapers_co(
            syllabus_code, season, year_short, component)
        candidates = []
        official = self.build_official_index_url(syllabus_code)
        if official:
            candidates.append({"source": "cambridge_international_official", "url": official})
        # Prefer the canonical session directory before the two legacy forms.
        ordered_past = ([past[2]] if len(past) > 2 else []) + past[:2]
        for url in ordered_past:
            candidates.append({"source": "pastpapers.co", "url": url})
        return candidates[:4]


# ══════════════════════════════════════════════════════
# LAYER 2: DOWNLOADER
# ══════════════════════════════════════════════════════

class Downloader:
    """Downloads with rate limiting, retries, and size validation."""

    def __init__(self):
        self._session = None
        self._last_request_at = 0.0

    def _get_session(self):
        if self._session is None:
            try:
                import requests
                from requests.adapters import HTTPAdapter
                from urllib3.util.retry import Retry
            except ImportError:
                raise RuntimeError(REQUESTS_MISSING_MSG)   # RULE 7 (F8)

            session = requests.Session()
            session.headers.update({
                "User-Agent": "Mozilla/5.0 (compatible; CambridgeQBGenerator/1.0)",
                "Accept":     "application/pdf,text/html,*/*",
            })
            retry = Retry(
                total=MAX_RETRIES,
                backoff_factor=1.0,
                status_forcelist=[429, 500, 502, 503, 504],
            )
            adapter = HTTPAdapter(max_retries=retry)
            session.mount("https://", adapter)
            session.mount("http://", adapter)
            self._session = session
        return self._session

    def _throttle(self):
        """Keep the mandatory delay between every network request."""
        now = time.monotonic()
        wait = REQUEST_DELAY - (now - self._last_request_at)
        if wait > 0:
            time.sleep(wait)
        self._last_request_at = time.monotonic()

    def fetch_text(self, url: str) -> "tuple[Optional[str], Optional[str]]":
        """Fetch an official index page without treating HTML as a PDF."""
        try:
            session = self._get_session()
        except RuntimeError as e:
            return None, str(e)
        try:
            self._throttle()
            response = session.get(url, timeout=REQUEST_TIMEOUT, stream=False)
            if response.status_code == 404:
                return None, f"404 Not Found: {url}"
            if response.status_code != 200:
                return None, f"HTTP {response.status_code}: {url}"
            content = response.content
            if len(content) > 10_000_000:
                return None, f"Official index too large (>10000000B): {url}"
            return content.decode(response.encoding or "utf-8", errors="replace"), None
        except Exception as e:
            return None, str(e)

    def download(self, url: str, dest: Path) -> "tuple[bool, Optional[str]]":
        """Download url -> dest. Returns (success, error_message)."""
        try:
            session = self._get_session()
        except RuntimeError as e:                       # requests missing
            return False, str(e)
        try:
            self._throttle()
            response = session.get(url, timeout=REQUEST_TIMEOUT, stream=True)

            if response.status_code == 404:
                return False, f"404 Not Found: {url}"
            if response.status_code != 200:
                return False, f"HTTP {response.status_code}: {url}"

            content_type = response.headers.get("content-type", "").lower()
            if "text/html" in content_type and "pdf" not in content_type:
                return False, f"Response is HTML not PDF: {url}"

            dest.parent.mkdir(parents=True, exist_ok=True)
            downloaded = 0
            with open(dest, "wb") as f:
                for chunk in response.iter_content(65536):
                    downloaded += len(chunk)
                    if downloaded > MAX_FILE_SIZE:
                        dest.unlink(missing_ok=True)
                        return False, f"File too large (>{MAX_FILE_SIZE}B): {url}"
                    f.write(chunk)

            if downloaded < MIN_PDF_SIZE:
                dest.unlink(missing_ok=True)
                return False, f"File too small ({downloaded}B): {url}"

            logger.debug(f"Downloaded {downloaded}B from {url}")
            return True, None
        except Exception as e:
            dest.unlink(missing_ok=True)
            return False, str(e)

    def close(self):
        if self._session:
            self._session.close()
            self._session = None
        self._last_request_at = 0.0


# ══════════════════════════════════════════════════════
# LAYER 3: VERIFIER
# ══════════════════════════════════════════════════════

class PDFVerifier:
    """Verifies a downloaded PDF matches the expected identity BEFORE it is
    used. All checks must pass; any failure -> REVIEW_REQUIRED (RULE 2)."""

    MS_SIGNALS = [
        "mark scheme",
        "marking scheme",
        "answers and mark scheme",
        "suggested answers",
        "acceptable answers",
        "indicative content",
        "award marks",
    ]
    QP_SIGNALS = [
        "answer all questions",
        "write your answer",
        "candidate number",
        "instructions to candidates",
    ]

    def verify(
        self,
        pdf_path:      Path,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
    ) -> VerificationResult:
        reasons = []

        is_pdf = self._check_is_pdf(pdf_path)
        if not is_pdf:
            reasons.append("File is not a valid PDF")

        opens_cleanly = False
        text = ""
        if is_pdf:
            opens_cleanly, text = self._check_opens(pdf_path)
            if not opens_cleanly:
                reasons.append("PDF fails to open cleanly")

        syllabus_matches = False
        if opens_cleanly:
            syllabus_matches = syllabus_code in text
            if not syllabus_matches:
                reasons.append(
                    f"Syllabus code {syllabus_code} not found in PDF content")

        component_matches = False
        if opens_cleanly:
            component_matches = self._check_component(text, component)
            if not component_matches:
                reasons.append(
                    f"Component {component} not found in PDF content")

        session_matches = False
        if opens_cleanly:
            session_matches = self._check_session(text, season, year_short)
            if not session_matches:
                reasons.append(
                    f"Session {season}{year_short} not confirmed in PDF content")

        is_markscheme = False
        if opens_cleanly:
            is_markscheme = self._check_is_ms(text)
            if not is_markscheme:
                reasons.append("PDF does not appear to be a mark scheme")

        passed = (is_pdf and opens_cleanly and syllabus_matches
                  and component_matches and session_matches and is_markscheme)
        return VerificationResult(
            passed=passed,
            is_pdf=is_pdf,
            syllabus_matches=syllabus_matches,
            component_matches=component_matches,
            session_matches=session_matches,
            is_markscheme=is_markscheme,
            opens_cleanly=opens_cleanly,
            failure_reasons=reasons,
        )

    def _check_is_pdf(self, path: Path) -> bool:
        try:
            with open(path, "rb") as f:
                return f.read(4) == PDF_MAGIC_BYTES
        except Exception:
            return False

    def _check_opens(self, path: Path) -> "tuple[bool, str]":
        try:
            import fitz
            doc = fitz.open(str(path))
            text = ""
            for page in doc:
                text += page.get_text("text")
            doc.close()
            return True, text.lower()
        except Exception:
            return False, ""

    def _check_component(self, text: str, component: str) -> bool:
        paper_num = component[0] if component else ""
        variant = component[1] if len(component) > 1 else ""
        signals = [
            f"paper {paper_num}",
            f"/{component}",
            f"component {component}",
        ]
        if variant:
            signals.append(f"variant {variant}")
        return any(s in text for s in signals)

    def _check_session(self, text: str, season: str, year_short: str) -> bool:
        year_4 = "20" + year_short
        season_words = {
            "s":  ["may", "june", "summer"],
            "mj": ["may", "june", "summer"],
            "w":  ["october", "november", "winter"],
            "on": ["october", "november", "winter"],
            "m":  ["february", "march", "spring"],
            "fm": ["february", "march", "spring"],
        }
        season_n = SEASON_TO_CODE.get(season.lower(), season)
        words = season_words.get(season_n, [])
        year_ok = year_4 in text or year_short in text
        if season_n == "sp":
            return year_ok            # F4: specimen papers name no months
        season_ok = any(w in text for w in words)
        return year_ok and season_ok

    def _check_is_ms(self, text: str) -> bool:
        has_ms_signal = any(s in text for s in self.MS_SIGNALS)
        has_qp_signal = any(s in text for s in self.QP_SIGNALS)
        if has_qp_signal and not has_ms_signal:
            return False
        return has_ms_signal


# ══════════════════════════════════════════════════════
# LAYER 4: CACHE MANAGER
# ══════════════════════════════════════════════════════

class MSCache:
    """Local cache of downloaded MS PDFs — SEPARATE from the papers input
    dir; downloaded files never overwrite user-provided files (RULE 4)."""

    def __init__(self, cache_dir: Path):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def get_cache_path(self, syllabus_code: str, season: str,
                       year_short: str, component: str) -> Path:
        filename = f"{syllabus_code}_{season}{year_short}_ms_{component}.pdf"
        return self.cache_dir / syllabus_code / filename

    def is_cached(self, syllabus_code: str, season: str,
                  year_short: str, component: str) -> bool:
        path = self.get_cache_path(syllabus_code, season, year_short, component)
        return path.exists() and path.stat().st_size > MIN_PDF_SIZE

    def compute_sha256(self, path: Path) -> str:
        return _file_sha256(Path(path))   # single-source hasher (RS-8)


# ══════════════════════════════════════════════════════
# LAYER 5: FETCH LOG (SQLite extension — lazily created;
#          database.py is RS-8 LOCKED and deliberately not amended, F2)
# ══════════════════════════════════════════════════════

FETCH_LOG_SCHEMA = """
CREATE TABLE IF NOT EXISTS ms_fetch_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    bundle_key     TEXT    NOT NULL,
    syllabus_code  TEXT    NOT NULL,
    season         TEXT    NOT NULL,
    year           TEXT    NOT NULL,
    component      TEXT    NOT NULL,
    source         TEXT,
    url            TEXT,
    local_path     TEXT,
    sha256         TEXT,
    verified       INTEGER DEFAULT 0,
    success        INTEGER DEFAULT 0,
    error          TEXT,
    retrieved_at   REAL,
    created_at     REAL    DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_fetch_bundle
    ON ms_fetch_log(bundle_key);
"""


def ensure_fetch_log(db_path: Path):
    """Add the fetch log table to the existing database (idempotent)."""
    conn = sqlite3.connect(str(db_path))
    conn.executescript(FETCH_LOG_SCHEMA)
    conn.commit()
    conn.close()


def log_fetch_result(db_path: Path, result: FetchResult):
    """Record one fetch attempt (RULE 3: url, source, sha256, timestamp)."""
    conn = sqlite3.connect(str(db_path))
    parts = result.bundle_key.split("_")
    conn.execute("""
        INSERT INTO ms_fetch_log
        (bundle_key, syllabus_code, season, year,
         component, source, url, local_path, sha256,
         verified, success, error, retrieved_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        result.bundle_key,
        parts[0] if parts else "",
        parts[1][:1] if len(parts) > 1 else "",
        parts[1][1:] if len(parts) > 1 else "",
        parts[2] if len(parts) > 2 else "",
        result.source,
        result.url,
        str(result.local_path) if result.local_path else None,
        result.sha256,
        1 if result.verified else 0,
        1 if result.success else 0,
        result.error,
        result.retrieved_at,
    ))
    conn.commit()
    conn.close()


# ══════════════════════════════════════════════════════
# MASTER ORCHESTRATOR
# ══════════════════════════════════════════════════════

class MissingMSResolver:
    """Finds bundles with missing mark schemes and fetches them from online
    sources. Only runs when --fetch-missing-ms is passed. Never modifies
    already-complete bundles."""

    def __init__(self, db_path: Path, cache_dir: Path, dry_run: bool = False):
        self.db_path = Path(db_path)
        self.cache_dir = Path(cache_dir)
        self.dry_run = dry_run
        self.url_builder = URLBuilder()
        self.downloader = Downloader()
        self.verifier = PDFVerifier()
        self.cache = MSCache(cache_dir)
        self.db = Database(self.db_path)      # RS-8 WAL/register_file API (F2)
        ensure_fetch_log(self.db_path)

    def resolve_all(self) -> dict:
        """Fetch MS for every stored bundle whose ms_file_id IS NULL."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        missing = conn.execute("""
            SELECT b.id,
                   b.bundle_key,
                   b.syllabus_code,
                   b.season,
                   b.year,
                   b.component,
                   b.status,
                   b.ms_file_id
            FROM bundles b
            WHERE b.ms_file_id IS NULL
            AND   b.status IN ('pending', 'failed')
            ORDER BY b.id ASC
        """).fetchall()
        conn.close()

        if not missing:
            print("No bundles with missing mark schemes found.")
            return {"found": 0, "resolved": 0, "review": 0, "failed": 0}  # F7

        print(f"Found {len(missing)} bundles with missing MS. Attempting to fetch...")
        if self.dry_run:
            print("DRY RUN: showing URLs only, not downloading")

        resolved = 0
        failed = 0
        review = 0

        for row in missing:
            result = self._resolve_one(
                bundle_id=row["id"],
                bundle_key=row["bundle_key"],
                syllabus_code=row["syllabus_code"],
                season=row["season"],
                year_short=row["year"],
                component=row["component"],
            )

            if result.success and result.verified:
                resolved += 1
                self._update_bundle_ms(
                    row["id"], result.local_path,
                    syllabus_code=row["syllabus_code"], season=row["season"],
                    year_short=row["year"], component=row["component"],
                )
                print(f"  ✅ {row['bundle_key']}: MS found at {result.source}")
            elif result.success and not result.verified:
                review += 1
                print(f"  👁  {row['bundle_key']}: Downloaded but verification "
                      f"failed — REVIEW_REQUIRED")
                self._mark_review(
                    row["id"],
                    f"MS downloaded but failed verification: {result.error}")  # F3
            else:
                failed += 1
                print(f"  ❌ {row['bundle_key']}: Not found on any source")

            if not self.dry_run:                      # F6: dry-runs not logged
                log_fetch_result(self.db_path, result)

            if not self.dry_run:
                time.sleep(REQUEST_DELAY)             # RULE 5: mandatory

        self.downloader.close()

        summary = {
            "found": len(missing),
            "resolved": resolved,
            "review": review,
            "failed": failed,
        }
        print("\nMS Fetch Summary:")
        print(f"  Found missing:  {summary['found']}")
        print(f"  ✅ Resolved:    {summary['resolved']}")
        print(f"  👁  Review:     {summary['review']}")
        print(f"  ❌ Not found:   {summary['failed']}")
        return summary

    def _resolve_one(
        self,
        bundle_id:     int,
        bundle_key:    str,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
    ) -> FetchResult:
        """Fetch and verify one MS, official index first, then mirror URLs."""
        cached_path = self.cache.get_cache_path(
            syllabus_code, season, year_short, component)
        if cached_path.exists() and cached_path.stat().st_size > MIN_PDF_SIZE:
            # A cache hit is not trusted merely because it is large.  Verify it
            # again so a stale/wrong-session PDF can never enter a later run.
            cached_verification = self.verifier.verify(
                cached_path, syllabus_code, season, year_short, component)
            if cached_verification.passed:
                checksum = self.cache.compute_sha256(cached_path)
                logger.info(f"Using verified cached MS for {bundle_key}: {cached_path.name}")
                return FetchResult(
                    success=True, bundle_key=bundle_key, source="local_cache",
                    url="", local_path=cached_path, sha256=checksum, error=None,
                    verified=True, retrieved_at=time.time())
            logger.warning(
                "Rejecting stale/unverified cache %s: %s",
                cached_path,
                "; ".join(cached_verification.failure_reasons),
            )
            failed_cache = cached_path.with_suffix(".unverified.pdf")
            failed_cache.unlink(missing_ok=True)
            cached_path.rename(failed_cache)

        candidates = self.url_builder.build_all(
            syllabus_code, season, year_short, component)
        dest_path = cached_path

        if self.dry_run:
            print(f"  {bundle_key}: would try {len(candidates)} URLs:")
            for c in candidates:
                print(f"    [{c['source']}] {c['url']}")
            return FetchResult(
                success=False, bundle_key=bundle_key, source="dry_run",
                url=candidates[0]["url"] if candidates else "",
                local_path=None, sha256=None, error="dry_run",
                verified=False, retrieved_at=time.time())

        dest_path.parent.mkdir(parents=True, exist_ok=True)

        def download_and_verify(source: str, url: str) -> Optional[FetchResult]:
            success, error = self.downloader.download(url, dest_path)
            if not success:
                logger.debug(f"Download failed: {error}")
                return None

            verification = self.verifier.verify(
                pdf_path=dest_path,
                syllabus_code=syllabus_code,
                season=season,
                year_short=year_short,
                component=component,
            )
            checksum = self.cache.compute_sha256(dest_path)
            if verification.passed:
                return FetchResult(
                    success=True, bundle_key=bundle_key, source=source, url=url,
                    local_path=dest_path, sha256=checksum, error=None,
                    verified=True, retrieved_at=time.time())

            # Downloaded but verification failed: keep bytes for a human and
            # stop this source chain. Never silently try to use a different
            # identity under the same filename.
            failed_path = dest_path.with_suffix(".unverified.pdf")
            failed_path.unlink(missing_ok=True)
            dest_path.rename(failed_path)
            reasons = "; ".join(verification.failure_reasons)
            logger.warning(f"Verification failed for {url}: {reasons}")
            return FetchResult(
                success=True, bundle_key=bundle_key, source=source, url=url,
                local_path=failed_path, sha256=checksum, error=reasons,
                verified=False, retrieved_at=time.time())

        for candidate in candidates:
            source = candidate["source"]
            url = candidate["url"]
            logger.debug(f"Trying [{source}]: {url}")

            if source == "cambridge_international_official":
                html, error = self.downloader.fetch_text(url)
                if not html:
                    logger.debug(f"Official index unavailable: {error}")
                    continue
                direct_urls = self.url_builder.extract_official_ms_urls(
                    html, url, syllabus_code, season, year_short, component)
                if not direct_urls:
                    logger.debug("Official index had no unambiguous matching MS link")
                    continue
                for direct_url in direct_urls:
                    result = download_and_verify(source, direct_url)
                    if result is not None:
                        return result
                continue

            result = download_and_verify(source, url)
            if result is not None:
                return result

        return FetchResult(
            success=False, bundle_key=bundle_key, source="", url="",
            local_path=None, sha256=None, error="Not found on any source",
            verified=False, retrieved_at=time.time())

    def _update_bundle_ms(
        self,
        bundle_id:     int,
        ms_path:       Path,
        syllabus_code: str = "",
        season:        str = "",
        year_short:    str = "",
        component:     str = "",
    ):
        """Register the fetched MS (id-preserving UPSERT — F2) and point the
        bundle at it. Next run_pipeline picks it up via get_pending_bundles'
        files JOIN (verified against the RS-8 schema)."""
        file_id = self.db.register_file(
            path=Path(ms_path), kind="ms",
            syllabus_code=syllabus_code, season=season,
            year=year_short, component=component,
            paper_format="FETCHED_MS",
        )
        conn = sqlite3.connect(str(self.db_path))
        try:
            conn.execute("UPDATE bundles SET ms_file_id=? WHERE id=?",
                         (file_id, bundle_id))
            conn.commit()
        finally:
            conn.close()

    def _mark_review(self, bundle_id: int, reason: str):
        """Mark bundle as needing review (RULE 2)."""
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("""
            UPDATE bundles
            SET    status='review_required',
                   error_message=?
            WHERE  id=?
        """, (reason, bundle_id))
        conn.commit()
        conn.close()
