"""Cambridge Mathematics reference-topic loaders.

9709 and 9231 use their approved paper-reference files; 0580 and 0606 use
question-level official topic arrays.  Returned folder names are always the
configured names-only topic strings; numeric syllabus identifiers are never
introduced into routing names.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
import re
from typing import Dict, List, Sequence

REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Mathematics_9709 References.txt"
_HEADING = re.compile(r"\(P([1-6])\)\s*$")


@lru_cache(maxsize=1)
def load_9709_reference() -> Dict[int, List[str]]:
    """Load the uploaded reference file, preserving each topic string exactly."""
    if not REFERENCE_PATH.exists():
        raise FileNotFoundError(f"Mathematics 9709 reference missing: {REFERENCE_PATH}")
    sections: Dict[int, List[str]] = {}
    current_paper: int | None = None
    for raw_line in REFERENCE_PATH.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current_paper = int(heading.group(1))
            sections.setdefault(current_paper, [])
            continue
        if current_paper is None:
            raise ValueError(f"Topic before P1–P6 heading in {REFERENCE_PATH}: {line!r}")
        # The file's literal topic spelling is canonical; never title-case,
        # replace underscores, or otherwise transform it.
        sections[current_paper].append(line)
    if set(sections) != {1, 2, 3, 4, 5, 6}:
        raise ValueError("Mathematics 9709 reference must define exactly P1 through P6")
    if any(not topics for topics in sections.values()):
        raise ValueError("Every Mathematics 9709 paper section must contain topics")
    return sections


def allowed_topics_for_paper(paper_number: int) -> List[str]:
    return list(load_9709_reference().get(int(paper_number), []))


# Matching aliases are classification evidence only. Values always come from
# the reference file and are returned unchanged.
_TOPIC_KEYWORDS = {
    "Quadratics": ("quadratic", "quadratics", "discriminant", "roots", "completing the square"),
    "Functions": ("function", "domain", "range", "composite", "inverse function"),
    "Coordinate_geometry": ("coordinate geometry", "coordinate", "gradient", "straight line", "circle"),
    "Trigonometry": ("trigonometry", "trigonometric", "sin ", "cos ", "tan ", "sine rule", "cosine rule"),
    "Series": ("series", "sequence", "arithmetic progression", "geometric progression"),
    "Differentiation": ("differentiation", "differentiate", "derivative", "calculus", "dy/dx", "stationary", "gradient of the curve", "turning point", "maximum point", "minimum point"),
    "Integration": ("integration", "integrate", "integral", "area under", "shaded region", "area of the shaded", "area enclosed"),
    "Circular_measure": ("circular measure", "radian", "arc length", "sector"),
    "Algebra": ("algebra", "quadratic", "polynomial", "factorise", "factorize", "inequality"),
    "Logarithmic_and_exponential_functions": ("logarithm", "log ", "exponential", "e^"),
    "Numerical_solution_of_equations": ("numerical", "iteration", "root", "solve equation"),
    "Vectors": ("vector", "vectors"),
    "Differential_equations": ("differential equation", "differential equations", "dy/dx"),
    "Complex_numbers": ("complex number", "complex numbers", "argand", "imaginary"),
    "Forces_and_equilibrium": ("force", "forces", "equilibrium", "resultant"),
    "Kinematics_of_motion_in_a_straight_line": ("kinematics", "kinematic", "velocity", "acceleration", "displacement"),
    "Momentum": ("momentum", "impulse", "collision"),
    "Newton's_laws_of_motion": ("newton", "newton's law", "newtons law"),
    "Energy,_work_and_power": ("energy", "work", "power"),
    "Representation_of_data": ("histogram", "box plot", "data", "scatter", "frequency"),
    "Permutations_and_combinations": ("permutation", "combination", "arrangement", "npr", "ncr"),
    "Probability": ("probability", "probabilities", "event", "venn"),
    "Discrete_random_variables": ("discrete random", "probability distribution", "expectation"),
    "The_normal_distribution": ("normal distribution", "normal", "standard deviation", "mean"),
    "Continuous_random_variables": ("continuous random", "density function", "probability density"),
    "Hypothesis_tests": ("hypothesis", "significance", "critical region"),
    "Linear_combinations_of_random_variables": ("linear combination", "random variables"),
    "Sampling_and_estimation": ("sampling", "estimate", "estimation"),
    "The_Poisson_distribution": ("poisson",),
}


# Distinctive terms outrank broad shared words such as "force" or "data".
# This affects only evidence scoring; returned names still come verbatim from
# the reference file.
# A historical reference spelling contains a comma in the official phrase;
# the shipped folder profile uses the same name-only topic without punctuation
# so it remains a safe routing key.  Classification returns the profile key.
_REFERENCE_TOPIC_ALIASES = {
    "Energy,_work_and_power": "Energy_work_and_power",
}


_TOPIC_SPECIFICITY = {
    "Newton's_laws_of_motion": 3,
    "The_Poisson_distribution": 3,
    "The_normal_distribution": 3,
    "Differential_equations": 2,
    "Complex_numbers": 2,
    "Vectors": 2,
}


def _score_text_against(topics, keywords, specificity, haystack: str) -> dict:
    # 2026-08-13: line-break tokens inside maths formulas extract as "tan\ntan\n";
    # normalise all whitespace so "sin ", "tan ", "solve the equation" etc. match.
    haystack = re.sub(r"\s+", " ", haystack)
    return {
        topic: sum(haystack.count(keyword) for keyword in keywords.get(topic, ()))
        * specificity.get(topic, 1)
        for topic in topics
    }


def _fuse_diagram(scores: dict, diagram: dict | None) -> dict:
    """Deterministic diagram-signal fusion (spec Fix 8). Signals only ever ADD
    evidence for official topics; they never invent unlisted topics.

    - angle arcs / sectors / greek letters        -> Trigonometry, Circular_measure
    - a lone plain triangle is NOT trigonometry evidence (spec: 'A plain
      triangle is not enough') — it only counts alongside arcs or trig text.
    - vector arrows                               -> Vectors (9709/9231) or
      Transformations_and_vectors (0580)
    - force arrows                                -> Forces / Mechanics topics
    - axes + plotted curve                        -> Coordinate_geometry /
      Algebra_and_graphs
    - histogram-style bar blocks                  -> Representation_of_data /
      Statistics
    """
    if not diagram:
        return scores
    scores = dict(scores)
    arcs = int(diagram.get("angle_arcs", 0))
    sectors = int(diagram.get("sectors", 0))
    triangles = int(diagram.get("triangles", 0))
    arrows = int(diagram.get("vector_arrows", 0))
    force = int(diagram.get("force_arrows", 0))
    axes_curve = int(diagram.get("axes_with_curve", 0))
    bars = int(diagram.get("bar_blocks", 0))
    greek = int(diagram.get("greek_labels", 0))
    normal = int(diagram.get("normal_curves", 0))
    trees = int(diagram.get("probability_trees", 0))

    def bump(names, weight):
        for name in names:
            for key in scores:
                # Exact match, or underscore-suffix ('vectors' -> 'Vectors' and
                # 'Transformations_and_vectors', but 'geometry' must NOT leak
                # into 'Coordinate_geometry').
                kl = key.lower()
                if kl == name.lower() or kl.endswith("_" + name.lower()):
                    scores[key] += weight
    # 2026-08-13 (corpus-hardened): diagram bumps are CONSTANT and small.
    # Count-scaled weights (2 + arcs) amplified text-glyph noise on real
    # crops (a single stray arc added 3+ points, dwarfing text evidence).
    # Only multi-signal or structurally strong evidence bumps a topic now.
    if greek:
        bump(["trigonometry", "circular_measure"], 1)
    if arcs >= 2 and triangles >= 1 and greek >= 1:
        # RS-17 multi-signal contract: drawn angle arcs + a triangle + a
        # greek/angle label = a genuine trig figure (corpus-hardened 2026-08-13:
        # plain noise arcs without an angle label must NOT bump trigonometry).
        bump(["trigonometry", "circular_measure", "geometry"], 3)
        bump(["trigonometry"], 1)
    if force:
        bump(["forces_and_equilibrium", "newton's_laws_of_motion",
              "kinematics_of_motion_in_a_straight_line", "mechanics"], 2)
    # 2026-08-13: plain arrow counting is NOT used — 3D-solid edges trigger
    # the arrowhead heuristic (cuboid Q21 emitted 13 "arrows"). Real vector
    # questions carry "vector"/"arrow" wording, which the base keywords and
    # phrase bonuses already handle. force_arrows stays (text-gated).
    if axes_curve:
        bump(["coordinate_geometry", "algebra_and_graphs"], 2)
    if bars >= 3:
        bump(["representation_of_data", "statistics"], 2)
    if normal:
        bump(["the_normal_distribution"], 3)
    if trees:
        bump(["probability"], 2)
    venn = int(diagram.get("venn_diagram", 0))
    if venn:
        bump(["probability"], 2)
    return scores


_FORMULA_NOTATION_CHARS = "θπ°αβλφΔΣμ"
# 2026-08-13: the DEGREE sign opens the evidence gate (angle questions) but
# must NOT count as trig greek-notation — geometry questions with angles were
# being pulled into near-ties with Trigonometry (0580 Q13 cyclic quadrilateral).
_NOTATION_BUMP_CHARS = "θπαβλφΔΣμ"


def _text_gate_open(raw_text: str, scores: dict) -> bool:
    """Spec Fix 8 multi-signal contract: a topic is only routable when the
    question TEXT / formula-notation layer carries at least one signal
    (keyword hit or math notation like θ/π/°). Pixel-diagram signals ALONE
    never route a question — diagram-only input is REVIEW_REQUIRED."""
    if any(v > 0 for v in scores.values()):
        return True
    return any(ch in raw_text for ch in _FORMULA_NOTATION_CHARS)


def _merge_text_notation(diagram: dict | None, raw_text: str) -> dict:
    d = dict(diagram or {})
    d["greek_labels"] = int(d.get("greek_labels", 0)) + sum(
        raw_text.count(ch) for ch in _NOTATION_BUMP_CHARS)
    return d


def _apply_phrase_bonuses(scores: dict, raw_text: str, bonus_map: dict[str, Sequence[str]], weight: int = 2) -> dict:
    """Boost distinctive, low-collision phrases that are stronger than the base
    keyword lists. The bonuses only ever strengthen an already-configured topic;
    they never invent a new routing name."""
    haystack = f" {re.sub(r'\s+', ' ', raw_text.lower())} "
    boosted = dict(scores)
    for topic, phrases in bonus_map.items():
        if topic not in boosted:
            continue
        hits = sum(haystack.count(phrase) for phrase in phrases)
        if hits:
            boosted[topic] += hits * weight
    return boosted


def _pick_best_topic(ordered_topics: Sequence[str], scores: dict[str, float]) -> str | None:
    """Choose a math topic conservatively.

    Accuracy target: prefer abstaining on weak near-ties rather than forcing a
    wrong folder. Reference order still resolves confident ties only after the
    ambiguity gates say the winner is clear enough.
    """
    ranking = [(scores.get(topic, 0.0), idx, topic) for idx, topic in enumerate(ordered_topics)]
    ranking.sort(key=lambda row: (-row[0], row[1]))
    if not ranking or ranking[0][0] <= 0:
        return None
    best, _idx, winner = ranking[0]
    runner = ranking[1][0] if len(ranking) > 1 else 0.0
    gap = best - runner
    # Hard tie between multiple candidate topics -> review_required.
    if runner == best and best > 0:
        return None
    # Low-evidence / close-score outputs are more likely to be wrong than to be
    # safely auto-routed. Let the caller send them to review_required.
    # 2026-08-13 (corpus-calibrated, RS-41 round 2): a SINGLE topic with
    # evidence and NO competitor routes ("logarithm", "binomial expansion",
    # "velocity" were all being rejected at best=1, runner=0 — measured on the
    # 0606_s24 corpus). Rejection now requires a real competitor.
    if best < 2 and runner > 0 and gap <= 1:
        return None
    if best < 5 and runner > 0 and gap <= 1 and (runner / best) >= 0.8:
        return None
    return winner


# ── RS-24 (2026-08-14, real-paper finding 0580_s24_qp_41 Q9): full-auto must
# never leave a math question winnerless. Q9 is a composite/inverse function
# question whose OCR text is character-fragmented ("f", "(", "3" on separate
# lines) — "function" never appears, so the evidence gate stays closed and the
# paper bundle crashed with "Classification has no valid assigned topic".
# Under force (full-auto) the math routers now:
#   1. pick the best near-miss topic when SOME topic scored;
#   2. fall back to math-notation heuristics when nothing scored
#      (f(x)/g(x)/f⁻¹/gh notation -> the functions topic; θ/π/° notation ->
#      trigonometry/circular measure; digits+units -> Number, ...);
#   3. as an absolute last resort return the first topic in syllabus order
#      (only reachable when the crop text is empty/garbage).
_FUNCTION_NOTATION_RE = re.compile(
    r"\b[fgh]\s*\(\s*[x0-9]|⁻?\s*1\s*\)|\b[fg]\s*[gh]\s*\(",
    re.IGNORECASE,
)
_INVERSE_NOTATION_RE = re.compile(r"[fgh]⁻?\^?\s*-\s*1\b|inverse", re.IGNORECASE)
# RS-24: Cambridge math QP text extraction frequently scrambles function
# notation into character columns ("f(x)" -> "f", "=", "( )x" on separate
# lines), so no adjacency ever matches. Standalone single-letter identifiers
# f/g/h TOGETHER with a "Find" command and [n] mark tokens are a reliable
# functions-question signature (single letters as identifiers occur nowhere
# else in IGCSE/A-Level maths papers).
_SCRAMBLED_FUNCTION_RE = re.compile(r"\b[fgh]\b", re.IGNORECASE)
_MARK_TOKEN_RE = re.compile(r"\[\s*\d{1,2}\s*\]")
# RS-25: 0606 differentiation questions ("Find d/dx(...)") whose notation gets
# scrambled into character columns ("d", "dd" on their own lines). Only fires
# when ALL of: "find" command, mark tokens, a standalone x, a standalone
# d/dd token, AND "exact form" (the stem's closing phrase) are present — so
# subpart-(d) questions and surd "exact form" asks never match.
_D_TOKEN_RE = re.compile(r"(?<![a-z])d{1,2}(?![a-z])", re.IGNORECASE)
_X_TOKEN_RE = re.compile(r"(?<![a-z])x(?![a-z])", re.IGNORECASE)


def _is_scrambled_differentiation(text: str) -> bool:
    low = text.lower()
    return ("find" in low and "exact form" in low
            and _MARK_TOKEN_RE.search(text)
            and _X_TOKEN_RE.search(text)
            and _D_TOKEN_RE.search(text))


def _math_force_topic(text: str, topics: Sequence[str],
                      scores: dict[str, float],
                      functions_topic: str | None = None) -> str | None:
    """Deterministic full-auto fallback for math questions (never None)."""
    # 1. best near-miss
    ranked = [(scores.get(t, 0.0), i, t) for i, t in enumerate(topics)]
    ranked.sort(key=lambda r: (-r[0], r[1]))
    if ranked and ranked[0][0] > 0:
        return ranked[0][2]
    # 2. notation heuristics
    low = text.lower()
    if functions_topic:
        if (_FUNCTION_NOTATION_RE.search(text)
                or _INVERSE_NOTATION_RE.search(low)
                # scrambled-notation signature: standalone f/g/h identifiers +
                # "find" command + mark tokens (real 0580_s24_qp_41 Q9).
                or ("find" in low
                    and _SCRAMBLED_FUNCTION_RE.search(text)
                    and _MARK_TOKEN_RE.search(text))):
            return functions_topic
    if any(ch in text for ch in ("θ", "π", "°")):
        if "Trigonometry" in topics:
            return "Trigonometry"
        if "Circular_measure" in topics:
            return "Circular_measure"
    if "sin" in low or "cos" in low or "tan" in low or "pythagoras" in low:
        if "Trigonometry" in topics:
            return "Trigonometry"
    if any(ch in low for ch in ("mean", "median", "mode", "probability", "frequency")):
        for t in ("Statistics", "Probability"):
            if t in topics:
                return t
    # 3. absolute last resort: first topic in official syllabus order
    return topics[0] if topics else None


_9709_PHRASE_BONUSES = {
    "Quadratics": ("parabola", "turning point", "roots are equal"),
    "Functions": ("one-one", "one to one", "composite function", "inverse function"),
    "Coordinate_geometry": ("equation of the line", "midpoint", "perpendicular", "parallel"),
    "Trigonometry": ("identity", "identities", "trigonometric equation", "double angle", "sec", "cosec", "cot"),
    "Circular_measure": ("radians", "sector area", "small-angle", "small angle"),
    "Differentiation": ("stationary point", "second derivative", "tangent", "normal to the curve", "gradient of the curve"),
    "Integration": ("definite integral", "area between", "volume of revolution", "shaded region", "area of the shaded"),
    "Algebra": ("modulus", "partial fractions", "binomial expansion", "quotient", "remainder when"),
    "Logarithmic_and_exponential_functions": ("natural logarithm", "ln", "exponential growth", "exponential decay"),
    "Numerical_solution_of_equations": ("show that there is a root", "use an iteration", "iterative formula"),
    "Complex_numbers": ("argand diagram", "de moivre", "locus in the argand plane"),
    "Forces_and_equilibrium": ("equilibrium", "resultant force", "three forces"),
    "Kinematics_of_motion_in_a_straight_line": ("speed-time graph", "displacement-time graph", "constant acceleration"),
    "Momentum": ("coefficient of restitution", "impulse", "collision"),
    "Newton's_laws_of_motion": ("newton's second law", "mass times acceleration"),
    "Energy,_work_and_power": ("work done", "kinetic energy", "gravitational potential energy", "power output"),
    "Representation_of_data": ("cumulative frequency", "box-and-whisker", "stem-and-leaf", "scatter diagram"),
    "Permutations_and_combinations": ("npr", "ncr", "distinct arrangements"),
    "Probability": ("venn diagram", "conditional probability", "independent events"),
    "Discrete_random_variables": ("expected value", "variance of x", "probability mass"),
    "The_normal_distribution": ("standard normal", "z-value", "z score"),
    "Continuous_random_variables": ("probability density function", "density curve"),
    "Hypothesis_tests": ("null hypothesis", "alternative hypothesis", "critical value", "p-value"),
    "Linear_combinations_of_random_variables": ("x + y", "ax + by", "combined random variables"),
    "Sampling_and_estimation": ("unbiased estimator", "sampling distribution", "confidence interval"),
    "The_Poisson_distribution": ("poisson process",),
}


def classify_9709_question(text: str, paper_number: int, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Choose one valid topic from the filename-selected reference section.

    Returns None when there is NO deterministic evidence (spec: never fall back
    to an alphabetical/first topic — the caller routes to REVIEW_REQUIRED),
    and also when only pixels speak (diagram-only -> REVIEW_REQUIRED).
    ``force=True`` (full-auto, RS-24) never returns None: near-miss ->
    notation heuristics -> first allowed topic."""
    allowed = allowed_topics_for_paper(paper_number)
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(allowed, _TOPIC_KEYWORDS, _TOPIC_SPECIFICITY, haystack)
    text_scores = _apply_phrase_bonuses(text_scores, text, _9709_PHRASE_BONUSES)
    if not _text_gate_open(text, text_scores):
        if force:
            return _math_force_topic(text, allowed, text_scores,
                                     functions_topic="Functions")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    raw_topic = _pick_best_topic(allowed, scores)
    if raw_topic is None and force:
        raw_topic = _math_force_topic(text, allowed, text_scores,
                                      functions_topic="Functions")
    if raw_topic is None:
        return None
    # Reference order resolves confident outcomes; return the configured folder
    # key when an official reference spelling contains punctuation that the
    # profile deliberately flattened.
    return _REFERENCE_TOPIC_ALIASES.get(raw_topic, raw_topic)

FURTHER_9231_REFERENCE_PATH = Path(__file__).parent.parent / "references" / "Further_Mathematics_9231 Reference.txt"


def _load_paper_reference(path: Path) -> Dict[int, List[str]]:
    if not path.exists():
        raise FileNotFoundError(f"Mathematics reference missing: {path}")
    sections: Dict[int, List[str]] = {}
    current: int | None = None
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line:
            continue
        heading = _HEADING.search(line)
        if heading:
            current = int(heading.group(1)); sections.setdefault(current, [])
        elif current is None:
            raise ValueError(f"Topic before paper heading in {path}: {line!r}")
        else:
            sections[current].append(line)
    return sections


@lru_cache(maxsize=1)
def load_9231_reference() -> Dict[int, List[str]]:
    sections = _load_paper_reference(FURTHER_9231_REFERENCE_PATH)
    if set(sections) != {1, 2, 3, 4} or any(not values for values in sections.values()):
        raise ValueError("Further Mathematics 9231 reference must define P1 through P4")
    return sections


# The shipped 9231 reference text predates the final config-safe routing names
# in two places and omits the dedicated Hooke's-law major from P3.  Canonicalise
# those spellings here so question routing, folder names, and config validation
# all agree on one output vocabulary.
_9231_REFERENCE_TOPIC_ALIASES = {
    "Inference_using_normal_and_t-distributions": "Inference_using_normal_and_t_distributions",
    "Non-parametric_tests": "Non_parametric_tests",
}


def _canonical_9231_topic(topic: str) -> str:
    return _9231_REFERENCE_TOPIC_ALIASES.get(topic, topic)


@lru_cache(maxsize=None)
def _allowed_9231_topics_for_paper(paper_number: int) -> List[str]:
    allowed = [_canonical_9231_topic(t) for t in load_9231_reference().get(int(paper_number), [])]
    if int(paper_number) == 3 and "Hooke's_law" not in allowed:
        try:
            idx = allowed.index("Linear_motion_under_a_variable_force")
        except ValueError:
            idx = len(allowed)
        allowed.insert(idx, "Hooke's_law")
    return allowed


def reference_topics_for_subject_paper(syllabus_code: str, paper_number: int) -> List[str]:
    """Return canonical routing topics for a staging paper."""
    code = str(syllabus_code)
    if code == "9709":
        return allowed_topics_for_paper(paper_number)
    if code == "9231":
        return list(_allowed_9231_topics_for_paper(int(paper_number)))
    return []
# ---------------------------------------------------------------------------
# IGCSE Mathematics 0580 — official topic areas (2025–2027 syllabus, topic
# names verbatim). Question-level routing per mega-spec Fix 8: text + formula
# evidence first, deterministic diagram fusion, REVIEW_REQUIRED on no-evidence.
MATH_0580_TOPICS: List[str] = [
    "Number",
    "Algebra_and_graphs",
    "Coordinate_geometry",
    "Geometry",
    "Mensuration",
    "Trigonometry",
    "Transformations_and_vectors",
    "Probability",
    "Statistics",
]

_0580_TOPIC_KEYWORDS = {
    "Number": ("number", "integer", "fraction", "percentage", "decimal", "ratio",
               "standard form", "prime", "factor", "interest", "estimat", "bound",
               "currency", "proportion", "exponential", "exponentially",
               "depreciat", "appreciat"),
    "Algebra_and_graphs": ("algebra", "expand", "factorise", "factorize", "expression",
                           "simplify", "solve the equation", "quadratic", "sequence",
                           "nth term", "inequality", "inequalit", "formula", "equation",
                           "graph of", "sketch"),
    "Coordinate_geometry": ("gradient", "straight line", "coordinates", "coordinate",
                            "midpoint", "parallel to", "perpendicular", "equation of the line",
                            "y-intercept", "y ="),
    "Geometry": ("angle", "polygon", "congruent", "similar", "circle theorem",
                 "chord", "tangent", "construction", "bisector", "symmetry",
                 "interior angle", "exterior angle"),
    "Mensuration": ("area", "perimeter", "volume", "surface area", "circumference",
                    "radius", "diameter", "length of arc", "sector", "prism",
                    "cylinder", "cone", "sphere", "pyramid"),
    "Trigonometry": ("trigonometr", "sin ", "cos ", "tan ", "sinx", "cosx", "tanx", "siny", "cosy", "tany", "sine rule", "cosine rule",
                     "bearing", "angle of elevation", "angle of depression", "pythagoras"),
    "Transformations_and_vectors": ("transformation", "translation", "rotation", "reflection",
                                    "enlargement", "vector", "matrix", "matrices",
                                    "column vector"),
    "Probability": ("probability", "probabilities", "event", "outcome", "tree diagram",
                    "expected number", "without replacement", "venn diagram", "venn", "set notation"),
    "Statistics": ("mean", "median", "mode", "range of", "histogram", "cumulative frequency",
                   "scatter", "bar chart", "pie chart", "frequency table", "interquartile",
                   "box plot", "standard deviation"),
}

_0580_TOPIC_SPECIFICITY = {
    "Coordinate_geometry": 2,
    "Transformations_and_vectors": 2,
    "Trigonometry": 2,
}

_0580_PHRASE_BONUSES = {
    "Number": ("surd", "surd form", "upper bound", "lower bound", "compound interest",
               "percentage change", "as a fraction", "recurring decimal",
               "decreases exponentially", "increases exponentially", "calculate."),
    "Algebra_and_graphs": ("simultaneous equation", "nth term", "graphical solution",
                           "rearrange the formula", "variation", "factorise completely",
                           "inequalities that define", "unshaded region"),
    "Coordinate_geometry": ("equation of the line", "distance between", "midpoint", "gradient of ab", "perpendicular bisector"),
    "Geometry": ("locus", "construction", "circle theorem", "interior angle", "exterior angle",
                 "cyclic quadrilateral", "kite", "congruent", "similar to"),
    "Mensuration": ("surface area", "composite solid", "arc length", "volume of", "cross-sectional area",
                    "cuboid", "semicircle", "area of triangle", "area of the triangle"),
    "Trigonometry": ("sine rule", "cosine rule", "angle of elevation", "angle of depression", "bearing", "pythagoras", "sinx", "cosx", "tanx"),
    "Transformations_and_vectors": ("image of", "under enlargement", "matrix transformation", "column vector", "centre of enlargement"),
    "Probability": ("relative frequency", "without replacement", "tree diagram", "expected number"),
    "Statistics": ("cumulative frequency curve", "box plot", "histogram", "scatter diagram", "interquartile range"),
}


def classify_0580_question(text: str, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Question-level 0580 routing into the 9 official topic areas.

    Deterministic: keyword evidence x specificity, diagram fusion, ties resolve
    by official syllabus order. No evidence -> None (caller: REVIEW_REQUIRED).
    ``force=True`` (full-auto) never returns None: near-miss -> notation
    heuristics -> syllabus-order first topic (RS-24).
    """
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(MATH_0580_TOPICS, _0580_TOPIC_KEYWORDS,
                                      _0580_TOPIC_SPECIFICITY, haystack)
    # 2026-08-13: distinctive phrases ("cuboid", "cyclic quadrilateral") are
    # evidence too — apply before the gate so they can open it.
    text_scores = _apply_phrase_bonuses(text_scores, text, _0580_PHRASE_BONUSES)
    if not _text_gate_open(text, text_scores):
        if force:
            # RS-24: functions live under Algebra_and_graphs in 0580; f(x)/g(x)
            # /f⁻¹ notation with no other evidence still routes there.
            return _math_force_topic(text, MATH_0580_TOPICS, text_scores,
                                     functions_topic="Algebra_and_graphs")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    winner = _pick_best_topic(MATH_0580_TOPICS, scores)
    if winner is None and force:
        winner = _math_force_topic(text, MATH_0580_TOPICS, text_scores,
                                   functions_topic="Algebra_and_graphs")
    return winner


# ---------------------------------------------------------------------------
# IGCSE Additional Mathematics 0606 — official topic names for the
# 2025–2027 syllabus.  These are deliberately flattened routing names: the
# numeric syllabus identifiers stay in the profile metadata, never in output
# folders.  Text/formula evidence is required; diagram-only evidence remains
# REVIEW_REQUIRED just like the other mathematics profiles.
MATH_0606_TOPICS: List[str] = [
    "Functions",
    "Quadratic_functions",
    "Factors_of_polynomials",
    "Equations_inequalities_and_graphs",
    "Simultaneous_equations",
    "Logarithmic_and_exponential_functions",
    "Straight_line_graphs",
    "Coordinate_geometry_of_the_circle",
    "Circular_measure",
    "Trigonometry",
    "Permutations_and_combinations",
    "Series",
    "Vectors_in_two_dimensions",
    "Calculus",
]

_0606_TOPIC_KEYWORDS = {
    "Functions": ("function", "domain", "range", "inverse function", "composite function", "modulus function", "mapping"),
    "Quadratic_functions": ("quadratic", "discriminant", "completing the square", "maximum", "minimum", "parabola", "turning point"),
    "Factors_of_polynomials": ("polynomial", "factor theorem", "remainder theorem", "factorise", "factorize", "cubic", "quartic"),
    "Equations_inequalities_and_graphs": ("equation", "inequality", "inequalities", "graphical solution", "solve graphically", "modulus equation"),
    "Simultaneous_equations": ("simultaneous equations", "elimination", "substitution"),
    "Logarithmic_and_exponential_functions": ("logarithm", "logarithmic", "ln", "exponential", "laws of logarithms", "exponential equation", "growth", "decay", "single logarithm", "log ", "lg", "base 10"),
    "Straight_line_graphs": ("straight line", "straight-line", "linear graph", "gradient", "intercept", "linearise", "linearize"),
    "Coordinate_geometry_of_the_circle": ("coordinate geometry of the circle", "equation of a circle", "radius", "tangent to the circle", "circle"),
    "Circular_measure": ("circular measure", "radian", "radians", "arc length", "sector area", "sector"),
    "Trigonometry": ("trigonometry", "trigonometric", "sine", "cosine", "tangent", "sec", "cosec", "cot", "identity", "general solution", "amplitude", "period", "sin ", "cos ", "tan ", "solve the equation"),
    "Permutations_and_combinations": ("permutation", "combination", "factorial", "arrangement", "selection", "npr", "ncr"),
    "Series": ("series", "arithmetic progression", "geometric progression", "common difference", "common ratio", "nth term", "sum to n terms", "sum to infinity", "binomial expansion", "expansion", "ascending powers", "binomial"),
    "Vectors_in_two_dimensions": ("vector", "vectors", "magnitude", "unit vector", "position vector", "column vector", "parallel vectors", "displacement vector", "velocity vector"),
    "Calculus": ("calculus", "differentiation", "differentiate", "derivative",
                "dy/dx", "stationary point", "integration", "integral",
                "area under the curve", "constant of integration",
                # RS-25 (2026-08-14): removed false-positive keywords — "exact
                # form" is a command phrase used by surds/trig/algebra
                # questions everywhere, "particle" is a bare noun, and bare
                # "velocity"/"acceleration"/"displacement" fire on simple
                # speed-distance-time algebra. Replaced with calculus-context
                # phrases: motion questions in 0606 are calculus, but only
                # when the wording signals it (rates, "in terms of t",
                # distance travelled by integration, gradient of a curve).
                "rate of change", "in terms of t", "distance travelled",
                "gradient of the curve", "equation of the curve",
                "with respect to", "velocity is", "acceleration is",
                "displacement is", "maximum point", "minimum point",
                "turning point of the curve", "find the derivative",
                "integrate", "integration of", "differentiate with"),
}

_0606_TOPIC_SPECIFICITY = {
    "Coordinate_geometry_of_the_circle": 2,
    "Circular_measure": 2,
    "Trigonometry": 2,
    "Vectors_in_two_dimensions": 2,
    "Calculus": 2,
}

_0606_PHRASE_BONUSES = {
    "Functions": ("composite function", "inverse function", "one-to-one", "modulus function", "mapping"),
    "Quadratic_functions": ("completing the square", "turning point", "axis of symmetry", "roots are equal"),
    "Factors_of_polynomials": ("factor theorem", "remainder theorem", "cubic polynomial", "quartic polynomial"),
    "Equations_inequalities_and_graphs": ("solve graphically", "graphical solution", "modulus equation", "inequality"),
    "Simultaneous_equations": ("simultaneous equations", "elimination", "substitution"),
    "Logarithmic_and_exponential_functions": ("laws of logarithms", "natural logarithm", "exponential growth", "exponential decay"),
    "Straight_line_graphs": ("y = mx + c", "linear law", "linearise", "linearize", "gradient and intercept"),
    "Coordinate_geometry_of_the_circle": ("equation of a circle", "tangent to the circle", "radius and centre", "center"),
    "Circular_measure": ("radian", "sector area", "arc length", "small-angle", "small angle"),
    "Trigonometry": ("sec", "cosec", "cot", "compound angle", "general solution", "amplitude", "period"),
    "Permutations_and_combinations": ("npr", "ncr", "ordered", "unordered", "distinct arrangements"),
    "Series": ("sum to infinity", "binomial expansion", "common ratio", "common difference"),
    "Vectors_in_two_dimensions": ("position vector", "unit vector", "parallel vectors", "column vector"),
    "Calculus": ("rate of change", "second derivative", "stationary point", "area under the curve", "constant of integration"),
}


def classify_0606_question(text: str, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Route one 0606 question into one official major topic or None."""
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(MATH_0606_TOPICS, _0606_TOPIC_KEYWORDS,
                                      _0606_TOPIC_SPECIFICITY, haystack)
    if not _text_gate_open(text, text_scores):
        if force:
            if _is_scrambled_differentiation(text):
                return "Calculus"
            return _math_force_topic(text, MATH_0606_TOPICS, text_scores,
                                     functions_topic="Functions")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    scores = _apply_phrase_bonuses(scores, text, _0606_PHRASE_BONUSES)
    winner = _pick_best_topic(MATH_0606_TOPICS, scores)
    if winner is None and force:
        winner = _math_force_topic(text, MATH_0606_TOPICS, text_scores,
                                   functions_topic="Functions")
    return winner


# ---------------------------------------------------------------------------
# A-Level Further Mathematics 9231 — reference-file vocabulary, question-level
# routing (same contract as 9709).
_9231_TOPIC_KEYWORDS = {
    "Matrices": ("matrix", "matrices", "determinant", "inverse matrix"),
    "Polar_coordinates": ("polar", "r =", "pole", "initial line", "polar curve"),
    "Proof_by_induction": ("induction", "prove by induction", "inductive"),
    "Rational_functions_and_graphs": ("rational function", "asymptote", "oblique"),
    "Roots_of_polynomial_equations": ("roots of", "polynomial", "sum of the roots", "product of the roots", "cubic equation", "quadratic equation", "roots", "in terms of"),
    "Summation_of_series": ("summation", "sum of the series", "sigma", "method of differences"),
    "Vectors": ("vector", "vectors", "cross product", "scalar product", "plane", "line of intersection"),
    "Complex_numbers": ("complex", "argand", "modulus", "argument", "de moivre"),
    "Differential_equations": ("differential equation", "particular integral", "complementary function", "second order"),
    "Differentiation": ("differentiat", "derivative", "dy/dx", "implicit"),
    "Hyperbolic_functions": ("hyperbolic", "sinh", "cosh", "tanh"),
    "Integration": ("integrat", "integral", "reduction formula", "arc length", "surface of revolution"),
    "Circular_motion": ("circular motion", "angular speed", "angular velocity", "centripetal"),
    "Equilibrium_of_a_rigid_body": ("rigid body", "equilibrium", "moment", "centre of mass", "laminar", "lamina"),
    "Hooke's_law": ("hooke's law", "elastic spring", "elastic string", "spring", "modulus of elasticity", "natural length", "extension"),
    "Linear_motion_under_a_variable_force": ("variable force", "simple harmonic", "shm", "oscillat", "resistance proportional"),
    "Momentum": ("momentum", "impulse", "collision", "restitution"),
    "Motion_of_a_projectile": ("projectile", "trajectory", "greatest height", "range on"),
    "Continuous_random_variables": ("continuous random", "density function", "cumulative distribution"),
    "Inference_using_normal_and_t_distributions": ("t-distribution", "t distribution", "confidence interval", "normal distribution", "pooled", "population mean", "sample mean"),
    "Non_parametric_tests": ("non-parametric", "non parametric", "sign test", "wilcoxon", "rank"),
    "Probability_generating_functions": ("probability generating", "pgf", "generating function"),
    "Chi_squared_tests": ("chi-squared", "chi squared", "chi squared test", "goodness of fit", "contingency"),
}

_9231_TOPIC_SPECIFICITY = {
    "Hooke's_law": 3,
    "Inference_using_normal_and_t_distributions": 3,
    "Non_parametric_tests": 3,
    "Chi_squared_tests": 3,
    "Probability_generating_functions": 2,
}

_9231_PHRASE_BONUSES = {
    "Matrices": ("characteristic equation", "inverse matrix", "determinant"),
    "Polar_coordinates": ("polar curve", "pole", "initial line"),
    "Proof_by_induction": ("assume true for n = k", "true for n = k + 1", "prove by induction"),
    "Rational_functions_and_graphs": ("oblique asymptote", "vertical asymptote", "rational function"),
    "Roots_of_polynomial_equations": ("sum of roots", "product of roots", "polynomial equation"),
    "Summation_of_series": ("method of differences", "summation of series", "sigma notation"),
    "Vectors": ("vector equation", "cross product", "scalar product", "plane through"),
    "Complex_numbers": ("argand diagram", "de moivre", "modulus-argument"),
    "Differential_equations": ("auxiliary equation", "complementary function", "particular integral"),
    "Differentiation": ("implicit differentiation", "parametric differentiation", "second derivative"),
    "Hyperbolic_functions": ("sinh", "cosh", "tanh", "hyperbolic identity"),
    "Integration": ("reduction formula", "surface of revolution", "arc length"),
    "Circular_motion": ("centripetal", "angular speed", "angular velocity"),
    "Equilibrium_of_a_rigid_body": ("rigid body", "centre of mass", "center of mass", "lamina", "moment"),
    "Hooke's_law": ("hooke's law", "elastic spring", "elastic string", "natural length", "modulus of elasticity"),
    "Linear_motion_under_a_variable_force": ("simple harmonic motion", "simple harmonic", "shm", "variable force", "resistance proportional"),
    "Momentum": ("coefficient of restitution", "impulse", "collision"),
    "Motion_of_a_projectile": ("trajectory", "greatest height", "projectile"),
    "Continuous_random_variables": ("cumulative distribution", "density function", "continuous random variable"),
    "Inference_using_normal_and_t_distributions": ("t-distribution", "confidence interval", "population mean", "sample mean"),
    "Non_parametric_tests": ("sign test", "wilcoxon", "rank sum", "non-parametric"),
    "Probability_generating_functions": ("probability generating function", "pgf"),
    "Chi_squared_tests": ("goodness of fit", "contingency table", "chi-squared"),
}


def classify_9231_question(text: str, paper_number: int, diagram: dict | None = None,
                          force: bool = False) -> str | None:
    """Question-level 9231 routing within the filename-selected paper section."""
    allowed = _allowed_9231_topics_for_paper(int(paper_number))
    if not allowed:
        return None
    haystack = f" {text.lower()} "
    text_scores = _score_text_against(allowed, _9231_TOPIC_KEYWORDS, _9231_TOPIC_SPECIFICITY, haystack)
    if not _text_gate_open(text, text_scores):
        if force:
            return _math_force_topic(text, allowed, text_scores,
                                     functions_topic="Matrices")
        return None
    scores = _fuse_diagram(text_scores, _merge_text_notation(diagram, text))
    scores = _apply_phrase_bonuses(scores, text, _9231_PHRASE_BONUSES)
    winner = _pick_best_topic(allowed, scores)
    if winner is None and force:
        winner = _math_force_topic(text, allowed, text_scores,
                                   functions_topic="Matrices")
    return winner
