"""pipeline_state.py — NEW MODULE (Upgrade 4 / audit fix-group 8, maintainer-approved)

Stateful pipeline manager with crash recovery and resume capability.
Integrated into main.py's process loop: state is persisted to
`<output_root>/.pipeline_state.json` after every paper; on restart,
papers already COMPLETE are skipped.

Spec-reconstruction fixes (documented per maintainer convention):
  FIX-P1  `register_paper()` added — the spec's mark_* methods index
          self.papers[code], which only exists if the caller built the
          record, but no public constructor for records was provided.
          Registration is idempotent and never downgrades a COMPLETE
          record back to PENDING.
  FIX-P2  Paste linkification/corruption reconstructed (`__future__`,
          attribute references, comparison operators).
"""  # end module docstring

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional
from enum import Enum

logger = logging.getLogger(__name__)


class PaperStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETE = "complete"
    FAILED = "failed"
    SKIPPED = "skipped"
    # Mega-spec Fix 1 (2026-08-12): ambiguous/unsupported input is recorded,
    # never silently guessed or lumped into FAILED.
    REVIEW_REQUIRED = "review_required"


@dataclass
class PaperRecord:
    paper_code: str
    qp_path: str
    ms_path: Optional[str]
    er_path: Optional[str]
    status: PaperStatus = PaperStatus.PENDING
    questions_found: int = 0
    questions_saved: int = 0
    error_message: str = ""
    started_at: float = 0.0
    completed_at: float = 0.0
    review_reason: str = ""  # mega-spec Fix 1: why REVIEW_REQUIRED was set

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "PaperRecord":
        d = dict(d)
        d["status"] = PaperStatus(d["status"])
        return cls(**d)


@dataclass
class PipelineState:
    """Full pipeline state — persisted to disk after every paper.

    Enables crash recovery and resume.
    """
    run_id: str
    subject: str
    syllabus_code: str
    level: str
    started_at: float
    papers: Dict[str, PaperRecord] = field(default_factory=dict)
    total_questions: int = 0
    total_errors: int = 0

    STATE_FILE = ".pipeline_state.json"

    def save(self, output_dir: Path) -> None:
        """Persist state to disk."""
        output_dir = Path(output_dir)
        state_path = output_dir / self.STATE_FILE
        data = {
            "run_id": self.run_id,
            "subject": self.subject,
            "syllabus_code": self.syllabus_code,
            "level": self.level,
            "started_at": self.started_at,
            "total_questions": self.total_questions,
            "total_errors": self.total_errors,
            "papers": {
                code: record.to_dict()
                for code, record in self.papers.items()
            },
        }
        output_dir.mkdir(parents=True, exist_ok=True)
        # Atomic write (final-upgrade Issue 6, 2026-08-10, approved):
        # dump to a temp sibling then os-replace, so a crash mid-save can
        # never corrupt the on-disk state the resume path depends on.
        temp_path = output_dir / f"{self.STATE_FILE}.tmp"
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        temp_path.replace(state_path)

        # RS-13 (state→SQLite cutover, phase 1 — mandated 2026-08-11):
        # dual-write the identical snapshot into <output>/pipeline.sqlite.
        # The JSON above remains the sole authority; a mirror failure never
        # affects the run (loud warning only). Parity is verified at S8.
        try:
            from .state_mirror import mirror_state_to_db
            mirror_state_to_db(self, output_dir)
        except Exception as exc:  # mirror must never kill a run
            print(f"  [state-mirror] WARNING: DB mirror skipped ({exc}) — JSON state authoritative")

    def register_paper(
        self,
        paper_code: str,
        qp_path: str = "",
        ms_path: Optional[str] = None,
        er_path: Optional[str] = None,
    ) -> None:
        """FIX-P1: idempotent registration; never downgrades COMPLETE."""
        if paper_code in self.papers:
            rec = self.papers[paper_code]
            if rec.status is PaperStatus.COMPLETE:
                return
            # refresh paths (inputs may have moved between runs)
            rec.qp_path = qp_path or rec.qp_path
            rec.ms_path = ms_path or rec.ms_path
            rec.er_path = er_path or rec.er_path
            if rec.status is PaperStatus.PROCESSING:
                # crashed mid-run last time: reset to pending for a clean retry
                rec.status = PaperStatus.PENDING
            return
        self.papers[paper_code] = PaperRecord(
            paper_code=paper_code, qp_path=qp_path, ms_path=ms_path, er_path=er_path,
        )

    @classmethod
    def load_or_create(
        cls,
        output_dir: Path,
        subject: str,
        syllabus_code: str,
        level: str,
    ) -> "PipelineState":
        """Load existing state or create fresh."""
        output_dir = Path(output_dir)
        state_path = output_dir / cls.STATE_FILE
        if state_path.exists():
            with open(state_path, encoding="utf-8") as f:
                data = json.load(f)
            state = cls(
                run_id=data["run_id"],
                subject=data["subject"],
                syllabus_code=data["syllabus_code"],
                level=data["level"],
                started_at=data["started_at"],
                total_questions=data.get("total_questions", 0),
                total_errors=data.get("total_errors", 0),
            )
            for code, record_data in data.get("papers", {}).items():
                state.papers[code] = PaperRecord.from_dict(record_data)

            pending = sum(1 for r in state.papers.values() if r.status == PaperStatus.PENDING)
            complete = sum(1 for r in state.papers.values() if r.status == PaperStatus.COMPLETE)
            failed = sum(1 for r in state.papers.values() if r.status == PaperStatus.FAILED)
            logger.info(
                "Resuming pipeline run %s. Complete: %d, Pending: %d, Failed: %d",
                state.run_id, complete, pending, failed,
            )
            return state

        # Fresh state
        import uuid
        state = cls(
            run_id=str(uuid.uuid4())[:8],
            subject=subject,
            syllabus_code=syllabus_code,
            level=level,
            started_at=time.time(),
        )
        logger.info("New pipeline run: %s", state.run_id)
        return state

    def mark_processing(self, paper_code: str) -> None:
        if paper_code in self.papers:
            self.papers[paper_code].status = PaperStatus.PROCESSING
            self.papers[paper_code].started_at = time.time()

    def mark_complete(
        self,
        paper_code: str,
        questions_found: int,
        questions_saved: int,
    ) -> None:
        if paper_code in self.papers:
            record = self.papers[paper_code]
            record.status = PaperStatus.COMPLETE
            record.questions_found = questions_found
            record.questions_saved = questions_saved
            record.completed_at = time.time()
            self.total_questions += questions_saved

    def mark_review_required(self, paper_code: str, reason: str) -> None:
        """Mega-spec Fix 1: ambiguous/unsupported input -> REVIEW_REQUIRED with
        the exact reason. Distinct from FAILED so --retry-failed never silently
        re-attempts what already asked for human review."""
        if paper_code in self.papers:
            rec = self.papers[paper_code]
            rec.status = PaperStatus.REVIEW_REQUIRED
            rec.review_reason = reason
            rec.completed_at = time.time()

    def reset_failed(self, include_review: bool = False) -> int:
        """--retry-failed: return FAILED (optionally REVIEW_REQUIRED) records to
        PENDING so the run re-attempts them. Returns the reset count."""
        n = 0
        for rec in self.papers.values():
            if rec.status is PaperStatus.FAILED or (
                    include_review and rec.status is PaperStatus.REVIEW_REQUIRED):
                rec.status = PaperStatus.PENDING
                rec.error_message = ""
                n += 1
        return n

    def mark_failed(self, paper_code: str, error: str) -> None:
        if paper_code in self.papers:
            record = self.papers[paper_code]
            record.status = PaperStatus.FAILED
            record.error_message = error
            record.completed_at = time.time()
            self.total_errors += 1

    def should_skip(self, paper_code: str) -> bool:
        """True if this paper was already completed successfully."""
        record = self.papers.get(paper_code)
        return record is not None and record.status == PaperStatus.COMPLETE

    def print_summary(self) -> None:
        total = len(self.papers)
        complete = sum(1 for r in self.papers.values() if r.status == PaperStatus.COMPLETE)
        failed = sum(1 for r in self.papers.values() if r.status == PaperStatus.FAILED)
        pending = sum(1 for r in self.papers.values() if r.status == PaperStatus.PENDING)
        elapsed = time.time() - self.started_at
        mins = int(elapsed // 60)
        secs = int(elapsed % 60)

        print("\n" + "=" * 60)
        print(f" PIPELINE SUMMARY — Run {self.run_id}")
        print("=" * 60)
        print(f" Subject: {self.subject} {self.syllabus_code}")
        print(f" Papers total: {total}")
        print(f" Complete:   {complete}")
        print(f" Failed:     {failed}")
        print(f" Pending:    {pending}")
        print(f" Questions saved: {self.total_questions}")
        print(f" Errors:          {self.total_errors}")
        print(f" Time elapsed: {mins}m {secs}s")
        if failed > 0:
            print("\n FAILED PAPERS:")
            for code, record in self.papers.items():
                if record.status == PaperStatus.FAILED:
                    print(f"  {code}: {record.error_message[:80]}")
        print("=" * 60 + "\n")
