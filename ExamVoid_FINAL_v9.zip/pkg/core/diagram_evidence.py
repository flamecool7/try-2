"""Deterministic diagram-evidence harvester (mega-spec Fix 8).

Given a question crop raster (numpy array) and its extracted text, produce a
small dict of *counts* of geometric diagram classes. These signals only ever
SUPPLEMENT text/formula evidence in the math classifiers — a question with no
supporting text and only an ambiguous drawing (e.g. one plain triangle) yields
no confident topic and is routed by the caller to REVIEW_REQUIRED.

Recognised classes (per spec Fix 8 enumeration):
  triangles            - closed 3-vertex polygons
  angle_arcs           - open arc contours (not full circles), arc-radius 6..120px
  sectors              - arc with two bounding radii nearby (pie/sector shapes)
  circles              - closed near-circular contours
  vector_arrows        - straight segments with an arrowhead fan at one endpoint
  force_arrows         - vector_arrows when the question text mentions force,
                         weight, tension, friction or thrust (documented heuristic)
  axes_with_curve      - long orthogonal axis pair plus a free curve contour
  bar_blocks           - >=3 adjacent equal-width filled bars (histogram/frequency)
  greek_labels         - theta/pi/degree/alpha/beta/lambda symbols in the text
  normal_curves        - 0 from raster (text layer owns this; kept for schema)
  probability_trees    - 0 from raster (text layer owns this; kept for schema)

Everything is plain cv2/numpy geometry — no network, no model download, fully
deterministic for a fixed input raster.
"""
from __future__ import annotations

from typing import Dict

import math
import numpy as np

_GREEK_CHARS = "θπαβλφΔΣμ"
# Degree sign deliberately EXCLUDED: angles are geometry/mensuration
# vocabulary; counting ° as trig greek-notation created near-ties on
# geometry questions (0580 Q13 cyclic quadrilateral, corpus 2026-08-13).


def _to_gray(arr: np.ndarray) -> np.ndarray:
    if arr.ndim == 3:
        arr = arr[..., :3]
        gray = (0.299 * arr[..., 0] + 0.587 * arr[..., 1] + 0.114 * arr[..., 2]).astype(np.uint8)
    else:
        gray = arr.astype(np.uint8)
    return gray


def harvest_diagram_evidence(image: np.ndarray, text: str = "") -> Dict[str, int]:
    """Return the diagram-signal counts for one question crop. Never raises."""
    import cv2

    gray = _to_gray(image)
    # Ink mask: dark pixels on light paper.
    ink = (gray < 128).astype(np.uint8) * 255
    # Ignore tiny rasters — nothing trustworthy at thumbnail scale.
    h, w = gray.shape
    if h < 40 or w < 40:
        return _zero(text)

    signals = _zero(text)

    contours, _hier = cv2.findContours(ink, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    triangles = circles = arcs = 0
    curve_contours = 0
    arc_items = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < 60:
            continue
        peri = cv2.arcLength(cnt, True)
        if peri <= 0:
            continue
        approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
        # 2026-08-13: glyph floor — body-text 'A'/'V' polygons are ~150-400px²
        # at 2280px crop width; drawn geometry triangles are 10x larger.
        if cv2.isContourConvex(approx) and len(approx) == 3 and area > 500:
            triangles += 1
            continue
        circularity = 4.0 * math.pi * area / (peri * peri)
        closed = cv2.isContourConvex(approx) or circularity > 0.95
        if circularity >= 0.80 and len(approx) >= 5:
            (_x, _y), radius = cv2.minEnclosingCircle(cnt)
            if 14 <= radius <= 300:   # 2026-08-13: exclude text-glyph holes
                circles += 1
                continue
        # Arc-like: fits a circle of sane radius but is visibly open/short.
        if len(cnt) >= 5:
            (_x, _y), radius = cv2.minEnclosingCircle(cnt)
            if 14 <= radius <= 120:   # 2026-08-13: exclude text-glyph arcs
                # extent = contour area vs its bounding circle sector area
                chord = cv2.arcLength(cnt, False)
                frac = chord / (2.0 * math.pi * radius)
                if 0.05 <= frac <= 0.75 and area < 0.6 * math.pi * radius * radius:
                    arcs += 1
                    arc_items.append((float(_x), float(_y), float(radius)))
                    continue
        # Free curve heuristic: long non-convex open contour.
        hull = cv2.convexHull(cnt)
        hull_area = cv2.contourArea(hull)
        if hull_area > 0 and area / hull_area < 0.75 and peri > 120:
            curve_contours += 1

    # Sector: an arc whose fitted circle centre has two straight radii nearby —
    # approximated cheaply as 'arc with above-average straight-line spokes'.
    lines = cv2.HoughLinesP(ink, 1, np.pi / 180, threshold=max(20, min(h, w) // 12),
                            minLineLength=max(15, min(h, w) // 20), maxLineGap=4)
    segs = []
    if lines is not None:
        for ln in np.asarray(lines).reshape(-1, 4)[:600]:
            x1, y1, x2, y2 = (int(v) for v in ln)
            length = math.hypot(x2 - x1, y2 - y1)
            angle = math.degrees(math.atan2(y2 - y1, x2 - x1)) % 180.0
            segs.append((x1, y1, x2, y2, length, angle))

    sectors = 0
    for (cx, cy, r) in arc_items:
        spokes = sum(
            1 for (x1, y1, x2, y2, length, _a) in segs
            if length >= 0.6 * r and min(math.hypot(x1 - cx, y1 - cy),
                                          math.hypot(x2 - cx, y2 - cy)) <= 0.5 * r
        )
        if spokes >= 2:
            sectors += 1

    # Arrows: a long-ish segment whose endpoint collects 2+ short fan segments
    # at 15..75 degrees (arrowhead barbs).
    arrows = 0
    long_segs = [s for s in segs if s[4] >= max(30, min(h, w) // 10)]
    short_segs = [s for s in segs if 6 <= s[4] < max(30, min(h, w) // 10)]
    for (x1, y1, x2, y2, length, angle) in long_segs:
        for (ex, ey) in ((x1, y1), (x2, y2)):
            barbs = 0
            for (a1, b1, a2, b2, slen, sang) in short_segs:
                mx, my = (a1 + a2) / 2.0, (b1 + b2) / 2.0
                if math.hypot(mx - ex, my - ey) <= max(10, slen):
                    d = abs((sang - angle + 90) % 180 - 90)
                    if 15 <= d <= 75:
                        barbs += 1
            if barbs >= 2:
                arrows += 1
                break

    # Axes + curve: one near-horizontal and one near-vertical long segment plus
    # at least one free curve contour.
    horiz = any(s[4] >= 0.35 * w and (s[5] < 8 or s[5] > 172) for s in segs)
    vert = any(s[4] >= 0.30 * h and 82 <= s[5] <= 98 for s in segs)
    axes_curve = 1 if (horiz and vert and curve_contours >= 1) else 0

    # Histogram bars: >=3 rectangular filled blocks of similar width side by side.
    rect_count = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < 120:
            continue
        peri = cv2.arcLength(cnt, True)
        if peri <= 0:
            continue
        approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
        x, y, bw, bh = cv2.boundingRect(approx)
        if len(approx) == 4 and bh > 1.6 * max(bw, 1) and (area / float(bw * bh)) > 0.7:
            rect_count += 1
    bar_blocks = rect_count if rect_count >= 3 else 0

    # ── corpus-derived diagram classes (2026-08-13) ─────────────────────
    # Deterministic geometry only; each class was validated against the
    # June-2024 corpus of 27 real Cambridge QPs.  A class is only emitted
    # when the geometry is unambiguous; downstream topic boosts stay small
    # and only ever SUPPLEMENT text evidence.
    #
    # Venn diagram: >=2 large ellipse-like closed contours whose bounding
    # boxes overlap (set-notation / probability questions).
    big_closed = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < 800:   # 2026-08-13: Venn circles are 5000+; glyphs below
            continue
        peri = cv2.arcLength(cnt, True)
        if peri <= 0:
            continue
        circularity = 4.0 * math.pi * area / (peri * peri)
        if circularity >= 0.55 and len(cnt) >= 5:
            big_closed.append(cnt)
    # Venn: pairs of SIMILAR-SIZED, PARTIALLY-OVERLAPPING blobs (circle pairs
    # with a lens). Nested contours (overlap ~1.0) and 3D-solid face pairs
    # (overlap > 0.7 or wildly different sizes) are excluded. A real Venn
    # yields 1-4 such pairs; illustrations with many blobs exceed 4.
    venn = 0
    if len(big_closed) >= 2:
        pairs = 0
        for i in range(len(big_closed)):
            x1, y1, bw1, bh1 = cv2.boundingRect(big_closed[i])
            a1 = cv2.contourArea(big_closed[i])
            for j in range(i + 1, len(big_closed)):
                x2, y2, bw2, bh2 = cv2.boundingRect(big_closed[j])
                ix = max(0, min(x1 + bw1, x2 + bw2) - max(x1, x2))
                iy = max(0, min(y1 + bh1, y2 + bh2) - max(y1, y2))
                ov = ix * iy
                mn = min(bw1 * bh1, bw2 * bh2)
                a2 = cv2.contourArea(big_closed[j])
                r = min(a1, a2) / max(a1, a2) if max(a1, a2) else 0
                if 0.08 <= ov / mn <= 0.70 and r >= 0.25:
                    pairs += 1
        venn = 1 if 1 <= pairs <= 8 else 0   # 2 Venns in one crop = up to 8 lens pairs

    # Bond-line / structural formula: many SHORT segments whose angles sit
    # near 60 deg or 120 deg (mod 180) — the zigzag grammar of drawn organic
    # structures.  Text-only answers (no zigzag) emit 0.
    short_segs = [s for s in segs if 14 <= s[4] <= 110]
    zig = sum(1 for s in short_segs if abs(((s[5] - 60) % 180) - 0) <= 12
              or abs(((s[5] - 120) % 180) - 0) <= 12)
    bond_line = zig if zig >= 4 else 0

    # Energy-level diagram: >=2 long horizontal lines at clearly distinct
    # heights plus a vertical connecting segment (enthalpy / nuclear levels).
    hlines = sorted({round(s[1], 1) for s in segs
                     if s[4] >= 0.30 * w and (s[5] < 5 or s[5] > 175)})
    vsegs = [s for s in segs if 82 <= s[5] <= 98 and s[4] >= 0.12 * h]
    energy_levels = 1 if (len(hlines) >= 2 and vsegs) else 0

    # Wave train: >=5 small arcs of similar radius whose centres share a
    # horizontal band (wavefronts / diffraction patterns).
    if len(arc_items) >= 5:
        radii = [r for (_x, _y, r) in arc_items]
        ys = [y for (_x, y, _r) in arc_items]
        r_med = sorted(radii)[len(radii) // 2]
        r_ok = sum(1 for r in radii if 0.5 * r_med <= r <= 2.0 * r_med)
        y_span = max(ys) - min(ys)
        wave_train = 1 if (r_ok >= 5 and y_span <= 0.35 * h) else 0
    else:
        wave_train = 0

    # Circuit-like: >=2 small closed contours (component symbols / junctions)
    # together with many long straight segments (wires).
    small_closed = sum(1 for cnt in contours
                       if 60 <= cv2.contourArea(cnt) <= 900)
    long_seg_n = sum(1 for s in segs if s[4] >= max(40, min(h, w) // 16))
    circuit_like = 1 if (small_closed >= 2 and long_seg_n >= 6) else 0

    # Grid / table: >=2 long horizontal AND >=2 long vertical segments
    # (data tables, periodic-table fragments, Punnett squares, graph grids).
    nh = sum(1 for s in segs if s[4] >= 0.30 * w and (s[5] < 8 or s[5] > 172))
    nv = sum(1 for s in segs if s[4] >= 0.22 * h and 82 <= s[5] <= 98)
    grid_table = 1 if (nh >= 2 and nv >= 2) else 0

    # Cell-like / organism diagram: one large closed contour containing
    # >=3 smaller closed contours (nucleus, organelles, dots of a specimen).
    cell_like = 0
    if len(big_closed) >= 1:
        outer = max(big_closed, key=cv2.contourArea)
        ox, oy, ow_, oh_ = cv2.boundingRect(outer)
        inner = sum(1 for cnt in contours
                    if 60 <= cv2.contourArea(cnt) <= 0.5 * cv2.contourArea(outer)
                    and (ox <= cv2.boundingRect(cnt)[0] <= ox + ow_
                         and oy <= cv2.boundingRect(cnt)[1] <= oy + oh_))
        cell_like = 1 if inner >= 3 else 0

    signals["triangles"] = triangles
    signals["circles"] = circles
    signals["angle_arcs"] = max(0, arcs - sectors)
    signals["sectors"] = sectors
    signals["vector_arrows"] = arrows
    lowered = text.lower() if text else ""
    if arrows and any(k in lowered for k in ("force", "weight", "tension", "friction", "thrust", "newton")):
        signals["force_arrows"] = arrows
    signals["axes_with_curve"] = axes_curve
    signals["bar_blocks"] = bar_blocks

    signals["venn_diagram"] = venn
    signals["bond_line_structure"] = bond_line
    signals["energy_levels"] = energy_levels
    signals["wave_train"] = wave_train
    signals["circuit_like"] = circuit_like
    signals["grid_table"] = grid_table
    signals["cell_like"] = cell_like
    return signals


def _zero(text: str) -> Dict[str, int]:
    greek = sum(text.count(ch) for ch in _GREEK_CHARS) if text else 0
    return {
        "triangles": 0,
        "circles": 0,
        "angle_arcs": 0,
        "sectors": 0,
        "vector_arrows": 0,
        "force_arrows": 0,
        "axes_with_curve": 0,
        "bar_blocks": 0,
        "greek_labels": greek,
        "normal_curves": 0,
        "probability_trees": 0,
        "venn_diagram": 0,
        "bond_line_structure": 0,
        "energy_levels": 0,
        "wave_train": 0,
        "circuit_like": 0,
        "grid_table": 0,
        "cell_like": 0,
    }
