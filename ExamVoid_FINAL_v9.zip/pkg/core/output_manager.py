"""
Output Manager - Universal component supporting IGCSE + A-Level
Implements:
- JSON inside question folder (R1 previous fix)
- Topic folder is a byte-for-byte copy of metadata.json topic[0] (canonical)
- No empty folders, only create when actual question classified (R4)
- Winning major via point system, no duplication (R5,R6)
- Question folder naming Variant_Season_Year_QuestionNumber e.g., 41_Winter_2025_Q2 (R7)
- NEW: Paper type separation P2_AS_Structured, P4_A2_Structured, MCQ_P1 etc. (user request)
  Structure: Level/Subject/PaperType/Major/QuestionFolder/
  Example: A-Level/Chemistry_9701/P2_AS_Structured/Equilibria/41_Winter_2025_Q2/
"""

from pathlib import Path
from typing import List, Dict
from PIL import Image
from .qp_ms_matcher import MatchedQuestion
from .classifier import ClassificationResult
from .config_loader import SubjectConfig
import json
import logging
import re
import shutil

logger = logging.getLogger(__name__)

# Audit fix-group 7 C4: fields that must never persist in metadata.json.
FORBIDDEN_METADATA_FIELDS = {
    "topic_details", "primary", "secondary", "needs_review",
    "topic_scores", "primary_topic", "secondary_topics",
}

# Paper type folders - from gold-standard organize.py
_PAPER_FOLDER_BY_N = {
    2: "P2_AS_Structured",
    3: "P3_Practical_Skills",
    4: "P4_A2_Structured",
    5: "P5_Plan_Analysis",
    6: "P6_Alt_to_Practical",
}

_CS_9618_PAPER_FOLDERS = {
    1: "P1_Theory_Fundamentals",
    2: "P2_Problem_Solving_Programming",
    3: "P3_Advanced_Theory",
    4: "P4_Practical",
}

# User-requested maths paper-title folders.
_MATHS_PAPER_TITLE_FOLDERS = {
    "9709": {
        1: "Pure Maths 1",
        2: "Pure Maths 2",
        3: "Pure Maths 3",
        4: "Mechanics 1",
        5: "Statistics 1",
        6: "Statistics 2",
    },
    "9231": {
        1: "Further Pure Maths 1",
        2: "Further Pure Maths 2",
        3: "Further Mechanics 1",
        4: "Further Statistics 1",
    },
    "0580": {
        1: "Non-Calculator Core",
        2: "Calculator Core",
        3: "Non-Calculator Extended",
        4: "Calculator Extended",
    },
    "0606": {
        1: "Additional Maths Paper 1",
        2: "Additional Maths Paper 2",
    },
}

_MATHS_PAPER_TITLE_NAMES = {
    name for mapping in _MATHS_PAPER_TITLE_FOLDERS.values() for name in mapping.values()
}

def _is_mcq_paper(paper_code: str, syllabus: str = None) -> bool:
    """Unified-MCQ round (STEP-7 audit): MCQ status comes ONLY from
    core.mcq_registry.is_mcq (RULE 1). Thin adapter for the legacy call
    signature; syllabus=None keeps the historical any-syllabus P1 behaviour."""
    code = str(paper_code or "").lstrip("0")
    if not code or code[0] != "1":
        return False
    if syllabus is None:
        return True
    from .mcq_registry import is_mcq
    return is_mcq(str(syllabus), code)

# IGCSE paper-format round (user decision taxonomy=rename): suffix per
# resolved format. Names feed folder tokens in core/validation.py.
_IGCSE_FORMAT_SUFFIX = {"MCQ": "MCQ", "STRUCTURED": "Structured",
                        "PRACTICAL": "Practical", "ATP": "ATP", "ESSAY": "Essay"}


def _igcse_folder_map():
    """Lazy accessor for paper_identifier.IGCSE_COMPONENT_MAP — single source
    of truth, so the detection side and the folder side can never disagree."""
    try:
        from .paper_identifier import IGCSE_COMPONENT_MAP
        return IGCSE_COMPONENT_MAP
    except Exception:
        return {}


def _paper_type_folder(paper_code: str, syllabus_code: str = None) -> str:
    """Determine the paper-category folder.

    User-directed exception: maths subjects use the paper title as the main
    folder instead of the generic Pn_* routing token.
    """
    code = str(paper_code or "").lstrip("0") or str(paper_code or "")
    try:
        n = int(code[0]) if code and code[0].isdigit() else 2
    except Exception:
        n = 2

    _math_titles = _MATHS_PAPER_TITLE_FOLDERS.get(str(syllabus_code))
    if _math_titles and n in _math_titles:
        return _math_titles[n]

    if str(syllabus_code) == "9618":
        return _CS_9618_PAPER_FOLDERS.get(n, f"P{n}_Structured")

    # IGCSE paper-format round (user decision taxonomy=rename): truthful IGCSE
    # component folders resolved from the SAME map paper_identifier uses.
    # Non-IGCSE codes fall through to the legacy A-Level ladder UNCHANGED.
    # Resolve by FORMAT (paper-number aware) for every IGCSE syllabus code, so
    # Cambridge-added variant digits (14, 24, 34, 54, 64, ...) still get the
    # correct folder instead of falling through to the A-Level ladder.
    _igcse = _igcse_folder_map().get(str(syllabus_code)) if syllabus_code is not None else None
    if _igcse is not None:
        from .paper_identifier import resolve_paper_format
        _fmt = resolve_paper_format(str(syllabus_code), code)
        return f"P{n}_{_IGCSE_FORMAT_SUFFIX.get(_fmt, 'Structured')}"

    if n == 1:
        if _is_mcq_paper(paper_code, syllabus=syllabus_code):
            return "P1_MCQ"
        else:
            return "P1_Structured"

    return _PAPER_FOLDER_BY_N.get(n, f"P{n}_Structured")

def _is_review_required_no_ms(question_folder: Path) -> bool:
    """RS-5 (Overseer review_required): True when this folder is a deliberate
    review_required/no_markscheme home — the only place a missing MS webp is legal."""
    if question_folder.parent.name != "review_required":
        return False
    try:
        t = json.loads((question_folder / "metadata.json").read_text(encoding="utf-8")).get("topic")
    except Exception:
        return False
    return isinstance(t, list) and bool(t) and t[0] == "review_required_no_ms"


def _is_review_required_no_qp(question_folder: Path) -> bool:
    """2026-08-15: True when this folder is a review_required/missing_qp home —
    the only place a missing QP webp is legal (MS crop preserved instead)."""
    if question_folder.parent.name != "review_required":
        return False
    try:
        t = json.loads((question_folder / "metadata.json").read_text(encoding="utf-8")).get("topic")
    except Exception:
        return False
    return isinstance(t, list) and bool(t) and t[0] == "review_required_no_qp"


def _is_paper_type_dir_name(name: str) -> bool:
    if name == "loading..":
        return True
    if name in _MATHS_PAPER_TITLE_NAMES:
        return True
    if name.startswith("P") and ("_Structured" in name or "_MCQ" in name or "MCQ" in name
                                  or "Practical" in name or "_ATP" in name or "_Essay" in name
                                  or "Plan_Analysis" in name or "Alt_to_Practical" in name
                                  or name.startswith("P1_") or name.startswith("P2_")
                                  or name.startswith("P3_") or name.startswith("P4_")):
        return True
    return False


class OutputManager:
    def __init__(self, output_root: str | Path = "output", target_width=2280, quality=95):
        self.output_root = Path(output_root)
        self.target_width = target_width
        self.quality = quality
        self.output_root.mkdir(parents=True, exist_ok=True)

    def get_major_topic_path(self, level: str, subject: str, paper_type_folder: str, topic: str) -> Path:
        """
        Get path for major topic folder including level and paper type
        NEW STRUCTURE with paper type separation: Level/Subject/PaperType/Major
        Example: A-Level/Chemistry_9701/P2_AS_Structured/Equilibria/
        """
        # CRITICAL: Folder name must be direct copy of winning_topic, exact string
        # Preserves comma, semicolon per R10
        if paper_type_folder:
            return self.output_root / level / subject / paper_type_folder / topic
        else:
            return self.output_root / level / subject / topic

    def get_question_folder_path(self, level: str, subject: str, paper_type_folder: str, major_topic: str, question_folder_name: str) -> Path:
        major_path = self.get_major_topic_path(level, subject, paper_type_folder, major_topic)
        return major_path / question_folder_name

    def save_question_pair(self, matched: MatchedQuestion, classification: ClassificationResult, config: SubjectConfig) -> Dict[str, Path]:
        """
        Save QP/MS webp + metadata.json inside question folder
        NEW STRUCTURE: Level/Subject/PaperType/Major/QuestionFolder/
        Example: A-Level/Chemistry_9701/P2_AS_Structured/Equilibria/41_Winter_2025_Q2/
                 ├── 41_Winter_2025_Q2.webp
                 ├── 41_Winter_2025_Q2_MS.webp
                 ├── metadata.json
                 └── examiner_report.txt (if available)

        CRITICAL: Folder name = winning_topic exact, no transformation
        Question folder = Variant_Season_Year_QuestionNumber exact
        """
        winning_major = classification.winning_major
        subject = config.subject
        level = config.level

        # Determine paper type folder: P2_AS_Structured, P4_A2_Structured, MCQ_P1, etc.
        # Use matched.variant (e.g., 22 -> P2, 42 -> P4, 12 -> MCQ_P1)
        # Also use syllabus code for CS 9618 special handling
        paper_type_folder = _paper_type_folder(matched.variant, syllabus_code=config.syllabus_code)

        # Validate winning_major is actual syllabus major topic
        if winning_major not in config.major_topics:
            broad_categories = ["Organic_Chemistry", "Inorganic_Chemistry", "Physical_Chemistry"]
            if winning_major in broad_categories:
                print(f"[OutputManager] WARNING: Winning topic {winning_major} is broad category, not actual syllabus topic for {config.subject}")

        # RS-17 (spec: no `loading` folders, no pre-created topic folders, no
        # topic=[] math metadata): Mathematics 9709/9231/0580 classify at
        # question level into official topic names; the recorded topic[0] drives
        # the physical folder like every other subject. Zero-evidence questions
        # never reach here — S5 routes them to review_required upstream.
        json_data = self._generate_json_data(matched, classification, config)
        # The actual topic string recorded in JSON is the only source for
        # the physical topic-folder name.
        assigned_topic = json_data["topic"][0]
        if not isinstance(assigned_topic, str) or not assigned_topic:
            raise ValueError("metadata topic[0] must be a non-empty topic string")
        major_path = self.get_major_topic_path(level, subject, paper_type_folder, assigned_topic)
        major_path.mkdir(parents=True, exist_ok=True)

        # Question folder naming: Variant_Season_Year_QuestionNumber
        variant = matched.variant
        season = matched.season
        year = matched.year
        qnum = matched.question_number

        question_folder_name = f"{variant}_{season}_{year}_{qnum}"
        question_folder = major_path / question_folder_name

        if True:  # RS-17: staging branch deleted; invariant applies to every subject.
            # Audit fix-group 6 C3: single-folder invariant enforcement.
            # If a same-named question folder already exists under a DIFFERENT
            # topic folder, writing here would duplicate the question into a
            # second physical topic (forbidden by invariant R?). Log loudly and
            # skip the write; same-folder rewrites (idempotent re-runs) are fine.
            dupes = [
                d for d in (self.output_root / level / subject).rglob(question_folder_name)
                if d.is_dir() and d != question_folder
            ]
            if dupes:
                unc_dupes = [d for d in dupes if self.UNC_FOLDER in d.parts]
                real_dupes = [d for d in dupes if self.UNC_FOLDER not in d.parts]
                if not real_dupes:
                    # RS-5 promotion: the question now has a REAL classification
                    # (e.g. MS arrived and the paper re-ran). Retire the stale
                    # review_required twin so the single-folder invariant holds.
                    for d in unc_dupes:
                        print(f"[OutputManager] promotion: retiring review_required twin {d} "
                              f"(real classification arrived for {question_folder_name})")
                        shutil.rmtree(d)
                else:
                    logger.error(
                        "INVARIANT VIOLATION: %s already exists at %s — skipping write (no duplicate)",
                        question_folder_name, real_dupes[0],
                    )
                    return {"skipped_duplicate": True, "existing": real_dupes[0],
                            "question_folder": real_dupes[0]}

        question_folder.mkdir(parents=True, exist_ok=True)

        # File names inside question folder: same base as folder name
        qp_path = question_folder / f"{question_folder_name}.webp"
        ms_path = question_folder / f"{question_folder_name}_MS.webp"
        json_path = question_folder / "metadata.json"

        # IGCSE paper-format round (user decision mcq_ms=letters): an MCQ
        # question has NO mark-scheme image — Cambridge publishes a bare
        # answer grid. The extracted grid letter rides in metadata
        # (ms_answer); an MS webp is never fabricated from it.
        _mcq_answer = getattr(matched, "ms_answer", None)
        # Unified-MCQ round (approved Q2=additive, Q3=literal-writer): MCQ
        # status from the registry (RULE 1). User requirement (2026-08-14):
        # metadata.json carries ONLY the canonical 11 fields — the answer
        # letter rides in the `*_MS.txt` sidecar (written below), never in
        # metadata. _MS.txt is ALWAYS written for MCQ components — letter+\n,
        # or EMPTY+loud when the letter is unavailable (Rule 3: never skip).
        from .mcq_registry import is_mcq as _reg_is_mcq
        _mcq_paper = _reg_is_mcq(getattr(config, "syllabus_code", ""),
                                 getattr(matched, "variant", ""))

        self._save_image(matched.qp.assembled_image, qp_path)
        _ms_missing = getattr(matched, "ms", None) is None
        if not _mcq_paper and not _ms_missing:
            self._save_image(matched.ms.assembled_image, ms_path)

        # Save the same canonical metadata that supplied the folder name.
        # Only the canonical 11 fields persist (user requirement 2026-08-14).
        from .json_generator import canonical_metadata
        json_data = canonical_metadata(json_data)
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, indent=4)

        _ms_txt = None
        if _mcq_paper:
            from .mcq_output import write_mcq_ms, validate_mcq_ms_file
            _ms_txt = write_mcq_ms(question_folder, question_folder_name,
                                   _mcq_answer)
            if not validate_mcq_ms_file(_ms_txt):
                print(f"[OutputManager] ! MCQ _MS.txt empty/invalid for "
                      f"{question_folder_name} (letter {_mcq_answer!r}) — "
                      f"visible to audit (Rule 3/4)")
        elif _ms_missing:
            # QP-only mode (trust-self, run_guarded S5): no MS supplied —
            # write the placeholder sidecar so the folder is a legal MS-less
            # home (validators accept the marker; it is NEVER a fabricated
            # mark scheme). Fixes exit-code-1 crash: save_question_pair used
            # to dereference matched.ms.assembled_image with ms=None.
            from .mcq_output import PLACEHOLDER_MS_CONTENT
            _ms_txt = question_folder / f"{question_folder_name}_MS.txt"
            _ms_txt.write_text(PLACEHOLDER_MS_CONTENT + "\n", encoding="utf-8")
            # User requirement (2026-08-14): the crop is STILL categorized,
            # and a REASON.txt explains WHY review is needed — the question
            # never silently disappears.
            (question_folder / "REASON.txt").write_text(
                "REVIEW NEEDED — mark scheme unavailable\n"
                "========================================\n"
                f"Question: {question_folder_name}\n"
                f"Paper:    {matched.full_qp_code}\n"
                "Status:   Cropped and categorized (full-auto).\n"
                "Reason:   The mark scheme for this paper was not available.\n"
                "          The question is routed to its best topic, but the\n"
                "          answer key cannot be verified.\n"
                "Action:   Review this question when the mark scheme is\n"
                "          available and verify the routed topic/answer.\n",
                encoding="utf-8")

        assert qp_path.exists(), f"QP not saved: {qp_path}"
        if not _mcq_paper and not _ms_missing:
            assert ms_path.exists(), f"MS not saved: {ms_path}"
        assert json_path.exists(), f"JSON not saved: {json_path}"
        # RS-17: staging branch deleted — folder/topic[0] invariant holds for
        # every subject, Mathematics included.
        assert major_path.name == assigned_topic, (
            f"Topic folder {major_path.name!r} != metadata topic[0] {assigned_topic!r}"
        )

        return {
            "qp": qp_path,
            "ms": None if (_mcq_paper or _ms_missing) else ms_path,
            "ms_txt": _ms_txt,
            "json": json_path,
            "major": major_path,
            "paper_type": paper_type_folder,
            "question_folder": question_folder,
            "question_folder_name": question_folder_name,
            "winning_major": winning_major,
            "assigned_topic": assigned_topic,
            "level": level
        }

    UNC_FOLDER = "review_required"  # RS-5 (Overseer review_required directive)
    UNC_SENTINELS = {"classification_failed": "review_required",
                     "no_markscheme": "review_required_no_ms",
                     "missing_qp": "review_required_no_qp",
                     "review_required": "review_required"}
    UNC_REASON_MESSAGES = {
        "review_required": (
            "This question needs human review before it can be routed to an "
            "official syllabus topic.\n\n"
            "Possible causes:\n"
            "- No deterministic text / formula / diagram evidence for any "
            "official topic (spec: ambiguous input must surface REVIEW_REQUIRED "
            "rather than guess)\n"
            "- Extraction-poor scan; consider a higher-quality source PDF\n\n"
            "Action: Review manually and move to the correct topic folder."
        ),
        "classification_failed": (
            "This question could not be confidently assigned "
            "to any topic in the taxonomy.\n\n"
            "Possible causes:\n"
            "- Question text is too short or diagram-only\n"
            "- Topic keywords not in taxonomy JSON\n"
            "- All topic scores below minimum threshold\n\n"
            "Action: Review manually and move to correct topic."
        ),
        "no_markscheme": (
            "No mark scheme was found for this question.\n\n"
            "Possible causes:\n"
            "- MS PDF was not provided for this paper\n"
            "- Question number not found in MS PDF\n"
            "- MS PDF filename does not match QP filename\n\n"
            "Action: Locate the correct MS PDF and reprocess."
        ),
        "missing_qp": (
            "No question paper (QP) was found for this bundle, so the question "
            "could not be cropped or classified.\n\n"
            "The mark-scheme crop is preserved here for reference.\n\n"
            "Action: Locate the correct QP PDF and reprocess the bundle."
        ),
    }

    def save_review_required_question(self, matched, reason: str, config) -> Dict[str, Path]:
        """RS-5 (Overseer review_required directive, user-approved decisions):
        route a question to output/{Level}/{Subject}/review_required/{QID}/.

        Decisions applied: desperate_only trigger (callers check fallback_tier),
        adopt_keep_crop (QP crop ALWAYS saved — never discard a crop),
        single_level structure (REASON.txt distinguishes reasons), quality_scorer
        reporting. classification_failed folders keep QP+MS+metadata+REASON.txt
        (4 files); no_markscheme folders have QP+metadata+REASON.txt (no MS
        exists in that branch; the 4-file rule cannot apply by definition).

        Rule 4 honored: the review_required folder is only created when a question
        actually lands in it. Returns the folder dict (or skipped_duplicate).
        """
        assert reason in self.UNC_SENTINELS, f"unknown review_required reason: {reason}"
        level, subject = config.level, config.subject
        variant, season, year, qnum = matched.variant, matched.season, matched.year, matched.question_number
        question_folder_name = f"{variant}_{season}_{year}_{qnum}"
        major_path = self.output_root / level / subject / self.UNC_FOLDER
        question_folder = major_path / question_folder_name

        # A REAL classified twin wins outright: never shadow it with an
        # review_required duplicate (inverse of the promotion rule in
        # save_question_pair, which deletes the review_required twin when a real
        # classification later arrives).
        dupes = [d for d in (self.output_root / level / subject).rglob(question_folder_name)
                 if d.is_dir() and d != question_folder
                 and self.UNC_FOLDER not in d.parts]
        if dupes:
            logger.error(
                "REVIEW_REQUIRED SKIP: %s already has a real classified folder at %s - not shadowing",
                question_folder_name, dupes[0],
            )
            return {"skipped_duplicate": True, "existing": dupes[0],
                    "question_folder": dupes[0]}

        question_folder.mkdir(parents=True, exist_ok=True)
        qp_path = question_folder / f"{question_folder_name}.webp"
        self._save_image(matched.qp.assembled_image, qp_path)
        ms_path = None
        if getattr(matched, "ms", None) is not None:
            ms_path = question_folder / f"{question_folder_name}_MS.webp"
            self._save_image(matched.ms.assembled_image, ms_path)

        import uuid as _uuid
        json_data = {
            "id": str(_uuid.uuid4()),
            "level": level,
            "subject": subject,
            "board": getattr(config, "board", "CIE"),
            "topic": [self.UNC_SENTINELS[reason]],
            "paper": matched.full_qp_code,
            "question_number": matched.question_number,
            "variant": variant,
            "season": season,
            "year": year,
        }
        # IGCSE paper-format round (mcq_ms=letters): if this question came
        # from an MCQ paper, its extracted grid letter IS the mark scheme.
        # User requirement (2026-08-14): metadata stays canonical — the
        # letter rides in the `*_MS.txt` sidecar written below.
        _mcq_answer_unc = getattr(matched, "ms_answer", None)
        from .mcq_registry import is_mcq as _reg_is_mcq_u
        _mcq_paper_unc = _reg_is_mcq_u(getattr(config, "syllabus_code", ""),
                                       getattr(matched, "variant", ""))
        json_path = question_folder / "metadata.json"
        # Only the canonical 11 fields persist (user requirement 2026-08-14).
        from .json_generator import canonical_metadata
        json_data = canonical_metadata(json_data)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(json_data, f, indent=4)
        if _mcq_paper_unc:
            # Unified-MCQ (Q3=literal): ALWAYS write _MS.txt (letter or
            # empty+loud); validated immediately (Rule 4).
            from .mcq_output import write_mcq_ms, validate_mcq_ms_file
            _ms_txt_unc = write_mcq_ms(question_folder, question_folder_name,
                                       _mcq_answer_unc)
            if not validate_mcq_ms_file(_ms_txt_unc):
                print(f"[OutputManager] ! MCQ UNC _MS.txt empty/invalid for "
                      f"{question_folder_name}")

        reason_text = self.UNC_REASON_MESSAGES[reason]
        (question_folder / "REASON.txt").write_text(
            f"REVIEW_REQUIRED QUESTION\n"
            f"{'='*40}\n"
            f"Question: {question_folder_name}\n"
            f"Paper:    {matched.full_qp_code}\n"
            f"Subject:  {subject}\n"
            f"Reason:   {reason}\n"
            f"{'='*40}\n\n"
            f"{reason_text}\n",
            encoding="utf-8",
        )

        assert qp_path.exists(), f"QP not saved: {qp_path}"
        assert json_path.exists(), f"JSON not saved: {json_path}"
        print(f"[OutputManager] REVIEW_REQUIRED ({reason}): {matched.full_qp_code} {matched.question_number} -> {question_folder.relative_to(self.output_root)}")
        return {
            "qp": qp_path, "ms": ms_path, "json": json_path,
            "major": major_path, "paper_type": self.UNC_FOLDER,
            "question_folder": question_folder,
            "question_folder_name": question_folder_name,
            "winning_major": self.UNC_FOLDER,
            "assigned_topic": self.UNC_SENTINELS[reason],
            "reason": reason, "level": level,
        }

    def save_missing_qp_question(self, ms_crop, variant, season, year,
                                 full_ms_code, config) -> Dict[str, Path]:
        """2026-08-15 (user requirement): a bundle whose QP is missing (after
        fetch attempts) still has its MS cropped and preserved in
        review_required/missing_qp so a human can locate the QP and reprocess.
        Folders contain `{QID}_MS.webp` + metadata.json (sentinel topic) +
        REASON.txt — no QP webp exists by definition."""
        reason = "missing_qp"
        level, subject = config.level, config.subject
        question_number = getattr(ms_crop, "question_number", "Q?")
        question_folder_name = f"{variant}_{season}_{year}_{question_number}"
        major_path = self.output_root / level / subject / self.UNC_FOLDER
        question_folder = major_path / question_folder_name

        # A real classified twin wins outright; never shadow it.
        dupes = [d for d in (self.output_root / level / subject).rglob(question_folder_name)
                 if d.is_dir() and d != question_folder
                 and self.UNC_FOLDER not in d.parts]
        if dupes:
            logger.error(
                "REVIEW_REQUIRED SKIP (missing_qp): %s already has a real "
                "classified folder at %s - not shadowing",
                question_folder_name, dupes[0],
            )
            return {"skipped_duplicate": True, "existing": dupes[0],
                    "question_folder": dupes[0]}

        question_folder.mkdir(parents=True, exist_ok=True)
        ms_path = question_folder / f"{question_folder_name}_MS.webp"
        img = getattr(ms_crop, "assembled_image", None)
        if img is not None:
            self._save_image(img, ms_path)

        import uuid as _uuid
        json_data = {
            "id": str(_uuid.uuid4()),
            "level": level,
            "subject": subject,
            "board": getattr(config, "board", "CIE"),
            "topic": [self.UNC_SENTINELS[reason]],
            "paper": full_ms_code,
            "question_number": question_number,
            "variant": variant,
            "season": season,
            "year": year,
        }
        from .json_generator import canonical_metadata
        json_path = question_folder / "metadata.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(canonical_metadata(json_data), f, indent=4)

        reason_text = self.UNC_REASON_MESSAGES[reason]
        (question_folder / "REASON.txt").write_text(
            f"REVIEW_REQUIRED QUESTION\n"
            f"{'='*40}\n"
            f"Question: {question_folder_name}\n"
            f"Paper:    {full_ms_code}\n"
            f"Subject:  {subject}\n"
            f"Reason:   {reason}\n"
            f"{'='*40}\n\n"
            f"{reason_text}\n",
            encoding="utf-8",
        )

        assert json_path.exists(), f"JSON not saved: {json_path}"
        print(f"[OutputManager] REVIEW_REQUIRED ({reason}): {full_ms_code} "
              f"{question_number} -> {question_folder.relative_to(self.output_root)}")
        return {
            "ms": ms_path, "json": json_path,
            "major": major_path, "paper_type": self.UNC_FOLDER,
            "question_folder": question_folder,
            "question_folder_name": question_folder_name,
            "winning_major": self.UNC_FOLDER,
            "assigned_topic": self.UNC_SENTINELS[reason],
            "reason": reason, "level": level,
        }

    # Compatibility alias for old callers/tests. The implementation writes to
    # review_required, never to an Uncategorized directory.
    save_uncategorized_question = save_review_required_question

    def _generate_json_data(self, matched: MatchedQuestion, classification: ClassificationResult, config: SubjectConfig) -> dict:
        # Keep this writer in lock-step with JSONGenerator; the folder is driven
        # by its topic[0], never by a separately generated identifier.
        from .json_generator import JSONGenerator
        return JSONGenerator().generate_json(matched, classification, config)

    def _save_image(self, image: Image.Image, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        if image.mode in ('RGBA', 'LA'):
            bg = Image.new('RGB', image.size, 'white')
            bg.paste(image, mask=image.split()[-1])
            image = bg
        elif image.mode != 'RGB':
            image = image.convert('RGB')

        # User requirement (2026-08-14): no barcodes in any crop. The
        # seam/edge scrubber cannot see mid-page barcode bands, so every
        # image that reaches the disk passes the full-canvas scrubber.
        from .webp_utils import scrub_barcode_bands
        image = scrub_barcode_bands(image)

        if image.size[0] != self.target_width:
            w, h = image.size
            new_h = int((self.target_width / w) * h)
            image = image.resize((self.target_width, new_h), Image.LANCZOS)

        image.save(str(path), 'WEBP', quality=self.quality, method=6)

    def ensure_no_duplicate_distribution(self):
        from collections import defaultdict
        question_to_majors = defaultdict(set)

        for qp_file in self.output_root.rglob("*.webp"):
            if "_MS" in qp_file.name:
                continue
            question_folder = qp_file.parent
            # For new structure with paper type: Level/Subject/PaperType/Major/Q
            # Major is parent of Q folder's parent? Actually Q folder parent is major, major parent is paper type, paper type parent is subject
            # For duplicate check, we need major folder
            major_folder = question_folder.parent
            # If major folder is actually paper type? Check
            # Our structure: Level/Subject/PaperType/Major/Q
            # So Q parent = Major, Major parent = PaperType, PaperType parent = Subject
            # For old structure without paper type: Level/Subject/Major/Q

            json_path = question_folder / "metadata.json"
            base = None
            if json_path.exists():
                try:
                    with open(json_path, 'r') as f:
                        data = json.load(f)
                        paper = data.get("paper", "unknown")
                        qnum = data.get("question_number", "")
                        base = f"{paper}_{qnum}"
                except Exception as e:
                    print(f"[OutputManager] Warning duplicate check JSON parse failed {question_folder}: {e}")
                    base = str(question_folder)
            else:
                base = str(question_folder)

            question_to_majors[base].add(str(major_folder))

        errors = []
        fixed = []
        for base_q, majors in question_to_majors.items():
            if len(majors) > 1:
                errors.append(f"Duplicate placement for {base_q} in {len(majors)} majors: {majors} - must be exactly ONE per R5,R6")

        return errors, fixed

    def cleanup_empty_and_invalid_folders(self):
        removed = []
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.'):
                continue

            subject_dirs = []
            if level_dir.name in ["IGCSE", "A-Level"]:
                subject_dirs = [d for d in level_dir.iterdir() if d.is_dir()]
            else:
                subject_dirs = [level_dir]

            for subject_dir in subject_dirs:
                if not subject_dir.is_dir():
                    continue
                if subject_dir.name in {"Mathematics_9709", "Further_Mathematics_9231"}:
                    # Reference folders are intentionally empty until manual categorization.
                    continue
                # Subject may contain paper type folders or major folders directly
                # Check for paper type folders first
                for item in subject_dir.iterdir():
                    if not item.is_dir():
                        continue

                    # Item could be paper type folder (P2_AS_Structured) or major folder (if old structure without paper type)
                    # Determine if it's paper type folder by name pattern P?_
                    is_paper_type = _is_paper_type_dir_name(item.name)
                    
                    if is_paper_type:
                        # This is paper type folder, contains major folders
                        paper_type_dir = item
                        for major_dir in paper_type_dir.iterdir():
                            if not major_dir.is_dir():
                                continue
                            if major_dir.name == "_insert":
                                continue  # insert booklet crops (2026-08-15)
                            if major_dir.name == "json":
                                import shutil
                                shutil.rmtree(major_dir)
                                removed.append(str(major_dir))
                                continue

                            question_folders = [d for d in major_dir.iterdir() if d.is_dir()]
                            if not question_folders:
                                import shutil
                                shutil.rmtree(major_dir)
                                removed.append(str(major_dir))
                                continue

                            valid_q = 0
                            for q_folder in question_folders:
                                qp_exists = len(list(q_folder.glob("*.webp"))) > 0 and len([f for f in q_folder.glob("*.webp") if "_MS" not in f.name and "_INSERT" not in f.name and "_IN" not in f.name]) > 0
                                ms_exists = len(list(q_folder.glob("*_MS.webp"))) > 0 or len(list(q_folder.glob("*_MS.txt"))) > 0
                                json_exists = (q_folder / "metadata.json").exists()
                                reason_exists = (q_folder / "REASON.txt").exists()
                                # User requirement (2026-08-14): review-marked
                                # questions must NEVER disappear — a folder
                                # carrying REASON.txt is preserved even if a
                                # later cleanup pass disagrees about its files.
                                if (qp_exists and json_exists) or reason_exists:
                                    valid_q += 1
                                else:
                                    import shutil
                                    shutil.rmtree(q_folder)
                                    removed.append(str(q_folder))

                            if valid_q == 0:
                                import shutil
                                shutil.rmtree(major_dir)
                                removed.append(str(major_dir))

                        # After cleaning majors inside paper type, check if paper type folder is empty
                        if not any(d.is_dir() for d in paper_type_dir.iterdir()):
                            import shutil
                            shutil.rmtree(paper_type_dir)
                            removed.append(str(paper_type_dir))

                    else:
                        # Item is major folder directly under subject (old structure without paper type) or new structure if paper type omitted
                        major_dir = item
                        if major_dir.name == "grade_thresholds":
                            # Grade-threshold sidecars (grade_threshold.py,
                            # 2026-08-15) are leaf data folders (json/txt only,
                            # no question subfolders) — never pruned as an
                            # "empty major folder".
                            continue
                        if major_dir.name == "json":
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))
                            continue

                        # Check for direct webp in major (old invalid)
                        direct_webp = list(major_dir.glob("*.webp"))
                        if direct_webp:
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))
                            continue

                        question_folders = [d for d in major_dir.iterdir() if d.is_dir()]
                        if not question_folders:
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))
                            continue

                        valid_q = 0
                        for q_folder in question_folders:
                            all_webp = list(q_folder.glob("*.webp"))
                            qp_exists = len([f for f in all_webp if "_MS" not in f.name and "_INSERT" not in f.name and "_IN" not in f.name]) > 0
                            json_exists = (q_folder / "metadata.json").exists()
                            reason_exists = (q_folder / "REASON.txt").exists()
                            # User requirement (2026-08-14): review-marked
                            # questions must NEVER disappear (see above).
                            if (qp_exists and json_exists) or reason_exists:
                                valid_q += 1
                            else:
                                import shutil
                                shutil.rmtree(q_folder)
                                removed.append(str(q_folder))

                        if valid_q == 0:
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))

        return removed

    def validate_qp_ms_pairs(self, auto_heal: bool = True) -> List[str]:
        """Validate output tree. Returns a list of error strings.

        Audit fix-group 7 (maintainer-approved adaptations applied):
          C1  Folder name == metadata topic[0] — AUTO-HEALED by moving the
              question folder under the correct topic folder (was error-only).
          C4  Forbidden-field rescan: strip + rewrite any metadata.json found
              containing forbidden fields (belt-and-suspenders; the writer
              already strips them).
          C2  File presence per question folder: QP webp + MS webp +
              metadata.json are errors when missing. examiner_report.txt is
              only checked when an ER was supplied for the paper, and then
              only as a WARNING (legit statuses like `no_verified_er` produce
              no per-question txt by design — maintainer decision: no
              placeholder ER files).
              ADAPTATION: `*_ER.webp` renders are full-page report images, not
              2280px question crops — they are EXCLUDED from "QP present" and
              width checks (the old code let an ER webp masquerade as a QP
              file and would false-flag or false-pass).
          C3  Width invariant 2280 re-checked for QP and MS crops (not _ER).
          C5  Empty-folder pruning — EXCLUDING Math/Further-Math reference
              staging trees (`paper-N` folders), whose empty topic folders are
              intentional staging structure.
        """
        errors: List[str] = []

        # ---------- Phase 0a: forbidden-field rescan + folder/topic auto-heal ----------
        for json_file in list(self.output_root.rglob("metadata.json")):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
            except Exception as e:
                errors.append(f"Invalid JSON {json_file}: {e}")
                continue

            found = [f for f in FORBIDDEN_METADATA_FIELDS if f in data]
            if found:
                for f in found:
                    data.pop(f, None)
                json_file.write_text(json.dumps(data, indent=4), encoding="utf-8")
                logger.info("Stripped forbidden fields %s from %s", found, json_file)

            q_folder = json_file.parent
            major_folder = q_folder.parent
            topics = data.get("topic", [])
            assigned_topic = topics[0] if isinstance(topics, list) and topics else None
            if not assigned_topic:
                continue  # manual/reference staging (topic=[]) — nothing to heal
            if assigned_topic in ("review_required", "review_required_no_ms",
                                  "review_required_no_qp"):
                # RS-5: review_required routing is deliberate; the sentinel must
                # never be auto-healed into a physical topic folder name.
                continue
            if assigned_topic != major_folder.name:
                if auto_heal:
                    correct_dir = major_folder.parent / assigned_topic
                    dest = correct_dir / q_folder.name
                    if dest.exists():
                        errors.append(f"Cannot auto-heal {q_folder}: destination exists {dest}")
                    else:
                        correct_dir.mkdir(parents=True, exist_ok=True)
                        shutil.move(str(q_folder), str(dest))
                        logger.info("Auto-healed routing: %s -> %s", q_folder, dest)
                else:
                    errors.append(
                        f"Topic folder {major_folder.name!r} != JSON topic[0] {assigned_topic!r} for {json_file}"
                    )

        # Phase 0b: legacy .jsonc cleanup (pairs with json_generator C3).
        for stale in list(self.output_root.rglob("*.jsonc")):
            stale.unlink()
            logger.info("Removed legacy %s", stale)

        # ---------- Phase 1: per-question folder checks (healed tree) ----------
        for json_file in self.output_root.rglob("metadata.json"):
            question_folder = json_file.parent
            major_folder = question_folder.parent

            all_webp = list(question_folder.glob("*.webp"))
            # ADAPTATION: exclude examiner-report page renders from QP/MS logic.
            qp_files = [f for f in all_webp if "_MS" not in f.name and "_ER" not in f.name and "_INSERT" not in f.name and "_IN" not in f.name]
            ms_files = list(question_folder.glob("*_MS.webp"))

            if len(qp_files) == 0 and not _is_review_required_no_qp(question_folder):
                errors.append(f"Question folder {question_folder} missing QP webp - invalid per R9")
            if len(ms_files) == 0 and not _is_review_required_no_ms(question_folder):
                # IGCSE paper-format round (mcq_ms=letters): MCQ folders carry
                # the extracted grid letter in the `*_MS.txt` sidecar, never an
                # MS webp. User requirement (2026-08-14): metadata.json is
                # canonical 11 fields only — the sidecar is the single source
                # of the letter.
                from .mcq_output import valid_ms_sidecar as _valid_sidecar
                _txt_files = list(question_folder.glob("*_MS.txt"))
                if _txt_files:
                    _tl = _txt_files[0].read_text(encoding="utf-8").strip()
                    if not _valid_sidecar(_tl):
                        errors.append(f"Question folder {question_folder}: _MS.txt invalid content ({_tl!r}) - expected A-D letter or MS_UNAVAILABLE placeholder")
                else:
                    errors.append(f"Question folder {question_folder} missing MS webp - invalid per R9")

            # C3 width invariant. QP crops MUST be 2280 (locked QP pipeline
            # guarantee). MS crops come from the LOCKED gold MS path, which by
            # design does not normalise width (observed: 751px at main.py's
            # dpi=75 construction) — MS width is reported as a warning, never
            # an error, since the MS path must not be "fixed". _ER renders
            # are excluded entirely (full-page report images).
            for wf in qp_files:
                try:
                    with Image.open(wf) as im:
                        im.verify()
                    with Image.open(wf) as im:
                        if im.size[0] != self.target_width:
                            errors.append(f"Width not 2280 for {wf}: {im.size[0]}")
                except Exception as e:
                    errors.append(f"Invalid webp {wf}: {e}")
            for wf in ms_files:
                try:
                    with Image.open(wf) as im:
                        im.verify()
                    with Image.open(wf) as im:
                        if im.size[0] != self.target_width:
                            logger.warning(
                                "MS crop width %d != %d for %s (locked gold MS path — expected, not an error)",
                                im.size[0], self.target_width, wf,
                            )
                except Exception as e:
                    errors.append(f"Invalid webp {wf}: {e}")

            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                qnum = data.get("question_number", "")
                if qnum and qnum not in question_folder.name:
                    errors.append(f"JSON question_number {qnum} not in folder name {question_folder.name} in {json_file}")

                # C2 (adapted): ER presence only when an ER was supplied for
                # this paper's subtree, and only as a warning.
                paper_tree = major_folder.parent
                er_supplied = any(
                    p.name.endswith("_ER.webp") or p.name == "examiner_report_full.txt"
                    for p in paper_tree.rglob("*") if p.is_file()
                ) if paper_tree.exists() else False
                if er_supplied and not (question_folder / "examiner_report.txt").exists():
                    logger.warning(
                        "ER supplied for this paper but no examiner_report.txt in %s "
                        "(status no_verified_er/continue-process is legitimate)",
                        question_folder,
                    )
            except Exception as e:
                errors.append(f"Invalid JSON {json_file}: {e}")

        for json_file in self.output_root.rglob("*.json"):
            # 2026-08-10 (approved amendment RS-2, guarded-runner finding V2b):
            # dotfiles are state/tooling, not question artifacts — most
            # importantly .pipeline_state.json (RS-1 crash-resume). Same
            # protection as validation.py V2; loud, never silent.
            if json_file.name.startswith("."):
                print(f"[OutputManager] kept dotfile state JSON (not an orphan): {json_file.name}")
                continue
            if "_insert" in json_file.parts:
                # insert booklet manifest (2026-08-15): kept, never orphan-flagged
                print(f"[OutputManager] kept insert manifest JSON (not an orphan): {json_file.name}")
                continue
            if json_file.name != "metadata.json":
                errors.append(f"Orphan JSON not named metadata.json: {json_file}")

        # ---------- Phase 2: structural checks (paper-type + legacy layouts) ----------
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.'):
                continue
            subject_dirs = []
            if level_dir.name in ["IGCSE", "A-Level"]:
                subject_dirs = [d for d in level_dir.iterdir() if d.is_dir()]
            else:
                subject_dirs = [level_dir]

            for subject_dir in subject_dirs:
                for item in subject_dir.iterdir():
                    if not item.is_dir():
                        continue
                    is_paper_type = _is_paper_type_dir_name(item.name)
                    if is_paper_type:
                        paper_type_dir = item
                        for major_dir in paper_type_dir.iterdir():
                            if not major_dir.is_dir():
                                continue
                            if major_dir.name == "_insert":
                                continue  # insert booklet crops (2026-08-15)
                            direct_webp = [w for w in major_dir.glob("*.webp") if "_ER" not in w.name]
                            if direct_webp:
                                errors.append(f"Found webp directly in major folder {major_dir} - must be inside question subfolders")
                    else:
                        major_dir = item
                        if major_dir.name == "json":
                            continue
                        direct_webp = [w for w in major_dir.glob("*.webp") if "_ER" not in w.name]
                        if direct_webp:
                            errors.append(f"Found webp directly in major folder {major_dir} - must be inside question subfolders (new structure requires PaperType/Major/Q)")

        # ---------- Phase 3: empty-folder prune (math staging protected) ----------
        def _in_math_staging(p: Path) -> bool:
            return any(
                re.fullmatch(r"paper-\d+", a.name)
                for a in p.parents
                if a.is_relative_to(self.output_root)
            )

        dirs = [d for d in self.output_root.rglob("*") if d.is_dir()]
        dirs.sort(key=lambda d: len(d.parts), reverse=True)  # deepest first
        for folder in dirs:
            if folder == self.output_root:
                continue
            if _in_math_staging(folder):
                continue  # intentional empty reference-topic folders (9709/9231)
            if not any(folder.iterdir()):
                folder.rmdir()
                logger.debug("Pruned empty folder: %s", folder)

        return errors

