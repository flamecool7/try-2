"""core/grade_threshold.py — Grade Threshold (grade boundary) extraction.

NEW MODULE (2026-08-15, maintainer-directed).

Cambridge publishes a Grade Threshold (``gt``) document for every syllabus
and examination series, mapping raw marks to grades per component and per
option.  Historically the pipeline recognised ``gt`` files only as "ignore,
not a question paper".  This module extracts the threshold tables into
structured JSON plus a human-readable sidecar, so grade boundaries are
available alongside the topical question bank.

Handles the three Cambridge grade scales:
  * A-Level      — component grades A..E,   option grades A*..E
  * IGCSE        — component grades A..G,   option grades A*..G
  * IGCSE (9-1)  — component & option grades 9..1

Parsing strategy:
  * Grade scale + document metadata are read from the page text / word
    coordinates (robust against header-cell scattering).
  * The numeric tables are read with PyMuPDF ``find_tables()`` (official gt
    PDFs are vector, so ruling lines exist); a word-line fallback covers
    scanned PDFs with no ruling lines.
  * Phantom empty cells (``find_tables`` over-splitting a column) are
    skipped; en-dash "no grade" cells (``\\u2013``) map to ``null``.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import List, Optional, Tuple

try:
    import fitz  # PyMuPDF
except ImportError:
    import pymupdf as fitz

SCHEMA_VERSION = "examvoid.grade_threshold.v1"

_GRADE_LETTERS = set("ABCDEFG")
_GRADE_DIGITS = set("987654321")


# ---------------------------------------------------------------------------
# Grade-scale detection from word coordinates
# ---------------------------------------------------------------------------

def _words(pages) -> List[List[tuple]]:
    """Collect (x0, y0, x1, y1, text) word tuples per page."""
    out = []
    for page in pages:
        try:
            out.append(page.get_text("words"))
        except Exception:
            out.append([])
    return out


def _grade_scales(pages_words: List[List[tuple]]) -> Tuple[Optional[List[str]], Optional[List[str]]]:
    """Detect (component_grades, option_grades) from header lines.

    Grade tokens (``A*``, single letters A-G, single digits 9-1) are read in
    x-order off the header lines; a line carrying >= 3 such tokens is a
    grade header.  The line WITHOUT ``A*`` is the component scale, the line
    WITH ``A*`` is the option scale.  9-1 documents carry only digit tokens.
    Returns (None, None) when no scale can be determined.
    """
    letter_headers = []   # (line_y, [(x, token), ...])
    digit_headers = []    # (line_y, [(x, token), ...])

    def _tok(w: str):
        t = w.strip()
        if t in ("A*", "a*"):
            return "A*"
        if len(t) == 1:
            u = t.upper()
            if u in _GRADE_LETTERS:
                return u
            if t in _GRADE_DIGITS:
                return t
        return None

    for page_words in pages_words:
        lines: dict = {}
        for w in page_words:
            y = round(w[1] / 5) * 5
            lines.setdefault(y, []).append(w)
        for y, ws in lines.items():
            letters, digits = [], []
            for w in sorted(ws, key=lambda w: w[0]):
                tk = _tok(w[4])
                if tk is None:
                    continue
                if tk == "A*" or tk in _GRADE_LETTERS:
                    letters.append((w[0], tk))
                else:
                    digits.append((w[0], tk))
            if len(letters) >= 3:
                letter_headers.append((y, letters))
            if len(digits) >= 5:
                digit_headers.append((y, digits))

    # 9-1 scale: pick the digit header with the most tokens.
    if digit_headers:
        best = max(digit_headers, key=lambda lh: len(lh[1]))
        seq = [t for _, t in sorted(best[1], key=lambda p: p[0])]
        if seq == ["9", "8", "7", "6", "5", "4", "3", "2", "1"]:
            return seq, seq

    if not letter_headers:
        return None, None

    comp = opt = None
    for _y, toks in letter_headers:
        seq = [t for _, t in sorted(toks, key=lambda p: p[0])]
        if seq[0] == "A*":
            if opt is None or len(seq) > len(opt):
                opt = seq
        else:
            if comp is None or len(seq) > len(comp):
                comp = seq
    if comp is None and opt is not None:
        comp = [g for g in opt if g != "A*"]
    if opt is None and comp is not None:
        opt = ["A*"] + comp
    return comp, opt


# ---------------------------------------------------------------------------
# Document metadata from page text
# ---------------------------------------------------------------------------

def _document_meta(full_text: str) -> dict:
    meta = {"title": "", "qualification": "", "note": "",
            "syllabus_code": "", "subject": "", "session_label": ""}
    lines = [ln.strip() for ln in full_text.splitlines() if ln.strip()]
    for i, ln in enumerate(lines):
        if ln.lower().startswith("grade threshold") and meta["title"] == "":
            meta["title"] = ln
        elif ln.lower().startswith("cambridge") and meta["qualification"] == "":
            # join with the next line if it holds the "(code)" suffix
            nxt = lines[i + 1] if i + 1 < len(lines) else ""
            meta["qualification"] = (ln + (" " + nxt if re.match(r"^\(\d{4}\)", nxt) else "")).strip()
    m = re.search(r"Grade thresholds taken for Syllabus (\d{4}) \(([^)]+)\)", full_text, re.I)
    if m:
        meta["syllabus_code"] = m.group(1)
        meta["subject"] = m.group(2).strip()
    else:
        m = re.search(r"Syllabus (\d{4}) \(([^)]+)\)", full_text, re.I)
        if m:
            meta["syllabus_code"] = m.group(1)
            meta["subject"] = m.group(2).strip()
    m = re.search(r"in the (\w+ \d{4}) examination", full_text, re.I)
    if m:
        meta["session_label"] = m.group(1)
    return meta


# ---------------------------------------------------------------------------
# Table row extraction
# ---------------------------------------------------------------------------

def _clean_cell(cell) -> Optional[str]:
    """Normalise a table cell.  Returns None for phantom empty cells."""
    if cell is None:
        return None
    s = str(cell).replace("\n", " ").strip()
    if s == "":
        return None
    return s


def _is_int(s: str) -> bool:
    return s.isdigit()


def _parse_number(s: str):
    """'40' -> 40 ; en-dash '\\u2013' / '-' -> None ; else raise."""
    if s in ("–", "-", "—", ""):
        return None
    return int(s)


def _extract_rows(pages) -> List[dict]:
    """Yield normalised data rows across all tables/pages.

    Each row is a dict:
        {"label": str, "cells": [str, ...]}   (post-label cells, phantom-free)
    """
    rows: List[dict] = []
    for page in pages:
        try:
            tabs = page.find_tables()
        except Exception:
            tabs = None
        if tabs is not None and len(tabs.tables) > 0:
            for t in tabs.tables:
                try:
                    extracted = t.extract()
                except Exception:
                    continue
                prev_option = None  # last appended option row (for wrap merge)
                for r in extracted:
                    cells = [_clean_cell(c) for c in r]
                    cells = [c for c in cells if c is not None]
                    if not cells:
                        continue
                    label = cells[0]
                    if _is_data_label(label):
                        row = {"label": label, "cells": cells[1:]}
                        rows.append(row)
                        prev_option = row if not label.startswith("Component") else None
                    elif prev_option is not None and len(cells) == 1 and (
                            cells[0].isdigit() or cells[0].endswith(",")):
                        # Wrapped continuation of the combination-of-components
                        # (find_tables splits it onto its own row on later
                        # pages).  Merge it back into the combination cell.
                        comb = prev_option["cells"][1] if len(prev_option["cells"]) >= 2 else None
                        if comb is not None:
                            prev_option["cells"][1] = (comb.rstrip() + " " + cells[0]).strip()
            continue
        # fallback: word-line reconstruction (scanned PDFs)
        for wrow in _wordline_rows(page):
            rows.append(wrow)
    return rows


def _is_data_label(label: str) -> bool:
    """True for 'Component 11' and option codes like 'AX', 'BX1', 'S1'.

    Rejects the scattered header rows: single grade letters (A..G / A*),
    'Option'/'Maximum'/'Combination...' header words, etc.
    """
    if label.startswith("Component"):
        return True
    if label == "A*" or (len(label) == 1 and label.upper() in "ABCDEFG"):
        return False
    return bool(re.fullmatch(r"[A-Z]{1,4}\d{0,2}", label))


def _wordline_rows(page) -> List[dict]:
    """Scanned-PDF fallback: reconstruct rows from word lines."""
    lines: dict = {}
    try:
        words = page.get_text("words")
    except Exception:
        return []
    for w in words:
        y = round(w[1] / 5) * 5
        lines.setdefault(y, []).append(w)
    rows = []
    for _y, ws in sorted(lines.items()):
        toks = [w[4].strip() for w in sorted(ws, key=lambda w: w[0])]
        if not toks:
            continue
        label = toks[0]
        if label == "Component" and len(toks) >= 3 and _is_int(toks[1]):
            label = f"Component {toks[1]}"
            rows.append({"label": label, "cells": toks[2:]})
        elif _is_data_label(label) and not label.startswith("Component"):
            rows.append({"label": label, "cells": toks[1:]})
    return rows


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_grade_thresholds(pdf_path) -> Optional[dict]:
    """Parse a gt PDF into structured threshold data, or None if not a gt doc."""
    pdf_path = Path(pdf_path)
    try:
        doc = fitz.open(str(pdf_path))
    except Exception:
        return None
    try:
        pages = [doc[i] for i in range(len(doc))]
        words = _words(pages)
        full_text = "\n".join((p.get_text("text") or "") for p in pages)

        meta = _document_meta(full_text)
        comp_scale, opt_scale = _grade_scales(words)
        if comp_scale is None and opt_scale is None:
            # Not recognisable as a grade-threshold document.
            return None

        rows = _extract_rows(pages)
    finally:
        doc.close()
    components: List[dict] = []
    options: List[dict] = []

    for row in rows:
        label = row["label"]
        cells = row["cells"]
        if label.startswith("Component"):
            comp_id = label[len("Component"):].strip()
            scale = comp_scale
            # cells = [max] + grades (skip phantom empties upstream)
            try:
                maximum = _parse_number(cells[0]) if cells else None
            except ValueError:
                continue
            grades = {}
            grade_cells = cells[1:1 + len(scale)] if scale else cells[1:]
            for g, c in zip(scale or [], grade_cells):
                try:
                    grades[g] = _parse_number(c)
                except ValueError:
                    grades[g] = None
            components.append({
                "component": comp_id,
                "maximum_raw_mark": maximum,
                "grades": grades,
            })
        else:
            scale = opt_scale
            # cells = [max, combination, grade...]
            if not cells:
                continue
            try:
                maximum = _parse_number(cells[0])
            except ValueError:
                maximum = None
            # find the combination cell: the first cell that is not a plain
            # number and is not an en-dash (contains commas / spaces).
            comb_idx = None
            for i, c in enumerate(cells[1:], start=1):
                if c is not None and not _is_int(c) and c not in ("–", "-", "—"):
                    comb_idx = i
                    break
            combination = cells[comb_idx] if comb_idx is not None else None
            grade_cells = cells[comb_idx + 1:] if comb_idx is not None else cells[1:]
            grades = {}
            for g, c in zip(scale or [], grade_cells):
                try:
                    grades[g] = _parse_number(c)
                except ValueError:
                    grades[g] = None
            options.append({
                "option": label,
                "maximum_mark_after_weighting": maximum,
                "combination_of_components": combination,
                "grades": grades,
            })

    if not components and not options:
        return None

    return {
        "schema": SCHEMA_VERSION,
        "syllabus_code": meta["syllabus_code"],
        "subject": meta["subject"],
        "title": meta["title"],
        "qualification": meta["qualification"],
        "examination_note": meta["note"],
        "session_label": meta["session_label"],
        "component_grade_scale": comp_scale,
        "option_grade_scale": opt_scale,
        "component_thresholds": components,
        "option_thresholds": options,
        "source_file": Path(pdf_path).name,
    }


def render_text(data: dict) -> str:
    """Human-readable rendering of extracted threshold data."""
    lines = []
    lines.append(data.get("title") or "Grade thresholds")
    if data.get("qualification"):
        lines.append(data["qualification"])
    if data.get("session_label"):
        lines.append(f"Session: {data['session_label']}")
    if data.get("syllabus_code"):
        subj = f" ({data['subject']})" if data.get("subject") else ""
        lines.append(f"Syllabus: {data['syllabus_code']}{subj}")
    lines.append("")

    if data.get("component_thresholds"):
        comp_scale = data.get("component_grade_scale") or []
        header = ["Component", "Max"] + comp_scale
        lines.append("COMPONENT THRESHOLDS (minimum raw mark)")
        lines.append("  " + "  ".join(f"{h:>5}" for h in header))
        for c in data["component_thresholds"]:
            g = c["grades"]
            vals = [c["component"], str(c["maximum_raw_mark"] if c["maximum_raw_mark"] is not None else "-")]
            vals += [("-" if g.get(grade) is None else str(g.get(grade))) for grade in comp_scale]
            lines.append("  " + "  ".join(f"{v:>5}" for v in vals))
        lines.append("")

    if data.get("option_thresholds"):
        opt_scale = data.get("option_grade_scale") or []
        header = ["Option", "Max"] + opt_scale + ["Components"]
        lines.append("OVERALL (OPTION) THRESHOLDS")
        lines.append("  " + "  ".join(f"{h:>5}" for h in header))
        for o in data["option_thresholds"]:
            g = o["grades"]
            vals = [o["option"], str(o["maximum_mark_after_weighting"] if o["maximum_mark_after_weighting"] is not None else "-")]
            vals += [("-" if g.get(grade) is None else str(g.get(grade))) for grade in opt_scale]
            vals.append(o.get("combination_of_components") or "")
            lines.append("  " + "  ".join(f"{v:>5}" for v in vals))
        lines.append("")

    lines.append("Note: '-' / null = no threshold awarded at that grade.")
    return "\n".join(lines)


def write_grade_thresholds(
    pdf_path,
    output_root,
    level: Optional[str] = None,
    subject: Optional[str] = None,
    season_letter: Optional[str] = None,
    year_short: Optional[str] = None,
) -> Optional[Tuple[Path, Path]]:
    """Extract and write gt JSON + txt into
    ``{output_root}/{Level}/{Subject}/grade_thresholds/``.

    Returns (json_path, txt_path) or None when the PDF holds no thresholds.
    """
    data = extract_grade_thresholds(pdf_path)
    if data is None:
        return None

    from .paper_identifier import infer_level_from_code
    from .config_loader import KNOWN_CODE_MAP

    code = data.get("syllabus_code") or ""
    level = level or infer_level_from_code(code)
    subject_code = KNOWN_CODE_MAP.get(code) or subject or data.get("subject") or "Unknown"
    season_letter = season_letter or ""
    year_short = year_short or ""
    base = f"{code}_{season_letter}{year_short}_gt" if (season_letter or year_short) else f"{code}_gt"

    # Enrich the JSON with resolved routing fields so the file is
    # self-describing alongside the topical question bank.
    data = dict(data)
    data["level"] = level
    data["subject_code"] = subject_code
    data["season_letter"] = season_letter or None
    data["year"] = ("20" + year_short) if (year_short and year_short.isdigit() and len(year_short) == 2) else None

    out_dir = Path(output_root) / level / subject_code / "grade_thresholds"
    out_dir.mkdir(parents=True, exist_ok=True)

    json_path = out_dir / f"{base}.json"
    txt_path = out_dir / f"{base}.txt"

    json_path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    txt_path.write_text(render_text(data), encoding="utf-8")
    return json_path, txt_path
