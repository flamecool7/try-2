"""qp_fetcher.py — online missing question-paper resolver.

Mirror of core/ms_fetcher.py for the QP side of the bundle: when a mark
scheme (or examiner report) is present but the matching question paper is
missing, this module downloads, VERIFIES and registers the QP so the
pipeline can process the bundle instead of failing it.

Opt-in only via --fetch-missing-qp (same policy as --fetch-missing-ms:
never automatic, never guessed). All downloads are verified BEFORE use;
any verification failure -> REVIEW_REQUIRED, never into the pipeline.
Every attempt is logged to qp_fetch_log (url, source, sha256, timestamp).
Rate limiting of 2s between requests is mandatory (RULE 5).

DESIGN NOTES (mirroring ms_fetcher.py, receipted against the real code):
  * Source order is contractual: 1) Cambridge International official past-
    papers page (parsed for an exact year/season/component question-paper
    link — verified working, the page exposes /Images/<id>-june-2024-
    question-paper-<comp>.pdf anchors), 2) pastpapers.co approved mirror
    patterns. Any candidate that does not verify is skipped; the official
    page only hosts the current public window, so older sessions honestly
    fall through to the mirror candidates and fail loudly if absent.
  * Downloader / throttling / _OfficialLinkParser / SEASON_TO_CODE and the
    fetch-log SQL shape are REUSED from ms_fetcher.py (single source of
    truth; this module never forks that behaviour).
  * DB contract (RS-8): bundles.qp_file_id is NULL for QP-less bundles;
    Database.register_file is the id-preserving UPSERT (F2 fix) and
    updating bundles.qp_file_id is SUFFICIENT for the next run to consume
    a fetched QP via get_pending_bundles()'s files JOIN.
  * Directory mode (fetch_missing_qps_in_dir) is used by run_guarded/main
    pre-flight: the QP lands in the input folder next to its MS with the
    canonical filename, so the existing identification pass picks it up on
    the same run. Existing files are NEVER overwritten (RULE 4).
"""

from __future__ import annotations

import logging
import re
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.parse import urljoin

from .database import Database, sha256 as _file_sha256  # RS-8 single-source
from .ms_fetcher import (
    SEASON_TO_CODE,
    MIN_PDF_SIZE,
    OFFICIAL_PAGE_SLUGS,
    PDF_MAGIC_BYTES,
    REQUEST_DELAY,
    MAX_FILE_SIZE,
    MAX_RETRIES,
    REQUEST_TIMEOUT,
    Downloader,
    PDFVerifier,
    _OfficialLinkParser,
)

logger = logging.getLogger(__name__)

# ── CONSTANTS ──────────────────────────────────────────

# Same contractual order as ms_fetcher (official -> pastpapers.co ->
# approved). 'papers.co' is never a source (spec, verbatim).
SOURCES = [
    {
        "name":     "cambridge_international_official",
        "base_url": "https://www.cambridgeinternational.org/",
        "priority": 1,
    },
    {
        "name":     "pastpapers.co",
        "base_url": "https://pastpapers.co/",
        "priority": 2,
    },
]

REQUESTS_MISSING_MSG = "Install requests: pip install requests>=2.31.0"


@dataclass
class QPFetchResult:
    """Result of one QP fetch attempt."""
    success:      bool
    bundle_key:   str
    source:       str
    url:          str
    local_path:   Optional[Path]
    sha256:       Optional[str]
    error:        Optional[str]
    verified:     bool
    retrieved_at: float


@dataclass
class QPVerificationResult:
    """Result of QP identity verification."""
    passed:             bool
    is_pdf:             bool
    syllabus_matches:   bool
    component_matches:  bool
    session_matches:    bool
    is_question_paper:  bool
    opens_cleanly:      bool
    failure_reasons:    List[str]


# ══════════════════════════════════════════════════════
# LAYER 1: URL BUILDER (QP flavour of ms_fetcher.URLBuilder)
# ══════════════════════════════════════════════════════

class QPURLBuilder:
    """Builds candidate URLs for question paper PDFs (multiple patterns per
    source because hosting sites use inconsistent formats)."""

    def build_official_index_url(self, syllabus_code: str) -> Optional[str]:
        slug = OFFICIAL_PAGE_SLUGS.get(str(syllabus_code))
        if not slug:
            return None
        return f"https://www.cambridgeinternational.org/programmes-and-qualifications/{slug}/past-papers/"

    def build_pastpapers_co(
        self,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
    ) -> List[str]:
        """Candidate pastpapers.co URLs (directory structure varies)."""
        base = "https://pastpapers.co"
        season_n = SEASON_TO_CODE.get(season.lower(), season)
        year_4 = "20" + year_short            # pre-2000 out of scope
        filename = f"{syllabus_code}_{season_n}{year_short}_qp_{component}.pdf"

        level_paths = {
            "9": "a-level",
            "0": "igcse",
            "2": "o-level", "4": "o-level", "5": "o-level", "7": "o-level",
        }
        level_path = level_paths.get(syllabus_code[0], "a-level")
        page_level = "A-Level" if level_path == "a-level" else "IGCSE"
        subject_slug = {
            "0610": "Biology", "0620": "Chemistry", "0625": "Physics",
            "0580": "Mathematics", "0606": "Additional-Mathematics",
            "0478": "Computer-Science", "0455": "Economics",
            "0450": "Business-Studies", "0475": "Literature-in-English",
            "0470": "History", "0417": "ICT", "0460": "Geography",
            "9700": "Biology", "9701": "Chemistry", "9702": "Physics",
            "9709": "Mathematics", "9231": "Further-Mathematics",
            "9618": "Computer-Science", "9708": "Economics",
            "9609": "Business", "9695": "English-Literature",
            "9489": "History", "9626": "Information-Technology",
            "9696": "Geography",
        }.get(str(syllabus_code), "")
        season_folder = {
            "s": "May-June", "w": "October-November",
            "m": "February-March", "sp": "Specimen",
        }.get(season_n, season_n)
        canonical = (
            f"{base}/caie/{page_level}/{subject_slug}-{syllabus_code}/"
            f"{year_4}-{season_folder}/{filename}"
            if subject_slug else ""
        )

        urls = [
            f"{base}/cie/{level_path}/{syllabus_code}/{year_4}/{filename}",
            f"{base}/cie/{level_path}/{syllabus_code}/{filename}",
        ]
        if canonical:
            urls.append(canonical)
        urls.append(f"{base}/download/{syllabus_code}/{filename}")
        return urls

    @staticmethod
    def extract_official_qp_urls(
        html: str,
        page_url: str,
        syllabus_code: str,
        season: str,
        year_short: str,
        component: str,
    ) -> List[str]:
        """Extract exact QP PDF links from a Cambridge past-papers page.

        The page is only an index; the returned href must be a PDF and its
        anchor must independently identify the year, session, component, and
        question-paper artifact. Ambiguous links are ignored rather than
        guessed. (QP twin of ms_fetcher.extract_official_ms_urls.)
        """
        parser = _OfficialLinkParser()
        try:
            parser.feed(html)
        except Exception:
            return []
        year_4 = "20" + str(year_short)
        season_n = SEASON_TO_CODE.get(str(season).lower(), str(season).lower())
        season_words = {
            "s": ("may", "june", "summer"),
            "w": ("october", "november", "winter"),
            "m": ("february", "march", "spring"),
            "sp": ("specimen", "sample"),
        }.get(season_n, ())
        component_re = re.compile(
            rf"(?:\bpaper|\bcomponent)[ _-]*0?{re.escape(str(component))}\b|"
            rf"[_-]qp[_-]?0?{re.escape(str(component))}(?:[_-]|\.)|"
            rf"question[ _-]?paper[ _-]*0?{re.escape(str(component))}\b",
            re.IGNORECASE,
        )
        found = []
        for raw_href, raw_text in parser.links:
            if not raw_href:
                continue
            href = str(raw_href)
            if href.startswith("/"):
                href = urljoin(page_url, href)
            haystack = f"{raw_text} {href}".lower()
            if ".pdf" not in href.lower():
                continue
            if "question paper" not in haystack and "question-paper" not in haystack:
                continue
            if year_4 not in haystack and str(year_short) not in haystack:
                continue
            if season_words and not any(w in haystack for w in season_words):
                continue
            if not component_re.search(haystack):
                if not re.search(
                        rf"\bpaper\s*0?{re.escape(str(component))}\b",
                        haystack, re.IGNORECASE):
                    continue
            if href not in found:
                found.append(href)
        return found

    def build_all(
        self,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
    ) -> List[dict]:
        """All candidate URLs across allowed sources -> [{source, url}]."""
        past = self.build_pastpapers_co(
            syllabus_code, season, year_short, component)
        candidates = []
        official = self.build_official_index_url(syllabus_code)
        if official:
            candidates.append({"source": "cambridge_international_official", "url": official})
        ordered_past = ([past[2]] if len(past) > 2 else []) + past[:2]
        for url in ordered_past:
            candidates.append({"source": "pastpapers.co", "url": url})
        return candidates[:4]


# ══════════════════════════════════════════════════════
# LAYER 2: VERIFIER (QP identity; Downloader reused from ms_fetcher)
# ══════════════════════════════════════════════════════

class QPVerifier(PDFVerifier):
    """Verifies a downloaded PDF is the EXPECTED QUESTION PAPER before it is
    used. All checks must pass; any failure -> REVIEW_REQUIRED (RULE 2).

    A QP must:
      * be a real, cleanly-opening PDF;
      * carry the syllabus code, component, and session of the request;
      * look like a question paper (candidate instructions) and NOT like a
        mark scheme or an insert booklet (a mirror serving the MS or the
        insert under the QP filename is the classic identity swap).
    """

    QP_SIGNALS = [
        "answer all questions",
        "answer question",
        "write your answer",
        "candidate name",
        "centre number",
        "read these instructions",
        "do not write",
        "answer the questions",
    ]
    INSERT_SIGNALS = [
        "this insert contains",
        "insert booklet",
        "this insert has",
        "the insert contains",
    ]

    def verify(
        self,
        pdf_path:      Path,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
    ) -> QPVerificationResult:
        reasons = []

        is_pdf = self._check_is_pdf(pdf_path)
        if not is_pdf:
            reasons.append("File is not a valid PDF")

        opens_cleanly = False
        text = ""
        if is_pdf:
            opens_cleanly, text = self._check_opens(pdf_path)
            if not opens_cleanly:
                reasons.append("PDF fails to open cleanly")

        syllabus_matches = False
        if opens_cleanly:
            syllabus_matches = syllabus_code in text
            if not syllabus_matches:
                reasons.append(
                    f"Syllabus code {syllabus_code} not found in PDF content")

        component_matches = False
        if opens_cleanly:
            component_matches = self._check_component(text, component)
            if not component_matches:
                reasons.append(
                    f"Component {component} not found in PDF content")

        session_matches = False
        if opens_cleanly:
            session_matches = self._check_session(text, season, year_short)
            if not session_matches:
                reasons.append(
                    f"Session {season}{year_short} not confirmed in PDF content")

        is_question_paper = False
        if opens_cleanly:
            is_question_paper = self._check_is_qp(text)
            if not is_question_paper:
                reasons.append("PDF does not appear to be a question paper "
                               "(mark-scheme/insert identity swap?)")

        passed = (is_pdf and opens_cleanly and syllabus_matches
                  and component_matches and session_matches
                  and is_question_paper)
        return QPVerificationResult(
            passed=passed,
            is_pdf=is_pdf,
            syllabus_matches=syllabus_matches,
            component_matches=component_matches,
            session_matches=session_matches,
            is_question_paper=is_question_paper,
            opens_cleanly=opens_cleanly,
            failure_reasons=reasons,
        )

    def _check_is_qp(self, text: str) -> bool:
        has_ms_signal = any(s in text for s in self.MS_SIGNALS)
        has_qp_signal = any(s in text for s in self.QP_SIGNALS)
        has_insert_signal = any(s in text for s in self.INSERT_SIGNALS)
        if has_ms_signal:
            return False
        if has_insert_signal:
            return False
        return has_qp_signal


# ══════════════════════════════════════════════════════
# LAYER 3: CACHE MANAGER (QP flavour)
# ══════════════════════════════════════════════════════

class QPCache:
    """Local cache of downloaded QP PDFs — SEPARATE from the papers input
    dir; downloaded files never overwrite user-provided files (RULE 4)."""

    def __init__(self, cache_dir: Path):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def get_cache_path(self, syllabus_code: str, season: str,
                       year_short: str, component: str) -> Path:
        filename = f"{syllabus_code}_{season}{year_short}_qp_{component}.pdf"
        return self.cache_dir / syllabus_code / filename

    def is_cached(self, syllabus_code: str, season: str,
                  year_short: str, component: str) -> bool:
        path = self.get_cache_path(syllabus_code, season, year_short, component)
        return path.exists() and path.stat().st_size > MIN_PDF_SIZE

    def compute_sha256(self, path: Path) -> str:
        return _file_sha256(Path(path))   # single-source hasher (RS-8)


# ══════════════════════════════════════════════════════
# LAYER 4: FETCH LOG (SQLite extension — table qp_fetch_log)
# ══════════════════════════════════════════════════════

FETCH_LOG_SCHEMA = """
CREATE TABLE IF NOT EXISTS qp_fetch_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    bundle_key     TEXT    NOT NULL,
    syllabus_code  TEXT    NOT NULL,
    season         TEXT    NOT NULL,
    year           TEXT    NOT NULL,
    component      TEXT    NOT NULL,
    source         TEXT,
    url            TEXT,
    local_path     TEXT,
    sha256         TEXT,
    verified       INTEGER DEFAULT 0,
    success        INTEGER DEFAULT 0,
    error          TEXT,
    retrieved_at   REAL,
    created_at     REAL    DEFAULT (unixepoch())
);

CREATE INDEX IF NOT EXISTS idx_qp_fetch_bundle
    ON qp_fetch_log(bundle_key);
"""


def ensure_qp_fetch_log(db_path: Path):
    """Add the qp fetch log table to the existing database (idempotent)."""
    conn = sqlite3.connect(str(db_path))
    conn.executescript(FETCH_LOG_SCHEMA)
    conn.commit()
    conn.close()


def log_qp_fetch_result(db_path: Path, result: QPFetchResult):
    """Record one QP fetch attempt (RULE 3: url, source, sha256, timestamp)."""
    conn = sqlite3.connect(str(db_path))
    parts = result.bundle_key.split("_")
    conn.execute("""
        INSERT INTO qp_fetch_log
        (bundle_key, syllabus_code, season, year,
         component, source, url, local_path, sha256,
         verified, success, error, retrieved_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        result.bundle_key,
        parts[0] if parts else "",
        parts[1][:1] if len(parts) > 1 else "",
        parts[1][1:] if len(parts) > 1 else "",
        parts[2] if len(parts) > 2 else "",
        result.source,
        result.url,
        str(result.local_path) if result.local_path else None,
        result.sha256,
        1 if result.verified else 0,
        1 if result.success else 0,
        result.error,
        result.retrieved_at,
    ))
    conn.commit()
    conn.close()


# ══════════════════════════════════════════════════════
# MASTER ORCHESTRATOR
# ══════════════════════════════════════════════════════

def _canonical_qp_filename(syllabus_code: str, season: str,
                           year_short: str, component: str) -> str:
    season_n = SEASON_TO_CODE.get(str(season).lower(), str(season).lower())
    return f"{syllabus_code}_{season_n}{year_short}_qp_{component}.pdf"


class MissingQPResolver:
    """Finds bundles with missing question papers and fetches them from
    online sources. Only runs when --fetch-missing-qp is passed. Never
    modifies already-complete bundles.

    Two entry points:
      * resolve_all()               — DB-driven (run_pipeline): registers the
                                      fetched QP in `files` and points the
                                      bundle at it (next run consumes it).
      * fetch_missing_qps_in_dir()  — input-dir pre-flight (run_guarded /
                                      main.py): writes the verified QP into
                                      the input folder with the canonical
                                      filename so identification sees it on
                                      the same run.
    """

    def __init__(self, db_path: Optional[Path] = None,
                 cache_dir: Optional[Path] = None,
                 dry_run: bool = False):
        self.db_path = Path(db_path) if db_path else None
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.dry_run = dry_run
        self.url_builder = QPURLBuilder()
        self.downloader = Downloader()
        self.verifier = QPVerifier()
        self.cache = QPCache(cache_dir) if cache_dir else None
        self.db = Database(self.db_path) if self.db_path else None
        if self.db_path is not None:
            ensure_qp_fetch_log(self.db_path)

    # ── DB-driven mode (run_pipeline) ────────────────────────────

    def resolve_all(self) -> dict:
        """Fetch QP for every stored bundle whose qp_file_id IS NULL."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        missing = conn.execute("""
            SELECT b.id,
                   b.bundle_key,
                   b.syllabus_code,
                   b.season,
                   b.year,
                   b.component,
                   b.status,
                   b.qp_file_id
            FROM bundles b
            WHERE b.qp_file_id IS NULL
            AND   b.status IN ('pending', 'failed')
            ORDER BY b.id ASC
        """).fetchall()
        conn.close()

        if not missing:
            print("No bundles with missing question papers found.")
            return {"found": 0, "resolved": 0, "review": 0, "failed": 0}

        print(f"Found {len(missing)} bundles with missing QP. Attempting to fetch...")
        if self.dry_run:
            print("DRY RUN: showing URLs only, not downloading")

        resolved = 0
        failed = 0
        review = 0

        for row in missing:
            bundle_key = row["bundle_key"]
            syllabus_code = row["syllabus_code"]
            season = row["season"]
            year_short = row["year"]
            component = row["component"]
            dest_path = self.cache.get_cache_path(
                syllabus_code, season, year_short, component)

            result = self._resolve_one(
                bundle_key=bundle_key,
                syllabus_code=syllabus_code,
                season=season,
                year_short=year_short,
                component=component,
                dest_path=dest_path,
                check_cache=True,
            )

            if result.success and result.verified:
                resolved += 1
                self._update_bundle_qp(
                    row["id"], result.local_path,
                    syllabus_code=syllabus_code, season=season,
                    year_short=year_short, component=component,
                )
                print(f"  ✅ {bundle_key}: QP found at {result.source}")
            elif result.success and not result.verified:
                review += 1
                print(f"  👁  {bundle_key}: Downloaded but verification "
                      f"failed — REVIEW_REQUIRED")
                self._mark_review(
                    row["id"],
                    f"QP downloaded but failed verification: {result.error}")
            else:
                failed += 1
                print(f"  ❌ {bundle_key}: Not found on any source")

            if not self.dry_run:
                log_qp_fetch_result(self.db_path, result)
            if not self.dry_run:
                time.sleep(REQUEST_DELAY)             # RULE 5: mandatory

        self.downloader.close()

        summary = {
            "found": len(missing),
            "resolved": resolved,
            "review": review,
            "failed": failed,
        }
        print("\nQP Fetch Summary:")
        print(f"  Found missing:  {summary['found']}")
        print(f"  ✅ Resolved:    {summary['resolved']}")
        print(f"  👁  Review:     {summary['review']}")
        print(f"  ❌ Not found:   {summary['failed']}")
        return summary

    # ── Input-directory pre-flight mode (run_guarded / main.py) ──

    def fetch_missing_qps_in_dir(self, input_dir: Path,
                                 output_root: Optional[Path] = None) -> dict:
        """Scan an input dir for MS/ER files whose QP twin is absent, fetch
        the QPs into the input dir (canonical names), and return a summary.

        The QP is written NEXT TO the MS that references it (same subdir) so
        the normal identification pass finds the pair. Existing files are
        never overwritten.
        """
        from .paper_identifier import parse_paper_filename

        input_dir = Path(input_dir)
        missing = {}
        for pdf in sorted(input_dir.rglob("*.pdf")):
            info = parse_paper_filename(pdf)
            if info is None or info.paper_type not in ("ms", "er"):
                continue
            key = (info.syllabus_code, info.season_letter,
                   info.year_short, info.variant)
            twin_name = _canonical_qp_filename(*key)
            twin = pdf.parent / twin_name
            if twin.exists():
                continue
            if key in missing:
                continue  # first (deterministic) location wins
            missing[key] = {
                "bundle_key": f"{info.syllabus_code}_{info.season_letter}{info.year_short}_{info.variant}",
                "syllabus_code": info.syllabus_code,
                "season": info.season_letter,
                "year_short": info.year_short,
                "component": info.variant,
                "dest": twin,
            }

        if not missing:
            print("[fetch-qp] No missing question papers found in "
                  f"{input_dir} — every MS/ER has its QP twin.")
            return {"found": 0, "resolved": 0, "review": 0, "failed": 0,
                    "files": []}

        print(f"[fetch-qp] Found {len(missing)} missing question paper(s) "
              f"in {input_dir}. Attempting to fetch...")
        if self.dry_run:
            print("[fetch-qp] DRY RUN: showing URLs only, not downloading")

        resolved = 0
        failed = 0
        review = 0
        files = []

        for key in sorted(missing):
            entry = missing[key]
            result = self._resolve_one(
                bundle_key=entry["bundle_key"],
                syllabus_code=entry["syllabus_code"],
                season=entry["season"],
                year_short=entry["year_short"],
                component=entry["component"],
                dest_path=entry["dest"],
                check_cache=False,
            )

            if result.success and result.verified:
                resolved += 1
                files.append(str(result.local_path))
                print(f"  ✅ {entry['bundle_key']}: QP downloaded to "
                      f"{result.local_path} ({result.source})")
            elif result.success and not result.verified:
                review += 1
                print(f"  👁  {entry['bundle_key']}: Downloaded but verification "
                      f"failed — REVIEW_REQUIRED ({result.error})")
            else:
                failed += 1
                print(f"  ❌ {entry['bundle_key']}: Not found on any source")

            if not self.dry_run and self.db_path is not None:
                log_qp_fetch_result(self.db_path, result)
            if not self.dry_run:
                time.sleep(REQUEST_DELAY)             # RULE 5: mandatory

        self.downloader.close()

        summary = {
            "found": len(missing),
            "resolved": resolved,
            "review": review,
            "failed": failed,
            "files": files,
        }
        print("\nQP Fetch Summary:")
        print(f"  Found missing:  {summary['found']}")
        print(f"  ✅ Resolved:    {summary['resolved']}")
        print(f"  👁  Review:     {summary['review']}")
        print(f"  ❌ Not found:   {summary['failed']}")
        return summary

    # ── Shared single-QP resolution ──────────────────────────────

    def _resolve_one(
        self,
        bundle_key:    str,
        syllabus_code: str,
        season:        str,
        year_short:    str,
        component:     str,
        dest_path:     Path,
        check_cache:   bool,
    ) -> QPFetchResult:
        """Fetch and verify one QP: official index first, then mirror URLs.
        `dest_path` is the final resting place (cache dir in DB mode, input
        dir in pre-flight mode). Never overwrites an existing verified file.
        """
        dest_path = Path(dest_path)

        if dest_path.exists():
            # Already on disk (a user-provided file, or a previous run).
            # Re-verify so a stale/wrong-identity PDF can never enter.
            cached_verification = self.verifier.verify(
                dest_path, syllabus_code, season, year_short, component)
            if cached_verification.passed:
                checksum = self.cache.compute_sha256(dest_path) \
                    if self.cache else _file_sha256(dest_path)
                logger.info(
                    f"Existing verified QP reused for {bundle_key}: {dest_path.name}")
                return QPFetchResult(
                    success=True, bundle_key=bundle_key, source="local",
                    url="", local_path=dest_path, sha256=checksum,
                    error=None, verified=True, retrieved_at=time.time())
            logger.warning(
                "Rejecting unverified existing file %s: %s",
                dest_path,
                "; ".join(cached_verification.failure_reasons),
            )
            # RULE 4: never overwrite a user file. In cache mode (DB-driven)
            # the file is ours, so it is quarantined and a fresh download is
            # attempted. In input-dir mode the file may be the user's own —
            # it is left untouched and reported REVIEW_REQUIRED instead.
            if self.cache is not None:
                failed_path = dest_path.with_suffix(".unverified.pdf")
                failed_path.unlink(missing_ok=True)
                dest_path.rename(failed_path)
            else:
                return QPFetchResult(
                    success=True, bundle_key=bundle_key, source="local",
                    url="", local_path=dest_path,
                    sha256=self.cache.compute_sha256(dest_path)
                    if self.cache else _file_sha256(dest_path),
                    error="Existing file failed verification and was left in "
                          "place (user file never overwritten)",
                    verified=False, retrieved_at=time.time())

        candidates = self.url_builder.build_all(
            syllabus_code, season, year_short, component)
        if not candidates:
            return QPFetchResult(
                success=False, bundle_key=bundle_key, source="", url="",
                local_path=None, sha256=None,
                error="No candidate URLs (unknown syllabus code?)",
                verified=False, retrieved_at=time.time())

        if self.dry_run:
            print(f"  {bundle_key}: would try {len(candidates)} URLs:")
            for c in candidates:
                print(f"    [{c['source']}] {c['url']}")
            return QPFetchResult(
                success=False, bundle_key=bundle_key, source="dry_run",
                url=candidates[0]["url"] if candidates else "",
                local_path=None, sha256=None, error="dry_run",
                verified=False, retrieved_at=time.time())

        dest_path.parent.mkdir(parents=True, exist_ok=True)

        def download_and_verify(source: str, url: str) -> Optional[QPFetchResult]:
            tmp_path = dest_path.with_suffix(".part")
            tmp_path.unlink(missing_ok=True)
            success, error = self.downloader.download(url, tmp_path)
            if not success:
                logger.debug(f"Download failed: {error}")
                tmp_path.unlink(missing_ok=True)
                return None

            verification = self.verifier.verify(
                pdf_path=tmp_path,
                syllabus_code=syllabus_code,
                season=season,
                year_short=year_short,
                component=component,
            )
            checksum = self.cache.compute_sha256(tmp_path) \
                if self.cache else _file_sha256(tmp_path)

            if verification.passed:
                # Atomic publish: only a verified QP takes the canonical name.
                if dest_path.exists():
                    if self.cache is not None:
                        # Cache files are ours: safe to replace.
                        dest_path.unlink(missing_ok=True)
                    else:
                        # A file appeared at the canonical name mid-download
                        # (user copy-in). RULE 4: never overwrite it.
                        failed_path = dest_path.with_suffix(".unverified.pdf")
                        failed_path.unlink(missing_ok=True)
                        tmp_path.rename(failed_path)
                        return QPFetchResult(
                            success=True, bundle_key=bundle_key, source=source,
                            url=url, local_path=failed_path, sha256=checksum,
                            error="Destination appeared during download; "
                                  "user file never overwritten",
                            verified=False, retrieved_at=time.time())
                tmp_path.rename(dest_path)
                return QPFetchResult(
                    success=True, bundle_key=bundle_key, source=source,
                    url=url, local_path=dest_path, sha256=checksum,
                    error=None, verified=True, retrieved_at=time.time())

            # Downloaded but verification failed: keep bytes for a human and
            # stop this source chain. Never silently use a different identity
            # under the same filename.
            failed_path = dest_path.with_suffix(".unverified.pdf")
            failed_path.unlink(missing_ok=True)
            tmp_path.rename(failed_path)
            reasons = "; ".join(verification.failure_reasons)
            logger.warning(f"Verification failed for {url}: {reasons}")
            return QPFetchResult(
                success=True, bundle_key=bundle_key, source=source, url=url,
                local_path=failed_path, sha256=checksum, error=reasons,
                verified=False, retrieved_at=time.time())

        for candidate in candidates:
            source = candidate["source"]
            url = candidate["url"]
            logger.debug(f"Trying [{source}]: {url}")

            if source == "cambridge_international_official":
                html, error = self.downloader.fetch_text(url)
                if not html:
                    logger.debug(f"Official index unavailable: {error}")
                    continue
                direct_urls = self.url_builder.extract_official_qp_urls(
                    html, url, syllabus_code, season, year_short, component)
                if not direct_urls:
                    logger.debug("Official index had no unambiguous matching QP link")
                    continue
                for direct_url in direct_urls:
                    result = download_and_verify(source, direct_url)
                    if result is not None:
                        return result
                continue

            result = download_and_verify(source, url)
            if result is not None:
                return result

        return QPFetchResult(
            success=False, bundle_key=bundle_key, source="", url="",
            local_path=None, sha256=None, error="Not found on any source",
            verified=False, retrieved_at=time.time())

    def _update_bundle_qp(
        self,
        bundle_id:     int,
        qp_path:       Path,
        syllabus_code: str = "",
        season:        str = "",
        year_short:    str = "",
        component:     str = "",
    ):
        """Register the fetched QP (id-preserving UPSERT) and point the
        bundle at it. Next run_pipeline picks it up via get_pending_bundles'
        files JOIN (mirror of ms_fetcher._update_bundle_ms)."""
        file_id = self.db.register_file(
            path=Path(qp_path), kind="qp",
            syllabus_code=syllabus_code, season=season,
            year=year_short, component=component,
            paper_format="FETCHED_QP",
        )
        conn = sqlite3.connect(str(self.db_path))
        try:
            conn.execute("UPDATE bundles SET qp_file_id=? WHERE id=?",
                         (file_id, bundle_id))
            conn.commit()
        finally:
            conn.close()

    def _mark_review(self, bundle_id: int, reason: str):
        """Mark bundle as needing review (RULE 2)."""
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("""
            UPDATE bundles
            SET    status='review_required',
                   error_message=?
            WHERE  id=?
        """, (reason, bundle_id))
        conn.commit()
        conn.close()


# ──────────────────────────────────────────────────────────
# Module-level convenience for the run_guarded / main pre-flight.
# ──────────────────────────────────────────────────────────

def fetch_missing_qps_in_dir(input_dir, output_root=None, dry_run=False) -> dict:
    """Pre-flight helper: scan `input_dir` for MS/ER files whose QP twin is
    missing and download+verify the QPs into the input dir.

    Returns a summary dict {found, resolved, review, failed, files}.
    """
    db_path = None
    if output_root is not None:
        candidate = Path(output_root) / "pipeline.sqlite"
        if candidate.exists():
            db_path = candidate
    resolver = MissingQPResolver(db_path=db_path,
                                 cache_dir=None,
                                 dry_run=bool(dry_run))
    return resolver.fetch_missing_qps_in_dir(Path(input_dir),
                                             output_root=Path(output_root)
                                             if output_root else None)


# CLI: standalone fetch of missing QPs (used by scripts/tests).
def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(
        description="Fetch missing Cambridge question papers (verified) "
                    "into an input directory.")
    ap.add_argument("input_dir")
    ap.add_argument("--output", "-o", default=None,
                    help="output root (for pipeline.sqlite fetch log)")
    ap.add_argument("--dry-run", action="store_true",
                    help="print candidate URLs without downloading")
    args = ap.parse_args(argv)

    summary = fetch_missing_qps_in_dir(
        args.input_dir, output_root=args.output, dry_run=args.dry_run)
    return 0 if summary.get("failed", 0) == 0 and summary.get("review", 0) == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
