"""Central SQLite database for all pipeline state (Overseer batch-infrastructure
spec, Phase 1 — honest port into the production package).

Schema is VERBATIM from the spec (files / bundles / questions / artifacts /
errors + indexes + WAL). Deliberate deviations from the spec's code, audited
against SQLite semantics BEFORE writing (receipts in the round evidence log):

1. `register_file` uses an id-preserving UPSERT instead of the spec's
   `INSERT OR REPLACE`. REPLACE is DELETE+INSERT: re-registering the same
   path would mint a NEW rowid and silently orphan every bundle row whose
   qp_file_id / ms_file_id / er_file_id referenced the old one. ON CONFLICT
   DO UPDATE keeps the rowid stable (files.path is UNIQUE), so the foreign
   keys in `bundles` can never dangle.
2. Markdown-linkification corruption in the spec text repaired on write
   (-> operators, __init__, f.read, join predicates qp.id/ms.id, etc.).

Single source of truth for BATCH runs (core/batch_runner.py). main.py and
run_guarded.py keep the RS-locked .pipeline_state.json untouched for now —
maintainer-approved "bridge now, cutover later after parity proof".
"""

import sqlite3
import hashlib
import time
import logging
from pathlib import Path
from typing import Optional, List
from contextlib import contextmanager
from enum import Enum

logger = logging.getLogger(__name__)


class BundleStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETE = "complete"
    FAILED = "failed"
    REVIEW_REQUIRED = "review_required"


class ArtifactKind(Enum):
    QP = "qp"
    MS = "ms"
    ER = "er"
    IN = "in"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class Database:
    """
    Central SQLite database for all pipeline state.
    Thread-safe via WAL mode.
    """

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS files (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        path          TEXT    NOT NULL UNIQUE,
        sha256        TEXT    NOT NULL,
        kind          TEXT    NOT NULL,
        syllabus_code TEXT,
        season        TEXT,
        year          TEXT,
        component     TEXT,
        paper_format  TEXT,
        created_at    REAL    DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS bundles (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        bundle_key     TEXT    NOT NULL UNIQUE,
        syllabus_code  TEXT    NOT NULL,
        subject        TEXT    NOT NULL,
        level          TEXT    NOT NULL,
        season         TEXT    NOT NULL,
        year           TEXT    NOT NULL,
        component      TEXT    NOT NULL,
        paper_format   TEXT    NOT NULL,
        qp_file_id     INTEGER REFERENCES files(id),
        ms_file_id     INTEGER REFERENCES files(id),
        er_file_id     INTEGER REFERENCES files(id),
        status         TEXT    NOT NULL DEFAULT 'pending',
        attempts       INTEGER NOT NULL DEFAULT 0,
        error_message  TEXT,
        questions_found INTEGER,
        questions_saved INTEGER,
        started_at     REAL,
        completed_at   REAL
    );
    CREATE TABLE IF NOT EXISTS questions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        bundle_id       INTEGER NOT NULL REFERENCES bundles(id),
        question_num    TEXT    NOT NULL,
        topic_assigned  TEXT,
        folder_path     TEXT,
        status          TEXT    NOT NULL DEFAULT 'pending',
        needs_review    INTEGER NOT NULL DEFAULT 0,
        error_message   TEXT
    );
    CREATE TABLE IF NOT EXISTS artifacts (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL REFERENCES questions(id),
        kind        TEXT    NOT NULL,
        path        TEXT    NOT NULL,
        width_px    INTEGER,
        height_px   INTEGER,
        file_size   INTEGER,
        created_at  REAL    DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS errors (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        bundle_id  INTEGER REFERENCES bundles(id),
        stage      TEXT    NOT NULL,
        message    TEXT    NOT NULL,
        trace      TEXT,
        created_at REAL    DEFAULT (unixepoch())
    );
    CREATE INDEX IF NOT EXISTS idx_bundles_status
        ON bundles(status);
    CREATE INDEX IF NOT EXISTS idx_questions_bundle
        ON questions(bundle_id);
    CREATE INDEX IF NOT EXISTS idx_files_sha256
        ON files(sha256);
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=NORMAL;
    """

    def __init__(self, db_path: Path):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            conn.executescript(self.SCHEMA)

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(
            str(self.db_path),
            timeout=30,
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ── FILE REGISTRY ──────────────────────────────

    def register_file(
        self,
        path: Path,
        kind: str,
        syllabus_code: str,
        season: str,
        year: str,
        component: str,
        paper_format: str,
    ) -> int:
        checksum = sha256(path)
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO files
                (path, sha256, kind, syllabus_code,
                 season, year, component, paper_format)
                VALUES (?,?,?,?,?,?,?,?)
                ON CONFLICT(path) DO UPDATE SET
                    sha256=excluded.sha256,
                    kind=excluded.kind,
                    syllabus_code=excluded.syllabus_code,
                    season=excluded.season,
                    year=excluded.year,
                    component=excluded.component,
                    paper_format=excluded.paper_format
            """, (
                str(path), checksum, kind,
                syllabus_code, season, year,
                component, paper_format,
            ))
            row = conn.execute(
                "SELECT id FROM files WHERE path=?",
                (str(path),)
            ).fetchone()
            return row["id"]

    # ── BUNDLE MANAGEMENT ──────────────────────────

    def create_bundle(
        self,
        bundle_key: str,
        syllabus_code: str,
        subject: str,
        level: str,
        season: str,
        year: str,
        component: str,
        paper_format: str,
        qp_file_id: Optional[int],
        ms_file_id: Optional[int],
        er_file_id: Optional[int],
    ) -> int:
        with self._conn() as conn:
            conn.execute("""
                INSERT OR IGNORE INTO bundles
                (bundle_key, syllabus_code, subject, level,
                 season, year, component, paper_format,
                 qp_file_id, ms_file_id, er_file_id)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (
                bundle_key, syllabus_code, subject, level,
                season, year, component, paper_format,
                qp_file_id, ms_file_id, er_file_id,
            ))
            row = conn.execute(
                "SELECT id FROM bundles WHERE bundle_key=?",
                (bundle_key,)
            ).fetchone()
            return row["id"]

    def get_pending_bundles(self) -> List[sqlite3.Row]:
        with self._conn() as conn:
            return conn.execute("""
                SELECT b.*,
                       qp.path as qp_path,
                       ms.path as ms_path,
                       er.path as er_path
                FROM   bundles b
                LEFT JOIN files qp ON b.qp_file_id = qp.id
                LEFT JOIN files ms ON b.ms_file_id = ms.id
                LEFT JOIN files er ON b.er_file_id = er.id
                WHERE  b.status IN ('pending', 'failed')
                AND    b.attempts < 3
                ORDER  BY b.id ASC
            """).fetchall()

    def get_failed_bundles(self) -> List[sqlite3.Row]:
        with self._conn() as conn:
            return conn.execute("""
                SELECT * FROM bundles
                WHERE  status = 'failed'
                ORDER  BY id ASC
            """).fetchall()

    def mark_bundle_processing(self, bundle_id: int):
        with self._conn() as conn:
            conn.execute("""
                UPDATE bundles
                SET    status='processing',
                       started_at=?,
                       attempts=attempts+1
                WHERE  id=?
            """, (time.time(), bundle_id))

    def mark_bundle_complete(
        self,
        bundle_id: int,
        questions_found: int,
        questions_saved: int,
    ):
        with self._conn() as conn:
            conn.execute("""
                UPDATE bundles
                SET    status='complete',
                       completed_at=?,
                       questions_found=?,
                       questions_saved=?
                WHERE  id=?
            """, (
                time.time(),
                questions_found,
                questions_saved,
                bundle_id,
            ))

    def mark_bundle_failed(
        self,
        bundle_id: int,
        error: str,
        trace: str = "",
    ):
        with self._conn() as conn:
            conn.execute("""
                UPDATE bundles
                SET    status='failed',
                       error_message=?,
                       completed_at=?
                WHERE  id=?
            """, (error, time.time(), bundle_id))
            conn.execute("""
                INSERT INTO errors (bundle_id, stage, message, trace)
                VALUES (?, 'pipeline', ?, ?)
            """, (bundle_id, error, trace))

    def mark_bundle_review(
        self,
        bundle_id: int,
        reason: str,
    ):
        with self._conn() as conn:
            conn.execute("""
                UPDATE bundles
                SET    status='review_required',
                       error_message=?
                WHERE  id=?
            """, (reason, bundle_id))

    def bundle_exists(self, bundle_key: str) -> bool:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT id FROM bundles WHERE bundle_key=?",
                (bundle_key,)
            ).fetchone()
            return row is not None

    def bundle_is_complete(self, bundle_key: str) -> bool:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT status FROM bundles WHERE bundle_key=?",
                (bundle_key,)
            ).fetchone()
            return (row is not None
                    and row["status"] == "complete")

    def set_bundle_counts(
        self,
        bundle_id: int,
        questions_found: int,
        questions_saved: int,
    ):
        """Additive helper: record found/saved counts WITHOUT touching status.
        Used on review_required bundles whose crops legitimately committed —
        otherwise print_progress would claim 0 questions saved beside a full
        committed tree (untruthful reporting).
        """
        with self._conn() as conn:
            conn.execute("""
                UPDATE bundles
                SET    questions_found=?,
                       questions_saved=?
                WHERE  id=?
            """, (questions_found, questions_saved, bundle_id))

    def bundle_status(self, bundle_key: str) -> Optional[str]:
        """Additive read helper (batch runner reports)."""
        with self._conn() as conn:
            row = conn.execute(
                "SELECT status FROM bundles WHERE bundle_key=?",
                (bundle_key,)
            ).fetchone()
            return row["status"] if row is not None else None

    # ── QUESTION TRACKING ──────────────────────────

    def register_question(
        self,
        bundle_id: int,
        question_num: str,
        topic_assigned: str,
        folder_path: str,
        needs_review: bool = False,
    ) -> int:
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO questions
                (bundle_id, question_num, topic_assigned,
                 folder_path, status, needs_review)
                VALUES (?,?,?,?,'complete',?)
            """, (
                bundle_id, question_num,
                topic_assigned, folder_path,
                1 if needs_review else 0,
            ))
            return conn.execute(
                "SELECT last_insert_rowid()"
            ).fetchone()[0]

    def register_artifact(
        self,
        question_id: int,
        kind: str,
        path: str,
        width_px: Optional[int] = None,
        height_px: Optional[int] = None,
        file_size: Optional[int] = None,
    ):
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO artifacts
                (question_id, kind, path,
                 width_px, height_px, file_size)
                VALUES (?,?,?,?,?,?)
            """, (
                question_id, kind, path,
                width_px, height_px, file_size,
            ))

    # ── IDENTITY INDEX ─────────────────────────────

    def question_exists(
        self,
        syllabus_code: str,
        season: str,
        year: str,
        component: str,
        question_num: str,
    ) -> bool:
        """
        Constant-time duplicate detection.
        Replaces rglob() scanning of output tree.
        """
        with self._conn() as conn:
            row = conn.execute("""
                SELECT q.id FROM questions q
                JOIN   bundles b ON q.bundle_id = b.id
                WHERE  b.syllabus_code = ?
                AND    b.season        = ?
                AND    b.year          = ?
                AND    b.component     = ?
                AND    q.question_num  = ?
                AND    b.status        = 'complete'
            """, (
                syllabus_code, season, year,
                component, question_num,
            )).fetchone()
            return row is not None

    # ── PROGRESS REPORTING ─────────────────────────

    def get_progress(self) -> dict:
        with self._conn() as conn:
            row = conn.execute("""
                SELECT
                    COUNT(*)                              as total,
                    SUM(status='complete')                as complete,
                    SUM(status='failed')                  as failed,
                    SUM(status='pending')                 as pending,
                    SUM(status='processing')              as processing,
                    SUM(status='review_required')         as review,
                    SUM(COALESCE(questions_saved, 0))     as total_questions
                FROM bundles
            """).fetchone()
            return dict(row)

    def print_progress(self):
        p = self.get_progress()
        total = p["total"] or 0
        complete = p["complete"] or 0
        pct = (complete / total * 100) if total > 0 else 0
        print(f"\n{'=' * 55}")
        print(f"  PIPELINE PROGRESS")
        print(f"{'=' * 55}")
        print(f"  Total bundles:      {total}")
        print(f"  ✅ Complete:        {complete} ({pct:.1f}%)")
        print(f"  ⏳ Pending:         {p['pending']}")
        print(f"  🔄 Processing:      {p['processing']}")
        print(f"  ❌ Failed:          {p['failed']}")
        print(f"  👁  Review required: {p['review']}")
        print(f"  📄 Questions saved: {p['total_questions']}")
        print(f"{'=' * 55}\n")
