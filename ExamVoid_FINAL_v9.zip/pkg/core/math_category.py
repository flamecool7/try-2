"""
Mathematics / Further Mathematics Categorization + Paper 7 Verification
Implements Part 1 and Part 2 of Mathematics categorization requirement

PROTECTED: Does NOT modify cropping, naming, folder structure, JSON schema, examiner report

Mathematics categorization is paper/component based, NOT question-level detailed classification
Paper 7 triggers online verification with caching
"""

import json
import re
from pathlib import Path
from typing import Dict, Optional, Tuple
import hashlib

# Cache file for verified Paper 7 mappings
CACHE_FILE = Path(__file__).parent.parent / "paper7_mappings.json"

# Official component mappings for Mathematics subjects
# Source: Official Cambridge syllabus/component structure

# Mathematics 9709 - AS & A Level Mathematics
MATH_9709_COMPONENTS = {
    1: "P1_Pure_Mathematics_1",
    2: "P2_Pure_Mathematics_2",
    3: "P3_Pure_Mathematics_3",
    4: "P4_Mechanics",
    5: "P5_Probability_and_Statistics_1",
    6: "P6_Probability_and_Statistics_2",
}

# Further Mathematics 9231
FURTHER_9231_COMPONENTS = {
    1: "P1_Further_Pure_Mathematics_1",
    2: "P2_Further_Pure_Mathematics_2",
    3: "P3_Further_Mechanics",
    4: "P4_Further_Probability_and_Statistics",
}

# IGCSE Mathematics 0580 - Core and Extended have Papers 1-4
# Simplified: Paper 1 and 2 are Non-calculator/Calculator? For IGCSE, categories based on paper number
MATH_0580_COMPONENTS = {
    1: "P1_Non_Calculator_Core",
    2: "P2_Calculator_Core",
    3: "P3_Non_Calculator_Extended",
    4: "P4_Calculator_Extended",
}

# Generic fallback for other Mathematics-based syllabuses
GENERIC_MATH_COMPONENTS = {
    1: "P1_Pure_Mathematics_1",
    2: "P2_Pure_Mathematics_2",
    3: "P3_Pure_Mathematics_3",
    4: "P4_Mechanics",
    5: "P5_Probability_and_Statistics_1",
    6: "P6_Probability_and_Statistics_2",
    7: "P7_Paper_7",  # Will be verified online
}

def is_mathematics_subject(subject: str, syllabus_code: str = "") -> bool:
    """Check if subject is Mathematics-related per requirement"""
    subject_lower = subject.lower() if subject else ""
    code = str(syllabus_code or "")
    
    # Explicit Mathematics codes
    math_codes = {"9709", "9231", "0580", "0607", "0606", "4024", "4029", "0980"}
    if code in math_codes:
        return True
    
    # Check subject name contains mathematics
    if "mathematics" in subject_lower:
        return True
    
    return False

def get_paper_number_from_variant(variant: str) -> int:
    """Return the Mathematics component paper from its two-digit code.

    Mathematics and Further Mathematics use the component in the filename as
    the source of truth.  For ``..._qp_XY`` the *second-to-last* digit ``X`` is
    the paper number; ``Y`` is only the variant.  Thus 11, 12 and 13 are all
    P1, while 31, 32 and 33 are all P3.  No question text is consulted.

    A one-digit legacy component is retained as a defensive fallback because it
    has no separate variant digit; it is interpreted as that paper number.
    """
    value = str(variant).strip()
    digits = ''.join(char for char in value if char.isdigit())
    if len(digits) >= 2:
        return int(digits[-2])
    if len(digits) == 1:
        return int(digits)
    raise ValueError(f"Invalid Mathematics component code: {variant!r}")


def is_paper_7(variant: str, paper_number: int = None) -> bool:
    """Return true only when the filename-derived paper is P7.

    In particular, a final digit of 7 is a variant, not a Paper 7 indicator:
    ``17`` is P1 variant 7 and must not trigger Paper 7 verification.  ``71``
    is P7 variant 1 and does trigger the existing Paper 7 verification path.
    """
    if paper_number is None:
        paper_number = get_paper_number_from_variant(variant)
    return paper_number == 7

def get_canonical_math_category(syllabus_code: str, paper_number: int, variant: str = "") -> str:
    """
    Get canonical category for Mathematics based on paper/component identity
    NOT question content per requirement Part 1
    """
    code = str(syllabus_code)
    
    if code == "9709":
        return MATH_9709_COMPONENTS.get(paper_number, f"P{paper_number}_Paper_{paper_number}")
    elif code == "9231":
        return FURTHER_9231_COMPONENTS.get(paper_number, f"P{paper_number}_Paper_{paper_number}")
    elif code == "0580":
        return MATH_0580_COMPONENTS.get(paper_number, f"P{paper_number}_Paper_{paper_number}")
    elif code == "0606":
        # Additional Mathematics is routed question-by-question by the
        # official 14-topic classifier.  Refuse to manufacture a paper-number
        # pseudo-topic if an old caller reaches this component API.
        return ""
    else:
        # Generic mathematics
        return GENERIC_MATH_COMPONENTS.get(paper_number, f"P{paper_number}_Paper_{paper_number}")

def load_paper7_cache() -> Dict:
    """Load cached Paper 7 mappings"""
    if CACHE_FILE.exists():
        try:
            return json.loads(CACHE_FILE.read_text(encoding='utf-8'))
        except Exception:
            return {}
    return {}

def save_paper7_cache(cache: Dict):
    """Save cache"""
    try:
        CACHE_FILE.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding='utf-8')
    except Exception as e:
        print(f"[Paper7] Failed to save cache: {e}")

def get_cache_key(syllabus_code: str, year: str, season: str, subject: str, paper_number: int, variant: str) -> str:
    """Cache key must contain enough identifying info per requirement 17: syllabus, year, season, subject, component"""
    key_data = f"{syllabus_code}_{year}_{season}_{subject}_{paper_number}_{variant}"
    # Use hash for filesystem safety, but also keep readable
    return f"{syllabus_code}_{year}_{season}_{subject}_P{paper_number}_{variant}"

def get_cached_paper7_mapping(syllabus_code: str, year: str, season: str, subject: str, paper_number: int, variant: str) -> Optional[Dict]:
    """Get cached mapping if exists"""
    cache = load_paper7_cache()
    key = get_cache_key(syllabus_code, year, season, subject, paper_number, variant)
    return cache.get(key)

def cache_paper7_mapping(syllabus_code: str, year: str, season: str, subject: str, paper_number: int, variant: str, verified_mapping: str, source: str):
    """Cache verified mapping per requirement 16"""
    cache = load_paper7_cache()
    key = get_cache_key(syllabus_code, year, season, subject, paper_number, variant)
    
    cache[key] = {
        "syllabus": syllabus_code,
        "year": year,
        "season": season,
        "subject": subject,
        "paper": str(paper_number),
        "variant": variant,
        "verified_mapping": verified_mapping,
        "source": source,
        "verified": True,
        "timestamp": __import__("datetime").datetime.now().isoformat()
    }
    
    save_paper7_cache(cache)
    print(f"[Paper7] Cached mapping: {key} -> {verified_mapping}")

def search_online_for_paper7(syllabus_code: str, year: str, season: str, subject: str, variant: str) -> Tuple[Optional[str], str]:
    """
    Online verification for Paper 7 per requirements 9-11
    Searches using multiple identifying details, prefers official sources
    """
    # This would use web_search tool in real implementation
    # For now, we implement logic that would be used, with fallback to official component mapping
    
    # For Mathematics 9709 and Further 9231, Paper 7 is unusual - search for official documentation
    # Per requirement, we should search: "[syllabus code] Paper 7 [year] Cambridge"
    
    # In this environment, we cannot do live web search in this module, but main.py can use web_search tool
    # So this function will be called from main.py which can perform web_search
    
    # For now, return None to indicate need for online search
    # Actual online search will be done in main.py using web_search tool
    
    print(f"[Paper7] Online verification needed for {syllabus_code} Paper 7 Year {year} Season {season} Subject {subject}")
    
    # Fallback logic: For Mathematics, Paper 7 often corresponds to existing components or is independent
    # We need to determine based on official syllabus
    
    # For 9709 (Mathematics), there is NO official Paper 7 in current syllabus (only Papers 1-6)
    # So Paper 7 variant like 17,27,37,47 might actually be variant 7 of Paper 1,2,3,4
    # E.g., 9709_m26_qp_17.pdf: variant 17 = Paper 1 variant 7? Actually first digit 1 = Paper 1, second digit 7 = variant 7
    # So 17 is Paper 1 variant 7, not Paper 7
    # Similarly 27 = Paper 2 variant 7, 37 = Paper 3 variant 7, 47 = Paper 4 variant 7
    
    # Per requirement, we must NOT assume Paper 7 corresponds to Paper 1,2,3 etc. Verify it.
    # For Mathematics, variant 17 likely corresponds to Paper 1 (since first digit 1), variant 27 to Paper 2, etc.
    # But requirement says examples include _qp_17, _qp_27, _qp_37, _qp_47 as Paper 7 triggers
    # So _qp_17 should trigger verification, but after verification, it might be determined as corresponding to Paper 1
    
    # Let's implement logic to extract paper number from variant correctly:
    # Variant 12: Paper 1 variant 2, Variant 17: Paper 1 variant 7, Variant 22: Paper 2 variant 2, Variant 27: Paper 2 variant 7, etc.
    # So for variant 17, paper number is 1, variant number is 7
    # For variant 7, paper number is 7, variant 0? Actually single digit 7 could be Paper 7
    
    # For now, return None and let main.py handle online search via web_search tool
    return None, "Need online search"

def cross_check_paper7_against_pdf(pdf_path: str, syllabus_code: str, subject: str, paper_number: int, variant: str) -> Dict:
    """
    Cross-check against actual PDF per requirement 12
    Verify syllabus code, subject, paper number, component description, duration, title, instructions, question structure
    """
    # Extract text from PDF first page
    try:
        import fitz
        doc = fitz.open(pdf_path)
        text = ""
        for i in range(min(3, len(doc))):
            text += doc[i].get_text("text")[:2000] + "\n"
        doc.close()

        checks = {
            "syllabus_code_in_pdf": syllabus_code in text,
            "subject_in_pdf": subject.lower().split("_")[0] in text.lower() if subject else False,
            "paper_number_in_pdf": f"Paper {paper_number}" in text or f"Paper {variant}" in text,
            "text_sample": text[:500]
        }
        return checks
    except Exception as e:
        return {"error": str(e)}

def verify_paper7_mapping(syllabus_code: str, year: str, season: str, subject: str, paper_number: int, variant: str, pdf_path: str = None) -> Tuple[str, str, bool]:
    """
    Full verification process for Paper 7 per requirements 9-15
    Returns (verified_mapping, source, is_verified)
    """
    # Check cache first
    cached = get_cached_paper7_mapping(syllabus_code, year, season, subject, paper_number, variant)
    if cached:
        print(f"[Paper7] Using cached mapping for {syllabus_code} P{paper_number} {year} {season}: {cached['verified_mapping']}")
        return cached['verified_mapping'], cached['source'], True

    # For Mathematics, Paper 7 handling:
    # If variant is like 17,27,37,47, it's likely Paper 1,2,3,4 variant 7, not Paper 7
    # Extract paper number from variant first digit, variant number second digit
    variant_str = str(variant).lstrip("0")
    if len(variant_str) == 2 and variant_str[1] == "7":
        # Variant like 17,27,37,47,57,67 - first digit is paper number, second is variant 7
        actual_paper = int(variant_str[0])
        actual_variant = 7
        # This corresponds to existing component
        canonical = get_canonical_math_category(syllabus_code, actual_paper, variant)
        source = f"Variant {variant} is Paper {actual_paper} variant 7 per Cambridge variant system"
        print(f"[Paper7] {syllabus_code} variant {variant} -> Paper {actual_paper} variant 7 -> {canonical} (verified via variant parsing)")

        # Cache it
        cache_paper7_mapping(syllabus_code, year, season, subject, paper_number, variant, canonical, source)
        return canonical, source, True

    if len(variant_str) == 1 and variant_str == "7":
        # Single digit 7 - could be Paper 7 or variant 7
        # Need online verification to determine
        # For now, check if syllabus has Paper 7 as independent component
        # Mathematics 9709 does NOT have official Paper 7 (only 1-6), so Paper 7 likely corresponds to another paper or is legacy
        # We need online search - for now, we will search cache or return as independent with warning
        print(f"[Paper7] Single digit Paper 7 detected for {syllabus_code} - needs online verification")

        # Try to determine via online search would happen in main.py
        # For fallback, create independent category
        canonical = f"P7_Paper_7_Variant_{variant}"
        source = "Fallback independent P7 - needs online verification to confirm"
        return canonical, source, False

    # Default: treat as its own paper number
    canonical = get_canonical_math_category(syllabus_code, paper_number, variant)
    source = f"Direct paper number {paper_number} for {syllabus_code}"
    cache_paper7_mapping(syllabus_code, year, season, subject, paper_number, variant, canonical, source)
    return canonical, source, True
