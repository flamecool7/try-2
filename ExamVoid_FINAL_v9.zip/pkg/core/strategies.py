"""Strategy registry for paper processing (mega-spec Fix 4, 2026-08-12).

One interface per paper artefact kind; selection is driven by the syllabus
profile (paper_identifier format tables — the single format authority) and the
component number, never by guessing from pixels alone.

Production wiring: run_guarded's S2/S3/S6/S7 stages derive their branch
decisions from ``select_qp_strategy`` / ``select_ms_strategy`` /
``select_er_strategy``. A 9618-style structured-table parser is therefore
explicitly NOT universal: the registry only returns the structured-table legs
for components whose format is STRUCTURED, routes MCQ components to the
answer-grid/mcq legs, supports the three IGCSE science PRACTICAL/ATP profiles
through the validated structured splitter, and refuses other unsupported
components loudly with a REVIEW_REQUIRED reason instead of guessing.

Fail-closed contract: strategies never fabricate output. Unsupported component
kinds raise :class:`StrategyUnsupported` carrying the exact review reason.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .paper_identifier import resolve_paper_format


class StrategyUnsupported(RuntimeError):
    """Raised when a profile/component has no validated strategy.

    The message doubles as the REVIEW_REQUIRED reason stored in pipeline
    state / manifests (spec: ambiguous or unsupported input surfaces
    REVIEW_REQUIRED, never a silent assumption)."""

    def __init__(self, review_reason: str):
        super().__init__(review_reason)
        self.review_reason = review_reason


@dataclass(frozen=True)
class StrategyPlan:
    """The registry's decision for one paper, with the audit reason."""
    name: str          # strategy identifier (stable, used in proof manifests)
    kind: str          # qp_structured | qp_mcq | ms_structured | ms_mcq_grid |
                       # ms_legacy_portrait_ok | er_attach | unsupported
    reason: str        # why this strategy applies (profile + component driven)


class QuestionPaperStrategy:
    name = "qp_base"

    def plan(self, paper_info) -> StrategyPlan:  # pragma: no cover - interface
        raise NotImplementedError


class MarkSchemeStrategy:
    name = "ms_base"

    def plan(self, paper_info) -> StrategyPlan:  # pragma: no cover - interface
        raise NotImplementedError


class StructuredQuestionPaperStrategy(QuestionPaperStrategy):
    """Gold-standard numbered-anchor QP splitter (locked engine)."""
    name = "structured_qp_gold"


class MCQQuestionPaperStrategy(QuestionPaperStrategy):
    """MCQ QP: same numbered anchors per question stem; no MS crop exists."""
    name = "mcq_qp_gold"


class StructuredMarkSchemeStrategy(MarkSchemeStrategy):
    """Gold 'Question | Answer | Marks' header-rule MS splitter (locked)."""
    name = "structured_ms_gold"


class LegacyPortraitMarkSchemeStrategy(MarkSchemeStrategy):
    """Portrait-era (2015/2016 A-Level) flush-left margin-number MS splitter.

    Only ever a FALLBACK leg of the structured strategy: it must ground a
    strict 1..N run equal to the QP-proven question numbers (core/legacy_ms_split).
    """
    name = "legacy_portrait_ms"


class MCQMarkSchemeStrategy(MarkSchemeStrategy):
    """MCQ 'MS' = the bare answer grid; extracted to letters, never cropped."""
    name = "mcq_ms_grid"


class ExaminerReportStrategy:
    """ER: strict-identity text attach + per-question crops (S6/S7)."""
    name = "er_attach"
    kind = "er_attach"


class PracticalPaperStrategy(QuestionPaperStrategy):
    """IGCSE science practical/ATP QP using the validated numbered-anchor
    cropper.  The paper is practical in content, but its QP/MS raster grammar
    is still a structured numbered question paper.
    """
    name = "practical_qp_gold"


class EssayOrRubricStrategy(QuestionPaperStrategy):
    name = "essay_or_rubric"


def _paper_format(paper_info) -> str:
    fmt = getattr(paper_info, "paper_format", None)
    if fmt:
        return str(fmt).upper()
    return str(resolve_paper_format(getattr(paper_info, "syllabus_code", ""),
                                    getattr(paper_info, "variant", ""))).upper()


# IGCSE science Papers 5 and 6 are practical/alternative-to-practical in
# content, but their supplied QP/MS PDFs use the same numbered structured
# question grammar that the gold splitters can prove.  They are not sent
# through the MCQ grid parser or an A-Level essay parser.
PRACTICAL_STRUCTURED_CODES = {"0610", "0620", "0625"}


def _supports_practical_structured(paper_info) -> bool:
    return str(getattr(paper_info, "syllabus_code", "")) in PRACTICAL_STRUCTURED_CODES


def select_qp_strategy(paper_info) -> QuestionPaperStrategy:
    """Choose the QP strategy from profile + component identity.

    STRUCTURED/MCQ components -> the validated gold splitters. IGCSE science
    PRACTICAL/ATP components use the same structured splitter only for the
    three validated science codes in PRACTICAL_STRUCTURED_CODES. Other
    unsupported formats still raise REVIEW_REQUIRED.
    """
    fmt = _paper_format(paper_info)
    if fmt == "MCQ":
        return MCQQuestionPaperStrategy()
    if fmt in ("PRACTICAL", "ATP"):
        if _supports_practical_structured(paper_info):
            return PracticalPaperStrategy()
        raise StrategyUnsupported(
            f"REVIEW_REQUIRED: practical/ATP component (format={fmt}) has no "
            f"validated profile-driven strategy for syllabus "
            f"{getattr(paper_info, 'syllabus_code', '?')} — not guessing")
    if fmt == "ESSAY":
        raise StrategyUnsupported(
            "REVIEW_REQUIRED: essay/rubric component (format=ESSAY) has no "
            "validated strategy in this build — not routing to the structured "
            "table parser (spec Fix 4)")
    return StructuredQuestionPaperStrategy()


def select_ms_strategy(qp_info, ms_info) -> Optional[MarkSchemeStrategy]:
    """Choose the MS strategy; None when no MS paper was supplied (QP-only run).

    MCQ components -> answer-grid extraction. Everything else -> the structured
    gold splitter (whose own fail-closed fallback leg is the portrait-era
    splitter). Practical/essay components raise REVIEW_REQUIRED as above.
    """
    if ms_info is None:
        return None
    fmt = _paper_format(qp_info)
    if fmt == "MCQ":
        return MCQMarkSchemeStrategy()
    if fmt in ("PRACTICAL", "ATP"):
        if _supports_practical_structured(qp_info):
            return StructuredMarkSchemeStrategy()
        raise StrategyUnsupported(
            f"REVIEW_REQUIRED: mark-scheme strategy refused for format={fmt} "
            f"and syllabus {getattr(qp_info, 'syllabus_code', '?')} — no validated profile")
    if fmt == "ESSAY":
        raise StrategyUnsupported(
            "REVIEW_REQUIRED: essay/rubric mark scheme has no validated strategy")
    return StructuredMarkSchemeStrategy()


def select_er_strategy(er_info) -> ExaminerReportStrategy:
    return ExaminerReportStrategy()


def strategy_plan_for_paper(paper_info) -> StrategyPlan:
    """Audit-friendly description used by proof manifests and --dry-run."""
    fmt = _paper_format(paper_info)
    code = getattr(paper_info, "syllabus_code", "?")
    variant = getattr(paper_info, "variant", "?")
    try:
        qp = select_qp_strategy(paper_info)
        qp_name = qp.name
    except StrategyUnsupported as exc:
        return StrategyPlan("review_required", "unsupported",
                            f"{code} v{variant} format={fmt}: {exc.review_reason}")
    if fmt == "MCQ":
        return StrategyPlan(f"{qp_name}+mcq_ms_grid", "qp_mcq",
                            f"{code} v{variant}: MCQ per profile table "
                            f"(paper_identifier) -> question crops + grid letters; "
                            f"no MS WebP by design")
    if fmt in ("PRACTICAL", "ATP") and _supports_practical_structured(paper_info):
        return StrategyPlan(
            f"{qp_name}+structured_ms_gold(legacy-fallback)", "qp_structured",
            f"{code} v{variant}: IGCSE science {fmt} -> validated numbered "
            "structured QP/MS splitters; no MCQ or essay fallback"
        )
    return StrategyPlan(f"{qp_name}+structured_ms_gold(legacy-fallback)", "qp_structured",
                        f"{code} v{variant}: STRUCTURED per profile table -> gold "
                        f"splitters, portrait-era fallback allowed only on 1..N proof")
