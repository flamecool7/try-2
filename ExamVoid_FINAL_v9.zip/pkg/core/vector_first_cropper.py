#!/usr/bin/env python3
"""Confidence-gated Cambridge PDF question cropper.

This is a standalone replacement prototype for the crop stage.  It deliberately
fails closed: it never invents questions when detection is uncertain.  It uses
PDF text/vector geometry before rasterisation, renders only the final clip, and
keeps all page segments for multi-page questions.

Supported proof paths:
* QP: top-level question detection for text-backed Cambridge PDFs.
* MS/ER: conservative question-label analysis for pairing/coverage evidence.

This module is not a claim that one heuristic can perfectly crop every future
Cambridge layout.  Unsupported or ambiguous layouts are reported as REVIEW.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Optional

import fitz  # PyMuPDF
import numpy as np
from PIL import Image

TARGET_WIDTH = 2280
WEBP_MAX_DIM = 16383
DEFAULT_TOP_GUARD_PT = 12.0
DEFAULT_BOUNDARY_GAP_PT = 5.0
BODY_TOP_PT = 60.0
BODY_BOTTOM_FRACTION = 0.94
BODY_SIDE_MARGIN_PT = 24.0

PAPER_RE = re.compile(
    r"(?P<code>\d{4})[_-](?P<season>[msw])(?P<yy>\d{2})[_-]"
    r"(?P<kind>qp|ms|er)(?:[_-](?P<variant>\d{1,3}))?",
    re.IGNORECASE,
)
HEADER_CODE_RE = re.compile(r"\b(?P<code>\d{4})\s*/\s*(?P<component>\d{1,3})\b")
QP_MARKER_RE = re.compile(
    r"^\s*(?:(?:question|q)\s*)?(?P<number>\d{1,3})"
    r"(?:(?:[.)])|(?=\s)|$)(?P<rest>.*)$",
    re.IGNORECASE,
)
MS_LABEL_RE = re.compile(
    r"^\s*(?P<number>\d{1,3})(?:\s*\([a-zivx]{1,4}\))?"
    r"(?:\s*\([a-zivx]{1,4}\))?\s*(?P<rest>.*)$",
    re.IGNORECASE,
)
ER_QUESTION_RE = re.compile(r"^\s*question\s+(?P<number>\d{1,3})\b", re.IGNORECASE)


@dataclass(frozen=True)
class PaperIdentity:
    path: str
    code: str
    season: str
    year: str
    kind: str
    variant: str = ""

    @property
    def paper_key(self) -> str:
        return f"{self.code}_{self.season}{self.year[-2:]}_{self.variant}"


@dataclass(frozen=True)
class TextLine:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def width(self) -> float:
        return self.x1 - self.x0


@dataclass(frozen=True)
class Marker:
    number: int
    page: int
    y0: float
    y1: float
    x0: float
    text: str
    score: float
    reason: str


@dataclass
class Segment:
    page: int
    y0: float
    y1: float


@dataclass
class CropResult:
    number: int
    image_paths: list[str]
    pages: list[int]
    marker_text: str
    confidence: float
    status: str
    text_chars: int
    text: str = ""
    ink_fraction: float = 0.0
    width: int = 0
    height: int = 0
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DocumentAnalysis:
    identity: PaperIdentity
    page_count: int
    page_text_chars: list[int]
    markers: list[Marker]
    selected_numbers: list[int]
    warnings: list[str]
    elapsed_ms: float

    def to_dict(self) -> dict:
        data = asdict(self)
        data["identity"] = asdict(self.identity)
        data["markers"] = [asdict(marker) for marker in self.markers]
        return data


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_identity(path: Path) -> PaperIdentity:
    match = PAPER_RE.search(path.stem)
    if not match:
        raise ValueError(f"Cannot parse Cambridge paper identity from {path.name}")
    yy = int(match.group("yy"))
    year = str(2000 + yy if yy < 50 else 1900 + yy)
    return PaperIdentity(
        path=str(path),
        code=match.group("code"),
        season=match.group("season").lower(),
        year=year,
        kind=match.group("kind").lower(),
        variant=match.group("variant") or "",
    )


def lines_from_page(page: fitz.Page) -> list[TextLine]:
    lines: list[TextLine] = []
    data = page.get_text("dict")
    for block in data.get("blocks", []):
        if block.get("type") != 0:
            continue
        for raw_line in block.get("lines", []):
            spans = raw_line.get("spans", [])
            if not spans:
                continue
            text = "".join(str(span.get("text", "")) for span in spans).strip()
            if not text:
                continue
            x0 = min(float(span["bbox"][0]) for span in spans)
            y0 = min(float(span["bbox"][1]) for span in spans)
            x1 = max(float(span["bbox"][2]) for span in spans)
            y1 = max(float(span["bbox"][3]) for span in spans)
            lines.append(TextLine(text=text, x0=x0, y0=y0, x1=x1, y1=y1))
    return sorted(lines, key=lambda line: (line.y0, line.x0))


def _looks_like_header_or_footer(line: TextLine, page: fitz.Page) -> bool:
    text = line.text.lower()
    h = float(page.rect.height)
    if line.y1 < h * 0.055:
        return True
    if line.y0 > h * 0.955:
        return True
    if "turn over" in text or "do not write" in text:
        return True
    if "©" in line.text or "uc les" in text or "ucles" in text:
        return True
    if re.search(r"\b\d{4}/\d{1,3}/[a-z]/[a-z]/\d{2}\b", text):
        return True
    if re.search(r"\bpage\s+\d+\s+of\s+\d+\b", text):
        return True
    return False


def _next_line(lines: list[TextLine], index: int) -> Optional[TextLine]:
    return lines[index + 1] if index + 1 < len(lines) else None


def _qp_candidate(line: TextLine, page: fitz.Page, lines: list[TextLine], index: int) -> Optional[Marker]:
    match = QP_MARKER_RE.match(line.text)
    if not match or _looks_like_header_or_footer(line, page):
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None

    # Cambridge QP top-level labels are normally in the left body margin.
    # This excludes page headers, tables and answer options in the right body.
    relative_x = line.x0 / max(1.0, float(page.rect.width))
    if relative_x > 0.20:
        return None
    rest = match.group("rest").strip()
    next_line = _next_line(lines, index)
    next_text = next_line.text if next_line else ""

    # A line containing only a number is often followed by a formula/diagram
    # block before the prose question stem.  Look ahead a few lines, but only
    # accept a number-only marker when it is genuinely in the far-left margin.
    lookahead = " ".join(line.text for line in lines[index + 1:index + 10])
    nearby_text = f"{next_text} {lookahead}"
    has_prose = bool(re.search(r"[A-Za-z]", rest)) or bool(re.search(r"[A-Za-z]", nearby_text))
    if not has_prose:
        return None
    if not rest and relative_x > 0.15:
        return None
    if rest and re.fullmatch(r"[\d\s.,:+\-/%]+", rest):
        return None

    score = 1.0
    reason = "left-margin marker with nearby prose"
    if relative_x <= 0.12:
        score += 0.15
    if re.match(r"^(?:question|q)", line.text, re.IGNORECASE):
        score += 0.20
        reason = "explicit question marker"
    if not rest:
        score -= 0.05
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, score, reason)


def _ms_candidate(line: TextLine, page: fitz.Page, lines: list[TextLine], index: int) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    match = MS_LABEL_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None
    relative_x = line.x0 / max(1.0, float(page.rect.width))
    if relative_x > 0.24:
        return None
    # Mark-scheme labels are often at the left of the answer table.  Avoid
    # generic principles and arithmetic rows by requiring either a subpart,
    # explicit question wording, or a line at a table/question-column position.
    rest = match.group("rest").strip()
    has_subpart = bool(re.match(r"^\s*\d+\s*\(", line.text))
    next_line = _next_line(lines, index)
    nearby = (rest + " " + (next_line.text if next_line else "")).lower()
    if not has_subpart and not re.search(r"[A-Za-z]", nearby) and not re.search(r"\b[abcd]\b", nearby):
        return None
    score = 0.65 + (0.15 if has_subpart else 0.0)
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, score, "mark-scheme label")


def _er_candidate(line: TextLine, page: fitz.Page) -> Optional[Marker]:
    if _looks_like_header_or_footer(line, page):
        return None
    match = ER_QUESTION_RE.match(line.text)
    if not match:
        return None
    number = int(match.group("number"))
    if number < 1 or number > 150:
        return None
    return Marker(number, -1, line.y0, line.y1, line.x0, line.text, 0.85, "explicit examiner-report heading")


def raw_markers(doc: fitz.Document, kind: str) -> tuple[list[Marker], list[int]]:
    markers: list[Marker] = []
    page_text_chars: list[int] = []
    for page_index, page in enumerate(doc):
        lines = lines_from_page(page)
        page_text_chars.append(sum(len(line.text) for line in lines))
        for index, line in enumerate(lines):
            if kind == "qp":
                candidate = _qp_candidate(line, page, lines, index)
            elif kind == "ms":
                candidate = _ms_candidate(line, page, lines, index)
            else:
                candidate = _er_candidate(line, page)
            if candidate is not None:
                markers.append(
                    Marker(
                        number=candidate.number,
                        page=page_index,
                        y0=candidate.y0,
                        y1=candidate.y1,
                        x0=candidate.x0,
                        text=candidate.text,
                        score=candidate.score,
                        reason=candidate.reason,
                    )
                )
    return markers, page_text_chars


def select_qp_sequence(markers: list[Marker]) -> list[Marker]:
    """Select the strongest contiguous 1..N QP sequence.

    Cambridge QPs are sequential at top level.  This rejects page numbers,
    table values and repeated decorative labels without guessing across gaps.
    """
    if not markers:
        return []
    by_number: dict[int, list[Marker]] = {}
    for marker in markers:
        by_number.setdefault(marker.number, []).append(marker)
    for values in by_number.values():
        values.sort(key=lambda marker: (marker.page, marker.y0, -marker.score))

    firsts = by_number.get(1, [])
    if not firsts:
        return []
    best: list[Marker] = []
    for first in firsts:
        sequence = [first]
        cursor = (first.page, first.y0)
        expected = 2
        while expected in by_number:
            candidates = [
                marker for marker in by_number[expected]
                if (marker.page, marker.y0) > cursor
            ]
            if not candidates:
                break
            # Document order is the primary signal.  Answer-option numbers
            # later in the paper can have a slightly higher local score than
            # the true top-level label (e.g. an option row ``4 N`` after Q4),
            # and choosing by score can jump past Q5 and create one enormous
            # final crop.  Pick the earliest valid marker; score only breaks
            # an exact-coordinate tie.
            chosen = min(candidates, key=lambda marker: (marker.page, marker.y0, -marker.score))
            sequence.append(chosen)
            cursor = (chosen.page, chosen.y0)
            expected += 1
        if len(sequence) > len(best):
            best = sequence
        elif len(sequence) == len(best) and sequence and sum(x.score for x in sequence) > sum(x.score for x in best):
            best = sequence
    return best


def select_label_sequence(markers: list[Marker]) -> list[Marker]:
    """Conservative MS/ER sequence selection; deduplicate repeated labels."""
    if not markers:
        return []
    # Keep the first occurrence of each question number in document order.
    selected: list[Marker] = []
    seen: set[int] = set()
    for marker in sorted(markers, key=lambda value: (value.page, value.y0)):
        if marker.number in seen:
            continue
        seen.add(marker.number)
        selected.append(marker)
    return selected


def detect_markers(doc: fitz.Document, kind: str) -> tuple[list[Marker], list[int], list[str]]:
    markers, page_text_chars = raw_markers(doc, kind)
    warnings: list[str] = []
    if kind == "qp":
        selected = select_qp_sequence(markers)
        if not selected:
            warnings.append("No contiguous top-level QP sequence beginning at Q1 was found")
        elif len(selected) < 2:
            warnings.append("Only one QP marker found; review required")
        all_numbers = [marker.number for marker in selected]
    else:
        selected_markers = select_label_sequence(markers)
        all_numbers = [marker.number for marker in selected_markers]
        if not selected_markers:
            warnings.append(f"No conservative {kind.upper()} question labels found")
        selected = selected_markers
    return selected, page_text_chars, warnings


def page_body_bottom(page: fitz.Page) -> float:
    h = float(page.rect.height)
    bottom = h * BODY_BOTTOM_FRACTION
    # Cambridge PDFs often contain imposition barcodes/gibberish text just
    # above the printed footer.  Detect that vector text and end before it;
    # this is safer than painting pixels after the crop has been made.
    try:
        for word in page.get_text("words"):
            x0, y0, x1, y1, text, *_ = word
            if y0 < h * 0.82:
                continue
            value = str(text or "")
            alnum = sum(char.isalnum() for char in value)
            ascii_count = sum(ord(char) < 128 for char in value)
            unusual = len(value) >= 8 and (
                alnum / max(1, len(value)) < 0.55
                or ascii_count / max(1, len(value)) < 0.70
            )
            footerish = "turn over" in value.lower() or value in {"©", "UCLES"}
            if unusual:
                bottom = min(bottom, float(y0) - 4.0)
            elif footerish:
                bottom = min(bottom, float(y0) - 2.0)
    except Exception:
        pass
    return max(h * 0.78, bottom)


def page_clip_bounds(page: fitz.Page) -> tuple[float, float]:
    """Remove the printed do-not-write margin strips before rasterisation."""
    width = float(page.rect.width)
    left = BODY_SIDE_MARGIN_PT
    right = max(left + 10.0, width - BODY_SIDE_MARGIN_PT)
    try:
        words = page.get_text("words")
        left_margin = any(float(word[0]) < width * 0.08 and "margin" in str(word[4]).lower() for word in words)
        right_margin = any(float(word[0]) > width * 0.92 and "margin" in str(word[4]).lower() for word in words)
        if left_margin:
            left = max(left, width * 0.04)
        if right_margin:
            right = min(right, width - width * 0.04)
    except Exception:
        pass
    return left, right


def segment_for_marker(doc: fitz.Document, marker: Marker, next_marker: Optional[Marker]) -> list[Segment]:
    segments: list[Segment] = []
    start_page = marker.page
    start_y = max(0.0, marker.y0 - DEFAULT_TOP_GUARD_PT)
    if next_marker is not None:
        # If the next question begins immediately at the top of a new page,
        # the preceding question ended on the previous page.  Do not create a
        # useless header-only segment containing the printed page number.
        starts_new_page = (
            next_marker.page > marker.page
            and next_marker.y0 <= BODY_TOP_PT + 25.0
        )
        if starts_new_page:
            end_page = next_marker.page - 1
            end_y = page_body_bottom(doc[end_page])
        else:
            end_page = next_marker.page
            end_y = max(start_y + 2.0, next_marker.y0 - DEFAULT_BOUNDARY_GAP_PT)
    else:
        end_page = len(doc) - 1
        end_y = page_body_bottom(doc[end_page])

    for page_index in range(start_page, end_page + 1):
        page = doc[page_index]
        y0 = start_y if page_index == start_page else BODY_TOP_PT
        y1 = end_y if page_index == end_page else page_body_bottom(page)
        y0 = max(0.0, min(y0, float(page.rect.height)))
        y1 = max(y0 + 2.0, min(y1, float(page.rect.height)))
        segments.append(Segment(page=page_index, y0=y0, y1=y1))
    return segments


def render_clip(page: fitz.Page, y0: float, y1: float) -> Image.Image:
    x0, x1 = page_clip_bounds(page)
    rect = fitz.Rect(x0, y0, x1, y1)
    scale = TARGET_WIDTH / max(1.0, x1 - x0)
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=rect, alpha=False)
    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    if image.width != TARGET_WIDTH:
        image = image.resize(
            (TARGET_WIDTH, max(1, round(image.height * TARGET_WIDTH / image.width))),
            Image.Resampling.LANCZOS,
        )
    return image


def trim_vertical_white(image: Image.Image, pad: int = 16) -> Image.Image:
    gray = np.asarray(image.convert("L"))
    ink = gray < 248
    rows = np.flatnonzero(ink.any(axis=1))
    if rows.size == 0:
        return image

    # Registration bars and rotated margin warnings can form a short, dense
    # ink run right at a page clip's top edge.  A real text line at this scale
    # is taller and is followed by content without a large blank gap.  Remove
    # only the very specific short-run pattern; otherwise keep all ink.
    dark = gray < 200
    row_counts = dark.sum(axis=1)
    active = row_counts > max(3, int(image.width * 0.0008))
    runs: list[tuple[int, int]] = []
    index = 0
    while index < len(active):
        if not active[index]:
            index += 1
            continue
        end = index
        while end < len(active) and active[end]:
            end += 1
        runs.append((index, end - 1))
        index = end
    trim_top = int(rows[0])
    if len(runs) >= 2:
        first_start, first_end = runs[0]
        second_start, _second_end = runs[1]
        first_height = first_end - first_start + 1
        gap = second_start - first_end - 1
        first_density = float(row_counts[first_start:first_end + 1].mean()) / max(1, image.width)
        if first_start <= 1 and first_height <= 40 and gap >= 8 and first_density >= 0.08:
            trim_top = second_start
    top = max(0, trim_top - pad)
    bottom = min(image.height, int(rows[-1]) + pad + 1)
    if bottom <= top:
        return image
    return image.crop((0, top, image.width, bottom))


def stitch(parts: list[Image.Image], gap: int = 18) -> Image.Image:
    if not parts:
        raise ValueError("Cannot stitch zero image segments")
    width = max(image.width for image in parts)
    normalised: list[Image.Image] = []
    for image in parts:
        if image.width != width:
            image = image.resize((width, max(1, round(image.height * width / image.width))), Image.Resampling.LANCZOS)
        normalised.append(image)
    height = sum(image.height for image in normalised) + gap * (len(normalised) - 1)
    canvas = Image.new("RGB", (width, height), "white")
    y = 0
    for index, image in enumerate(normalised):
        canvas.paste(image, (0, y))
        y += image.height
        if index + 1 < len(normalised):
            y += gap
    return canvas


def save_webp_tiled(image: Image.Image, destination: Path, quality: int = 92) -> list[Path]:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if image.width > WEBP_MAX_DIM:
        raise ValueError(f"Crop width {image.width} exceeds WebP maximum")
    stride = WEBP_MAX_DIM - 32
    paths: list[Path] = []
    y = 0
    part = 1
    while y < image.height:
        y1 = min(image.height, y + stride)
        tile = image.crop((0, y, image.width, y1))
        path = destination if part == 1 else destination.with_name(f"{destination.stem}_part{part}{destination.suffix}")
        tile.save(path, format="WEBP", quality=quality, method=4)
        paths.append(path)
        y = y1
        part += 1
    return paths


def image_ink_fraction(image: Image.Image) -> float:
    gray = np.asarray(image.convert("L"))
    return float((gray < 245).mean())


def extract_text_for_segment(page: fitz.Page, y0: float, y1: float) -> str:
    return (page.get_text("text", clip=fitz.Rect(0, y0, page.rect.width, y1)) or "").strip()


class CambridgeCropper:
    def __init__(self, output_root: Path, quality: int = 92):
        self.output_root = Path(output_root)
        self.quality = quality

    def analyze(self, pdf_path: Path, kind: Optional[str] = None) -> DocumentAnalysis:
        started = time.perf_counter()
        identity = parse_identity(pdf_path)
        if kind:
            identity = PaperIdentity(identity.path, identity.code, identity.season, identity.year, kind, identity.variant)
        with fitz.open(pdf_path) as doc:
            markers, page_text_chars, warnings = detect_markers(doc, identity.kind)
            selected_numbers = [marker.number for marker in markers]
            page_count = len(doc)
        return DocumentAnalysis(
            identity=identity,
            page_count=page_count,
            page_text_chars=page_text_chars,
            markers=markers,
            selected_numbers=selected_numbers,
            warnings=warnings,
            elapsed_ms=round((time.perf_counter() - started) * 1000, 2),
        )

    def crop_qp(self, pdf_path: Path) -> tuple[DocumentAnalysis, list[CropResult]]:
        analysis = self.analyze(pdf_path, kind="qp")
        started = time.perf_counter()
        results: list[CropResult] = []
        with fitz.open(pdf_path) as doc:
            markers = analysis.markers
            paper_dir = self.output_root / f"{analysis.identity.code}_{analysis.identity.season}{analysis.identity.year[-2:]}_{analysis.identity.variant}"
            for index, marker in enumerate(markers):
                next_marker = markers[index + 1] if index + 1 < len(markers) else None
                segments = segment_for_marker(doc, marker, next_marker)
                images: list[Image.Image] = []
                pages: list[int] = []
                text_parts: list[str] = []
                for segment in segments:
                    image = render_clip(doc[segment.page], segment.y0, segment.y1)
                    image = trim_vertical_white(image)
                    images.append(image)
                    pages.append(segment.page + 1)
                    text_parts.append(extract_text_for_segment(doc[segment.page], segment.y0, segment.y1))
                assembled = stitch(images)
                destination = paper_dir / f"Q{marker.number}.webp"
                paths = save_webp_tiled(assembled, destination, quality=self.quality)
                ink = image_ink_fraction(assembled)
                confidence = min(1.0, marker.score / 1.35)
                warnings: list[str] = []
                if len(segments) > 1:
                    warnings.append(f"multi-page question: {len(segments)} segments")
                if assembled.height < 80:
                    warnings.append("crop height is unusually small")
                if ink < 0.0005:
                    warnings.append("crop has very little ink")
                if not text_parts or not "".join(text_parts).strip():
                    warnings.append("no extractable text in crop")
                status = "PASS" if confidence >= 0.70 and ink >= 0.0005 and text_parts else "REVIEW"
                results.append(
                    CropResult(
                        number=marker.number,
                        image_paths=[str(path) for path in paths],
                        pages=pages,
                        marker_text=marker.text,
                        confidence=round(confidence, 3),
                        status=status,
                        text_chars=len(" ".join(text_parts)),
                        text="\n".join(text_parts),
                        ink_fraction=round(ink, 6),
                        width=assembled.width,
                        height=assembled.height,
                        warnings=warnings,
                    )
                )
        return analysis, results

    def analyze_non_qp(self, pdf_path: Path) -> DocumentAnalysis:
        return self.analyze(pdf_path, kind=parse_identity(pdf_path).kind)


def write_manifest(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def validate_crop_files(results: Iterable[CropResult]) -> list[str]:
    errors: list[str] = []
    for result in results:
        if result.status not in {"PASS", "REVIEW"}:
            errors.append(f"Q{result.number}: invalid status {result.status}")
        if result.width != TARGET_WIDTH:
            errors.append(f"Q{result.number}: width={result.width}, expected {TARGET_WIDTH}")
        if not result.image_paths:
            errors.append(f"Q{result.number}: no image files")
        for raw_path in result.image_paths:
            path = Path(raw_path)
            if not path.exists():
                errors.append(f"Q{result.number}: missing {path}")
                continue
            try:
                with Image.open(path) as image:
                    image.verify()
                with Image.open(path) as image:
                    if image.width != TARGET_WIDTH:
                        errors.append(f"Q{result.number}: {path.name} width={image.width}")
            except Exception as exc:
                errors.append(f"Q{result.number}: invalid image {path}: {exc}")
    return errors


def main() -> int:
    parser = __import__("argparse").ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--kind", choices=["qp", "ms", "er"], default=None)
    parser.add_argument("--output", type=Path, default=Path("crop_output"))
    parser.add_argument("--manifest", type=Path, default=None)
    args = parser.parse_args()
    cropper = CambridgeCropper(args.output)
    identity = parse_identity(args.pdf)
    if (args.kind or identity.kind) == "qp":
        analysis, results = cropper.crop_qp(args.pdf)
        errors = validate_crop_files(results)
        payload = {
            "tool": "cambridge_cropper",
            "source": str(args.pdf),
            "source_sha256": sha256_file(args.pdf),
            "analysis": analysis.to_dict(),
            "crops": [result.to_dict() for result in results],
            "validation_errors": errors,
            "passed": not errors and bool(results),
        }
    else:
        analysis = cropper.analyze_non_qp(args.pdf)
        payload = {
            "tool": "cambridge_cropper",
            "source": str(args.pdf),
            "source_sha256": sha256_file(args.pdf),
            "analysis": analysis.to_dict(),
            "validation_errors": [],
            "passed": bool(analysis.selected_numbers),
        }
    manifest = args.manifest or args.output / "manifest.json"
    write_manifest(manifest, payload)
    print(json.dumps(payload, indent=2))
    return 0 if payload["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
