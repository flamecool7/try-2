"""
Legacy portrait-era structured mark-scheme splitter (RS-16 subject coverage).

WHY THIS EXISTS
---------------
The LOCKED gold MS splitter (core/markscheme_split_gold.py, called by the
never-touch core/ms_cropping_engine.py b69285ee…) was built on the structure
of nine official **2025** mark schemes: landscape pages whose
"Question | Answer | Marks" header band is bounded by two long horizontal
rules. Cambridge's **portrait-era** AS/A-Level mark schemes (observed on the
s15 fixtures for 9700 / 9701 / 9702 / 9709) use a different printed grammar:
portrait pages, a "Question | Mark Scheme | Mark | Total" four-column table,
question markers like "1" / "2" in a narrow first column, sub-part rows
"(a)", "(b)(i)" in the SAME column, and no long header-rule pair. The gold
engine correctly finds zero structural boxes there and fails closed.

This module is the additive era-twin: it NEVER replaces the gold path (the
caller tries gold first and only falls here when gold returns nothing), it
never fabricates a boundary it cannot ground in the printed marker column,
and — decisive — it VALIDATES its split against the top-level question
numbers already proven out of the question paper by the locked QP splitter
(expected_top_numbers). If reality disagrees with the paper, it returns
nothing and the run keeps its old fail-closed behaviour.

GEOMETRY CONTRACT (same as gold): returns one header-free upright PIL image
per top-level question, merged across page turns, tight-cropped to the
surrounding table border when one is detectable (gold-crop, same helper,
with the same loud fallback to the unboxed image).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .pdf_io import render_pdf_with_rotation_info, _upright_bbox

# first column of the legacy table holds markers like:
#   1        (top-level start)
#   2 (a)    (top-level + first sub-part, same row)
# sub-part-only rows ((a), (b)(i), (ii)…) carry no bare number and can never
# open a new block. Bare page numbers are excluded by the column-x band and
# the footer band (detect_header_y/detect_footer_y from the locked pdf_io).
_NUM_WORD = re.compile(r"^\(?(\d{1,2})\)?\s*(\(([a-z]|[ivx]+)(\(([ivx]+)\))?)?\)?$")
_HEADER_VOCAB = ("mark scheme",)
_MARKS_COL_HINTS = ("mark", "total", "marks")
_QCOL_HINT = re.compile(r"^question$", re.I)

PAD_TOP_PT = 4.0   # headroom above a marker's own glyph box
# top-level markers sit in the left third of the content area in every
# portrait-era layout observed (9700/9701/9702 tables, 9709 margin numbers)
BAND_X_LO = 0.04
BAND_X_HI = 0.32


@dataclass
class LegacySplitDiagnostics:
    markers_found: List[int] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    split_notes: List[str] = field(default_factory=list)
    valid: bool = False


def _page_words_upright(page) -> List[Tuple[str, float, float, float, float]]:
    out = []
    for raw in page.get_text("words"):
        x0, y0, x1, y1, text, *_ = raw
        t = (text or "").strip()
        if not t:
            continue
        (ux0, uy0), (ux1, uy1) = _upright_bbox(x0, y0, x1, y1, page)
        out.append((t, ux0, uy0, ux1, uy1))
    return out


def _vocab_ok(doc) -> bool:
    blob = " ".join((pg.get_text("text") or "").lower() for pg in doc)
    return any(v in blob for v in _HEADER_VOCAB)


_STRIP_WORDS = {"mark", "scheme", "syllabus", "paper", "cambridge", "international"}


def _band_top(page) -> float:
    """Content top for a portrait-era MS page.

    pdf_io.detect_header_y keys on footer/turn-over signs and returns 0 for
    these top syllabus strips, so add the era-specific rule: the line(s)
    carrying mark/scheme/syllabus/paper/cambridge tokens in the top 14% of
    the page (plus anything above them, e.g. a watermark slug) are running
    header, never question content.
    """
    from .pdf_io import detect_header_y
    lo = detect_header_y(page)
    H = float(page.rect.height)
    if H <= 0:
        return lo
    strip_bottom = None
    for raw in page.get_text("words"):
        x0, y0, x1, y1, text, *_ = raw
        t = (text or "").strip().lower().strip("|")
        if not t or y0 > 0.14 * H:
            continue
        # NOTE: no bare-digit clause — a continuation page's top content row
        # can begin with a number INSIDE the 14% zone and must survive.
        if t in _STRIP_WORDS or "dynamicpapers" in t:
            strip_bottom = y1 if strip_bottom is None else max(strip_bottom, y1)
    if strip_bottom is not None:
        lo = max(lo, strip_bottom + 2.0)
    return lo


def _digit_span_candidates(doc) -> List[dict]:
    """Every left-band span that could be a marker, with its type signature."""
    from .pdf_io import detect_footer_y, detect_header_y
    out = []
    for pi, page in enumerate(doc):
        if pi == 0 and len(doc) > 2:
            continue  # cover page
        rect = page.rect
        top = detect_header_y(page)
        bottom = detect_footer_y(page)
        for blk in page.get_text("dict")["blocks"]:
            for ln in blk.get("lines", []):
                for sp in ln.get("spans", []):
                    t = (sp.get("text") or "").strip()
                    if len(t) > 6 or not any(c.isdigit() for c in t):
                        continue
                    if not _NUM_WORD.match(t):
                        continue
                    x0, y0, x1, y1 = sp["bbox"]
                    if not (BAND_X_LO * rect.width <= x0 <= BAND_X_HI * rect.width):
                        continue
                    if y1 < top - 2 or y0 > bottom + 2:
                        continue
                    out.append({"q": int(_NUM_WORD.match(t).group(1)), "pi": pi,
                                "y0": y0, "x0": x0,
                                "size": round(float(sp.get("size", 0)), 1),
                                "font": sp.get("font", "")})
    out.sort(key=lambda c: (c["pi"], c["y0"]))
    return out


def _collect_markers(doc):
    """Pick the ONE (font, size, x0-tight-cluster) signature whose tokens form
    a strict 1..N run. Equation digits share neither the marker font nor its
    x0 in the observed grammars; a signature that fails the run test loses.
    Returns (markers, warnings, signature-note)."""
    cands = _digit_span_candidates(doc)
    if not cands:
        return [], ["no left-band digit candidates at all"], ""
    groups = {}
    for c in cands:
        groups.setdefault((c["font"], c["size"]), []).append(c)
    best = None
    for (font, size), items in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        first1 = next((c for c in items if c["q"] == 1), None)
        if first1 is None:
            continue
        xc = first1["x0"]
        tight = [c for c in items if abs(c["x0"] - xc) <= 6.0]
        ded = []
        for c in tight:
            if not ded or c["q"] != ded[-1]["q"]:
                ded.append(c)
        seq = [c["q"] for c in ded]
        if seq == list(range(1, len(seq) + 1)) and len(seq) >= 1:
            cand = (len(seq), ded, f"font={font} size={size} x0≈{xc:.1f}")
            if best is None or cand[0] > best[0]:
                best = cand
    if best is None:
        seqs = [[c["q"] for c in v] for v in groups.values()]
        longest = max(seqs, key=len)
        return [], [f"no (font,size,x0) signature forms a strict 1..N run "
                    f"(longest group: {longest[:14]}…)"], ""
    markers = [(c["q"], c["pi"], c["y0"]) for c in best[1]]
    return markers, [], f"marker signature: {best[2]}"


def split_legacy_portrait_ms(pdf_path, *, dpi: int = 150,
                             expected_top_numbers: Optional[List[int]] = None,
                             ) -> Tuple[Dict[int, "Image.Image"], LegacySplitDiagnostics]:
    """Split a portrait-era structured MS into per-question header-free images.

    Returns ({}, diagnostics) — never guesses — when the document is not the
    legacy layout, when no marker column exists, when the marker sequence is
    not a clean 1..N run, or when the QP-proven expectation disagrees.
    """
    from PIL import Image  # pillow
    diag = LegacySplitDiagnostics()
    images, scale, _rots, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    try:
        images = [im.convert("RGB") for im in images]
        if not _vocab_ok(doc):
            diag.warnings.append("no legacy header vocabulary ('mark scheme') — not a legacy MS")
            return {}, diag
        markers, warns, sig_note = _collect_markers(doc)
        diag.warnings.extend(warns)
        if not markers:
            diag.warnings.append("no strict marker run found (see signature note) — refusing to split")
            return {}, diag
        diag.split_notes.append(sig_note)
        seq = [q for q, _pi, _y in markers]
        if seq != list(range(1, len(seq) + 1)):
            diag.warnings.append(f"marker sequence {seq[:12]} is not a strict 1..{len(seq)} run")
            return {}, diag
        diag.markers_found = seq
        if expected_top_numbers:
            want = sorted(set(int(n) for n in expected_top_numbers))
            if want != seq:
                diag.warnings.append(
                    f"legacy split {seq} != QP-proven top-level questions {want} — refusing")
                return {}, diag

        # block boundaries: marker row top .. next marker row top (y in pt,
        # mapped through render scale), continuing across page turns; the last
        # question runs to its page's content bottom. EVERY page slice is
        # banded by the running-header / footer bands (portrait-era pages put
        # the syllabus strip on top and the ©/turn-over line at the bottom;
        # they are never question content).
        from .pdf_io import detect_footer_y, detect_header_y
        bounds: List[Tuple[int, int, float]] = list(markers)
        last_q, last_pi, _ = markers[-1]
        bounds.append((0, last_pi, detect_footer_y(doc[last_pi])))
        diag.valid = True

        pieces: Dict[int, List["Image.Image"]] = {q: [] for q in seq}
        for idx in range(len(bounds) - 1):
            q, pi, y0 = bounds[idx]
            _qn, pj, y1 = bounds[idx + 1]
            for p in range(pi, pj + 1):
                img = images[p]
                pg = doc[p]
                lo_pt = _band_top(pg)               # running-header band bottom
                hi_pt = detect_footer_y(pg)         # footer band top
                if p == pi:
                    lo_pt = max(lo_pt, y0 - PAD_TOP_PT)
                if p == pj:
                    hi_pt = min(hi_pt, y1)
                y_top = int(round(lo_pt * scale))
                y_bot = int(round(min(pg.rect.height, hi_pt) * scale))
                if y_bot - y_top < 8:
                    continue
                pieces[q].append(img.crop((0, y_top, img.width, y_bot)))
                diag.split_notes.append(f"Q{q}: page {p + 1} rows {y_top}:{y_bot}px")
        out: Dict[int, "Image.Image"] = {}
        for q in seq:
            chunks = pieces[q]
            if not chunks:
                diag.warnings.append(f"Q{q}: no pixels assembled")
                return {}, LegacySplitDiagnostics(warnings=diag.warnings)
            if len(chunks) == 1:
                merged = chunks[0]
            else:
                w = max(c.width for c in chunks)
                h = sum(c.height for c in chunks)
                merged = Image.new("RGB", (w, h), "white")
                y = 0
                for c in chunks:
                    merged.paste(c, (0, y))
                    y += c.height
            out[q] = merged
        # same tight-crop as the gold engine (same helper, same loud fallback):
        # trim whitespace/empty bands around the content rectangle.
        try:
            from .ms_crop_gold import crop_to_mark_box as _box
        except Exception:
            try:
                from cambridge_qb.ms_crop import crop_to_mark_box as _box
            except Exception:
                _box = None
        if _box is not None:
            for q in list(out):
                try:
                    out[q] = _box(out[q], dark_threshold=150, col_threshold=0.45,
                                  gap_tol=12, margin=1)
                except Exception as e:
                    diag.warnings.append(f"Q{q}: tight-crop fallback ({e})")
        return out, diag
    finally:
        doc.close()


def split_portrait_column_ms(pdf_path, *, dpi: int = 150,
                             expected_top_numbers: Optional[List[int]] = None,
                             ) -> Tuple[Dict[int, "Image.Image"], LegacySplitDiagnostics]:
    """Split the older portrait IGCSE table grammar by its printed Q column.

    Some IGCSE Mathematics 0580 mark schemes use a simple ``Question | Answer
    | Mark`` table with no long horizontal rules and no repeated table header on
    continuation pages.  The locked landscape splitter correctly returns only
    the structurally proven first page in that case.  This fallback is allowed
    only when every QP-proven top-level number appears exactly once in the
    narrow printed Question column; it never uses arbitrary page fractions or
    answer-option numbers as boundaries.
    """
    from PIL import Image
    from .pdf_io import detect_footer_y

    diag = LegacySplitDiagnostics()
    images, scale, _rots, doc = render_pdf_with_rotation_info(pdf_path, dpi=dpi)
    try:
        if not _vocab_ok(doc):
            diag.warnings.append("no mark-scheme header vocabulary")
            return {}, diag
        expected = sorted(set(int(n) for n in (expected_top_numbers or [])))
        if not expected:
            diag.warnings.append("QP-proven expected numbers are required")
            return {}, diag

        # The portrait IGCSE grammar puts top-level labels at about x=56 pt;
        # page numbers and table values are in other columns.  Keep exact
        # integer words only, below the running header.
        labels = []
        for pi, page in enumerate(doc):
            width = float(page.rect.width)
            height = float(page.rect.height)
            # This grammar repeats a compact header at roughly 64–70pt;
            # _band_top can mistake the word "mark" in a content row for a
            # continuation header, so cap the header floor for this strict
            # portrait-column mode.
            top = min(_band_top(page), 70.0)
            for raw in page.get_text("words"): 
                x0, y0, x1, y1, text, *_ = raw
                value = str(text or "").strip()
                if not re.fullmatch(r"\d{1,2}", value):
                    continue
                number = int(value)
                if number not in expected:
                    continue
                if x0 > width * 0.13:
                    continue
                if y0 < max(top + 2.0, height * 0.075):
                    continue
                labels.append((number, pi, float(y0)))

        labels.sort(key=lambda item: (item[1], item[2]))
        # Reject duplicates or missing numbers.  This is the fail-closed proof
        # that distinguishes the Question column from a numeric answer row.
        if [q for q, _p, _y in labels] != expected:
            diag.warnings.append(
                f"portrait Question-column labels {[q for q, _p, _y in labels]} "
                f"do not equal QP-proven {expected} — refusing"
            )
            return {}, diag

        diag.markers_found = expected
        diag.valid = True
        pieces: Dict[int, List[Image.Image]] = {q: [] for q in expected}

        for idx, (question, start_page, start_y) in enumerate(labels):
            if idx + 1 < len(labels):
                _next_q, end_page, end_y = labels[idx + 1]
            else:
                end_page = len(doc) - 1
                end_y = detect_footer_y(doc[end_page])
            for page_index in range(start_page, end_page + 1):
                page = doc[page_index]
                image = images[page_index]
                page_top = min(_band_top(page), 70.0)
                page_bottom = detect_footer_y(page)
                if page_bottom <= page_top or page_bottom > float(page.rect.height):
                    page_bottom = float(page.rect.height) - 12.0
                y0 = page_top if page_index != start_page else max(page_top, start_y - PAD_TOP_PT)
                y1 = page_bottom
                if page_index == end_page:
                    y1 = min(y1, end_y)
                top_px = max(0, int(round(y0 * scale)))
                bottom_px = min(image.height, int(round(y1 * scale)))
                if bottom_px - top_px < 8:
                    continue
                pieces[question].append(image.crop((0, top_px, image.width, bottom_px)))
                diag.split_notes.append(
                    f"Q{question}: page {page_index + 1} rows {top_px}:{bottom_px}px"
                )

        out: Dict[int, Image.Image] = {}
        for question in expected:
            chunks = pieces[question]
            if not chunks:
                diag.valid = False
                diag.warnings.append(f"Q{question}: no pixels assembled")
                return {}, diag
            if len(chunks) == 1:
                merged = chunks[0]
            else:
                width = max(chunk.width for chunk in chunks)
                height = sum(chunk.height for chunk in chunks)
                merged = Image.new("RGB", (width, height), "white")
                cursor = 0
                for chunk in chunks:
                    merged.paste(chunk, (0, cursor))
                    cursor += chunk.height
            out[question] = merged

        try:
            from .ms_crop_gold import crop_to_mark_box as _box
        except Exception:
            _box = None
        if _box is not None:
            for question in list(out):
                try:
                    out[question] = _box(
                        out[question], dark_threshold=150,
                        col_threshold=0.45, gap_tol=12, margin=1,
                    )
                except Exception as exc:
                    diag.warnings.append(f"Q{question}: tight-crop fallback ({exc})")
        return out, diag
    finally:
        doc.close()
