"""Quality scoring over a generated output tree (Upgrade 5, 2026-08-10).

Scan a built question bank and report quality per subject. Read-only: this
module never writes, moves, or deletes anything.

Design decisions recorded at build time (maintainer-approved):
  * Difficulty uses core.difficulty.mark_to_difficulty WHEN marks are
    available. Reality found at fact-check: metadata.json does not persist
    marks (schema: board,id,level,paper,question_number,season,subject,topic,
    variant,year), so the difficulty dimension reports UNAVAILABLE loudly
    instead of fabricating a number.
  * topic_scores is a DEAD dimension BY DESIGN — json_generator,
    output_manager and validation all FORBID that field in metadata. It is
    reported as {"status": "dead_dimension"} so callers stop looking for it,
    instead of silently scoring {}.
  * ER dimension is N/A when no ER content exists in the tree; its weight is
    redistributed proportionally across the remaining live dimensions.
  * `*_ER.webp` page renders are full-page report images, not 2280px question
    crops (locked convention, output_manager C3) — they are EXCLUDED from the
    width/integrity scoring and only counted for ER coverage.
  * Subject-path normalisation (final-upgrade Issue 8): "Chemistry",
    "Chemistry_9701", "chemistry 9701", "9701" all resolve against the actual
    output directories with a loud log; unknown or ambiguous queries raise
    loudly — never a silent {}.

Report shape (score_subject):
    {
      "subject": "Biology_9700", "level": "A-Level",
      "question_folders": 12,
      "dimensions": {
         "presence":   {"score": ..., "weight": ..., "failed": [...]},
         "integrity":  {...},              # webp validity + 2280 (non-ER) + json
         "er_coverage": {...} | {"status": "na_redistributed"},
         "difficulty": {"status": "unavailable", "reason": ...},
         "topic_scores": {"status": "dead_dimension", "reason": ...},
      },
      "overall": 0-100,
      "weights": {...resolved...},        # always sums to 1.0
    }
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PIL import Image

TARGET_WIDTH = 2280

# Base weights; when ER content is absent, er_coverage's weight is
# redistributed proportionally across presence/integrity.
_W_PRESENCE = 0.4
_W_INTEGRITY = 0.3
_W_ER = 0.3

_REQUIRED_JSON_FIELDS = ("id", "level", "subject", "board", "topic",
                         "question_number", "variant", "season", "year")
_QFOLDER = re.compile(r"_Q\d+$")


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _subject_dirs(output_root: Path) -> List[Tuple[str, str, Path]]:
    """[(level, subject_dir_name, path)] under IGCSE/ and A-Level/ (or flat)."""
    out = []
    for level_dir in sorted(output_root.iterdir()):
        if not level_dir.is_dir() or level_dir.name.startswith("."):
            continue
        if level_dir.name in ("IGCSE", "A-Level"):
            for sub in sorted(level_dir.iterdir()):
                if sub.is_dir():
                    out.append((level_dir.name, sub.name, sub))
        elif "_" in level_dir.name:
            out.append(("", level_dir.name, level_dir))
    return out


def normalize_subject(output_root: str | Path, subject_query: str) -> Tuple[str, Path]:
    """Resolve a user-ish subject string to (display_name, dir) — loudly.

    Raises LookupError on no match and on ambiguity, listing the actual
    subjects present. Never returns None / {} silently.
    """
    output_root = Path(output_root)
    subjects = _subject_dirs(output_root) if output_root.exists() else []
    q = _norm(subject_query)
    level_hint = ("alevel" if _norm("A-Level") in q or "alevel" in q else
                  "igcse" if "igcse" in q else None)

    matches = []
    for level, name, path in subjects:
        name_n = _norm(name)                                # computerscience9618
        words = _norm(re.sub(r"_\d{4}$", "", name))        # computerscience
        code = name.rsplit("_", 1)[-1].lower()              # 9618
        hit = q in {name_n, words, code} or name_n in q and q or q == words + code
        if hit:
            if level_hint and level and _norm(level) != level_hint:
                continue
            matches.append((level, name, path))

    if not matches:
        # token prefix fallback: split the query into letters + 4-digit code.
        # "chem 0620" -> letters "chem" prefix of "chemistry", code "0620"
        # equal -> unique match resolves (loudly). Code alone ("9700") was
        # already an exact primary hit; code+letters must BOTH agree.
        qa = _norm(re.sub(r"[0-9]", "", subject_query))
        qd_list = re.findall(r"\d{4}", subject_query)
        qd = qd_list[0] if qd_list else ""
        pref = []
        for l, n, pa in subjects:
            words = _norm(re.sub(r"_\d{4}$", "", n))
            code = n.rsplit("_", 1)[-1].lower()
            code_ok = (not qd) or code == qd
            name_ok = words.startswith(qa) if qd else (len(qa) >= 4 and words.startswith(qa))
            if code_ok and name_ok:
                pref.append((l, n, pa))
        pref = [(l, n, pa) for l, n, pa in pref
                if not level_hint or not l or _norm(l) == level_hint]
        if len({n for _, n, _ in pref}) == 1:
            level, name, path = pref[0]
            print(f"[quality_scorer] prefix match {subject_query!r} -> {level}/{name}")
            matches = pref
    if not matches:
        avail = ", ".join(f"{l}/{n}" for l, n, _ in subjects) or "(none)"
        raise LookupError(
            f"[quality_scorer] subject {subject_query!r} not found under {output_root}. "
            f"Available: {avail}")
    if len(matches) > 1:
        choices = "; ".join(f"{l}/{n}" for l, n, _ in matches)
        raise LookupError(
            f"[quality_scorer] subject {subject_query!r} is ambiguous: {choices}. "
            f"Include the level (e.g. 'A-Level Biology_9700').")

    level, name, path = matches[0]
    print(f"[quality_scorer] normalized {subject_query!r} -> {level}/{name} ({path})")
    return (f"{level}/{name}" if level else name), path


def _question_folders(subject_dir: Path) -> List[Path]:
    return sorted(p for p in subject_dir.rglob("*_Q*")
                  if p.is_dir() and _QFOLDER.search(p.name))


def _has_webp_set(folder: Path, stem_suffix: str = "") -> bool:
    """Exists as single file or vertical tiles ({stem}_partN.webp)."""
    for f in folder.glob("*.webp"):
        n = f.name
        if "_ER" in n:
            continue
        if stem_suffix == "":
            if "_MS" not in n:
                return True
        elif n.endswith(f"{stem_suffix}.webp") or re.search(
                rf"{re.escape(stem_suffix)}_part\d+\.webp$", n):
            return True
    return False


def _score_presence(folders: List[Path]) -> Tuple[float, List[str]]:
    failed = []
    for f in folders:
        if not (_has_webp_set(f, "") and _has_webp_set(f, "_MS")
                and (f / "metadata.json").exists()):
            failed.append(str(f))
    return (1.0 - len(failed) / len(folders) if folders else 0.0), failed


def _score_integrity(folders: List[Path]) -> Tuple[float, List[str]]:
    bad = []
    for f in folders:
        for w in f.glob("*.webp"):
            if "_ER" in w.name:
                continue  # full-page report renders: excluded from crop checks
            try:
                with Image.open(w) as im:
                    im.verify()
                with Image.open(w) as im:
                    if im.width != TARGET_WIDTH:
                        bad.append(f"{f.name}/{w.name}: width {im.width}")
            except Exception as e:
                bad.append(f"{f.name}/{w.name}: unreadable ({e})")
        js = f / "metadata.json"
        try:
            data = json.loads(js.read_text(encoding="utf-8"))
            missing = [k for k in _REQUIRED_JSON_FIELDS if k not in data]
            if missing:
                bad.append(f"{f.name}/metadata.json: missing {missing}")
        except Exception as e:
            bad.append(f"{f.name}/metadata.json: unparseable ({e})")
    n_items = sum(len([x for x in f.glob('*.webp') if '_ER' not in x.name]) + 1 for f in folders)
    # 1 - bad/total fuzzy item count (folders with zero files still count once)
    total = max(n_items, len(folders)) or 1
    return (max(0.0, 1.0 - len(bad) / total)), bad


def _score_er(folders: List[Path]) -> Tuple[Optional[float], List[str], bool]:
    covered = [f for f in folders
               if any("ER" in w.name for w in f.glob("*_ER.webp"))
               or (f / "examiner_report.txt").exists()]
    if not covered:
        return None, [], False  # ER genuinely absent -> NA, redistribute
    missing = [str(f) for f in folders if f not in covered]
    return len(covered) / len(folders), missing, True


def _needs_review(folders: List[Path]) -> Dict:
    """RS-3+ (Overseer review_required directive): count review_required question
    folders by reason sentinel. These are included in the score like any other
    folder, but flagged separately for manual review."""
    counts = {"classification_failed": 0, "no_markscheme": 0}
    flagged = []
    for f in folders:
        if f.parent.name != "review_required":
            continue
        reason = "classification_failed"
        try:
            with open(f / "metadata.json", "r") as fh:
                t = json.load(fh).get("topic")
            if isinstance(t, list) and t and t[0] == "review_required_no_ms":
                reason = "no_markscheme"
        except Exception:
            pass
        counts[reason] += 1
        flagged.append(str(f))
    return {
        "review_required_total": len(flagged),
        "no_markscheme": counts["no_markscheme"],
        "classification_failed": counts["classification_failed"],
        "needs_review": len(flagged) > 0,
        "folders": flagged[:20],
    }


def score_subject(output_root: str | Path, subject_query: str) -> Dict:
    output_root = Path(output_root)
    display, sdir = normalize_subject(output_root, subject_query)
    folders = _question_folders(sdir)
    if not folders:
        raise LookupError(f"[quality_scorer] {display} has no question folders under {sdir}")

    presence, presence_failed = _score_presence(folders)
    integrity, integrity_failed = _score_integrity(folders)
    er, er_missing, er_supplied = _score_er(folders)

    weights = {"presence": _W_PRESENCE, "integrity": _W_INTEGRITY}
    dims: Dict[str, Dict] = {
        "presence": {"score": round(presence * 100, 1), "weight": _W_PRESENCE,
                     "failed": presence_failed[:20]},
        "integrity": {"score": round(integrity * 100, 1), "weight": _W_INTEGRITY,
                      "failed": integrity_failed[:20]},
    }
    if er_supplied:
        weights["er_coverage"] = _W_ER
        dims["er_coverage"] = {"score": round(er * 100, 1), "weight": _W_ER,
                               "missing": er_missing[:20]}
    else:
        # redistribute proportionally
        s = _W_PRESENCE + _W_INTEGRITY
        weights = {"presence": round(_W_PRESENCE / s * 1.0, 4),
                   "integrity": round(_W_INTEGRITY / s * 1.0, 4)}
        dims["presence"]["weight"] = weights["presence"]
        dims["integrity"]["weight"] = weights["integrity"]
        dims["er_coverage"] = {"status": "na_redistributed",
                               "reason": "no ER content found in tree; weight "
                                         "redistributed across presence/integrity"}
    dims["difficulty"] = {
        "status": "unavailable",
        "reason": "marks are not persisted in metadata.json (schema has no marks "
                  "field); core.difficulty.mark_to_difficulty is ready the moment "
                  "marks are stored — reported loudly instead of fabricated",
    }
    dims["topic_scores"] = {
        "status": "dead_dimension",
        "reason": "topic_scores is forbidden in metadata by json_generator / "
                  "output_manager / validation (locked no-extra-fields policy)",
    }

    total_w = round(sum(weights.values()), 4)
    overall = round(sum(dims[d]["score"] * weights[d] for d in weights), 1)
    report = {
        "subject": display,
        "question_folders": len(folders),
        "needs_review": _needs_review(folders),
        "dimensions": dims,
        "weights": weights,
        "overall": overall,
    }
    print(f"[quality_scorer] {display}: overall {overall}/100 across {len(folders)} folders "
          f"(weights sum={total_w})")
    if abs(total_w - 1.0) > 1e-6:
        raise ArithmeticError(f"[quality_scorer] weights do not sum to 1.0: {weights}")
    return report


def score_all(output_root: str | Path) -> Dict[str, Dict]:
    """Score every subject found under output_root. Loud on empty/missing tree."""
    output_root = Path(output_root)
    subjects = _subject_dirs(output_root) if output_root.exists() else []
    if not subjects:
        raise LookupError(
            f"[quality_scorer] score_all: no subject folders under {output_root} "
            f"(expected IGCSE/<Subject_Code>/ or A-Level/<Subject_Code>/)")
    out = {}
    for level, name, path in subjects:
        label = f"{level}/{name}" if level else name
        try:
            out[label] = score_subject(output_root, label)
        except LookupError as e:
            print(str(e))
            out[label] = {"status": "no_questions", "detail": str(e)}
    return out


if __name__ == "__main__":
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else "output"
    query = sys.argv[2] if len(sys.argv) > 2 else None
    result = score_subject(root, query) if query else score_all(root)
    print(json.dumps(result, indent=2))
