"""render_memory.py — in-memory page renderer (Amendment 10 / RS-44).

Created as its OWN module because core/converter.py is a RULE-6 pristine
file (hash-pinned, never modified). `render_pdf_to_memory` mirrors
converter.render_pdf_local's pixel production exactly (same scale math,
same final 2480x3508 resize) but returns PIL images directly — no
intermediate WebP save/load round-trip.

Measured on real papers: WebPEncode of the 12 intermediate pages was 5.0s
of a 10.4s crop pass (~50%). Removing it is a pure speed win AND removes a
lossy (quality=90) intermediate, so crops are marginally sharper —
accuracy-neutral-to-better.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from PIL import Image

EXPECTED_W = 2480
EXPECTED_H = 3508


def render_pdf_to_memory(
    pdf_path: str | Path,
    target_width: int = EXPECTED_W,
    target_height: int = EXPECTED_H,
) -> List[Image.Image]:
    """Render every PDF page to a 2480x3508 RGB PIL image, no disk writes."""
    import fitz

    doc = fitz.open(str(pdf_path))
    images: List[Image.Image] = []
    for page in doc:
        rect = page.rect
        scale_x = target_width / rect.width
        scale_y = target_height / rect.height
        scale = max(scale_x, scale_y)
        zoom = fitz.Matrix(scale, scale)
        pix = page.get_pixmap(matrix=zoom, alpha=False)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        if img.size != (target_width, target_height):
            img = img.resize((target_width, target_height), Image.LANCZOS)
        images.append(img.convert("RGB"))
    doc.close()
    return images
