"""
Sideways-display rotation normalizer (rotation-handling round / RS-14).

WHY THIS EXISTS
---------------
Two real-world classes of PDFs carry a non-zero /Rotate page attribute:

  * "Cambridge-style": content is authored *sideways* inside the mediabox
    and /Rotate=90 makes the DISPLAY upright (e.g. the real fixture
    0620_s16_ms_42.pdf, whose content pages are /Rotate=90). All existing
    rotation-aware machinery (core/pdf_io.py::_upright_bbox, gold MS split,
    gold MCQ answer parser) already handles these because rendered pixels
    and the upright coordinate mapping agree.

  * "Home-rotated": content is authored upright and a user/tool later set
    /Rotate (qpdf / Acrobat "Rotate Pages"), so the DISPLAY is sideways.
    The pipeline renders/display-maps just fine, but every reading-order
    algorithm sees text running vertically: the MCQ answer-grid parser
    returns 0 answers and the QP splitter emits empty/broken crops
    (fail-closed at stage S2 with "has ink dark=0.00000"). Nothing is
    fabricated — but nothing usable comes out either.

This module detects ONLY the second class and normalizes those PDFs by
CLEARING the /Rotate hint on verbatim copies (page.set_rotation(0) —
the authored content is already upright; the hint was the vandalism),
leaving the first class — and every rotation=0 input — untouched.

DESIGN RULES (mirroring the project's fail-closed, loud behaviour)
------------------------------------------------------------------
  * Pure detection by word-geometry evidence. A page is "sideways" when it
    has /Rotate != 0 AND multi-letter words, mapped to upright (display)
    coordinates by the locked pdf_io._upright_bbox, are predominantly tall
    (width/height < SIDEWAYS_ASPECT_LO). Pages with no usable word evidence
    abstain (pass through untouched, with a loud note) — downstream QC is
    the backstop there, as before.
  * For the home-rotated class the authored content is upright, so
    set_rotation(0) restores it exactly; for the Cambridge-style class we
    never clear at all (detector votes upright), which is exactly why
    detection must run first.
  * Normalized copies are deterministic (insert + hint-clear, saved with
    no_new_id=True -> byte-identical across runs for the same input),
    cached under a caller-supplied directory keyed by the ORIGINAL file's
    sha256, and always keep the ORIGINAL filename.
  * Zero changes to locked files: this module is called from
    run_guarded.run_paper_stages (recorded amendment); the locked MS/QP
    engines, converter DPI and WebP quality are untouched.

LIMITS
------
  * Pure-raster sideways pages (no text layer) abstain — see above.
  * Examiner-report PDFs are not normalized here (no rotated ER fixture
    exists; QP+MS are the proven-problem inputs).
"""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path
from typing import List, Optional, Tuple

# Upright mapped words with aspect > 1.2 vote "upright", < 0.8 vote
# "sideways"; near-square words (single glyphs, digits) abstain.
UPRIGHT_ASPECT_HI = 1.2
SIDEWAYS_ASPECT_LO = 0.8
# Minimum sideways votes before a page is considered sideways (evidence bar
# deliberately low — a sideways page votes overwhelmingly sideways: measured
# 142:16 and 18:0 on the case-(A) probe vs 0:39..7:130 on the real
# Cambridge-style rotated fixture).
MIN_SIDEWAYS_VOTES = 5


def _fitz():
    import fitz  # PyMuPDF — deferred import keeps module import cheap
    return fitz


def _word_evidence(page) -> Tuple[int, int, int]:
    """(sideways_votes, upright_votes, total_words) in DISPLAY coordinates."""
    from .pdf_io import _upright_bbox  # locked helper, unchanged

    sideways = upright = total = 0
    for raw in page.get_text("words"):
        x0, y0, x1, y1, text, *_ = raw
        text = (text or "").strip()
        if sum(c.isalpha() for c in text) < 2:
            continue
        (ux0, uy0), (ux1, uy1) = _upright_bbox(x0, y0, x1, y1, page)
        w, h = ux1 - ux0, uy1 - uy0
        if h <= 0:
            continue
        total += 1
        if w / h > UPRIGHT_ASPECT_HI:
            upright += 1
        elif w / h < SIDEWAYS_ASPECT_LO:
            sideways += 1
    return sideways, upright, total


def page_is_sideways(page) -> Tuple[bool, Tuple[int, int, int]]:
    """True when /Rotate != 0 AND the displayed text runs vertically.

    Returns (verdict, evidence) where evidence = (sideways, upright, total).
    """
    if page.rotation == 0:
        return False, (0, 0, 0)
    ev = _word_evidence(page)
    sideways, upright, total = ev
    if total == 0:
        return False, ev  # abstain: no word evidence on this page
    return (sideways >= MIN_SIDEWAYS_VOTES and sideways > upright), ev


def needs_normalization(pdf_path: str | Path) -> Tuple[bool, List[int]]:
    """(should_normalize, sideways_page_numbers_1idx) for a whole PDF."""
    fitz = _fitz()
    doc = fitz.open(str(pdf_path))
    try:
        sideways_pages: List[int] = []
        for page in doc:
            verdict, ev = page_is_sideways(page)
            if page.rotation != 0:
                state = "SIDEWAYS -> normalize" if verdict else "keep"
                print(f"    [rotation] {Path(str(pdf_path)).name} p{page.number + 1}: "
                      f"rot={page.rotation} sideways={ev[0]} upright={ev[1]} -> {state}")
            if verdict:
                sideways_pages.append(page.number + 1)
        return bool(sideways_pages), sideways_pages
    finally:
        doc.close()


def normalize_pdf(pdf_path: str | Path, out_path: str | Path) -> List[int]:
    """Re-bake sideways pages of ``pdf_path`` into rotation=0 upright pages.

    Sideways pages are "normalized" by CLEARING the /Rotate display hint
    (set_rotation(0)) on a verbatim copy — for the home-rotated class the
    authored content is already upright and the hint was the vandalism, so
    removing it restores the page exactly (no re-bake, no XObject wrap, no
    scaling; content geometry bit-preserving). All other pages are copied
    as-is. Deterministic across runs (no_new_id=True). Returns the
    1-indexed page numbers that were fixed.

    GEOMETRY NOTE: two earlier bake attempts (show_pdf_page into page.rect,
    then into mediabox) were rejected by measured evidence — the first
    letterboxed into landscape and doubled render RAM (worker exit -9 on a
    2 GB box), the second shrank content ~0.7x floating mid-page (Q26 crop
    rendered white, S2 ink check fail-closed).
    """
    fitz = _fitz()
    src = fitz.open(str(pdf_path))
    out = fitz.open()
    fixed: List[int] = []
    try:
        out.insert_pdf(src)
        try:
            out.set_metadata(dict(src.metadata or {}))
        except Exception:
            pass  # metadata is cosmetic; identity comes from the filename
        for pno in range(len(src)):
            verdict, _ev = page_is_sideways(src[pno])
            if verdict:
                out[pno].set_rotation(0)
                fixed.append(pno + 1)
        out.save(str(out_path), deflate=True, no_new_id=True)
    finally:
        out.close()
        src.close()
    return fixed


def ensure_upright(pdf_path: str | Path, cache_dir: str | Path,
                   ) -> Tuple[Path, List[int]]:
    """Return a path to a rotation-safe copy of ``pdf_path`` (loud noop if fine).

    Result lives at ``cache_dir/<orig-sha256[:16]>__<orig name>`` and is
    reused across runs (keyed by ORIGINAL bytes, so the cache is stable even
    though it contains a derived file). The filename is preserved verbatim
    after the hash prefix is stripped nowhere — identity parsing happens on
    the ORIGINAL file upstream; processors here just need the bytes.
    """
    pdf_path = Path(pdf_path)
    wanted, pages = needs_normalization(pdf_path)
    if not wanted:
        return pdf_path, []
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(pdf_path.read_bytes()).hexdigest()[:16]
    out_path = cache_dir / f"{digest}__{pdf_path.name}"
    if out_path.exists():
        print(f"    [rotation] reusing normalized {out_path.name} "
              f"(sideways pages {pages} in {pdf_path.name})")
        return out_path, pages
    baked = normalize_pdf(pdf_path, out_path)
    print(f"    [rotation] NORMALIZED {pdf_path.name}: baked sideways pages {baked} "
          f"to upright (rotation=0) -> {out_path.name} [original untouched]")
    return out_path, baked
