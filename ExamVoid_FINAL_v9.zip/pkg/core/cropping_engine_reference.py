"""
question_split.py
=================
Split a Cambridge question-paper PDF into individual question images with
hard requirements:
  A. FINAL WIDTH: Every final crop is EXACTLY 2280 pixels wide (aspect ratio preserved).
  B. BARCODE ELIMINATION / CLEAN TOP: every QP crop top begins exactly 20px above
     the detected question line (COMPLETE first line - fraction numerators and
     superscripts rising above the bare question number are included via
     _question_first_line_top_pdf). Page-level barcodes, page numbers and running
     headers are excluded structurally with a raster-validated safety boundary.
  C. MULTI-PAGE WHITESPACE OPTIMIZATION: Tight-trims each page section (5–10px margin)
     and combines them with a minimal gap (5–15px separation).
  D. ZERO CONTENT LOSS: Protects all diagrams, chemical structures, reaction schemes,
     equations, tables, and marks allocations [Total: X].
  E. MULTI-PAGE RESIZING: Resizes final combined images to exactly 2280px wide with
     LANCZOS resampling and validation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Set, Tuple, Union

try:
    import fitz
except ImportError:
    import pymupdf as fitz

import numpy as np
from PIL import Image

from .chemistry_reference import (
    PageClassification,
    classify_page,
    identify_removable_pages,
)
from .config import Config
from .multipage_optimizer import (
    assemble_multipage_question,
    enforce_exact_width_2280,
    find_content_bbox,
    trim_page_section,
    validate_content_preservation,
)
from .pdf_io import (
    detect_footer_y,
    detect_header_y,
    is_blank_image,
    page_is_usable,
)
from .quality_control import QuestionQCValidator, QCValidationResult

# Standard dimensions
TARGET_WIDTH = 2280
EXPECTED_W = 2480
EXPECTED_H = 3508

# Question & Marker Patterns
_NUMBER_LINE = re.compile(r"^\s*(\d{1,3})\s*[.)]?\s*$")
_NUMBER_PREFIX = re.compile(r"^\s*(\d{1,3})(?:[.)]\s+|\s+)\S")
_QUESTION_WORD_PREFIX = re.compile(r"^\s*(?:question|q)\s*(\d{1,3})\s*[:.)]?\s*", re.IGNORECASE)
_NUMBER_WITH_SUBPART = re.compile(r"^\s*(\d{1,3})\s*\(\s*([a-z]|[ivx]{1,4})\s*\)", re.IGNORECASE)
_SUBPART = re.compile(r"\(([a-z]|[ivx]{1,4})\)")
_UNIT_OR_VALUE = re.compile(r"^\s*\d{1,3}\s*(?:mol|cm|dm|g|kg|pa|kpa|mpa|atm|v|mv|s|min|h|kj|j|w|k|°c|%)\b", re.IGNORECASE)

LEFT_MARGIN = 0.22
LEFT_MARGIN_STRICT = 0.15
Q_START_TOP_BAND_PT = 30.0
BOTTOM_SKIP = 0.90

# User-specified QP top rule (approved via visual feedback loop):
# every QP crop top begins exactly this many pixels ABOVE the detected
# question line (complete first line, see _question_first_line_top_pdf).
# Meaning of "20px": exactly 20 VISIBLE white pixels above the first ink in
# the FINAL 2280px-wide image. The segment-level cut pre-positions the band in
# render pixels; _align_top_white_band_final() then anchors it raster-exactly
# at final scale (downstream trimming/scaling can stretch or shrink the band,
# so the final image is the only place "20px" can be honoured exactly).
QUESTION_TOP_GUARD_PX = 20

# Amendment 5 (2026-08-10, approved): side-air constant for the QP page
# frame crop. The physical page-side trim measured from each page edge.
# 45pt -> 35pt widens the kept frame by 10pt (~40px at 300dpi render)
# per side; the downstream ink-bbox trim and the 2280px invariant are
# unchanged. NOTE for future auditors: there is NO LEFT_MARGIN_PX /
# RIGHT_MARGIN_PX anywhere in this codebase and CONTENT_PADDING_LR in
# multipage_optimizer only acts as a clamp CEILING for this path —
# visible side air is governed by this constant alone.
PAGE_SIDE_TRIM_PT = 35.0


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------
@dataclass
class Question:
    qid: str = ""
    source_pdf: str = ""
    paper_code: str = ""
    session_label: str = ""
    year: int = 0
    question_number: str = ""
    sub_parts: List[str] = field(default_factory=list)
    images: List[Image.Image] = field(default_factory=list)
    text: str = ""
    text_hash: Optional[str] = None
    perceptual_hash: Optional[str] = None
    topic: List[str] = field(default_factory=list)
    needs_review: bool = False
    is_duplicate: bool = False
    duplicate_of: Optional[str] = None
    folder_name: str = ""
    topic_scores: Dict[str, float] = field(default_factory=dict)
    topic_confidence: float = 0.0
    ms_entry: Optional[Union[str, Image.Image]] = None
    _topic_scores: list = field(default_factory=list)
    page_segments: List[dict] = field(default_factory=list)
    review_reasons: List[str] = field(default_factory=list)
    qc_metrics: Dict[str, object] = field(default_factory=dict)

    @property
    def is_multi_page(self) -> bool:
        return len(self.images) > 1 or (self.images and self.images[0].height > 4000)


@dataclass(frozen=True)
class PageSegment:
    """A vertical slice of one source page."""
    page_index: int
    y0: int
    y1: int
    shared_page: bool = False
    safe_whitespace_cut: bool = True


@dataclass
class PageCropInfo:
    page_index: int
    left: int
    top: int
    right: int
    bottom: int
    orig_w: int
    orig_h: int
    # Proportional top-guard margin (px) used for this page. Derived from the
    # page's own body font size and render scale, so it tracks layout & DPI
    # instead of being a blind hardcoded pixel value. Shared with the segment
    # splitter so question-start boundaries keep the same validated margin.
    top_guard_px: float = 8.0


# ---------------------------------------------------------------------------
# Question Boundary Detection: 5px Above Question Line (No Barcode)
# ---------------------------------------------------------------------------
def find_question_start_pdf(page: fitz.Page, qnum: int) -> float:
    """
    Find the exact upright PDF y-coordinate where the question begins,
    excluding top barcodes, page numbers, and running headers.
    """
    w, h = float(page.rect.width), float(page.rect.height)
    q_re = re.compile(rf"^\s*(?:question\s*)?{qnum}(?:$|\s+|[.)])", re.IGNORECASE)

    blocks = page.get_text("dict").get("blocks", [])
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                txt = s.get("text", "").strip()
                bbox = s.get("bbox", [0, 0, 0, 0])
                # Question start must be below top margin (y > 55pt) and near left margin
                if bbox[1] > 55.0 and bbox[0] < w * 0.22:
                    if q_re.match(txt):
                        return float(bbox[1])

    # Fallback to general text analysis
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                bbox = s.get("bbox", [0, 0, 0, 0])
                if bbox[1] > 58.0 and bbox[0] < w * 0.90:
                    return float(bbox[1])

    return 60.0


def find_continuation_start_pdf(page: fitz.Page) -> float:
    """
    Find top-most question content on a continuation page (below running header).
    """
    w, h = float(page.rect.width), float(page.rect.height)
    min_y = h

    blocks = page.get_text("dict").get("blocks", [])
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                txt = s.get("text", "").strip()
                bbox = s.get("bbox", [0, 0, 0, 0])
                if bbox[1] > 58.0 and bbox[3] < h * 0.92 and bbox[0] < w * 0.94:
                    if "DO NOT WRITE" not in txt and "Turn over" not in txt and "Assessment 2026" not in txt:
                        min_y = min(min_y, bbox[1])

    drawings = page.get_drawings()
    for d in drawings:
        r = d.get("rect")
        if r and r.y0 > 58.0 and r.y1 < h * 0.92 and r.x1 < w * 0.94:
            min_y = min(min_y, r.y0)

    if min_y >= h:
        min_y = 60.0
    return min_y


def find_question_bottom_pdf(page: fitz.Page) -> float:
    """
    Find the bottom-most question content on a page (above running footer & barcode).
    """
    w, h = float(page.rect.width), float(page.rect.height)
    max_y = 0.0

    blocks = page.get_text("dict").get("blocks", [])
    for b in blocks:
        lines = b.get("lines", [])
        for l in lines:
            for s in l.get("spans", []):
                txt = s.get("text", "").strip()
                bbox = s.get("bbox", [0, 0, 0, 0])
                if bbox[3] < h * 0.94 and bbox[0] < w * 0.94:
                    if "©" not in txt and "Assessment" not in txt and "Turn over" not in txt and "DO NOT WRITE" not in txt:
                        max_y = max(max_y, bbox[3])

    drawings = page.get_drawings()
    for d in drawings:
        r = d.get("rect")
        if r and r.y1 < h * 0.94 and r.x1 < w * 0.94:
            if r.width < w * 0.90 or r.height < h * 0.90:
                max_y = max(max_y, r.y1)

    if max_y <= 0:
        max_y = h * 0.90
    return max_y


# ---------------------------------------------------------------------------
# Adaptive Crop Page (validated, layout-adaptive safe top)
# ---------------------------------------------------------------------------
# Header-junk recognition for the page-top boundary. Junk is recognised
# structurally (typography + position + pattern), never by a fixed y-line,
# so the boundary adapts to different paper layouts and resolutions.
_PAGE_BARCODE_RE = re.compile(r"\*+\s*[\d\s]{5,}\s*\*+")
_PAGE_NUM_RE = re.compile(r"^\s*\d{1,3}\s*$")
# banded boilerplate kept out of the question area in legacy papers
_HEADER_BOILERPLATE = ("©", "ucles", "turn over", "read these instructions")
# banner text that is junk anywhere on the page (rotated side-margin warnings
# on newer papers span the full page height, so no top-band restriction)
_BANNER_BOILERPLATE = ("do not write",)
# printer-slug fragments printed above the barcode strip (never question text)
_SLUG_FRAGMENTS = ("dfd",)
# Amendment 9 (2026-08-13, authorised by the maintainer): top-band junk that
# is printed on EVERY page of a Cambridge paper and must never survive into a
# crop. Continuation pages of multipage questions previously leaked it into
# the assembled image (the classic "barcode top-right" defect):
#   - barcode strip text ("This document has 16 pages", "DC (LK) 123456")
#   - third-party redistributor watermarks ("www.dynamicpapers.com", ...)
#   - the printed paper code ("9701/21/M/J/24")
_BARCODE_TEXT_SIGNS = ("this document has", "blank pages are indicated",
                       "dc (", "dc(")
# Amendment 11 (2026-08-14): the standard Cambridge instruction block printed
# at the top of the first question page ("Answer all the questions in the
# spaces provided.", "The number of marks is given in brackets [ ]...", ...).
# Recognised as junk ONLY in the top band (same constraint as every other
# header-junk class) so section headers mid-page ("Answer all the questions
# in this section") are never touched. The question-first-line walk uses the
# same classifier, so it skips these lines instead of pulling them into the
# crop as part of a question's first line.
_INSTRUCTION_SIGNS = (
    "answer all the questions",
    "answer all questions",
    "read these instructions",
    "in the spaces provided",
    "the number of marks is given",
    "marks is given in brackets",
    "at the end of the examination",
    "fasten all your work",
    "the total mark for this paper",
    "the total for this paper",
    "electronic calculators may be used",
    "if you have been given an insert",
    "answer on the insert",
    "write in dark blue or black pen",
    "you may use an hb pencil",
)
_WATERMARK_SIGNS = ("www.", "dynamicpapers", "exam-mate", "exammate",
                    "gceguide", "papacambridge", "xtremepapers",
                    "savemyexams", "physicsandmathstutor", "bestexamhelp")
_PAPER_CODE_RE = re.compile(r"^\d{4}/\d{2}/(?:[A-Za-z]{1,3}/)*\d{2}$")


def _classify_header_span(text: str, x0: float, y0: float, x1: float, y1: float,
                          size: float, w: float, h: float) -> dict:
    """Classify a span for header-junk purposes (used by both the page-top
    analyser and the question-first-line walk so they agree on what 'junk' is).
    Returns flags; pagenumber alone-ness is resolved by the caller."""
    lowered = text.lower()
    in_top_band = y1 < h * 0.15
    ctrl = sum(1 for c in text if ord(c) < 32 or ord(c) > 126)
    is_glyphart = bool(text) and ctrl > len(text) / 2.0
    return {
        "barcode": bool(_PAGE_BARCODE_RE.search(text)),
        "barcodetext": in_top_band and any(s in lowered for s in _BARCODE_TEXT_SIGNS),
        "watermark": in_top_band and any(s in lowered for s in _WATERMARK_SIGNS),
        "papercode": in_top_band and bool(_PAPER_CODE_RE.match(text)),
        "instructions": in_top_band and any(s in lowered for s in _INSTRUCTION_SIGNS),
        "glyphart": in_top_band and is_glyphart,
        "boilerplate": (in_top_band and any(s in lowered for s in _HEADER_BOILERPLATE)) or
                       any(s in lowered for s in _BANNER_BOILERPLATE),
        "slug": in_top_band and any(f in lowered for f in _SLUG_FRAGMENTS),
        "is_pagenum_shape": in_top_band and abs((x0 + x1) / 2.0 - w / 2.0) < w * 0.18
                            and size >= 9.0 and bool(_PAGE_NUM_RE.match(text)),
    }


def _analyse_page_top(page: fitz.Page) -> Tuple[float, float, float, List[Tuple[float, float, float, float]], Tuple[float, float]]:
    """Analyse one page and return (header_floor_pdf, content_top_pdf, margin_pt, junk_boxes_pdf).

    header_floor_pdf : bottom y (PDF pts) of recognised header junk (page number,
        barcode strip, banner/slug boilerplate); 0 when nothing is recognised.
    content_top_pdf  : top y (PDF pts) of true question content - the first text
        span or vector drawing that is NOT recognised header junk. No artificial
        y-floor is applied, so compact layouts (content starting high on the
        page) are detected correctly; off-page (negative-y) artifacts ignored.
    margin_pt        : proportional safety margin = 0.45 * median body font size,
        clamped to [3, 16] pt. Scales with the layout; multiplied by the page's
        own render scale downstream, so it also adapts to DPI automatically.
    junk_boxes_pdf   : PDF-space boxes of recognised header junk, masked during
        raster validation and white-painted if they survive inside the kept
        region (painting is clipped at content_top so real content is never
        erased - see adaptive_crop_page).

    Recognition is deliberately conservative: a page number must be digits-only,
    centered, header-sized, AND vertically alone among NON-JUNK spans in the
    top band - rotated full-height boilerplate banners ('DO NOT WRITE IN THIS
    MARGIN') and barcode strips are classed first so they cannot veto a genuine
    page number nor be mistaken for question content.
    """
    w, h = float(page.rect.width), float(page.rect.height)
    spans: List[Tuple[str, float, float, float, float, float]] = []
    span_line: List[int] = []
    _line_id = 0
    for block in page.get_text("dict").get("blocks", []):
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span.get("text", "").strip()
                if not text:
                    continue
                x0, y0, x1, y1 = span.get("bbox", [0, 0, 0, 0])
                size = float(span.get("size", 0.0) or 0.0)
                spans.append((text, x0, y0, x1, y1, size))
                span_line.append(_line_id)
            _line_id += 1

    base_flags = [
        _classify_header_span(t, x0, y0, x1, y1, size, w, h)
        for (t, x0, y0, x1, y1, size) in spans
    ]
    # Amendment 11: the printed instruction block ("Answer all the questions
    # in the spaces provided.") is split across multiple spans, so span-level
    # sign matching misses it. Match at LINE level, then flag EVERY span of an
    # instruction line as junk — while leaving all span bboxes byte-identical
    # for every other line (verified: clean 2024 papers show zero pixel
    # changes). Only lines containing an instruction sign are affected.
    _line_texts: Dict[int, List[str]] = {}
    for _i, (_t, *_rest) in enumerate(spans):
        _line_texts.setdefault(span_line[_i], []).append(_t)
    _line_has_instr = {
        _lid: any(_s in " ".join(_ts).lower() for _s in _INSTRUCTION_SIGNS)
        for _lid, _ts in _line_texts.items()
    }
    for _i, _f in enumerate(base_flags):
        if _line_has_instr.get(span_line[_i], False):
            _f["instructions"] = True

    base_junk = [f["barcode"] or f["barcodetext"] or f["watermark"]
                 or f["papercode"] or f["instructions"] or f["glyphart"]
                 or f["boilerplate"] or f["slug"]
                 for f in base_flags]

    junk_flags: List[bool] = []
    for i, (text, x0, y0, x1, y1, size) in enumerate(spans):
        is_pagenum = False
        if base_flags[i]["is_pagenum_shape"]:
            alone = True
            for j, (_t, _x0, oy0, _x1, oy1, _s) in enumerate(spans):
                if i == j or base_junk[j]:
                    continue  # junk-classed spans (banners, barcode art) cannot veto
                if oy1 < h * 0.15 and oy1 > y0 - 2.0 and oy0 < y1 + 2.0:
                    alone = False
                    break
            is_pagenum = alone
        junk_flags.append(bool(base_junk[i] or is_pagenum))

    sizes: List[float] = [s[5] for s in spans if s[5] > 0]
    junk_boxes: List[Tuple[float, float, float, float]] = []
    header_floor = 0.0
    content_top: Optional[float] = None
    content_x0: Optional[float] = None
    content_x1: Optional[float] = None

    for (text, x0, y0, x1, y1, size), is_junk in zip(spans, junk_flags):
        if is_junk:
            junk_boxes.append((x0, y0, x1, y1))
        else:
            content_top = y0 if content_top is None else min(content_top, y0)
            content_x0 = x0 if content_x0 is None else min(content_x0, x0)
            content_x1 = x1 if content_x1 is None else max(content_x1, x1)

    # Amendment 9: vector barcode ART. Modern Cambridge barcodes are drawn as
    # many narrow vertical bars (not text); without this they are read as
    # content and leak into crops on continuation pages. A cluster of >= 8
    # thin, tightly-spaced, height-aligned bars inside the top band is a
    # barcode block, never question content.
    bar_boxes: List[Tuple[float, float, float, float]] = []
    bars = []
    for d in page.get_drawings():
        r = d.get("rect")
        if not r or r.y0 < 0.0 or r.y0 > h:
            continue
        if r.y1 < h * 0.15 and r.width < 4.5 and r.height > 8.0:
            bars.append((r.x0, r.y0, r.x1, r.y1))
    bars.sort(key=lambda r: r[0])
    if len(bars) >= 8:
        span = bars[-1][2] - bars[0][0]
        gaps = [b[0] - a[2] for a, b in zip(bars, bars[1:])]
        y0s = [r[1] for r in bars]
        y1s = [r[3] for r in bars]
        if (span <= w * 0.35 and max(gaps, default=0.0) < 6.0
                and (max(y1s) - min(y0s)) < h * 0.12
                and (max(y0s) - min(y0s)) < 12.0):
            bar_boxes.append((bars[0][0] - 2.0, min(y0s) - 2.0,
                              bars[-1][2] + 2.0, max(y1s) + 2.0))
    for (bx0, by0, bx1, by1) in bar_boxes:
        junk_boxes.append((bx0, by0, bx1, by1))

    # On-page vector drawings (diagrams, rules, graphs) count as content; bits
    # drawn outside the visible page, plus thin flanking rules beside the side
    # margin banners (header furniture on newer papers), are NOT content. The
    # furniture comes in two shapes: vertical rules flanking the margins, and
    # short horizontal end-cap rules in the top band hugging the page edges.
    for d in page.get_drawings():
        r = d.get("rect")
        if not r or r.y0 < 0.0 or r.y0 > h:
            # Off-page registration art (e.g. a full-height fill anchored above
            # the page): never question content, but its pixels DO render, so
            # it must be masked as junk - otherwise raster validation mistakes
            # its ink for content and pulls the page-top boundary up to row 0.
            if r:
                junk_boxes.append((r.x0, max(0.0, r.y0), r.x1, min(h, r.y1)))
            continue
        if any((r.x0 >= bx0 - 1.0 and r.x1 <= bx1 + 1.0
                and r.y0 >= by0 - 1.0 and r.y1 <= by1 + 1.0)
               for (bx0, by0, bx1, by1) in bar_boxes):
            continue  # barcode art - already junk-painted, never content
        is_vertical_margin_rule = (
            r.y1 < h * 0.15 and r.width < 3.0
            and (r.x1 < w * 0.10 or r.x0 > w * 0.90)
        )
        is_horizontal_margin_rule = (
            r.y1 < h * 0.15 and r.height < 3.0 and r.width < w * 0.25
            and (r.x1 < w * 0.11 or r.x0 > w * 0.89)
        )
        if is_vertical_margin_rule or is_horizontal_margin_rule:
            junk_boxes.append((r.x0, r.y0, r.x1, r.y1))
            continue
        if r.width < w * 0.90 or r.height < h * 0.90:
            content_top = r.y0 if content_top is None else min(content_top, r.y0)

    # Header floor = rows known to be junk that do NOT overlap real content and
    # belong to the top band: full-height side banners and barcode strips that
    # extend into content rows must never push the boundary past the question's
    # first line.
    for (bx0, by0, bx1, by1) in junk_boxes:
        if by1 >= h * 0.15:
            continue
        no_v_overlap = by1 <= (content_top if content_top is not None else 0.0)
        no_x_overlap = (content_x1 is not None and content_x0 is not None
                        and (bx1 <= content_x0 or bx0 >= content_x1))
        if no_v_overlap or no_x_overlap:
            header_floor = max(header_floor, by1)

    if sizes:
        median_size = float(sorted(sizes)[len(sizes) // 2])
        margin_pt = max(3.0, min(16.0, 0.45 * median_size))
    else:
        margin_pt = 5.0  # textless page fallback (diagram-only): modest fixed margin

    if content_top is None:
        content_top = header_floor if header_floor > 0 else h * 0.07
    content_xrange = (
        (content_x0 if content_x0 is not None else 0.0,
         content_x1 if content_x1 is not None else w)
    )

    return header_floor, content_top, margin_pt, junk_boxes, content_xrange


def _validate_top_against_ink(
    img: Image.Image,
    top_px: int,
    guard_px: int,
    junk_boxes_px: List[Tuple[int, int, int, int]],
) -> int:
    """Raster validation pass for the page-top boundary.

    Scans the ACTUAL rendered pixels above the candidate boundary. Any ink found
    there that does not belong to recognised header junk is real content that
    would have been sliced (coordinate misalignment, ink above the PDF text
    bbox, or an unrecognised drawing), so the boundary is pulled UP above it
    with the same proportional guard. Validation-based safety instead of blind
    trust in PDF coordinates. Only ever raises the boundary (adds whitespace),
    never lowers it (never clips).
    """
    gray = np.asarray(img.convert("L"))
    height, width = gray.shape
    if height < 10 or width < 10:
        return top_px

    top_px = int(max(0, min(height, top_px)))
    if top_px <= 0:
        return 0

    masked = gray[:top_px, :].copy()
    for (x0, y0, x1, y1) in junk_boxes_px:
        x0 = max(0, min(width, x0)); x1 = max(0, min(width, x1))
        y0 = max(0, min(top_px, y0)); y1 = max(0, min(top_px, y1))
        if y1 > y0 and x1 > x0:
            masked[y0:y1, x0:x1] = 255

    # >= 2 faint pixels (< 250) per row: robust against speckle noise, still
    # catches light anti-aliased ink. Guaranteed no-clipping, not byte-tight.
    ink_rows = np.where((masked < 250).sum(axis=1) >= 2)[0]
    if ink_rows.size:
        return max(0, int(ink_rows.min()) - max(1, int(guard_px)))
    return top_px


def _align_top_white_band_final(
    img: Image.Image,
    target_px: int = QUESTION_TOP_GUARD_PX,
) -> Image.Image:
    """Raster-exact top white band on a FINAL 2280px-wide QP image.

    The segment-level 20px pre-cut is made in render pixels, but downstream
    trimming (find_content_bbox/trim_page_section) and the exact-2280 resize
    stretch or shrink that band, so the visible white above the first ink
    drifts (measured ~24px on 9700_w25_qp_22). This pass measures the rendered
    image directly and re-anchors the band to exactly ``target_px`` rows of
    visible white above the first ink:

    - if the band is too tall, only rows ABOVE the first ink are removed -
      every removed row is verified white (defensive assertion: never clips);
    - if the band is too short, white rows are ADDED on top (never clips).

    Width, bottom, seams and all other geometry are untouched (crop/pad only
    shifts the top edge). Recognised junk was already painted white upstream,
    so the scan sees a clean band.
    """
    gray = np.asarray(img.convert("L"))
    height, width = gray.shape
    if height < 10 or width < 10:
        return img

    ink_rows = np.where((gray < 250).sum(axis=1) >= 2)[0]
    if ink_rows.size == 0:
        return img  # blank section: leave untouched

    first_ink = int(ink_rows.min())
    delta = first_ink - int(target_px)

    if delta > 0:
        removed = gray[:delta]
        assert int((removed < 250).sum()) == 0, (
            "top white-band trim would remove ink rows - refused"
        )
        return img.crop((0, delta, width, height))
    if delta < 0:
        out = Image.new("RGB", (width, height - delta), "white")
        out.paste(img, (0, -delta))
        return out
    return img


def fixed_crop_page(img: Image.Image, cfg: Config) -> Image.Image:
    """Fallback fixed pixel crop."""
    w, h = img.size
    left = cfg.crop_left
    top = cfg.crop_top
    right = w - cfg.crop_right
    bottom = h - cfg.crop_bottom

    if bottom <= top or right <= left:
        return img
    return img.crop((left, top, right, bottom))


def _find_raster_barcode_boxes(img: Image.Image) -> List[Tuple[int, int, int, int]]:
    """Pixel-level barcode strip detector (Amendment 9) for scanned papers
    with no text/vector layer. Conservative: >= 8 narrow, tall, tightly
    spaced, height-aligned dark columns in the top band of the page -- the
    signature of a printed barcode, which question content (text, dotted
    answer lines, tables) does not produce. Returns pixel-space boxes for
    the caller to junk-paint. Never raises; no match -> empty list."""
    import numpy as _np
    arr = _np.asarray(img.convert("L"))
    h, w = arr.shape
    if h < 100 or w < 100:
        return []
    top = max(20, int(h * 0.12))
    band = arr[:top, :]
    dark = band < 160
    # A barcode bar is a TALL contiguous dark run in its column (>= 18 px at
    # 200 dpi, ~1.5 mm). Text lines and table rules produce runs of only a
    # few pixels, so column dark-COUNT thresholds would over-fire on text.
    col_run = _np.zeros(dark.shape[1], dtype=int)
    for x in range(dark.shape[1]):
        best = cur = 0
        for v in dark[:, x]:
            cur = cur + 1 if v else 0
            if cur > best:
                best = cur
        col_run[x] = best
    bar_cols = col_run >= 18
    runs = []
    in_run = False
    start = 0
    for x in range(len(bar_cols)):
        if bar_cols[x] and not in_run:
            start = x
            in_run = True
        elif not bar_cols[x] and in_run:
            runs.append((start, x - 1))
            in_run = False
    if in_run:
        runs.append((start, len(bar_cols) - 1))
    if len(runs) < 8:
        return []
    widths = [b - a + 1 for a, b in runs]
    gaps = [runs[i + 1][0] - runs[i][1] - 1 for i in range(len(runs) - 1)]
    if max(widths) > 8 or max(gaps) > 10:
        return []
    xs = [c for a, b in runs for c in range(a, b + 1)]
    rows = _np.where(dark[:, xs].sum(axis=1) > 0)[0]
    if len(rows) < 4:
        return []
    y0 = int(rows.min())
    y1 = int(rows.max())
    if (y1 - y0) < 8:
        return []
    return [(runs[0][0] - 2, max(0, y0 - 2), runs[-1][1] + 2, min(top, y1 + 2))]


def adaptive_crop_page(
    img: Image.Image,
    page: fitz.Page,
    cfg: Config,
) -> Tuple[Image.Image, PageCropInfo]:
    """
    Context-aware crop boundary:
    Top boundary starts at a validated proportional margin above the page's
    first real question content, structurally excluding barcodes/page numbers/
    running headers and raster-validated so text is never clipped.
    """
    orig_w, orig_h = img.size
    page_w = float(page.rect.width) or 1.0
    page_h = float(page.rect.height) or 1.0
    scale_y = orig_h / page_h
    scale_x = orig_w / page_w

    # Content bounds on this page (bottom unchanged: detected content + slack)
    bottom_pdf = find_question_bottom_pdf(page)

    # Safe top boundary: structural detection + proportional margin + raster
    # validation (replaces the previous fixed 55pt constant, which sliced
    # question content that starts high on compact layouts).
    header_floor_pdf, content_top_pdf, margin_pt, junk_boxes_pdf, content_xrange_pdf = _analyse_page_top(page)
    # Page-level guard: proportional font-size margin, but never below the
    # 20px question-line guard band (+ small slack) so the per-question 20px
    # rule always has its whitespace band available on the page. (Page crop is
    # an outer frame; per-question tops are refined at segment level.)
    guard_px = max(QUESTION_TOP_GUARD_PX + 4, int(round(margin_pt * scale_y)))
    margin_pt_eff = guard_px / scale_y
    top_pdf = max(0.0, max(header_floor_pdf, content_top_pdf - margin_pt_eff))
    top_px = max(0, min(orig_h, int(round(top_pdf * scale_y))))
    # Validate against actual pixels: unexpected non-junk ink above the
    # candidate boundary pulls it upward so nothing is ever clipped.
    # Junk boxes are padded before masking/painting. The vertical pad must
    # cover drawing stroke widths: a zero-height rule's ink can spread ~2pt+
    # either side of its bounding line, and a fixed 3px pad leaves unpainted
    # ghost lines at the edges. 2.5pt, scaled with the render resolution, is
    # safe: painting is clipped at the content top, so real text can't be hit.
    junk_pad_y = max(4, int(round(2.5 * scale_y)))
    junk_boxes_px = [
        (int(round(bx0 * scale_x)) - 3, int(round(by0 * scale_y)) - junk_pad_y,
         int(round(bx1 * scale_x)) + 3, int(round(by1 * scale_y)) + junk_pad_y)
        for (bx0, by0, bx1, by1) in junk_boxes_pdf
    ]
    # Amendment 9: scanned papers have no text/vector layer -- detect the
    # barcode strip on pixels. Strict signature; boxes are painted with the
    # same content-top clip as structural junk, so content is never erased.
    # Amendment 10: skip the raster scan when structural junk was already
    # found (text-layer pages: page numbers/barcodes are caught structurally;
    # scanned pages have no text -> junk_boxes empty -> scan still runs).
    if not junk_boxes_pdf:
        junk_boxes_px.extend(_find_raster_barcode_boxes(img))
    top_px = _validate_top_against_ink(img, top_px, guard_px, junk_boxes_px)

    bottom_px = min(orig_h, int(round(bottom_pdf * scale_y)) + 5)

    # White-out recognised header junk that survives inside the kept region
    # (e.g. a page number or barcode strip that could leak into the crop).
    # ONLY conservatively recognised junk boxes are painted, and any box whose
    # x-range intersects real content is clipped at the content top so text is
    # never erased (same precedent as the existing watermark and imposition-
    # barcode scrubbing in pdf_io/webp_utils). Side-banner columns sit outside
    # the content x-range and are painted full-height.
    if junk_boxes_px:
        painted = img if img.mode == "RGB" else img.convert("RGB")
        painted = painted.copy()
        pw, ph = painted.size
        content_top_px_i = int(round(content_top_pdf * scale_y))
        cx_lo = int(round(content_xrange_pdf[0] * scale_x))
        cx_hi = int(round(content_xrange_pdf[1] * scale_x))
        for (jx0, jy0, jx1, jy1) in junk_boxes_px:
            px0 = max(0, min(pw, jx0)); px1 = max(0, min(pw, jx1))
            overlaps_content_x = (px1 > cx_lo) and (px0 < cx_hi)
            py0 = max(top_px, max(0, min(ph, jy0)))
            py1 = min(bottom_px + 1, max(0, min(ph, jy1)))
            if overlaps_content_x:
                py1 = min(py1, content_top_px_i)
            if px1 > px0 and py1 > py0:
                painted.paste(Image.new("RGB", (px1 - px0, py1 - py0), "white"), (px0, py0))
        img = painted

    left_px = max(0, int(round(PAGE_SIDE_TRIM_PT * scale_x)))
    right_px = min(orig_w, int(round((page_w - PAGE_SIDE_TRIM_PT) * scale_x)))
    # Amendment 5: the widened frame (35pt) can re-include margin furniture
    # the classic 45pt trim excluded (e.g. the right margin rule at 36pt
       # from the edge on 9700 m25). Whiten exactly the [35pt, 45pt] band each
    # side: anything there was deleted by the historic 45pt trim anyway,
    # so information content is identical to the pre-Amendment pipeline —
    # the band simply becomes clean, measurable whitespace.
    side_sliver_px = max(0, int(round((45.0 - PAGE_SIDE_TRIM_PT) * scale_x)))

    if bottom_px <= top_px or right_px <= left_px:
        cropped = img
        top_px, bottom_px, left_px, right_px = 0, orig_h, 0, orig_w
    else:
        cropped = img.crop((left_px, top_px, right_px, bottom_px))
        if side_sliver_px > 0:
            cw = cropped.width
            work = cropped if cropped.mode == "RGB" else cropped.convert("RGB")
            work = work.copy()
            white = Image.new("RGB", (side_sliver_px, cropped.height), "white")
            work.paste(white, (0, 0))
            work.paste(white, (cw - side_sliver_px, 0))
            cropped = work

    crop_info = PageCropInfo(
        page_index=page.number,
        left=left_px,
        top=top_px,
        right=right_px,
        bottom=bottom_px,
        orig_w=orig_w,
        orig_h=orig_h,
        top_guard_px=float(guard_px),
    )
    return cropped, crop_info


# ---------------------------------------------------------------------------
# Page Removal: Chemistry Reference Material
# ---------------------------------------------------------------------------
def remove_unnecessary_pages(
    doc: fitz.Document,
    images: List[Image.Image],
    cfg: Config,
) -> List[int]:
    """Identify and remove all reference pages, periodic tables, and data sheets."""
    total_pages = len(images)
    syllabus_code = str(getattr(cfg, "syllabus_code", "") or "")
    keep, remove, classifications = identify_removable_pages(
        doc, total_pages, syllabus_code=syllabus_code
    )

    for cls in classifications:
        p_num = cls.page_idx + 1
        if cls.is_reference or cls.is_blank or cls.is_candidate_info:
            print(f"  [page-remove] Page {p_num:2d}/{total_pages}: {cls.category} - {cls.reason} "
                  f"(conf={cls.confidence:.2f})")

    if not keep and total_pages > 1:
        keep = list(range(1, total_pages))

    return keep


# ---------------------------------------------------------------------------
# Marker Detection & Sequence Healing
# ---------------------------------------------------------------------------
def _lines_on_page(page: "fitz.Page"):
    """Extract text lines with bounding boxes and typography."""
    rect = page.rect
    out = []
    for block in page.get_text("dict").get("blocks", []):
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            if not spans:
                continue
            text = "".join(s.get("text", "") for s in spans).rstrip()
            if not text.strip():
                continue
            x0 = min(s.get("bbox", [1e9])[0] for s in spans)
            y0 = min(s.get("bbox", [0, 1e9])[1] for s in spans)
            y1 = max(s.get("bbox", [0, 0])[3] for s in spans)
            font_size = max(float(s.get("size", 0.0) or 0.0) for s in spans)
            is_bold = any("bold" in str(s.get("font", "")).lower() for s in spans)
            out.append((x0, y0, y1, text, font_size, is_bold))
    out.sort(key=lambda t: (t[1], t[0]))
    return out, rect


def _parse_candidate_number(text: str) -> Optional[int]:
    """Parse question number from text line."""
    st = text.strip()
    if not st or _UNIT_OR_VALUE.match(st):
        return None

    m = _NUMBER_LINE.match(st) or _QUESTION_WORD_PREFIX.match(st) or \
        _NUMBER_WITH_SUBPART.match(st) or _NUMBER_PREFIX.match(st)
    if m:
        val = int(m.group(1))
        if 1 <= val <= 120:
            return val
    return None


def _question_first_line_top_pdf(page: fitz.Page, marker_y_pdf: float) -> float:
    """Top (PDF pts) of the COMPLETE detected question line.

    The 20px-above-question-line rule must sit above the whole first line of the
    question - including anything that rises above the bare question number
    (fraction numerators, superscripts, tall math). The marker detector returns
    the bare number's y0 (e.g. '4' at 72.19pt while 'sin^3' begins at 62.65pt),
    so we walk upward through text lines whose vertical extents overlap/adjoin
    and stop at the first real whitespace gap (which separates the question line
    from header junk / the previous question). For plain one-line questions this
    simply returns the marker y itself.
    """
    lines, rect = _lines_on_page(page)
    if not lines:
        return marker_y_pdf
    w, h = float(rect.width), float(rect.height)
    # adjacency tolerance proportional to line height (layout-adaptive)
    heights = sorted((y1 - y0) for (_x, y0, y1, _t, _s, _b) in lines if y1 > y0)
    median_h = heights[len(heights) // 2] if heights else 11.0
    tol = max(1.5, 0.15 * median_h)

    # Skip header junk and abnormal (rotated full-height banner) lines: they
    # can never belong to the question's first line but would otherwise be
    # absorbed by the upward walk (e.g. side-margin banners span all rows).
    usable = []
    for (x0, y0, y1, text, fsize, bold) in lines:
        if y1 - y0 > 2.5 * median_h:
            continue  # rotated/abnormal line (e.g. side-margin banner), never question text
        flags = _classify_header_span(text.strip(), x0, y0, x0 + 1.0, y1,
                                      fsize if fsize > 0 else median_h, w, h)
        if flags["barcode"] or flags["glyphart"] or flags["boilerplate"] or flags["slug"]:
            continue  # header/banner junk, never part of the question line
        usable.append((x0, y0, y1, text, fsize, bold))

    top = marker_y_pdf
    above = [l for l in usable if l[1] < top - tol]
    # walk upward while lines overlap or adjoin the current group top
    while above:
        cand = max(above, key=lambda l: l[1])  # nearest line above
        if cand[2] >= top - tol:
            top = cand[1]
            above = [l for l in above if l[1] < top - tol]
        else:
            break
    return top


def _detect_markers(
    doc: fitz.Document,
    kept_indices: Optional[List[int]] = None,
) -> Tuple[List[Tuple[int, float, int]], bool]:
    """Detect question starts using multi-pattern matching and sequence healing."""
    kept_set = set(kept_indices) if kept_indices is not None else set(range(len(doc)))
    raw_candidates: List[Tuple[int, float, int, float, float, bool, float, str]] = []
    per_page_lines: Dict[int, list] = {}

    for p_idx in sorted(kept_set):
        page = doc[p_idx]
        lines, rect = _lines_on_page(page)
        per_page_lines[p_idx] = lines

        for line_idx, (x0, y0, y1, text, font_size, is_bold) in enumerate(lines):
            if x0 > LEFT_MARGIN * rect.width or y0 > BOTTOM_SKIP * rect.height or y0 < 0.04 * rect.height:
                continue

            num = _parse_candidate_number(text)
            if num is None:
                continue

            prev_bottom = 0.0
            for prior in lines[:line_idx]:
                if prior[2] <= y0 and prior[0] < rect.width * 0.92:
                    prev_bottom = max(prev_bottom, prior[2])
            gap_above = max(0.0, y0 - prev_bottom)

            raw_candidates.append((p_idx, y0, num, x0, font_size, is_bold, gap_above, text))

    if not raw_candidates:
        return [], False

    filtered = [
        c for c in raw_candidates
        if c[3] < LEFT_MARGIN_STRICT * doc[c[0]].rect.width or _QUESTION_WORD_PREFIX.match(c[7])
    ]
    if not filtered:
        filtered = raw_candidates

    starts = [c for c in filtered if c[2] == 1]
    if not starts:
        min_q = min(c[2] for c in filtered)
        starts = [c for c in filtered if c[2] == min_q]

    def marker_quality(c, anchor_x: float) -> float:
        p_idx, _y, _n, x0, font_size, is_bold, gap, _txt = c
        rect = doc[p_idx].rect
        score = 4.0 if x0 < rect.width * 0.10 else 2.0
        score += 2.0 if font_size >= 10.0 else 0.0
        score += 1.5 if is_bold else 0.0
        score += min(2.0, gap / 8.0)
        score -= abs(x0 - anchor_x) / 6.0
        return score

    best_chain: List[Tuple[int, float, int, float, float, bool, float, str]] = []
    best_value = float("-inf")

    for start in starts[:10]:
        anchor_x = start[3]
        chain = [start]
        curr_val = marker_quality(start, anchor_x)
        expected = start[2] + 1
        curr_page, curr_y = start[0], start[1]

        while expected <= 120:
            options = [
                c for c in filtered
                if c[2] == expected
                and (c[0] > curr_page or (c[0] == curr_page and c[1] > curr_y + 25.0))
            ]
            if not options:
                # Sequence gap healing
                healed = None
                for p in kept_set:
                    if p < curr_page:
                        continue
                    for lx0, ly0, ly1, ltext, lfs, lbold in per_page_lines.get(p, []):
                        if p == curr_page and ly0 <= curr_y + 20:
                            continue
                        n = _parse_candidate_number(ltext)
                        if n == expected and lx0 < LEFT_MARGIN * doc[p].rect.width:
                            healed = (p, ly0, n, lx0, lfs, lbold, 10.0, ltext)
                            break
                    if healed:
                        break
                if healed:
                    options = [healed]

            if not options:
                break

            chosen = max(options, key=lambda c: marker_quality(c, anchor_x))
            chain.append(chosen)
            curr_val += marker_quality(chosen, anchor_x)
            curr_page, curr_y = chosen[0], chosen[1]
            expected = chosen[2] + 1

        chain_score = len(chain) * 100.0 + curr_val
        if chain_score > best_value:
            best_value = chain_score
            best_chain = chain

    markers = [(c[0], c[1], c[2]) for c in best_chain]
    markers.sort(key=lambda c: (c[0], c[1]))
    if not markers:
        return [], False

    sequential = all(markers[i][2] == markers[i - 1][2] + 1 for i in range(1, len(markers)))
    confidence = len(markers) >= 1 and sequential
    return markers, confidence


# ---------------------------------------------------------------------------
# Whitespace Cut Finder (Shared Pages)
# ---------------------------------------------------------------------------
def _blank_runs(mask: np.ndarray) -> List[Tuple[int, int]]:
    runs: List[Tuple[int, int]] = []
    start = None
    for index, value in enumerate(mask):
        if bool(value) and start is None:
            start = index
        elif not bool(value) and start is not None:
            runs.append((start, index))
            start = None
    if start is not None:
        runs.append((start, len(mask)))
    return runs


def find_whitespace_cut(
    image: Image.Image,
    marker_y_px: int,
    *,
    min_band_px: Optional[int] = None,
    protected_bands: Optional[List[Tuple[int, int]]] = None,
) -> Tuple[Optional[int], bool, Optional[Tuple[int, int]]]:
    """Find safe whitespace cut above a question marker."""
    gray = np.asarray(image.convert("L"))
    height, width = gray.shape
    if height < 20 or width < 20:
        return None, False, None

    marker_y_px = max(1, min(height - 1, int(marker_y_px)))
    x0 = max(0, int(width * 0.03))
    x1 = min(width, int(width * 0.97))
    region = gray[:, x0:x1]
    dark = region < 242
    row_ink = dark.sum(axis=1)

    search_dist = max(240, int(height * 0.20))
    search_top = max(1, marker_y_px - search_dist)
    search_bottom = max(search_top + 1, marker_y_px - 2)
    if search_bottom <= search_top:
        return None, False, None

    min_band = min_band_px if min_band_px is not None else max(10, int(height * 0.0035))

    protected_mask = np.zeros(height, dtype=bool)
    if protected_bands:
        for py0, py1 in protected_bands:
            py0 = max(0, min(height - 1, py0))
            py1 = max(0, min(height, py1))
            if py1 > py0:
                protected_mask[py0:py1] = True

    def find_best_band(max_ink: int, required_len: int):
        local_mask = (row_ink[search_top:search_bottom] <= max_ink)
        candidates = []
        for local_start, local_end in _blank_runs(local_mask):
            start = search_top + local_start
            end = search_top + local_end
            if end - start < required_len or np.any(protected_mask[start:end]):
                continue
            distance = marker_y_px - end
            candidates.append((distance, -(end - start), start, end))

        if not candidates:
            return None
        _dist, _neg_len, start, end = min(candidates)
        return start, end

    band = find_best_band(0, min_band) or find_best_band(max(2, int((x1 - x0) * 0.001)), min_band)
    if band is not None:
        start, end = band
        return (start + end) // 2, True, band

    band = find_best_band(0, 1)
    if band is not None:
        start, end = band
        return (start + end) // 2, False, band

    return None, False, None


def _pdf_y_to_cropped_px(
    page: fitz.Page,
    y_pdf: float,
    orig_h: int,
    crop_info: PageCropInfo,
) -> int:
    page_h = float(page.rect.height) or 1.0
    y_full = (float(y_pdf) / page_h) * orig_h
    return max(0, int(round(y_full - crop_info.top)))


def _page_has_continuation_above(
    doc: fitz.Document,
    page_idx: int,
    marker_y_pdf: float,
) -> bool:
    page = doc[page_idx]
    w, h = float(page.rect.width), float(page.rect.height)
    header_h = h * 0.06
    if marker_y_pdf <= header_h + 35.0:
        return False

    body_clip = fitz.Rect(0, header_h, w, marker_y_pdf)
    text_above = page.get_text("text", clip=body_clip).strip()
    lines = [l.strip() for l in text_above.splitlines() if l.strip()]
    clean_lines = [l for l in lines if not re.match(r"^\d{1,4}/|\bturn over\b|^\d{1,3}$", l, re.I)]
    combined = " ".join(clean_lines)

    has_subpart = bool(re.search(r"\([a-zivx]+\)", combined, re.I))
    has_marks = bool(re.search(r"\[\s*\d+\s*\]|\[\s*total", combined, re.I))
    has_command = bool(re.search(r"\b(calculate|explain|state|describe|determine|suggest|draw|write|complete|identify)\b", combined, re.I))
    has_substantive_text = len(combined) > 40

    drawings_above = [
        d for d in page.get_drawings()
        if header_h < d.get("rect", fitz.Rect(0, 0, 0, 0)).y1 < marker_y_pdf
        and d.get("rect", fitz.Rect(0, 0, 0, 0)).height < h * 0.90
    ]
    return bool(has_subpart or has_marks or has_command or (has_substantive_text and len(drawings_above) > 0))


# ---------------------------------------------------------------------------
# Build Question Segments
# ---------------------------------------------------------------------------
def build_question_segments(
    markers: List[Tuple[int, float, int]],
    kept_indices: List[int],
    original_images: List[Image.Image],
    cropped_images: List[Image.Image],
    crop_infos: Dict[int, PageCropInfo],
    doc: fitz.Document,
    cfg: Config,
) -> Tuple[Dict[int, List[PageSegment]], bool, List[str]]:
    """Build question segments so every QP crop top sits 20px above the
    detected question line (complete first line; user-specified QP top rule).
    This cut pre-positions the band in render pixels; crop_page_segments then
    re-anchors it raster-exactly to 20 visible white pixels in the final
    2280px image (_align_top_white_band_final)."""
    if not markers:
        return {}, False, ["No question markers detected"]

    kept = sorted(set(kept_indices))
    kept_set = set(kept)
    cuts: Dict[int, Tuple[int, bool]] = {}
    notes: List[str] = []
    all_safe = True

    for marker_idx in range(1, len(markers)):
        prev_m = markers[marker_idx - 1]
        curr_m = markers[marker_idx]
        p_idx, y_pdf, qnum = curr_m

        if p_idx not in kept_set:
            continue

        cinfo = crop_infos[p_idx]

        same_page = (prev_m[0] == curr_m[0])
        continuation_above = _page_has_continuation_above(doc, p_idx, y_pdf)
        should_split = same_page or continuation_above

        if not should_split:
            continue

        # --- USER-QP-TOP-RULE: split exactly 20px above the detected question
        # line (complete first line - _question_first_line_top_pdf walks up over
        # fraction numerators/superscripts that rise above the bare number, so
        # the "complete question line" is preserved, then fixed 20px of white).
        first_line_top_pdf = _question_first_line_top_pdf(doc[p_idx], y_pdf)
        first_line_top_px = _pdf_y_to_cropped_px(
            doc[p_idx], first_line_top_pdf, original_images[p_idx].height, cinfo
        )
        guard = QUESTION_TOP_GUARD_PX
        cut = max(1, min(cropped_images[p_idx].height - 1, first_line_top_px - guard))
        safe = True
        notes.append(
            f"Page {p_idx + 1}, Q{qnum}: split at y={cut} "
            f"(complete question line top y={first_line_top_px} - {guard}px guard)"
        )

        cuts[marker_idx] = (cut, safe)
        all_safe = all_safe and safe

    by_question: Dict[int, List[PageSegment]] = {}
    for marker_idx, (start_page, start_y_pdf, qnum) in enumerate(markers):
        if marker_idx + 1 < len(markers):
            next_page = markers[marker_idx + 1][0]
            if marker_idx + 1 in cuts:
                end_page = next_page
            else:
                before_next = [p for p in kept if start_page <= p < next_page]
                end_page = before_next[-1] if before_next else start_page
        else:
            remaining = [p for p in kept if p >= start_page]
            end_page = remaining[-1] if remaining else start_page

        segments: List[PageSegment] = []
        for p_idx in kept:
            if p_idx < start_page or p_idx > end_page:
                continue
            image = cropped_images[p_idx]
            if not page_is_usable(image):
                continue

            y0 = 0
            y1 = image.height
            shared = False
            safe = True

            # Start page of the question: USER-QP-TOP-RULE - top boundary
            # begins exactly 20px above the detected question line (complete
            # first line, incl. fraction numerators/superscripts above the number).
            if p_idx == start_page:
                cinfo = crop_infos[p_idx]
                first_line_top_pdf = _question_first_line_top_pdf(doc[p_idx], start_y_pdf)
                first_line_top_px = _pdf_y_to_cropped_px(
                    doc[p_idx], first_line_top_pdf, original_images[p_idx].height, cinfo
                )
                if marker_idx in cuts:
                    y0, safe = cuts[marker_idx]
                    shared = True
                else:
                    # Whether or not an earlier question sits on this page, every
                    # QP crop top uses the same 20px rule (page-level structural
                    # top already excluded barcodes/page numbers, so the 20px band
                    # is always safe whitespace).
                    y0 = max(0, first_line_top_px - QUESTION_TOP_GUARD_PX)

            if (marker_idx + 1 in cuts and markers[marker_idx + 1][0] == p_idx):
                y1, end_safe = cuts[marker_idx + 1]
                safe = safe and end_safe
                shared = True

            y0 = max(0, min(image.height, int(y0)))
            y1 = max(0, min(image.height, int(y1)))
            if y1 - y0 < 10:
                all_safe = False
                continue

            segments.append(PageSegment(
                page_index=p_idx, y0=y0, y1=y1,
                shared_page=shared, safe_whitespace_cut=safe,
            ))

        if segments:
            by_question[qnum] = segments

    return by_question, all_safe, notes


def crop_page_segments(
    cropped_images: List[Image.Image],
    segments: List[PageSegment],
) -> List[Image.Image]:
    """Materialize PageSegment slices and enforce whitespace optimization & 2280px width."""
    output: List[Image.Image] = []
    for segment in segments:
        if segment.page_index >= len(cropped_images):
            continue
        image = cropped_images[segment.page_index]
        if segment.y0 == 0 and segment.y1 == image.height:
            piece = image.copy()
        else:
            piece = image.crop((0, segment.y0, image.width, segment.y1)).copy()
        output.append(piece)

    if not output:
        return []

    # Assemble all segments with whitespace optimization into a single 2280px wide image
    assembled = assemble_multipage_question(output, target_width=TARGET_WIDTH)
    # USER-QP-TOP-RULE (final authority): exactly 20 visible white pixels above
    # the first ink in the final 2280px image. The segment cut pre-positions
    # the band; trimming/scaling inside assemble_multipage_question drifts it,
    # so re-anchor raster-exactly at final scale (white rows only, never ink).
    assembled = _align_top_white_band_final(assembled)
    return [assembled]


def merge_question_pages(
    images: List[Image.Image],
    page_indices: List[int],
) -> Image.Image:
    """Merge multiple page images vertically into a single 2280px wide question canvas."""
    real = [images[idx] for idx in page_indices if idx < len(images) and page_is_usable(images[idx])]
    return assemble_multipage_question(real, target_width=TARGET_WIDTH)


def extract_question_text(
    doc: fitz.Document,
    question_pages: List[int],
    markers: List[Tuple[int, float, int]],
    qnum: int,
) -> str:
    """Extract exact question text from PDF for classification."""
    marker_idx = None
    for i, (p0, y0, qn) in enumerate(markers):
        if qn == qnum:
            marker_idx = i
            break

    if marker_idx is None:
        return ""

    p0, y0, _ = markers[marker_idx]
    relevant_pages = sorted(set(question_pages))
    if not relevant_pages:
        return ""

    if marker_idx + 1 < len(markers):
        next_page, next_y, _ = markers[marker_idx + 1]
        if next_page in relevant_pages:
            p1, y1 = next_page, next_y
        else:
            p1 = relevant_pages[-1]
            y1 = float(doc[p1].rect.height)
    else:
        p1 = relevant_pages[-1]
        y1 = float(doc[p1].rect.height)

    texts: List[str] = []
    for pg in relevant_pages:
        if pg < p0 or pg > p1:
            continue
        page = doc[pg]
        if pg == p0 and pg == p1:
            clip = fitz.Rect(0, y0, page.rect.width, y1)
        elif pg == p0:
            clip = fitz.Rect(0, y0, page.rect.width, page.rect.height)
        elif pg == p1:
            clip = fitz.Rect(0, 0, page.rect.width, y1)
        else:
            clip = page.rect
        text = page.get_text("text", clip=clip).strip()
        if text:
            # Clean header/footer/barcode artifacts from classification text
            text = re.sub(r"\*\s*\d{10,16}\s*\*", "", text)
            text = re.sub(r"DO NOT WRITE IN THIS MARGIN", "", text, flags=re.IGNORECASE)
            text = re.sub(r"\d{4}/\d{2}/[A-Z]/[A-Z]/\d{2}", "", text)
            text = re.sub(r"©.*?Assessment \d{4}", "", text)
            texts.append(text)

    return "\n".join(texts).strip()


# ---------------------------------------------------------------------------
# Main Entry Point: split_questions
# ---------------------------------------------------------------------------
def split_questions(
    pdf_path: str | Path,
    dpi: int = 200,
    paper_code: str = "",
    webp_dir: str | Path | None = None,
    use_api: bool = False,
    api_key: str | None = None,
    cfg: Optional[Config] = None,
    pre_rendered: Optional[Sequence[Image.Image]] = None,
) -> Tuple[List[Question], bool]:
    """
    Split question-paper PDF into Question objects:
      1. Renders PDF pages to images.
      2. Removes reference sheets (Periodic Table, Data Sheets, etc.).
      3. Sets top crop boundary at a validated proportional margin above the question line (eliminating barcodes without clipping content).
      4. Assembles multi-page questions with tight whitespace trimming (5–10px margin, 5–15px gap).
      5. Enforces EXACTLY 2280px width on every crop.
    """
    if cfg is None:
        cfg = Config()

    pdf_path = Path(pdf_path)
    doc = fitz.open(str(pdf_path))

    # --- Step 1: Render PDF pages to WebP ---
    if webp_dir is not None:
        webp_dir = Path(webp_dir)
    else:
        import tempfile
        webp_dir = Path(tempfile.mkdtemp(prefix="qp_pages_"))

    # Amendment 10 (2026-08-13): in-memory page images skip the intermediate
    # WebP save/load round-trip (5.0s/paper measured — ~50% of the crop pass)
    # and remove a lossy quality=90 intermediate. When pre_rendered is None
    # the original webp_dir path runs unchanged (byte-identical for every
    # other caller). Pre-rendered images must be 2480x3508 RGB (the same
    # dimensions render_pdf_local produces).
    images: List[Image.Image] = []
    if pre_rendered is not None:
        images = [im.convert("RGB") if im.mode != "RGB" else im
                  for im in pre_rendered]
    else:
        if use_api and api_key:
            from .converter import convert_pdf_to_webp, render_pdf_local
            try:
                webp_paths = convert_pdf_to_webp(pdf_path, webp_dir, api_key)
            except Exception as e:
                print(f"[split] API render failed ({e}). Falling back to local renderer...")
                webp_paths = render_pdf_local(pdf_path, webp_dir)
        else:
            from .converter import render_pdf_local
            webp_paths = render_pdf_local(pdf_path, webp_dir)
        for wp in webp_paths:
            img = Image.open(wp).convert("RGB")
            images.append(img)

    print(f"[split] Loaded {len(images)} page images from {pdf_path.name} (mode={'memory' if pre_rendered is not None else 'webp_dir'})")

    # --- Step 2: Chemistry Reference Material Removal ---
    print("[split] Detecting and removing reference sheets, data tables, and cover pages...")
    kept_indices = remove_unnecessary_pages(doc, images, cfg)
    print(f"[split] Kept {len(kept_indices)} of {len(images)} pages (removed {len(images) - len(kept_indices)} non-question pages)")

    # --- Step 3: Adaptive Page Cropping ---
    print("[split] Applying context-aware boundary detection to question pages...")
    cropped_images: List[Image.Image] = [Image.new("RGB", (1, 1), "white")] * len(images)
    crop_infos: Dict[int, PageCropInfo] = {}

    for idx in kept_indices:
        cropped, cinfo = adaptive_crop_page(images[idx], doc[idx], cfg)
        cropped_images[idx] = cropped
        crop_infos[idx] = cinfo

    # --- Step 4: Marker Detection ---
    markers, marker_confident = _detect_markers(doc, kept_indices=kept_indices)

    if not markers:
        print("[split] WARNING: No question markers detected!")
        doc.close()
        return [], False

    print(f"[split] Detected {len(markers)} question marker(s) (confident={marker_confident})")

    # --- Step 5: Shared-Page Segmentation ---
    question_segments, split_confident, split_notes = build_question_segments(
        markers, kept_indices, images, cropped_images, crop_infos, doc, cfg,
    )
    for note in split_notes:
        print(f"  [shared-page] {note}")

    overall_confident = marker_confident and split_confident

    # --- Step 6: Create Question Objects & Run QC Validation ---
    questions: List[Question] = []

    for qnum, segments in sorted(question_segments.items()):
        segment_images = crop_page_segments(cropped_images, segments)
        if not segment_images:
            continue
        page_indices = [segment.page_index for segment in segments]

        text = extract_question_text(doc, page_indices, markers, qnum)
        sub_parts = sorted(set(_SUBPART.findall(text)))

        segment_dicts = [
            {
                "page": s.page_index + 1,
                "y0": s.y0,
                "y1": s.y1,
                "shared": s.shared_page,
                "safe": s.safe_whitespace_cut,
            }
            for s in segments
        ]

        # Enforce exact 2280px width on the final image
        final_images = [enforce_exact_width_2280(im, target_width=TARGET_WIDTH) for im in segment_images]

        # Quality Control Validation
        qc_res = QuestionQCValidator.validate(
            question_number=str(qnum),
            images=final_images,
            text=text,
            sub_parts=sub_parts,
            page_segments=segment_dicts,
            paper_code=paper_code,
            doc=doc,
        )

        q = Question(
            source_pdf=str(pdf_path),
            paper_code=paper_code,
            question_number=str(qnum),
            sub_parts=sub_parts,
            images=final_images,
            text=text,
            needs_review=qc_res.needs_review,
            page_segments=segment_dicts,
            review_reasons=qc_res.review_reasons,
            qc_metrics=qc_res.metrics,
        )

        if not qc_res.is_valid:
            print(f"  [qc-warn] Q{qnum} failed QC validation: {', '.join(qc_res.review_reasons)}")
        elif qc_res.needs_review:
            print(f"  [qc-review] Q{qnum} flagged for review: {', '.join(qc_res.review_reasons)}")

        questions.append(q)

        assembled_w = max(im.width for im in final_images)
        assembled_h = sum(im.height for im in final_images)
        shared_count = sum(1 for s in segments if s.shared_page)
        print(f"  Q{qnum}: {len(segments)} page section(s), "
              f"final crop {assembled_w}×{assembled_h}px (width=2280 exactly), subparts={sub_parts}")

    doc.close()
    return questions, overall_confident
