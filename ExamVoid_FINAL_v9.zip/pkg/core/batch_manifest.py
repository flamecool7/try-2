"""One-pass batch manifest (Overseer manifest spec — implemented for real).

ROUND PREMISE RECEIPT: the Overseer claimed "Step 1 completed" with
`review/project/core/batch_manifest.py` added, "2 tests passed" and a
12-file/5-bundle fixture run. NOTHING existed on disk anywhere in the
workspace (verified 2026-08-11: no `review/` tree, no `*batch_manifest*`
file, no such tests). This module is the real implementation, written this
round; the Overseer's claimed numbers are unverifiable and NOT used as a
target anywhere in the tests.

WHAT THIS IS (approved decision set: new_delegate + derived_cache):
  * A DERIVED, RECOMPUTABLE CACHE of input-directory identity. It is never
    authoritative: consumers validate freshness and silently fall back to
    the live identifier on ANY mismatch. `.pipeline_state.json` and the
    RS-8 batch SQLite remain the only status truths.
  * One pass over the input tree: identify (delegated to the LOCKED
    `paper_identifier.parse_paper_filename`), hash, stat, group. Parents
    build it; workers consume-or-fallback and NEVER build (kills the O(N^2)
    per-worker full-directory re-identification in run_guarded.load_inputs
    S1 — verified: worker_main -> load_inputs -> S1 identify over the whole
    input dir in EVERY spawned paper worker).

DELIBERATE DESIGN RECEIPTS (audited against real code before writing):
  1. Parsing is NOT re-implemented. `parse_paper_filename` (paper_identifier,
     RS-7 locked) is the single source of identity. The manifest serializes
     its own superset of PaperInfo fields because `PaperInfo.to_dict()` omits
     `file_path` / `subject_guess` / `year_short`.
  2. `.pdf` AND `.PDF` are both matched (case-insensitive suffix walk), closing
     a REAL gap: `identify_papers_in_dir` uses `rglob("*.pdf")` which misses
     `.PDF` on case-sensitive filesystems (paper_identifier.py:436). The
     locked identifier is NOT amended; the manifest walk covers the gap.
  3. File hashing is single-sourced from `core.database.sha256` (RS-8) —
     one canonical chunked hasher, imported (no amendment, no duplication).
  4. Grouping is a self-contained TWO-PASS grouping with receipted parity to
     RS-8 `preflight._group_bundles`: QP/MS bundles first, then ERs attach —
     component-less session ERs (9700_m25_er.pdf, variant='') attach to EVERY
     bundle of the same code/season/year; an ER naming a component matches by
     FIRST DIGIT of the component. `QPMSMatcher.group_papers` was NOT reused:
     it keeps only the first of a duplicate pair (its grouping_errors path
     drops the second path — the spec requires duplicates to be DETECTED with
     both paths listed) and it would file ERs under the component key rather
     than attaching them.
  5. Spec bullets beyond preflight semantics (receipted as SUPERSET): ms-only
     groups are kept as REVIEW_REQUIRED bundles (preflight silently drops
     no-QP groups); duplicate QP/MS and missing QP/MS are first-class
     `reasons`; ERs with no matching bundle land in review.unpaired_er.
  6. Round-trip is FAIL-CLOSED on identifier drift: the manifest stores the
     derived fields (paper_format / is_mcq / expected_question_count) exactly
     as produced by `PaperInfo.__post_init__` at build time; on consume they
     are re-derived from the live code and must match, else ManifestError and
     the caller falls back to a live scan. A future identifier amendment can
     therefore never silently ride a stale manifest.
  7. Atomic write: same-directory tmp file + fsync + os.replace. A crashed
     build never leaves a torn manifest (workers treat unreadable manifests
     as absent -> live fallback).
  8. Workers NEVER build (build_if_missing=False on the worker branch);
     run_guarded parents / pipeline.py parents (via load_inputs) / main.py /
     this CLI build-or-refresh. Default location: <input>/.batch_manifest.json
     (auto-discovered — pipeline.py needs NO amendment; explicit override via
     --manifest flag or GUARDED_MANIFEST_JSON env).
  9. Freshness tiers: cheap = path-set + size + mtime_ns equality; full = +
     sha256 per file (which also RESCUES a manifest whose mtimes changed but
     whose bytes did not, e.g. a copied tree). Sha values are recorded at
     BUILD for duplicate detection and the full tier — the cheap tier never
     re-hashes (that would defeat the point at 300+ files).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import List, Optional, Tuple

from .database import sha256 as _file_sha256  # receipt 3: RS-8 single-source hasher
from .paper_identifier import PaperInfo, parse_paper_filename  # receipt 1

MANIFEST_VERSION = 1
DEFAULT_NAME = ".batch_manifest.json"
ENV_MANIFEST = "GUARDED_MANIFEST_JSON"

# PaperInfo ctor fields serialized per identified file (receipt 1: to_dict()
# omits file_path/subject_guess/year_short, so we store our own superset).
_CTOR_FIELDS = (
    "syllabus_code", "year", "year_short", "season", "season_letter",
    "paper_type", "variant", "full_code", "level", "subject_guess",
    "original_name",
)
# Derived fields stored for the fail-closed drift check (receipt 6).
_DERIVED_FIELDS = ("paper_format", "is_mcq", "expected_question_count")

_BUNDLE_TYPES = ("qp", "ms")          # pass-1 bundle members
_ER_TYPE = "er"                       # pass-2 attach


class ManifestError(Exception):
    """Fail-closed manifest load/validate error — caller falls back to live."""


# --------------------------------------------------------------------------- #
# Walk + build
# --------------------------------------------------------------------------- #

def _walk_pdfs(input_dir: Path) -> List[Path]:
    """Case-insensitive PDF walk, sorted by relative path (receipt 2)."""
    files = [p for p in input_dir.rglob("*")
             if p.is_file() and p.suffix.lower() == ".pdf"]
    return sorted(files, key=lambda p: str(p.relative_to(input_dir)))


def _paper_record(info: PaperInfo) -> dict:
    return {
        "ctor": {k: getattr(info, k) for k in _CTOR_FIELDS},
        "derived": {k: getattr(info, k) for k in _DERIVED_FIELDS},
    }


def build_manifest(input_dir: str | Path) -> dict:
    """One-pass scan/identify/hash/group of an input tree (spec bullets)."""
    input_dir = Path(input_dir)
    files_out, paper_by_rel = [], {}
    unparseable = []

    for p in _walk_pdfs(input_dir):
        rel = str(p.relative_to(input_dir))
        st = p.stat()
        info = parse_paper_filename(p)
        rec = {
            "path": rel,
            "size": st.st_size,
            "mtime_ns": st.st_mtime_ns,
            "sha256": _file_sha256(p),
            "identified": info is not None,
            "paper": _paper_record(info) if info else None,
            "parse_note": None if info else "no identifier pattern matched",
        }
        files_out.append(rec)
        if info is None:
            unparseable.append(rec["path"])
        else:
            paper_by_rel[rel] = info

    # --- Pass 1: QP/MS bundles (preflight parity, receipt 4) ---------------
    bundles = {}
    er_rels = []
    for rec in files_out:
        if not rec["identified"]:
            continue
        info = paper_by_rel[rec["path"]]
        kind = info.paper_type
        if kind == _ER_TYPE:
            er_rels.append(rec["path"])
            continue
        if kind not in _BUNDLE_TYPES:
            continue  # insert / ci / gt / in ... recorded in files, never bundled
        base_key = f"{info.syllabus_code}_{info.season_letter}{info.year_short}_{info.variant}"
        b = bundles.setdefault(base_key, {
            "base_key": base_key,
            "syllabus_code": info.syllabus_code,
            "level": info.level,
            "season_letter": info.season_letter,
            "year_short": info.year_short,
            "variant": str(info.variant),
            "paper_format": info.paper_format,
            "qp": [], "ms": [], "er": [],
            "status": "READY", "reasons": [],
        })
        b[kind].append(rec["path"])

    # --- Pass 2: ER attach, order-independent (preflight parity) -----------
    ers_attached = 0
    unpaired_er = []
    for rel in er_rels:
        info = paper_by_rel[rel]
        paper_num = str(info.variant)[:1] if str(info.variant or "") else ""
        attached = False
        for b in bundles.values():
            if (b["syllabus_code"] == info.syllabus_code
                    and b["season_letter"] == info.season_letter
                    and b["year_short"] == info.year_short
                    and (not paper_num or b["variant"][:1] == paper_num)):
                b["er"].append(rel)
                ers_attached += 1
                attached = True
        if not attached:
            unpaired_er.append(rel)

    # --- Status: spec bullets (duplicates / missing -> REVIEW_REQUIRED) ----
    duplicates = missing_qp = missing_ms = 0
    for b in bundles.values():
        r = b["reasons"]
        if not b["qp"]:
            r.append("missing_qp")
            missing_qp += 1
        if not b["ms"]:
            r.append("missing_ms")
            missing_ms += 1
        if len(b["qp"]) > 1:
            r.append(f"duplicate_qp x{len(b['qp'])}")
            duplicates += len(b["qp"]) - 1
        if len(b["ms"]) > 1:
            r.append(f"duplicate_ms x{len(b['ms'])}")
            duplicates += len(b["ms"]) - 1
        if r:
            b["status"] = "REVIEW_REQUIRED"

    bundles = {k: bundles[k] for k in sorted(bundles)}
    parsed = sum(1 for f in files_out if f["identified"])
    ready = sum(1 for b in bundles.values() if b["status"] == "READY")
    summary = {
        "files_scanned": len(files_out),
        "files_parsed": parsed,
        "bundles_found": len(bundles),
        "bundles_ready": ready,
        "bundles_review_required": len(bundles) - ready,
        "examiner_reports_attached": ers_attached,
        "duplicates": duplicates,
        "missing_qp": missing_qp,
        "missing_ms": missing_ms,
        "unparseable": len(unparseable),
    }
    return {
        "manifest_version": MANIFEST_VERSION,
        "tool": "core/batch_manifest.py",
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "input_dir": str(input_dir.resolve()),
        "files": files_out,
        "bundles": bundles,
        "review": {"unparseable": unparseable, "unpaired_er": unpaired_er},
        "summary": summary,
    }


def write_manifest(input_dir: str | Path, out_path: str | Path | None = None,
                   quiet: bool = False) -> Tuple[Path, dict]:
    """Build + atomically write (receipt 7). Returns (path, manifest)."""
    input_dir = Path(input_dir)
    out_path = Path(out_path) if out_path else input_dir / DEFAULT_NAME
    mf = build_manifest(input_dir)
    payload = json.dumps(mf, indent=2, ensure_ascii=False) + "\n"
    fd, tmp = tempfile.mkstemp(prefix=".manifest_", dir=str(out_path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, out_path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    if not quiet:
        print_summary(mf)
    return out_path, mf


def print_summary(mf: dict) -> None:
    s = mf["summary"]
    print(f"{s['files_scanned']} files scanned")
    print(f"{s['files_parsed']} files parsed")
    print(f"{s['bundles_found']} QP/MS bundles found")
    print(f"{s['bundles_ready']} bundles ready")
    print(f"{s['bundles_review_required']} bundles requiring review")
    print(f"{s['examiner_reports_attached']} examiner reports attached")
    for k in ("duplicates", "missing_qp", "missing_ms", "unparseable"):
        if s[k]:
            print(f"  ! {k}: {s[k]}")


# --------------------------------------------------------------------------- #
# Consume (derived-cache semantics: validate or fall back — NEVER wrong)
# --------------------------------------------------------------------------- #

def load_manifest(path: str | Path) -> dict:
    path = Path(path)
    try:
        mf = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise ManifestError(f"unreadable manifest {path}: {e}")
    if not isinstance(mf, dict) or mf.get("manifest_version") != MANIFEST_VERSION:
        raise ManifestError(
            f"manifest version {mf.get('manifest_version')!r} != {MANIFEST_VERSION}")
    for key in ("files", "bundles", "summary", "review"):
        if key not in mf:
            raise ManifestError(f"manifest missing key {key!r}")
    return mf


def check_freshness(mf: dict, input_dir: str | Path,
                    full: bool = False) -> Tuple[bool, str]:
    """Cheap tier: path-set + size + mtime_ns. Full tier adds sha256 rescue
    (receipt 9). Returns (fresh, reason)."""
    input_dir = Path(input_dir)
    recorded = {f["path"]: f for f in mf["files"]}
    live = {}
    for p in _walk_pdfs(input_dir):
        rel = str(p.relative_to(input_dir))
        st = p.stat()
        live[rel] = (st.st_size, st.st_mtime_ns, p)
    if set(live) != set(recorded):
        only_live = sorted(set(live) - set(recorded))[:3]
        only_rec = sorted(set(recorded) - set(live))[:3]
        return False, f"file set changed (new:{only_live} gone:{only_rec})"
    for rel, (size, mtime_ns, p) in live.items():
        f = recorded[rel]
        if size != f["size"]:
            return False, f"size changed: {rel}"
        if mtime_ns != f["mtime_ns"]:
            if full and _file_sha256(p) == f["sha256"] and size == f["size"]:
                continue  # sha rescue: metadata drift, same bytes
            return False, f"mtime changed: {rel}"
    if full:
        for rel, (size, _, p) in live.items():
            if _file_sha256(p) != recorded[rel]["sha256"]:
                return False, f"sha256 changed: {rel}"
    return True, "fresh"


def papers_from_manifest(mf: dict, input_dir: str | Path) -> List[PaperInfo]:
    """Rebuild PaperInfos; FAIL-CLOSED on identifier drift (receipt 6)."""
    input_dir = Path(input_dir)
    papers = []
    for f in mf["files"]:
        if not f["identified"]:
            continue
        ctor = dict(f["paper"]["ctor"])
        unknown = set(ctor) - set(_CTOR_FIELDS)
        if unknown:
            raise ManifestError(f"unknown ctor fields {sorted(unknown)} (drift)")
        ctor["file_path"] = input_dir / f["path"]
        info = PaperInfo(**ctor)
        for k in _DERIVED_FIELDS:
            if getattr(info, k) != f["paper"]["derived"][k]:
                raise ManifestError(
                    f"identifier drift on {f['path']}: {k} "
                    f"stored={f['paper']['derived'][k]!r} live={getattr(info, k)!r}")
        papers.append(info)
    return papers


def identify_via_manifest_or_live(
    input_dir: str | Path,
    manifest_path: str | Path | None = None,
    build_if_missing: bool = False,
    no_manifest: bool = False,
    full_check: bool = False,
) -> Tuple[List[PaperInfo], str]:
    """THE consumed API (run_guarded S1 / main.py). Never wrong, never raises:
    any manifest problem -> live `identify_papers_in_dir` fallback. Parents
    pass build_if_missing=True (and thereby pre-seed workers); workers pass
    False and NEVER build (receipt 8). Returns (papers, source_label)."""
    from .paper_identifier import identify_papers_in_dir
    input_dir = Path(input_dir)
    if no_manifest:
        return identify_papers_in_dir(input_dir), "live (manifest disabled)"

    env_path = os.environ.get(ENV_MANIFEST)
    mpath = Path(manifest_path or env_path) if (manifest_path or env_path) \
        else input_dir / DEFAULT_NAME
    mf = None
    if mpath.exists():
        try:
            mf = load_manifest(mpath)
            fresh, why = check_freshness(mf, input_dir, full=full_check)
            if not fresh:
                print(f"[manifest] stale ({why}) — falling back to live identification")
                mf = None
        except ManifestError as e:
            print(f"[manifest] rejected ({e}) — falling back to live identification")
            mf = None
    if mf is not None:
        try:
            papers = papers_from_manifest(mf, input_dir)
            tier = "full" if full_check else "cheap"
            return papers, f"manifest:{mpath.name} ({len(papers)} papers, {tier}-validated)"
        except ManifestError as e:
            print(f"[manifest] drift ({e}) — falling back to live identification")

    papers = identify_papers_in_dir(input_dir)
    if build_if_missing:
        try:
            out, _ = write_manifest(input_dir, mpath, quiet=True)
            print(f"[manifest] wrote {out} "
                  f"({len(papers)} papers identified live; workers will consume it)")
            return papers, f"live+wrote-manifest:{out.name}"
        except Exception as e:  # never let cache-writing break a real run
            print(f"[manifest] write failed ({e}) — continuing live")
    return papers, "live"


# --------------------------------------------------------------------------- #
# CLI — pre-seed a manifest for pipeline.py runs (children auto-discover
# <input>/.batch_manifest.json; no pipeline.py amendment needed, receipt 8).
# --------------------------------------------------------------------------- #

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Build / check a one-pass input manifest (derived cache).")
    ap.add_argument("input_dir")
    ap.add_argument("--out", default=None, help="manifest path (default <input>/.batch_manifest.json)")
    ap.add_argument("--check", action="store_true",
                    help="validate an existing manifest instead of building")
    ap.add_argument("--full", action="store_true", help="sha256 freshness tier")
    args = ap.parse_args(argv)

    input_dir = Path(args.input_dir)
    if not input_dir.is_dir():
        print(f"not a directory: {input_dir}")
        return 2
    mpath = Path(args.out) if args.out else input_dir / DEFAULT_NAME

    if args.check:
        if not mpath.exists():
            print(f"no manifest at {mpath}")
            return 1
        try:
            mf = load_manifest(mpath)
        except ManifestError as e:
            print(f"REJECTED: {e}")
            return 1
        fresh, why = check_freshness(mf, input_dir, full=args.full)
        print(f"{'FRESH' if fresh else 'STALE'}: {why}")
        print_summary(mf)
        return 0 if fresh else 1

    _, mf = write_manifest(input_dir, mpath)
    return 0


if __name__ == "__main__":
    sys.exit(main())
