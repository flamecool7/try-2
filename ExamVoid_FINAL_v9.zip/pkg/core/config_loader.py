"""
Config Loader - Universal component supporting IGCSE + A-Level with syllabus-year awareness

Architecture:
Level → Subject → Syllabus Code → Syllabus Year → Topic Configuration

Supports:
- Official Cambridge syllabus as source of truth
- Major topics = high-level official structure
- Detailed topics = sub-topics
- Mapping detailed -> major preserved from official hierarchy
- Syllabus year awareness (2025, 2026, 2027, etc.)
- Validation before allowing config to be used
- No mixing IGCSE/A-Level

Structure:
subjects/
├── IGCSE/
│   ├── Chemistry_0620/
│   ├── Computer_Science_0478/
│   └── ...
└── A-Level/
    ├── Chemistry_9701/
    ├── Computer_Science_9618/
    └── ...

And year-aware:
subjects/A-Level/Chemistry_9701/
├── config.json (default, latest)
├── 2025/config.json (if syllabus differs)
├── 2026/config.json
└── 2027+/config.json

If paper year matches historical config, use it.
"""

import copy
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

SUBJECTS_ROOT = Path(__file__).parent.parent / "subjects"

# Complete code map including all required subjects per prompt
KNOWN_CODE_MAP = {
    # IGCSE Required per prompt
    "0620": "Chemistry_0620",
    "0625": "Physics_0625",
    "0610": "Biology_0610",
    "0580": "Mathematics_0580",
    "0606": "Additional_Mathematics_0606",
    "0478": "Computer_Science_0478",
    "0455": "Economics_0455",
    "0450": "Business_Studies_0450",
    "0475": "Literature_in_English_0475",
    "0470": "History_0470",
    "0417": "ICT_0417",
    "0460": "Geography_0460",
    # A-Level Required per prompt
    "9701": "Chemistry_9701",
    "9702": "Physics_9702",
    "9709": "Mathematics_9709",
    "9231": "Further_Mathematics_9231",
    "9618": "Computer_Science_9618",
    "9708": "Economics_9708",
    "9609": "Business_9609",
    "9695": "English_Literature_9695",
    "9489": "History_9489",
    "9626": "Information_Technology_9626",
    "9696": "Geography_9696",
    # Extra
    "9700": "Biology_9700",
    # Detected-but-previously-unconfigured A-Level subjects (2026-08-15):
    # subject_detector recognised these codes yet no config existed, so their
    # papers were skipped as "no approved subject config".
    "9990": "Psychology_9990",
    "9699": "Sociology_9699",
    "9706": "Accounting_9706",
    # ── Broad subject-coverage expansion (2026-08-15) ──────────────────
    # Generated configs for the wider Cambridge IGCSE + A-Level catalog so
    # papers are no longer skipped as "no approved subject config".  See
    # tools/build_full_subject_catalog.py.
    # IGCSE
    "0400": "Art_and_Design_0400",
    "0410": "Music_0410",
    "0411": "Drama_0411",
    "0413": "Physical_Education_0413",
    "0445": "Design_and_Technology_0445",
    "0448": "Pakistan_Studies_0448",
    "0452": "Accounting_0452",
    "0454": "Enterprise_0454",
    "0457": "Global_Perspectives_0457",
    "0471": "Travel_and_Tourism_0471",
    "0490": "Religious_Studies_0490",
    "0493": "Islamiyat_0493",
    "0495": "Sociology_0495",
    "0500": "English_First_Language_0500",
    "0510": "English_Second_Language_0510",
    "0520": "French_0520",
    "0525": "German_0525",
    "0530": "Spanish_0530",
    "0539": "Urdu_0539",
    "0544": "Arabic_0544",
    "0547": "Mandarin_Chinese_0547",
    "0549": "Hindi_0549",
    "0607": "International_Mathematics_0607",
    "0648": "Food_and_Nutrition_0648",
    "0680": "Environmental_Management_0680",
    "0697": "Marine_Science_0697",
    # A-Level / AS
    "8021": "English_General_Paper_8021",
    "9084": "Law_9084",
    "9093": "English_Language_9093",
    "9239": "Global_Perspectives_9239",
    "9274": "Classical_Studies_9274",
    "9395": "Travel_and_Tourism_9395",
    "9396": "Physical_Education_9396",
    "9479": "Art_and_Design_9479",
    "9481": "Digital_Media_and_Design_9481",
    "9482": "Drama_9482",
    "9483": "Music_9483",
    "9607": "Media_Studies_9607",
    "9686": "Urdu_9686",
    "9693": "Marine_Science_9693",
    "9694": "Thinking_Skills_9694",
    "9705": "Design_and_Technology_9705",
    "9713": "Applied_ICT_9713",
    "9715": "Mandarin_Chinese_9715",
    "9716": "French_9716",
    "9717": "German_9717",
    "9719": "Spanish_9719",
    # IGCSE 9-1 graded equivalents (same syllabus content, second code)
    "0983": "Computer_Science_0478",
    "0971": "Chemistry_0620",
    "0972": "Physics_0625",
    "0970": "Biology_0610",
    "0980": "Mathematics_0580",
    "0987": "Economics_0455",
    "0986": "Business_Studies_0450",
    "0976": "Geography_0460",
    "0977": "History_0470",
    # Combined / Coordinated Sciences
    "0653": "Combined_Science_0653",
    "0654": "Coordinated_Sciences_0654",
    "0973": "Combined_Science_0653",      # 9-1 graded
    "0974": "Coordinated_Sciences_0654",   # 9-1 graded
    # Superseded A-Level codes (old syllabus code -> current subject)
    "9608": "Computer_Science_9618",       # CS: 9608 -> 9618 (2020)
    "9389": "History_9489",                # History: 9389 -> 9489 (2021)
}

# Syllabus-code aliases: alternate codes that resolve to a canonical config.
# 9-1 IGCSE equivalents (0983 == 0478 content), 9-1 graded Combined Science
# (0973/0974), and superseded A-Level codes (9608/9389). Adding a new alias
# here makes the whole pipeline (identification, config loading, subject
# detection, MCQ format, classification) treat the alias as its canonical
# subject while keeping the original code in metadata/paper fields.
CODE_ALIASES = {
    "0983": "0478",
    "0971": "0620",
    "0972": "0625",
    "0970": "0610",
    "0980": "0580",
    "0987": "0455",
    "0986": "0450",
    "0976": "0460",
    "0977": "0470",
    "0973": "0653",
    "0974": "0654",
    "9608": "9618",
    "9389": "9489",
}


def resolve_code_alias(syllabus_code) -> str:
    """Map an alias syllabus code to its canonical code (identity if not an
    alias). Used everywhere a code keys into configs/registries."""
    code = str(syllabus_code)
    return CODE_ALIASES.get(code, code)

LEVEL_BY_CODE_PREFIX = {
    "04": "IGCSE",
    "05": "IGCSE",
    "06": "IGCSE",
    # 09xx = IGCSE 9-1 graded codes (0983 CS, 0971 Chemistry, ...).
    # A-Level codes are 92xx/94xx/96xx/97xx; the bare-9 fallback below
    # must exclude the 09 range.
    "09": "IGCSE",
    "96": "A-Level",
    "97": "A-Level",
    "92": "A-Level",
    "94": "A-Level",   # History 9489, Art & Design 9479, Drama 9482, Music 9483, ...
    "90": "A-Level",   # Law 9084, English Language 9093, ...
    "86": "A-Level",   # A-Level language syllabi (8682 French, 8686 Urdu, 8695 Lang&Lit, ...)
    "80": "A-Level",   # AS-Level-only syllabi (8021 English General Paper, ...)
}

def infer_level_from_code(syllabus_code: str) -> str:
    code = str(syllabus_code)
    for prefix, level in LEVEL_BY_CODE_PREFIX.items():
        if code.startswith(prefix):
            return level
    return "A-Level" if (code.startswith("9") and not code.startswith("09")) else "IGCSE"

class SubjectConfig:
    def __init__(self, data: dict, config_path: Optional[Path] = None):
        self.data = data
        self.config_path = config_path
        self.subject: str = data["subject"]
        self.syllabus_code: str = data["syllabus_code"]
        self.board: str = data.get("board", "CIE")
        self.level: str = data.get("level", infer_level_from_code(self.syllabus_code))
        self.major_topics: List[str] = data["major_topics"]
        self.detailed_topics: List[str] = data["detailed_topics"]
        self.mapping: Dict[str, str] = data["mapping"]
        self.classification_keywords: Dict[str, List[str]] = data.get("classification_keywords", {})
        self.specialization_weights: Dict[str, float] = data.get("specialization_weights", {})
        self.syllabus_order: Dict[str, int] = data.get("syllabus_order", {})
        self.folder_naming: str = data.get("folder_naming", "Pascal_Snake")
        # New: syllabus year awareness
        self.syllabus_years: List[str] = data.get("syllabus_years", ["2026"])
        self.official_source: str = data.get("official_source", "")
        self.version: str = data.get("version", "2026")
        self.year: Optional[str] = data.get("year")  # For year-specific configs
        # A syllabus edition is verified when the paper year is declared in
        # syllabus_years.  Unknown historical/future years may still be
        # processed in the explicit review-required mode requested by the
        # maintainer: crops and evidence are preserved, but the bundle cannot
        # be marked complete against an unverified syllabus edition.
        self.historical_year_policy: str = data.get(
            "historical_year_policy", "review_required"
        )
        self.requested_year: Optional[str] = None
        self.year_verified: bool = True
        self.year_review_required: bool = False

        if self.level not in ["IGCSE", "A-Level"]:
            self.level = infer_level_from_code(self.syllabus_code)

    def get_major_for_detailed(self, detailed: str) -> str:
        return self.mapping.get(detailed)

    def validate(self) -> Tuple[bool, List[str]]:
        """
        Configuration validation per requirement 11:
        ✓ Syllabus code exists
        ✓ Level is correct
        ✓ Subject name is correct
        ✓ Major topics exist
        ✓ Every minor topic maps to a major topic
        ✓ No minor topic maps to an invalid major topic
        ✓ No duplicate topic identifiers
        ✓ Folder-safe names exist
        ✓ Syllabus year is defined
        ✓ Configuration is internally consistent
        """
        errors = []

        if not self.syllabus_code or len(self.syllabus_code) != 4:
            errors.append(f"Syllabus code invalid: {self.syllabus_code}")

        if self.level not in ["IGCSE", "A-Level"]:
            errors.append(f"Level invalid: {self.level} must be IGCSE or A-Level")

        if not self.subject or "_" not in self.subject:
            errors.append(f"Subject name invalid: {self.subject} should be like Chemistry_0620")

        # Subject name should contain code
        if self.syllabus_code not in self.subject:
            errors.append(f"Subject {self.subject} does not contain syllabus code {self.syllabus_code}")

        if not self.major_topics or len(self.major_topics) == 0:
            errors.append("Major topics missing")

        if not self.detailed_topics or len(self.detailed_topics) == 0:
            errors.append("Detailed topics missing")

        # Every minor maps to major
        major_set = set(self.major_topics)
        for det in self.detailed_topics:
            if det not in self.mapping:
                errors.append(f"Detailed topic {det} not in mapping")
            else:
                maj = self.mapping[det]
                if maj not in major_set:
                    errors.append(f"Detailed {det} maps to invalid major {maj}")

        # No duplicates
        if len(self.major_topics) != len(set(self.major_topics)):
            errors.append("Duplicate major topics")
        if len(self.detailed_topics) != len(set(self.detailed_topics)):
            errors.append("Duplicate detailed topics")

        # Folder-safe names (no spaces, special chars). Production routing
        # uses major-topic names only: numeric prefixes and decimal syllabus
        # identifiers belong in diagnostics/profile metadata, never folders.
        for name in self.major_topics + self.detailed_topics:
            if " " in name:
                errors.append(f"Space in folder-safe name: {name}")
            if any(c in name for c in ["/", "\\", ":", "*", "?", "\"", "<", ">", "|"]):
                errors.append(f"Invalid char in name: {name}")
            if re.match(r"^\d", name) or re.search(r"\d+\.\d+", name):
                errors.append(f"Numeric/decimal topic identifier not allowed in routing name: {name}")

        # Syllabus year defined
        if not self.syllabus_years or len(self.syllabus_years) == 0:
            errors.append("Syllabus year not defined")
        if self.historical_year_policy not in {"reject", "review_required"}:
            errors.append(
                "historical_year_policy must be 'reject' or 'review_required'"
            )

        # Code vs Level consistency is a hard gate. A profile must not claim
        # A-Level for an IGCSE code or vice versa.
        inferred = infer_level_from_code(self.syllabus_code)
        if inferred != self.level:
            errors.append(
                f"Code/level mismatch: {self.syllabus_code} infers {inferred} "
                f"but config declares {self.level}"
            )

        return len(errors) == 0, errors

# U4 (Overseer efficiency): process-session cache for the whole config tree.
# load_subject_config_by_code_and_level() re-parsed + re-validated EVERY
# config.json on each call. Keyed on (path, mtime_ns, size) fingerprints, so
# on-disk edits invalidate automatically within the session.
_CONFIG_TREE_CACHE: Dict[tuple, Dict[str, 'SubjectConfig']] = {}


def load_all_subject_configs() -> Dict[str, 'SubjectConfig']:
    try:
        key = tuple(sorted(
            (str(p), p.stat().st_mtime_ns, p.stat().st_size)
            for p in SUBJECTS_ROOT.rglob("config.json")
        ))
    except FileNotFoundError:
        key = None
    if key is not None and key in _CONFIG_TREE_CACHE:
        return _CONFIG_TREE_CACHE[key]

    configs: Dict[str, SubjectConfig] = {}
    if not SUBJECTS_ROOT.exists():
        return configs

    for config_path in SUBJECTS_ROOT.rglob("config.json"):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            cfg = SubjectConfig(data, config_path=config_path)

            # Validate before allowing use
            valid, errs = cfg.validate()
            if not valid:
                print(f"[ConfigLoader] Validation FAILED for {config_path}: {errs} - Do not process papers using this config")
                continue

            configs[cfg.subject] = cfg
            configs[cfg.syllabus_code] = cfg
            # Register alias codes (0983 -> 0478 config, 9608 -> 9618, ...)
            # so `configs["0983"]` resolves like `configs["0478"]`.
            for _alias, _canon in CODE_ALIASES.items():
                if _canon == cfg.syllabus_code and _alias not in configs:
                    configs[_alias] = cfg

            # Handle year-specific configs: path like subjects/A-Level/Chemistry_9701/2025/config.json
            try:
                relative = config_path.relative_to(SUBJECTS_ROOT)
                parts = relative.parts
                # parts: [Level, Subject, config.json] or [Level, Subject, Year, config.json]
                if len(parts) >= 2:
                    level_folder = parts[0]
                    if level_folder in ["IGCSE", "A-Level"]:
                        configs[f"{level_folder}/{cfg.subject}"] = cfg
                        configs[f"{level_folder}/{cfg.syllabus_code}"] = cfg
                        # If year specific: Level/Subject/Year/config.json
                        if len(parts) >= 3 and parts[2] != "config.json":
                            year_folder = parts[2]
                            # e.g., 2025, 2026
                            if year_folder.isdigit() or year_folder.endswith("+"):
                                configs[f"{level_folder}/{cfg.subject}/{year_folder}"] = cfg
                                configs[f"{level_folder}/{cfg.syllabus_code}/{year_folder}"] = cfg
                                configs[f"{cfg.syllabus_code}/{year_folder}"] = cfg
                # Also handle year in filename: config_2026.json
                if "config_" in config_path.name:
                    year_part = config_path.stem.replace("config_", "")
                    configs[f"{cfg.syllabus_code}/{year_part}"] = cfg

            except Exception as e:
                print(f"[ConfigLoader] Path handling warning for {config_path}: {e}")

        except Exception as e:
            print(f"[ConfigLoader] Failed to load {config_path}: {e}")
            continue

    if key is not None:
        _CONFIG_TREE_CACHE.clear()
        _CONFIG_TREE_CACHE[key] = configs
    return configs

def _normalise_year(year: Optional[str]) -> Optional[str]:
    if year is None or str(year).strip() == "":
        return None
    value = str(year).strip()
    if len(value) == 2 and value.isdigit():
        return "20" + value
    return value


def _bind_requested_year(cfg: SubjectConfig, year: Optional[str]) -> SubjectConfig:
    """Return a per-request config view without mutating the cached config.

    Unknown years are deliberately loud and review-bound.  This lets the
    engine crop/process every available paper year while preventing an
    unverified historical syllabus from being reported as a clean completion.
    """
    bound = copy.copy(cfg)
    requested = _normalise_year(year)
    bound.requested_year = requested
    bound.year = requested
    bound.year_verified = True
    bound.year_review_required = False
    if requested is not None and requested not in [str(y) for y in cfg.syllabus_years]:
        if cfg.historical_year_policy == "review_required":
            bound.year_verified = False
            bound.year_review_required = True
            print(
                f"[ConfigLoader] YEAR UNVERIFIED: {cfg.syllabus_code} exam year "
                f"{requested} is outside declared syllabus editions "
                f"{cfg.syllabus_years}; processing is allowed but the bundle "
                "will remain REVIEW_REQUIRED"
            )
        else:
            return None
    return bound


def load_subject_config_by_name(subject_name: str) -> 'SubjectConfig':
    configs = load_all_subject_configs()
    if subject_name in configs:
        return configs[subject_name]
    if subject_name in KNOWN_CODE_MAP:
        code_name = KNOWN_CODE_MAP[subject_name]
        if code_name in configs:
            return configs[code_name]
    raise ValueError(f"Subject config not found: {subject_name}")

def load_subject_config_by_code_and_level(syllabus_code: str, level: Optional[str] = None, year: Optional[str] = None) -> Optional['SubjectConfig']:
    """Load the profile for a code/level and bind the requested paper year.

    Declared syllabus editions are clean.  Any other four-digit paper year is
    still processable in historical review mode: the engine can crop and
    preserve the paper, but its bundle is forced to REVIEW_REQUIRED until a
    matching official syllabus profile is added.  This is the only safe way to
    support every available historical year without silently claiming that a
    modern taxonomy is identical to an old syllabus.
    """
    syllabus_code = resolve_code_alias(syllabus_code)
    configs = load_all_subject_configs()
    requested_year = _normalise_year(year)

    # Exact year-specific config first, if a future profile is supplied.
    if requested_year:
        for key in [
            f"{syllabus_code}/{requested_year}",
            f"{level}/{syllabus_code}/{requested_year}" if level else None,
        ]:
            if key and key in configs:
                cfg = configs[key]
                valid, _ = cfg.validate()
                if valid:
                    return _bind_requested_year(cfg, requested_year)

    cfg = None
    if level:
        key = f"{level}/{syllabus_code}"
        if key in configs:
            cfg = configs[key]

    if cfg is None and syllabus_code in configs:
        cfg = configs[syllabus_code]
        if level and cfg.level != level:
            print(
                f"[ConfigLoader] Level mismatch: requested {level} but code "
                f"{syllabus_code} maps to {cfg.level} - STOP"
            )
            return None

    if cfg is None:
        inferred_level = level or infer_level_from_code(syllabus_code)
        key = f"{inferred_level}/{syllabus_code}"
        cfg = configs.get(key)

    if cfg is None:
        return None
    return _bind_requested_year(cfg, requested_year)

def get_subject_folders():
    configs = load_all_subject_configs()
    subjects = set()
    for key, cfg in configs.items():
        if isinstance(cfg, SubjectConfig) and key == cfg.subject:
            subjects.add(cfg.subject)
    return list(subjects)

def get_configs_by_level(level: str) -> Dict[str, 'SubjectConfig']:
    all_configs = load_all_subject_configs()
    result = {}
    seen_subjects = set()
    for key, cfg in all_configs.items():
        if not isinstance(cfg, SubjectConfig):
            continue
        if cfg.level == level and cfg.subject not in seen_subjects:
            result[cfg.subject] = cfg
            seen_subjects.add(cfg.subject)
    return result

def validate_all_configs() -> Tuple[bool, Dict[str, List[str]]]:
    """Validate all configs per requirement 11"""
    all_configs = load_all_subject_configs()
    seen = set()
    errors_by_subject = {}
    overall_valid = True

    for key, cfg in all_configs.items():
        if not isinstance(cfg, SubjectConfig):
            continue
        # Only validate once per subject
        if cfg.subject in seen:
            continue
        seen.add(cfg.subject)

        valid, errs = cfg.validate()
        if not valid:
            errors_by_subject[cfg.subject] = errs
            overall_valid = False
            print(f"[ConfigLoader] {cfg.subject} validation FAILED: {errs}")
        else:
            print(f"[ConfigLoader] {cfg.subject} validated OK - {len(cfg.major_topics)} majors, {len(cfg.detailed_topics)} detailed, years {cfg.syllabus_years}")

    return overall_valid, errors_by_subject
