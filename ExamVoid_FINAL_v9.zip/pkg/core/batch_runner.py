"""Batch orchestrator (Overseer batch-infrastructure spec, Phase 5 — honest
port; the spec text targeted the fictional cambridge_qb.pipeline module).

Main entry point for batch processing:

    preflight (main process, scans input + registers bundles in SQLite)
      -> work queue from the database (resume / retry_failed supported)
      -> bounded worker execution (sequential at workers==1, bounded
         ProcessPoolExecutor otherwise; concurrency clamped by the measured
         RAM guard from pipeline.py so a batch can never OOM itself)
      -> examiner-report attach + final locked audit ONCE over the real
         output tree, after all workers (same shape as pipeline.py S6/S7/S8)
      -> progress report from the database (single source of truth)

Audited deviations from the spec text (receipts in the round evidence log):
  * file homes: cambridge_qb/* does not exist; the port lives in core/.
    root pipeline.py is already the approved efficiency-round orchestrator,
    so this runner is core/batch_runner.py with run_pipeline.py as the CLI.
  * workers never rescan the input directory (pre-built args from the DB)
    and never reload all 23 subject configs.
  * the RAM guard calibration is real (measured worker peaks, RS-2) rather
    than the spec's unchecked use of the requested worker count.
"""

import logging
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

logger = logging.getLogger(__name__)


def _handle_result(result: dict):
    status = result["status"]
    key = result["bundle_key"]

    if status == "complete":
        q = result.get("questions", 0)
        r = result.get("needs_review", [])
        logger.info(f"✅ {key}: {q} questions ({len(r)} need review)")
        print(f"  ✅ {key}: {q} questions ({len(r)} need review)")
    elif status == "already_complete":
        print(f"  ⏭  {key}: already complete (resume-skip)")
    elif status == "failed":
        logger.error(f"❌ {key}: {result.get('error', 'unknown')}")
        print(f"  ❌ {key}: {result.get('error', 'unknown')}")
    elif status == "review_required":
        logger.warning(f"👁  {key}: {result.get('reason', '')}")
        print(f"  👁  {key}: {result.get('reason', '')}")


def _post_run_attach_and_audit(db, output_dir: Path, touched_bundle_keys):
    """ER text attach + ER question crops + final FinalValidator audit —
    once, over the real output tree, after all workers (mirrors pipeline.py's
    approved post-stages)."""
    from .paper_identifier import parse_paper_filename
    from .examiner_report import attach_examiner_reports_to_output
    from .er_question_crops import attach_question_er_crops
    from .output_manager import OutputManager
    from .validation import FinalValidator

    # ER inputs = every ER file this DB knows about (preflight registered
    # them this run or a prior resumed one).
    with db._conn() as conn:
        er_rows = conn.execute("SELECT path FROM files WHERE kind='er'").fetchall()
    er_papers = []
    for row in er_rows:
        info = parse_paper_filename(Path(row["path"]))
        if info is not None:
            er_papers.append(info)

    if er_papers:
        stats = attach_examiner_reports_to_output(er_papers, output_dir)
        print(f"  [ER] text attach: {stats.get('questions_attached', 0)} questions"
              + (f", errors={stats['errors'][:2]}" if stats.get("errors") else ""))
        stats2 = attach_question_er_crops(er_papers, output_dir)
        print(f"  [ER] crops: {stats2.get('crops_written', 0)} written / "
              f"{stats2.get('verified', 0)} verified"
              + (f", errors={stats2['errors'][:2]}" if stats2.get("errors") else ""))
        _sync_er_artifacts(db, output_dir)
    else:
        print("  [ER] no ER papers supplied — stage skipped by design")

    removed = OutputManager(output_root=output_dir, target_width=2280, quality=95) \
        .cleanup_empty_and_invalid_folders()
    if removed:
        print(f"  [audit] cleanup removed {len(removed)} invalid folders")
    result = FinalValidator(output_root=str(output_dir)).validate_all()
    print(f"  [audit] final validation: {'PASSED' if result['passed'] else 'FAILED'} "
          f"(errors={result.get('total_errors', 0)})")
    return result


def _sync_er_artifacts(db, output_dir: Path):
    """Post-attach bookkeeping: ER crops land in question folders AFTER the
    worker's commit-time artifact registration, so they would otherwise be
    invisible to the artifacts table. Register any *_ER*.webp whose path is
    not already recorded (idempotent; DB remains the single truth).
    """
    from PIL import Image
    output_dir = Path(output_dir)
    with db._conn() as conn:
        known = {r["path"] for r in conn.execute("SELECT path FROM artifacts")}
        qrows = {r["folder_path"]: r["id"] for r in conn.execute("SELECT id, folder_path FROM questions")}
    added = 0
    for webp in output_dir.rglob("*_ER*.webp"):
        rel = str(webp.relative_to(output_dir))
        if rel in known:
            continue
        q_id = qrows.get(str(webp.parent.relative_to(output_dir)))
        if q_id is None:
            continue
        try:
            with Image.open(webp) as im:
                w, h = im.size
        except Exception:
            w = h = None
        db.register_artifact(question_id=q_id, kind="er", path=rel,
                             width_px=w, height_px=h, file_size=webp.stat().st_size)
        added += 1
    if added:
        print(f"  [ER] artifacts registered post-attach: {added} ER crop rows")


def run_pipeline(
    pdf_dir: str,
    output_dir: str,
    topics_dir: str = "topics",
    workers: int = None,
    resume: bool = True,
    retry_failed: bool = False,
    dry_run: bool = False,
    low_ram: bool = True,
    full_auto: bool = False,
) -> dict:
    """
    Main entry point for batch processing.

    Args:
        pdf_dir:      Input directory containing PDFs
        output_dir:   Output directory for question bank
        topics_dir:   Accepted for spec-signature compatibility; the real
                      system resolves approved subject configs from
                      subjects/<Level>/<Subject>/config.json.
        workers:      Number of parallel workers (default: cpu_count // 2,
                      RAM-guard clamped)
        resume:       skip bundles the DB already marks complete (the DB is
                      queried for pending/failed work only, so a completed
                      bundle never re-runs unless retried)
        retry_failed: Re-attempt previously failed bundles
        dry_run:      Run preflight only, no processing
        low_ram:      Route QP cropping through the RAM-safe streaming path
                      (required on this 2GB box)

    Returns a summary dict (also printed).
    """
    import os
    from .database import Database
    from .preflight import Preflight
    from .bundle_worker import process_bundle

    pdf_dir = Path(pdf_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if workers is None:
        workers = 6  # user-requested default (2026-08-14); RAM guard clamps down safely

    # ── Initialise database ─────────────────────────
    db_path = output_dir / "pipeline.sqlite"
    db = Database(db_path)

    # ── Run preflight ───────────────────────────────
    preflight = Preflight(pdf_dir, output_dir, db)
    preflight._check_ram(workers)
    new_bundles = preflight.run()

    if dry_run:
        print("Dry run complete. No processing performed.")
        db.print_progress()
        return {"dry_run": True, "new_bundles": new_bundles}

    # ── Get work queue ──────────────────────────────
    if retry_failed:
        # Reset failed bundles to pending
        with db._conn() as conn:
            conn.execute("""
                UPDATE bundles
                SET    status='pending'
                WHERE  status='failed'
                AND    attempts < 3
            """)

    pending = db.get_pending_bundles()
    if not resume:
        # resume=False: force every known bundle back to pending
        with db._conn() as conn:
            conn.execute("UPDATE bundles SET status='pending'")
        pending = db.get_pending_bundles()

    if not pending:
        # Resume must still report unresolved state.  The old early return
        # treated a tree containing review_required bundles as clean simply
        # because there was no pending work left in SQLite.
        with db._conn() as conn:
            rows = conn.execute(
                "SELECT status, COUNT(*) AS n FROM bundles GROUP BY status"
            ).fetchall()
        counts = {str(row["status"]): int(row["n"]) for row in rows}
        review_existing = counts.get("review_required", 0)
        failed_existing = counts.get("failed", 0)
        unresolved = counts.get("pending", 0) + counts.get("processing", 0)
        if unresolved:
            failed_existing += unresolved
            print(f"Found {unresolved} bundle(s) still pending/processing; "
                  "failing closed instead of reporting a clean resume.")

        print("No bundles to process.")
        audit = None
        if counts.get("complete", 0) or review_existing:
            audit = _post_run_attach_and_audit(db, output_dir, [])
        db.print_progress()
        return {
            "processed": 0,
            "complete": counts.get("complete", 0),
            "failed": failed_existing,
            "review_required": review_existing,
            "new_bundles": new_bundles,
            "results": [],
            "audit_passed": (audit or {}).get("passed"),
        }

    # Measured RAM guard (pipeline.py): clamp concurrency, loudly.
    try:
        from pipeline import available_mem_mb, guard_decision
        conc, reasons = guard_decision(workers, available_mem_mb())
        for r in reasons:
            print(f"[batch] {r}")
    except Exception:
        conc = max(1, workers)

    print(
        f"Processing {len(pending)} bundles "
        f"with {conc} workers..."
    )
    print(f"[batch] QP path: {'RAM-SAFE streaming (--low-ram)' if low_ram else 'production CroppingEngine'}")
    print(f"[batch] staging: {output_dir}/.staging/ (final output touched only at commit)")

    # ── Build args for workers ──────────────────────
    # Workers receive pre-built args dicts.
    # They do NOT rescan the input directory.
    args_list = []
    for row in pending:
        args_list.append({
            "bundle_key": row["bundle_key"],
            "bundle_id": row["id"],
            "qp_path": row["qp_path"],
            "ms_path": row["ms_path"],
            "er_path": row["er_path"],
            "output_dir": str(output_dir),
            "db_path": str(db_path),
            "syllabus_code": row["syllabus_code"],
            "subject": row["subject"],
            "level": row["level"],
            "season": row["season"],
            "year": row["year"],
            "component": row["component"],
            "paper_format": row["paper_format"],
            "topics_dir": topics_dir,
            "low_ram": low_ram,
            "full_auto": full_auto,
            "quiet_worker": conc > 1,
        })

    # ── Process with bounded pool ───────────────────
    start_time = time.time()
    complete = 0
    failed = 0
    review = 0
    results = []

    def _record(result):
        """Record one isolated-worker result without letting a dead child kill
        the parent batch controller."""
        nonlocal complete, failed, review
        _handle_result(result)
        results.append(result)
        complete += result["status"] == "complete"
        failed += result["status"] == "failed"
        review += result["status"] == "review_required"

    def _worker_failure(args, exc):
        error = f"isolated worker exception: {exc}"
        # A SIGKILL/BrokenProcessPool can happen before the child gets to its
        # normal exception handler.  Repair the DB lifecycle in the parent so
        # the bundle is retryable instead of remaining PROCESSING forever.
        try:
            from .database import Database
            Database(args["db_path"]).mark_bundle_failed(
                args["bundle_id"], error
            )
        except Exception as db_exc:
            error += f"; parent DB repair failed: {db_exc}"
        return {
            "status": "failed",
            "bundle_key": args["bundle_key"],
            "error": error,
        }

    def _one_isolated(args):
        """Run exactly one bundle in a disposable process.

        Calling process_bundle directly for workers=1 kept all PDF/rendering
        allocations in the parent process. That was the reason a mixed IGCSE
        batch could finish 0580 and then be killed while starting 0625. The
        process boundary is now used even for one-worker runs.
        """
        with ProcessPoolExecutor(max_workers=1) as pool:
            try:
                return pool.submit(process_bundle, args).result()
            except Exception as exc:
                return _worker_failure(args, exc)

    if conc == 1:
        # One disposable worker per bundle.  The child dies before the next
        # paper, returning PyMuPDF/Pillow/native allocator memory to the OS.
        for args in args_list:
            _record(_one_isolated(args))
    else:
        try:
            from tqdm import tqdm
            use_tqdm = True
        except ImportError:
            use_tqdm = False

        # Recycle every worker after one bundle where supported.  This keeps
        # long 300+ file runs from accumulating native PDF/image allocations.
        import inspect
        pool_kwargs = {"max_workers": conc}
        if "max_tasks_per_child" in inspect.signature(ProcessPoolExecutor).parameters:
            pool_kwargs["max_tasks_per_child"] = 1
        with ProcessPoolExecutor(**pool_kwargs) as pool:
            futures = {
                pool.submit(process_bundle, args): args
                for args in args_list
            }
            pbar = None
            if use_tqdm:
                from tqdm import tqdm as _tqdm
                pbar = _tqdm(total=len(futures), desc="Processing", unit="paper")

            for future in as_completed(futures):
                args = futures[future]
                try:
                    result = future.result()
                except Exception as exc:
                    result = _worker_failure(args, exc)
                _record(result)

                if use_tqdm and pbar is not None:
                    pbar.set_postfix({
                        "ok": complete,
                        "fail": failed,
                        "review": review,
                    })
                    pbar.update(1)
            if pbar is not None:
                pbar.close()

    # ── ER attach + final audit (once, parent side) ──
    audit = None
    if complete + review > 0:
        audit = _post_run_attach_and_audit(db, output_dir, [a["bundle_key"] for a in args_list])

    # SQLite is the source of truth after workers finish.  Include review or
    # failed bundles left by an earlier run; only counting this invocation's
    # futures made resume capable of printing a false clean result.
    with db._conn() as conn:
        final_rows = conn.execute(
            "SELECT status, COUNT(*) AS n FROM bundles GROUP BY status"
        ).fetchall()
    final_counts = {str(row["status"]): int(row["n"]) for row in final_rows}
    review = final_counts.get("review_required", review)
    failed = final_counts.get("failed", failed)
    unresolved = final_counts.get("pending", 0) + final_counts.get("processing", 0)
    if unresolved:
        failed += unresolved
        print(f"  {unresolved} bundles remain pending/processing; treating run as failed.")

    # ── Final report ────────────────────────────────
    elapsed = time.time() - start_time
    mins = int(elapsed // 60)
    secs = int(elapsed % 60)

    print(f"\nBatch complete in {mins}m {secs}s")
    db.print_progress()

    if failed > 0:
        print(
            f"  {failed} failed bundles. "
            f"Run with --retry-failed to retry."
        )

    if review > 0:
        print(
            f"  {review} bundles need manual review. "
            f"Check output tree + .staging/ worker logs."
        )

    return {
        "processed": len(args_list),
        "complete": complete,
        "failed": failed,
        "review_required": review,
        "new_bundles": new_bundles,
        "results": results,
        "audit_passed": (audit or {}).get("passed"),
    }
