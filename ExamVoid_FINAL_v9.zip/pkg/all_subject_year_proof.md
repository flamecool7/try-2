# Subject/year proof run

Date: 2026-08-12

This is a real-fixture proof, not a claim that every Cambridge PDF layout has
been exhaustively tested.

## Fixture matrix exercised

The shipped fixture manifest supplied 19 QP/MS bundles across 9 subject codes:

- IGCSE: 0580, 0610, 0620, 0625
- A-Level: 9618, 9700, 9701, 9702, 9709
- Fixture years: 2015, 2016, and 2023
- MCQ, structured, multipage, portrait/landscape, Practical Test, and
  Alternative-to-Practical mark-scheme layouts

## Final result after fixes

```text
19 bundles discovered
8 clean bundles
11 review_required bundles
0 failed bundles
378 questions recorded as saved
0 loading directories
0 Uncategorized directories
```

The first matrix pass exposed a real 9709 classification-name mismatch:
`Energy,_work_and_power` in the uploaded reference did not match the flattened
configured folder key `Energy_work_and_power`. That was fixed and the failed
9709_s15_42 bundle was retried successfully:

```text
9709_s15_42: 7 questions, 0 need review
```

The final matrix command returned exit code `2`, which is correct because some
questions/bundles require review. It did not return code `1` and no bundle
remained failed.

## IGCSE Chemistry component proof

Separate real 0620 May/June 2024 runs were also completed:

```text
Paper 4: variants 41/42/43 — 7/6/7 questions, 0 review, exit 0
Paper 5: variant 51 — 5 questions saved, review_required because 2 QP items
        had no MS twin; variants 52/53 — 3/3 questions, 0 review, exit 0
Paper 6: variants 61/62/63 — 4/4/4 questions, 0 review, exit 0
```

All nine 0620 Practical/Alternative-to-Practical bundles completed without a
failed bundle. Paper 5 variant 51 was correctly held for review because its
supplied QP/MS pair did not cover the same question set; it was not silently
paired or marked complete. Papers 5 and 6 use profile-driven structured QP/MS
processing and are no longer rejected at strategy selection.

## What this proves

- The current configured subject profiles can process real papers across the
  fixture years without a paper-level crash.
- Review status is surfaced instead of being reported as clean.
- Crops are preserved for review-required questions.
- The all-year policy allows an undeclared year to process, but binds it to
  `SYLLABUS_YEAR_UNVERIFIED` and prevents clean completion.

## What it does not prove

- It does not cover all 24 configured subject codes with real fixtures.
- It does not cover every Cambridge syllabus edition or every future year.
- A review-required result is not proof of automatic topic correctness.
- Official syllabus profiles for every historical edition still need to be
  pinned before those editions can be marked clean automatically.
