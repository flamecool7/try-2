# Examiner Report System Lock

The Examiner Report implementation is read-only. Topic and folder routing must not
change report discovery, exact-paper verification, parsing, question matching, report
content, report naming, report placement, or report validation.

## Baseline verification

`core/examiner_report_gold.py` remains byte-for-byte identical to the original
downloaded project archive. `core/examiner_report.py` contains the approved ER-only
integration addition: strict metadata-to-report matching and validated creation of
`examiner_report.txt` for files identified by the `_er` suffix.

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `7fa54fbd8242139b0a58c60fedf45dc674ba4ed530f1453f0d45080503fab528` |
| `core/examiner_report_gold.py` | `7750c213d4b1ce71225d44d13d77f7dcd19274c6a1f787c4855db599d9782b08` |

## Routing compatibility verification

The existing main-pipeline integration locates each processed question through its
own `metadata.json` and writes `examiner_report.txt` to `json_path.parent`. Therefore
an exact-topic-folder rename or routing change does not change the report's question
association: the report remains in that question's actual folder. No examiner-report
code was changed.

An end-to-end extraction test requires a real matching Examiner Report PDF; no such
PDF is present in the supplied workspace. When one is supplied, the existing strict
matching pipeline remains responsible for accepting or rejecting it.

## Amendment ER-1 (2026-08-10): Merged ER engine v1.1 — authorised by the maintainer

The maintainer approved (`er_approach=merge`) upgrading `core/examiner_report.py` in
place to the layered spec engine (ERPdfLoader / ERCleaner / ERSectionSplitter /
ERQuestionParser / ERMatcher / ERWriter), keeping the strict matcher and the existing
main.py integration points unchanged. `core/examiner_report_gold.py` remains
byte-for-byte identical to the original archive (verified).

Maintainer decisions folded into the merge:
- **Fallback = "if there is no er continue process"** (maintainer's custom decision;
  supersedes the spec's 4-file Invariant 6). No placeholder files are written when no
  ER exists or no question-specific commentary is found; the pipeline continues.
- **Artifacts = text + webp**: keep `_ER.webp` rendering and additionally write
  `examiner_report.txt` (question-specific) / `examiner_report_full.txt` (general).

Documented spec fixes applied during reconstruction: question-header pattern A
(`Question 1` / `Q1` forms), bare page numbers stripped only at page edges, sub-part
header groups use `[ \t]*` (never `\s*` — it ate next-line `(a)` labels), section
titles line-anchored (`re.MULTILINE`), hyphen healing across page breaks
(`([a-z])-\n(?:[ \t]*\n)*([a-z])`). Also fixed two latent bugs: dead `.organize`
import (-> `.output_manager`) and `_source_doc_for` so the webp renders from the
MATCHED report document instead of `parsed_docs[0]`.

Evidence: 56/56 checks green (`test-crops/er-tests/run_er_tests.py`) against the real
`9709_s22_er_paper11_pages.pdf`; sample artifacts in `test-crops/er-tests/sample-output/`.
Status values: `written` / `general_fallback` / `no_verified_er` / `skipped_no_content`.

### Updated SHA-256 (Amendment ER-1)

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `83fe747ec1ab02e06f0e10884925e6434e7533e8ef53f6af57acb2872fc2eff6` |
| `core/examiner_report_gold.py` | `7750c213d4b1ce71225d44d13d77f7dcd19274c6a1f787c4855db599d9782b08` (unchanged) |

## Amendment ER-2 (2026-08-10): Grouped question headers + per-question ER crops — authorised by the maintainer

Two parts:

1. **`core/examiner_report.py`** — question-header detection extended with the
   `grouped_range` pattern ("Questions 1-10" grouped ranges, MCQ style) inside
   `QUESTION_HEADER_PATTERNS`; consumed by both ER text attach and the new crop
   module. No other behavioural change; ER text pipeline re-verified 56/56.
2. **NEW module `core/er_question_crops.py`** (additive; locked gold files
   untouched) — per-question ER boundary crops written into each question folder
   as `{variant}_{Season}_{Year}_Q{n}_ER.webp` (e.g. `41_Winter_2025_Q5_ER.webp`),
   2280px wide, 150dpi streamed renders, `save_webp` quality 95. Every crop is
   verified by text containment (subpart-line normalisation) before write; no
   placeholders are ever emitted. Wired into `main.py` after
   `attach_examiner_reports_to_output` inside try/except (failure never fatal to
   the pipeline).

Documented spec-bug fixes applied during reconstruction (the supplied spec again
described a nonexistent codebase): component scoping ("Paper 9700/22" inside
multi-component ER booklets), locked import of `QUESTION_HEADER_PATTERNS`
(including `grouped_range`), guarded bare-number matching, line-anchored header
matching, streamed (not list-held) 150dpi page renders, q95 webp tiling, and
text-containment verification.

Evidence: 56/56 ER suite green; m25 full-pipeline runs — 6/6 crops written and
verified on m25 v2 and v3 (`test-crops/m25-proof-v3/M25_V3_TEST_RUN_pack.html`).

### Updated SHA-256 (Amendment ER-2)

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `972e68d3dc6085b6852e3f266f28665692887aeaa5867c1fcd91d5130e1ce9ac` |
| `core/er_question_crops.py` | `b93ad5f2b4bb83a4f428671cb60a151900fa133ec2046692b828059cc5cc50b8` (new module) |
| `core/examiner_report_gold.py` | `7750c213d4b1ce71225d44d13d77f7dcd19274c6a1f787c4855db599d9782b08` (unchanged) |

## Amendment ER-3 (2026-08-10): Subject-level full-report placement for QP-only trees + mixed-tree ordering fix — authorised by the maintainer

Part of the RS-5 (Uncategorized) round: QP-only trees have no paper-type folder.
1. `examiner_report_full.txt` previously required a paper-type folder, so on
   QP-only trees it had nowhere to land. The subject folder is now captured at
   registration and, when no paper-type folder exists, the full report writes at
   SUBJECT level with a loud print.
2. ER-3b (same amendment): on mixed trees the stored paper-type folder is
   upgraded when a later classified json reveals that directory, so the full
   report lands beside the question folders instead of being orphaned at subject
   level.

Strict matcher, discovery, parsing, question matching, report content, naming,
placement of question-specific commentary and the per-question ER crops are all
unchanged. `core/er_question_crops.py` byte-untouched; `core/examiner_report_gold.py`
byte-untouched.

Evidence: T1 QP-only real-tree run (9700 m25 qp+er, no MS) — full report at
subject level, per-question commentary still attached inside the Uncategorized
question folders, validator ALL GREEN; mixed-tree ordering unit green
(test-crops/eff-bench logs, UNCATEGORIZED_IMPLEMENTATION.md).

### Updated SHA-256 (Amendment ER-3)

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `44a7dd8235d2d9d37beec758c6b2e38f434009369196524b401096eb386be247` (was `972e68d3…`) |
| `core/er_question_crops.py` | `b93ad5f2b4bb83a4f428671cb60a151900fa133ec2046692b828059cc5cc50b8` (unchanged) |
| `core/examiner_report_gold.py` | `e4f29c597490b86002227971743339b944adec09ecc4aaa6329ee7702ab2880f` (unchanged) |

---

## RS-17/18 (2026-08-12) — taxonomy + mega-spec amendments touching this lock's files — standing pre-approval

Full receipts: `test-crops/redesign/RS161718_ROUND_EVIDENCE.md` (§2–§3).

| `core/examiner_report.py` | `6acf5fd5f1868e94fbac93a0817f326739b8a8a0a28640109b0a8d6e2df5d5d3` | (was `44a7dd8235d2d9d3…`)

---

## RS-18b (2026-08-12) — ER tile-cache tempdir cleanup — standing pre-approval

Same round as ROUTING_STATE_LOCK RS-18b: cached tile tempdirs are tracked in
`_ER_TILE_DIRS` and dropped by `clear_er_tile_cache()` after the ER stages.

| `core/examiner_report.py` | `d67af641789fbce9816a5921b6a6791a1536b45588a9ea0a0ad0767ceb5292ff` | (was 6acf5fd5f1868e94…) |
