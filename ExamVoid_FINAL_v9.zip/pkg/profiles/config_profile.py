"""Config-backed subject profiles.

The production classifier uses ``subjects/*/config.json`` as its single
source of syllabus truth.  This adapter gives the formal ``ProfileRegistry``
a real, inspectable profile for every validated configuration without
copying taxonomy data into one profile module per subject.
"""
from __future__ import annotations

from typing import Optional

from .base_profile import ComponentSpec, MSStrategy, PaperFormat, SubjectProfile


class ConfigBackedProfile(SubjectProfile):
    """Small profile adapter generated from one validated SubjectConfig."""

    def __init__(self, config):
        components = []
        # Cambridge component codes are paper number + variant.  The profile
        # adapter covers the normal 1..7 / variants 1..3 space; the actual
        # input identity and strategy registries remain authoritative at run
        # time.  This is deliberately metadata, not a routing fallback.
        try:
            from core.mcq_registry import is_mcq
        except Exception:
            is_mcq = lambda _code, _component: False

        for paper in range(1, 8):
            for variant in range(1, 4):
                code = f"{paper}{variant}"
                fmt = (PaperFormat.MCQ if is_mcq(config.syllabus_code, code)
                       else PaperFormat.STRUCTURED)
                strategy = (MSStrategy.MCQ_GRID if fmt is PaperFormat.MCQ
                            else MSStrategy.STRUCTURED)
                components.append(ComponentSpec(
                    component_code=code,
                    paper_number=paper,
                    variant=variant,
                    paper_format=fmt,
                    ms_strategy=strategy,
                ))

        super().__init__(
            syllabus_code=config.syllabus_code,
            subject=config.subject,
            qualification=config.level,
            valid_years=[str(year) for year in config.syllabus_years],
            components=components,
            taxonomy_path=str(config.config_path or ""),
            has_er=True,
        )
        self.config = config

    def get_component(self, variant: str) -> Optional[ComponentSpec]:
        return self._component_map.get(str(variant))

    def get_paper_format(self, variant: str) -> PaperFormat:
        component = self.get_component(variant)
        if component is None:
            # Unknown components are not asserted as supported by this
            # adapter.  The runtime strategy selector will fail closed.
            raise ValueError(
                f"Unknown component {variant!r} for {self.syllabus_code}"
            )
        return component.paper_format

    def get_ms_strategy(self, variant: str) -> MSStrategy:
        component = self.get_component(variant)
        if component is None:
            raise ValueError(
                f"Unknown component {variant!r} for {self.syllabus_code}"
            )
        return component.ms_strategy
