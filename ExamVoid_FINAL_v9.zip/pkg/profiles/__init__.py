"""Subject profiles — pluggable per-syllabus knowledge for the engine."""
