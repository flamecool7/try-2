"""Abstract base class for all subject profiles.

Overseer rebuild spec (Phase 1, Step 1), adapted to this repo:

* Import root is the top-level ``profiles`` package (the spec's
  ``cambridge_qb.`` prefix is a mechanical path alias; ``original_reference/
  cambridge_qb/`` is an archive and must stay pristine).
* ``taxonomy_path`` is informational only. Topic/taxonomy data has exactly ONE
  source of truth in this system: the locked per-subject
  ``subjects/{Level}/{Subject}_{code}/config.json`` (23 files, byte-verified
  against the shipped zip). Profiles never duplicate it; use
  :meth:`SubjectProfile.load_config` to reach it through the locked
  ``core.config_loader`` (mtime-keyed cache, RS-4).
* ``SubjectProfile`` is a plain ABC whose ``__init__`` takes the spec's
  keyword set. (The spec decorated the ABC with @dataclass AND showed
  subclasses calling ``super().__init__(syllabus_code=..., components=[...])``;
  a generated dataclass __init__ plus a custom subclass __init__ is needlessly
  fragile — plain assignment keeps the exact call shape the spec example uses.)

Locks honoured: nothing here touches the question_split triplet, the MS
engine, converter render settings, webp settings, or any config.json.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


class PaperFormat(Enum):
    MCQ = "mcq"
    STRUCTURED = "structured"
    ESSAY = "essay"
    PRACTICAL = "practical"
    ATP = "alternative_to_practical"
    INSERT = "insert"
    COURSEWORK = "coursework"


class MSStrategy(Enum):
    MCQ_GRID = "mcq_grid"
    STRUCTURED = "structured"
    LEVELS_BASED = "levels_based"
    POINT_BASED = "point_based"
    NONE = "none"


@dataclass
class ComponentSpec:
    component_code: str                      # e.g. "11", "12", "22", "42"
    paper_number: int                        # e.g. 1, 2, 4
    variant: int                             # e.g. 1, 2, 3
    paper_format: PaperFormat
    ms_strategy: MSStrategy
    has_insert: bool = False
    question_count: Optional[int] = None
    total_marks: Optional[int] = None


class SubjectProfile(ABC):
    def __init__(
        self,
        syllabus_code: str,
        subject: str,
        qualification: str,                  # "A-Level", "IGCSE", "O-Level"
        valid_years: List[str],              # ["2019", ..., "2025"]
        components: List[ComponentSpec],
        taxonomy_path: str,                  # informational (see module docstring)
        has_er: bool = True,
    ) -> None:
        self.syllabus_code = str(syllabus_code)
        self.subject = subject
        self.qualification = qualification
        self.valid_years = list(valid_years)
        self.components = list(components)
        self.taxonomy_path = taxonomy_path
        self.has_er = has_er
        self._component_map: Dict[str, ComponentSpec] = {
            c.component_code: c for c in self.components
        }

    # -- abstract per-spec ------------------------------------------------
    @abstractmethod
    def get_component(self, variant: str) -> Optional[ComponentSpec]:
        ...

    @abstractmethod
    def get_paper_format(self, variant: str) -> PaperFormat:
        ...

    @abstractmethod
    def get_ms_strategy(self, variant: str) -> MSStrategy:
        ...

    # -- concrete per-spec ------------------------------------------------
    def is_valid_year(self, year: str) -> bool:
        return year in self.valid_years

    def is_mcq(self, variant: str) -> bool:
        return self.get_paper_format(variant) == PaperFormat.MCQ

    # -- repo adapter (additive; single source of truth stays config.json) --
    def load_config(self):
        """Return this subject's locked ``core.config_loader.SubjectConfig``.

        Uses the real loader signature
        ``load_subject_config_by_code_and_level(syllabus_code, level=None,
        year=None)`` with its RS-4 mtime-keyed cache. Raises loudly if the
        subject is not configured (a profile without config data is a wiring
        error — spec rule 2 requires a real fixture before "supported").
        """
        from core.config_loader import load_subject_config_by_code_and_level
        cfg = load_subject_config_by_code_and_level(
            self.syllabus_code, self.qualification
        )
        if cfg is None:
            raise FileNotFoundError(
                f"[profiles] no subjects/ config.json for {self.syllabus_code} "
                f"({self.qualification}) — profile '{type(self).__name__}' cannot "
                f"be considered supported until config + a real paper fixture exist."
            )
        return cfg
