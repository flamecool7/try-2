"""Registry of validated Cambridge subject profiles.

The topic taxonomy remains exclusively in ``subjects/*/config.json``.  The
registry now builds a concrete metadata adapter for every validated config, so
``ProfileRegistry.load_all_profiles()`` is no longer an empty placeholder and
coverage can be inspected without maintaining 23 duplicated profile modules.
"""
from __future__ import annotations

import importlib
from typing import Dict, List, Optional

from .base_profile import SubjectProfile


class ProfileRegistry:
    _profiles: Dict[str, SubjectProfile] = {}
    _loaded = False

    # Optional extension modules may self-register additional profiles.  The
    # config-backed adapter below covers the shipped matrix; a listed module
    # that fails to import remains a loud wiring error.
    _PROFILE_MODULES: List[str] = [
        "profiles.config_profile",
    ]

    @classmethod
    def reset(cls) -> None:
        """Test hook: clear all registrations and permit a fresh load."""
        cls._profiles = {}
        cls._loaded = False

    @classmethod
    def register(cls, profile: SubjectProfile) -> None:
        cls._profiles[profile.syllabus_code] = profile

    @classmethod
    def _ensure_loaded(cls) -> None:
        if not cls._loaded:
            cls.load_all_profiles()

    @classmethod
    def get(cls, syllabus_code: str) -> Optional[SubjectProfile]:
        cls._ensure_loaded()
        return cls._profiles.get(str(syllabus_code))

    @classmethod
    def is_supported(cls, syllabus_code: str) -> bool:
        cls._ensure_loaded()
        return str(syllabus_code) in cls._profiles

    @classmethod
    def all_codes(cls) -> List[str]:
        cls._ensure_loaded()
        return sorted(cls._profiles.keys())

    @classmethod
    def load_all_profiles(cls) -> int:
        """Load extension profiles and one adapter for every valid config.

        Returns the number of registered syllabus codes.  A malformed config
        is already rejected by ``core.config_loader`` and therefore cannot be
        advertised as a supported profile.
        """
        if cls._loaded:
            return len(cls._profiles)

        for name in cls._PROFILE_MODULES:
            importlib.import_module(name)
            if name != "profiles.config_profile":
                print(f"[profiles] loaded {name}")

        from .config_profile import ConfigBackedProfile
        from core.config_loader import load_all_subject_configs

        configs = load_all_subject_configs()
        seen = set()
        for key, config in configs.items():
            code = str(getattr(config, "syllabus_code", ""))
            if len(code) != 4 or code in seen:
                continue
            seen.add(code)
            cls.register(ConfigBackedProfile(config))

        cls._loaded = True
        print(f"[profiles] loaded {len(cls._profiles)} config-backed profiles")
        return len(cls._profiles)
