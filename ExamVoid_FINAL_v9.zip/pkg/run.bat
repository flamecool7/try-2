@echo off
setlocal EnableExtensions DisableDelayedExpansion

REM This file may be double-clicked or called from any current directory.
REM Work only from the directory that contains this launcher.
set "PROJECT_DIR=%~dp0"
cd /d "%PROJECT_DIR%"
if errorlevel 1 goto DIRECTORY_ERROR
set "PROJECT_DIR=%CD%"

REM The existing application entry point is main.py. Do not continue if this
REM launcher has been separated from the extracted project.
if not exist "%PROJECT_DIR%\main.py" goto MAIN_NOT_FOUND

REM Prefer the project's existing virtual environment. No environment is created
REM and no packages are installed by this launcher.
set "PYTHON_EXE="
set "PYTHON_ARGS="
if exist "%PROJECT_DIR%\.venv\Scripts\python.exe" set "PYTHON_EXE=%PROJECT_DIR%\.venv\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%PROJECT_DIR%\venv\Scripts\python.exe" set "PYTHON_EXE=%PROJECT_DIR%\venv\Scripts\python.exe"

REM If this project has no virtual environment, use an installed Python 3
REM launcher/runtime without hard-coding a machine-specific installation path.
if defined PYTHON_EXE goto CHECK_PYTHON
for /f "delims=" %%P in ('where py.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
if defined PYTHON_EXE set "PYTHON_ARGS=-3"
if defined PYTHON_EXE goto CHECK_PYTHON
for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
if not defined PYTHON_EXE goto PYTHON_ERROR

:CHECK_PYTHON
"%PYTHON_EXE%" %PYTHON_ARGS% --version
if errorlevel 1 goto PYTHON_ERROR

REM Double-click / no-argument mode now runs the recommended batch command
REM automatically. Use --menu to open the old interactive launcher.
REM Command-line use still preserves application arguments exactly.
if /I "%~1"=="--menu" goto MENU
if "%~1"=="" goto AUTO_RUN
if not "%~1"=="" goto COMMAND_LINE

:AUTO_RUN
REM ──────────────────────────────────────────────────────────────
REM Auto RAM profile (2026-08-14): the batch must "just work" on the
REM machine it is run on. Detect total physical RAM, pick the profile:
REM   >=16 GB : full-speed (production crop path, up to 6 workers)
REM   12-15 GB: balanced (RAM-safe streaming, 4 workers)
REM   <12 GB  : low-RAM  (RAM-safe streaming, 2 workers; 8GB machines)
REM The Python side RAM-guards concurrency again at launch time
REM (pipeline.guard_decision) and clamps further if memory is tight.
set "TOTAL_RAM_GB="
for /f "delims=" %%B in ('powershell -NoProfile -Command "try { [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB) } catch { 8 }" 2^>nul') do set "TOTAL_RAM_GB=%%B"
echo %TOTAL_RAM_GB%| findstr /r "^[0-9][0-9]*$" >nul || set "TOTAL_RAM_GB=8"
set "PROFILE_FLAGS="
set "PROFILE_LABEL="
if %TOTAL_RAM_GB% GEQ 16 (
    set "PROFILE_FLAGS=--performance --workers 6"
    set "PROFILE_LABEL=%TOTAL_RAM_GB% GB detected: full-speed profile"
) else if %TOTAL_RAM_GB% GEQ 12 (
    set "PROFILE_FLAGS=--workers 4"
    set "PROFILE_LABEL=%TOTAL_RAM_GB% GB detected: balanced profile (RAM-safe)"
) else (
    set "PROFILE_FLAGS=--workers 2"
    set "PROFILE_LABEL=%TOTAL_RAM_GB% GB detected: low-RAM profile (RAM-safe streaming)"
)
REM ──────────────────────────────────────────────────────────────
if not exist "%PROJECT_DIR%\input\*.pdf" (
    echo [ERROR] No PDF files were found in "%PROJECT_DIR%\input".
    echo Add matching QP and MS PDFs, then run run.bat again.
    echo Use run.bat --menu if you want the interactive launcher.
    goto FATAL
)
echo ================================================================
echo  ExamVoid Topical Generator
echo ================================================================
echo  Auto-running %PROFILE_LABEL%
echo    python run_pipeline.py --input input --output output %PROFILE_FLAGS% --fetch-missing-ms
echo.
"%PYTHON_EXE%" %PYTHON_ARGS% "%PROJECT_DIR%\run_pipeline.py" --input "%PROJECT_DIR%\input" --output "%PROJECT_DIR%\output" %PROFILE_FLAGS% --fetch-missing-ms
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" (
    echo.
    echo [OK] Batch completed successfully. Opening "%PROJECT_DIR%\output".
    start "" "%PROJECT_DIR%\output"
    goto EXIT
)
if "%APP_EXIT%"=="2" (
    echo.
    echo [WARN] Batch completed with review_required items. Opening "%PROJECT_DIR%\output".
    start "" "%PROJECT_DIR%\output"
    goto EXIT
)
call :APPLICATION_ERROR %APP_EXIT%
goto EXIT

:MENU
cls
echo ================================================================
echo  ExamVoid Topical Generator
 echo ================================================================
echo  Project folder: %PROJECT_DIR%
echo  Python runtime:  %PYTHON_EXE% %PYTHON_ARGS%
echo.
echo  [1] Run using PDFs in input\
echo  [2] Demo all configured subjects
echo  [3] Demo core subjects
echo  [4] Clean output and run input PDFs
echo  [5] Validate existing output
echo  [6] Validate subject configurations
echo  [7] Show project paths
echo  [8] Exit
echo.
set "CHOICE="
set /p "CHOICE=Choose an option (1-8): "
if "%CHOICE%"=="1" goto RUN_INPUT
if "%CHOICE%"=="2" goto RUN_DEMO_ALL
if "%CHOICE%"=="3" goto RUN_DEMO_CORE
if "%CHOICE%"=="4" goto RUN_CLEAN
if "%CHOICE%"=="5" goto RUN_VALIDATE
if "%CHOICE%"=="6" goto RUN_CONFIGS
if "%CHOICE%"=="7" goto SHOW_PATHS
if "%CHOICE%"=="8" goto EXIT
echo Invalid option.
pause
goto MENU

:RUN_INPUT
if not exist "%PROJECT_DIR%\input\*.pdf" (
    echo [ERROR] No PDF files were found in "%PROJECT_DIR%\input".
    echo Add matching QP and MS PDFs, then choose option 1 again.
    pause
    goto MENU
)
call :RUN_BATCH --input "%PROJECT_DIR%\input" --output "%PROJECT_DIR%\output" %PROFILE_FLAGS% --fetch-missing-ms
goto MENU

:RUN_DEMO_ALL
call :RUN_APPLICATION --input "%PROJECT_DIR%\input" --output "%PROJECT_DIR%\output" --demo --demo-all --clean --validate
goto MENU

:RUN_DEMO_CORE
call :RUN_APPLICATION --input "%PROJECT_DIR%\input" --output "%PROJECT_DIR%\output" --demo --clean --validate
goto MENU

:RUN_CLEAN
set "CONFIRM="
set /p "CONFIRM=Delete generated output and run input PDFs? (Y/N): "
if /I not "%CONFIRM%"=="Y" goto MENU
call :RUN_BATCH --input "%PROJECT_DIR%\input" --output "%PROJECT_DIR%\output" --clean %PROFILE_FLAGS% --fetch-missing-ms
goto MENU

:RUN_VALIDATE
call :RUN_VALIDATE_ONLY --output "%PROJECT_DIR%\output"
goto MENU

:RUN_CONFIGS
"%PYTHON_EXE%" %PYTHON_ARGS% -c "from core.config_loader import validate_all_configs; print(validate_all_configs())"
if errorlevel 1 (
    echo [ERROR] Configuration validation command failed.
    pause
) else (
    echo [OK] Configuration validation command completed.
    pause
)
goto MENU

:SHOW_PATHS
cls
echo Project folder:
echo %PROJECT_DIR%
echo.
echo Put QP and MS PDFs in:
echo %PROJECT_DIR%\input
echo.
echo Generated files are written to:
echo %PROJECT_DIR%\output
echo.
pause
goto MENU

:COMMAND_LINE
"%PYTHON_EXE%" %PYTHON_ARGS% "%PROJECT_DIR%\main.py" %*
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" goto EXIT
call :APPLICATION_ERROR %APP_EXIT%
goto EXIT

:RUN_BATCH
"%PYTHON_EXE%" %PYTHON_ARGS% "%PROJECT_DIR%\run_pipeline.py" %*
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" (
    echo.
    echo [OK] Batch command completed. Opening "%PROJECT_DIR%\output".
    start "" "%PROJECT_DIR%\output"
    pause
    exit /b 0
)
if "%APP_EXIT%"=="2" (
    echo.
    echo [WARN] Batch completed with review_required items. Opening "%PROJECT_DIR%\output".
    start "" "%PROJECT_DIR%\output"
    pause
    exit /b 0
)
call :APPLICATION_ERROR %APP_EXIT%
exit /b %APP_EXIT%

:RUN_VALIDATE_ONLY
"%PYTHON_EXE%" %PYTHON_ARGS% "%PROJECT_DIR%\run_guarded.py" --validate %*
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" (
    echo.
    echo [OK] Validation completed.
    pause
    exit /b 0
)
call :APPLICATION_ERROR %APP_EXIT%
exit /b %APP_EXIT%

:RUN_APPLICATION
"%PYTHON_EXE%" %PYTHON_ARGS% "%PROJECT_DIR%\main.py" %*
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" (
    echo.
    echo [OK] Command completed. Check "%PROJECT_DIR%\output".
    pause
    exit /b 0
)
call :APPLICATION_ERROR %APP_EXIT%
exit /b %APP_EXIT%

:APPLICATION_ERROR
echo.
echo [ERROR] The Topical Generator returned error code %~1.
echo The Python output above has not been hidden. Review it before retrying.
pause
exit /b %~1

:DIRECTORY_ERROR
echo [ERROR] Cannot switch to the folder containing run.bat.
echo Move the fully extracted project to a writable local directory and try again.
goto FATAL

:MAIN_NOT_FOUND
echo [ERROR] main.py was not found beside run.bat.
echo Extract the complete ZIP before launching this file.
goto FATAL

:PYTHON_ERROR
echo [ERROR] No usable Python 3 runtime was found.
echo Install Python 3 or restore this project's .venv/venv folder, then run run.bat again.
goto FATAL

:FATAL
echo.
echo Press any key to keep this error visible.
pause >nul
exit /b 1

:EXIT
endlocal
exit /b 0
