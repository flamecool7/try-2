# ExamVoid Topical Generator — Categorization Upgrade Notes

This round focused on improving question-to-topic classification quality for the
approved production subjects without touching cropping or examiner-report code.

## Main principle

Weak catch-all keywords were reduced or removed, and replaced with more
syllabus-aligned evidence phrases that are far more specific to the intended
topic.

Examples of problematic old patterns that were reduced/removed:
- A-Level Chemistry 9701: `chemical`, `group`, `compounds`, `organic`, `chemistry`, `level`
- A-Level Biology 9700: placeholders like `"Transport plants"`, `"Immunity"`, `"Photosynthesis"`
- IGCSE Chemistry 0620: broad overlaps like `ion`, `metal`, `water`
- IGCSE Physics 0625: over-broad terms like `measure`, `length`, `unit`

## Upgraded target profiles

### A-Level
- Chemistry 9701
  - Added stronger evidence for:
    - equilibria (`Kc`, `Kp`, buffers, titration curves, `Ksp`)
    - kinetics (rate equations, Arrhenius, order, initial rate)
    - electrochemistry (standard electrode potentials, salt bridges, half-cells)
    - analytical techniques (IR / NMR / mass spectrometry / chromatography)
    - transition elements (ligands, complex ions, ligand exchange)
    - more specific organic families and mechanisms
- Physics 9702
  - Tightened wording around DC circuits, electric fields, capacitance,
    quantum/nuclear, SHM, astronomy, etc.
- Biology 9700
  - Replaced placeholder topic keywords with real evidence for:
    - transport in plants/mammals
    - infectious diseases
    - immunity
    - energy and respiration
    - photosynthesis
    - biodiversity / conservation
    - genetic technology

### IGCSE
- Chemistry 0620
  - Rebuilt keywords around electrolysis, stoichiometry, periodic table,
    acids/bases/salts, environmental chemistry, and practical analysis.
- Physics 0625
  - Tightened keywords for motion/forces/energy, thermal physics, waves,
    electricity/magnetism, nuclear, and space physics.
- Biology 0610
  - Strengthened excretion, plant transport, animal transport, diseases and
    immunity, respiration, ecology, and biotechnology/genetic modification.

## Maths status

Mathematics categorization is already handled in the dedicated maths routing
engine (`core/math_reference.py`) rather than these generic config keywords.
That engine was improved earlier in this session for:
- 9709 Mathematics
- 9231 Further Mathematics
- 0580 Mathematics
- 0606 Additional Mathematics

## Validation

The round was covered by:
- full config validation
- targeted regression tests for upgraded subject-routing cases
- full repository test suite
