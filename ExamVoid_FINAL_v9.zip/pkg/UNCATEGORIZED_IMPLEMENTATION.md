# UNCATEGORIZED FOLDER LOGIC — implementation evidence (Overseer directive, 3rd receipt)
### Executed 2026-08-10 with the user-approved decision set (directive's own questions skipped twice → recommended set applied)

**Decisions applied** | `classification_failed` trigger = **desperate_only** (only the paper-hint /
alphabetical-first fallback tiers route; weak-keyword stays classified) · `no_markscheme` =
**adopt_keep_crop** (QP always saved; paper still recorded `MISSING_MS`/failed so a later MS
re-run reprocesses fully) · structure = **single_level** `output/{Level}/{Subject}/Uncategorized/{QID}/`
+ `REASON.txt` (no reason subfolders) · reporting = **quality_scorer `needs_review` block** +
printed run counts (metadata.json's `needs_review` name is forbidden-field-locked).

Spec-bug catch list #11: phantom `organize.py`/`topics_enhanced.py`/`classify()`/`output_validator.py`;
`classify()` "returns empty list" is impossible (locked fallback chain always assigns — fixed by exposing
`fallback_tier` instead); `Cambridge_Question_Bank/` root stale (real: `output/{Level}/{Subject}/…`);
RULE 1's "4 mandatory files" is self-contradictory for the no-MS branch (no MS file exists there);
two-level `{reason}/` folders would be auto-healed/invalidated by locked scanners (single-level adopted).

---

## Answers the directive asked for
- **Questions to Uncategorized in test runs:** 6 of 6 (QP-only paper, no MS at all) · 3 of 6 (paper whose MS was truncated to 3 questions: Q1–Q3 classified normally, Q4–Q6 routed)
- **Most common reason:** `no_markscheme` (9 real-run total). `classification_failed` = 0 on real 9700 runs — expected: the locked classifier assigns confidently; the desperate-tier path is proven via forced-tier unit tests.
- **Errors during folder creation:** none.

## Evidence battery (all on real 9700 m25 PDFs unless noted)
| Test | Result |
|---|---|
| **Parity / zero-blast-radius** | Clean m25+w25 run after ALL patches: 33/33 webps byte-identical to RS-2 approved tree, metadata identical, **0 Uncategorized appear on clean inputs** |
| **T1 QP-only** (no MS PDF at all) | 6 questions → `Uncategorized/` with QP+metadata+REASON.txt, ER commentary STILL attached into those folders, exam average summary at subject level (ER-3), `exit 0 ALL GREEN`, paper state stays `failed: MISSING_MS` so re-running with MS reprocesses |
| **T2 truncated MS** (Q1–3 MS only) | Q1 Cell_Structure / Q2 Biological_Molecules / Q3 Physiology (approved baselines) + Q4–6 Uncategorized; printed `Uncategorized (no MS): 3 / (classify failed): 0`; ALL GREEN |
| **T3 forced desperate tier** | `classification_failed` folder keeps **QP+MS+metadata+REASON.txt** (4 files, directive RULE 1); `weak_keyword` tier correctly does NOT route; no-shadow rule (real twin wins) verified |
| **T4 validator negatives** | 1000px-wide webp inside Uncategorized STILL flagged (width not exempt); sentinel topics never flagged as unknown; MS-missing allowed only under the no_ms sentinel; `classification_failed` without MS flagged; sentinels never auto-renamed |
| **T5 scorer** | `needs_review: {total 3, no_markscheme 3}` on mixed tree; `{total 0}` on clean tree; overall score math unchanged |
| **Promotion** | Uncategorized twin auto-retired (loud print) when the same question later gets a real classification; same-folder rewrite idempotent |
| **main.py wiring** | mini-QP real run: `MISSING_MS 9700_m25_22 … QP preserved`, folder written, counts printed, failure recorded (pre-existing semantics preserved; main.py exits 1 on MISSING_MS as before, run_guarded exits green with failed paper state — deliberate, documented difference) |

## Bugs the process caught & fixed this round
1. **Auto-heal conflict (critical):** `OutputManager.validate_qp_ms_pairs` Phase-0a auto-heal MOVED Uncategorized
   question folders into folders literally named `Uncategorized_No_MS` (metadata topic[0]) — sentinel bypass added (RS-5b).
2. **Second taxonomy-check site:** `check_no_cross_contamination` (validation.py:~940) held its own
   "topic not in configured reference topics" copy — both sites exempted.
3. **UnboundLocalError in my own wiring:** MISSING_MS block runs before `paper_code = base_key`
   exists in main.py — fixed to `base_key`, proven by real run.
4. **ER-3 structural gap:** QP-only trees have no paper-type folder → `examiner_report_full.txt` used to error loudly;
   now subject-level fallback write + upgrade-on-mixed-tree.
5. **Environment anomaly disclosed:** at 22:39:21 three *test* evidence trees lost content+state writes with no attributable
   code path (every destructive function proven inert on intact trees afterwards; matches a prior-session sandbox
   snapshot event). No user data involved; manifests record all approved bytes; regenerated proofs stand.

## ⏸️ PENDING LOCK RECORDS (awaiting approval — nothing written)
- CLS-4: `core/classifier.py` = `e756cb9a…`
- RS-5/RS-5b: `core/output_manager.py` = `fdbf8c85…`, `core/validation.py` = `3b971478…` (was 2a62f1ce), `main.py` = `01f7c676…`, `run_guarded.py` = `0fc96374…`, `pipeline.py` = `6bd045bd…`
- ER-3: `core/examiner_report.py` = `44a7dd82…` (EXAMINER_REPORT_LOCK amendment)
- RS-3 amendment: `core/quality_scorer.py` = `5dc26609…` (was 5dd491d8… — needs_review block)
- Untouched as required: triplet (00cc779e), MS engine & golds, webp_utils, converter DPI, er_question_crops (b93ad5f2), chemistry_reference pristine (193820b9), all `subjects/*/config.json` (content byte-verified vs zip).
