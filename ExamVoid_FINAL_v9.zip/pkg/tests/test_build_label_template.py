import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from tools.build_label_template import collect_rows, write_csv  # noqa: E402


class TestBuildLabelTemplate(unittest.TestCase):
    def test_collect_rows_and_write_csv(self):
        tmp = Path(tempfile.mkdtemp(prefix="label_template_"))
        out = tmp / "output"
        out.mkdir()

        samples = [
            ({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q2", "topic": ["Geometry"], "variant": "42", "season": "Summer", "year": "2024"}, out / "b" / "metadata.json"),
            ({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q1", "topic": ["review_required"], "variant": "42", "season": "Summer", "year": "2024"}, out / "a" / "metadata.json"),
        ]
        for payload, path in samples:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(payload), encoding="utf-8")

        rows = collect_rows(out)
        self.assertEqual([r["question_number"] for r in rows], ["Q1", "Q2"])
        self.assertEqual(rows[0]["route_status"], "review_required")
        self.assertEqual(rows[1]["route_status"], "auto_routed")
        self.assertEqual(rows[1]["predicted_topic"], "Geometry")

        csv_path = tmp / "labels.csv"
        write_csv(rows, csv_path)
        with csv_path.open(newline="", encoding="utf-8") as fh:
            written = list(csv.DictReader(fh))
        self.assertEqual(len(written), 2)
        self.assertEqual(written[0]["expected_topic"], "")
        self.assertIn("metadata.json", written[0]["metadata_path"])


if __name__ == "__main__":
    unittest.main()
