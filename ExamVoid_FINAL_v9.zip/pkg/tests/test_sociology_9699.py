#!/usr/bin/env python3
"""Regression: short-answer/essay subject support + Sociology 9699 (2026-08-16).

Pins two fixes:
  1. `qp_min_height_px` returns 60 (not 80) for short-answer/essay subjects so
     a legitimate one-line question ("Describe two quantitative research
     methods. [4]" -> ~75px crop) does not fail the whole paper.
  2. An unsplittable essay-style mark scheme (Question|Answer|Marks tables,
     sub-part markers 2(a)/2(b), level-of-response descriptors) no longer
     aborts the paper — it continues QP-only and routes every question to
     review_required/no_markscheme.
"""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from run_guarded import qp_min_height_px  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level  # noqa: E402


def _info(code):
    return SimpleNamespace(syllabus_code=code)


class TestShortAnswerHeightFloor(unittest.TestCase):
    def test_default_stays_80(self):
        for code in ("9701", "0620", "9700", "0625"):
            self.assertEqual(qp_min_height_px(_info(code)), 80, code)

    def test_short_answer_subjects_lower_to_60(self):
        for code in ("9699", "9990", "9489", "0470", "9695", "0475",
                     "9093", "8021", "9084", "9609", "9708", "9706",
                     "9696", "9239", "9694", "0580"):
            self.assertEqual(qp_min_height_px(_info(code)), 60, code)


class TestSociologyConfig(unittest.TestCase):
    def test_9699_config_loads(self):
        cfg = load_subject_config_by_code_and_level("9699", "A-Level")
        self.assertIsNotNone(cfg)
        self.assertEqual(cfg.subject, "Sociology_9699")
        self.assertGreaterEqual(len(cfg.major_topics), 6)


if __name__ == "__main__":
    unittest.main()
