"""Alias codes + Combined/Coordinated Sciences support (2026-08-14).

Cambridge uses multiple codes for the same subject:
  - 9-1 IGCSE equivalents: 0983 == 0478 (CS), 0971 == 0620 (Chemistry), ...
  - Superseded A-Level codes: 9608 -> 9618 (CS), 9389 -> 9489 (History)
  - Combined Science 0653 / 0973 and Coordinated Sciences 0654 / 0974
The whole pipeline must treat an alias code exactly like its canonical code
while keeping the alias in the paper's metadata.
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.config_loader import (  # noqa: E402
    resolve_code_alias,
    load_subject_config_by_code_and_level,
    infer_level_from_code,
    validate_all_configs,
)
from core.paper_identifier import (  # noqa: E402
    parse_paper_filename,
    infer_level_from_code as paper_level,
)
from core.mcq_registry import is_mcq  # noqa: E402
from core.classifier import TopicClassifier  # noqa: E402


class TestCodeAliases(unittest.TestCase):
    def test_alias_resolution(self):
        for alias, canon in [("0983", "0478"), ("0971", "0620"),
                             ("0972", "0625"), ("0970", "0610"),
                             ("0980", "0580"), ("0987", "0455"),
                             ("0986", "0450"), ("0976", "0460"),
                             ("0977", "0470"), ("0973", "0653"),
                             ("0974", "0654"), ("9608", "9618"),
                             ("9389", "9489")]:
            self.assertEqual(resolve_code_alias(alias), canon, alias)
        # non-alias passes through
        self.assertEqual(resolve_code_alias("9701"), "9701")

    def test_level_9_1_is_igcse(self):
        for code in ["0983", "0971", "0970", "0980", "0973", "0974"]:
            self.assertEqual(infer_level_from_code(code), "IGCSE", code)
            self.assertEqual(paper_level(code), "IGCSE", code)
        # A-Level codes still A-Level
        for code in ["9701", "9618", "9608", "9231"]:
            self.assertEqual(infer_level_from_code(code), "A-Level", code)

    def test_alias_config_lookup(self):
        cfg = load_subject_config_by_code_and_level("0983", None, "2026")
        self.assertEqual(cfg.subject, "Computer_Science_0478")
        cfg = load_subject_config_by_code_and_level("9608", None, "2019")
        self.assertEqual(cfg.subject, "Computer_Science_9618")
        cfg = load_subject_config_by_code_and_level("9389", None, "2019")
        self.assertEqual(cfg.subject, "History_9489")

    def test_filename_parse_alias(self):
        info = parse_paper_filename("0983_s24_qp_21.pdf")
        self.assertEqual(info.level, "IGCSE")
        self.assertEqual(info.paper_format, "STRUCTURED")
        info = parse_paper_filename("0971_s24_qp_12.pdf")
        self.assertEqual(info.level, "IGCSE")
        self.assertEqual(info.paper_format, "MCQ")
        info = parse_paper_filename("9608_s19_qp_21.pdf")
        self.assertEqual(info.level, "A-Level")


class TestCombinedSciences(unittest.TestCase):
    def test_configs_validate(self):
        ok, errs = validate_all_configs()
        self.assertTrue(ok, errs)

    def test_combined_science_config(self):
        cfg = load_subject_config_by_code_and_level("0653", "IGCSE", "2026")
        self.assertIsNotNone(cfg)
        self.assertEqual(cfg.major_topics, ["Biology", "Chemistry", "Physics"])
        self.assertGreaterEqual(len(cfg.detailed_topics), 30)
        for det in cfg.detailed_topics:
            self.assertIn(cfg.mapping[det], ["Biology", "Chemistry", "Physics"])
        cfg4 = load_subject_config_by_code_and_level("0654", "IGCSE", "2026")
        self.assertIsNotNone(cfg4)
        # 9-1 graded aliases
        cfg9 = load_subject_config_by_code_and_level("0973", "IGCSE", "2026")
        self.assertEqual(cfg9.subject, "Combined_Science_0653")

    def test_mcq_formats(self):
        self.assertTrue(is_mcq("0653", "11"))
        self.assertFalse(is_mcq("0653", "21"))
        self.assertTrue(is_mcq("0654", "11"))
        self.assertTrue(is_mcq("0654", "21"))
        self.assertFalse(is_mcq("0654", "31"))
        self.assertTrue(is_mcq("0973", "11"))   # 9-1 alias of 0653

    def test_classification_routes_domains(self):
        cfg = load_subject_config_by_code_and_level("0653", "IGCSE", "2026")
        clf = TopicClassifier(cfg)
        cases = [
            ("Describe how a green plant makes glucose by photosynthesis in "
             "the presence of light.", "Biology"),
            ("Explain how electrolysis of molten lead(II) bromide produces "
             "lead at the cathode.", "Chemistry"),
            ("State what is meant by the acceleration of a falling object "
             "and calculate its speed.", "Physics"),
        ]
        for text, want in cases:
            m = SimpleNamespace(
                qp=SimpleNamespace(text=text, marks=4), ms=None,
                variant="11", year="2026", season="Summer",
                question_number="Q1")
            res = clf.classify_question(m)
            self.assertEqual(res.winning_major, want, text)


if __name__ == "__main__":
    unittest.main()
