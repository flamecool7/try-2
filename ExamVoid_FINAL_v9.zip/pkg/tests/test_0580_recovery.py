from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

import run_guarded  # noqa: E402


class _FakeCropEngine:
    def __init__(self, returned):
        self.returned = returned
        self.calls = 0

    def process_paper(self, path):
        self.calls += 1
        return self.returned


class Test0580Recovery(unittest.TestCase):
    def test_0580_qp_height_guard_is_relaxed(self):
        qp = SimpleNamespace(syllabus_code="0580")
        self.assertEqual(run_guarded.qp_min_height_px(qp), 60)
        self.assertEqual(run_guarded.qp_min_height_px(SimpleNamespace(syllabus_code="0620")), 80)

    def test_0580_low_ram_zero_questions_falls_back_to_locked_engine(self):
        qp = SimpleNamespace(file_path=Path("0580_s24_qp_42.pdf"), syllabus_code="0580", full_code="0580_s24_qp_42")
        fake = [SimpleNamespace(question_number="Q1", number_int=1, images=[], assembled_image=None, text="", marks=0, pages=[])]
        engine = _FakeCropEngine(fake)
        original = run_guarded.qp_crops_low_ram
        try:
            run_guarded.qp_crops_low_ram = lambda *_a, **_k: []
            out = run_guarded.low_ram_qp_with_fallback(qp, "Mathematics_0580", engine, spool=Path(tempfile.mkdtemp()))
        finally:
            run_guarded.qp_crops_low_ram = original
        self.assertEqual(out, fake)
        self.assertEqual(engine.calls, 1)

    def test_0580_low_ram_reasonable_count_keeps_vector_first(self):
        qp = SimpleNamespace(file_path=Path("0580_s24_qp_42.pdf"), syllabus_code="0580", full_code="0580_s24_qp_42")
        vector = [SimpleNamespace(question_number=f"Q{i}", number_int=i, images=[], assembled_image=None, text="", marks=0, pages=[])
                  for i in range(1, 6)]
        engine = _FakeCropEngine([SimpleNamespace(question_number="Q99")])
        original = run_guarded.qp_crops_low_ram
        try:
            run_guarded.qp_crops_low_ram = lambda *_a, **_k: vector
            out = run_guarded.low_ram_qp_with_fallback(qp, "Mathematics_0580", engine, spool=Path(tempfile.mkdtemp()))
        finally:
            run_guarded.qp_crops_low_ram = original
        self.assertEqual(out, vector)
        self.assertEqual(engine.calls, 0)

    def test_non_0580_never_uses_this_fallback(self):
        qp = SimpleNamespace(file_path=Path("0620_s24_qp_42.pdf"), syllabus_code="0620", full_code="0620_s24_qp_42")
        vector = [SimpleNamespace(question_number="Q1", number_int=1, images=[], assembled_image=None, text="", marks=0, pages=[])]
        engine = _FakeCropEngine([SimpleNamespace(question_number="Q99")])
        original = run_guarded.qp_crops_low_ram
        try:
            run_guarded.qp_crops_low_ram = lambda *_a, **_k: vector
            out = run_guarded.low_ram_qp_with_fallback(qp, "Chemistry_0620", engine, spool=Path(tempfile.mkdtemp()))
        finally:
            run_guarded.qp_crops_low_ram = original
        self.assertEqual(out, vector)
        self.assertEqual(engine.calls, 0)


if __name__ == "__main__":
    unittest.main()
