import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from tools.evaluate_topic_accuracy import evaluate, load_labels, load_predictions  # noqa: E402


class TestEvaluateTopicAccuracy(unittest.TestCase):
    def test_report_counts_correct_incorrect_missing_and_review(self):
        tmp = Path(tempfile.mkdtemp(prefix="eval_topic_"))
        out = tmp / "output"
        out.mkdir()

        rows = [
            ({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q1", "topic": ["Trigonometry"]}, out / "a" / "metadata.json"),
            ({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q2", "topic": ["Geometry"]}, out / "b" / "metadata.json"),
            ({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q3", "topic": ["review_required"]}, out / "c" / "metadata.json"),
        ]
        for payload, path in rows:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(payload), encoding="utf-8")

        labels_csv = tmp / "labels.csv"
        with labels_csv.open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["subject", "level", "paper", "question_number", "expected_topic"])
            w.writeheader()
            w.writerow({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q1", "expected_topic": "Trigonometry"})
            w.writerow({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q2", "expected_topic": "Mensuration"})
            w.writerow({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q3", "expected_topic": "Geometry"})
            w.writerow({"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "question_number": "Q4", "expected_topic": "Number"})

        report = evaluate(load_labels(labels_csv), load_predictions(out))
        self.assertEqual(report["summary"]["labeled"], 4)
        self.assertEqual(report["summary"]["correct"], 1)
        self.assertEqual(report["summary"]["incorrect"], 2)
        self.assertEqual(report["summary"]["missing_prediction"], 1)
        self.assertEqual(report["summary"]["review_required"], 1)
        self.assertEqual(report["summary"]["accuracy_percent"], 25.0)
        self.assertEqual(report["confusion"][0]["expected"], "Mensuration")
        self.assertEqual(report["confusion"][0]["predicted"], "Geometry")
        topics = {r["expected_topic"]: r for r in report["per_topic"]}
        self.assertEqual(topics["Trigonometry"]["accuracy_percent"], 100.0)
        self.assertEqual(topics["Geometry"]["review_required"], 1)
        papers = {r["paper"]: r for r in report["per_paper"]}
        self.assertEqual(papers["0580_s24_qp_42"]["labeled"], 4)


if __name__ == "__main__":
    unittest.main()
