#!/usr/bin/env python3
"""User requirement (2026-08-14) regression suite.

1. metadata.json contains ONLY the canonical 11 fields
   (id, level, subject, board, topic, paper, question_number, variant,
   season, year) — for MCQ, structured and review paths alike. MCQ answer
   letters ride in the `*_MS.txt` sidecar, never in metadata.
2. No barcode bands survive in question crops: the full-image scrubber
   removes uniform vertical-bar stripes anywhere in the image while never
   touching text, tables or diagrams.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.json_generator import (  # noqa: E402
    CANONICAL_METADATA_FIELDS,
    canonical_metadata,
    JSONGenerator,
)
from core.output_manager import OutputManager  # noqa: E402
from core.webp_utils import scrub_barcode_bands  # noqa: E402
from tests.test_mcq_unified import (  # noqa: E402
    _fake_classification, _fake_config, _fake_matched,
)

CANON = set(CANONICAL_METADATA_FIELDS)
REAL_BARCODE_CROP = (PROJ.parent / "uploads" / "62_Winter_2025_Q1.webp")


def _make_barcode_image(with_fake: bool = False) -> Image.Image:
    """Synthetic crop: text-ish rows top/bottom + a 100px-tall barcode band
    in the middle (identical bar columns on every band row)."""
    h, w = 1200, 800
    arr = np.full((h, w), 255, dtype=np.uint8)

    def _textish(y0, nrows, seed):
        rng = np.random.default_rng(seed)
        for r in range(nrows):
            y = y0 + r
            for _ in range(rng.integers(6, 14)):
                x = int(rng.integers(10, w - 40))
                arr[y, x:x + int(rng.integers(2, 9))] = 0

    _textish(20, 8, 1)
    _textish(1100, 8, 2)

    by0, by1 = 500, 600
    x = 100
    while x < 700:
        bar_w = 8 if (x // 16) % 2 == 0 else 6
        arr[by0:by1, x:x + bar_w] = 0
        x += bar_w + 8
    if with_fake:
        # corrupt every band row with random content (text-like): the band
        # must NOT be scrubbed because the pattern varies row-to-row.
        rng = np.random.default_rng(7)
        for r in range(by0, by1):
            for _ in range(rng.integers(8, 16)):
                x = int(rng.integers(90, 720))
                arr[r, x:x + int(rng.integers(2, 9))] = 0
    return Image.fromarray(arr)


class TestCanonicalMetadataOnly(unittest.TestCase):
    def test_canonical_field_list_is_exactly_11(self):
        self.assertEqual(
            CANONICAL_METADATA_FIELDS,
            ["id", "level", "subject", "board", "topic", "paper",
             "question_number", "variant", "season", "year"],
        )

    def test_canonical_metadata_filters_extras(self):
        data = {
            "id": "x", "level": "IGCSE", "subject": "Physics_0625",
            "board": "CIE", "topic": ["Electricity_and_magnetism"],
            "paper": "0625_w25_qp_13", "question_number": "Q30",
            "variant": "13", "season": "Winter", "year": "2025",
            "paper_format": "MCQ", "ms_answer": "B", "question_type": "MCQ",
            "correct_answer": "B", "ms_status": "missing",
            "auto_assigned": True, "fallback_tier": "auto_forced",
        }
        out = canonical_metadata(data)
        self.assertEqual(set(out.keys()), CANON)
        self.assertEqual(list(out.keys()), CANONICAL_METADATA_FIELDS)

    def test_save_question_pair_mcq_writes_only_11_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_fake_matched(ms_answer="B"),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(set(md.keys()), CANON, md.keys())
            self.assertEqual(list(md.keys()), CANONICAL_METADATA_FIELDS)
            # letter in sidecar, not metadata
            txts = list(qf.glob("*_MS.txt"))
            self.assertEqual(len(txts), 1)
            self.assertEqual(txts[0].read_text().strip(), "B")

    def test_save_question_pair_structured_writes_only_11_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            from types import SimpleNamespace
            ms = SimpleNamespace(
                assembled_image=Image.new("RGB", (2280, 200), "white"),
                question_number="Q1", number_int=1, text="B",
            )
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(
                _fake_matched(ms=ms, variant="42", paper_code="0620_s16_42",
                              full_qp_code="0620_s16_qp_42",
                              full_ms_code="0620_s16_ms_42"),
                _fake_classification(), _fake_config(tmp))
            qf = Path(saved["question_folder"])
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(set(md.keys()), CANON, md.keys())

    def test_json_generator_save_json_filters(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "metadata.json"
            JSONGenerator().save_json({
                "id": "i", "level": "IGCSE", "subject": "S_0000",
                "board": "CIE", "topic": ["T"], "paper": "p",
                "question_number": "Q1", "variant": "1", "season": "Summer",
                "year": "2024", "extra_key": 1, "ms_answer": "A",
            }, p)
            md = json.loads(p.read_text(encoding="utf-8"))
            self.assertEqual(set(md.keys()), CANON)


class TestBarcodeScrubber(unittest.TestCase):
    def test_scrubs_uniform_band_keeps_text(self):
        img = _make_barcode_image()
        out = scrub_barcode_bands(img)
        arr = np.array(out.convert("L"))
        # barcode band region is now white
        self.assertEqual(arr[500:600, 90:720].min(), 255, "band not scrubbed")
        # text rows untouched
        self.assertLess(arr[20:28].min(), 128, "top text erased")
        self.assertLess(arr[1100:1108].min(), 128, "bottom text erased")

    def test_does_not_scrub_varying_rows(self):
        img = _make_barcode_image(with_fake=True)
        out = scrub_barcode_bands(img)
        arr = np.array(out.convert("L"))
        # fake rows must survive (varying pattern is content, not barcode)
        self.assertLess(arr[500:600].min(), 128, "content erased")

    def test_blank_identity(self):
        img = Image.new("RGB", (2280, 600), "white")
        self.assertIs(scrub_barcode_bands(img), img)

    @unittest.skipUnless(REAL_BARCODE_CROP.exists(),
                         "user upload absent")
    def test_real_user_crop_barcode_removed(self):
        img = Image.open(REAL_BARCODE_CROP)
        arr0 = np.array(img.convert("L"))
        out = scrub_barcode_bands(img)
        arr = np.array(out.convert("L"))
        self.assertEqual(arr.shape, arr0.shape, "size changed")
        # the previously-visible barcode band (y≈2857-2957, x≈133-911) is gone
        self.assertEqual(arr[2870:2940, 130:912].min(), 255,
                         "real barcode band still present")
        # question text above and below the band survives
        self.assertLess(arr[16:60].min(), 128, "top text erased")
        self.assertLess(arr[6000:6050].min(), 128, "bottom text erased")


if __name__ == "__main__":
    unittest.main(verbosity=2)
