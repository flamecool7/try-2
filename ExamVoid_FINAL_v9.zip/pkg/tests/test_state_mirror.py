#!/usr/bin/env python3
"""RS-13 state-mirror parity tests (state→SQLite cutover phase 1).

Pins: dual-write in save(); field-exact parity; loud drift reporting;
mirror-failure can never touch the JSON authority; UPSERT idempotency +
stale-row reconciliation.
"""
import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.pipeline_state import PaperStatus, PipelineState  # noqa: E402
from core.state_mirror import mirror_state_to_db, verify_parity  # noqa: E402


def _state():
    st = PipelineState(run_id="t3st1234", subject="Biology_9700", syllabus_code="9700",
                       level="A-Level", started_at=100.0)
    st.register_paper("9700_w25_qp_22", qp_path="/in/9700_w25_qp_22.pdf",
                      ms_path="/in/9700_w25_ms_22.pdf")
    st.register_paper("9700_m25_qp_22", qp_path="/in/9700_m25_qp_22.pdf",
                      ms_path="/in/9700_m25_ms_22.pdf")
    st.mark_complete("9700_w25_qp_22", questions_found=6, questions_saved=6)
    st.mark_failed("9700_m25_qp_22", "boom")
    return st


class TestStateMirror(unittest.TestCase):
    def test_save_dual_writes_and_parity_is_exact(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            st = _state()
            st.save(out)  # JSON + mirror
            js = json.loads((out / ".pipeline_state.json").read_text())
            self.assertEqual(js["run_id"], "t3st1234")
            self.assertEqual(js["papers"]["9700_w25_qp_22"]["status"], "complete")
            ok, drift = verify_parity(st, out)
            self.assertTrue(ok, drift)
            with sqlite3.connect(str(out / "pipeline.sqlite")) as conn:
                runs = conn.execute("SELECT run_id, total_questions FROM state_runs").fetchall()
                papers = conn.execute(
                    "SELECT paper_code, status, questions_saved FROM state_papers ORDER BY 1").fetchall()
            self.assertEqual(runs, [("t3st1234", 6)])
            self.assertEqual(papers, [("9700_m25_qp_22", "failed", 0),
                                      ("9700_w25_qp_22", "complete", 6)])

    def test_drift_is_reported_field_exact(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            st = _state()
            st.save(out)
            with sqlite3.connect(str(out / "pipeline.sqlite")) as conn:
                conn.execute("UPDATE state_papers SET questions_saved=99 "
                             "WHERE paper_code='9700_w25_qp_22'")
            ok, drift = verify_parity(st, out)
            self.assertFalse(ok)
            self.assertTrue(any("questions_saved" in d and "9700_w25_qp_22" in d for d in drift),
                            drift)

    def test_mirror_failure_never_touches_json_authority(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            (out / "pipeline.sqlite").mkdir()  # DB path is a DIRECTORY -> mirror must fail
            st = _state()
            st.save(out)  # must NOT raise
            js = json.loads((out / ".pipeline_state.json").read_text())
            self.assertEqual(js["papers"]["9700_w25_qp_22"]["questions_saved"], 6)

    def test_upsert_idempotent_and_reconciles_stale_rows(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            st = _state()
            st.save(out)
            st.save(out)  # same snapshot twice
            with sqlite3.connect(str(out / "pipeline.sqlite")) as conn:
                n_runs = conn.execute("SELECT COUNT(*) FROM state_runs").fetchone()[0]
                n_papers = conn.execute("SELECT COUNT(*) FROM state_papers").fetchone()[0]
            self.assertEqual((n_runs, n_papers), (1, 2))
            # simulate a paper vanishing from the live set
            del st.papers["9700_m25_qp_22"]
            st.save(out)
            with sqlite3.connect(str(out / "pipeline.sqlite")) as conn:
                codes = [r[0] for r in conn.execute("SELECT paper_code FROM state_papers")]
            self.assertEqual(codes, ["9700_w25_qp_22"])

    def test_resume_flow_parity_after_reload(self):
        """load_or_create from the JSON, then parity verifies the mirror too."""
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            _state().save(out)
            st2 = PipelineState.load_or_create(out, "Biology_9700", "9700", "A-Level")
            self.assertTrue(st2.should_skip("9700_w25_qp_22"))
            self.assertFalse(st2.should_skip("9700_m25_qp_22"))
            ok, drift = verify_parity(st2, out)
            self.assertTrue(ok, drift)
            # re-register the failed paper (crash-retry semantics pinned by FIX-P1)
            st2.register_paper("9700_m25_qp_22", ms_path="/in/moved_ms.pdf")
            self.assertEqual(st2.papers["9700_m25_qp_22"].status, PaperStatus.FAILED)
            st2.save(out)
            ok, drift = verify_parity(st2, out)
            self.assertTrue(ok, drift)


if __name__ == "__main__":
    unittest.main()
