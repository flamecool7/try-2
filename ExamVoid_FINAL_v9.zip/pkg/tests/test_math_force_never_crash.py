#!/usr/bin/env python3
"""RS-24 regression: math full-auto must never crash on fragmented OCR text.

Real-paper finding 0580_s24_qp_41 Q9: a composite/inverse function question
whose PDF text extraction scrambles notation into character columns
("f(x)" -> "f", "=", "( )x" on separate lines). No keyword ever matched, the
evidence gate stayed closed, and under full-auto the classifier returned an
EMPTY winner -> "Classification has no valid assigned topic" ValueError ->
the whole paper bundle died with exit code 1.

Fix: the math routers accept force=True (full-auto) and never return None:
near-miss topic -> notation heuristics (incl. the scrambled-function
signature: standalone f/g/h identifiers + "find" + [n] marks) -> syllabus
first topic as documented last resort.
"""
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.math_reference import (  # noqa: E402
    classify_0580_question, classify_0606_question,
    classify_9709_question, classify_9231_question,
)

SCRAMBLED_Q9 = """9
( )x
x
4
1
f
=
+
( )x
x
6
2
g
=
-
( )x
3
h
x
2
=
-
(a) Find
(i)
( )
3
f
................................................. [1]
(ii)
( )
3
gf
................................................. [1]
(b) Find
( )x
g 1
-
.
( )x
g 1
=
-
"""


class TestMathForceNeverCrash(unittest.TestCase):
    def test_0580_scrambled_function_question_routes(self):
        # The real failing question: must yield Algebra_and_graphs (functions
        # live there in 0580), never an empty winner.
        self.assertEqual(
            classify_0580_question(SCRAMBLED_Q9, force=True),
            "Algebra_and_graphs")

    def test_0580_force_never_returns_none(self):
        for t in ("zzzz qqqq", "", "   ", "Find x. [2]"):
            self.assertIsNotNone(classify_0580_question(t, force=True), t)

    def test_0606_force_never_returns_none(self):
        for t in ("zzzz qqqq", "", "f(x) = x^2. [2]"):
            self.assertIsNotNone(classify_0606_question(t, force=True), t)

    def test_9709_force_never_returns_none(self):
        for t in ("zzzz qqqq", "", "f(x) = 2x + 1. [2]"):
            self.assertIsNotNone(classify_9709_question(t, 1, force=True), t)

    def test_9231_force_never_returns_none(self):
        for t in ("zzzz qqqq", "", "matrix A. [2]"):
            self.assertIsNotNone(classify_9231_question(t, 1, force=True), t)

    def test_non_force_still_abstains(self):
        # --no-full-auto behaviour is unchanged: zero evidence -> None.
        self.assertIsNone(classify_0580_question("zzzz qqqq xxxx"))
        self.assertIsNone(classify_9709_question("zzzz qqqq xxxx", 1))
        self.assertIsNone(classify_9231_question("zzzz qqqq xxxx", 1))
        self.assertIsNone(classify_0606_question("zzzz qqqq xxxx"))

    def test_force_respects_paper_allowed_topics(self):
        # 9709 P2 (Pure 2) must never route outside its allowed topic set.
        r = classify_9709_question("zzzz qqqq", 2, force=True)
        from core.math_reference import allowed_topics_for_paper
        self.assertIn(r, allowed_topics_for_paper(2))


if __name__ == "__main__":
    unittest.main(verbosity=2)
