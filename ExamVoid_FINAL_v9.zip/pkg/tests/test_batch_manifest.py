#!/usr/bin/env python3
"""Batch-manifest round — regression suite (Overseer manifest spec, built for
real after the "step 1 completed" claim proved FALSE on disk).

T1  Real uploads corpus: 6 files -> 2 READY bundles, 1 series-ER attach,
    1 unpaired ER (0620_m25_er has no 0620 bundle).
T2  .PDF uppercase: manifest counts+identifies it; the locked identifier's
    rglob("*.pdf") MISSES it (gap receipt — pinned, not "fixed" silently).
T3  Duplicate QP -> REVIEW_REQUIRED, both paths listed (QPMSMatcher keeps
    only the first — receipt for self-contained grouping).
T4  MS-only group -> REVIEW_REQUIRED missing_qp (preflight would silently
    drop it — receipted SUPERSET).
T5  QP-only group -> REVIEW_REQUIRED missing_ms.
T6  Component-less series ER attaches to ALL bundles of code/season/year.
T7  Component ER attaches by FIRST-DIGIT rule only (preflight parity).
T8  Round-trip: manifest papers == live identifier output; tampered derived
    field -> ManifestError (fail-closed identifier-drift tripwire).
T9  Freshness cheap tier: size/mtime/add/remove -> STALE.
T10 Freshness full tier: sha256 rescue (mtime drift, same bytes -> FRESH).
T11 Atomic write: no stray tmp, versioned JSON.
T12 Wiring: run_guarded.load_inputs parent builds, worker consumes, env
    override honoured, --no-manifest bypasses; papers identical either way.
T13 CLI: build + --check rc transitions on tamper.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core import batch_manifest as bm                      # noqa: E402
from core.paper_identifier import identify_papers_in_dir  # noqa: E402

UPLOADS = Path("/home/user/uploads")
HAS_UPLOADS = any(UPLOADS.glob("*.pdf"))
DONOR = UPLOADS / "9700_m25_qp_22.pdf"   # real bytes for renamed synthetics


def make_tree(files, root):
    """files: {name: src_path} copied into root."""
    for name, src in files.items():
        dst = Path(root) / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


@unittest.skipUnless(HAS_UPLOADS, "real upload fixtures absent; run tools/download_fixtures.py")
class T1RealUploads(unittest.TestCase):
    def test_real_uploads_grouping(self):
        with tempfile.TemporaryDirectory() as td:
            for f in UPLOADS.glob("*.pdf"):
                shutil.copy2(f, Path(td) / f.name)
            mf = bm.build_manifest(td)
            s = mf["summary"]
            self.assertEqual(s["files_scanned"], 6)
            self.assertEqual(s["files_parsed"], 6)
            self.assertEqual(s["bundles_found"], 2)
            self.assertEqual(s["bundles_ready"], 2)
            self.assertEqual(s["bundles_review_required"], 0)
            self.assertEqual(s["examiner_reports_attached"], 1)  # 9700_m25_er -> m25 bundle only
            self.assertEqual(mf["review"]["unpaired_er"], ["0620_m25_er.pdf"])
            b = mf["bundles"]["9700_m25_22"]
            self.assertEqual(b["status"], "READY")
            self.assertEqual(b["er"], ["9700_m25_er.pdf"])
            self.assertEqual(b["qp"], ["9700_m25_qp_22.pdf"])
            self.assertEqual(b["ms"], ["9700_m25_ms_22.pdf"])
            self.assertEqual(mf["bundles"]["9700_w25_22"]["er"], [])


@unittest.skipUnless(HAS_UPLOADS, "real upload fixtures absent; run tools/download_fixtures.py")
class T2UppercasePDF(unittest.TestCase):
    def test_uppercase_extension_identified(self):
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "sub").mkdir()
            shutil.copy2(DONOR, Path(td) / "sub" / "9700_m25_qp_22.PDF")
            mf = bm.build_manifest(td)
            # found in a SUBDIRECTORY too (tree walk, not flat glob)
            self.assertEqual(mf["summary"]["files_scanned"], 1)
            self.assertEqual(mf["summary"]["files_parsed"], 1)
            self.assertIn("9700_m25_22", mf["bundles"])
            # Gap receipt: the locked live identifier rglob("*.pdf") misses it.
            self.assertEqual(identify_papers_in_dir(td), [])


@unittest.skipUnless(HAS_UPLOADS, "real upload fixtures absent; run tools/download_fixtures.py")
class GroupingSemantics(unittest.TestCase):
    def test_duplicate_qp_flagged_both_paths(self):  # T3
        with tempfile.TemporaryDirectory() as td:
            make_tree({"a/9700_m25_qp_22.pdf": DONOR, "b/9700_m25_qp_22.pdf": DONOR,
                       "9700_m25_ms_22.pdf": UPLOADS / "9700_m25_ms_22.pdf"}, td)
            b = bm.build_manifest(td)["bundles"]["9700_m25_22"]
            self.assertEqual(b["status"], "REVIEW_REQUIRED")
            self.assertTrue(any(r.startswith("duplicate_qp") for r in b["reasons"]))
            self.assertEqual(len(b["qp"]), 2)  # BOTH paths listed, none dropped

    def test_ms_only_bundle_review_not_dropped(self):  # T4
        with tempfile.TemporaryDirectory() as td:
            make_tree({"9700_m25_ms_22.pdf": UPLOADS / "9700_m25_ms_22.pdf"}, td)
            mf = bm.build_manifest(td)
            self.assertIn("9700_m25_22", mf["bundles"])
            b = mf["bundles"]["9700_m25_22"]
            self.assertEqual(b["status"], "REVIEW_REQUIRED")
            self.assertIn("missing_qp", b["reasons"])

    def test_qp_only_bundle_missing_ms(self):  # T5
        with tempfile.TemporaryDirectory() as td:
            make_tree({"9700_m25_qp_22.pdf": DONOR}, td)
            b = bm.build_manifest(td)["bundles"]["9700_m25_22"]
            self.assertEqual(b["status"], "REVIEW_REQUIRED")
            self.assertIn("missing_ms", b["reasons"])

    def test_series_er_attaches_to_all_variants(self):  # T6
        with tempfile.TemporaryDirectory() as td:
            make_tree({
                "9700_m25_qp_21.pdf": DONOR, "9700_m25_ms_21.pdf": UPLOADS / "9700_m25_ms_22.pdf",
                "9700_m25_qp_22.pdf": DONOR, "9700_m25_ms_22.pdf": UPLOADS / "9700_m25_ms_22.pdf",
                "9700_m25_er.pdf": UPLOADS / "9700_m25_er.pdf",
            }, td)
            mf = bm.build_manifest(td)
            self.assertEqual(mf["summary"]["examiner_reports_attached"], 2)
            self.assertEqual(mf["bundles"]["9700_m25_21"]["er"], ["9700_m25_er.pdf"])
            self.assertEqual(mf["bundles"]["9700_m25_22"]["er"], ["9700_m25_er.pdf"])

    def test_component_er_first_digit_rule(self):  # T7
        with tempfile.TemporaryDirectory() as td:
            make_tree({
                "0620_s16_qp_22.pdf": DONOR, "0620_s16_ms_22.pdf": DONOR,
                "0620_s16_qp_42.pdf": DONOR, "0620_s16_ms_42.pdf": DONOR,
                "0620_s16_er_2.pdf": UPLOADS / "9700_m25_er.pdf",
            }, td)
            mf = bm.build_manifest(td)
            self.assertEqual(mf["bundles"]["0620_s16_22"]["er"], ["0620_s16_er_2.pdf"])
            self.assertEqual(mf["bundles"]["0620_s16_42"]["er"], [])
            self.assertEqual(mf["review"]["unpaired_er"], [])


@unittest.skipUnless(HAS_UPLOADS, "real upload fixtures absent; run tools/download_fixtures.py")
class RoundTripAndFreshness(unittest.TestCase):
    def _upload_tree(self, td):
        for f in UPLOADS.glob("*.pdf"):
            shutil.copy2(f, Path(td) / f.name)

    def test_roundtrip_identical_and_drift_failclosed(self):  # T8
        with tempfile.TemporaryDirectory() as td:
            self._upload_tree(td)
            _, mf = bm.write_manifest(td, quiet=True)
            fresh, _ = bm.check_freshness(mf, td)
            self.assertTrue(fresh)
            got = bm.papers_from_manifest(mf, td)
            want = identify_papers_in_dir(td)
            key = lambda p: (p.full_code, p.paper_type, str(p.file_path))
            self.assertEqual(
                sorted((p.full_code, p.paper_type, p.level, p.paper_format,
                        p.is_mcq, p.expected_question_count, p.variant) for p in got),
                sorted((p.full_code, p.paper_type, p.level, p.paper_format,
                        p.is_mcq, p.expected_question_count, p.variant) for p in want))
            self.assertEqual(sorted(key(p) for p in got), sorted(key(p) for p in want))
            # tamper a derived field -> fail-closed
            mf["files"][0]["paper"]["derived"]["paper_format"] = "MCQ"
            with self.assertRaises(bm.ManifestError):
                bm.papers_from_manifest(mf, td)

    def test_cheap_tier_staleness(self):  # T9
        with tempfile.TemporaryDirectory() as td:
            self._upload_tree(td)
            _, mf = bm.write_manifest(td, quiet=True)
            self.assertTrue(bm.check_freshness(mf, td)[0])
            # size change
            with open(Path(td) / "9700_m25_qp_22.pdf", "ab") as fh:
                fh.write(b"x")
            self.assertFalse(bm.check_freshness(mf, td)[0])
            shutil.copy2(UPLOADS / "9700_m25_qp_22.pdf", Path(td) / "9700_m25_qp_22.pdf")
            # mtime change (copy2 would preserve; force)
            os.utime(Path(td) / "9700_m25_qp_22.pdf")
            ok, why = bm.check_freshness(mf, td)
            self.assertFalse(ok, why)
            # removal
            (Path(td) / "0620_m25_er.pdf").unlink()
            self.assertFalse(bm.check_freshness(mf, td)[0])
            # addition
            self._upload_tree(td)
            shutil.copy2(DONOR, Path(td) / "9701_s15_qp_12.pdf")
            self.assertFalse(bm.check_freshness(mf, td)[0])

    def test_full_tier_sha_rescue(self):  # T10
        with tempfile.TemporaryDirectory() as td:
            self._upload_tree(td)
            _, mf = bm.write_manifest(td, quiet=True)
            for f in Path(td).glob("*.pdf"):
                os.utime(f)  # mtime drift, same bytes
            self.assertFalse(bm.check_freshness(mf, td)[0])
            ok, why = bm.check_freshness(mf, td, full=True)
            self.assertTrue(ok, why)

    def test_atomic_write(self):  # T11
        with tempfile.TemporaryDirectory() as td:
            self._upload_tree(td)
            out, mf = bm.write_manifest(td, quiet=True)
            self.assertEqual(out.name, ".batch_manifest.json")
            self.assertEqual([p.name for p in Path(td).glob(".manifest_*")], [])
            self.assertEqual(json.loads(out.read_text())["manifest_version"], 1)


@unittest.skipUnless(HAS_UPLOADS, "real upload fixtures absent; run tools/download_fixtures.py")
class Wiring(unittest.TestCase):
    def test_load_inputs_parent_builds_worker_consumes(self):  # T12
        with tempfile.TemporaryDirectory() as td:
            inp, out = Path(td) / "in", Path(td) / "out"
            inp.mkdir()
            for f in UPLOADS.glob("*.pdf"):
                shutil.copy2(f, inp / f.name)
            import io, contextlib
            import run_guarded
            # parent style: builds the manifest
            args_p = SimpleNamespace(input=str(inp), output=str(out), clean=True,
                                     worker=None, manifest=None, no_manifest=False,
                                     manifest_full_check=False)
            with contextlib.redirect_stdout(io.StringIO()) as buf1:
                g1 = run_guarded.load_inputs(args_p)
            src1 = [ln for ln in buf1.getvalue().splitlines() if "identity:" in ln]
            self.assertTrue((inp / ".batch_manifest.json").exists())
            self.assertTrue(any("live+wrote-manifest" in ln for ln in src1), src1)
            # worker style: consumes, never builds
            args_w = SimpleNamespace(input=str(inp), output=str(out), clean=False,
                                     worker="9700_m25_22", manifest=None,
                                     no_manifest=False, manifest_full_check=False)
            with contextlib.redirect_stdout(io.StringIO()) as buf2:
                g2 = run_guarded.load_inputs(args_w)
            src2 = [ln for ln in buf2.getvalue().splitlines() if "identity:" in ln]
            self.assertTrue(any("manifest:.batch_manifest.json" in ln for ln in src2), src2)
            # identical identity either way
            self.assertEqual(sorted(p.full_code for p in g1[2]),
                             sorted(p.full_code for p in g2[2]))
            # disabled -> live
            args_off = SimpleNamespace(**{**vars(args_w), "no_manifest": True})
            with contextlib.redirect_stdout(io.StringIO()):
                g3 = run_guarded.load_inputs(args_off)
            self.assertEqual(sorted(p.full_code for p in g1[2]),
                             sorted(p.full_code for p in g3[2]))
            for g in (g1, g2, g3):
                self.assertIsNotNone(g[3])  # sep built by the same separator

    def test_cli_build_check(self):  # T13
        with tempfile.TemporaryDirectory() as td:
            for f in UPLOADS.glob("*.pdf"):
                shutil.copy2(f, Path(td) / f.name)
            r1 = subprocess.run([sys.executable, "-m", "core.batch_manifest", td],
                                cwd=str(PROJ), capture_output=True, text=True)
            self.assertEqual(r1.returncode, 0, r1.stderr)
            self.assertIn("6 files scanned", r1.stdout)
            self.assertIn("2 QP/MS bundles found", r1.stdout)
            r2 = subprocess.run([sys.executable, "-m", "core.batch_manifest", td, "--check"],
                                cwd=str(PROJ), capture_output=True, text=True)
            self.assertEqual(r2.returncode, 0, r2.stdout)
            self.assertIn("FRESH", r2.stdout)
            with open(Path(td) / "9700_w25_qp_22.pdf", "ab") as fh:
                fh.write(b"tamper")
            r3 = subprocess.run([sys.executable, "-m", "core.batch_manifest", td, "--check"],
                                cwd=str(PROJ), capture_output=True, text=True)
            self.assertEqual(r3.returncode, 1)
            self.assertIn("STALE", r3.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
