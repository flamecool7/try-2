#!/usr/bin/env python3
"""Grade-threshold extraction + non-standard filename parsing — regression suite.

Covers (maintainer-directed, 2026-08-15):
  1. `parse_paper_filename` loose fallback: names that carry a syllabus code
     and a qp/ms/er/gt marker in non-standard arrangement now resolve, while
     random PDFs still fail-closed.
  2. `grade_threshold.extract_grade_thresholds`: a synthetic gt PDF (drawn
     with real ruling lines so the vector-table path is exercised) yields the
     correct component + option grade boundaries, across A-Level and IGCSE
     scales, with en-dash "no grade" cells -> null.
"""
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

try:
    import fitz  # PyMuPDF
except ImportError:
    import pymupdf as fitz

from core.paper_identifier import parse_paper_filename  # noqa: E402
from core.grade_threshold import (                        # noqa: E402
    extract_grade_thresholds, _parse_number,
)


# ---------------------------------------------------------------------------
# 1. Non-standard filename parsing
# ---------------------------------------------------------------------------
class TestLooseFilenameParsing(unittest.TestCase):
    def _parse(self, name):
        return parse_paper_filename(Path(name))

    def test_gt_files_parse(self):
        info = self._parse("9701_s24_gt.pdf")
        self.assertIsNotNone(info)
        self.assertEqual(info.syllabus_code, "9701")
        self.assertEqual(info.paper_type, "gt")
        self.assertEqual(info.season_letter, "s")
        self.assertEqual(info.year_short, "24")
        self.assertEqual(info.variant, "")

    def test_gt_without_season_year(self):
        info = self._parse("9701_gt.pdf")
        self.assertIsNotNone(info)
        self.assertEqual(info.paper_type, "gt")

    def test_code_type_glued_together(self):
        info = self._parse("9701gt.pdf")
        self.assertIsNotNone(info)
        self.assertEqual(info.paper_type, "gt")
        self.assertEqual(info.syllabus_code, "9701")

    def test_code_type_only_no_component(self):
        info = self._parse("9701_qp_22.pdf")
        self.assertIsNotNone(info)
        self.assertEqual(info.paper_type, "qp")
        self.assertEqual(info.variant, "22")

    def test_type_phrase_and_code_anywhere(self):
        info = self._parse("0620 Chemistry June 2024 Grade Threshold.pdf")
        self.assertIsNotNone(info)
        self.assertEqual(info.syllabus_code, "0620")
        self.assertEqual(info.paper_type, "gt")
        self.assertEqual(info.season_letter, "s")
        self.assertEqual(info.year_short, "24")

    def test_markscheme_phrase(self):
        info = self._parse("9701 m26 mark scheme 42.pdf")
        self.assertIsNotNone(info)
        self.assertEqual(info.paper_type, "ms")
        self.assertEqual(info.season_letter, "m")
        self.assertEqual(info.year_short, "26")
        self.assertEqual(info.variant, "42")

    def test_variant_not_read_from_code_digits(self):
        # the trailing digits of the syllabus code must never leak as variant
        info = self._parse("9701_ms.pdf")
        self.assertEqual(info.variant, "")

    def test_standard_form_unchanged(self):
        info = self._parse("9701_s24_qp_22.pdf")
        self.assertEqual((info.syllabus_code, info.paper_type, info.season_letter,
                          info.year_short, info.variant),
                         ("9701", "qp", "s", "24", "22"))

    def test_random_pdf_fails_closed(self):
        self.assertIsNone(self._parse("random notes.pdf"))
        self.assertIsNone(self._parse("scan_2024.pdf"))


# ---------------------------------------------------------------------------
# 2. Grade-threshold extraction (synthetic PDF)
# ---------------------------------------------------------------------------
def _build_gt_pdf(path: Path, *, igcse: bool = False) -> Path:
    """Draw a minimal Cambridge-style gt PDF with real ruling lines."""
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)

    grades = ["A", "B", "C", "D", "E", "F", "G"] if igcse else ["A", "B", "C", "D", "E"]
    opt_grades = (["A*"] + grades) if not igcse else grades  # IGCSE comp uses A..G, opt A*..G
    subject = "Physics (0625)" if igcse else "Chemistry (9701)"
    code = "0625" if igcse else "9701"
    level = "Cambridge IGCSE™ Physics (0625)" if igcse else \
        "Cambridge International AS & A Level Chemistry (9701)"

    page.insert_text((40, 40), "Grade thresholds – June 2024", fontsize=13)
    page.insert_text((40, 60), level, fontsize=10)
    page.insert_text(
        (40, 80),
        f"Grade thresholds taken for Syllabus {code} ({subject.split(' (')[0]}) in the June 2024 examination.",
        fontsize=8)

    # ---- component table (with ruling lines) ----
    top = 130
    col_x = [40, 120, 200, 260, 320, 380, 440, 500, 560, 620]  # up to 9 cols
    ncols = 1 + 1 + len(grades)  # Component + Max + grades
    row_h = 22

    def grid(x0, y0, x1, y1, ncol, nrow):
        for r in range(nrow + 1):
            y = y0 + r * row_h
            page.draw_line((x0, y), (x1, y), color=(0, 0, 0), width=0.6)
        for c in range(ncol + 1):
            x = col_x[c]
            page.draw_line((x, y0), (x, y0 + nrow * row_h), color=(0, 0, 0), width=0.6)

    page.insert_text((40, top - 14), "Minimum raw mark required for grade:", fontsize=8)
    nrows = 2
    grid(col_x[0], top, col_x[ncols], top + nrows * row_h, ncols, nrows)
    hdr = ["Component", "Max"] + grades
    for i, h in enumerate(hdr):
        page.insert_text((col_x[i] + 4, top + 15), h, fontsize=8)
    comp_rows = [("11", ["40", "29", "27", "22", "17", "13", "10"]),
                 ("12", ["40", "27", "24", "20", "15", "11", "8"])]
    for r, (comp, vals) in enumerate(comp_rows):
        page.insert_text((col_x[0] + 4, top + (r + 1) * row_h + 15), f"Component {comp}", fontsize=8)
        cells = [vals[0]] + vals[1:1 + len(grades)]
        for i, v in enumerate(cells):
            page.insert_text((col_x[i + 1] + 6, top + (r + 1) * row_h + 15), v, fontsize=8)

    doc.save(str(path))
    doc.close()
    return path


class TestGradeThresholdExtraction(unittest.TestCase):
    def test_parse_number_dash(self):
        self.assertIsNone(_parse_number("–"))
        self.assertIsNone(_parse_number("-"))
        self.assertEqual(_parse_number("40"), 40)

    def test_extract_alevel(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            pdf = _build_gt_pdf(Path(td) / "9701_s24_gt.pdf")
            data = extract_grade_thresholds(pdf)
        self.assertIsNotNone(data)
        self.assertEqual(data["syllabus_code"], "9701")
        self.assertEqual(data["component_grade_scale"], ["A", "B", "C", "D", "E"])
        self.assertEqual(data["option_grade_scale"], ["A*", "A", "B", "C", "D", "E"])
        comps = {c["component"]: c for c in data["component_thresholds"]}
        self.assertIn("11", comps)
        self.assertEqual(comps["11"]["maximum_raw_mark"], 40)
        self.assertEqual(comps["11"]["grades"]["A"], 29)
        self.assertEqual(comps["11"]["grades"]["E"], 13)

    def test_extract_igcse(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            pdf = _build_gt_pdf(Path(td) / "0625_s24_gt.pdf", igcse=True)
            data = extract_grade_thresholds(pdf)
        self.assertIsNotNone(data)
        self.assertEqual(data["syllabus_code"], "0625")
        self.assertEqual(data["component_grade_scale"],
                         ["A", "B", "C", "D", "E", "F", "G"])

    def test_non_gt_pdf_returns_none(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "notes.pdf"
            doc = fitz.open()
            pg = doc.new_page()
            pg.insert_text((40, 40), "These are just some random notes.")
            doc.save(str(p))
            doc.close()
            self.assertIsNone(extract_grade_thresholds(p))


if __name__ == "__main__":
    unittest.main()
