"""Confidence-gate + identity regression suites."""
