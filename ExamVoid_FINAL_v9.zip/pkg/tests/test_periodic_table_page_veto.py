#!/usr/bin/env python3
"""Regression: 9701_w25_qp_11 page-2 periodic-table false positive.

The question page that opens a Chemistry paper carries a mini periodic table
box at the top AND Q1-Q4 below it. The old `_detect_periodic_table_grid`
rule `has_pt_title and >= 8 element symbols -> conf 0.95` fired on the page
because Q2's wording mentions "Periodic Table" and the MCQ options list
element symbols (Na, Mg, Al, Si, P, S, Cl, Ar) — the whole page (and Q1-Q4
with it) was silently deleted. The question-content veto must reject that,
while the REAL periodic-table page (100+ symbols) is still detected.
"""
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.chemistry_reference import _detect_periodic_table_grid  # noqa: E402

# Real text from 9701_w25_qp_11.pdf page 2 (Q1-Q4 + mini PT box context).
PAGE2_Q1_Q4 = """
2
© UCLES 2025
9701/11/O/N/25
1
What is the electronic configuration for the particle
?
A
1s22s22p63s13p1
B
1s22s22p63s2
C
1s22s22p63s23p2
D
1s22s22p63s23p63d74s1
2
The data in the table gives the 5th to the 10th ionisation energies of three
elements from Period 3 of the Periodic Table.
element X element Y element Z
A Na Mg Al
B Mg Al Si
C P S Cl
D S Cl Ar
3
What contains 9.03 x 1023 oxygen atoms?
A 0.25 mol aluminium oxide
B 0.75 mol sulfur dioxide
C 1.5 mol sulfur trioxide
D 3.0 mol water
4
Methane and steam react to produce hydrogen.
CH4(g) + 2H2O(g) -> CO2(g) + 4H2(g)
0.80 g of methane and 1.35 g of steam react. One of the reactants is used up.
Which volume of hydrogen, measured at room conditions, will be produced?
A 1.80 dm3
B 3.60 dm3
C 4.80 dm3
D 7.20 dm3
"""

# Real text from 9701_w25_qp_11.pdf page 16 (the actual Periodic Table grid).
PAGE16_PERIODIC_TABLE = """
16
© UCLES 2025
9701/11/O/N/25
Group
The Periodic Table of Elements
1
H
hydrogen
1.0
2
He
helium
4.0
1
2
13
14
15
16
17
18
3
4
5
6
7
8
9
10
11
12
3
Li
lithium
6.9
4
Be
beryllium
9.0
atomic number
atomic symbol
Key
name
relative atomic mass
11
Na
sodium
23.0
12
Mg
magnesium
24.3
19
K
potassium
39.1
20
Ca
calcium
40.1
37
Rb
rubidium
85.5
38
Sr
strontium
87.6
55
Cs
caesium
132.9
56
Ba
barium
137.3
87
Fr
francium
-
88
Ra
radium
-
5
B
boron
10.8
13
Al
aluminium
27.0
31
Ga
gallium
69.7
49
In
indium
114.8
81
Tl
thallium
204.4
6
C
carbon
12.0
14
Si
silicon
28.1
32
Ge
germanium
72.6
50
Sn
tin
118.7
82
Pb
lead
207.2
22
Ti
titanium
47.9
40
Zr
zirconium
91.2
72
Hf
hafnium
178.5
104
Rf
rutherfordium
-
23
V
vanadium
50.9
41
Nb
niobium
92.9
73
Ta
tantalum
180.9
105
Db
dubnium
-
24
Cr
chromium
52.0
42
Mo
molybdenum
95.9
74
W
tungsten
183.8
106
Sg
seaborgium
-
25
Mn
manganese
54.9
43
Tc
technetium
-
75
Re
rhenium
186.2
107
Bh
bohrium
-
26
Fe
iron
55.8
44
Ru
ruthenium
101.1
76
Os
osmium
190.2
108
Hs
hassium
-
27
Co
cobalt
58.9
45
Rh
rhodium
102.9
77
Ir
iridium
192.2
109
Mt
meitnerium
-
28
Ni
nickel
58.7
46
Pd
palladium
106.4
78
Pt
platinum
195.1
110
Ds
darmstadtium
-
29
Cu
copper
63.5
47
Ag
silver
107.9
79
Au
gold
197.0
111
Rg
roentgenium
-
30
Zn
zinc
65.4
48
Cd
cadmium
112.4
80
Hg
mercury
200.6
112
Cn
copernicium
-
31
Ga
gallium
69.7
49
In
indium
114.8
81
Tl
thallium
204.4
113
Nh
nihonium
-
32
Ge
germanium
72.6
50
Sn
tin
118.7
82
Pb
lead
207.2
114
Fl
flerovium
-
33
As
arsenic
74.9
51
Sb
antimony
121.8
83
Bi
bismuth
209.0
115
Mc
moscovium
-
34
Se
selenium
79.0
52
Te
tellurium
127.6
84
Po
polonium
-
116
Lv
livermorium
-
35
Br
bromine
79.9
53
I
iodine
126.9
85
At
astatine
-
117
Ts
tennessine
-
36
Kr
krypton
83.8
54
Xe
xenon
131.3
86
Rn
radon
-
118
Og
oganesson
-
57
La
lanthanum
138.9
89
Ac
actinium
-
58
Ce
cerium
140.1
90
Th
thorium
232.0
59
Pr
praseodymium
140.9
91
Pa
protactinium
231.0
60
Nd
neodymium
144.2
92
U
uranium
238.0
61
Pm
promethium
-
93
Np
neptunium
-
62
Sm
samarium
150.4
94
Pu
plutonium
-
63
Eu
europium
152.0
95
Am
americium
-
64
Gd
gadolinium
157.3
96
Cm
curium
-
65
Tb
terbium
158.9
97
Bk
berkelium
-
66
Dy
dysprosium
162.5
98
Cf
californium
-
67
Ho
holmium
164.9
99
Es
einsteinium
-
68
Er
erbium
167.3
100
Fm
fermium
-
69
Tm
thulium
168.9
101
Md
mendelevium
-
70
Yb
ytterbium
173.0
102
No
nobelium
-
71
Lu
lutetium
175.0
103
Lr
lawrencium
-
"""


class TestPeriodicTablePageVeto(unittest.TestCase):
    def test_question_page_2_is_not_periodic_table(self):
        # The veto (question starts + answer options) must reject the page.
        is_pt, conf = _detect_periodic_table_grid(PAGE2_Q1_Q4, [])
        self.assertFalse(is_pt, f"question page flagged periodic_table conf={conf}")

    def test_real_periodic_table_page_still_detected(self):
        # 100+ element symbols -> conf 1.0; the veto must NOT fire on the
        # real grid even though its rows look like question starts.
        is_pt, conf = _detect_periodic_table_grid(PAGE16_PERIODIC_TABLE, [])
        self.assertTrue(is_pt)
        self.assertGreaterEqual(conf, 1.0)

    def test_structured_question_page_mentioning_pt_with_marks(self):
        # Structured paper page: question starts + [n] mark tokens.
        text = (
            "9701/22/O/N/25\n"
            "1 (a) State the electronic configuration of the Al3+ ion. [1]\n"
            "(b) The data below relates to elements from Period 3 "
            "of the Periodic Table. [2]\n"
            "2 (a) Define relative atomic mass. [1]\n"
            "(b) Calculate the relative atomic mass of element X. [2]\n"
        )
        is_pt, conf = _detect_periodic_table_grid(text, [])
        self.assertFalse(is_pt, f"structured question page flagged conf={conf}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
