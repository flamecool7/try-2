#!/usr/bin/env python3
"""IGCSE paper-format round — regression suite.

Folds together:
  1. The Overseer spec's exact 17-case scan_paper() truth table
     (log of original run: test-crops/redesign/igcse_validation_test.log).
  2. Folder-name rename truth table (user decision taxonomy=rename),
     including A-Level byte-identical regression rows.
  3. mcq_support.detect_mcq fast-paths (paper_meta_profile /
     paper_identifier_profile / unresolved_identity).
  4. extract_mcq_answers on REAL fixtures (0620_s16_ms_22, 9701_s15_ms_12) —
     skipped automatically if the fixture corpus is absent.
  5. End-to-end synthetic save: MCQ stub -> QP webp + metadata only
     (ms_answer + paper_format additive keys, never an MS webp), then
     validator acceptance; negative case (letter stripped) must fail.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.paper_scan import scan_paper                       # noqa: E402
from core.output_manager import _paper_type_folder, OutputManager  # noqa: E402
from core.mcq_support import detect_mcq                      # noqa: E402

FIXTURES = PROJ.parent / "test-crops" / "fixtures" / "remote"


# ---------------------------------------------------------------------------
# 1. The spec's exact 17 cases
# ---------------------------------------------------------------------------
SPEC_CASES = [
    ("0620_m25_qp_12.pdf", "MCQ", 40),
    ("0620_m25_qp_22.pdf", "MCQ", 40),
    ("0620_m25_qp_32.pdf", "STRUCTURED", None),
    ("0620_m25_qp_42.pdf", "STRUCTURED", None),
    ("0610_s24_qp_11.pdf", "MCQ", 40),
    ("0610_s24_qp_21.pdf", "MCQ", 40),
    ("0625_w23_qp_12.pdf", "MCQ", 40),
    ("0625_w23_qp_22.pdf", "MCQ", 40),
    ("0580_s24_qp_42.pdf", "STRUCTURED", None),
    ("0580_s24_qp_12.pdf", "STRUCTURED", None),
    ("0606_s24_qp_12.pdf", "STRUCTURED", None),
    ("0606_s24_qp_22.pdf", "STRUCTURED", None),
    ("0455_s24_qp_12.pdf", "MCQ", 30),
    ("0455_s24_qp_22.pdf", "STRUCTURED", None),
    ("9701_s24_qp_12.pdf", "MCQ", 40),
    ("9701_s24_qp_22.pdf", "STRUCTURED", None),
    ("9701_s24_qp_42.pdf", "STRUCTURED", None),
]


class TestSpec17(unittest.TestCase):
    def test_all_17_cases(self):
        for fname, fmt, count in SPEC_CASES:
            with self.subTest(fname=fname):
                info = scan_paper(fname)
                self.assertIsNotNone(info, f"{fname}: unrecognised")
                self.assertEqual(info["paper_format"], fmt)
                self.assertEqual(info["expected_question_count"], count)


# ---------------------------------------------------------------------------
# 2. Folder-name truth table (rename decision + A-Level regression)
# ---------------------------------------------------------------------------
FOLDER_CASES = [
    # IGCSE rename
    ("12", "0620", "P1_MCQ"), ("22", "0620", "P2_MCQ"),
    ("32", "0620", "P3_Structured"), ("42", "0620", "P4_Structured"),
    ("52", "0620", "P5_Practical"), ("62", "0620", "P6_ATP"),
    ("12", "0455", "P1_MCQ"), ("22", "0455", "P2_Structured"),
    ("12", "0470", "P1_Essay"), ("42", "0470", "P4_Essay"),
    ("22", "0580", "Calculator Core"), ("42", "0580", "Calculator Extended"),
    ("12", "0606", "Additional Maths Paper 1"), ("22", "0606", "Additional Maths Paper 2"),
    ("12", "0610", "P1_MCQ"), ("21", "0625", "P2_MCQ"),
    # A-Level byte-identical regression
    ("12", "9701", "P1_MCQ"), ("22", "9701", "P2_AS_Structured"),
    ("42", "9701", "P4_A2_Structured"), ("52", "9701", "P5_Plan_Analysis"),
    ("33", "9702", "P3_Practical_Skills"), ("62", "9701", "P6_Alt_to_Practical"),
    ("12", "9618", "P1_Theory_Fundamentals"), ("42", "9618", "P4_Practical"),
    ("12", "9709", "Pure Maths 1"), ("22", "9709", "Pure Maths 2"),
    ("42", "9709", "Mechanics 1"), ("52", "9709", "Statistics 1"),
    ("12", "9231", "Further Pure Maths 1"), ("22", "9231", "Further Pure Maths 2"),
    ("32", "9231", "Further Mechanics 1"), ("42", "9231", "Further Statistics 1"),
    ("22", None, "P2_AS_Structured"), ("12", None, "P1_MCQ"),
]


class TestFolderNames(unittest.TestCase):
    def test_truth_table(self):
        for variant, syllabus, want in FOLDER_CASES:
            with self.subTest(variant=variant, syllabus=syllabus):
                self.assertEqual(_paper_type_folder(variant, syllabus_code=syllabus), want)


# ---------------------------------------------------------------------------
# 3. detect_mcq fast-paths
# ---------------------------------------------------------------------------
class TestDetectMcq(unittest.TestCase):
    def test_meta_fast_path(self):
        # Unified-MCQ round: registry fast-path resolves syllabus+variant.
        info = detect_mcq(paper_meta={"syllabus_code": "0620", "variant": "22",
                                      "paper_format": "MCQ",
                                      "expected_question_count": 40})
        self.assertTrue(info.is_mcq)
        self.assertEqual(info.paper_variant, "22")
        self.assertEqual(info.question_count, 40)
        self.assertEqual(info.confirmed_by, ["mcq_registry"])

    def test_meta_legacy_profile_without_syllabus(self):
        info = detect_mcq(paper_meta={"paper_format": "MCQ", "variant": "22",
                                      "expected_question_count": 40})
        self.assertTrue(info.is_mcq)
        self.assertEqual(info.question_count, 40)
        self.assertEqual(info.confirmed_by, ["paper_meta_profile"])

    def test_identifier_profile_fallback(self):
        info = detect_mcq(filename="0620_m25_qp_22.pdf")
        self.assertTrue(info.is_mcq)
        self.assertEqual(info.confirmed_by, ["paper_identifier_profile"])
        info2 = detect_mcq(filename="0580_s24_qp_42.pdf")
        self.assertFalse(info2.is_mcq)

    def test_unresolved_identity_fail_closed(self):
        info = detect_mcq(filename="totally-unrecognised.pdf")
        self.assertFalse(info.is_mcq)
        self.assertEqual(info.confirmed_by, ["unresolved_identity"])


# ---------------------------------------------------------------------------
# 4. Real-fixture grid extraction
# ---------------------------------------------------------------------------
@unittest.skipUnless((FIXTURES / "0620_s16_ms_22.pdf").exists(), "fixture corpus absent")
class TestExtractMcqAnswers(unittest.TestCase):
    def _extract(self, name):
        from core.ms_cropping_engine import MSCroppingEngine
        return MSCroppingEngine().extract_mcq_answers(FIXTURES / name)

    def test_igcse_0620_grid_40(self):
        ans = self._extract("0620_s16_ms_22.pdf")
        self.assertEqual(len(ans), 40)
        self.assertLessEqual(set(ans.values()), set("ABCD"))

    def test_alevel_9701_grid_40(self):
        ans = self._extract("9701_s15_ms_12.pdf")
        self.assertEqual(len(ans), 40)
        self.assertLessEqual(set(ans.values()), set("ABCD"))


# ---------------------------------------------------------------------------
# 5. Synthetic save + validator acceptance (MCQ and structured regression)
# ---------------------------------------------------------------------------
def _fake_config(tmp):
    return SimpleNamespace(
        subject="Chemistry_0620", level="IGCSE", syllabus_code="0620",
        board="CIE", major_topics=["Stoichiometry"], detailed_topics=["Stoichiometry"],
    )


def _fake_qp():
    from PIL import Image
    return SimpleNamespace(assembled_image=Image.new("RGB", (2280, 400), "white"),
                           question_number="Q1", number_int=1, marks=1, text="Which gas?")


def _fake_matched(**kw):
    base = dict(question_number="Q1", number_int=1, _fake_qp_=None,
                qp=_fake_qp(), ms=None, paper_code="0620_s16_22",
                full_qp_code="0620_s16_qp_22", full_ms_code="0620_s16_ms_22",
                year="2016", season="Summer", variant="22", subject="Chemistry")
    base.pop("_fake_qp_", None)
    base.update(kw)
    return SimpleNamespace(**base)


def _fake_classification():
    return SimpleNamespace(winning_major="Stoichiometry",
                           detailed_topics=["Stoichiometry"],
                           fallback_tier="scored")


class TestMcqSavePath(unittest.TestCase):
    """save_question_pair must write QP webp + metadata ONLY for MCQ stubs and
    the OutputValidator must accept the folder (and reject a stripped letter)."""

    def _save(self, tmp, matched):
        mgr = OutputManager(output_root=str(Path(tmp) / "out"))
        return mgr.save_question_pair(matched, _fake_classification(), _fake_config(tmp))

    def test_mcq_folder_contents(self):
        with tempfile.TemporaryDirectory() as tmp:
            saved = self._save(tmp, _fake_matched(ms_answer="B"))
            qf = Path(saved["question_folder"])
            self.assertIn("P2_MCQ", str(qf))
            webps = sorted(p.name for p in qf.glob("*.webp"))
            self.assertEqual(webps, ["22_Summer_2016_Q1.webp"])
            self.assertIsNone(saved["ms"])
            md = json.loads((qf / "metadata.json").read_text())
            # User requirement (2026-08-14): canonical 11 fields ONLY.
            from core.json_generator import CANONICAL_METADATA_FIELDS as _CANON
            self.assertEqual(set(md.keys()), set(_CANON), md.keys())
            self.assertNotIn("paper_format", md)
            self.assertNotIn("ms_answer", md)
            txt = list(qf.glob("*_MS.txt"))
            self.assertEqual(txt[0].read_text(), "B\n")   # letter sidecar

            # validator accepts (no errors touching this folder)
            from core.validation import FinalValidator as OutputValidator
            v = OutputValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            v.check_qp_ms_pairing_new()
            self.assertEqual(v.errors, [], v.errors)

    def test_mcq_missing_letter_flagged(self):
        with tempfile.TemporaryDirectory() as tmp:
            saved = self._save(tmp, _fake_matched(ms_answer="B"))
            qf = Path(saved["question_folder"])
            # Corrupt the letter sidecar: validator must flag the folder.
            txt = list(qf.glob("*_MS.txt"))
            self.assertTrue(txt)
            txt[0].write_text("", encoding="utf-8")
            from core.validation import FinalValidator as OutputValidator
            v = OutputValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertTrue(any("_MS.txt" in e for e in v.errors), v.errors)

    def test_structured_regression_still_writes_pair(self):
        # Unified-MCQ round: the writer now keys MCQ-ness on the REGISTRY,
        # so a truly-structured component must be used here (0620/22 IS MCQ;
        # 0620/42 is the structured theory paper).
        with tempfile.TemporaryDirectory() as tmp:
            from PIL import Image
            ms = SimpleNamespace(assembled_image=Image.new("RGB", (2280, 200), "white"),
                                 question_number="Q1", number_int=1, text="B")
            saved = self._save(tmp, _fake_matched(
                ms=ms, variant="42", paper_code="0620_s16_42",
                full_qp_code="0620_s16_qp_42", full_ms_code="0620_s16_ms_42"))
            qf = Path(saved["question_folder"])
            self.assertIn("P4_Structured", str(qf))
            webps = sorted(p.name for p in qf.glob("*.webp"))
            self.assertEqual(webps, ["42_Summer_2016_Q1.webp", "42_Summer_2016_Q1_MS.webp"])
            self.assertIsNotNone(saved["ms"])
            md = json.loads((qf / "metadata.json").read_text())
            self.assertNotIn("ms_answer", md)
            self.assertNotIn("paper_format", md)
            # User requirement (2026-08-14): canonical 11 fields ONLY.
            from core.json_generator import CANONICAL_METADATA_FIELDS as _CANON
            self.assertEqual(set(md.keys()), set(_CANON), md.keys())


if __name__ == "__main__":
    unittest.main(verbosity=2)
