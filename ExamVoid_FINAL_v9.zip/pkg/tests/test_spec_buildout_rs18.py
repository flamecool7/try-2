"""RS-18 tests — mega-spec build-out pins: strategy registry (Fix 4), unified
MCQ authority (Fix 5), ms_fetcher allowed-source order (Fix 6), REVIEW_REQUIRED
state (Fix 1), no-loading validator (Fix 12), CLI flags + main.py delegation.
"""
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

FIXTURES = PROJ.parent / "test-crops" / "fixtures" / "remote"


class _Probe:
    def __init__(self, code, variant, fmt=None):
        self.syllabus_code = code
        self.variant = variant
        self.file_path = Path(f"{code}_s16_qp_{variant}.pdf")
        self.paper_format = fmt


class TestStrategies(unittest.TestCase):
    """Fix 4: profile+component selection; no universal structured parser."""

    def test_structured_selection(self):
        from core.strategies import (StructuredMarkSchemeStrategy,
                                     StructuredQuestionPaperStrategy,
                                     select_ms_strategy, select_qp_strategy)
        qp = _Probe("0620", "42")
        self.assertIsInstance(select_qp_strategy(qp), StructuredQuestionPaperStrategy)
        self.assertIsInstance(select_ms_strategy(qp, object()), StructuredMarkSchemeStrategy)

    def test_mcq_selection_both_levels(self):
        from core.strategies import (MCQMarkSchemeStrategy, MCQQuestionPaperStrategy,
                                     select_ms_strategy, select_qp_strategy)
        for code, variant in (("0620", "22"), ("9701", "12"), ("0610", "21"), ("9702", "13")):
            qp = _Probe(code, variant)
            self.assertIsInstance(select_qp_strategy(qp), MCQQuestionPaperStrategy, (code, variant))
            self.assertIsInstance(select_ms_strategy(qp, object()), MCQMarkSchemeStrategy, (code, variant))
        # QP-only run -> None ms strategy, not a crash
        self.assertIsNone(select_ms_strategy(_Probe("0620", "42"), None))

    def test_igcse_science_practical_and_atp_are_structured(self):
        from core.strategies import (
            StrategyUnsupported, PracticalPaperStrategy,
            StructuredMarkSchemeStrategy, select_qp_strategy, select_ms_strategy,
        )
        for code, variant in (("0610", "52"), ("0620", "52"), ("0625", "52"),
                              ("0620", "62")):
            self.assertIsInstance(select_qp_strategy(_Probe(code, variant)),
                                  PracticalPaperStrategy)
            self.assertIsInstance(select_ms_strategy(_Probe(code, variant), object()),
                                  StructuredMarkSchemeStrategy)
        # A practical label on a non-profiled A-Level code must still fail
        # closed rather than reusing the IGCSE science parser blindly.
        with self.assertRaises(StrategyUnsupported):
            select_qp_strategy(_Probe("9702", "33", fmt="PRACTICAL"))
        with self.assertRaises(StrategyUnsupported):
            select_qp_strategy(_Probe("0470", "12"))  # ESSAY
        with self.assertRaises(StrategyUnsupported):
            select_ms_strategy(_Probe("9702", "61", fmt="ATP"), object())

    def test_audit_plan_strings(self):
        from core.strategies import strategy_plan_for_paper
        p = strategy_plan_for_paper(_Probe("9709", "12"))
        self.assertIn("structured_qp_gold", p.name)
        self.assertIn("9709", p.reason)
        p2 = strategy_plan_for_paper(_Probe("0620", "22"))
        self.assertIn("mcq_ms_grid", p2.name)
        bad = strategy_plan_for_paper(_Probe("0470", "11"))
        self.assertEqual(bad.kind, "unsupported")
        self.assertIn("REVIEW_REQUIRED", bad.reason)


class TestUnifiedMCQAuthority(unittest.TestCase):
    """Fix 5: one MCQ list. paper_identifier must not contradict mcq_registry."""

    def test_identifier_and_registry_agree(self):
        from core.mcq_registry import get_all_mcq_codes
        from core.paper_identifier import IGCSE_COMPONENT_MAP as fmt
        reg = get_all_mcq_codes()
        for code, comp_map in fmt.items():
            mcq_comps = {c for c, f in comp_map.items() if f == "MCQ"}
            if code in reg:
                self.assertEqual(mcq_comps, reg[code],
                                 f"{code}: identifier {sorted(mcq_comps)} != registry {sorted(reg[code])}")
            else:
                self.assertEqual(mcq_comps, set(),
                                 f"{code}: identifier claims MCQ {sorted(mcq_comps)} "
                                 f"but registry has none")

    def test_mcq_ms_txt_contract(self):
        """MCQ _MS.txt = exactly one letter A-D (+ optional trailing newline)."""
        import re
        from core.mcq_output import write_mcq_ms, validate_mcq_ms_file
        tmp = Path(tempfile.mkdtemp(prefix="mcqtxt_"))
        f = write_mcq_ms(tmp, "22_Summer_2016_Q1", "C")
        self.assertTrue(validate_mcq_ms_file(f))
        body = f.read_text(encoding="utf-8")
        self.assertRegex(body, r"^[ABCD]\n?$")
        self.assertEqual(body.strip(), "C")


class TestMSFetcherSourceOrder(unittest.TestCase):
    """Fix 6: source order is contractual; papers.co never appears."""

    def test_source_order(self):
        from core.ms_fetcher import SOURCES
        names = [s["name"] for s in SOURCES]
        self.assertEqual(names[0], "cambridge_international_official")
        self.assertIn("pastpapers.co", names)
        self.assertLess(names.index("cambridge_international_official"),
                        names.index("pastpapers.co"))

    def test_papers_co_banned_everywhere(self):
        for f in list((PROJ / "core").glob("*.py")) + [PROJ / "run_guarded.py",
                                                       PROJ / "run_pipeline.py",
                                                       PROJ / "main.py"]:
            for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
                if "papers.co/" in line and "pastpapers.co" not in line:
                    self.fail(f"{f.name}:{i}: bare papers.co reference")

    def test_verifier_rejects_non_pdf_and_identity_mismatch(self):
        from core.ms_fetcher import PDFVerifier
        tmp = Path(tempfile.mkdtemp(prefix="verify_"))
        fake = tmp / "0620_s16_ms_22.pdf"
        fake.write_bytes(b"<html>not a real pdf at all</html>" * 40)
        v = PDFVerifier()
        r = v.verify(fake, syllabus_code="0620", season="s", year_short="16",
                     component="22")
        self.assertFalse(r.passed)
        self.assertFalse(r.is_pdf)
        self.assertTrue(r.failure_reasons)


class TestStateStatuses(unittest.TestCase):
    """Fix 1 statuses incl. REVIEW_REQUIRED + retry semantics."""

    def test_review_required_roundtrip(self):
        from core.pipeline_state import PaperStatus, PipelineState
        tmp = Path(tempfile.mkdtemp(prefix="state_"))
        st = PipelineState.load_or_create(tmp, subject="X_9999", syllabus_code="9999", level="IGCSE")
        st.papers["9999_s16_42"] = __import__("core.pipeline_state", fromlist=["PaperRecord"]).PaperRecord(
            paper_code="9999_s16_42", qp_path="q", ms_path=None, er_path=None)
        st.mark_review_required("9999_s16_42", "practical component has no validated strategy")
        st.save(tmp)
        st2 = PipelineState.load_or_create(tmp, subject="X_9999", syllabus_code="9999", level="IGCSE")
        self.assertIs(st2.papers["9999_s16_42"].status, PaperStatus.REVIEW_REQUIRED)
        self.assertEqual(st2.papers["9999_s16_42"].review_reason,
                         "practical component has no validated strategy")
        n_reset = st2.reset_failed()
        self.assertEqual(n_reset, 0, "review is NOT failed — retry-failed must not sweep it up")
        n_reset2 = st2.reset_failed(include_review=True)
        self.assertEqual(n_reset2, 1)


class TestNoLoadingValidator(unittest.TestCase):
    """Fix 12: a 'loading' path anywhere fails the audit."""

    def test_loading_dir_fails_audit(self):
        from core.validation import FinalValidator
        tmp = Path(tempfile.mkdtemp(prefix="noload_"))
        bad = tmp / "IGCSE" / "Chemistry_0620" / "P2_Structured" / "loading"
        bad.mkdir(parents=True)
        (bad / "22_Summer_2016_Q1").mkdir()
        res = FinalValidator(output_root=tmp).validate_all()
        self.assertFalse(res["passed"])
        self.assertTrue(any("loading" in e for e in res["errors"]),
                        f"errors={res['errors'][:3]}")

    def test_topic_folder_equals_metadata_topic_new_structure(self):
        """Spec Fix 12: folder name == metadata topic[0] (writer-side invariant)."""
        src = (PROJ / "core/output_manager.py").read_text(encoding="utf-8")
        self.assertIn("assert major_path.name == assigned_topic", src)
        jsrc = (PROJ / "core/json_generator.py").read_text(encoding="utf-8")
        self.assertIn("canonical_topic_list", jsrc)


@unittest.skipUnless(FIXTURES.is_dir(), "fixture corpus not downloaded")
class TestCLIFlags(unittest.TestCase):
    def _in_dir(self, tmp, names):
        inp = tmp / "in"
        inp.mkdir(exist_ok=True)
        for n in names:
            shutil.copy(FIXTURES / n, inp / n)
        return inp

    def test_dry_run_processes_nothing(self):
        tmp = Path(tempfile.mkdtemp(prefix="dryrun_"))
        inp = self._in_dir(tmp, ["9709_s15_qp_42.pdf", "9709_s15_ms_42.pdf"])
        out = tmp / "out"
        r = subprocess.run([sys.executable, "-u", str(PROJ / "run_guarded.py"),
                            "--input", str(inp), "--output", str(out), "--dry-run"],
                           capture_output=True, text=True, timeout=300, cwd=str(PROJ))
        self.assertEqual(r.returncode, 0, r.stdout[-1500:])
        self.assertIn("DRY RUN", r.stdout)
        self.assertIn("strategy structured_qp_gold+structured_ms_gold", r.stdout)
        self.assertFalse(list(out.rglob("*.webp")), "dry-run wrote no question output")

    def test_main_py_delegates_to_guarded(self):
        tmp = Path(tempfile.mkdtemp(prefix="deleg_"))
        inp = self._in_dir(tmp, ["9709_s15_qp_42.pdf", "9709_s15_ms_42.pdf"])
        out = tmp / "out"
        r = subprocess.run([sys.executable, "-u", str(PROJ / "main.py"),
                            "--input", str(inp), "--output", str(out), "--dry-run"],
                           capture_output=True, text=True, timeout=300, cwd=str(PROJ))
        self.assertEqual(r.returncode, 0, r.stdout[-1500:])
        self.assertIn("delegating to the guarded production path", r.stdout)
        self.assertIn("DRY RUN", r.stdout)

    def test_validate_flag_audits_existing_output(self):
        tmp = Path(tempfile.mkdtemp(prefix="valflag_"))
        out = tmp / "out"
        (out / "IGCSE" / "Chemistry_0620" / "P2_Structured" / "loading").mkdir(parents=True)
        r = subprocess.run([sys.executable, "-u", str(PROJ / "run_guarded.py"),
                            "--output", str(out), "--validate"],
                           capture_output=True, text=True, timeout=300, cwd=str(PROJ))
        self.assertEqual(r.returncode, 1, "loading dir must fail --validate")
        self.assertIn("FAIL", r.stdout)


if __name__ == "__main__":
    unittest.main()
