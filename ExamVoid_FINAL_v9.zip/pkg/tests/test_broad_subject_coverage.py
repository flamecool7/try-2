#!/usr/bin/env python3
"""Broad subject-coverage regression (2026-08-15).

The system previously skipped papers with "no approved subject config" for the
wider Cambridge catalog.  tools/build_full_subject_catalog.py generated
configs for 46 more subjects (35 A-Level + 40 IGCSE total).  This test pins
that the new subjects load, validate, resolve via code, and classify.
"""
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.config_loader import (load_subject_config_by_code_and_level,  # noqa: E402
                                get_configs_by_level, KNOWN_CODE_MAP,
                                validate_all_configs)
from core.paper_identifier import parse_paper_filename, infer_level_from_code  # noqa: E402


class TestBroadSubjectCoverage(unittest.TestCase):
    def test_all_configs_validate(self):
        ok, errs = validate_all_configs()
        self.assertTrue(ok, f"invalid configs: {errs}")

    def test_subject_counts_expanded(self):
        self.assertGreaterEqual(len(get_configs_by_level("A-Level")), 30)
        self.assertGreaterEqual(len(get_configs_by_level("IGCSE")), 35)

    def test_new_subjects_load(self):
        cases = [
            ("9084", "A-Level", "Law_9084"),
            ("9093", "A-Level", "English_Language_9093"),
            ("0680", "IGCSE", "Environmental_Management_0680"),
            ("0454", "IGCSE", "Enterprise_0454"),
            ("9693", "A-Level", "Marine_Science_9693"),
            ("0520", "IGCSE", "French_0520"),
            ("0607", "IGCSE", "International_Mathematics_0607"),
            ("0452", "IGCSE", "Accounting_0452"),
        ]
        for code, level, subject in cases:
            cfg = load_subject_config_by_code_and_level(code, level)
            self.assertIsNotNone(cfg, f"{code} config missing")
            self.assertEqual(cfg.subject, subject, code)
            self.assertGreaterEqual(len(cfg.major_topics), 3, code)

    def test_new_codes_in_known_map(self):
        for code in ("9084", "9093", "0680", "0454", "9693", "0520", "0607",
                     "0452", "0500", "0495", "9694", "9607"):
            self.assertIn(code, KNOWN_CODE_MAP, code)

    def test_level_inference_for_new_codes(self):
        for code in ("9084", "9093", "9693", "9607", "9479"):
            self.assertEqual(infer_level_from_code(code), "A-Level", code)
        for code in ("0680", "0454", "0520", "0607", "0500", "0495"):
            self.assertEqual(infer_level_from_code(code), "IGCSE", code)

    def test_parse_new_subject_filenames(self):
        info = parse_paper_filename(Path("0680_s24_qp_11.pdf"))
        self.assertEqual(info.syllabus_code, "0680")
        self.assertEqual(info.subject_guess, "Environmental_Management_0680")
        info = parse_paper_filename(Path("9084_s24_qp_11.pdf"))
        self.assertEqual(info.subject_guess, "Law_9084")


if __name__ == "__main__":
    unittest.main()
