"""Regression suite for the confidence-gate defect fixes (F4/F5/F6/F7/F10)
plus identity seeds (spec tests 1 & 15).

Every test stands alone; the two that need the real RS-2 approved baseline
tree skip loudly if it is absent. No test fabricates evidence.
"""
from __future__ import annotations

import contextlib
import io
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJ))

from PIL import Image  # noqa: E402

from core import cropping_engine as ce  # noqa: E402
from core import ms_cropping_engine as mse  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level  # noqa: E402
from core.paper_identifier import parse_paper_filename  # noqa: E402

FIXTURES = PROJ.parent / "test-crops" / "fixtures"
RS2_TREE = PROJ.parent / "test-crops" / "guarded-run" / "output"


class TestF5FailClosed(unittest.TestCase):
    """Defect 5: no dummy/synthetic questions from production, ever."""

    def _engine(self):
        return ce.CroppingEngine(target_width=2280, quality=95, dpi=75)

    def test_qp_fail_closed_when_gold_unavailable(self):
        self.assertTrue(ce.HAS_FITZ, "test env must have PyMuPDF")
        saved = ce.GOLD_AVAILABLE
        ce.GOLD_AVAILABLE = False
        try:
            eng = self._engine()
            out = eng.process_paper(Path("9700_m25_qp_22.pdf"))
            self.assertEqual(out, [], "must return zero crops, not dummies")
            self.assertTrue(eng.last_error, "fail-closed reason must be set")
        finally:
            ce.GOLD_AVAILABLE = saved

    def test_qp_fail_closed_when_fitz_unavailable(self):
        saved_f, saved_g = ce.HAS_FITZ, ce.GOLD_AVAILABLE
        ce.HAS_FITZ, ce.GOLD_AVAILABLE = False, False
        try:
            eng = self._engine()
            out = eng.process_paper(Path("9700_m25_qp_22.pdf"))
            self.assertEqual(out, [])
            self.assertIn("fail-closed", eng.last_error or "")
        finally:
            ce.HAS_FITZ, ce.GOLD_AVAILABLE = saved_f, saved_g

    def test_qp_fail_closed_on_gold_exception(self):
        eng = self._engine()
        split = ce.gold_question_split.split_questions

        def boom(*a, **k):
            raise RuntimeError("forced gold failure for test")

        ce.gold_question_split.split_questions = boom
        try:
            out = eng.process_paper(Path("9700_m25_qp_22.pdf"))
            self.assertEqual(out, [], "exception must yield [], never dummies")
            self.assertIn("forced gold failure", eng.last_error or "")
        finally:
            ce.gold_question_split.split_questions = split

    def test_ms_fail_closed_when_gold_unavailable(self):
        saved = mse.GOLD_MS_AVAILABLE
        mse.GOLD_MS_AVAILABLE = False
        try:
            eng = mse.MSCroppingEngine(target_width=2280, quality=95, dpi=150)
            out = eng.process_paper(Path("9700_m25_ms_22.pdf"))
            self.assertEqual(out, [])
        finally:
            mse.GOLD_MS_AVAILABLE = saved

    def test_no_dummy_symbols_left_in_engines(self):
        """Fabrication SITES gone (comments mentioning the old design are fine
        and must not trip this)."""
        src_qp = (PROJ / "core" / "cropping_engine.py").read_text()
        src_ms = (PROJ / "core" / "ms_cropping_engine.py").read_text()
        for src in (src_qp, src_ms):
            self.assertNotIn("_dummy_process", src)
            self.assertNotIn("dummy text", src)
            self.assertNotIn('f"MS Question {i}', src)
            self.assertNotIn('f"Question {i} dummy', src)


class TestF4QCPropagation(unittest.TestCase):
    """Defect 4: gold QC verdicts must reach the adapter, not be dropped."""

    def test_per_question_qc_and_paper_confidence_propagate(self):
        eng = ce.CroppingEngine(target_width=2280, quality=95, dpi=75)
        img = Image.new("RGB", (2280, 640), "white")
        fake_q = SimpleNamespace(
            question_number="1", images=[img], text="Q1 stem [10]",
            page_segments=[], needs_review=True,
            review_reasons=["unit-test QC flag"],
        )
        split = ce.gold_question_split.split_questions
        ce.gold_question_split.split_questions = (
            lambda *a, **k: ([fake_q], False))
        try:
            out = eng.process_paper(Path("9700_m25_qp_22.pdf"))
        finally:
            ce.gold_question_split.split_questions = split
        self.assertEqual(len(out), 1)
        self.assertTrue(out[0].needs_review)
        self.assertEqual(out[0].qc_reasons, ["unit-test QC flag"])
        self.assertIs(eng.last_confident, False)
        self.assertIsNone(eng.last_error)


class TestF10RealNamingValidator(unittest.TestCase):
    """Defect 10: distribution check must operate on the REAL naming."""

    def _tree(self, tmp: Path) -> Path:
        # one question in TWO majors — a true R6 duplicate the OLD vacuous
        # "*_QP.webp" glob could never see
        for topic in ("Cell_Structure", "Genetics"):
            qf = (tmp / "A-Level" / "Biology_9700" / "P2_AS_Structured"
                  / topic / "22_Spring_2025_Q1")
            qf.mkdir(parents=True)
            Image.new("RGB", (2280, 600), "white").save(
                qf / "22_Spring_2025_Q1.webp")
            Image.new("RGB", (2280, 600), "white").save(
                qf / "22_Spring_2025_Q1_MS.webp")
            (qf / "metadata.json").write_text(json.dumps({
                "paper": "9700_s25_qp_22", "question_number": "Q1"}))
        return tmp

    def test_old_glob_was_vacuous_new_glob_catches_duplicate(self):
        tmp = Path(tempfile.mkdtemp(prefix="f10_tree_"))
        try:
            self._tree(tmp)
            # the bug: zero files match the legacy convention
            self.assertEqual(list(tmp.rglob("*_QP.webp")), [],
                             "fixture uses real naming; old glob must see nothing")
            from core.validation import FinalValidator
            v = FinalValidator(str(tmp))
            v.check_single_folder_distribution()
            self.assertTrue(any("R6" in e for e in v.errors),
                            f"duplication must be caught; errors={v.errors}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class TestF7YearFlag(unittest.TestCase):
    """Every paper year can process, but unverified editions stay review-bound."""

    def test_unknown_year_is_review_bound(self):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cfg = load_subject_config_by_code_and_level("9700", "A-Level", year="1999")
        self.assertIsNotNone(cfg)
        self.assertTrue(cfg.year_review_required)
        self.assertFalse(cfg.year_verified)
        self.assertIn("YEAR UNVERIFIED", buf.getvalue())

    def test_supported_year_stays_quiet(self):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            cfg = load_subject_config_by_code_and_level("9700", "A-Level", year="2026")
        self.assertIsNotNone(cfg)
        self.assertNotIn("YEAR FLAG", buf.getvalue())


class TestIdentitySeeds(unittest.TestCase):
    """Spec tests 1 & 15 (identity parse; two subjects same session)."""

    def test_identity_parse(self):
        info = parse_paper_filename(Path("9701_s15_qp_12.pdf"))
        self.assertIsNotNone(info)
        self.assertEqual((info.syllabus_code, info.season_letter,
                          info.year_short, info.paper_type, info.variant),
                         ("9701", "s", "15", "qp", "12"))

    def test_variantless_er_is_er_not_drop(self):
        info = parse_paper_filename(Path("0620_s15_er.pdf"))
        self.assertIsNotNone(info)
        self.assertEqual(info.paper_type, "er")

    def test_two_subjects_same_variant_session_year_isolate(self):
        from engine.discoverer import Discoverer
        paths = [Path("9701_s15_qp_12.pdf"), Path("9701_s15_ms_12.pdf"),
                 Path("9701_s15_er.pdf"),
                 Path("0620_s16_qp_21.pdf"), Path("0620_s16_ms_21.pdf"),
                 Path("0620_s15_er.pdf")]
        with contextlib.redirect_stdout(io.StringIO()):
            groups = {g.paper_code: g for g in Discoverer().discover_paths(paths)}
        self.assertIn("9701_s15_12", groups)
        self.assertIn("0620_s16_21", groups)
        # ERs attach to their own subject only
        self.assertEqual(groups["9701_s15_12"].er_path.name, "9701_s15_er.pdf")
        self.assertIsNone(groups["0620_s16_21"].er_path)
        self.assertIn("0620_s15_er", groups)   # no-sibling ER group kept


class TestF6CompletenessGateIntegration(unittest.TestCase):
    """Defect 6: a paper with 0 detected questions must NOT complete."""

    def _tiny_pdf(self, path: Path, title: str):
        from reportlab.pdfgen import canvas
        c = canvas.Canvas(str(path))
        c.drawString(72, 770, title + " — page with no question markers")
        c.showPage()
        c.drawString(72, 770, "Another content-less page.")
        c.showPage()
        c.save()

    def test_markerless_paper_fails_closed(self):
        tmp = Path(tempfile.mkdtemp(prefix="f6_run_"))
        try:
            inp, out = tmp / "in", tmp / "out"
            inp.mkdir()
            self._tiny_pdf(inp / "9700_s15_qp_22.pdf", "QP")
            self._tiny_pdf(inp / "9700_s15_ms_22.pdf", "MS")
            r = subprocess.run(
                [sys.executable, "-u", str(PROJ / "run_guarded.py"),
                 "--input", str(inp), "--output", str(out), "--low-ram"],
                capture_output=True, text=True, timeout=600, cwd=str(PROJ))
            # fail-closed chain: S2 gate ("at least 1 question") fires → worker
            # aborts loudly → runner exits nonzero; NOTHING is marked complete.
            self.assertNotEqual(r.returncode, 0,
                                "run must abort loudly on a marker-less paper")
            reports = list(out.rglob("failure_report.txt"))
            self.assertTrue(reports, "failure_report.txt must be written")
            self.assertIn("at least 1 question", r.stdout)
            # nothing half-built: no question webp was written
            self.assertEqual([p for p in out.rglob("*.webp")], [])
            # and no state file claims completion (if any state exists at all)
            for sf in out.rglob(".pipeline_state.json"):
                st = json.loads(sf.read_text())
                for rec in st.get("papers", {}).values():
                    self.assertNotEqual(rec.get("status"), "complete")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class TestDefect3MultiPageRegression(unittest.TestCase):
    """Spec item E: continuation pages never disappear (approved artifacts)."""

    @unittest.skipUnless(RS2_TREE.exists(), "RS-2 approved tree absent")
    def test_approved_4page_question_is_stitched_tall(self):
        hits = list(RS2_TREE.rglob("22_Winter_2025_Q1.webp"))
        self.assertEqual(len(hits), 1)
        im = Image.open(hits[0])
        self.assertEqual(im.width, 2280)
        self.assertGreater(im.height, 10000,
                           f"stitched 4-section Q1 must be tall; got {im.size}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
