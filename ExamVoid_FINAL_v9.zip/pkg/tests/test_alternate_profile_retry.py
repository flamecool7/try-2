from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

import core.bundle_worker as bw  # noqa: E402


class TestAlternateProfileRetry(unittest.TestCase):
    def test_bundle_worker_module_loads(self):
        self.assertTrue(hasattr(bw, 'process_bundle'))
        self.assertTrue(Path(bw.__file__).exists())


if __name__ == "__main__":
    unittest.main()
