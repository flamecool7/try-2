from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

import run_guarded  # noqa: E402


class TestContinueOnPaperFailure(unittest.TestCase):
    def test_record_paper_failure_stashes_log_and_report(self):
        tmp = Path(tempfile.mkdtemp(prefix="paper_fail_"))
        (tmp / "failure_report.txt").write_text(
            "failure_report\nFAIL  at least 1 question: 0 questions\n",
            encoding="utf-8",
        )
        meta = run_guarded._record_paper_failure(
            tmp,
            "0580_s24_42",
            1,
            "some header\nFAIL  at least 1 question: 0 questions\n",
        )
        fail_root = tmp / "paper_failures" / "0580_s24_42"
        self.assertTrue((fail_root / "worker_log.txt").exists())
        self.assertTrue((fail_root / "failure_report.txt").exists())
        self.assertTrue((fail_root / "summary.json").exists())
        self.assertFalse((tmp / "failure_report.txt").exists())
        self.assertIn("at least 1 question", meta["reason"])

    def test_write_failed_papers_report_creates_txt_and_json(self):
        tmp = Path(tempfile.mkdtemp(prefix="paper_fail_report_"))
        txt, js = run_guarded._write_failed_papers_report(tmp, [{
            "paper": "0580_s24_42",
            "worker_exit_code": 1,
            "reason": "at least 1 question",
            "failure_report": "paper_failures/0580_s24_42/failure_report.txt",
            "worker_log": "paper_failures/0580_s24_42/worker_log.txt",
        }])
        self.assertTrue(txt.exists())
        self.assertTrue(js.exists())
        self.assertIn("0580_s24_42", txt.read_text(encoding="utf-8"))
        payload = json.loads(js.read_text(encoding="utf-8"))
        self.assertEqual(payload["failed_papers"][0]["paper"], "0580_s24_42")

    def test_soft_fail_stage_does_not_abort_immediately(self):
        tmp = Path(tempfile.mkdtemp(prefix="gate_soft_"))
        gate = run_guarded.Gate(tmp)

        def stage(check):
            check("worker process exited cleanly", False, "exit=1")
            return 0

        gate.run_stage("S5", "paper worker result [0580_s24_42]", stage, abort_on_fail=False)
        self.assertEqual(len(gate.stage_results), 1)
        with self.assertRaises(SystemExit) as cm:
            gate.finish_all("soft-fail batch", paper_failures=[{"paper": "0580_s24_42"}])
        self.assertEqual(cm.exception.code, 1)


if __name__ == "__main__":
    unittest.main()
