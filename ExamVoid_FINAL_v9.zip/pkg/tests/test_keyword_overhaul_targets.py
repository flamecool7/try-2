from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level, validate_all_configs  # noqa: E402


def _matched(text: str, variant: str = "22", marks: int = 6):
    return SimpleNamespace(
        qp=SimpleNamespace(text=text, marks=marks),
        ms=None,
        variant=variant,
        year="2026",
        season="Spring",
        question_number="Q1",
        full_qp_code="TEST_QP",
    )


class TestKeywordOverhaulTargets(unittest.TestCase):
    def test_configs_still_validate(self):
        ok, errs = validate_all_configs()
        self.assertTrue(ok, errs)

    def test_9701_equilibria(self):
        cfg = load_subject_config_by_code_and_level("9701", "A-Level", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "The equilibrium constant Kc is calculated from concentrations. "
            "Use Le Chatelier's principle to explain the change in position of equilibrium."
        ))
        self.assertEqual(res.winning_major, "Equilibria")

    def test_9701_generic_chemistry_stays_nonempty(self):
        cfg = load_subject_config_by_code_and_level("9701", "A-Level", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "This chemistry question asks for a brief explanation of the result."
        ))
        self.assertIn(res.fallback_tier, {"review_required", "scored", "forced_best_fit"})

    def test_9700_transport_in_plants(self):
        cfg = load_subject_config_by_code_and_level("9700", "A-Level", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "Explain how xylem, phloem and companion cells are involved in translocation and the transpiration stream."
        ))
        self.assertEqual(res.winning_major, "Transport_in_plants")

    def test_0620_electrochemistry(self):
        cfg = load_subject_config_by_code_and_level("0620", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "During electrolysis of brine, state what forms at the anode and cathode and explain selective discharge."
        ))
        self.assertEqual(res.winning_major, "Electrochemistry")

    def test_0610_excretion(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "Describe ultrafiltration and selective reabsorption in the nephron of the kidney."
        ))
        self.assertEqual(res.winning_major, "Excretion_in_humans")

    def test_0625_space_physics(self):
        cfg = load_subject_config_by_code_and_level("0625", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "Explain redshift using Hubble's law and state what a light year measures."
        ))
        self.assertEqual(res.winning_major, "Space_physics")

    def test_0606_system_level_handles_low_evidence(self):
        cfg = load_subject_config_by_code_and_level("0606", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "zzzz qqqq xxxx", variant="12"
        ))
        self.assertIn(res.fallback_tier, {"review_required", "scored", "forced_best_fit"})


if __name__ == "__main__":
    unittest.main()
