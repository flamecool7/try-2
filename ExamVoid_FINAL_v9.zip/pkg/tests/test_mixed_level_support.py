from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent

try:
    from reportlab.pdfgen import canvas as _canvas_mod
    HAS_REPORTLAB = True
except Exception:
    HAS_REPORTLAB = False


@unittest.skipUnless(HAS_REPORTLAB, "reportlab not installed")
class TestMixedLevelSupport(unittest.TestCase):
    def _tiny_pdf(self, path: Path, title: str):
        from reportlab.pdfgen import canvas
        c = canvas.Canvas(str(path))
        c.drawString(72, 770, title)
        c.showPage()
        c.save()

    def test_run_guarded_dry_run_accepts_mixed_igcse_and_alevel_inputs(self):
        tmp = Path(tempfile.mkdtemp(prefix="mixed_levels_"))
        inp = tmp / "input"
        out = tmp / "output"
        inp.mkdir()
        self._tiny_pdf(inp / "0620_m26_qp_12.pdf", "IGCSE Chemistry QP")
        self._tiny_pdf(inp / "0620_m26_ms_12.pdf", "IGCSE Chemistry MS")
        self._tiny_pdf(inp / "9701_m26_qp_12.pdf", "A-Level Chemistry QP")
        self._tiny_pdf(inp / "9701_m26_ms_12.pdf", "A-Level Chemistry MS")
        r = subprocess.run(
            [sys.executable, "-u", str(PROJ / "run_guarded.py"),
             "--input", str(inp), "--output", str(out), "--dry-run"],
            capture_output=True, text=True, timeout=600, cwd=str(PROJ)
        )
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("'A-Level': ['Chemistry_9701']", r.stdout)
        self.assertIn("'IGCSE': ['Chemistry_0620']", r.stdout)
        self.assertIn("0620_m26_12: qp=Y ms=Y", r.stdout)
        self.assertIn("9701_m26_12: qp=Y ms=Y", r.stdout)


if __name__ == "__main__":
    unittest.main()
