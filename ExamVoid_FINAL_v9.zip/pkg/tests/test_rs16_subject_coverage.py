"""RS-16 coverage tests — the 8 target syllabus profiles end-to-end evidence.

Pins:
 * MCQ registry correctness for all 8 codes (IGCSE sciences MCQ P1+P2 grids,
   A-Level sciences MCQ P1, maths none),
 * config presence + required keys for every target profile,
 * the portrait-era (legacy) MS splitter on the six REAL 2015/2016 A-Level /
   IGCSE mark schemes it was built for (question-number sequences proven
   against the locked QP splitter at build time),
 * fixture pin manifest completeness for the RS-16 additions.
"""
import json
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

FIXTURES = PROJ.parent / "test-crops" / "fixtures" / "remote"

TARGETS = [
    ("0610", "IGCSE", "Biology_0610"),
    ("0620", "IGCSE", "Chemistry_0620"),
    ("0625", "IGCSE", "Physics_0625"),
    ("0580", "IGCSE", "Mathematics_0580"),
    ("9700", "A-Level", "Biology_9700"),
    ("9701", "A-Level", "Chemistry_9701"),
    ("9702", "A-Level", "Physics_9702"),
    ("9709", "A-Level", "Mathematics_9709"),
]

REQUIRED_CONFIG_KEYS = {"subject", "syllabus_code", "board", "level",
                        "syllabus_years", "official_source", "version",
                        "major_topics", "detailed_topics", "mapping",
                        "classification_keywords", "specialization_weights",
                        "syllabus_order", "folder_naming", "validation"}


class TestTargetProfiles(unittest.TestCase):
    def test_all_8_configs_present_with_required_keys(self):
        for code, level, subject in TARGETS:
            cfg_path = PROJ / "subjects" / level / subject / "config.json"
            self.assertTrue(cfg_path.exists(), f"missing {cfg_path}")
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
            self.assertEqual(cfg["syllabus_code"], code)
            self.assertEqual(cfg["level"], level)
            missing = REQUIRED_CONFIG_KEYS - set(cfg)
            self.assertFalse(missing, f"{subject} missing keys: {missing}")

    def test_mcq_registry_truthtable(self):
        from core.mcq_registry import get_all_mcq_codes
        reg = get_all_mcq_codes()
        for code in ("0610", "0620", "0625"):
            self.assertEqual(reg.get(code), {"11", "12", "13", "21", "22", "23"},
                             f"{code} IGCSE MCQ papers are Extended+Core P1/P2")
        for code in ("9700", "9701", "9702"):
            self.assertEqual(reg.get(code), {"11", "12", "13"},
                             f"{code} A-Level MCQ is Paper 1 only")
        for code in ("0580", "9709"):
            self.assertEqual(reg.get(code, set()), set(), f"{code} has NO MCQ papers")


@unittest.skipUnless(FIXTURES.is_dir(), "fixture corpus not downloaded")
class TestLegacyPortraitMSSplitter(unittest.TestCase):
    """core/legacy_ms_split.py on the REAL legacy mark schemes. Expected
    question-number runs were proven against the locked QP splitter during
    the RS-16 build; crop width/ink assertions pin the raster contract."""

    CASES = {
        "9700_s15_ms_22.pdf": (6, [1, 2, 3, 4, 5, 6]),
        "9701_s15_ms_22.pdf": (4, [1, 2, 3, 4]),
        "9701_s15_ms_42.pdf": (9, [1, 2, 3, 4, 5, 6, 7, 8, 9]),
        "9702_s15_ms_22.pdf": (7, [1, 2, 3, 4, 5, 6, 7]),
        "9709_s15_ms_12.pdf": (11, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]),
        "9709_s15_ms_42.pdf": (7, [1, 2, 3, 4, 5, 6, 7]),
    }

    def test_all_six_fixtures_split_valid(self):
        from core.legacy_ms_split import split_legacy_portrait_ms
        for name, (count, seq) in self.CASES.items():
            path = FIXTURES / name
            if not path.exists():
                self.skipTest(f"{name} not downloaded")
            pieces, diag = split_legacy_portrait_ms(path, dpi=150,
                                                    expected_top_numbers=seq)
            self.assertEqual(sorted(pieces), seq,
                             f"{name}: {sorted(pieces)} != {seq} ({diag.split_notes})")
            for q, img in pieces.items():
                self.assertGreaterEqual(img.width, 400, f"{name} Q{q} raster sane")
                self.assertGreaterEqual(img.height, 40, f"{name} Q{q} min height")

    def test_fail_closed_without_qp_proof(self):
        """No QP-proven expectation -> the splitter must refuse ({}), never guess."""
        from core.legacy_ms_split import split_legacy_portrait_ms
        path = FIXTURES / "9701_s15_ms_22.pdf"
        if not path.exists():
            self.skipTest("fixture not downloaded")
        pieces, _diag = split_legacy_portrait_ms(path, dpi=150,
                                                 expected_top_numbers=[1, 2, 3, 4, 99])
        self.assertEqual(pieces, {}, "must fail closed when the 1..N run cannot "
                                     "equal the QP-proven expectation")


class TestFixturePinManifest(unittest.TestCase):
    def test_manifest_covers_rs16_fixtures(self):
        man = json.loads((PROJ / "tools/fixture_manifest.json").read_text())
        names = {f["file"] for f in man.get("fixtures", [])}
        for need in ("remote/0610_s16_qp_22.pdf", "remote/0610_s16_ms_42.pdf",
                     "remote/0625_s16_qp_22.pdf", "remote/0625_s16_ms_42.pdf",
                     "remote/0580_s15_qp_22.pdf", "remote/0580_s15_ms_22.pdf",
                     "remote/9702_s15_qp_22.pdf", "remote/9702_s15_ms_22.pdf",
                     "remote/9709_s15_ms_12.pdf", "remote/9700_s15_qp_22.pdf"):
            self.assertIn(need, names, f"manifest missing {need}")
        for f in man.get("fixtures", []):
            self.assertRegex(f.get("sha256", ""), r"^[0-9a-f]{64}$",
                             f"{f['file']} must carry a full sha256 pin")
            self.assertGreater(int(f.get("bytes", 0)), 5000,
                               f"{f['file']} size pin sanity")


if __name__ == "__main__":
    unittest.main()
