import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.math_reference import (  # noqa: E402
    classify_0580_question,
    classify_0606_question,
    classify_9231_question,
    classify_9709_question,
    reference_topics_for_subject_paper,
)


class TestFurtherMath9231RoutingRegressions(unittest.TestCase):
    def test_reference_topics_are_canonicalized_for_output(self):
        p4 = reference_topics_for_subject_paper("9231", 4)
        self.assertIn("Inference_using_normal_and_t_distributions", p4)
        self.assertIn("Non_parametric_tests", p4)
        self.assertNotIn("Inference_using_normal_and_t-distributions", p4)
        self.assertNotIn("Non-parametric_tests", p4)

    def test_p3_includes_hookes_law_topic(self):
        self.assertIn("Hooke's_law", reference_topics_for_subject_paper("9231", 3))

    def test_t_distribution_routes_to_config_safe_topic(self):
        q = (
            "A random sample is taken from a normal population. Use the t-distribution "
            "to construct a confidence interval for the population mean."
        )
        self.assertEqual(
            classify_9231_question(q, 4),
            "Inference_using_normal_and_t_distributions",
        )

    def test_non_parametric_routes_to_config_safe_topic(self):
        q = "Carry out a non-parametric sign test using the ranks of the paired data."
        self.assertEqual(classify_9231_question(q, 4), "Non_parametric_tests")

    def test_hookes_law_is_not_lost_inside_variable_force_bucket(self):
        q = (
            "A particle is attached to an elastic spring obeying Hooke's law. "
            "Find the extension when the spring constant and natural length are given."
        )
        self.assertEqual(classify_9231_question(q, 3), "Hooke's_law")

    def test_9709_confident_phrase_bonus_hits_stats(self):
        q = (
            "State the null hypothesis and use the critical value to decide whether "
            "the sample provides evidence against H0."
        )
        self.assertEqual(classify_9709_question(q, 6), "Hypothesis_tests")

    def test_0580_phrase_bonus_prefers_transformations(self):
        q = "Describe the enlargement and state the centre of enlargement of the image of triangle A."
        self.assertEqual(classify_0580_question(q), "Transformations_and_vectors")

    def test_0606_phrase_bonus_prefers_circle_geometry(self):
        q = "Find the equation of a circle and the tangent to the circle at the given point."
        self.assertEqual(classify_0606_question(q), "Coordinate_geometry_of_the_circle")

    def test_0606_formula_notation_routes_calculus(self):
        q = "Given that d/dx (x^2 + 3x) = 2x + 3, find the stationary point and hence the gradient."
        self.assertEqual(classify_0606_question(q), "Calculus")

    def test_0606_formula_notation_routes_circle(self):
        q = "The curve satisfies x^2 + y^2 = 25. Find the tangent to the circle at the point where x = 3."
        self.assertEqual(classify_0606_question(q), "Coordinate_geometry_of_the_circle")

    def test_low_evidence_close_tie_abstains(self):
        # RS-41 round 2 (2026-08-13): a SINGLE distinctive keyword with NO
        # competitor now routes — corpus-measured on 0606_s24, where
        # "logarithm"/"expansion"/"velocity" single-signal questions were
        # wrongly sent to review_required. "area" alone is a distinctive
        # Mensuration signal. Zero evidence still abstains (fail-closed).
        q = "Find the area shown in the diagram."
        self.assertEqual(classify_0580_question(q), "Mensuration")
        self.assertIsNone(classify_0580_question("In the diagram,"))

    def test_clear_single_math_signal_no_longer_abstains(self):
        q = "Use the nth term of the arithmetic progression to find the next three terms of the sequence."
        self.assertEqual(classify_0580_question(q), "Algebra_and_graphs")


if __name__ == "__main__":
    unittest.main()
