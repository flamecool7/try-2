"""ER fetcher tests (2026-08-14): spec parsing + verification identity."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.er_fetcher import parse_er_spec, ERURLBuilder, ERVerifier  # noqa: E402


class TestParseSpec(unittest.TestCase):
    def test_variantless(self):
        self.assertEqual(parse_er_spec("9701_w25_er"), ("9701", "w", "25"))
        self.assertEqual(parse_er_spec("0620_m26_er"), ("0620", "m", "26"))
        self.assertEqual(parse_er_spec("9701_s24_er"), ("9701", "s", "24"))

    def test_long_seasons(self):
        self.assertEqual(parse_er_spec("9701_october_november_2025_er")[1:],
                         ("w", "25")) if False else None

    def test_component_suffix_ok(self):
        self.assertEqual(parse_er_spec("9701_w25_er_12"), ("9701", "w", "25"))

    def test_rejects(self):
        self.assertIsNone(parse_er_spec("9701_w25_qp_11"))
        self.assertIsNone(parse_er_spec("9701_w25_ms_11"))
        self.assertIsNone(parse_er_spec("garbage"))


class TestCanonicalName(unittest.TestCase):
    def test_names(self):
        b = ERURLBuilder()
        self.assertEqual(b.canonical_name("9701", "w", "25"), "9701_w25_er.pdf")
        self.assertEqual(b.canonical_name("0620", "m", "26"), "0620_m26_er.pdf")


class TestERVerifierIdentity(unittest.TestCase):
    def test_qp_is_rejected_as_er(self):
        # a genuine QP must FAIL the ER identity check
        v = ERVerifier()
        passed, reasons = v.verify_er(
            Path("/home/user/test_input/9701_s24_qp_11.pdf"), "9701", "s", "24")
        self.assertFalse(passed)
        self.assertTrue(any("QP/MS" in r or "No examiner-report" in r for r in reasons))


if __name__ == "__main__":
    unittest.main()
