"""Classification buffs (2026-08-13): MCQ option down-weighting, phrase
whitespace tolerance, paper-coherence prior, and corpus math vocabulary.

These pin the behaviors measured on the June-2024 corpus (385 questions,
reviews 10 -> 2)."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier, _split_subpart_options  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level, validate_all_configs  # noqa: E402
from core.math_reference import classify_0580_question  # noqa: E402


def _matched(text: str, variant: str = "11", marks: int = 4):
    return SimpleNamespace(
        qp=SimpleNamespace(text=text, marks=marks),
        ms=None,
        variant=variant,
        year="2024",
        season="Summer",
        question_number="Q1",
        full_qp_code="TEST_QP",
    )


class TestOptionSplitter(unittest.TestCase):
    def test_mcq_layout_split(self):
        stem, opts = _split_subpart_options(
            "which gas is produced when ammonium chloride is warmed with "
            "aqueous sodium hydroxide?\n24\na\nammonia\nb\nnitrogen\nc\noxygen")
        self.assertIn("sodium hydroxide", stem)
        self.assertIn("ammonia", opts)
        self.assertIn("nitrogen", opts)

    def test_no_option_layout(self):
        stem, opts = _split_subpart_options(
            "describe the structure of the kidney nephron and explain "
            "ultrafiltration.\n(a) [3]")
        self.assertEqual(opts, "")
        self.assertIn("kidney", stem)


class TestOptionDownWeighting(unittest.TestCase):
    def test_stem_signal_beats_option_only(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", "2024")
        clf = TopicClassifier(cfg)
        # stem clearly plant nutrition; options stuffed with other topics
        res = clf.classify_question(_matched(
            "Which process do green plants use to make glucose from carbon "
            "dioxide and water in the presence of light?\n"
            "a\nrespiration\nb\nphotosynthesis\nc\ntranspiration\nd\nexcretion"))
        self.assertEqual(res.winning_major, "Plant_nutrition")


class TestPhraseWhitespace(unittest.TestCase):
    def test_newline_split_phrase_matches(self):
        cfg = load_subject_config_by_code_and_level("9701", "A-Level", "2024")
        clf = TopicClassifier(cfg)
        # extraction inserts newlines between words of a phrase
        res = clf.classify_question(_matched(
            "2-bromopropane is converted to 1,2-dibromopropane in a pathway "
            "involving two reactions.\nwhat are the reagents\nand\nconditions "
            "for the two reactions?"))
        self.assertEqual(res.winning_major, "Organic_synthesis")


class TestCoherencePrior(unittest.TestCase):
    def test_prior_resolves_ambiguity(self):
        cfg = load_subject_config_by_code_and_level("0620", "IGCSE", "2024")
        clf = TopicClassifier(cfg)
        ambiguous = _matched(
            "which gas is produced when ammonium chloride is warmed with "
            "aqueous sodium hydroxide?\na\nammonia\nb\nnitrogen\nc\noxygen")
        # without prior it may be ambiguous or routed; with a strong
        # paper prior toward Acids_bases_and_salts it must route there when
        # the pre-prior state is ambiguous (or already routed to it)
        prior = {"Acids_bases_and_salts": 4, "Stoichiometry": 3}
        res = clf.classify_question(ambiguous, coherence_prior=prior)
        self.assertTrue(res.winning_major in ("", "review_required")
                        or res.winning_major == "Acids_bases_and_salts")
        # and a prior must never flip a confident non-ambiguous winner
        confident = _matched(
            "describe the tests for the presence of water and how to show "
            "that a liquid is pure water")
        base = clf.classify_question(confident)
        if base.winning_major:
            priored = clf.classify_question(
                confident, coherence_prior={"Some_other_topic": 99})
            self.assertEqual(priored.winning_major, base.winning_major)


class TestMathCorpusVocabulary(unittest.TestCase):
    def test_math_corpus_cases(self):
        cases = {
            "calculate. . 343 40 96 3 -": "Number",
            "the value of a car is $8000. each year the value decreases exponentially": "Number",
            "write .0 146o o as a fraction in its simplest form.": "Number",
            "find the inequalities that define the unshaded region r": "Algebra_and_graphs",
            "factorise completely. m t 12 75 2 2 -": "Algebra_and_graphs",
        }
        for text, want in cases.items():
            self.assertEqual(classify_0580_question(text, None), want, text)

    def test_no_regression_on_trig(self):
        self.assertEqual(
            classify_0580_question("solve the equation sinx = 0.5 for x between 0 and 360", None),
            "Trigonometry")


class TestConfigsStillValidate(unittest.TestCase):
    def test_all_configs_validate(self):
        ok, errs = validate_all_configs()
        self.assertTrue(ok, errs)


if __name__ == "__main__":
    unittest.main()
