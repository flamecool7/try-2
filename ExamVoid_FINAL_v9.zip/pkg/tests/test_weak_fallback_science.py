from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level  # noqa: E402


def _matched(text: str, subject_variant: str = "52", marks: int = 3):
    return SimpleNamespace(
        qp=SimpleNamespace(text=text, marks=marks),
        ms=None,
        variant=subject_variant,
        year="2026",
        season="Spring",
        question_number="Q1",
        full_qp_code="TEST_QP",
    )


class TestWeakFallbackScience(unittest.TestCase):
    def test_0610_practical_can_route_on_clear_single_topic_evidence(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "A thermostatically controlled water-bath was used. The starch and amylase mixture was tested until iodine stayed yellow-brown."
        ))
        self.assertEqual(res.winning_major, "Enzymes")
        self.assertIn(res.fallback_tier, {"scored", "weak_keyword", "forced_best_fit"})

    def test_weak_fallback_does_not_guess_when_two_topics_are_too_close(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "The student measured heart rate and breathing rate during exercise and recorded the results in a table."
        ))
        self.assertIn(res.fallback_tier, {"review_required", "scored", "weak_keyword", "forced_best_fit"})
        self.assertTrue(res.winning_major or res.fallback_tier == "review_required")


if __name__ == "__main__":
    unittest.main()
