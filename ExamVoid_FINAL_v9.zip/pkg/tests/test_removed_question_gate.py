#!/usr/bin/env python3
"""Regression: Cambridge 'question removed' notices must not fail the height gate.

Real paper 0625_s24_qp_21 Q14 prints:
  "Due to an issue with question 14, the question has been removed from the
   question paper."
That crop is legitimately ~95px tall; the 80px MIN_HEIGHT_PX floor used to
fail the bundle (exit code 1) for a completely normal paper.
"""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from run_guarded import _is_removed_question  # noqa: E402


class TestRemovedQuestionGate(unittest.TestCase):
    def test_removal_notice_detected(self):
        crop = SimpleNamespace(
            text="Due to an issue with question 14, the question has been "
                 "removed from the question paper.")
        self.assertTrue(_is_removed_question(crop))

    def test_removal_notice_variants(self):
        for t in (
            "14 Due to an issue with question 14, the question has been removed.",
            "Question 4 has been removed from this paper.",
            "This question has been removed.",
        ):
            self.assertTrue(_is_removed_question(SimpleNamespace(text=t)), t)

    def test_normal_questions_not_flagged(self):
        for t in (
            "14 A student investigates the resistance of a wire.",
            "13 Wet clothes are put out on a line to evaporate.",
            "What is the electronic configuration?",
        ):
            self.assertFalse(_is_removed_question(SimpleNamespace(text=t)), t)

    def test_empty_text_not_flagged(self):
        self.assertFalse(_is_removed_question(SimpleNamespace(text="")))


if __name__ == "__main__":
    unittest.main(verbosity=2)
