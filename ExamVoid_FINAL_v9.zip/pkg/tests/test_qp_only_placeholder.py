#!/usr/bin/env python3
"""Regression: QP-only mode (no MS supplied) must not crash.

real finding 2026-08-14 (failed_papers_report exit code 1):
  0606_s24_11 -> stopped at STAGE S5: classify + save question pairs
  AttributeError: 'NoneType' object has no attribute 'assembled_image'

save_question_pair dereferenced matched.ms.assembled_image with ms=None.
The writer now skips the MS webp, writes a `*_MS.txt` placeholder sidecar
(MS_UNAVAILABLE marker — never a fabricated mark scheme), and all validators
accept it as a legal MS-less home.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from PIL import Image

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.json_generator import CANONICAL_METADATA_FIELDS  # noqa: E402
from core.mcq_output import PLACEHOLDER_MS_CONTENT, is_placeholder_ms  # noqa: E402
from core.output_manager import OutputManager  # noqa: E402
from core.validation import FinalValidator  # noqa: E402
from tests.test_mcq_unified import _fake_classification, _fake_config  # noqa: E402


def _qp_only_matched():
    qp = SimpleNamespace(assembled_image=Image.new("RGB", (2280, 300), "white"),
                         question_number="Q1", number_int=1, text="Solve x.")
    return SimpleNamespace(
        qp=qp, ms=None, ms_answer=None, variant="42",
        paper_code="0606_s24_42", full_qp_code="0606_s24_qp_42",
        full_ms_code=None, question_number="Q1", season="Summer", year="2024",
    )


class TestQpOnlyPlaceholder(unittest.TestCase):
    def test_save_without_ms_writes_placeholder(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_qp_only_matched(),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            self.assertIsNone(saved["ms"], "no MS webp expected")
            # QP webp + placeholder sidecar + canonical metadata
            self.assertTrue(list(qf.glob("*.webp")), "QP webp missing")
            self.assertEqual(list(qf.glob("*_MS.webp")), [], "MS webp fabricated")
            txts = list(qf.glob("*_MS.txt"))
            self.assertEqual(len(txts), 1, "placeholder _MS.txt missing")
            self.assertTrue(is_placeholder_ms(txts[0].read_text()), txts[0].read_text())
            # User requirement (2026-08-14): categorized + reason for review
            reason = qf / "REASON.txt"
            self.assertTrue(reason.exists(), "REASON.txt missing")
            self.assertIn("mark scheme", reason.read_text().lower())
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(set(md.keys()), set(CANONICAL_METADATA_FIELDS), md.keys())

    def test_validators_accept_placeholder(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            mgr.save_question_pair(_qp_only_matched(), _fake_classification(),
                                   _fake_config(tmp))
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertEqual(v.errors, [], v.errors)

    def test_tampered_placeholder_flagged(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(_qp_only_matched(),
                                           _fake_classification(),
                                           _fake_config(tmp))
            qf = Path(saved["question_folder"])
            (qf / f"{qf.name}_MS.txt").write_text("GARBAGE\n")
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertTrue(any("_MS.txt invalid content" in e for e in v.errors),
                            v.errors)

    def test_placeholder_marker_constants(self):
        self.assertEqual(PLACEHOLDER_MS_CONTENT, "MS_UNAVAILABLE")
        self.assertTrue(is_placeholder_ms("MS_UNAVAILABLE\n"))
        self.assertTrue(is_placeholder_ms("ms_unavailable"))
        self.assertFalse(is_placeholder_ms("B"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
