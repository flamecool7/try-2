"""Instruction-boilerplate junk detection (Amendment 11, 2026-08-14).

The Cambridge instruction block ("Answer all the questions in the spaces
provided.") printed at the top of the first question page must be recognised
as junk (top band only) so it never leaks into page-level crops or gets
pulled into a question's first line. Span-split lines must be matched at
LINE level."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.question_split import (  # noqa: E402
    _classify_header_span,
    _INSTRUCTION_SIGNS,
)


class TestInstructionSigns(unittest.TestCase):
    def test_signs_present(self):
        self.assertIn("answer all the questions", _INSTRUCTION_SIGNS)
        self.assertIn("in the spaces provided", _INSTRUCTION_SIGNS)

    def test_span_classified_in_top_band(self):
        f = _classify_header_span(
            "the questions in the spaces provided.", 100, 60, 400, 72, 10,
            w=595, h=842)
        self.assertTrue(f["instructions"])

    def test_not_junk_outside_top_band(self):
        # same phrase lower on the page (e.g. a section header) must NOT be junk
        f = _classify_header_span(
            "Answer all the questions in this section.", 100, 300, 400, 312, 10,
            w=595, h=842)
        self.assertFalse(f["instructions"])

    def test_bare_answer_span_not_junk_alone(self):
        # the split span "Answer" alone carries no sign — line-level joining
        # in _analyse_page_top handles the full line; a lone span must not
        # fire (so genuine content words are never junked).
        f = _classify_header_span("Answer", 179, 60, 219, 72, 10, w=595, h=842)
        self.assertFalse(f["instructions"])

    def test_ordinary_question_stem_not_junk(self):
        f = _classify_header_span(
            "Which process do living organisms use to remove excess carbon "
            "dioxide from their bodies?", 50, 63, 517, 74, 10, w=595, h=842)
        self.assertFalse(f["instructions"])


if __name__ == "__main__":
    unittest.main()
