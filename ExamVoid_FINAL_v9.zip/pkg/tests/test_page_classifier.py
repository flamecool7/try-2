#!/usr/bin/env python3
"""Page-classifier defect round (RS-12) — pins the three approved decisions.

D1 shim:            cambridge_qb-bound relatives resolve to core.chemistry_reference
D2 ordered-veto:    PT grid beats the MCQ-broadened question probe; content-sign
                    detectors never veto real question pages
D3 rescue:          question start beyond a back-matter sign keeps the page
Regression rails:   is_terminal fallback never reintroduced; A-level baseline
                    classification unchanged; no question page in the corpus lost.

Every pinned page verdict below was ground-truthed against the page text
(see test-crops/redesign/PAGE_CLASSIFIER_ROUND_EVIDENCE.md).
"""
import os
import subprocess
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
FIXTURES = PROJ.parent / "test-crops" / "fixtures" / "remote"
UPLOADS = PROJ.parent / "uploads"

sys.path.insert(0, str(PROJ))

import fitz  # noqa: E402

from core import chemistry_reference as cr  # noqa: E402
from core.chemistry_reference import classify_page  # noqa: E402


def _removed(pdf: Path):
    doc = fitz.open(pdf)
    got = {}
    for i in range(doc.page_count):
        c = classify_page(doc, i, doc.page_count)
        if c.is_reference or c.is_blank or c.is_candidate_info:
            got[i + 1] = c.category
    doc.close()
    return got


class TestWireup(unittest.TestCase):
    def test_d1_shim_binds_gold_relative_imports_to_core_copy(self):
        """D1: clean-interpreter proof that the sys.modules pre-seed engages
        before any cambridge_qb import, and that question_split +
        quality_control see the CORE classifier through their relative import."""
        code = (
            "import sys; sys.path.insert(0, r'%s');"
            "import core.cropping_engine as ce;"
            "import core.chemistry_reference as core_cr;"
            "m = sys.modules['cambridge_qb.chemistry_reference'];"
            "assert m is core_cr, ('module mismatch', m.__file__);"
            "from cambridge_qb import question_split as gqs;"
            "assert gqs.classify_page is core_cr.classify_page, 'question_split binding';"
            "assert gqs.identify_removable_pages is core_cr.identify_removable_pages;"
            "from cambridge_qb import quality_control as gqc;"
            "assert gqc.ADMIN_BACK_MATTER_SIGNS is core_cr.ADMIN_BACK_MATTER_SIGNS;"
            "import cambridge_qb.chemistry_reference as direct;"
            "assert direct is core_cr;"
            "print('wireup OK')"
            % PROJ
        )
        r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, f"wireup failed:\n{r.stdout}\n{r.stderr}")
        self.assertIn("wireup OK", r.stdout)


class TestVetoAndRescueSemantics(unittest.TestCase):
    SYN_QPAGE = (
        "1 Which statement is correct?\nA Water boils at 100 oC.\nB Ice is denser than water.\n"
        "C Steam is an element.\nD Salt melts at 0 oC.\n"
    )

    def test_d2_veto_order_pt_beats_question_probe(self):
        """Ordered-veto: if the question probe would fire AND the PT grid
        detector fires, periodic_table must win (core/as-is regression rail)."""
        src_q = cr._page_has_question_structure
        src_pt = cr._detect_periodic_table_grid
        try:
            cr._page_has_question_structure = lambda doc, i: True
            cr._detect_periodic_table_grid = lambda text, words: (True, 1.0)
            doc = self._mk_multipage(16, {11: self.SYN_QPAGE})
            c = classify_page(doc, 11, 16)
            self.assertEqual(c.category, "periodic_table")
            self.assertTrue(c.is_reference)
        finally:
            cr._page_has_question_structure = src_q
            cr._detect_periodic_table_grid = src_pt

    def _pdf_bytes(self, text=None):
        import io
        import reportlab.lib.pagesizes
        from reportlab.pdfgen import canvas
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=reportlab.lib.pagesizes.A4)
        y = 700  # fitz-y ~142: inside the 6%-92% body clip, not the header zone
        for line in (text or self.SYN_QPAGE).splitlines():
            c.drawString(72, y, line[:110])
            y -= 14
        c.save()
        return buf.getvalue()

    def _mk_multipage(self, n_pages, page_texts):
        """n_pages-page in-memory PDF; page_texts maps 0-idx page -> text
        (other pages get a dense question page so they classify as content)."""
        import io
        import reportlab.lib.pagesizes
        from reportlab.pdfgen import canvas
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=reportlab.lib.pagesizes.A4)
        for i in range(n_pages):
            y = 700  # fitz-y ~142: inside the 6%-92% body clip, not the header zone
            for line in page_texts.get(i, self.SYN_QPAGE).splitlines():
                c.drawString(72, y, line[:110])
                y -= 14
            c.showPage()
        c.save()
        return fitz.open(stream=buf.getvalue(), filetype="pdf")

    def test_d3_rescue_question_beyond_sign(self):
        """Poison layout: copyright block ABOVE, question BELOW -> kept."""
        text = ("Permission to reproduce items where third-party owned material is included.\n"
                "Every reasonable effort has been made by the publisher (UCLES).\n\n"
                "38 What is an advantage of fermentation?\nA The alcohol produced is purer.\n"
                "B The process is faster.\nC It uses high temperature.\nD It is renewable.\n")
        doc = fitz.open(stream=self._pdf_bytes(text), filetype="pdf")
        c = classify_page(doc, 0, 1)
        self.assertEqual(c.category, "question_content")
        self.assertFalse(c.is_reference)

    def test_d3_pure_admin_still_removed(self):
        """Pure copyright page (no question beyond the sign) -> still removed."""
        text = ("16\nPermission to reproduce items where third-party owned material is included.\n"
                "Every reasonable effort has been made by the publisher (UCLES) to trace holders.\n"
                "Cambridge International Examinations is part of the Cambridge Assessment Group.\n"
                "0620/22/M/J/16\n")
        doc = fitz.open(stream=self._pdf_bytes(text), filetype="pdf")
        c = classify_page(doc, 0, 1)
        self.assertEqual(c.category, "admin_back_matter")
        self.assertTrue(c.is_reference)

    _DETECTORS_1ARG = ("_detect_qualitative_analysis_notes",
                       "_detect_electrode_potentials_table", "_detect_spectroscopy_table",
                       "_detect_data_booklet_or_constants", "_detect_formula_sheet",
                       "_detect_admin_back_matter")
    _SPARSE = "End of paper. Nothing further is printed on this trailing prose page.\n"

    def _nullify_all_detectors(self):
        saved = {"_page_has_question_structure": cr._page_has_question_structure,
                 "_detect_periodic_table_grid": cr._detect_periodic_table_grid}
        cr._page_has_question_structure = lambda doc, i: False
        cr._detect_periodic_table_grid = lambda t, w: (False, 0.0)
        for n in self._DETECTORS_1ARG:
            saved[n] = getattr(cr, n)
            setattr(cr, n, lambda t: (False, 0.0))
        return saved

    def _restore(self, saved):
        for n, fn in saved.items():
            setattr(cr, n, fn)

    def test_is_terminal_fallback_never_reintroduced(self):
        """Rail: a sparse non-question page in the LAST six pages must NOT be
        force-classified admin_back_matter (the original gold data-loss bug:
        gold line `if is_adm or is_terminal:` at conf=0.80)."""
        saved = self._nullify_all_detectors()
        try:
            doc = self._mk_multipage(16, {i: self._SPARSE for i in range(10, 16)})
            for idx in range(10, 16):  # terminal window of a 16-page paper
                c = cr.classify_page(doc, idx, 16)
                self.assertNotEqual(c.category, "admin_back_matter",
                                    f"is_terminal fallback resurfaced at terminal page {idx + 1}")
        finally:
            self._restore(saved)

    def test_terminal_sparse_page_falls_to_question_content(self):
        """With every detector false and is_q false, the fallback verdict is
        question_content (delete-nothing bias) — never invented admin."""
        saved = self._nullify_all_detectors()
        try:
            doc = self._mk_multipage(16, {15: self._SPARSE})
            c = classify_page(doc, 15, 16)
            self.assertEqual(c.category, "question_content")
            self.assertFalse(c.is_reference)
        finally:
            self._restore(saved)


class TestRescueHelpers(unittest.TestCase):
    def test_first_admin_sign_pos(self):
        t = "questions first\nPermission to reproduce items here\nmore"
        self.assertEqual(cr._first_admin_sign_pos(t), t.lower().find("permission"))
        self.assertEqual(cr._first_admin_sign_pos("no signs at all"), len("no signs at all"))

    def test_has_question_start_beyond(self):
        poison_tail = ("Permission to reproduce items where third-party owned material.\n"
                       "38 What is an advantage?\nA The alcohol produced is purer.\nB The process is faster.\n")
        self.assertTrue(cr._has_question_start_beyond(poison_tail, 0))
        pure = "Permission to reproduce items where third-party owned material.\nUCLES 2016\n0620/22/M/J/16\n"
        self.assertFalse(cr._has_question_start_beyond(pure, 0))


@unittest.skipUnless((FIXTURES / "0620_s16_qp_22.pdf").exists(), "fixture corpus absent")
class TestFixturePins(unittest.TestCase):
    """D4 oracle (iii): the full ground-truthed corpus table, pinned."""

    EXPECTED = {
        "0580_s15_qp_22.pdf": {1: "candidate_info", 16: "admin_back_matter"},
        "0620_s16_qp_21.pdf": {1: "candidate_info", 17: "blank_page", 18: "blank_page",
                               19: "admin_back_matter", 20: "periodic_table"},
        "0620_s16_qp_22.pdf": {1: "candidate_info", 16: "periodic_table"},
        "0620_s16_qp_42.pdf": {1: "candidate_info", 11: "admin_back_matter",
                               12: "periodic_table"},
        "9618_s23_qp_12.pdf": {1: "candidate_info", 4: "blank_page", 15: "blank_page",
                               16: "admin_back_matter"},
        "9700_s15_qp_12.pdf": {1: "candidate_info", 18: "blank_page", 19: "blank_page",
                               20: "admin_back_matter"},
        "9700_s15_qp_22.pdf": {1: "candidate_info", 14: "blank_page", 15: "blank_page",
                               16: "admin_back_matter"},
        "9701_s15_qp_12.pdf": {1: "candidate_info", 16: "admin_back_matter"},
        "9701_s15_qp_22.pdf": {1: "candidate_info", 8: "admin_back_matter"},
        "9701_s15_qp_42.pdf": {1: "candidate_info", 18: "blank_page", 19: "blank_page",
                               20: "admin_back_matter"},
        "9709_s15_qp_12.pdf": {1: "candidate_info", 4: "admin_back_matter"},
        "9709_s15_qp_42.pdf": {1: "candidate_info"},
    }

    def test_corpus_removed_sets_exact(self):
        for name, expected in self.EXPECTED.items():
            with self.subTest(fixture=name):
                got = _removed(FIXTURES / name)
                self.assertEqual(got, expected)

    def test_terminal_mcq_pages_recovered(self):
        """The 0620_s16_qp_22 defect pages: 11/12/14 kept (is_q), 15 rescued."""
        doc = fitz.open(FIXTURES / "0620_s16_qp_22.pdf")
        for p1 in (11, 12, 14, 15):
            c = classify_page(doc, p1 - 1, doc.page_count)
            self.assertEqual(c.category, "question_content", f"page {p1} still eaten")
        doc.close()

    def test_9701_data_booklet_mention_pages_kept(self):
        """Question pages whose TEXT mentions the Data Booklet stay questions."""
        doc = fitz.open(FIXTURES / "9701_s15_qp_12.pdf")
        for p1 in (5, 6, 13):
            c = classify_page(doc, p1 - 1, doc.page_count)
            self.assertEqual(c.category, "question_content", f"9701/12 page {p1} eaten")
        doc.close()


@unittest.skipUnless((UPLOADS / "9700_m25_qp_22.pdf").exists(), "RS-2 baseline uploads absent")
class TestALevelBaselineRail(unittest.TestCase):
    def test_baseline_classification_sets_unchanged(self):
        self.assertEqual(_removed(UPLOADS / "9700_m25_qp_22.pdf"),
                         {1: "candidate_info", 2: "blank_page", 24: "admin_back_matter"})
        self.assertEqual(_removed(UPLOADS / "9700_w25_qp_22.pdf"), {1: "candidate_info"})


if __name__ == "__main__":
    unittest.main()
