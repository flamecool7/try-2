import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from tools.render_topic_accuracy_dashboard import build_dashboard, render_dashboard  # noqa: E402


class TestRenderTopicAccuracyDashboard(unittest.TestCase):
    def test_build_dashboard_is_self_contained(self):
        report = {
            "summary": {
                "labeled": 10,
                "correct": 9,
                "incorrect": 1,
                "missing_prediction": 0,
                "review_required": 2,
                "accuracy_percent": 90.0,
            },
            "per_subject": [
                {"subject": "Mathematics_0580", "labeled": 10, "correct": 9, "incorrect": 1,
                 "missing_prediction": 0, "review_required": 2, "accuracy_percent": 90.0}
            ],
            "confusion": [{"expected": "Mensuration", "predicted": "Geometry", "count": 1}],
            "mismatches": [{"key": ["Mathematics_0580", "IGCSE", "0580_s24_qp_42", "Q2"],
                             "expected": "Mensuration", "predicted": "Geometry", "path": "x/metadata.json"}],
            "missing_predictions": [],
        }
        html = build_dashboard(report, title="Accuracy Test")
        self.assertIn("Accuracy Test", html)
        self.assertIn("90.00%", html)
        self.assertIn("Mensuration", html)
        self.assertIn("Geometry", html)
        self.assertTrue(html.startswith("<!DOCTYPE html>"))
        for pat in ("<script", "<link", 'src="http', "src='http", "url(http", "@import", "<iframe"):
            self.assertNotIn(pat, html)

    def test_render_dashboard_writes_file(self):
        tmp = Path(tempfile.mkdtemp(prefix="accdash_"))
        report_json = tmp / "report.json"
        out = tmp / "dashboard.html"
        report_json.write_text(json.dumps({
            "summary": {"labeled": 1, "correct": 1, "incorrect": 0,
                        "missing_prediction": 0, "review_required": 0, "accuracy_percent": 100.0},
            "per_subject": [], "confusion": [], "mismatches": [], "missing_predictions": []
        }), encoding="utf-8")
        render_dashboard(report_json, out, title="Dash")
        self.assertTrue(out.exists())
        self.assertIn("Dash", out.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
