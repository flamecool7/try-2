from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier, _science_ambiguity_reason  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level  # noqa: E402


def _matched(text: str, variant: str = "22", marks: int = 6):
    return SimpleNamespace(
        qp=SimpleNamespace(text=text, marks=marks),
        ms=None,
        variant=variant,
        year="2024",
        season="Summer",
        question_number="Q1",
        full_qp_code="TEST_QP",
    )


class TestScienceAccuracyHardening(unittest.TestCase):
    def test_9701_rate_equation_prefers_kinetics(self):
        cfg = load_subject_config_by_code_and_level("9701", "A-Level", year="2024")
        clf = TopicClassifier(cfg)
        res = clf.classify_question(_matched(
            "Initial-rate data are used to determine the order of reaction and hence the rate equation. "
            "Use the activation energy to explain the effect of temperature."
        ))
        self.assertEqual(res.winning_major, "Reaction_kinetics")
        self.assertEqual(res.fallback_tier, "scored")

    def test_9702_internal_resistance_prefers_dc_circuits(self):
        cfg = load_subject_config_by_code_and_level("9702", "A-Level", year="2024")
        clf = TopicClassifier(cfg)
        res = clf.classify_question(_matched(
            "A cell of emf E and internal resistance r is connected to a potential divider. "
            "Use Kirchhoff's laws to determine the current in the circuit."
        ))
        self.assertEqual(res.winning_major, "D_C_circuits")
        self.assertEqual(res.fallback_tier, "scored")

    def test_9700_glycolysis_prefers_energy_and_respiration(self):
        cfg = load_subject_config_by_code_and_level("9700", "A-Level", year="2024")
        clf = TopicClassifier(cfg)
        res = clf.classify_question(_matched(
            "State where glycolysis occurs and explain the role of the Krebs cycle and oxidative phosphorylation."
        ))
        self.assertEqual(res.winning_major, "Energy_and_respiration")
        self.assertEqual(res.fallback_tier, "scored")

    def test_0625_logic_gate_prefers_electricity_and_magnetism(self):
        cfg = load_subject_config_by_code_and_level("0625", "IGCSE", year="2024")
        clf = TopicClassifier(cfg)
        res = clf.classify_question(_matched(
            "Complete the truth table for the logic gate and explain why the transformer reduces energy losses."
        ))
        self.assertEqual(res.winning_major, "Electricity_and_magnetism")
        self.assertEqual(res.fallback_tier, "scored")

    def test_science_ambiguity_gate_flags_close_major_scores(self):
        reason = _science_ambiguity_reason("Chemistry_9701", {
            "Reaction_kinetics": 4.2,
            "Equilibria": 3.9,
        })
        self.assertIsNotNone(reason)
        self.assertIn("top=Reaction_kinetics", reason)
        self.assertIsNone(_science_ambiguity_reason("Mathematics_9709", {"Trigonometry": 4.2, "Algebra": 4.1}))


if __name__ == "__main__":
    unittest.main()
