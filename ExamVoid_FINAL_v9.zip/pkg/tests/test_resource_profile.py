import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from run_pipeline import apply_resource_profile  # noqa: E402


class TestResourceProfile(unittest.TestCase):
    def test_performance_profile_disables_low_ram_and_bumps_default_workers(self):
        args = SimpleNamespace(performance=True, low_ram=True, workers=None)
        out = apply_resource_profile(args)
        self.assertFalse(out.low_ram)
        self.assertGreaterEqual(out.workers, 2)

    def test_explicit_workers_are_respected(self):
        args = SimpleNamespace(performance=True, low_ram=True, workers=5)
        out = apply_resource_profile(args)
        self.assertFalse(out.low_ram)
        self.assertEqual(out.workers, 5)

    def test_non_performance_profile_leaves_values_alone(self):
        args = SimpleNamespace(performance=False, low_ram=True, workers=1)
        out = apply_resource_profile(args)
        self.assertTrue(out.low_ram)
        self.assertEqual(out.workers, 1)


if __name__ == "__main__":
    unittest.main()
