import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from tools.benchmark_workers import build_command  # noqa: E402


class TestBenchmarkWorkers(unittest.TestCase):
    def test_build_command(self):
        cmd = build_command("in", "out", 10, performance=True, fetch_missing_ms=True)
        self.assertIn("run_pipeline.py", cmd[1])
        self.assertIn("--workers", cmd)
        self.assertIn("10", cmd)
        self.assertIn("--performance", cmd)
        self.assertIn("--fetch-missing-ms", cmd)


if __name__ == "__main__":
    unittest.main()
