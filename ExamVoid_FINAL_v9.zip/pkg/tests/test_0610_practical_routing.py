from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level  # noqa: E402


def _matched(text: str, variant: str = "52", marks: int = 6):
    return SimpleNamespace(
        qp=SimpleNamespace(text=text, marks=marks),
        ms=None,
        variant=variant,
        year="2026",
        season="Spring",
        question_number="Q1",
        full_qp_code="0610_m26_qp_52",
    )


class Test0610PracticalRouting(unittest.TestCase):
    def test_potato_diffusion_practical_prefers_movement_into_and_out_of_cells(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "Potato cylinders were placed in dye. Calculate the percentage light absorbed and explain diffusion distance and surface area to volume ratio."
        ))
        self.assertEqual(res.winning_major, "Movement_into_and_out_of_cells")

    def test_practical_weak_evidence_now_routes_instead_of_review_required(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "Measure the length of each potato cylinder and compare the percentage light absorbed after soaking."
        ))
        self.assertEqual(res.winning_major, "Movement_into_and_out_of_cells")
        self.assertIn(res.fallback_tier, {"scored", "weak_keyword"})

    def test_amylase_water_bath_practical_prefers_enzymes(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "A student used amylase and starch solution in a thermostatically controlled water-bath. Record when iodine stays yellow-brown."
        ))
        self.assertEqual(res.winning_major, "Enzymes")

    def test_potometer_practical_prefers_transport_in_plants(self):
        cfg = load_subject_config_by_code_and_level("0610", "IGCSE", year="2026")
        res = TopicClassifier(cfg).classify_question(_matched(
            "A potometer was used to measure air bubble movement in the xylem to investigate the transpiration stream."
        ))
        self.assertEqual(res.winning_major, "Transport_in_plants")


if __name__ == "__main__":
    unittest.main()
