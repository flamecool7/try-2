#!/usr/bin/env python3
"""RS-23 regression: full-auto forced fallback must not dump zero-evidence
questions into detailed_topics[0] (Atomic_structure for 9701).

Real-paper finding 9701_w25_qp_11: ~9 of 40 MCQs (calculation/application
questions with generic wording) scored ZERO keyword evidence and were all
auto-assigned to the config's first topic — a dominant share of the measured
~54.8% accuracy. Two fixes:

1. near-miss fallback: when no topic reaches the 1.5 threshold but several
   scored below it, force the BEST near-miss topic instead of index 0.
2. 9701 keyword curation: standard CIE MCQ vocabulary ("volume of hydrogen",
   "HBr", "propene", "hydrolysis", "relative atomic mass", ...) added to the
   correct topics; bare "compounds" noise removed from organic topics.
"""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier  # noqa: E402
from core.config_loader import load_subject_config_by_code_and_level  # noqa: E402


def _q(text):
    qp = SimpleNamespace(text=text, marks=1)
    return SimpleNamespace(qp=qp, ms=None, text=text,
                           question_number="Q1")


class TestFullAutoNoIndexZeroDump(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.clf = TopicClassifier(
            load_subject_config_by_code_and_level("9701", "A-Level", "2025"))

    def _winner(self, text):
        return self.clf.classify_question(_q(text), force_winner=True).winning_major

    def test_gas_volume_calc_goes_ams(self):
        # Real Q4: previously dumped into Atomic_structure (index 0).
        text = ("Methane and steam react to produce hydrogen. 0.80 g of "
                "methane and 1.35 g of steam react. One of the reactants is "
                "used up. Which volume of hydrogen, measured at room "
                "conditions, will be produced?")
        self.assertEqual(self._winner(text), "Atoms_molecules_and_stoichiometry")

    def test_hbr_addition_goes_hydrocarbons(self):
        # Real Q27: previously dumped into Atomic_structure.
        text = ("Which intermediate ion forms in the greatest amount during "
                "the addition of HBr to propene?")
        self.assertEqual(self._winner(text), "Hydrocarbons")

    def test_ester_hydrolysis_goes_carboxylic(self):
        # Real Q35: previously dumped into Atomic_structure.
        text = ("Which compound is a product of the hydrolysis of "
                "CH3CO2CH2C2H5 using aqueous sodium hydroxide?")
        self.assertEqual(self._winner(text), "Carboxylic_acids_and_derivatives")

    def test_mg_isotope_abundance_goes_ams(self):
        # Real Q40: previously Atomic_structure via "isotopes" keyword.
        text = ("A sample of magnesium contains the isotopes 24Mg, 25Mg and "
                "26Mg only. The percentage abundance of 25Mg and 26Mg is the "
                "same. The relative atomic mass of magnesium in the sample is "
                "24.3. What is the percentage abundance of 24Mg?")
        self.assertEqual(self._winner(text), "Atoms_molecules_and_stoichiometry")

    def test_redox_oxidising_agent_goes_electrochemistry(self):
        # Real Q10: previously Hydroxy_compounds (stale "oxidising agent" kw).
        text = ("Which equation shows hydrogen acting as an oxidising agent?")
        self.assertEqual(self._winner(text), "Electrochemistry")

    def test_balancing_equations_goes_ams(self):
        # Real Q17: previously Atomic_structure.
        text = ("Three equations are listed. x, y and z are all whole "
                "numbers. 1 x Al + y O2 -> z Al2O3")
        self.assertEqual(self._winner(text), "Atoms_molecules_and_stoichiometry")

    def test_fuel_energy_goes_chemical_energetics(self):
        # Real Q8: previously Atomic_structure.
        text = ("In an experiment, 1.60 g of a fuel is burnt. 45.0% of the "
                "energy is used to heat water.")
        self.assertEqual(self._winner(text), "Chemical_energetics")

    def test_empty_text_still_deterministic_no_crash(self):
        r = self.clf.classify_question(_q(""), force_winner=True)
        self.assertTrue(r.winning_major)  # deterministic winner, never blank
        self.assertEqual(r.fallback_tier, "auto_forced")


if __name__ == "__main__":
    unittest.main(verbosity=2)
