#!/usr/bin/env python3
"""RS-25 regression: non-calculus questions must NOT route to Calculus.

Real findings (2026-08-14): the 0606 Calculus keyword list contained
"exact form" (a generic command phrase used by surds/trig/algebra),
"particle" (bare noun), and bare "velocity"/"acceleration"/"displacement"
which fire on simple speed-distance-time algebra. Confirmed false positives:
"Simplify (3+sqrt(5))^2 giving your answer in exact form" -> Calculus,
"Write 8/sqrt(2) in exact form" -> Calculus,
"A particle moves 20 m in 4 s at constant velocity" -> Calculus.

Fix: replaced with calculus-context phrases (rate of change, in terms of t,
distance travelled, gradient of the curve, with respect to, velocity is,
...), plus a scrambled-differentiation rescue ("Find d/dx(...)" whose
notation is scrambled into character columns: standalone d/dd + x tokens +
"find" + marks + "exact form").
"""
import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.math_reference import (  # noqa: E402
    classify_0606_question, _is_scrambled_differentiation,
)

# Real 0606_s24_qp_11 Q6 (scrambled d/dx extraction).
SCRAMBLED_Q6 = ("6 Find ( )x x x 2 3 2 3 5 3 d 2 2 4 - - - "
                "c e dd e o giving your answer in exact form. [4]")
# Real 0606_s24_qp_11 Q10 (kinematics by integration/differentiation).
KINEMATICS_Q10 = ("10 In this question, all distances are in metres and "
                  "time, t, is in seconds. A particle P is at a fixed point "
                  "O at time t = 0. The velocity, v, of P is given by "
                  "v = 3sin(2t). (b) Find an expression, in terms of t, for "
                  "the displacement of P from O at time t. [4] (c) Find the "
                  "distance travelled by P. [3]")


class TestCalculusFalsePositives(unittest.TestCase):
    def test_exact_form_surd_is_not_calculus(self):
        r = classify_0606_question(
            "Simplify (3 + sqrt(5))^2 giving your answer in exact form. [2]",
            force=True)
        self.assertNotEqual(r, "Calculus", r)

    def test_surd_exact_form_not_calculus(self):
        r = classify_0606_question("Write 8/sqrt(2) in exact form. [1]",
                                   force=True)
        self.assertNotEqual(r, "Calculus", r)

    def test_constant_velocity_algebra_not_calculus(self):
        r = classify_0606_question(
            "A particle moves 20 m in 4 s at constant velocity. "
            "Find the velocity. [2]", force=True)
        self.assertNotEqual(r, "Calculus", r)

    def test_subpart_d_find_x_not_calculus(self):
        # "d" appears as a subpart label; must not trigger the scrambled-diff
        # signature (no "exact form").
        r = classify_0606_question("4 (d) Find the value of x. [2]",
                                   force=True)
        self.assertNotEqual(r, "Calculus", r)

    def test_real_scrambled_differentiation_still_calculus(self):
        self.assertEqual(classify_0606_question(SCRAMBLED_Q6, force=True),
                         "Calculus")

    def test_real_kinematics_still_calculus(self):
        self.assertEqual(classify_0606_question(KINEMATICS_Q10, force=True),
                         "Calculus")

    def test_classic_calculus_still_routes(self):
        for t in (
            "Differentiate y = x^3 - 4x^2 + 5x with respect to x. [4]",
            "Find the area under the curve y = x^2 between x = 0 and 3. [5]",
            "Find the stationary point of the curve y = x^3 - 3x. [4]",
            "Find dy/dx given y = sin(2x). [3]",
        ):
            self.assertEqual(classify_0606_question(t, force=True),
                             "Calculus", t)

    def test_scrambled_diff_detector_requires_all_signals(self):
        # no "find" -> no
        self.assertFalse(
            _is_scrambled_differentiation("Calculate d/dx (x^2). [2]"))
        # no marks -> no
        self.assertFalse(
            _is_scrambled_differentiation("Find d/dx (x^2) in exact form"))
        # no x token -> no
        self.assertFalse(
            _is_scrambled_differentiation("Find d in exact form. [2]"))
        # no exact form -> no (subpart d)
        self.assertFalse(
            _is_scrambled_differentiation("4 (d) Find the value of x. [2]"))
        # all signals -> yes
        self.assertTrue(_is_scrambled_differentiation(SCRAMBLED_Q6))


if __name__ == "__main__":
    unittest.main(verbosity=2)
