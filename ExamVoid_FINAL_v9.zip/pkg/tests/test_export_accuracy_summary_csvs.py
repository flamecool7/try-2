import csv
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from tools.export_accuracy_summary_csvs import export_summary_csvs  # noqa: E402


class TestExportAccuracySummaryCSVs(unittest.TestCase):
    def test_exports_ranked_csvs(self):
        tmp = Path(tempfile.mkdtemp(prefix="acc_csv_"))
        report = {
            "summary": {"labeled": 10, "correct": 8, "incorrect": 2, "missing_prediction": 0, "review_required": 1, "accuracy_percent": 80.0},
            "per_subject": [
                {"subject": "Physics_0625", "labeled": 4, "correct": 2, "incorrect": 2, "missing_prediction": 0, "review_required": 0, "accuracy_percent": 50.0},
                {"subject": "Mathematics_0580", "labeled": 6, "correct": 6, "incorrect": 0, "missing_prediction": 0, "review_required": 1, "accuracy_percent": 100.0},
            ],
            "per_topic": [
                {"expected_topic": "Waves", "labeled": 3, "correct": 1, "incorrect": 2, "missing_prediction": 0, "review_required": 0, "accuracy_percent": 33.33},
                {"expected_topic": "Trigonometry", "labeled": 2, "correct": 2, "incorrect": 0, "missing_prediction": 0, "review_required": 0, "accuracy_percent": 100.0},
            ],
            "per_paper": [
                {"subject": "Physics_0625", "level": "IGCSE", "paper": "0625_s24_qp_42", "labeled": 4, "correct": 2, "incorrect": 2, "missing_prediction": 0, "review_required": 0, "accuracy_percent": 50.0},
                {"subject": "Mathematics_0580", "level": "IGCSE", "paper": "0580_s24_qp_42", "labeled": 6, "correct": 6, "incorrect": 0, "missing_prediction": 0, "review_required": 1, "accuracy_percent": 100.0},
            ],
            "confusion": [{"expected": "Waves", "predicted": "Electricity_and_magnetism", "count": 2}],
            "mismatches": [{"key": ["Physics_0625", "IGCSE", "0625_s24_qp_42", "Q2"], "expected": "Waves", "predicted": "Electricity_and_magnetism", "path": "x/metadata.json"}],
            "missing_predictions": [],
        }
        written = export_summary_csvs(report, tmp)
        self.assertGreaterEqual(len(written), 7)
        with (tmp / "subject_ranking.csv").open(newline="", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(rows[0]["subject"], "Physics_0625")
        with (tmp / "topic_ranking.csv").open(newline="", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(rows[0]["expected_topic"], "Waves")
        with (tmp / "paper_ranking.csv").open(newline="", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(rows[0]["paper"], "0625_s24_qp_42")


if __name__ == "__main__":
    unittest.main()
