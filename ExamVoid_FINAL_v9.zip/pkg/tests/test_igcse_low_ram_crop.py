"""Regression tests for the low-RAM IGCSE question-marker path.

Older portrait IGCSE MCQ papers contain answer-option numbers after the real
question label.  Choosing a duplicate marker by local score used to jump from
Q4 to a later option-row ``4``; the resulting final segment covered the whole
PDF and the worker was killed before producing crops.  Selection must remain
in document order and prefer the earliest valid duplicate.
"""
from pathlib import Path
import unittest

from core.vector_first_cropper import Marker, select_qp_sequence


class TestQuestionMarkerSelection(unittest.TestCase):
    def test_duplicate_answer_row_cannot_jump_past_next_question(self):
        markers = [
            Marker(1, 0, 10.0, 20.0, 50.0, "1", 1.10, "top-level"),
            Marker(2, 0, 100.0, 110.0, 50.0, "2", 1.10, "top-level"),
            Marker(3, 0, 200.0, 210.0, 50.0, "3", 1.10, "top-level"),
            Marker(4, 1, 10.0, 20.0, 50.0, "4", 1.10, "top-level"),
            # A later answer/table row has a higher local score but is not Q4.
            Marker(4, 1, 200.0, 210.0, 80.0, "4 N", 1.15, "answer row"),
            Marker(5, 1, 300.0, 310.0, 50.0, "5", 1.10, "top-level"),
            Marker(6, 1, 400.0, 410.0, 50.0, "6", 1.10, "top-level"),
        ]
        selected = select_qp_sequence(markers)
        self.assertEqual([marker.number for marker in selected], [1, 2, 3, 4, 5, 6])
        self.assertEqual(selected[3].y0, 10.0)


FIXTURE = (Path(__file__).resolve().parents[1].parent /
           "test-crops" / "fixtures" / "remote" / "0625_s16_qp_22.pdf")
MS_0580_FIXTURE = (Path(__file__).resolve().parents[1].parent /
                   "test-crops" / "fixtures" / "remote" / "0580_s15_ms_22.pdf")


@unittest.skipUnless(FIXTURE.exists(), "real IGCSE fixture absent")
class TestRealIGCSEMarkerCoverage(unittest.TestCase):
    def test_0625_mcq_has_all_forty_question_markers(self):
        from core.vector_first_cropper import CambridgeCropper
        analysis = CambridgeCropper(Path("/tmp/igcse_marker_test")).analyze(
            FIXTURE, kind="qp"
        )
        self.assertEqual(analysis.selected_numbers, list(range(1, 41)))
        self.assertFalse(analysis.warnings)


@unittest.skipUnless(MS_0580_FIXTURE.exists(), "real IGCSE MS fixture absent")
class TestPortraitIGCSEMarkSchemeCoverage(unittest.TestCase):
    def test_0580_portrait_mark_scheme_recovers_all_qp_numbers(self):
        from core.legacy_ms_split import split_portrait_column_ms
        pieces, diagnostics = split_portrait_column_ms(
            MS_0580_FIXTURE,
            dpi=150,
            expected_top_numbers=list(range(1, 25)),
        )
        self.assertTrue(diagnostics.valid, diagnostics.warnings)
        self.assertEqual(sorted(pieces), list(range(1, 25)))


if __name__ == "__main__":

    unittest.main(verbosity=2)
