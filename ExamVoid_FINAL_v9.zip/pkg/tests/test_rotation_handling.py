"""
Rotation-handling round (RS-14): core/page_rotation.py + run_guarded wiring.

Classes under test:
  case (A) "home-rotated": content authored upright, /Rotate hint added later
           -> DISPLAY sideways -> must be normalized (hint cleared)
  case (B) "Cambridge-style": content authored sideways, /Rotate makes the
           display upright (real fixture 0620_s16_ms_42.pdf) -> must pass
           through UNTOUCHED
  rotation=0 inputs: must pass through untouched (same path returned)

Heavy tier (skipUnless BATCH_HEAVY=1): real end-to-end oracle — a both-files-
rotated MCQ bundle must produce output byte-identical to the upright twin.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
FIXTURES = PROJ.parent / "test-crops" / "fixtures" / "remote"
HEAVY = os.environ.get("BATCH_HEAVY") == "1"

sys.path.insert(0, str(PROJ))

from core.page_rotation import ensure_upright, needs_normalization, normalize_pdf


def _rotate_copy(src: Path, dst: Path, delta: int = 90) -> Path:
    import fitz
    doc = fitz.open(str(src))
    for page in doc:
        page.set_rotation((page.rotation + delta) % 360)
    doc.save(str(dst), deflate=True)
    doc.close()
    return dst


@unittest.skipUnless((FIXTURES / "0620_s16_ms_22.pdf").exists(), "fixture corpus absent")
class TestSidewaysDetector(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="rot_t_"))
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def test_caseA_home_rotated_ms_flagged_every_page(self):
        rot = _rotate_copy(FIXTURES / "0620_s16_ms_22.pdf", self.tmp / "ms_rot.pdf")
        wanted, pages = needs_normalization(rot)
        self.assertTrue(wanted)
        self.assertEqual(pages, [1, 2])          # both MS pages sideways

    def test_caseB_cambridge_rotated_ms_NOT_touched(self):
        # real 0620_s16_ms_42.pdf: /Rotate=90 content pages, display already
        # upright — detector must vote keep on every page.
        wanted, pages = needs_normalization(FIXTURES / "0620_s16_ms_42.pdf")
        self.assertFalse(wanted)
        self.assertEqual(pages, [])

    def test_rotation_zero_inputs_pass_through_same_path(self):
        for name in ("0620_s16_qp_22.pdf", "0620_s16_ms_22.pdf"):
            path, changed = ensure_upright(FIXTURES / name, self.tmp / "cache")
            self.assertEqual(Path(path), FIXTURES / name)   # original, not a copy
            self.assertEqual(changed, [])
        self.assertFalse((self.tmp / "cache").exists())      # nothing written

    def test_caseA_qp_flagged_all_text_pages(self):
        rot = _rotate_copy(FIXTURES / "0620_s16_qp_22.pdf", self.tmp / "qp_rot.pdf")
        wanted, pages = needs_normalization(rot)
        self.assertTrue(wanted)
        self.assertIn(1, pages)
        # measured on the real corpus: pages 1-15 sideways; p16 (Periodic
        # Table) abstains by design (mixed-vote page; classifier removes it).
        self.assertEqual(pages, list(range(1, 16)))


@unittest.skipUnless((FIXTURES / "0620_s16_ms_22.pdf").exists(), "fixture corpus absent")
class TestNormalization(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="rot_n_"))
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def _norm_ms(self) -> Path:
        rot = _rotate_copy(FIXTURES / "0620_s16_ms_22.pdf", self.tmp / "0620_s16_ms_22.pdf")
        out, pages = ensure_upright(rot, self.tmp / "cache")
        self.assertEqual(pages, [1, 2])
        self.assertNotEqual(Path(out), rot)
        self.assertTrue(str(out).endswith("__0620_s16_ms_22.pdf"))  # name preserved
        return Path(out)

    def test_mcq_grid_identical_after_normalization(self):
        from core.ms_cropping_engine import MSCroppingEngine
        eng = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
        want = eng.extract_mcq_answers(FIXTURES / "0620_s16_ms_22.pdf")
        got = eng.extract_mcq_answers(self._norm_ms())
        self.assertEqual(len(want), 40)
        self.assertEqual(want, got)
        self.assertEqual([got[i] for i in range(1, 6)], ["A", "A", "D", "B", "C"])

    def test_normalized_qp_pages_render_pixel_identical(self):
        import fitz
        rot = _rotate_copy(FIXTURES / "0620_s16_qp_22.pdf", self.tmp / "0620_s16_qp_22.pdf")
        out, pages = ensure_upright(rot, self.tmp / "cache")
        orig = fitz.open(str(FIXTURES / "0620_s16_qp_22.pdf"))
        norm = fitz.open(str(out))
        self.assertEqual(sorted({p.rotation for p in norm}), [0, 90])  # p16 abstains
        m = fitz.Matrix(1.2, 1.2)
        for i in range(15):            # every cleared page == upright twin
            xa = orig[i].get_pixmap(matrix=m, alpha=False).samples
            xb = norm[i].get_pixmap(matrix=m, alpha=False).samples
            self.assertEqual(xa, xb, f"page {i + 1} pixels differ")
        orig.close(); norm.close()

    def test_normalization_deterministic_bytes_and_cache_reuse(self):
        rot = _rotate_copy(FIXTURES / "0620_s16_ms_22.pdf", self.tmp / "ms_rot.pdf")
        o1 = self.tmp / "n1.pdf"; o2 = self.tmp / "n2.pdf"
        normalize_pdf(rot, o1); normalize_pdf(rot, o2)
        self.assertEqual(hashlib.sha256(o1.read_bytes()).hexdigest(),
                         hashlib.sha256(o2.read_bytes()).hexdigest())
        p1, _ = ensure_upright(rot, self.tmp / "c1")
        s1 = hashlib.sha256(Path(p1).read_bytes()).hexdigest()
        p2, _ = ensure_upright(rot, self.tmp / "c1")   # cache hit: reuse, same inode content
        self.assertEqual(p1, p2)
        self.assertEqual(s1, hashlib.sha256(Path(p2).read_bytes()).hexdigest())

    def test_real_rotated_structured_ms_still_splits(self):
        # case (B) regression pin: real /Rotate=90 MS must keep its exact
        # gold-standard split (6 questions, pinned raster sizes at dpi=150).
        from core.ms_cropping_engine import MSCroppingEngine
        eng = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
        res = eng.process_paper(FIXTURES / "0620_s16_ms_42.pdf")
        self.assertEqual([r.number_int for r in res], [1, 2, 3, 4, 5, 6])
        sizes = [(r.assembled_image.width, r.assembled_image.height) for r in res]
        self.assertEqual(sizes, [(1421, 454), (1421, 385), (1421, 563),
                                 (1421, 1217), (1421, 687), (1421, 1161)])


@unittest.skipUnless(HEAVY, "set BATCH_HEAVY=1 for real end-to-end")
@unittest.skipUnless((FIXTURES / "0620_s16_qp_22.pdf").exists(), "fixture corpus absent")
class TestRotatedEndToEnd(unittest.TestCase):
    """Full guarded run: rotated bundle output must equal the upright oracle."""

    def _run(self, input_dir: Path, out_dir: Path) -> subprocess.CompletedProcess:
        return subprocess.run(
            [sys.executable, str(PROJ / "run_guarded.py"), "--input", str(input_dir),
             "--output", str(out_dir), "--clean", "--low-ram"],
            capture_output=True, text=True, timeout=1700)

    def _tree(self, root: Path):
        skip_dirs = {".rotcache"}
        skip_files = {"failure_report.txt", ".pipeline_state.json",
                      "pipeline.sqlite", "pipeline.sqlite-wal", "pipeline.sqlite-shm"}
        out = {}
        for dp, dn, fn in os.walk(root):
            dn[:] = [d for d in dn if d not in skip_dirs]
            for f in fn:
                if f in skip_files:
                    continue
                p = Path(dp) / f
                out[str(p.relative_to(root))] = p.read_bytes()
        return out

    def test_rotated_bundle_output_byte_oracle(self):
        tmp = Path(tempfile.mkdtemp(prefix="rot_e2e_"))
        self.addCleanup(shutil.rmtree, tmp, True)
        orig_in, rot_in = tmp / "orig_in", tmp / "rot_in"
        orig_in.mkdir(); rot_in.mkdir()
        shutil.copy(FIXTURES / "0620_s16_qp_22.pdf", orig_in)
        shutil.copy(FIXTURES / "0620_s16_ms_22.pdf", orig_in)
        _rotate_copy(FIXTURES / "0620_s16_qp_22.pdf", rot_in / "0620_s16_qp_22.pdf")
        _rotate_copy(FIXTURES / "0620_s16_ms_22.pdf", rot_in / "0620_s16_ms_22.pdf")

        ra = self._run(orig_in, tmp / "out_orig")
        rb = self._run(rot_in, tmp / "out_rot")
        self.assertEqual(ra.returncode, 0, ra.stdout[-2000:])
        self.assertEqual(rb.returncode, 0, rb.stdout[-2000:])
        self.assertIn("ALL GREEN", ra.stdout)
        self.assertIn("ALL GREEN", rb.stdout)
        self.assertIn("[rotation] NORMALIZED 0620_s16_qp_22.pdf", rb.stdout)
        self.assertNotIn("[rotation] NORMALIZED", ra.stdout)   # upright run untouched

        A, B = self._tree(tmp / "out_orig"), self._tree(tmp / "out_rot")
        self.assertEqual(set(A), set(B))                        # same relative tree
        for rel in sorted(A):
            if rel.endswith("metadata.json"):
                ja, jb = json.loads(A[rel]), json.loads(B[rel])
                ja.pop("id", None); jb.pop("id", None)          # per-run UUID only
                self.assertEqual(ja, jb, rel)
            else:
                self.assertEqual(A[rel], B[rel], f"bytes differ: {rel}")
        webps = [k for k in A if k.endswith(".webp")]
        self.assertEqual(len(webps), 40)


if __name__ == "__main__":
    unittest.main()
