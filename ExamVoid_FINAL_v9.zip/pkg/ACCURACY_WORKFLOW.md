# 1k-Paper Topic Accuracy Workflow

This workflow is for measuring and improving **real-world topic-routing accuracy** without touching the locked crop or examiner-report systems.

## Goal

For the supported scope:

- **A Level:** Chemistry 9701, Physics 9702, Mathematics 9709, Further Mathematics 9231, Biology 9700
- **IGCSE:** Chemistry 0620, Physics 0625, Mathematics 0580, Additional Mathematics 0606, Biology 0610

measure:

- question-level topic accuracy
- review-required rate
- top confusion pairs
- per-subject accuracy

---

## Files added for this workflow

- `tools/build_label_template.py`
- `tools/evaluate_topic_accuracy.py`
- `tools/render_topic_accuracy_dashboard.py`
- `tools/export_accuracy_summary_csvs.py`
- `tools/topic_accuracy_workflow.py`

---

## Recommended process for 1,000 papers

## Phase 1 — Run the batch

Use the guarded runner so uncertain/questionable outputs fail closed instead of silently passing.

```bash
python tools/topic_accuracy_workflow.py run-batch \
  --input papers \
  --output output \
  --clean \
  --low-ram \
  --workers 1 \
  --labels-template topic_accuracy_labels.csv
```

If the machine has around **4GB RAM or more** and you want a slightly more
aggressive CPU/RAM profile, use:

```bash
python tools/topic_accuracy_workflow.py run-batch \
  --input papers \
  --output output \
  --clean \
  --performance \
  --labels-template topic_accuracy_labels.csv
```

`--performance` does **not** create physical RAM. It simply tells the software
not to use the low-RAM crop path and nudges the worker target upward a little.

What this does:
1. runs `run_guarded.py`
2. generates `topic_accuracy_labels.csv` from the produced `metadata.json` files
3. leaves `expected_topic` blank for human labeling

---

## Phase 2 — Fill the labels

Open `topic_accuracy_labels.csv` and fill only this column:

- `expected_topic`

Everything else is prefilled to make review faster:
- `subject`
- `level`
- `paper`
- `question_number`
- `predicted_topic`
- `route_status`
- `metadata_path`
- `question_folder`

### Labeling rules

Use the **canonical folder/topic names** already used by the system.

Examples:
- `Trigonometry`
- `Coordinate_geometry_of_the_circle`
- `Hooke's_law`
- `Inference_using_normal_and_t_distributions`
- `Biological_molecules`

Do **not** invent alternate spellings.

---

## Phase 3 — Score the run

Once `expected_topic` is filled in:

```bash
python tools/topic_accuracy_workflow.py evaluate \
  --output-root output \
  --labels topic_accuracy_labels_filled.csv \
  --report-json topic_accuracy_report.json \
  --dashboard-html topic_accuracy_dashboard.html
```

This prints:
- total labeled questions
- correct
- incorrect
- missing predictions
- review-required count
- overall accuracy %
- per-subject accuracy
- worst topics
- top confusions

It also produces:
- `topic_accuracy_report.json`
- `topic_accuracy_dashboard.html`
- ranked CSV summaries when `--summary-dir` is provided

Example with CSV exports:

```bash
python tools/topic_accuracy_workflow.py evaluate \
  --output-root output \
  --labels topic_accuracy_labels_filled.csv \
  --report-json topic_accuracy_report.json \
  --dashboard-html topic_accuracy_dashboard.html \
  --summary-dir topic_accuracy_csvs
```

The CSV summary folder contains:
- `overall_summary.csv`
- `subject_ranking.csv`
- `topic_ranking.csv`
- `paper_ranking.csv`
- `confusion_summary.csv`
- `mismatch_samples.csv`
- `missing_predictions.csv`

The HTML dashboard is self-contained and includes:
- summary metrics
- per-subject accuracy table
- top confusion pairs
- mismatch samples
- missing-prediction samples

---

## Phase 4 — Patch the biggest misses

Use the report to focus only on:
1. the most common confusion pairs
2. the worst-performing subjects
3. the highest-volume topics

Typical pattern:
- run 100–200 papers
- label
- score
- patch top 10 failure modes
- rerun
- repeat until stable

---

## CSV columns

Generated label template columns:

- `subject`
- `level`
- `paper`
- `question_number`
- `predicted_topic`
- `expected_topic`
- `route_status`
- `variant`
- `season`
- `year`
- `metadata_path`
- `question_folder`
- `notes`

### `route_status`

- `auto_routed` = model/system chose a topic
- `review_required` = system abstained / marked as review-required

This is useful because **high accuracy on auto-routed outputs** is usually a better production KPI than forcing every question into a topic.

---

## One-command run + evaluate

If you already have a filled labels CSV, you can do the whole loop in one command:

```bash
python tools/topic_accuracy_workflow.py run-batch \
  --input papers \
  --output output \
  --clean \
  --low-ram \
  --workers 1 \
  --labels-template topic_accuracy_labels.csv \
  --labels topic_accuracy_labels_filled.csv \
  --report-json topic_accuracy_report.json \
  --dashboard-html topic_accuracy_dashboard.html \
  --summary-dir topic_accuracy_csvs
```

---

## Recommended KPI targets

For a production-quality run, track:

1. **Overall labeled accuracy**
2. **Auto-routed accuracy**
3. **Review-required rate**
4. **Per-subject accuracy**
5. **Top 10 confusion pairs**

A realistic strong target is:

- **95%+ on accepted / auto-routed outputs**
- controlled `review_required` rate
- low silent misclassification rate

---

## Important honesty note

A 1,000-paper run should not be judged only by:
- “did it crash?”

It should be judged by:
- how many outputs were correct
- how many bad guesses were avoided by abstaining
- which topics still confuse the router

That is exactly what this workflow is designed to measure.
