r"""Find and group PDF files by paper code. Knows nothing about subjects.

Overseer rebuild spec (Phase 1, Step 3), adapted — implementation is an
ADAPTER over the locked ``core.paper_identifier`` (RS-1, multi-pattern:
standard, year-first / type-first ER arrangements, long-form names, season
token set), because the spec's literal regex was fact-checked against the
real uploaded fixtures and MISSES them:

    spec:  ^(\d{4})_([a-z]+)(\d{2})_(qp|ms|er|in)_(\w+)\.pdf$
    9700_m25_er.pdf   -> NO MATCH (real ERs carry no variant suffix)
    0620_m25_er.pdf   -> NO MATCH

Spec design bug also fixed here (documented): the spec's ER fan-out assigned
``er_path`` only to groups that already existed when the ER file was
encountered — filesystem glob order decided whether an ER attached. This
implementation is strictly two-pass (group QP/MS/insert first, then attach
every ER to ALL matching variants), so results are order-independent.

Group semantics (spec): QP/MS/insert group by {code, season, year, variant};
an ER attaches to EVERY variant group of the same {code, season, year}; an
ER with no QP/MS sibling keeps its own group (``qp_path is None``) so the
orchestrator can skip it loudly or run ER-only flows.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from core.paper_identifier import parse_paper_filename


@dataclass
class PaperGroup:
    paper_code: str                          # "9701_s22_21" ("…_er" for ER-only)
    syllabus_code: str
    season: str                              # normalised letter: "m"/"s"/"w"
    year: str                                # short: "25"
    variant: str                             # "22" | "42" | "" (ER-only group)
    qp_path: Optional[Path]
    ms_path: Optional[Path]
    er_path: Optional[Path]
    insert_path: Optional[Path]


_INSERT_TYPES = {"insert", "in", "ir", "ci"}


class Discoverer:
    def discover(self, pdf_dir: Path) -> List[PaperGroup]:
        paths = sorted(Path(pdf_dir).rglob("*.pdf"))
        return self.discover_paths(paths)

    def discover_paths(self, paths: Iterable[Path]) -> List[PaperGroup]:
        """Order-independent grouping (test hook + spec-bug fix)."""
        groups: Dict[str, PaperGroup] = {}
        ers = []          # (PaperInfo,) — applied in pass 2
        ignored = []

        # Pass 1: QP / MS / insert groups.
        for pdf in paths:
            info = parse_paper_filename(pdf)
            if info is None:
                continue  # paper_identifier already printed the loud flag
            ptype = (info.paper_type or "").lower()
            if ptype == "er":
                ers.append(info)
                continue
            if ptype in ("gt",):
                ignored.append((pdf, ptype))
                continue
            key = f"{info.syllabus_code}_{info.season_letter}{info.year_short}_{info.variant}"
            group = groups.get(key)
            if group is None:
                group = PaperGroup(
                    paper_code=key,
                    syllabus_code=info.syllabus_code,
                    season=info.season_letter,
                    year=info.year_short,
                    variant=info.variant,
                    qp_path=None, ms_path=None, er_path=None, insert_path=None,
                )
                groups[key] = group
            if ptype == "qp":
                group.qp_path = pdf
            elif ptype == "ms":
                group.ms_path = pdf
            elif ptype in _INSERT_TYPES:
                group.insert_path = pdf
            else:
                ignored.append((pdf, ptype))

        # Pass 2: ER fan-out — attach to EVERY variant of the paper,
        # regardless of the order files were discovered in (spec bug fix).
        for info in ers:
            key = f"{info.syllabus_code}_{info.season_letter}{info.year_short}"
            matched = False
            for g in groups.values():
                if (g.syllabus_code, g.season, g.year) == (
                    info.syllabus_code, info.season_letter, info.year_short,
                ):
                    g.er_path = info.file_path
                    matched = True
            if not matched:
                gk = f"{key}_er"
                groups[gk] = PaperGroup(
                    paper_code=gk,
                    syllabus_code=info.syllabus_code,
                    season=info.season_letter,
                    year=info.year_short,
                    variant="",
                    qp_path=None, ms_path=None,
                    er_path=info.file_path, insert_path=None,
                )

        for pdf, ptype in ignored:
            print(f"[Discoverer] ignored non-question document "
                  f"({ptype}): {Path(pdf).name}")
        return list(groups.values())
