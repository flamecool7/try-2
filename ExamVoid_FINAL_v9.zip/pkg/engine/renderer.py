"""Render any PDF to PIL images. Knows nothing about subjects.

Overseer rebuild spec (Phase 1, Step 3). Two adaptations, both documented
and both preserving the spec's public shape:

1. RAM (this box: 2 cores / ~2GB; measured full-paper worker RSS peaks
   933-960MB — fact-checked against the efficiency-round benchmarks):
   300dpi A4 pages are ~26MB each as RGB PIL, so the spec's whole-document
   list (~312MB for a 12-page QP, plus MS) would stand workers on the OOM
   line. ``iter_pages()`` streams page-by-page; ``render()`` remains as the
   spec-compatible convenience (it just materializes the generator). The
   orchestrator (Step 7) streams.
2. DPI: class attribute ``DPI = 300`` per spec, overridable per instance —
   the LOCKED crop engines run their own internal renders (QP 75dpi clamp
   ``min(dpi,150)``, MS 150dpi; see ROUTING_STATE_LOCK item 5) and this
   renderer is never wired into that path. Rule 5 untouched: converter.py
   render settings are not consulted, changed, or reimplemented here.

Zero disk writes, always; page renders are returned and forgotten.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterator, List

import fitz
from PIL import Image


class Renderer:
    DPI = 300

    def __init__(self, dpi: int | None = None) -> None:
        self.dpi = int(dpi or self.DPI)
        self.matrix = fitz.Matrix(self.dpi / 72.0, self.dpi / 72.0)

    def iter_pages(self, pdf_path: Path) -> Iterator[Image.Image]:
        """Yield one RGB PIL image per page. Zero disk writes."""
        doc = fitz.open(str(pdf_path))
        try:
            for page in doc:
                pix = page.get_pixmap(
                    matrix=self.matrix,
                    alpha=False,
                    colorspace=fitz.csRGB,
                )
                yield Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        finally:
            doc.close()

    def render(self, pdf_path: Path) -> List[Image.Image]:
        """Spec-compatible: whole document as a list of PIL images."""
        return list(self.iter_pages(pdf_path))
