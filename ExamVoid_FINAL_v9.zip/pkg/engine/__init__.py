"""Format-agnostic engine — knows nothing about subjects.

Overseer rebuild spec Phase 1. Step 3 ships the discoverer and renderer;
storage/validator/orchestrator arrive at Step 7 as adapters over the locked
core modules (output_manager / validation / pipeline_state /
examiner_report), never reimplementations.
"""
