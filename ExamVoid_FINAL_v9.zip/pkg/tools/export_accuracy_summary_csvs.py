#!/usr/bin/env python3
"""Export ranked CSV summaries from topic_accuracy_report.json.

Outputs include:
- overall_summary.csv
- subject_ranking.csv
- topic_ranking.csv
- paper_ranking.csv
- confusion_summary.csv
- mismatch_samples.csv
- missing_predictions.csv

Usage:
    python tools/export_accuracy_summary_csvs.py \
        --report-json topic_accuracy_report.json \
        --output-dir accuracy_csvs
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Iterable, Sequence


def _write_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def export_summary_csvs(report: dict, output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    summary = report.get("summary", {})
    overall_path = output_dir / "overall_summary.csv"
    _write_csv(overall_path, [
        "labeled", "correct", "incorrect", "missing_prediction", "review_required", "accuracy_percent"
    ], [summary])
    written.append(overall_path)

    subject_rows = sorted(
        report.get("per_subject", []),
        key=lambda r: (float(r.get("accuracy_percent", 0.0)), -int(r.get("labeled", 0)), str(r.get("subject", ""))),
    )
    subject_path = output_dir / "subject_ranking.csv"
    _write_csv(subject_path, [
        "subject", "labeled", "correct", "incorrect", "missing_prediction", "review_required", "accuracy_percent"
    ], subject_rows)
    written.append(subject_path)

    topic_rows = sorted(
        report.get("per_topic", []),
        key=lambda r: (float(r.get("accuracy_percent", 0.0)), -int(r.get("labeled", 0)), str(r.get("expected_topic", ""))),
    )
    topic_path = output_dir / "topic_ranking.csv"
    _write_csv(topic_path, [
        "expected_topic", "labeled", "correct", "incorrect", "missing_prediction", "review_required", "accuracy_percent"
    ], topic_rows)
    written.append(topic_path)

    paper_rows = sorted(
        report.get("per_paper", []),
        key=lambda r: (float(r.get("accuracy_percent", 0.0)), -int(r.get("labeled", 0)), str(r.get("paper", ""))),
    )
    paper_path = output_dir / "paper_ranking.csv"
    _write_csv(paper_path, [
        "subject", "level", "paper", "labeled", "correct", "incorrect", "missing_prediction", "review_required", "accuracy_percent"
    ], paper_rows)
    written.append(paper_path)

    confusion_path = output_dir / "confusion_summary.csv"
    _write_csv(confusion_path, ["expected", "predicted", "count"], report.get("confusion", []))
    written.append(confusion_path)

    mismatch_rows = []
    for row in report.get("mismatches", []):
        key = row.get("key", ["", "", "", ""])
        mismatch_rows.append({
            "subject": key[0] if len(key) > 0 else "",
            "level": key[1] if len(key) > 1 else "",
            "paper": key[2] if len(key) > 2 else "",
            "question_number": key[3] if len(key) > 3 else "",
            "expected": row.get("expected", ""),
            "predicted": row.get("predicted", ""),
            "path": row.get("path", ""),
        })
    mismatch_path = output_dir / "mismatch_samples.csv"
    _write_csv(mismatch_path, ["subject", "level", "paper", "question_number", "expected", "predicted", "path"], mismatch_rows)
    written.append(mismatch_path)

    missing_rows = []
    for row in report.get("missing_predictions", []):
        key = row.get("key", ["", "", "", ""])
        missing_rows.append({
            "subject": key[0] if len(key) > 0 else "",
            "level": key[1] if len(key) > 1 else "",
            "paper": key[2] if len(key) > 2 else "",
            "question_number": key[3] if len(key) > 3 else "",
            "expected": row.get("expected", ""),
        })
    missing_path = output_dir / "missing_predictions.csv"
    _write_csv(missing_path, ["subject", "level", "paper", "question_number", "expected"], missing_rows)
    written.append(missing_path)

    return written


def main(argv: Iterable[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--report-json", required=True)
    ap.add_argument("--output-dir", required=True)
    args = ap.parse_args(list(argv) if argv is not None else None)

    report = json.loads(Path(args.report_json).read_text(encoding="utf-8"))
    written = export_summary_csvs(report, Path(args.output_dir))
    for path in written:
        print(f"[accuracy-csv] wrote {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
