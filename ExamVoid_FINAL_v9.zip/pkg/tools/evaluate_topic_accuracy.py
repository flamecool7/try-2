#!/usr/bin/env python3
"""Evaluate routed-topic accuracy against a labeled CSV.

Expected CSV columns:
    subject,level,paper,question_number,expected_topic

Optional columns are ignored. The tool scans metadata.json files under an output
root, matches rows by (subject, level, paper, question_number), and reports:
- overall labeled coverage
- overall accuracy
- review_required rate
- per-subject accuracy
- confusion counts

Usage:
    python tools/evaluate_topic_accuracy.py \
        --output-root output \
        --labels labels.csv \
        --report-json evaluation_report.json
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, Tuple

Key = Tuple[str, str, str, str]


def _norm(value: str) -> str:
    return str(value or "").strip()


def load_predictions(output_root: Path) -> Dict[Key, dict]:
    preds: Dict[Key, dict] = {}
    for meta in output_root.rglob("metadata.json"):
        try:
            data = json.loads(meta.read_text(encoding="utf-8"))
        except Exception:
            continue
        key = (
            _norm(data.get("subject")),
            _norm(data.get("level")),
            _norm(data.get("paper")),
            _norm(data.get("question_number")),
        )
        topic = data.get("topic") or []
        predicted = topic[0] if isinstance(topic, list) and topic else ""
        preds[key] = {
            "predicted_topic": predicted,
            "path": str(meta),
            "raw": data,
        }
    return preds


def load_labels(csv_path: Path) -> Dict[Key, dict]:
    rows: Dict[Key, dict] = {}
    with csv_path.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        required = {"subject", "level", "paper", "question_number", "expected_topic"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise SystemExit(f"labels CSV missing required columns: {sorted(missing)}")
        for row in reader:
            key = (
                _norm(row.get("subject")),
                _norm(row.get("level")),
                _norm(row.get("paper")),
                _norm(row.get("question_number")),
            )
            if key in rows:
                raise SystemExit(f"duplicate label row for key {key}")
            rows[key] = {
                "expected_topic": _norm(row.get("expected_topic")),
                "raw": row,
            }
    return rows


def evaluate(labels: Dict[Key, dict], predictions: Dict[Key, dict]) -> dict:
    overall = Counter()
    per_subject = defaultdict(Counter)
    per_topic = defaultdict(Counter)
    per_paper = defaultdict(Counter)
    confusion = Counter()
    missing_predictions = []
    mismatches = []

    for key, label in labels.items():
        subject, level, paper, _q = key
        expected_topic = _norm(label.get("expected_topic"))
        overall["labeled"] += 1
        per_subject[subject]["labeled"] += 1
        per_topic[expected_topic]["labeled"] += 1
        per_paper[(subject, level, paper)]["labeled"] += 1
        pred = predictions.get(key)
        if not pred:
            overall["missing_prediction"] += 1
            per_subject[subject]["missing_prediction"] += 1
            per_topic[expected_topic]["missing_prediction"] += 1
            per_paper[(subject, level, paper)]["missing_prediction"] += 1
            missing_predictions.append({"key": key, "expected": expected_topic})
            continue
        predicted_topic = _norm(pred.get("predicted_topic"))
        if predicted_topic in {"review_required", "review_required_no_ms", ""}:
            overall["review_required"] += 1
            per_subject[subject]["review_required"] += 1
            per_topic[expected_topic]["review_required"] += 1
            per_paper[(subject, level, paper)]["review_required"] += 1
        if predicted_topic == expected_topic:
            overall["correct"] += 1
            per_subject[subject]["correct"] += 1
            per_topic[expected_topic]["correct"] += 1
            per_paper[(subject, level, paper)]["correct"] += 1
        else:
            overall["incorrect"] += 1
            per_subject[subject]["incorrect"] += 1
            per_topic[expected_topic]["incorrect"] += 1
            per_paper[(subject, level, paper)]["incorrect"] += 1
            confusion[(expected_topic, predicted_topic)] += 1
            mismatches.append({
                "key": key,
                "expected": expected_topic,
                "predicted": predicted_topic,
                "path": pred.get("path", ""),
            })

    def ratio(num: int, den: int) -> float:
        return round((num / den) * 100.0, 2) if den else 0.0

    subject_rows = []
    for subject, counts in sorted(per_subject.items()):
        subject_rows.append({
            "subject": subject,
            "labeled": counts["labeled"],
            "correct": counts["correct"],
            "incorrect": counts["incorrect"],
            "missing_prediction": counts["missing_prediction"],
            "review_required": counts["review_required"],
            "accuracy_percent": ratio(counts["correct"], counts["labeled"]),
        })

    topic_rows = []
    for expected_topic, counts in sorted(per_topic.items()):
        topic_rows.append({
            "expected_topic": expected_topic,
            "labeled": counts["labeled"],
            "correct": counts["correct"],
            "incorrect": counts["incorrect"],
            "missing_prediction": counts["missing_prediction"],
            "review_required": counts["review_required"],
            "accuracy_percent": ratio(counts["correct"], counts["labeled"]),
        })

    paper_rows = []
    for (subject, level, paper), counts in sorted(per_paper.items()):
        paper_rows.append({
            "subject": subject,
            "level": level,
            "paper": paper,
            "labeled": counts["labeled"],
            "correct": counts["correct"],
            "incorrect": counts["incorrect"],
            "missing_prediction": counts["missing_prediction"],
            "review_required": counts["review_required"],
            "accuracy_percent": ratio(counts["correct"], counts["labeled"]),
        })

    return {
        "summary": {
            "labeled": overall["labeled"],
            "correct": overall["correct"],
            "incorrect": overall["incorrect"],
            "missing_prediction": overall["missing_prediction"],
            "review_required": overall["review_required"],
            "accuracy_percent": ratio(overall["correct"], overall["labeled"]),
        },
        "per_subject": subject_rows,
        "per_topic": topic_rows,
        "per_paper": paper_rows,
        "confusion": [
            {"expected": exp, "predicted": pred, "count": count}
            for (exp, pred), count in confusion.most_common()
        ],
        "mismatches": mismatches,
        "missing_predictions": missing_predictions,
    }


def print_report(report: dict) -> None:
    s = report["summary"]
    print("=== Topic Accuracy Report ===")
    print(f"Labeled questions   : {s['labeled']}")
    print(f"Correct             : {s['correct']}")
    print(f"Incorrect           : {s['incorrect']}")
    print(f"Missing prediction  : {s['missing_prediction']}")
    print(f"Review required     : {s['review_required']}")
    print(f"Accuracy            : {s['accuracy_percent']}%")
    print()
    print("Per subject:")
    for row in report["per_subject"]:
        print(
            f"- {row['subject']}: {row['correct']}/{row['labeled']} "
            f"({row['accuracy_percent']}%), review={row['review_required']}, missing={row['missing_prediction']}"
        )
    if report["per_topic"]:
        print()
        print("Worst topics:")
        ranked_topics = sorted(report["per_topic"], key=lambda r: (r["accuracy_percent"], -r["labeled"], r["expected_topic"]))
        for row in ranked_topics[:10]:
            print(
                f"- {row['expected_topic']}: {row['correct']}/{row['labeled']} "
                f"({row['accuracy_percent']}%), review={row['review_required']}, missing={row['missing_prediction']}"
            )
    if report["confusion"]:
        print()
        print("Top confusions:")
        for row in report["confusion"][:15]:
            print(f"- expected={row['expected']} predicted={row['predicted']} count={row['count']}")


def main(argv: Iterable[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-root", required=True)
    ap.add_argument("--labels", required=True)
    ap.add_argument("--report-json", default="")
    args = ap.parse_args(list(argv) if argv is not None else None)

    output_root = Path(args.output_root)
    labels_path = Path(args.labels)
    predictions = load_predictions(output_root)
    labels = load_labels(labels_path)
    report = evaluate(labels, predictions)
    print_report(report)
    if args.report_json:
        Path(args.report_json).write_text(json.dumps(report, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
