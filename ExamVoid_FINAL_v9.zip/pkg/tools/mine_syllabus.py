#!/usr/bin/env python3
"""tools/mine_syllabus.py — extract topic vocabulary from the OFFICIAL
Cambridge syllabus PDFs (the authoritative source of syllabus vocabulary).

For every subject config carrying an `official_source` URL, this tool:
  1. Fetches + caches the syllabus PDF (graceful offline skip).
  2. Splits the "Subject content" into topic sections (numbered headings like
     "1 Atomic structure", "1.1 Isotopes").
  3. Extracts significant vocabulary — content words and multi-word phrases —
     from each topic's text (esp. the "Learning outcomes").
  4. Merges that vocabulary into the matching config topic's
     classification_keywords (token-overlap routing; never removes, never
     pollutes with stopwords/single letters).

Idempotent; every config is re-validated by the loader after.
"""
import json
import re
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
SUBJECTS_ROOT = PROJ / "subjects"
CACHE_DIR = PROJ / ".syllabus_cache"

_STOP = {
    "and", "or", "the", "of", "a", "an", "in", "on", "with", "for", "to",
    "as", "at", "by", "is", "are", "was", "were", "be", "been", "being",
    "its", "their", "into", "between", "from", "across", "that", "this",
    "these", "those", "level", "using", "use", "used", "able", "should",
    "candidates", "explain", "describe", "state", "identify", "define",
    "understand", "calculate", "determine", "outline", "suggest", "give",
    "draw", "show", "know", "include", "including", "such", "each", "other",
    "following", "follows", "which", "where", "when", "how", "why", "what",
    "can", "may", "must", "will", "would", "could", "also", "not", "no",
    "any", "all", "some", "than", "then", "there", "here", "about", "over",
    "under", "between", "through", "during", "within", "without", "above",
    "below", "both", "either", "neither", "whether", "because", "therefore",
    "however", "although", "while", "until", "since", "before", "after",
    "less", "more", "most", "least", "very", "only", "just", "per", "via",
    "e.g", "i.e", "etc", "number", "numbers", "term", "terms", "example",
    "examples", "limited", "one", "two", "three", "four", "five", "six",
    "able", "should", "candidates", "different", "same", "order", "explain",
    "describe", "state", "outline", "identify", "calculate", "determine",
    "understand", "define", "recall", "use", "using", "give", "predict",
    "deduce", "compare", "contrast", "suggest", "discuss", "evaluate",
    "assess", "analyse", "analyze", "interpret", "demonstrate", "appreciate",
}

# heading patterns: "1 Atomic structure", "1.1 Isotopes", "Topic 1: X"
_HEADING_RE = re.compile(
    r"^\s*(\d{1,2}(?:\.\d{1,2})?)\s+([A-Z][A-Za-z&()\-/ ,]+?)\s*$")


def _tokens(s: str) -> set:
    return {t for t in re.findall(r"[a-z][a-z0-9]+", s.lower()) if t not in _STOP and len(t) >= 3}


def _fetch(code: str, url: str) -> Path | None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    dest = CACHE_DIR / f"{code}_syllabus.pdf"
    if dest.exists():
        return dest
    if not url or "cambridgeinternational.org" not in url:
        return None
    try:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read()
        if not data.startswith(b"%PDF"):
            return None
        dest.write_bytes(data)
        return dest
    except Exception as e:
        print(f"  [syllabus] fetch failed {code}: {e}")
        return None


_LO_MARKERS = ("learning outcomes", "candidates should be able to")


def _learning_outcome_text(section_text: str) -> str:
    """Return only the learning-outcome portion of a section (the most
    vocabulary-dense, least boilerplate part), else the whole section."""
    low = section_text.lower()
    for m in _LO_MARKERS:
        idx = low.find(m)
        if idx != -1:
            return section_text[idx + len(m):]
    return section_text


def _extract_vocab(text: str) -> set:
    """Significant single words + bigrams (NOT trigrams) from learning-outcome
    text.  Single words are the highest-precision; bigrams of adjacent content
    words capture noun phrases without the trigram noise."""
    text = _learning_outcome_text(text)
    out = set()
    words = re.findall(r"[a-z][a-z\-]{3,}", text.lower())
    for w in words:
        if w not in _STOP and not w.replace("-", "").isdigit():
            out.add(w)
    toks = [w for w in re.findall(r"[a-z][a-z\-]+", text.lower())
            if w not in _STOP and len(w) >= 3]
    for i in range(len(toks) - 1):
        phrase = " ".join(toks[i:i + 2])
        if 4 <= len(phrase) <= 40:
            out.add(phrase)
    return out


def mine_one(config_path: Path) -> bool:
    data = json.loads(config_path.read_text(encoding="utf-8"))
    code = str(data.get("syllabus_code", ""))
    url = data.get("official_source", "")
    pdf = _fetch(code, url)
    if pdf is None:
        return False
    try:
        import fitz
    except ImportError:
        import pymupdf as fitz

    doc = fitz.open(str(pdf))
    try:
        sections = {}   # heading_name -> text
        current = None
        for page in doc:
            text = page.get_text("text") or ""
            for line in text.splitlines():
                m = _HEADING_RE.match(line)
                if m and len(m.group(2)) > 3 and len(m.group(2)) < 60:
                    current = m.group(2).strip()
                    sections.setdefault(current, "")
                    continue
                if current is not None:
                    sections[current] += line + "\n"
    finally:
        doc.close()

    if not sections:
        return False

    # map syllabus sections -> config topics by token overlap
    keywords = data.get("classification_keywords", {})
    if keywords is None:
        keywords = {}
    topic_tokens = {t: _tokens(t) | {x for kw in kws for x in _tokens(kw)}
                    for t, kws in keywords.items()}

    changed = False
    # Cross-topic generic filter (TF-IDF-style, at insertion time): a syllabus
    # term is only added to a topic if it is NOT already spread across >= 2
    # OTHER topics' keywords.  This keeps topic-discriminative vocabulary
    # ("nucleon number", "enthalpy") and rejects generic prose ("reaction",
    # "temperature", "measure") that would pollute every topic.
    def _cross_topic_count(term, exclude_topic):
        n = 0
        for t, kws in keywords.items():
            if t == exclude_topic:
                continue
            if term in kws:
                n += 1
        return n

    for heading, text in sections.items():
        ht = _tokens(heading)
        best, best_score = None, 0
        for t, toks in topic_tokens.items():
            score = len(ht & toks)
            if score > best_score:
                best_score, best = score, t
        if best is None or best_score == 0:
            continue
        vocab = _extract_vocab(text)
        cur = set(keywords.get(best, []))
        before = len(cur)
        for v in vocab:
            if len(cur) >= 1500:      # per-topic cap: bound the blow-up
                break
            if v in cur:
                continue
            if _cross_topic_count(v, best) >= 2:
                continue  # generic — skip
            cur.add(v)
        if len(cur) != before:
            keywords[best] = sorted(cur)
            topic_tokens[best] |= {x for v in vocab for x in _tokens(v)}
            changed = True

    if changed:
        data["classification_keywords"] = keywords
        config_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n",
                               encoding="utf-8")
        print(f"  [syllabus] {code}: {len(sections)} sections mined")
    return changed


def main() -> int:
    changed = 0
    for config_path in sorted(SUBJECTS_ROOT.rglob("config.json")):
        try:
            if mine_one(config_path):
                changed += 1
        except Exception as e:
            print(f"[syllabus] ERROR {config_path}: {e}")
    total = 0
    for config_path in sorted(SUBJECTS_ROOT.rglob("config.json")):
        d = json.loads(config_path.read_text(encoding="utf-8"))
        total += sum(len(v) for v in d.get("classification_keywords", {}).values())
    print(f"[syllabus] changed {changed} configs; TOTAL keywords = {total}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
