#!/usr/bin/env python3
"""tools/expand_vocabulary.py — scale classification vocabulary toward 50k+.

Three authoritative, high-precision expansions of the existing per-subject
classification keywords (data-only — no classifier code touched):

  1. Spelling / morphological variants (British<->US, hyphenation, plurals).
  2. Curated NAMED ENTITIES (named reactions, laws, scientists, apparatus,
     case studies, key models) mapped to their topics — each a near-certain
     topic pin.
  3. (Optional) syllabus learning-outcome mining — fetched official syllabus
     PDFs contribute topic vocabulary; degrades gracefully offline.

Idempotent: existing keywords are never removed; additions are de-duplicated
and files rewritten only when changed.  Every config is re-validated after.
"""

import json
import re
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
SUBJECTS_ROOT = PROJ / "subjects"

# ── British <-> US spellings (both directions applied) ─────────────────────
BRIT_US = {
    "aluminium": "aluminum", "sulphur": "sulfur", "sulphate": "sulfate",
    "sulphide": "sulfide", "sulphite": "sulfite", "colour": "color",
    "colourless": "colorless", "vapour": "vapor", "vapourisation": "vaporization",
    "ionisation": "ionization", "ionise": "ionize", "neutralisation": "neutralization",
    "neutralise": "neutralize", "hydrolysis": "hydrolysis",
    "oxidise": "oxidize", "oxidised": "oxidized", "oxidation": "oxidation",
    "reduction": "reduction", "electrolyse": "electrolyze",
    "electrolysed": "electrolyzed", "catalyse": "catalyze",
    "catalysed": "catalyzed", "catalysis": "catalysis", "polymerisation": "polymerization",
    "polymerise": "polymerize", "dimerisation": "dimerization",
    "isomerisation": "isomerization", "crystallisation": "crystallization",
    "crystallise": "crystallize", "metre": "meter", "metres": "meters",
    "centimetre": "centimeter", "millimetre": "millimeter", "kilometre": "kilometer",
    "litre": "liter", "litres": "liters", "theatre": "theater",
    "centre": "center", "fibre": "fiber", "grey": "gray",
    "organise": "organize", "organisation": "organization", "organised": "organized",
    "recognise": "recognize", "analyse": "analyze", "analysing": "analyzing",
    "analysed": "analyzed", "analysis": "analysis", "behaviour": "behavior",
    "modelling": "modeling", "modelled": "modeled", "labelling": "labeling",
    "labelled": "labeled", "cancelling": "canceling", "travelling": "traveling",
    "programme": "program", "defence": "defense", "licence": "license",
    "artefact": "artifact", "faeces": "feces", "oesophagus": "esophagus",
    "oestrogen": "estrogen", "haemoglobin": "hemoglobin", "haemophilia": "hemophilia",
    "anaemia": "anemia", "diarrhoea": "diarrhea", "tumour": "tumor",
    "mould": "mold", "plough": "plow", "catalogue": "catalog",
    "dialogue": "dialog", "specialise": "specialize", "specialised": "specialized",
    "practise": "practice", "fulfil": "fulfill", "skilful": "skillful",
    "sceptic": "skeptic", "tyre": "tire", "aeroplane": "airplane",
    "maths": "math", "cheque": "check", "judgement": "judgment",
}

# Irregular plurals (and no-plural guards)
IRREGULAR_PLURALS = {
    "analysis": "analyses", "crisis": "crises", "hypothesis": "hypotheses",
    "thesis": "theses", "parenthesis": "parentheses", "basis": "bases",
    "phenomenon": "phenomena", "criterion": "criteria", "datum": "data",
    "medium": "media", "bacterium": "bacteria", "fungus": "fungi",
    "nucleus": "nuclei", "mitochondrion": "mitochondria", "index": "indices",
    "vertex": "vertices", "matrix": "matrices", "axis": "axes",
    "stimulus": "stimuli", "cactus": "cacti", "alumnus": "alumni",
    "syllabus": "syllabuses", "focus": "foci", "locus": "loci",
    "radius": "radii", "appendix": "appendices", "formula": "formulae",
    "larva": "larvae", "alga": "algae", "corpus": "corpora",
    "genus": "genera", "species": "species", "series": "series",
    "fish": "fish", "sheep": "sheep", "child": "children",
    "tooth": "teeth", "foot": "feet", "person": "people",
    "gas": "gases", "bus": "buses", "quiz": "quizzes",
}

# Words that must NOT be pluralised (uncountable / already-mass / awkward)
NO_PLURAL = {
    "water", "air", "oxygen", "hydrogen", "nitrogen", "carbon", "energy",
    "information", "knowledge", "equipment", "furniture", "advice",
    "homeostasis", "photosynthesis", "respiration", "electrolysis",
    "polymerisation", "equilibria", "equilibrium", "catalysis",
    "osmosis", "diffusion", "physics", "mathematics", "economics",
    "ethics", "aesthetics", "logistics", "graphics", "series",
    "species", "news", "means", "data", "media",
}

_UNITS = {
    "kg": "kilogram", "mol": "mole", "kj": "kilojoule", "kpa": "kilopascal",
    "nm": "nanometre", "dm3": "decimetre cubed", "cm3": "centimetre cubed",
    "kj mol": "kilojoule per mole",
}


def _expand_spelling(kw: str, generic: set = None) -> set:
    """Return valid spelling/morphological variants of a keyword.

    `generic` = set of single-word keywords that appear in >= 3 topics (shared
    cross-topic vocabulary).  Those are never pluralised: a fresh plural string
    would escape the classifier's collision dampening and create false signals
    (e.g. "reaction" -> "reactions" — generic)."""
    out = set()
    lw = kw.lower().strip()
    if not lw or len(lw) < 2:
        return out
    out.add(lw)
    # British/US both directions
    for b, a in BRIT_US.items():
        if lw == b:
            out.add(a)
        elif lw == a:
            out.add(b)
    # hyphenated <-> unhyphenated <-> spaced
    if "-" in lw:
        out.add(lw.replace("-", ""))
        out.add(lw.replace("-", " "))
    # Plural forms are DELIBERATELY not auto-generated (2026-08-15): blanket
    # pluralisation introduced false signals ("reaction" -> "reactions"
    # matched generic "two reactions" prose and tipped organic-synthesis
    # questions into a near-tie).  Plural coverage is instead provided by the
    # explicit IRREGULAR_PLURALS map + the named-entity lists, and by a
    # classifier-side normalisation (light stemming) added as a variable.
    # Here we only add irregular plurals that are unambiguous.
    if lw not in NO_PLURAL and lw in IRREGULAR_PLURALS:
        out.add(IRREGULAR_PLURALS[lw])
    return out


# ── Curated NAMED ENTITIES: topic_name -> [high-precision phrases] ──────────
# (subject-scoped dicts; the expander merges them into matching topic keywords)
NAMED_ENTITIES = {
    "Chemistry_9701": {
        "Chemical_energetics": ["hess's law", "born-haber cycle", "lattice enthalpy",
            "enthalpy of formation", "enthalpy of combustion", "enthalpy of neutralisation",
            "standard enthalpy change", "bond dissociation enthalpy", "entropy", "gibbs free energy"],
        "Equilibria": ["le chatelier's principle", "dynamic equilibrium", "equilibrium constant",
            "kc", "kp", "solubility product", "ksp", "partition coefficient", "buffer solution",
            "acid dissociation constant", "ka", "ionic product of water", "kw"],
        "Reaction_kinetics": ["arrhenius equation", "activation energy", "rate equation",
            "rate constant", "order of reaction", "initial rate", "half-life",
            "maxwell-boltzmann distribution", "collision theory", "catalyst"],
        "Electrochemistry": ["standard electrode potential", "electrochemical series",
            "galvanic cell", "electrolytic cell", "salt bridge", "half-cell",
            "redox potential", "faraday constant", "nernst equation", "fuel cell"],
        "An_introduction_to_AS_Level_organic_chemistry": ["homologous series", "functional group",
            "structural isomer", "stereoisomer", "optical isomer", "chiral", "enantiomer",
            "racemic mixture", "cis-trans isomerism", "e-z isomerism", "nucleophile",
            "electrophile", "free radical", "substitution reaction", "addition reaction",
            "elimination reaction", "condensation reaction", "hydrolysis", "sn1", "sn2"],
        "Hydrocarbons": ["alkane", "alkene", "alkyne", "markovnikov's rule",
            "addition polymerisation", "cracking", "fractional distillation", "petroleum"],
        "Halogenoalkanes": ["halogenoalkane", "nucleophilic substitution", "chlorofluorocarbon",
            "cfc", "ozone depletion", "grignard reagent"],
        "Alcohols": ["primary alcohol", "secondary alcohol", "tertiary alcohol",
            "oxidation of alcohols", "esterification", "dehydration of alcohols"],
        "Carbonyl_compounds": ["aldehyde", "ketone", "2,4-dinitrophenylhydrazine",
            "2,4-dnph", "tollens' reagent", "fehling's solution", "nucleophilic addition"],
        "Carboxylic_acids_and_derivatives": ["carboxylic acid", "acyl chloride", "ester",
            "amide", "acid anhydride", "nucleophilic acyl substitution"],
        "Nitrogen_compounds": ["amine", "amide", "nitrile", "hinsberg test",
            "diazonium salt", "azo dye"],
        "Polymerisation": ["addition polymer", "condensation polymer", "polyamide",
            "polyester", "nylon", "kevlar", "protein polymer"],
        "Organic_synthesis": ["retrosynthesis", "synthetic route", "functional group interconversion"],
        "Analytical_techniques": ["infrared spectroscopy", "ir spectrum", "mass spectrometry",
            "molecular ion peak", "proton nmr", "carbon-13 nmr", "chemical shift",
            "thin-layer chromatography", "tlc", "gas-liquid chromatography", "glc",
            "retention time", "high-performance liquid chromatography", "hplc"],
        "Transition_elements": ["transition metal", "complex ion", "ligand",
            "ligand exchange", "coordination number", "d-block", "coloured ion",
            "variable oxidation state", "catalyst"],
        "An_introduction_to_AS_Level_organic_chemistry": ["homologous series"],
        "The_Periodic_Table_chemical_periodicity": ["ionisation energy", "electronegativity",
            "atomic radius", "ionic radius", "periodic trend", "melting point trend"],
        "Chemical_bonding": ["covalent bond", "ionic bond", "metallic bond", "hydrogen bonding",
            "van der waals", "dipole", "sigma bond", "pi bond", "hybridisation",
            "vsepr", "electronegativity difference", "polar bond"],
        "States_of_matter": ["ideal gas", "boyle's law", "charles's law",
            "avogadro's law", "kinetic theory of gases", "real gas", "intermolecular force"],
        "Atoms_molecules_and_stoichiometry": ["avogadro constant", "mole", "molar mass",
            "empirical formula", "molecular formula", "limiting reagent",
            "percentage yield", "atom economy", "relative atomic mass"],
        "Acids_and_bases": ["bronsted-lowry", "lewis acid", "lewis base", "strong acid",
            "weak acid", "ph scale", "conjugate acid", "conjugate base", "titration",
            "indicator", "equivalence point", "end point"],
        "Redox": ["oxidation number", "oxidising agent", "reducing agent",
            "disproportionation", "half-equation", "redox titration"],
        "Group_2": ["alkaline earth metal", "magnesium", "calcium", "strontium", "barium",
            "thermal decomposition of carbonates", "solubility of hydroxides"],
        "Group_17": ["halogen", "chlorine", "bromine", "iodine", "displacement reaction",
            "oxidising power of halogens", "halide ion"],
    },
    "Physics_9702": {
        "Physical_quantities_and_units": ["si unit", "base unit", "derived unit",
            "scalar quantity", "vector quantity", "dimensional analysis", "systematic error",
            "random error", "uncertainty", "percentage uncertainty"],
        "Kinematics": ["uniform acceleration", "equations of motion", "free fall",
            "projectile motion", "displacement-time graph", "velocity-time graph",
            "terminal velocity", "air resistance"],
        "Dynamics": ["newton's first law", "newton's second law", "newton's third law",
            "friction", "normal reaction", "tension", "impulse", "momentum",
            "conservation of momentum", "elastic collision", "inelastic collision"],
        "Forces_density_and_pressure": ["couple", "torque", "moment of a force",
            "principle of moments", "centre of gravity", "upthrust", "archimedes' principle",
            "pressure", "density", "hooke's law", "young modulus", "elastic limit"],
        "Work_energy_and_power": ["kinetic energy", "potential energy", "work done",
            "conservation of energy", "power", "efficiency", "gravitational potential energy",
            "elastic potential energy"],
        "Circular_motion": ["centripetal force", "centripetal acceleration", "angular velocity",
            "angular displacement", "period of rotation"],
        "Gravitational_fields": ["gravitational field strength", "gravitational potential",
            "newton's law of gravitation", "gravitational constant", "escape velocity",
            "geostationary orbit", "kepler's laws"],
        "Temperature_and_thermal": ["specific heat capacity", "latent heat of fusion",
            "latent heat of vaporisation", "absolute zero", "kelvin scale",
            "internal energy", "thermal equilibrium", "brownian motion", "ideal gas equation",
            "boyle's law", "charles's law", "pressure law"],
        "Oscillations": ["simple harmonic motion", "amplitude", "frequency", "period",
            "angular frequency", "resonance", "damping", "natural frequency",
            "forced oscillation", "free oscillation"],
        "Waves": ["transverse wave", "longitudinal wave", "wavelength", "frequency",
            "amplitude", "wave speed", "phase difference", "polarisation", "diffraction",
            "interference", "superposition", "stationary wave", "node", "antinode",
            "young's double slit", "diffraction grating", "coherence", "doppler effect"],
        "Electricity": ["ohm's law", "resistance", "resistivity", "potential difference",
            "current", "kirchhoff's laws", "series circuit", "parallel circuit",
            "emf", "internal resistance", "potential divider", "power dissipation"],
        "Electric_fields": ["electric field strength", "coulomb's law", "electric potential",
            "uniform electric field", "capacitance", "capacitor", "time constant",
            "discharging capacitor", "charging capacitor"],
        "Magnetic_fields": ["magnetic flux density", "magnetic flux", "fleming's left-hand rule",
            "force on a current-carrying conductor", "moving charge in a magnetic field",
            "electromagnetic induction", "faraday's law", "lenz's law", "transformer",
            "alternating current", "root mean square", "rms", "peak voltage"],
        "Quantum_physics": ["photoelectric effect", "photon", "work function", "threshold frequency",
            "planck constant", "einstein's photoelectric equation", "wave-particle duality",
            "de broglie wavelength", "electron diffraction", "emission spectrum",
            "absorption spectrum", "energy level", "line spectrum"],
        "Nuclear_physics": ["alpha particle", "beta particle", "gamma radiation",
            "half-life", "decay constant", "radioactive decay", "nuclear fission",
            "nuclear fusion", "binding energy", "mass defect", "einstein's mass-energy",
            "e=mc2", "rutherford scattering", "nuclear model of the atom"],
        "Particle_physics": ["quark", "lepton", "hadron", "baryon", "meson",
            "electron", "proton", "neutron", "neutrino", "antimatter", "standard model",
            "fundamental particle", "conservation of charge", "conservation of baryon number"],
        "Astronomy": ["hubble's law", "red shift", "big bang theory", "luminosity",
            "apparent magnitude", "absolute magnitude", "parallax", "stellar evolution",
            "main sequence", "red giant", "white dwarf", "neutron star", "black hole",
            "cosmic microwave background"],
    },
    "Biology_9700": {
        "Cell_structure": ["cell membrane", "cytoplasm", "nucleus", "mitochondrion",
            "chloroplast", "ribosome", "endoplasmic reticulum", "golgi apparatus",
            "lysosome", "vacuole", "cell wall", "prokaryote", "eukaryote",
            "ultrastructure", "organelle"],
        "Biological_molecules": ["carbohydrate", "monosaccharide", "disaccharide",
            "polysaccharide", "starch", "glycogen", "cellulose", "protein",
            "amino acid", "peptide bond", "polypeptide", "lipid", "triglyceride",
            "phospholipid", "nucleic acid", "dna", "rna", "nucleotide",
            "atp", "water", "benedict's test", "biuret test", "iodine test", "emulsion test"],
        "Enzymes": ["enzyme", "active site", "substrate", "enzyme-substrate complex",
            "lock and key", "induced fit", "denaturation", "competitive inhibitor",
            "non-competitive inhibitor", "vmax", "km", "michaelis-menten",
            "temperature coefficient", "q10", "optimum ph", "optimum temperature"],
        "Cell_membranes_and_transport": ["fluid mosaic model", "phospholipid bilayer",
            "diffusion", "facilitated diffusion", "osmosis", "active transport",
            "endocytosis", "exocytosis", "water potential", "solute potential",
            "pressure potential", "turgor", "plasmolysis", "carrier protein", "channel protein"],
        "Cell_division": ["mitosis", "meiosis", "cell cycle", "interphase", "prophase",
            "metaphase", "anaphase", "telophase", "cytokinesis", "chromosome",
            "chromatid", "centromere", "spindle", "haploid", "diploid",
            "crossing over", "independent assortment", "stem cell", "cancer", "tumour"],
        "Nucleic_acids_and_protein_synthesis": ["dna replication", "semi-conservative",
            "transcription", "translation", "messenger rna", "mrna", "transfer rna",
            "trna", "ribosomal rna", "codon", "anticodon", "genetic code",
            "gene", "allele", "mutation", "polymerase chain reaction", "pcr", "gel electrophoresis"],
        "Transport_in_plants": ["xylem", "phloem", "transpiration", "transpiration stream",
            "cohesion-tension", "root pressure", "stomata", "guard cell",
            "translocation", "source", "sink", "mass flow", "potometer"],
        "Transport_in_mammals": ["heart", "atrium", "ventricle", "artery", "vein",
            "capillary", "blood", "plasma", "red blood cell", "erythrocyte",
            "white blood cell", "leucocyte", "platelet", "haemoglobin",
            "oxyhaemoglobin", "dissociation curve", "bohr effect", "cardiac cycle",
            "cardiac output", "heart rate", "blood pressure", "tissue fluid", "lymph"],
        "Gas_exchange": ["alveolus", "alveoli", "trachea", "bronchus", "bronchiole",
            "gaseous exchange", "ventilation", "tidal volume", "vital capacity",
            "spirometer", "partial pressure", "surfactant", "gill", "spiracle"],
        "Infectious_disease": ["pathogen", "bacterium", "virus", "fungus", "protoctist",
            "transmission", "cholera", "tuberculosis", "malaria", "hiv", "aids",
            "antibiotic", "penicillin", "antibiotic resistance", "epidemic", "pandemic"],
        "Immunity": ["immune response", "antigen", "antibody", "phagocytosis", "phagocyte",
            "lymphocyte", "b cell", "t cell", "plasma cell", "memory cell",
            "vaccination", "immunity", "active immunity", "passive immunity",
            "monoclonal antibody", "autoimmune disease"],
        "Energy_and_respiration": ["aerobic respiration", "anaerobic respiration",
            "glycolysis", "krebs cycle", "link reaction", "electron transport chain",
            "oxidative phosphorylation", "atp synthesis", "chemiosmosis",
            "respiratory quotient", "rq", "lactate", "fermentation"],
        "Photosynthesis": ["chloroplast", "thylakoid", "granum", "stroma", "chlorophyll",
            "light-dependent reaction", "light-independent reaction", "calvin cycle",
            "photophosphorylation", "rubisco", "photosystem", "photolysis",
            "limiting factor", "action spectrum", "absorption spectrum"],
        "Homeostasis": ["negative feedback", "positive feedback", "thermoregulation",
            "osmoregulation", "kidney", "nephron", "glomerulus", "bowman's capsule",
            "ultrafiltration", "selective reabsorption", "adrenal gland", "adrenaline",
            "insulin", "glucagon", "diabetes", "homeostatic control"],
        "Coordination": ["neurone", "sensory neurone", "motor neurone", "relay neurone",
            "synapse", "neurotransmitter", "reflex arc", "resting potential",
            "action potential", "depolarisation", "repolarisation", "myelin sheath",
            "saltatory conduction", "acetylcholine", "hormone", "endocrine gland",
            "target organ", "pituitary gland", "thyroid gland"],
        "Inheritance": ["monohybrid cross", "dihybrid cross", "dominant allele",
            "recessive allele", "codominance", "sex linkage", "phenotype", "genotype",
            "homozygous", "heterozygous", "punnet square", "mendel", "pedigree",
            "test cross", "autosomal", "multiple allele"],
        "Genetic_technology": ["genetic engineering", "recombinant dna", "restriction enzyme",
            "dna ligase", "plasmid", "vector", "transgenic", "genetically modified",
            "gene therapy", "dna fingerprinting", "electrophoresis", "somatic cell",
            "germ line", "cloning"],
        "Ecology": ["ecosystem", "habitat", "population", "community", "food chain",
            "food web", "trophic level", "producer", "consumer", "decomposer",
            "biomass", "pyramid of numbers", "pyramid of biomass", "pyramid of energy",
            "nitrogen cycle", "carbon cycle", "nitrification", "denitrification",
            "nitrogen fixation", "succession", "climax community"],
        "Biodiversity": ["biodiversity", "conservation", "endangered species", "extinction",
            "habitat loss", "deforestation", "overfishing", "captive breeding",
            "seed bank", "protected area", "keystone species", "indicator species"],
    },
    "Psychology_9990": {
        "Research_methods_psychology": ["independent variable", "dependent variable",
            "control variable", "extraneous variable", "confounding variable",
            "experimental design", "independent groups", "repeated measures",
            "matched pairs", "counterbalancing", "randomisation", "standardisation",
            "hypothesis", "null hypothesis", "alternative hypothesis", "operationalisation",
            "reliability", "validity", "internal validity", "external validity",
            "ecological validity", "demand characteristics", "investigator effect",
            "social desirability", "sampling", "random sample", "opportunity sample",
            "volunteer sample", "stratified sample", "questionnaire", "interview",
            "observation", "case study", "correlation", "correlation coefficient",
            "scatter diagram", "chi-squared", "mann-whitney", "wilcoxon",
            "spearman's rho", "significance level", "type one error", "type two error",
            "ethical guidelines", "informed consent", "deception", "debrief",
            "right to withdraw", "confidentiality"],
        "Biological_psychology": ["central nervous system", "peripheral nervous system",
            "neuron", "synapse", "neurotransmitter", "serotonin", "dopamine",
            "acetylcholine", "adrenaline", "noradrenaline", "gaba", "action potential",
            "resting potential", "brain structure", "cerebral cortex", "hippocampus",
            "amygdala", "hypothalamus", "frontal lobe", "temporal lobe", "parietal lobe",
            "occipital lobe", "brain lateralisation", "split brain", "hemisphere",
            "mri", "fmri", "pet scan", "eeg", "genetics", "twin study",
            "adoption study", "concordance rate", "heritability", "nature nurture",
            "evolution", "fight or flight", "sympathetic nervous system", "hormone",
            "cortisol", "testosterone", "oxytocin"],
        "Cognitive_psychology": ["memory", "encoding", "storage", "retrieval",
            "short-term memory", "long-term memory", "working memory", "multi-store model",
            "atkinson and shiffrin", "baddeley", "central executive", "phonological loop",
            "visuospatial sketchpad", "episodic buffer", "episodic memory", "semantic memory",
            "procedural memory", "forgetting", "interference", "decay", "retrieval failure",
            "cue dependent forgetting", "reconstruction", "schema", "loftus",
            "eyewitness testimony", "leading question", "post-event information",
            "cognitive interview", "attention", "perception", "thinking", "problem solving"],
        "Social_psychology": ["conformity", "obedience", "compliance", "milgram", "asch",
            "zimbardo", "stanford prison experiment", "informational social influence",
            "normative social influence", "majority influence", "minority influence",
            "social roles", "deindividuation", "bystander effect", "diffusion of responsibility",
            "prosocial behaviour", "altruism", "aggression", "frustration-aggression",
            "social learning theory", "bandura", "attribution", "fundamental attribution error",
            "attitude", "prejudice", "discrimination", "stereotyping", "in-group", "out-group"],
        "Developmental_psychology": ["attachment", "bowlby", "ainsworth", "strange situation",
            "secure attachment", "insecure avoidant", "insecure resistant", "maternal deprivation",
            "privation", "cognitive development", "piaget", "sensorimotor stage",
            "preoperational stage", "concrete operational stage", "formal operational stage",
            "schema", "assimilation", "accommodation", "object permanence", "conservation",
            "egocentrism", "theory of mind", "vygotsky", "zone of proximal development",
            "scaffolding", "language development", "moral development", "kohlberg",
            "gender development", "social learning"],
        "Psychopathology": ["abnormality", "mental disorder", "statistical infrequency",
            "deviation from social norms", "failure to function adequately", "deviation from ideal mental health",
            "dsm", "icd", "classification system", "depression", "bipolar disorder",
            "schizophrenia", "anxiety", "phobia", "ocd", "eating disorder", "anorexia",
            "bulimia", "biological approach", "psychodynamic approach", "behavioural approach",
            "cognitive approach", "cognitive behavioural therapy", "cbt", "drug therapy",
            "psychotherapy", "systematic desensitisation", "flooding", "aversion therapy"],
    },
    "Sociology_9699": {
        "Socialisation_culture_identity": ["socialisation", "primary socialisation",
            "secondary socialisation", "culture", "subculture", "norms", "values",
            "identity", "gender identity", "ethnic identity", "role", "status",
            "social construction", "nature vs nurture", "feral children"],
        "Research_methods": ["positivism", "interpretivism", "quantitative data",
            "qualitative data", "questionnaire", "interview", "participant observation",
            "non-participant observation", "case study", "longitudinal study",
            "sample", "sampling", "representative", "reliability", "validity",
            "triangulation", "ethics", "informed consent", "anonymity", "confidentiality",
            "primary data", "secondary data", "official statistics", "content analysis"],
        "Family": ["nuclear family", "extended family", "reconstituted family",
            "single-parent family", "symmetrical family", "conjugal roles", "joint conjugal roles",
            "segregated conjugal roles", "marriage", "divorce", "cohabitation",
            "functionalism and family", "murdock", "parsons", "new right", "feminism and family",
            "childhood", "domestic division of labour", "patriarchy"],
        "Education": ["hidden curriculum", "comprehensive school", "grammar school",
            "meritocracy", "social class and education", "material deprivation",
            "cultural deprivation", "labelling theory", "self-fulfilling prophecy",
            "setting and streaming", "ethnicity and education", "gender and education",
            "functionalist view of education", "durkeim", "vocational education"],
        "Crime_and_deviance": ["deviance", "crime", "social control", "formal social control",
            "informal social control", "anomie", "strain theory", "merton", "labelling",
            "becker", "moral panic", "subcultural theory", "cohen", "marxist theory of crime",
            "feminist theory of crime", "white-collar crime", "corporate crime",
            "crime statistics", "victimisation", "media and crime"],
        "Stratification_and_inequality": ["social stratification", "social class",
            "social mobility", "closed system", "open system", "caste system", "slavery",
            "social inequality", "wealth", "income", "poverty", "absolute poverty",
            "relative poverty", "underclass", "gender inequality", "ethnic inequality",
            "age inequality", "marx and class", "weber and class", "functionalist view of stratification",
            "davis and moore", "meritocracy", "life chances"],
    },
    "Economics_9708": {
        "Basic_economic_ideas_and_resource_allocation": ["scarcity", "opportunity cost",
            "factors of production", "land labour capital enterprise", "production possibility curve",
            "ppc", "productive efficiency", "allocative efficiency", "ceteris paribus",
            "normative statement", "positive statement", "free market economy",
            "command economy", "mixed economy", "specialisation", "division of labour", "money"],
        "The_price_system_and_the_microeconomy_AS": ["demand", "supply", "demand curve",
            "supply curve", "market equilibrium", "excess demand", "excess supply",
            "price elasticity of demand", "ped", "price elasticity of supply", "pes",
            "income elasticity of demand", "yed", "cross elasticity of demand", "xed",
            "elastic", "inelastic", "substitute good", "complementary good", "normal good",
            "inferior good", "consumer surplus", "producer surplus", "indirect tax", "subsidy"],
        "The_macroeconomy_AS": ["national income", "gdp", "gnp", "circular flow of income",
            "aggregate demand", "aggregate supply", "inflation", "deflation", "disinflation",
            "unemployment", "frictional unemployment", "structural unemployment",
            "cyclical unemployment", "seasonal unemployment", "balance of payments",
            "current account", "exchange rate", "economic growth", "recession",
            "consumer price index", "cpi", "real gdp", "nominal gdp"],
        "Government_macroeconomic_intervention_AS": ["fiscal policy", "monetary policy",
            "supply-side policy", "taxation", "government spending", "budget deficit",
            "budget surplus", "interest rate", "central bank", "quantitative easing",
            "inflation targeting", "exchange rate policy", "crowding out", "multiplier effect"],
        "International_economic_issues_AS": ["international trade", "comparative advantage",
            "absolute advantage", "protectionism", "tariff", "quota", "embargo",
            "subsidy", "free trade", "world trade organisation", "wto", "trade deficit",
            "trade surplus", "terms of trade", "globalisation", "multinational corporation",
            "mnc", "foreign direct investment", "fdi", "exchange rate appreciation", "depreciation"],
        "The_price_system_and_the_microeconomy_A_Level": ["utility", "marginal utility",
            "diminishing marginal utility", "indifference curve", "budget line",
            "income effect", "substitution effect", "market failure", "externality",
            "public good", "merit good", "demerit good", "private cost", "social cost",
            "private benefit", "social benefit", "monopoly", "oligopoly", "monopolistic competition",
            "perfect competition", "market structure", "barriers to entry", "price discrimination",
            "deadweight loss", "government intervention", "regulation", "privatisation", "nationalisation"],
        "The_macroeconomy_A_Level": ["circular flow", "aggregate demand curve", "long-run aggregate supply",
            "short-run aggregate supply", "economic cycle", "output gap", "potential output",
            "phillips curve", "natural rate of unemployment", "money supply", "liquidity preference",
            "velocity of circulation", "quantity theory of money", "economic development",
            "human development index", "hdi", "developing economy", "emerging economy",
            "poverty", "income inequality", "lorenz curve", "gini coefficient", "sustainable development"],
        "Labour_market_forces_and_government_intervention": ["labour market", "demand for labour",
            "supply of labour", "wage rate", "minimum wage", "trade union", "monopsony",
            "marginal revenue product", "labour productivity", "mobility of labour"],
    },
    "Business_9609": {
        "Business_and_its_environment": ["enterprise", "entrepreneur", "business objectives",
            "mission statement", "corporate social responsibility", "csr", "stakeholder",
            "shareholder", "business environment", "pestle analysis", "swot analysis",
            "sole trader", "partnership", "private limited company", "public limited company",
            "franchise", "joint venture", "multinational", "economic environment",
            "legal environment", "technological environment"],
        "People_in_organisations": ["human resource management", "recruitment", "selection",
            "training", "induction", "performance appraisal", "motivation", "maslow",
            "herzberg", "taylor", "mcgregor", "theory x", "theory y", "leadership style",
            "autocratic leadership", "democratic leadership", "laissez-faire",
            "organisational structure", "hierarchy", "span of control", "delegation",
            "centralisation", "decentralisation", "trade union", "industrial relations"],
        "Marketing": ["marketing mix", "4ps", "product", "price", "place", "promotion",
            "market research", "primary research", "secondary research", "market segmentation",
            "target market", "niche marketing", "mass marketing", "product life cycle",
            "branding", "packaging", "advertising", "sales promotion", "pricing strategy",
            "elasticity of demand", "distribution channel", "e-commerce"],
        "Operations_and_project_management": ["operations management", "production",
            "job production", "batch production", "flow production", "lean production",
            "just-in-time", "jit", "quality control", "quality assurance", "total quality management",
            "tqm", "kaizen", "capacity utilisation", "inventory management", "supply chain",
            "outsourcing", "productivity", "break-even analysis", "break-even point",
            "economies of scale", "diseconomies of scale", "location decisions"],
        "Finance_and_accounting": ["cash flow", "cash flow forecast", "working capital",
            "liquidity", "profit", "gross profit", "net profit", "profit margin",
            "return on capital employed", "roce", "current ratio", "acid test ratio",
            "budget", "budgeting", "variance analysis", "investment appraisal",
            "payback period", "average rate of return", "net present value", "internal rate of return",
            "sources of finance", "share capital", "loan capital", "overdraft", "leasing",
            "balance sheet", "income statement", "ratio analysis"],
        "Strategic_management": ["strategic management", "corporate strategy", "business strategy",
            "functional strategy", "strategic analysis", "ansoff matrix", "boston matrix",
            "porter's five forces", "competitive advantage", "differentiation", "cost leadership",
            "merger", "acquisition", "takeover", "strategic alliance", "globalisation",
            "growth strategy", "diversification", "vertical integration", "horizontal integration"],
    },
    "History_9489": {
        "Modern_Europe": ["french revolution", "napoleon", "congress of vienna", "metternich",
            "liberalism", "nationalism", "conservatism", "revolution of 1848", "unification of italy",
            "unification of germany", "bismarck", "cavour", "garibaldi", "second empire",
            "commune", "industrialisation", "urbanisation", "suffrage", "chartism"],
        "USA_1820": ["jacksonian democracy", "manifest destiny", "westward expansion",
            "slavery", "abolitionism", "secession", "american civil war", "lincoln",
            "reconstruction", "plantation economy", "missouri compromise"],
        "International_1870": ["imperialism", "colonisation", "scramble for africa",
            "berlin conference", "alliance system", "triple alliance", "triple entente",
            "arms race", "naval race", "july crisis", "schlieffen plan"],
        "WWI": ["world war one", "first world war", "trench warfare", "western front",
            "eastern front", "gallipoli", "somme", "verdun", "armistice", "fourteen points",
            "treaty of versailles", "wilson", "clemenceau", "lloyd george", "war guilt clause",
            "reparations", "league of nations"],
        "Germany_1918": ["weimar republic", "weimar constitution", "hyperinflation",
            "ruhr occupation", "dawes plan", "young plan", "great depression in germany",
            "nazi party", "hitler", "enabling act", "night of the long knives",
            "nuremberg laws", "kristallnacht", "gestapo", "concentration camp", "propaganda",
            "reichstag fire"],
        "Russia_1905": ["tsarist regime", "nicholas ii", "1905 revolution", "duma",
            "rasputin", "february revolution", "october revolution", "bolshevik",
            "lenin", "trotsky", "stalin", "civil war", "war communism", "new economic policy",
            "nep", "collectivisation", "five year plan", "great purge", "gulags"],
        "USA_1944": ["great depression", "new deal", "roosevelt", "hoover",
            "civil rights movement", "martin luther king", "segregation", "desegregation",
            "brown v board", "montgomery bus boycott", "vietnam war", "watergate", "nixon"],
        "International_1945": ["cold war", "iron curtain", "truman doctrine", "marshall plan",
            "berlin blockade", "berlin airlift", "nato", "warsaw pact", "korean war",
            "cuban missile crisis", "berlin wall", "arms race", "space race", "detente",
            "vietnam war", "soviet invasion of afghanistan", "glasnost", "perestroika",
            "fall of the berlin wall", "dissolution of the soviet union"],
        "Holocaust": ["holocaust", "genocide", "final solution", "auschwitz",
            "wannsee conference", "antisemitism", "nuremberg trials"],
    },
    "Geography_9696": {
        "Core_Physical_Hydrology": ["hydrological cycle", "drainage basin", "precipitation",
            "evapotranspiration", "infiltration", "surface runoff", "groundwater", "aquifer",
            "water table", "river discharge", "hydrograph", "flood", "floodplain", "levee",
            "meander", "oxbow lake", "delta", "waterfall", "gorge", "erosion", "deposition"],
        "Core_Physical_Atmosphere": ["atmosphere", "insolation", "heat budget", "temperature",
            "pressure", "wind", "global atmospheric circulation", "trade winds", "westerlies",
            "monsoon", "rainfall", "convectional rainfall", "frontal rainfall", "orographic rainfall",
            "humidity", "condensation", "cloud formation", "el nino", "la nina"],
        "Core_Physical_Rocks": ["rock cycle", "igneous rock", "sedimentary rock",
            "metamorphic rock", "weathering", "physical weathering", "chemical weathering",
            "biological weathering", "mass movement", "plate tectonics", "plate boundary",
            "convergent boundary", "divergent boundary", "transform boundary", "earthquake",
            "volcano", "subduction", "fold mountain", "rift valley", "tsunami"],
        "Core_Human_Population": ["population distribution", "population density",
            "birth rate", "death rate", "fertility rate", "mortality rate", "natural increase",
            "population growth", "demographic transition model", "population pyramid",
            "overpopulation", "underpopulation", "migration", "push factor", "pull factor",
            "refugee", "population policy"],
        "Core_Human_Migration": ["migration", "internal migration", "international migration",
            "rural to urban migration", "urbanisation", "counter-urbanisation", "remittances",
            "brain drain", "diaspora"],
        "Core_Human_Settlement": ["settlement", "site", "situation", "hierarchy",
            "urban structure", "cbd", "central business district", "suburb", "inner city",
            "urban sprawl", "rural settlement", "dispersed settlement", "nucleated settlement",
            "urban growth", "megacity"],
        "Advanced_Physical_Tropical": ["tropical rainforest", "tropical ecosystem",
            "nutrient cycle", "deforestation", "biodiversity", "leaching", "laterite",
            "shifting cultivation", "selective logging"],
        "Advanced_Physical_Coastal": ["coastal erosion", "wave action", "longshore drift",
            "beach", "spit", "bar", "lagoon", "cliff", "wave-cut platform", "headland",
            "bay", "coastal management", "hard engineering", "soft engineering", "sea wall",
            "groynes", "sand dune", "salt marsh"],
        "Advanced_Physical_Hazardous": ["natural hazard", "tropical cyclone", "hurricane",
            "typhoon", "earthquake", "volcanic eruption", "hazard management", "prediction",
            "preparedness", "response", "recovery", "risk assessment", "vulnerability"],
        "Advanced_Physical_Arid": ["arid environment", "desert", "desertification",
            "wind erosion", "sand dune", "oasis", "salinisation", "water scarcity", "irrigation"],
        "Advanced_Human_Production": ["agriculture", "intensive farming", "extensive farming",
            "subsistence farming", "commercial farming", "agribusiness", "green revolution",
            "industrial location", "manufacturing", "deindustrialisation", "tertiary sector",
            "quaternary sector", "tourism", "eco-tourism"],
        "Advanced_Human_Environmental_management": ["environmental management", "conservation",
            "sustainable development", "renewable energy", "non-renewable energy", "pollution",
            "climate change", "greenhouse effect", "global warming", "carbon footprint",
            "recycling", "waste management"],
        "Advanced_Human_Global_interdependence": ["globalisation", "international trade",
            "trade bloc", "multinational corporation", "foreign direct investment", "global village",
            "interdependence", "fair trade", "debt", "development gap", "north-south divide"],
        "Advanced_Human_Economic_transition": ["economic development", "development indicators",
            "gdp per capita", "human development index", "primary sector", "secondary sector",
            "tertiary sector", "quaternary sector", "industrialisation", "newly industrialised country",
            "emerging economy", "informal economy"],
    },
    "Mathematics_9709": {
        "P1_Pure_Mathematics_1": ["quadratic equation", "completing the square", "discriminant", "simultaneous equation", "coordinate geometry", "gradient", "circle equation", "binomial expansion", "pascal's triangle", "differentiation", "derivative", "tangent", "normal", "integration", "definite integral", "indefinite integral", "area under curve", "arithmetic progression", "geometric progression", "sum to infinity", "trigonometry", "sine rule", "cosine rule", "radian measure", "arc length", "sector area"],
        "P2_Pure_Mathematics_2": ["logarithm", "exponential function", "natural logarithm", "laws of logarithms", "modulus function", "partial fraction", "parametric equation", "implicit differentiation", "second derivative", "stationary point", "point of inflection", "trapezium rule", "numerical integration", "integration by substitution"],
        "P3_Pure_Mathematics_3": ["trigonometric identity", "double angle formula", "compound angle formula", "harmonic form", "vector", "vector equation of line", "vector equation of plane", "scalar product", "dot product", "complex number", "argand diagram", "modulus argument form", "de moivre's theorem", "polar form", "differential equation", "separation of variables", "integration by parts"],
        "Mechanics": ["kinematics", "equations of motion", "projectile", "newton's laws of motion", "friction", "coefficient of friction", "momentum", "conservation of momentum", "impulse", "work", "energy", "power", "moment", "equilibrium", "centre of mass", "resultant force", "resolving forces", "inclined plane", "pulley"],
        "Statistics_1": ["mean", "median", "mode", "standard deviation", "variance", "quartile", "interquartile range", "box plot", "histogram", "frequency distribution", "probability", "mutually exclusive", "independent events", "conditional probability", "tree diagram", "venn diagram", "permutation", "combination", "binomial distribution", "expected value", "discrete random variable", "normal distribution", "z-score", "central limit theorem", "sampling", "correlation", "regression", "pmcc", "pearson"],
        "Statistics_2": ["poisson distribution", "hypothesis testing", "null hypothesis", "significance level", "critical region", "type i error", "type ii error", "normal approximation", "continuity correction", "confidence interval"],
    },
    "Further_Mathematics_9231": {
        "Further_Pure_Mathematics_1": ["roots of polynomial equations", "sum of roots", "product of roots", "rational function", "partial fraction", "polar coordinate", "hyperbolic function", "sinh", "cosh", "tanh", "inverse hyperbolic function", "summation of series", "mathematical induction", "complex root", "cube root of unity"],
        "Further_Pure_Mathematics_2": ["maclaurin series", "taylor series", "matrix", "determinant", "inverse matrix", "eigenvalue", "eigenvector", "linear transformation", "rotation matrix", "reflection matrix", "differential equation", "first order", "second order", "auxiliary equation", "particular integral", "complementary function"],
        "Further_Mechanics": ["moment of inertia", "angular momentum", "angular velocity", "centripetal force", "circular motion", "simple harmonic motion", "damped oscillation", "forced oscillation", "elastic collision", "coefficient of restitution", "variable mass", "rocket equation", "centre of mass of lamina"],
        "Further_Statistics": ["discrete random variable", "continuous random variable", "probability density function", "cumulative distribution function", "geometric distribution", "negative binomial distribution", "exponential distribution", "gamma distribution", "sampling distribution", "unbiased estimator", "confidence interval", "chi-squared test", "contingency table", "goodness of fit", "linear regression", "least squares", "bivariate normal distribution", "central limit theorem"],
    },
    "Mathematics_0580": {
        "Number": ["integer", "prime number", "factor", "multiple", "highest common factor", "lowest common multiple", "fraction", "decimal", "percentage", "ratio", "proportion", "standard form", "scientific notation", "significant figure", "square root", "cube root", "index", "surd", "direct proportion", "inverse proportion"],
        "Algebra": ["algebraic expression", "simplify", "expand", "factorise", "linear equation", "quadratic equation", "simultaneous equation", "inequality", "substitution", "formula", "subject of formula", "sequence", "nth term", "arithmetic sequence", "geometric sequence"],
        "Geometry": ["angle", "triangle", "quadrilateral", "polygon", "circle", "circumference", "area", "perimeter", "pythagoras", "theorem", "trigonometry", "sine", "cosine", "tangent", "similarity", "congruence", "symmetry", "reflection", "rotation", "translation", "enlargement", "scale factor", "bearings"],
        "Statistics_and_probability": ["mean", "median", "mode", "range", "bar chart", "pie chart", "histogram", "scatter graph", "line of best fit", "probability", "mutually exclusive", "independent", "tree diagram", "sample space"],
    },
    "Computer_Science_9618": {
        "Information_representation": ["binary", "denary", "hexadecimal", "two's complement", "binary addition", "binary subtraction", "ascii", "unicode", "bcd", "character set", "sound sampling", "sampling rate", "bitmap image", "pixel", "resolution", "colour depth", "compression", "lossless compression", "lossy compression", "run-length encoding"],
        "Communication": ["network", "lan", "wan", "topology", "star topology", "bus topology", "ring topology", "mesh topology", "router", "switch", "hub", "packet", "packet switching", "circuit switching", "protocol", "tcp", "ip", "tcp/ip", "osi model", "client-server", "peer-to-peer", "wireless", "wi-fi", "bluetooth", "bandwidth", "latency"],
        "Hardware": ["cpu", "central processing unit", "register", "alu", "arithmetic logic unit", "control unit", "fetch-decode-execute", "cache", "ram", "rom", "volatile", "non-volatile", "secondary storage", "hard disk drive", "solid state drive", "optical storage", "input device", "output device", "embedded system"],
        "Processor_fundamentals": ["von neumann", "harvard architecture", "buses", "address bus", "data bus", "control bus", "assembly language", "machine code", "instruction set", "addressing mode", "interrupt", "polling"],
        "System_software": ["operating system", "utility software", "compiler", "interpreter", "assembler", "library", "device driver", "memory management", "file management", "process scheduling", "virtual memory"],
        "Security_privacy_and_data_integrity": ["encryption", "decryption", "symmetric encryption", "asymmetric encryption", "public key", "private key", "firewall", "malware", "virus", "worm", "trojan", "spyware", "phishing", "authentication", "password", "biometric", "data integrity", "validation", "verification", "denial of service", "ddos"],
        "Databases": ["database", "relational database", "table", "field", "record", "primary key", "foreign key", "entity relationship diagram", "normalisation", "first normal form", "second normal form", "third normal form", "sql", "query", "select", "index"],
        "Algorithm_design_and_problem_solving": ["algorithm", "pseudocode", "flowchart", "sequence", "selection", "iteration", "recursion", "linear search", "binary search", "bubble sort", "insertion sort", "merge sort", "quick sort", "stack", "queue", "linked list", "tree", "binary tree", "graph", "abstract data type", "big-o notation", "time complexity", "space complexity"],
        "Data_types_and_structures": ["data type", "integer", "real", "float", "boolean", "character", "string", "array", "record", "set", "pointer", "composite data type", "enumeration", "file handling"],
        "Programming": ["programming", "variable", "constant", "assignment", "sequence", "selection", "iteration", "for loop", "while loop", "repeat until", "procedure", "function", "parameter", "argument", "global variable", "local variable", "array", "string manipulation", "modular programming", "structured programming", "object-oriented programming", "class", "object", "inheritance", "polymorphism", "encapsulation", "exception handling", "integrated development environment"],
    },
    "Computer_Science_0478": {
        "Data_representation": ["binary", "denary", "hexadecimal", "two's complement", "binary addition", "binary shift", "ascii", "unicode", "sound sampling", "bitmap image", "pixel", "colour depth", "compression", "lossless", "lossy"],
        "Data_transmission": ["data packet", "packet switching", "serial transmission", "parallel transmission", "usb", "simplex", "half-duplex", "full-duplex", "error checking", "checksum", "parity bit", "encryption", "symmetric", "asymmetric"],
        "Hardware": ["cpu", "register", "alu", "control unit", "fetch-execute cycle", "ram", "rom", "input device", "output device", "sensor", "actuator", "embedded system"],
        "Software": ["system software", "application software", "operating system", "compiler", "interpreter", "assembler", "high-level language", "low-level language", "utility software"],
        "Internet": ["internet", "world wide web", "url", "http", "https", "web browser", "html", "css", "cookie", "search engine", "cloud computing"],
        "Boolean_logic": ["logic gate", "and gate", "or gate", "not gate", "nand gate", "nor gate", "xor gate", "truth table", "logic circuit", "boolean expression"],
        "Algorithm_design": ["algorithm", "pseudocode", "flowchart", "linear search", "binary search", "bubble sort", "selection", "iteration", "sequence", "validation check"],
        "Programming": ["variable", "constant", "data type", "integer", "string", "boolean", "array", "selection", "iteration", "loop", "procedure", "function", "modular programming"],
        "Databases": ["database", "table", "field", "record", "primary key", "query", "sql", "data validation", "data verification"],
    },
    "English_Literature_9695": {
        "Poetry": ["sonnet", "ballad", "ode", "elegy", "free verse", "blank verse", "stanza", "couplet", "quatrain", "iambic pentameter", "rhyme scheme", "meter", "metre", "rhythm", "caesura", "enjambment", "alliteration", "assonance", "consonance", "onomatopoeia", "sibilance", "imagery", "metaphor", "simile", "personification", "pathetic fallacy", "symbol", "motif", "refrain", "speaker", "voice"],
        "Prose": ["narrative", "narrator", "first-person narrative", "third-person narrative", "omniscient narrator", "unreliable narrator", "plot", "setting", "characterisation", "protagonist", "antagonist", "dialogue", "foreshadowing", "flashback", "stream of consciousness", "irony", "satire", "allegory", "point of view"],
        "Drama": ["play", "act", "scene", "stage direction", "soliloquy", "monologue", "aside", "dramatic irony", "tragedy", "comedy", "tragic hero", "catharsis", "protagonist", "antagonist", "denouement", "climax", "subplot", "chorus"],
        "Unseen": ["close reading", "analysis", "tone", "mood", "atmosphere", "form", "structure", "language", "diction", "register", "contrast", "juxtaposition", "tension", "ambiguity", "perspective"],
        "Literary_techniques": ["allusion", "hyperbole", "oxymoron", "paradox", "pun", "rhetorical question", "repetition", "anaphora", "antithesis", "emotive language", "sensory language", "colloquialism", "dialect", "idiom"],
        "Themes_and_characterisation": ["theme", "motif", "conflict", "love", "death", "power", "identity", "alienation", "social class", "gender", "morality", "character arc", "character development", "relationship", "setting"],
        "Context_and_comparison": ["context", "historical context", "social context", "cultural context", "literary period", "romanticism", "victorian", "modernism", "postmodernism", "comparison", "contrast", "perspective", "interpretation"],
    },
    "Law_9084": {
        "English_legal_system": ["rule of law", "separation of powers", "parliament", "statute", "statutory interpretation", "literal rule", "golden rule", "mischief rule", "purposive approach", "precedent", "stare decisis", "ratio decidendi", "obiter dicta", "hierarchy of courts", "supreme court", "court of appeal", "high court", "magistrates' court", "crown court", "judicial review", "delegated legislation", "civil law", "criminal law", "burden of proof", "standard of proof", "beyond reasonable doubt", "balance of probabilities"],
        "Criminal_law": ["actus reus", "mens rea", "intention", "recklessness", "negligence", "strict liability", "murder", "manslaughter", "voluntary manslaughter", "involuntary manslaughter", "theft", "robbery", "burglary", "assault", "battery", "grievous bodily harm", "attempt", "conspiracy", "self-defence", "duress", "necessity", "insanity", "diminished responsibility", "loss of control"],
        "Law_of_tort": ["tort", "negligence", "duty of care", "breach of duty", "causation", "remoteness of damage", "neighbour principle", "nuisance", "private nuisance", "public nuisance", "occupiers' liability", "vicarious liability", "defamation", "trespass", "damages", "injunction", "compensation"],
        "Contract_law": ["contract", "offer", "acceptance", "consideration", "intention to create legal relations", "invitation to treat", "counter-offer", "breach of contract", "misrepresentation", "duress", "undue influence", "frustration", "damages", "specific performance", "privity of contract", "exclusion clause", "term", "condition", "warranty"],
        "Human_rights_law": ["human rights", "european convention on human rights", "human rights act", "right to life", "freedom of expression", "right to privacy", "right to a fair trial", "freedom of religion", "discrimination", "equality"],
        "The_nature_of_law": ["justice", "morality", "legal positivism", "natural law", "utilitarianism", "the rule of law", "law and morality", "the nature of law"],
    },
    "Accounting_9706": {
        "Introduction_to_accounting": ["accounting", "bookkeeping", "double entry", "debit", "credit", "ledger", "journal", "trial balance", "accounting equation", "assets", "liabilities", "capital", "revenue", "expenses", "financial statement", "income statement", "statement of financial position", "accrual", "prepayment"],
        "Recording_transactions": ["sales journal", "purchases journal", "cash book", "petty cash", "bank reconciliation", "control account", "sales ledger", "purchase ledger", "trade receivable", "trade payable", "discount allowed", "discount received", "returns inwards", "returns outwards"],
        "Financial_statements": ["income statement", "statement of financial position", "gross profit", "net profit", "cost of goods sold", "closing stock", "opening stock", "depreciation", "straight line method", "reducing balance method", "bad debt", "provision for doubtful debts", "accrual", "prepayment", "capital expenditure", "revenue expenditure"],
        "Partnership_accounts": ["partnership", "partnership agreement", "appropriation account", "current account", "capital account", "goodwill", "admission of partner", "retirement of partner", "dissolution of partnership", "profit sharing ratio"],
        "Company_accounts": ["limited company", "share capital", "ordinary share", "preference share", "debenture", "reserves", "retained earnings", "dividend", "statement of changes in equity", "published accounts", "bonus issue", "rights issue"],
        "Cost_and_management_accounting": ["cost accounting", "direct cost", "indirect cost", "fixed cost", "variable cost", "semi-variable cost", "marginal cost", "contribution", "break-even point", "margin of safety", "absorption costing", "marginal costing", "budget", "budgetary control", "variance", "standard costing", "overhead absorption rate"],
        "Ratio_analysis": ["gross profit margin", "net profit margin", "return on capital employed", "current ratio", "acid test ratio", "quick ratio", "inventory turnover", "stock turnover", "trade receivable days", "trade payable days", "gearing ratio", "earnings per share", "dividend yield", "price earnings ratio", "liquidity", "profitability", "efficiency"],
    },
    "Accounting_0452": {
        "Bookkeeping": ["double entry", "debit", "credit", "ledger", "journal", "trial balance", "cash book", "petty cash", "bank reconciliation", "accounting equation", "assets", "liabilities", "capital"],
        "Financial_statements": ["income statement", "statement of financial position", "gross profit", "net profit", "cost of goods sold", "depreciation", "straight line", "reducing balance", "bad debt", "accrual", "prepayment"],
        "Analysis": ["ratio analysis", "gross profit margin", "net profit margin", "return on capital employed", "current ratio", "acid test ratio", "inventory turnover"],
    },
    "Environmental_Management_0680": {
        "Rocks_and_minerals": ["rock cycle", "igneous rock", "sedimentary rock", "metamorphic rock", "weathering", "erosion", "mineral extraction", "quarrying", "open-pit mining", "subsidence"],
        "Energy_and_the_environment": ["fossil fuel", "coal", "oil", "natural gas", "renewable energy", "solar energy", "wind energy", "hydroelectric power", "geothermal energy", "biomass", "nuclear energy", "non-renewable", "carbon emission", "greenhouse gas", "energy demand", "fuelwood"],
        "Agriculture_and_the_environment": ["farming", "arable farming", "pastoral farming", "monoculture", "crop rotation", "irrigation", "fertiliser", "pesticide", "herbicide", "soil erosion", "soil degradation", "salination", "organic farming", "intensive farming", "food security", "genetically modified crop"],
        "Water_and_its_management": ["water cycle", "surface water", "groundwater", "aquifer", "water supply", "water shortage", "drought", "reservoir", "dam", "desalination", "irrigation", "water pollution", "eutrophication", "sewage treatment", "flood management"],
        "Oceans_and_fisheries": ["ocean", "marine ecosystem", "fishing", "overfishing", "aquaculture", "fish farming", "coral reef", "mangrove", "pollution", "oil spill", "el nino", "la nina"],
        "Managing_natural_hazards": ["natural hazard", "earthquake", "volcanic eruption", "tropical storm", "cyclone", "hurricane", "drought", "flood", "hazard prediction", "hazard management", "emergency response", "risk reduction"],
        "The_atmosphere_and_human_activities": ["atmosphere", "climate change", "global warming", "greenhouse effect", "carbon dioxide", "methane", "ozone layer", "ozone depletion", "acid rain", "photochemical smog", "air pollution", "carbon footprint"],
        "Human_population": ["population growth", "population density", "birth rate", "death rate", "demographic transition", "overpopulation", "carrying capacity", "migration", "urbanisation"],
        "Natural_ecosystems_and_human_activities": ["ecosystem", "habitat", "biodiversity", "food chain", "food web", "deforestation", "habitat destruction", "conservation", "protected area", "endangered species", "extinction", "succession"],
    "Business_Studies_0450": {
    },
        "Business_activity": ["needs", "wants", "scarcity", "opportunity cost", "specialisation", "division of labour", "added value", "profit", "goods", "services"],
        "Marketing_mix": ["marketing mix", "product", "price", "place", "promotion", "4ps", "target market", "market segment", "brand", "packaging", "advertising", "sales promotion"],
        "Market_research": ["primary research", "secondary research", "questionnaire", "survey", "focus group", "sample", "sampling", "quantitative data", "qualitative data"],
        "Motivating_employees": ["motivation", "maslow", "herzberg", "taylor", "financial reward", "non-financial reward", "wage", "salary", "commission", "bonus", "fringe benefit", "job rotation", "job enrichment", "job enlargement"],
        "Organisation_and_management": ["organisational structure", "hierarchy", "span of control", "chain of command", "delegation", "centralisation", "decentralisation", "autocratic leadership", "democratic leadership", "laissez-faire"],
        "Recruitment_selection_and_training_of_employees": ["recruitment", "selection", "job description", "person specification", "induction", "on-the-job training", "off-the-job training", "appraisal", "redundancy", "dismissal"],
        "Production_of_goods_and_services": ["job production", "batch production", "flow production", "lean production", "just-in-time", "jit", "quality control", "quality assurance", "kaizen", "productivity", "stock", "inventory"],
        "Costs_scale_of_production_and_breakeven_analysis": ["fixed cost", "variable cost", "total cost", "average cost", "break-even", "break-even point", "margin of safety", "economies of scale", "diseconomies of scale", "contribution"],
        "Business_finance_needs_and_sources": ["sources of finance", "internal finance", "external finance", "retained profit", "share capital", "loan", "overdraft", "trade credit", "leasing", "microfinance", "crowdfunding"],
        "Cash_flow_forecasting_and_working_capital": ["cash flow", "cash flow forecast", "cash inflow", "cash outflow", "working capital", "liquidity", "insolvency"],
        "Income_statements": ["income statement", "revenue", "cost of sales", "gross profit", "net profit", "profit and loss account"],
        "Statement_of_financial_position": ["statement of financial position", "balance sheet", "assets", "liabilities", "equity", "current assets", "non-current assets", "current liabilities", "non-current liabilities"],
        "Analysis_of_accounts": ["ratio analysis", "gross profit margin", "net profit margin", "return on capital employed", "current ratio", "acid test ratio", "profitability", "liquidity ratio"],
        "Economic_issues": ["inflation", "interest rate", "exchange rate", "unemployment", "economic growth", "gdp", "taxation", "government policy"],
        "Environmental_and_ethical_issues": ["sustainability", "environmental impact", "pollution", "recycling", "carbon footprint", "corporate social responsibility", "csr", "ethical business", "fair trade", "global warming"],
        "Business_and_the_international_economy": ["globalisation", "multinational corporation", "import", "export", "exchange rate", "trade barrier", "tariff", "quota", "protectionism", "free trade"],
    },
    "Economics_0455": {
        "The_nature_of_the_economic_problem": ["scarcity", "unlimited wants", "limited resources", "economic problem", "choice", "opportunity cost"],
        "The_factors_of_production": ["land", "labour", "capital", "enterprise", "factors of production", "mobility of factors", "reward to factors", "rent", "wages", "interest", "profit"],
        "Demand": ["demand", "demand curve", "effective demand", "law of demand", "extension of demand", "contraction of demand", "shift in demand", "movement along demand curve", "determinants of demand", "income", "substitute", "complement"],
        "Supply": ["supply", "supply curve", "law of supply", "shift in supply", "determinants of supply", "cost of production", "technology", "tax", "subsidy"],
        "Price_determination": ["equilibrium price", "market equilibrium", "excess demand", "excess supply", "disequilibrium", "market clearing price"],
        "Price_elasticity_of_demand": ["price elasticity of demand", "ped", "elastic demand", "inelastic demand", "perfectly elastic", "perfectly inelastic", "unit elasticity", "total revenue"],
        "Price_elasticity_of_supply": ["price elasticity of supply", "pes", "elastic supply", "inelastic supply"],
        "Market_failure": ["market failure", "externality", "public good", "merit good", "demerit good", "monopoly", "monopoly power", "government intervention", "regulation", "taxation", "subsidy", "price control"],
        "Money_and_banking": ["money", "functions of money", "barter", "central bank", "commercial bank", "bank deposit", "interest rate", "liquidity", "credit"],
        "Trade_unions": ["trade union", "collective bargaining", "strike", "industrial action", "minimum wage", "worker representation"],
        "Firms_costs_revenue_and_objectives": ["fixed cost", "variable cost", "total cost", "average cost", "marginal cost", "revenue", "profit maximisation", "sales maximisation", "economies of scale", "diseconomies of scale"],
        "Market_structure": ["perfect competition", "monopoly", "oligopoly", "monopolistic competition", "barriers to entry", "market share", "price maker", "price taker"],
        "Fiscal_policy": ["fiscal policy", "taxation", "government spending", "budget", "budget deficit", "budget surplus", "direct tax", "indirect tax"],
        "Monetary_policy": ["monetary policy", "interest rate", "money supply", "central bank", "inflation targeting"],
        "Supplyside_policy": ["supply-side policy", "privatisation", "deregulation", "education and training", "labour market flexibility", "tax cuts"],
        "Economic_growth": ["economic growth", "gdp", "real gdp", "recession", "boom", "business cycle", "recovery"],
        "Employment_and_unemployment": ["unemployment", "frictional unemployment", "structural unemployment", "cyclical unemployment", "seasonal unemployment", "full employment", "employment rate"],
        "Inflation": ["inflation", "deflation", "consumer price index", "cpi", "cost-push inflation", "demand-pull inflation", "hyperinflation"],
        "Poverty": ["poverty", "absolute poverty", "relative poverty", "income inequality", "wealth inequality", "standard of living"],
        "Specialisation_and_free_trade": ["specialisation", "international trade", "comparative advantage", "free trade", "trade"],
        "Globalisation_and_trade_restrictions": ["globalisation", "multinational corporation", "tariff", "quota", "embargo", "subsidy", "protectionism", "world trade organisation", "wto"],
        "Foreign_exchange_rates": ["exchange rate", "appreciation", "depreciation", "devaluation", "revaluation", "floating exchange rate", "fixed exchange rate", "foreign exchange market"],
        "Current_account_of_the_balance_of_payments": ["balance of payments", "current account", "trade in goods", "trade in services", "trade deficit", "trade surplus", "visible trade", "invisible trade"],
    },
    "ICT_0417": {
        "Hardware_components": ["cpu", "processor", "motherboard", "ram", "rom", "hardware", "internal hardware", "external hardware"],
        "Input_devices_and_their_uses": ["keyboard", "mouse", "scanner", "microphone", "webcam", "touch screen", "barcode reader", "qr code", "optical mark reader", "omr", "magnetic ink character recognition", "micr", "sensor"],
        "Output_devices_and_their_uses": ["monitor", "printer", "laser printer", "inkjet printer", "speaker", "projector", "plotter", "actuator"],
        "Types_of_storage": ["hard disk drive", "solid state drive", "optical disc", "cd", "dvd", "blu-ray", "usb flash drive", "memory card", "cloud storage", "magnetic tape"],
        "Network_types": ["lan", "wan", "wlan", "network", "topology", "star topology", "bus topology", "mesh topology"],
        "Network_hardware": ["router", "switch", "hub", "modem", "network interface card", "nic", "access point", "bridge", "gateway"],
        "Internet_and_intranet": ["internet", "intranet", "world wide web", "url", "http", "https", "ip address", "dns", "browser", "isp"],
        "Esafety": ["e-safety", "online safety", "cyberbullying", "phishing", "identity theft", "malware", "virus", "spyware", "spam", "firewall", "digital footprint"],
        "Spreadsheets": ["spreadsheet", "cell", "row", "column", "formula", "function", "chart", "graph", "absolute reference", "relative reference", "macro", "data validation", "pivot table"],
        "Databases": ["database", "table", "field", "record", "primary key", "query", "form", "report", "relational database", "flat file"],
        "Website_authoring": ["website", "web page", "html", "css", "hyperlink", "navigation", "web design", "homepage", "cascading style sheet"],
        "Document_production": ["word processing", "document", "mail merge", "template", "header", "footer", "table of contents", "spell check"],
        "Presentations": ["presentation", "slide", "transition", "animation", "master slide", "speaker notes"],
        "Graphics_and_images": ["bitmap", "vector graphic", "pixel", "resolution", "image editing", "jpeg", "png", "gif"],
    },
    "Media_Studies_9607": {
        "Media_language_and_representation": ["mise-en-scene", "camera angle", "shot type", "editing", "sound", "representation", "stereotype", "connotation", "denotation", "semiotics", "sign", "signifier", "signified", "genre", "narrative", "binary opposition"],
        "Media_industries_and_audiences": ["media industry", "production", "distribution", "exhibition", "regulation", "audience", "target audience", "audience theory", "uses and gratifications", "hypodermic needle", "active audience", "passive audience", "media ownership", "conglomerate", "public service broadcasting"],
        "Media_contexts": ["social context", "cultural context", "historical context", "political context", "economic context", "ideology", "hegemony", "dominant ideology"],
        "Film_fiction": ["film", "genre", "narrative structure", "cinematography", "editing", "sound design", "mise-en-scene", "auteur", "star system", "franchise"],
        "Documentary": ["documentary", "observational documentary", "expository documentary", "participatory documentary", "reflexive documentary", "mockumentary", "actuality footage", "voice-over"],
        "Broadcasting_and_digital_media": ["broadcasting", "television", "radio", "streaming", "digital media", "social media", "convergence", "platform", "on-demand", "web series"],
    },
    "Thinking_Skills_9694": {
        "Problem_solving": ["problem solving", "algorithm", "heuristic", "deduction", "induction", "spatial reasoning", "logical puzzle", "pattern recognition", "data sufficiency"],
        "Critical_thinking": ["critical thinking", "argument", "premise", "conclusion", "assumption", "fallacy", "ad hominem", "straw man", "false dichotomy", "begging the question", "credibility", "evidence", "claim", "counter-argument"],
        "Applied_reasoning": ["applied reasoning", "analogy", "relevance", "sufficiency", "necessary condition", "sufficient condition", "inference", "validity", "soundness"],
        "Argument_analysis": ["argument analysis", "structure of argument", "intermediate conclusion", "main conclusion", "flaw", "weakening", "strengthening", "evaluation of argument"],
        "Decision_making": ["decision making", "cost-benefit analysis", "risk assessment", "criteria", "trade-off", "alternative", "recommendation"],
    },
    "Physical_Education_9396": {
        "Applied_anatomy_and_physiology": ["skeletal system", "bone", "joint", "synovial joint", "muscle", "skeletal muscle", "cardiac muscle", "smooth muscle", "respiratory system", "alveoli", "cardiovascular system", "heart", "cardiac output", "stroke volume", "aerobic", "anaerobic", "energy system", "atp", "lactic acid"],
        "Exercise_physiology": ["exercise", "training", "aerobic capacity", "vo2 max", "recovery", "overtraining", "periodisation", "warm up", "cool down", "principles of training", "specificity", "progression", "overload", "reversibility"],
        "Biomechanics": ["biomechanics", "force", "motion", "linear motion", "angular motion", "projectile", "levers", "first class lever", "second class lever", "third class lever", "newton's laws", "centre of mass", "balance", "stability", "friction"],
        "Skill_acquisition": ["skill", "motor skill", "open skill", "closed skill", "gross motor skill", "fine motor skill", "learning", "feedback", "intrinsic feedback", "extrinsic feedback", "knowledge of results", "knowledge of performance", "practice", "whole practice", "part practice", "guidance", "visual guidance", "verbal guidance"],
        "Sports_psychology": ["sports psychology", "motivation", "intrinsic motivation", "extrinsic motivation", "arousal", "anxiety", "aggression", "personality", "attitude", "goal setting", "imagery", "self-efficacy", "confidence", "stress management"],
        "Sport_and_society": ["sport", "society", "socialisation", "deviance in sport", "drugs in sport", "doping", "commercialisation", "sponsorship", "media and sport", "globalisation of sport", "ethics", "amateur", "professional", "olympics"],
    },
    "English_Language_9093": {
        "Language_and_the_individual": ["idiolect", "sociolect", "dialect", "accent", "register", "idiolect", "personal language", "language and identity", "self-representation"],
        "Language_and_society": ["standard english", "non-standard english", "received pronunciation", "rp", "social variation", "regional variation", "occupational language", "jargon", "slang", "code switching", "language and social class", "language and gender", "language and ethnicity"],
        "Language_change": ["language change", "etymology", "semantic change", "broadening", "narrowing", "amelioration", "pejoration", "neologism", "archaism", "prescriptivism", "descriptivism", "great vowel shift"],
        "Child_language_acquisition": ["child language acquisition", "babbling", "holophrastic stage", "two-word stage", "telegraphic speech", "overextension", "underextension", "virtuous errors", "child-directed speech", "chomsky", "innateness", "language acquisition device"],
        "Spoken_language_and_social_groups": ["spoken language", "conversation", "turn-taking", "adjacency pair", "hedge", "filler", "tag question", "overlap", "interruption", "politeness", "face theory", "pragmatics"],
        "English_as_a_global_language": ["global english", "lingua franca", "world englishes", "pidgin", "creole", "kachru's circles", "language imperialism"],
        "Language_and_identity": ["language and identity", "gender identity", "ethnic identity", "national identity", "youth language", "multicultural london english"],
    },
    "English_First_Language_0500": {
        "Reading_comprehension": ["comprehension", "inference", "explicit meaning", "implicit meaning", "main idea", "supporting detail", "tone", "purpose", "audience"],
        "Summary_writing": ["summary", "paraphrase", "condense", "key points", "selecting information"],
        "Writers_effects_and_language_analysis": ["writer's effect", "language analysis", "imagery", "metaphor", "simile", "personification", "alliteration", "onomatopoeia", "diction", "word choice", "sentence structure", "emotive language"],
        "Directed_writing": ["directed writing", "letter", "report", "article", "speech", "formal writing", "informal writing", "audience", "purpose", "register"],
        "Descriptive_writing": ["descriptive writing", "description", "sensory detail", "imagery", "setting", "atmosphere", "mood", "figurative language"],
        "Narrative_writing": ["narrative writing", "plot", "character", "setting", "dialogue", "point of view", "first person", "third person", "climax", "resolution"],
        "Argumentative_and_discursive_writing": ["argumentative writing", "discursive writing", "argument", "counter-argument", "persuasion", "opinion", "rhetorical question", "evidence", "conclusion"],
    },
    "Literature_in_English_0475": {
        "Poetry_analysis": ["poem", "poet", "stanza", "verse", "rhyme", "rhythm", "meter", "metre", "line", "quatrain", "couplet", "sonnet", "ballad", "free verse", "blank verse"],
        "Poetic_devices": ["metaphor", "simile", "personification", "alliteration", "assonance", "consonance", "onomatopoeia", "imagery", "symbol", "enjambment", "caesura", "sibilance", "hyperbole", "oxymoron", "irony"],
        "Narrative_voice": ["narrator", "first-person narrator", "third-person narrator", "omniscient", "point of view", "unreliable narrator", "voice", "tone"],
        "Characterisation_prose": ["character", "protagonist", "antagonist", "character development", "characterisation", "dialogue", "motivation", "relationship"],
        "Dramatic_techniques": ["drama", "play", "act", "scene", "stage direction", "soliloquy", "monologue", "aside", "dramatic irony", "tragedy", "comedy"],
        "Literary_devices": ["foreshadowing", "flashback", "motif", "theme", "symbolism", "allegory", "satire", "allusion", "juxtaposition", "contrast"],
        "Language_and_imagery": ["imagery", "figurative language", "literal language", "diction", "word choice", "sensory imagery", "simile", "metaphor", "personification"],
        "Structure_and_form": ["structure", "form", "narrative structure", "chronological", "non-linear", "plot", "climax", "resolution", "denouement"],
        "Themes_exploration": ["theme", "love", "death", "power", "identity", "conflict", "morality", "social class", "gender", "nature"],
        "Historical_context": ["context", "historical context", "social context", "cultural context", "victorian", "romanticism", "modernism", "colonialism", "war literature"],
        "Comparison_of_texts": ["comparison", "compare", "contrast", "similarity", "difference", "cross-text", "interpretation"],
    },
}


def _build_variants(kw: str, generic: set = None) -> set:
    return _expand_spelling(kw, generic)


_STOP = {
    "and", "or", "the", "of", "a", "an", "in", "on", "with", "for", "to",
    "as", "at", "by", "is", "are", "its", "their", "into", "between",
    "from", "across", "that", "this", "these", "those", "level", "using",
    "use", "used", "between", "through", "under", "over", "during",
}


def _ngrams(kw: str) -> set:
    """Contiguous bigram/trigram sub-phrases of a multi-word keyword, after
    dropping stopwords.  Only high-precision fragments are returned (the exact
    phrase plus its meaningful adjacent-word sub-phrases)."""
    toks = [t for t in re.split(r"[ _-]+", kw.lower()) if t and t not in _STOP]
    if len(toks) < 3:
        return set()
    out = set()
    for n in (2, 3):
        for i in range(len(toks) - n + 1):
            out.add(" ".join(toks[i:i + n]))
    return out


def expand_config(config_path: Path) -> bool:
    data = json.loads(config_path.read_text(encoding="utf-8"))
    subject = data.get("subject", "")
    code = str(data.get("syllabus_code", ""))
    keywords = data.get("classification_keywords", {})
    if keywords is None:
        keywords = {}
    changed = False

    # 1. Merge named entities FIRST (per-entity, token-overlap routing), so
    #    they also receive the n-gram + spelling expansion below.
    ent = NAMED_ENTITIES.get(subject)
    if ent:
        def _tokens(s):
            return set(re.findall(r"[a-z0-9]+", s.lower()))

        topic_tokens = {t: set() for t in keywords}
        for t, kws in keywords.items():
            toks = set()
            for kw in kws:
                toks |= _tokens(kw)
            topic_tokens[t] = toks

        for topic_name, entities in ent.items():
            for e in entities:
                e = e.lower().strip()
                if not e:
                    continue
                et = _tokens(e)
                best, best_score = None, 0
                for t, toks in topic_tokens.items():
                    score = len(et & toks)
                    if score > best_score:
                        best_score, best = score, t
                if best is None:
                    continue  # no overlap -> skip (never pollute)
                if e not in keywords[best]:
                    keywords[best] = keywords[best] + [e]
                    topic_tokens[best] |= et
                    changed = True

    # 2. spelling/morphological variants + n-gram sub-phrases (applies to the
    #    original keywords AND the merged named entities).  Pluralisation is
    #    skipped for cross-topic generic terms (see _expand_spelling).
    #    Compute the generic set: single-word keywords in >= 3 topics.
    all_single = {}
    for topic, kws in keywords.items():
        for kw in kws:
            if " " not in kw and "-" not in kw:
                all_single[kw] = all_single.get(kw, 0) + 1
    generic = {kw for kw, n in all_single.items() if n >= 3}

    new_kw = {}
    for topic, kws in keywords.items():
        cur = set(kws)
        expanded = set(kws)
        for kw in kws:
            expanded |= _build_variants(kw, generic)
            expanded |= _ngrams(kw)
        if expanded != cur:
            changed = True
        new_kw[topic] = sorted(expanded)

    if changed:
        data["classification_keywords"] = new_kw
        config_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return changed


def main() -> int:
    changed = 0
    total = 0
    for config_path in sorted(SUBJECTS_ROOT.rglob("config.json")):
        total += 1
        try:
            if expand_config(config_path):
                changed += 1
        except Exception as e:
            print(f"[vocab] ERROR {config_path}: {e}")
    # report totals
    all_kw = 0
    for config_path in sorted(SUBJECTS_ROOT.rglob("config.json")):
        d = json.loads(config_path.read_text(encoding="utf-8"))
        all_kw += sum(len(v) for v in d.get("classification_keywords", {}).values())
    print(f"[vocab] changed {changed}/{total} configs; TOTAL keywords = {all_kw}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
