#!/usr/bin/env python3
"""tools/buff_categorization.py — extensive categorization buff from the
OFFICIAL Cambridge A-Level & IGCSE syllabus topic taxonomy.

The active classifier consumes `subjects/*/*/config.json` classification
keywords.  This tool enriches those keywords using the official syllabus
topic identifiers themselves (every `detailed_topics` / `major_topics` name
IS the Cambridge syllabus topic name — the authoritative source).  For each
topic it derives high-signal matching phrases:

  - the full official topic name (underscores -> spaces)
  - each significant single-word segment (>= 4 chars, stopwords dropped)
  - adjacent pairs of segments (natural sub-phrases)
  - the mapped MAJOR topic name (underscores -> spaces), so questions phrased
    at major-topic level still route correctly.

NOTE (2026-08-15): the `topics/*/*_topics.json` shadow keyword lists are
deliberately NOT merged — they predate the catch-all-keyword purge and would
re-introduce weak generic terms ("water", "enzyme", "protein", ...) that the
CATEGORIZATION_UPGRADE round removed.  The official topic NAMES are the
high-precision source of truth.

Idempotent: existing keywords are never removed; new keywords are de-duplicated
and the file is rewritten only when something actually changes.
"""
import json
import re
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
SUBJECTS_ROOT = PROJ / "subjects"

_STOPWORDS = {
    "and", "or", "the", "of", "a", "an", "in", "on", "with", "for", "to",
    "as", "at", "by", "is", "are", "its", "their", "into", "between",
    "from", "across", "that", "this", "these", "those", "level",
}


def _name_phrases(name: str) -> set:
    """Derive matching phrases from an official topic identifier."""
    segs = [s for s in name.strip("_").split("_") if s]
    out = set()
    if segs:
        out.add(" ".join(segs).lower())
    for s in segs:
        ls = s.lower()
        if ls not in _STOPWORDS and len(ls) >= 4:
            out.add(ls)
    clean = [s.lower() for s in segs if s.lower() not in _STOPWORDS]
    for i in range(len(clean) - 1):
        out.add(f"{clean[i]} {clean[i + 1]}")
    return out


def buff_one(config_path: Path) -> bool:
    data = json.loads(config_path.read_text(encoding="utf-8"))
    detailed = data.get("detailed_topics", [])
    mapping = data.get("mapping", {})
    keywords = data.get("classification_keywords", {})
    if keywords is None:
        keywords = {}

    changed = False
    for dt in detailed:
        cur = set(keywords.get(dt, []))
        for ph in _name_phrases(dt):
            if ph and ph not in cur:
                cur.add(ph)
        maj = mapping.get(dt)
        if maj:
            for ph in _name_phrases(maj):
                if ph and ph not in cur:
                    cur.add(ph)
        new = sorted(cur)
        if new != keywords.get(dt):
            keywords[dt] = new
            changed = True

    if changed:
        data["classification_keywords"] = keywords
        config_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    return changed


def main() -> int:
    changed = 0
    total = 0
    for config_path in sorted(SUBJECTS_ROOT.rglob("config.json")):
        total += 1
        try:
            if buff_one(config_path):
                changed += 1
                print(f"[buff] {config_path.relative_to(SUBJECTS_ROOT)} enriched")
        except Exception as e:
            print(f"[buff] ERROR {config_path}: {e}")
    print(f"[buff] done: {changed}/{total} configs enriched")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

