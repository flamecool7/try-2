#!/usr/bin/env python3
"""quarantine_reviewed_crops.py — RS-13 review-workflow tool (OPT-IN, never in-pipeline).

Moves question folders whose crops the locked QC flagged during a run into a
`_Review/` area, driven by the run log's own per-question verdict lines — an
EXACT signal (no OCR heuristics). Default mode restricts to
REFERENCE_MATERIAL_CONTAMINATION (e.g. RS-12's rescued-page Q40 case: locked
splitter crops last-question-to-page-bottom, trailing back-matter included).

Usage:
  python3 tools/quarantine_reviewed_crops.py --output OUT --log RUN.log            # dry-run report
  python3 tools/quarantine_reviewed_crops.py --output OUT --log RUN.log --apply    # move
  ...  --all-review        # quarantine every QC needs_review verdict, not only contamination

Exit codes: 0 ok (or dry-run done), 2 = no review verdicts parsed from the log.
Idempotent: already-quarantined or already-moved folders are skipped.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

VERDICT_RE = re.compile(r"^\s*(?:\[low-ram\]\s*)?Q(\d+): .*?QC:?\s*review: (.+?)\s*$")
DEFAULT_REASON = "REFERENCE_MATERIAL_CONTAMINATION"


def parse_review_verdicts(log_path: Path) -> dict:
    """question number(int) -> reason, from pipeline QC verdict lines."""
    out = {}
    for line in Path(log_path).read_text(encoding="utf-8", errors="replace").splitlines():
        m = VERDICT_RE.match(line)
        if m:
            out[int(m.group(1))] = m.group(2).strip()
    return out


def find_question_folders(output_root: Path) -> dict:
    """question number(int) -> absolute folder paths (excludes _Review areas)."""
    found = {}
    for d in Path(output_root).rglob("*"):
        if not d.is_dir() or "_Review" in d.parts:
            continue
        m = re.search(r"_Q(\d+)$", d.name)
        if m:
            found.setdefault(int(m.group(1)), []).append(d)
    return found


def quarantine(output_root: Path, verdicts: dict, reason_filter=None,
               apply: bool = False, dest_name: str = "_Review") -> list:
    """Returns plan rows: (qno, reason, src, dst, acted[bool], note)."""
    folders = find_question_folders(output_root)
    dest_root = Path(output_root) / dest_name
    plan = []
    for qno, reason in sorted(verdicts.items()):
        if reason_filter and not any(reason.startswith(rf) for rf in reason_filter):
            continue
        targets = folders.get(qno)
        if not targets:
            plan.append((qno, reason, None, None, False, "no folder on disk"))
            continue
        for src in targets:
            rel = src.relative_to(output_root)
            safe_reason = re.sub(r"[^A-Za-z0-9_]+", "_", reason.split(":")[0]).strip("_")
            dst = dest_root / safe_reason / rel
            if dst.exists():
                plan.append((qno, reason, src, dst, False, "already quarantined"))
                continue
            if apply:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dst))
            plan.append((qno, reason, src, dst, apply, "moved" if apply else "dry-run"))
    return plan


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--output", required=True, help="pipeline output tree")
    ap.add_argument("--log", required=True, help="run log with QC verdict lines")
    ap.add_argument("--apply", action="store_true", help="actually move (default: dry-run)")
    ap.add_argument("--all-review", action="store_true",
                    help="quarantine ALL QC review verdicts, not just contamination")
    ap.add_argument("--dest", default="_Review", help="quarantine area name under --output")
    args = ap.parse_args(argv)

    verdicts = parse_review_verdicts(Path(args.log))
    if not verdicts:
        print(f"[quarantine] no QC review verdicts parsed from {args.log}")
        return 2
    reason_filter = None if args.all_review else (DEFAULT_REASON,)
    plan = quarantine(Path(args.output), verdicts, reason_filter,
                      apply=args.apply, dest_name=args.dest)
    mode = "APPLY" if args.apply else "DRY-RUN"
    print(f"[quarantine:{mode}] verdicts parsed: {len(verdicts)} -> actions: {len(plan)}")
    for qno, reason, src, dst, acted, note in plan:
        print(f"  Q{qno:<3} {note:<18} {reason[:60]}"
              + (f"  {src} -> {dst}" if src else ""))
    if args.apply and plan:
        dest_root = Path(args.output) / args.dest
        dest_root.mkdir(parents=True, exist_ok=True)
        readme = dest_root / "README.md"
        lines = [f"# Quarantined crops — {datetime.now(timezone.utc).isoformat()}\n",
                 f"source log: `{args.log}`\n", "", "| Q | reason | original location |", "|---|---|---|"]
        for qno, reason, src, dst, acted, note in plan:
            if src:
                lines.append(f"| Q{qno} | {reason} | {src} |")
        readme.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"[quarantine] README written: {readme}")
    if not args.apply:
        print("[quarantine] dry-run only — re-run with --apply to move folders")
    return 0


if __name__ == "__main__":
    sys.exit(main())
