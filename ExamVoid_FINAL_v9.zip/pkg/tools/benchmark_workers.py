#!/usr/bin/env python3
"""Benchmark different worker counts on the current machine.

This is meant to be run on the USER'S actual machine, not the low-resource
sandbox. It runs the real batch pipeline multiple times against the same input
folder and records wall time / exit code for each worker count.

Example:
  python tools/benchmark_workers.py \
    --input input \
    --output-root benchmark_runs \
    --workers 3 4 5 10 \
    --performance \
    --fetch-missing-ms
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Iterable, List

REPO = Path(__file__).resolve().parents[1]


def _mem_available_mb() -> int | None:
    try:
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except OSError:
        pass
    return None


def build_command(input_dir: str, output_dir: str, workers: int,
                  performance: bool, fetch_missing_ms: bool) -> List[str]:
    cmd = [
        sys.executable,
        str(REPO / "run_pipeline.py"),
        "--input", input_dir,
        "--output", output_dir,
        "--workers", str(workers),
    ]
    if performance:
        cmd.append("--performance")
    if fetch_missing_ms:
        cmd.append("--fetch-missing-ms")
    return cmd


def benchmark_once(input_dir: Path, output_dir: Path, workers: int,
                   performance: bool, fetch_missing_ms: bool) -> dict:
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = build_command(str(input_dir), str(output_dir), workers, performance, fetch_missing_ms)
    t0 = time.time()
    proc = subprocess.run(cmd, cwd=str(REPO), capture_output=True, text=True)
    wall = time.time() - t0
    return {
        "workers": workers,
        "performance": performance,
        "fetch_missing_ms": fetch_missing_ms,
        "returncode": proc.returncode,
        "wall_seconds": round(wall, 2),
        "stdout_tail": "\n".join(proc.stdout.splitlines()[-25:]),
        "stderr_tail": "\n".join(proc.stderr.splitlines()[-25:]),
        "output_dir": str(output_dir),
    }


def write_reports(results: list[dict], out_root: Path) -> tuple[Path, Path]:
    json_path = out_root / "benchmark_results.json"
    csv_path = out_root / "benchmark_results.csv"
    json_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=[
            "workers", "performance", "fetch_missing_ms",
            "returncode", "wall_seconds", "output_dir",
        ])
        writer.writeheader()
        for row in results:
            writer.writerow({k: row[k] for k in writer.fieldnames})
    return json_path, csv_path


def main(argv: Iterable[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output-root", required=True)
    ap.add_argument("--workers", nargs="+", type=int, default=[3, 4, 5, 10])
    ap.add_argument("--performance", action="store_true")
    ap.add_argument("--fetch-missing-ms", action="store_true")
    args = ap.parse_args(list(argv) if argv is not None else None)

    input_dir = Path(args.input)
    out_root = Path(args.output_root)
    out_root.mkdir(parents=True, exist_ok=True)

    print("[benchmark] host snapshot")
    print(f"[benchmark] cpu_count={os.cpu_count()} mem_available_mb={_mem_available_mb()}")
    print(f"[benchmark] worker matrix={args.workers}")

    results = []
    for workers in args.workers:
        run_dir = out_root / f"workers_{workers}"
        print(f"\n[benchmark] running workers={workers} -> {run_dir}")
        result = benchmark_once(input_dir, run_dir, workers, args.performance, args.fetch_missing_ms)
        results.append(result)
        print(f"[benchmark] rc={result['returncode']} wall={result['wall_seconds']}s")

    json_path, csv_path = write_reports(results, out_root)
    print(f"\n[benchmark] wrote {json_path}")
    print(f"[benchmark] wrote {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
