#!/usr/bin/env python3
"""Fixture downloader + manifest for the confidence-gated cropping round.

Honesty rule (Overseer spec): every fixture is a REAL public Cambridge PDF
with a recorded source URL and a recorded SHA-256. The first successful
download PINS the hash into this file's EMBEDDED_MANIFEST_BOOTSTRAP copy on
disk (fixture_manifest.json); every later run VERIFIES against the pinned
hash and exits nonzero on any mismatch or missing mandatory fixture.

Fixture PDFs live OUTSIDE the shipped project tree
(<repo>/../test-crops/fixtures/) so the deliverable zip never swells; the
manifest JSON itself stays in the repo as the provenance record.

Usage:
    python3 tools/download_fixtures.py --download   # fetch + verify
    python3 tools/download_fixtures.py --verify     # verify only
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = REPO_ROOT / "tools" / "fixture_manifest.json"
FIXTURE_ROOT = REPO_ROOT.parent / "test-crops" / "fixtures"
UPLOADS = REPO_ROOT.parent / "uploads"

DP = "https://dynamicpapers.com/wp-content/uploads/2015/09"
BEH = "https://bestexamhelp.com/exam/cambridge-international-a-level/computer-science-9618"
BEH_IG = "https://bestexamhelp.com/exam/cambridge-igcse"  # RS-16: genuine %PDF bytes probed

# (url, name, roles) — every entry probed HTTP-200. honesty note: papacambridge
# (first-choice source) serves an HTML interstitial to non-browser clients —
# caught by the %PDF magic check in fetch(). Sources below are the two mirrors
# verified to serve genuine PDF bytes. 9701/0620/9709/0580/9700 sets are
# 2015/2016 Cambridge-authored papers (Cambridge layout grammar is stable);
# 9618 is 2023-era. Ages are recorded here and disclosed in proof_report's
# limitations section.
FIXTURES = [
    # A-Level Chemistry 9701: MCQ P1 (grid MS) + structured P2/P4 + ER
    (f"{DP}/9701_s15_qp_12.pdf", "9701_s15_qp_12.pdf", ["alevel", "mcq_qp"]),
    (f"{DP}/9701_s15_ms_12.pdf", "9701_s15_ms_12.pdf", ["alevel", "mcq_ms"]),
    (f"{DP}/9701_s15_qp_22.pdf", "9701_s15_qp_22.pdf", ["alevel", "structured_qp", "multipage"]),
    (f"{DP}/9701_s15_ms_22.pdf", "9701_s15_ms_22.pdf", ["alevel", "structured_ms"]),
    (f"{DP}/9701_s15_qp_42.pdf", "9701_s15_qp_42.pdf", ["alevel", "structured_qp", "multipage"]),
    (f"{DP}/9701_s15_ms_42.pdf", "9701_s15_ms_42.pdf", ["alevel", "structured_ms"]),
    (f"{DP}/9701_s15_er.pdf",    "9701_s15_er.pdf",    ["alevel", "er", "er_variantless_name"]),
    # IGCSE Chemistry 0620 (2016): TWO MCQ variants (core+extended) + theory P4
    (f"{DP}/0620_s16_qp_21.pdf", "0620_s16_qp_21.pdf", ["igcse", "mcq_qp"]),
    (f"{DP}/0620_s16_ms_21.pdf", "0620_s16_ms_21.pdf", ["igcse", "mcq_ms"]),
    (f"{DP}/0620_s16_qp_22.pdf", "0620_s16_qp_22.pdf", ["igcse", "mcq_qp"]),
    (f"{DP}/0620_s16_ms_22.pdf", "0620_s16_ms_22.pdf", ["igcse", "mcq_ms"]),
    (f"{DP}/0620_s16_qp_42.pdf", "0620_s16_qp_42.pdf", ["igcse", "structured_qp"]),
    (f"{DP}/0620_s16_ms_42.pdf", "0620_s16_ms_42.pdf", ["igcse", "structured_ms"]),
    (f"{DP}/0620_s15_er.pdf",    "0620_s15_er.pdf",    ["igcse", "er", "er_variantless_name"]),
    # IGCSE Biology 0610 (RS-16): s15 MCQ pair + full coherent s16 set (MCQ 22 + theory 42 + ER)
    (f"{BEH_IG}/biology-0610/2015/0610_s15_qp_22.pdf", "0610_s15_qp_22.pdf", ["igcse", "bio", "mcq_qp"]),
    (f"{BEH_IG}/biology-0610/2015/0610_s15_ms_22.pdf", "0610_s15_ms_22.pdf", ["igcse", "bio", "mcq_ms"]),
    (f"{BEH_IG}/biology-0610/2016/0610_s16_qp_22.pdf", "0610_s16_qp_22.pdf", ["igcse", "bio", "mcq_qp"]),
    (f"{BEH_IG}/biology-0610/2016/0610_s16_ms_22.pdf", "0610_s16_ms_22.pdf", ["igcse", "bio", "mcq_ms"]),
    (f"{BEH_IG}/biology-0610/2016/0610_s16_qp_42.pdf", "0610_s16_qp_42.pdf", ["igcse", "bio", "structured_qp"]),
    (f"{BEH_IG}/biology-0610/2016/0610_s16_ms_42.pdf", "0610_s16_ms_42.pdf", ["igcse", "bio", "structured_ms"]),
    (f"{BEH_IG}/biology-0610/2016/0610_s16_er.pdf",    "0610_s16_er.pdf",    ["igcse", "bio", "er", "er_variantless_name"]),
    # IGCSE Physics 0625 (RS-16): full coherent s16 set
    (f"{BEH_IG}/physics-0625/2016/0625_s16_qp_22.pdf", "0625_s16_qp_22.pdf", ["igcse", "phys", "mcq_qp"]),
    (f"{BEH_IG}/physics-0625/2016/0625_s16_ms_22.pdf", "0625_s16_ms_22.pdf", ["igcse", "phys", "mcq_ms"]),
    (f"{BEH_IG}/physics-0625/2016/0625_s16_qp_42.pdf", "0625_s16_qp_42.pdf", ["igcse", "phys", "structured_qp"]),
    (f"{BEH_IG}/physics-0625/2016/0625_s16_ms_42.pdf", "0625_s16_ms_42.pdf", ["igcse", "phys", "structured_ms"]),
    (f"{BEH_IG}/physics-0625/2016/0625_s16_er.pdf",    "0625_s16_er.pdf",    ["igcse", "phys", "er", "er_variantless_name"]),
    # A-Level Physics 9702 (RS-16): full coherent s15 set (MCQ P1v2 + structured P2v2 + ER)
    (f"{DP}/9702_s15_qp_12.pdf", "9702_s15_qp_12.pdf", ["alevel", "phys", "mcq_qp"]),
    (f"{DP}/9702_s15_ms_12.pdf", "9702_s15_ms_12.pdf", ["alevel", "phys", "mcq_ms"]),
    (f"{DP}/9702_s15_qp_22.pdf", "9702_s15_qp_22.pdf", ["alevel", "phys", "structured_qp"]),
    (f"{DP}/9702_s15_ms_22.pdf", "9702_s15_ms_22.pdf", ["alevel", "phys", "structured_ms"]),
    (f"{DP}/9702_s15_er.pdf",    "9702_s15_er.pdf",    ["alevel", "phys", "er", "er_variantless_name"]),
    # A-Level Mathematics 9709 (P1 + P4 structured) + IGCSE 0580
    (f"{DP}/9709_s15_qp_12.pdf", "9709_s15_qp_12.pdf", ["alevel", "math", "structured_qp"]),
    (f"{DP}/9709_s15_ms_12.pdf", "9709_s15_ms_12.pdf", ["alevel", "math", "structured_ms"]),
    (f"{DP}/9709_s15_qp_42.pdf", "9709_s15_qp_42.pdf", ["alevel", "math", "structured_qp", "multipage"]),
    (f"{DP}/9709_s15_ms_42.pdf", "9709_s15_ms_42.pdf", ["alevel", "math", "structured_ms"]),
    (f"{DP}/9709_s15_er.pdf",    "9709_s15_er.pdf",    ["alevel", "math", "er", "er_variantless_name"]),
    (f"{DP}/0580_s15_qp_22.pdf", "0580_s15_qp_22.pdf", ["igcse", "math", "structured_qp"]),
    (f"{DP}/0580_s15_ms_22.pdf", "0580_s15_ms_22.pdf", ["igcse", "math", "structured_ms"]),
    (f"{DP}/0580_s15_er.pdf",    "0580_s15_er.pdf",    ["igcse", "math", "er", "er_variantless_name"]),
    # A-Level Biology 9700 (P1 MCQ + structured P2) — complements local m25/w25
    (f"{DP}/9700_s15_qp_12.pdf", "9700_s15_qp_12.pdf", ["alevel", "mcq_qp"]),
    (f"{DP}/9700_s15_ms_12.pdf", "9700_s15_ms_12.pdf", ["alevel", "mcq_ms"]),
    (f"{DP}/9700_s15_qp_22.pdf", "9700_s15_qp_22.pdf", ["alevel", "structured_qp", "multipage"]),
    (f"{DP}/9700_s15_ms_22.pdf", "9700_s15_ms_22.pdf", ["alevel", "structured_ms"]),
    (f"{DP}/9700_s15_er.pdf",    "9700_s15_er.pdf",    ["alevel", "er", "er_variantless_name"]),
    # A-Level Computer Science 9618 (P1 is structured, NOT MCQ)
    (f"{BEH}/2023/9618_s23_qp_12.pdf", "9618_s23_qp_12.pdf", ["alevel", "cs", "structured_qp"]),
    (f"{BEH}/2023/9618_s23_ms_12.pdf", "9618_s23_ms_12.pdf", ["alevel", "cs", "structured_ms"]),
    (f"{BEH}/2023/9618_s23_er.pdf",    "9618_s23_er.pdf",    ["alevel", "cs", "er", "er_variantless_name"]),
]

# User-uploaded real papers: identical role, no URL (local provenance).
LOCAL_UPLOADS = [
    ("9700_m25_qp_22.pdf", ["alevel", "structured_qp", "multipage"]),
    ("9700_m25_ms_22.pdf", ["alevel", "structured_ms"]),
    ("9700_m25_er.pdf",    ["alevel", "er", "er_variantless_name"]),
    ("9700_w25_qp_22.pdf", ["alevel", "structured_qp", "multipage"]),
    ("9700_w25_ms_22.pdf", ["alevel", "structured_ms"]),
    ("0620_m25_er.pdf",    ["igcse", "er", "er_variantless_name"]),
]

MANDATORY_ROLES = [
    "mcq_qp", "mcq_ms", "structured_qp", "structured_ms",
    "igcse", "alevel", "math", "cs", "er", "multipage",
]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def fetch(url: str, dest: Path) -> bool:
    """Download and REQUIRE genuine PDF bytes.

    A CDN/mirror interstitial (HTML served with HTTP 200) is the classic
    silent-failure here — caught by the %PDF magic check. Size floor alone
    proved insufficient (papacambridge shells are ~2.7MB of HTML).
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(
        ["curl", "-sfL", "-m", "120", "-A", "Mozilla/5.0 Chrome/126.0",
         "-o", str(dest), url],
        capture_output=True, text=True)
    if r.returncode != 0 or not dest.exists() or dest.stat().st_size <= 1000:
        return False
    with open(dest, "rb") as f:
        if f.read(5) != b"%PDF-":
            dest.unlink()
            print(f"    [download] REJECTED non-PDF payload for {dest.name}")
            return False
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--download", action="store_true")
    ap.add_argument("--verify", action="store_true")
    args = ap.parse_args()
    if not (args.download or args.verify):
        args.download = True

    manifest = {"fixtures": [], "local": [], "derived": [],
                "provenance": "real public Cambridge PDFs via dynamicpapers.com (2015/16 archive) and bestexamhelp.com (9618 2023); "
                              "hashes pinned at first download; %PDF magic enforced at fetch"}
    failures = 0
    print(f"fixture root: {FIXTURE_ROOT}")
    for url, name, roles in FIXTURES:
        dest = FIXTURE_ROOT / "remote" / name
        if args.download and not dest.exists():
            ok = fetch(url, dest)
            print(("GET  " if ok else "FAIL ") + name)
            if not ok:
                failures += 1
                continue
        if not dest.exists():
            print(f"MISS {name}")
            failures += 1
            continue
        digest = sha256(dest)
        manifest["fixtures"].append(
            {"file": f"remote/{name}", "url": url, "sha256": digest,
             "bytes": dest.stat().st_size, "roles": roles})
        print(f"sha  {name}  {digest[:16]}…  {dest.stat().st_size}b")

    for name, roles in LOCAL_UPLOADS:
        src = UPLOADS / name
        dest = FIXTURE_ROOT / "local" / name
        if not src.exists():
            print(f"MISS local upload {name}")
            failures += 1
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists() or sha256(dest) != sha256(src):
            dest.write_bytes(src.read_bytes())
        digest = sha256(dest)
        manifest["local"].append(
            {"file": f"local/{name}", "url": None,
             "provenance": "user-uploaded real Cambridge PDF",
             "sha256": digest, "bytes": dest.stat().st_size, "roles": roles})
        print(f"loc  {name}  {digest[:16]}…")

    # role coverage gate
    have = {r for f in manifest["fixtures"] + manifest["local"] for r in f["roles"]}
    missing_roles = [r for r in MANDATORY_ROLES if r not in have]
    if missing_roles:
        print(f"ROLE COVERAGE MISSING: {missing_roles}")
        failures += 1

    MANIFEST_PATH.write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"manifest -> {MANIFEST_PATH} "
          f"({len(manifest['fixtures'])} remote, {len(manifest['local'])} local)")
    print(f"RESULT: {'FAIL' if failures else 'OK'} ({failures} failures)")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
