#!/usr/bin/env python3
"""Generate a labeling CSV from an output tree.

The template is intentionally prediction-aware: each row includes the current
predicted topic so a reviewer can confirm/correct it quickly while filling the
blank expected_topic column.

Usage:
    python tools/build_label_template.py \
        --output-root output \
        --csv topic_accuracy_labels.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Iterable, List

REVIEW_SENTINELS = {"review_required", "review_required_no_ms", ""}
_QNUM_RE = re.compile(r"Q?(\d+)")


def _norm(value: str) -> str:
    return str(value or "").strip()


def _question_sort_key(qnum: str):
    q = _norm(qnum)
    m = _QNUM_RE.match(q)
    if not m:
        return (999999, q)
    return (int(m.group(1)), q)


def collect_rows(output_root: Path) -> List[dict]:
    rows: List[dict] = []
    for meta in sorted(output_root.rglob("metadata.json")):
        try:
            data = json.loads(meta.read_text(encoding="utf-8"))
        except Exception:
            continue
        topic = data.get("topic") or []
        predicted = topic[0] if isinstance(topic, list) and topic else ""
        row = {
            "subject": _norm(data.get("subject")),
            "level": _norm(data.get("level")),
            "paper": _norm(data.get("paper")),
            "question_number": _norm(data.get("question_number")),
            "predicted_topic": _norm(predicted),
            "expected_topic": "",
            "route_status": "review_required" if _norm(predicted) in REVIEW_SENTINELS else "auto_routed",
            "variant": _norm(data.get("variant")),
            "season": _norm(data.get("season")),
            "year": _norm(data.get("year")),
            "metadata_path": meta.relative_to(output_root).as_posix(),
            "question_folder": meta.parent.relative_to(output_root).as_posix(),
            "notes": "",
        }
        rows.append(row)
    rows.sort(key=lambda r: (
        r["level"], r["subject"], r["paper"], _question_sort_key(r["question_number"]), r["metadata_path"]
    ))
    return rows


def write_csv(rows: List[dict], csv_path: Path) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "subject", "level", "paper", "question_number", "predicted_topic",
        "expected_topic", "route_status", "variant", "season", "year",
        "metadata_path", "question_folder", "notes",
    ]
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main(argv: Iterable[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-root", required=True)
    ap.add_argument("--csv", required=True)
    args = ap.parse_args(list(argv) if argv is not None else None)

    rows = collect_rows(Path(args.output_root))
    write_csv(rows, Path(args.csv))
    print(f"[label-template] wrote {args.csv} with {len(rows)} rows")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
