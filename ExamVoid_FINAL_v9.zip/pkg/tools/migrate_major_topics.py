#!/usr/bin/env python3
"""Migrate selected profiles to names-only official routing topics.

This intentionally updates only the active subject configs. The old configs
used paper buckets or broad invented categories for several profiles. Routing
now uses flattened official named topics with no numeric prefixes or decimal
subtopic folders; detailed evidence is retained only through keyword evidence.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

PROFILES = {
    "subjects/IGCSE/Chemistry_0620/config.json": {
        "topics": [
            "States_of_matter", "Atoms_elements_and_compounds", "Stoichiometry",
            "Electrochemistry", "Chemical_energetics", "Chemical_reactions",
            "Acids_bases_and_salts", "The_Periodic_Table", "Metals",
            "Chemistry_of_the_environment", "Organic_chemistry",
            "Experimental_techniques_and_chemical_analysis",
        ],
        "years": ["2015", "2016", "2025", "2026", "2027", "2028"],
        "source": "https://www.cambridgeinternational.org/Images/697205-2026-2028-syllabus.pdf",
        "topic_aliases": {
            "Atoms_elements_and_compounds": ["Atoms_elements_compounds"],
            "Stoichiometry": ["Stoichiometry_IGCSE"],
            "Electrochemistry": ["Electrochemistry_IGCSE"],
            "Chemical_energetics": ["Chemical_energetics_IGCSE"],
            "Chemical_reactions": ["Chemical_reactions_IGCSE"],
            "Acids_bases_and_salts": ["Acids_bases_salts_IGCSE"],
            "The_Periodic_Table": ["Periodic_table_IGCSE"],
            "Metals": ["Metals_IGCSE"],
            "Organic_chemistry": ["Organic_chemistry_IGCSE"],
            "Experimental_techniques_and_chemical_analysis": ["Experimental_techniques_IGCSE"],
        },
    },
    "subjects/A-Level/Chemistry_9701/config.json": {
        "topics": [
            "Atomic_structure", "Atoms_molecules_and_stoichiometry", "Chemical_bonding",
            "States_of_matter", "Chemical_energetics", "Electrochemistry", "Equilibria",
            "Reaction_kinetics", "The_Periodic_Table_chemical_periodicity", "Group_2",
            "Group_17", "Nitrogen_and_sulfur", "An_introduction_to_AS_Level_organic_chemistry",
            "Hydrocarbons", "Halogen_compounds", "Hydroxy_compounds", "Carbonyl_compounds",
            "Carboxylic_acids_and_derivatives", "Nitrogen_compounds", "Polymerisation",
            "Organic_synthesis", "Analytical_techniques", "Chemistry_of_transition_elements",
            "An_introduction_to_A_Level_organic_chemistry",
        ],
        "years": ["2015", "2025", "2026", "2027"],
        "source": "https://www.cambridgeinternational.org/Images/664563-2025-2027-syllabus.pdf",
        "topic_aliases": {"The_Periodic_Table_chemical_periodicity": ["The_Periodic_Table;_chemical_periodicity"]},
    },
    "subjects/IGCSE/Mathematics_0580/config.json": {
        "topics": [
            "Number", "Algebra_and_graphs", "Coordinate_geometry", "Geometry", "Mensuration",
            "Trigonometry", "Transformations_and_vectors", "Probability", "Statistics",
        ],
        "years": ["2015", "2025", "2026", "2027", "2028", "2029", "2030"],
        "source": "https://www.cambridgeinternational.org/Images/662466-2025-2027-syllabus.pdf",
    },
    "subjects/A-Level/Mathematics_9709/config.json": {
        "topics": [
            "Quadratics", "Functions", "Coordinate_geometry", "Circular_measure", "Trigonometry",
            "Series", "Differentiation", "Integration", "Algebra",
            "Logarithmic_and_exponential_functions", "Numerical_solution_of_equations", "Vectors",
            "Differential_equations", "Complex_numbers", "Forces_and_equilibrium",
            "Kinematics_of_motion_in_a_straight_line", "Momentum", "Newton's_laws_of_motion",
            "Energy_work_and_power", "Representation_of_data", "Permutations_and_combinations",
            "Probability", "Discrete_random_variables", "The_normal_distribution",
            "The_Poisson_distribution", "Linear_combinations_of_random_variables",
            "Continuous_random_variables", "Sampling_and_estimation", "Hypothesis_tests",
        ],
        "years": ["2015", "2026", "2027", "2028", "2029", "2030"],
        "source": "https://www.cambridgeinternational.org/Images/697427-2026-2027-syllabus.pdf",
        "topic_aliases": {"Quadratics": ["Algebra"]},
    },
    "subjects/A-Level/Further_Mathematics_9231/config.json": {
        "topics": [
            "Roots_of_polynomial_equations", "Rational_functions_and_graphs", "Summation_of_series",
            "Matrices", "Polar_coordinates", "Vectors", "Proof_by_induction", "Hyperbolic_functions",
            "Differentiation", "Integration", "Complex_numbers", "Differential_equations",
            "Motion_of_a_projectile", "Equilibrium_of_a_rigid_body", "Circular_motion", "Hooke's_law",
            "Linear_motion_under_a_variable_force", "Momentum", "Continuous_random_variables",
            "Inference_using_normal_and_t_distributions", "Chi_squared_tests", "Non_parametric_tests",
            "Probability_generating_functions",
        ],
        "years": ["2026", "2027"],
        "source": "https://www.cambridgeinternational.org/Images/697357-2026-2027-syllabus.pdf",
        "topic_aliases": {
            "Chi_squared_tests": ["x²_tests"],
        },
    },
    "subjects/IGCSE/Physics_0625/config.json": {
        "topics": [
            "Motion_forces_and_energy", "Thermal_physics", "Waves", "Electricity_and_magnetism",
            "Nuclear_physics", "Space_physics",
        ],
        "years": ["2016", "2026", "2027", "2028"],
        "source": "https://www.cambridgeinternational.org/Images/697209-2026-2028-syllabus.pdf",
    },
    "subjects/A-Level/Physics_9702/config.json": {
        "topics": [
            "Physical_quantities_and_units", "Kinematics", "Dynamics", "Forces_density_and_pressure",
            "Work_energy_and_power", "Deformation_of_solids", "Waves", "Superposition", "Electricity",
            "D_C_circuits", "Particle_physics", "Motion_in_a_circle", "Gravitational_fields",
            "Temperature", "Ideal_gases", "Thermodynamics", "Oscillations", "Electric_fields",
            "Capacitance", "Magnetic_fields", "Alternating_currents", "Quantum_physics",
            "Nuclear_physics", "Medical_physics", "Astronomy_and_cosmology",
        ],
        "years": ["2015", "2025", "2026", "2027"],
        "source": "https://www.cambridgeinternational.org/Images/664565-2025-2027-syllabus.pdf",
    },
    "subjects/A-Level/Biology_9700/config.json": {
        "topics": [
            "Cell_structure", "Biological_molecules", "Enzymes", "Cell_membranes_and_transport",
            "The_mitotic_cell_cycle", "Nucleic_acids_and_protein_synthesis", "Transport_in_plants",
            "Transport_in_mammals", "Gas_exchange", "Infectious_diseases", "Immunity",
            "Energy_and_respiration", "Photosynthesis", "Homeostasis", "Control_and_coordination",
            "Inheritance", "Selection_and_evolution", "Classification_biodiversity_and_conservation",
            "Genetic_technology",
        ],
        "years": ["2015", "2025", "2026", "2027"],
        "source": "https://www.cambridgeinternational.org/Images/664560-2025-2027-syllabus.pdf",
        "topic_aliases": {
            "Cell_structure": ["Cells", "Microscopy"],
            "Biological_molecules": ["Biological_Molecules_Carbs", "Proteins", "Lipids"],
            "Enzymes": ["Enzyme_Action"],
            "Cell_membranes_and_transport": ["Membrane_Transport"],
            "The_mitotic_cell_cycle": ["Cell_Division"],
            "Nucleic_acids_and_protein_synthesis": ["DNA_and_Protein_Synthesis"],
            "Transport_in_mammals": ["Circulation"],
            "Gas_exchange": ["Gas_Exchange"],
            "Homeostasis": ["Homeostasis"],
            "Control_and_coordination": ["Nervous_System"],
            "Inheritance": ["Inheritance"],
            "Selection_and_evolution": ["Natural_Selection"],
            "Genetic_technology": ["Gene_Technology"],
        },
    },
}


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def default_keywords(topic: str) -> list[str]:
    words = [w for w in re.split(r"[_ ]+", topic) if w and len(w) > 2]
    return [" ".join(words)] if words else [topic]


def build_keywords(data: dict, topics: list[str], aliases: dict[str, list[str]]) -> dict[str, list[str]]:
    old = data.get("classification_keywords", {})
    old_by_norm = {norm(k): list(v) for k, v in old.items()}
    # topics JSON, when present, is an additional official keyword source.
    topic_json = ROOT / "topics" / ("A-Level" if data.get("level") == "A-Level" else "IGCSE") / f"{data['subject']}_topics.json"
    if topic_json.exists():
        try:
            for key, value in json.loads(topic_json.read_text(encoding="utf-8")).get("topics", {}).items():
                kws = value.get("keywords", []) if isinstance(value, dict) else []
                old_by_norm.setdefault(norm(key), []).extend(kws)
        except Exception:
            pass
    result = {}
    for topic in topics:
        candidates = [topic] + aliases.get(topic, [])
        kws: list[str] = []
        for candidate in candidates:
            kws.extend(old_by_norm.get(norm(candidate), []))
        if not kws:
            kws = default_keywords(topic)
        # Use stable deduplication and add distinctive plain-text aliases.
        result[topic] = list(dict.fromkeys(str(k).strip() for k in kws if str(k).strip()))
    return result


def migrate(path: Path, spec: dict) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    topics = spec["topics"]
    aliases = spec.get("topic_aliases", {})
    data["major_topics"] = topics
    data["detailed_topics"] = topics
    data["mapping"] = {topic: topic for topic in topics}
    data["classification_keywords"] = build_keywords(data, topics, aliases)
    data["specialization_weights"] = {topic: float(data.get("specialization_weights", {}).get(topic, 1.0)) for topic in topics}
    data["syllabus_order"] = {topic: index + 1 for index, topic in enumerate(topics)}
    data["syllabus_years"] = spec["years"]
    data["official_source"] = spec["source"]
    data["folder_naming"] = "Names_Only_Major_Topics"
    data["naming_rule"] = {
        "routing": "major_topic_only",
        "numeric_prefixes": False,
        "decimal_subtopics": False,
        "detailed_evidence": "diagnostic_only",
    }
    data["validation"] = {
        "major_topics_names_only": True,
        "no_numeric_prefixes": True,
        "no_decimal_subtopics": True,
        "detailed_topics_are_routing_topics": True,
        "every_topic_maps_to_itself": True,
    }
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    for relative, spec in PROFILES.items():
        path = ROOT / relative
        migrate(path, spec)
        print(f"migrated {relative}: {len(spec['topics'])} major topics")


if __name__ == "__main__":
    main()
