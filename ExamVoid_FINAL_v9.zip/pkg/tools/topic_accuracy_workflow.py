#!/usr/bin/env python3
"""End-to-end batch accuracy workflow for real-paper validation.

Subcommands:
  run-batch  -> run the guarded pipeline, then generate a labeling template,
                and optionally evaluate against a completed labels CSV.
  template   -> build a labeling template from an existing output tree.
  evaluate   -> score an existing output tree against a completed labels CSV.

Examples:
  python tools/topic_accuracy_workflow.py run-batch \
      --input papers --output output --clean --low-ram \
      --labels-template topic_accuracy_labels.csv

  python tools/topic_accuracy_workflow.py evaluate \
      --output-root output --labels topic_accuracy_labels_filled.csv \
      --report-json topic_accuracy_report.json
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from typing import Iterable

REPO = Path(__file__).resolve().parents[1]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))


def _run_guarded(input_dir: str, output_dir: str, clean: bool, low_ram: bool,
                 workers: int, fetch_missing_ms: bool) -> int:
    cmd = [sys.executable, str(REPO / "run_guarded.py"), "--input", input_dir, "--output", output_dir, "--workers", str(workers)]
    if clean:
        cmd.append("--clean")
    if low_ram:
        cmd.append("--low-ram")
    if fetch_missing_ms:
        cmd.append("--fetch-missing-ms")
    print("[workflow] running:", " ".join(cmd))
    proc = subprocess.run(cmd, cwd=str(REPO))
    return proc.returncode


def _run_template(output_root: str, csv_path: str) -> int:
    from tools.build_label_template import collect_rows, write_csv

    rows = collect_rows(Path(output_root))
    write_csv(rows, Path(csv_path))
    print(f"[workflow] label template -> {csv_path} ({len(rows)} rows)")
    return 0


def _run_evaluate(output_root: str, labels: str, report_json: str = "", dashboard_html: str = "", summary_dir: str = "") -> int:
    from tools.evaluate_topic_accuracy import evaluate, load_labels, load_predictions, print_report

    report = evaluate(load_labels(Path(labels)), load_predictions(Path(output_root)))
    print_report(report)
    report_path = ""
    if report_json:
        Path(report_json).write_text(__import__("json").dumps(report, indent=2), encoding="utf-8")
        report_path = report_json
        print(f"[workflow] evaluation report -> {report_json}")
    if dashboard_html or summary_dir:
        if not report_path:
            report_path = str(Path(output_root) / "topic_accuracy_report.json")
            Path(report_path).write_text(__import__("json").dumps(report, indent=2), encoding="utf-8")
            print(f"[workflow] evaluation report -> {report_path}")
    if dashboard_html:
        from tools.render_topic_accuracy_dashboard import render_dashboard
        render_dashboard(Path(report_path), Path(dashboard_html))
        print(f"[workflow] dashboard -> {dashboard_html}")
    if summary_dir:
        from tools.export_accuracy_summary_csvs import export_summary_csvs
        written = export_summary_csvs(report, Path(summary_dir))
        for path in written:
            print(f"[workflow] summary csv -> {path}")
    return 0


def main(argv: Iterable[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run-batch", help="run guarded batch, then emit label template, optionally evaluate")
    p_run.add_argument("--input", required=True)
    p_run.add_argument("--output", required=True)
    p_run.add_argument("--labels-template", default="topic_accuracy_labels.csv")
    p_run.add_argument("--labels", default="", help="completed labels CSV; if supplied, evaluate after the run")
    p_run.add_argument("--report-json", default="topic_accuracy_report.json")
    p_run.add_argument("--dashboard-html", default="topic_accuracy_dashboard.html")
    p_run.add_argument("--summary-dir", default="topic_accuracy_csvs")
    p_run.add_argument("--clean", action="store_true")
    p_run.add_argument("--low-ram", action="store_true", default=True)
    p_run.add_argument("--workers", type=int, default=1)
    p_run.add_argument("--fetch-missing-ms", action="store_true")

    p_template = sub.add_parser("template", help="build a label template from an output tree")
    p_template.add_argument("--output-root", required=True)
    p_template.add_argument("--csv", required=True)

    p_eval = sub.add_parser("evaluate", help="evaluate an output tree against a completed labels CSV")
    p_eval.add_argument("--output-root", required=True)
    p_eval.add_argument("--labels", required=True)
    p_eval.add_argument("--report-json", default="")
    p_eval.add_argument("--dashboard-html", default="")
    p_eval.add_argument("--summary-dir", default="")

    args = ap.parse_args(list(argv) if argv is not None else None)

    if args.cmd == "template":
        return _run_template(args.output_root, args.csv)
    if args.cmd == "evaluate":
        return _run_evaluate(args.output_root, args.labels, args.report_json, args.dashboard_html, args.summary_dir)
    if args.cmd == "run-batch":
        rc = _run_guarded(args.input, args.output, args.clean, args.low_ram, args.workers, args.fetch_missing_ms)
        _run_template(args.output, args.labels_template)
        if args.labels:
            _run_evaluate(args.output, args.labels, args.report_json, args.dashboard_html, args.summary_dir)
        return rc
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
