#!/usr/bin/env python3
"""Render a self-contained HTML dashboard from topic_accuracy_report.json.

Usage:
    python tools/render_topic_accuracy_dashboard.py \
        --report-json topic_accuracy_report.json \
        --output topic_accuracy_dashboard.html
"""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Iterable

CSS = """
body{font:14px/1.5 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;color:#1a1f2b;background:#f6f7f9}
header{padding:28px 34px;background:#101828;color:#fff}
h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:28px 0 10px;color:#101828}
.sub{color:#c9d2e0;font-size:12.5px}.wrap{max-width:1120px;margin:0 auto;padding:0 22px 60px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin-top:-18px}
.card{background:#fff;border:1px solid #e4e7ec;border-radius:12px;padding:16px 18px;box-shadow:0 1px 2px rgba(16,24,40,.04)}
.metric{font-size:28px;font-weight:700;color:#101828}.label{font-size:12px;color:#667085;text-transform:uppercase;letter-spacing:.04em}
.good{color:#067647}.mid{color:#b54708}.bad{color:#b42318}
table{border-collapse:collapse;width:100%;background:#fff;border:1px solid #e4e7ec;border-radius:10px;overflow:hidden}
th{background:#f2f4f7;text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:#475467}
td,th{padding:8px 12px;border-bottom:1px solid #eef0f3;font-size:12.8px;vertical-align:top}
code,pre{font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;background:#f2f4f7;border-radius:5px;padding:1px 5px}
pre{padding:12px;overflow:auto}.pill{display:inline-block;padding:3px 8px;border-radius:999px;font-size:12px;font-weight:600}
.pill.good{background:#ecfdf3}.pill.mid{background:#fff7ed}.pill.bad{background:#fef3f2}
.small{font-size:12px;color:#667085}.empty{color:#667085;font-style:italic}
"""


def _esc(value) -> str:
    return html.escape(str(value), quote=True)


def _pct_class(value: float) -> str:
    if value >= 95.0:
        return "good"
    if value >= 85.0:
        return "mid"
    return "bad"


def build_dashboard(report: dict, title: str = "Topic Accuracy Dashboard") -> str:
    summary = report.get("summary", {})
    per_subject = report.get("per_subject", [])
    confusion = report.get("confusion", [])
    mismatches = report.get("mismatches", [])
    missing = report.get("missing_predictions", [])
    acc = float(summary.get("accuracy_percent", 0.0) or 0.0)
    acc_cls = _pct_class(acc)

    parts = [
        "<!DOCTYPE html><html><head><meta charset='utf-8'>",
        f"<title>{_esc(title)}</title><style>{CSS}</style></head><body>",
        f"<header><h1>{_esc(title)}</h1>",
        "<div class='sub'>Self-contained accuracy dashboard generated from the labeled evaluation report. "
        "No external scripts, styles, or network requests.</div></header>",
        "<div class='wrap'>",
        "<div class='grid'>",
    ]

    cards = [
        ("Accuracy", f"{acc:.2f}%", acc_cls),
        ("Labeled questions", int(summary.get("labeled", 0) or 0), ""),
        ("Correct", int(summary.get("correct", 0) or 0), "good"),
        ("Incorrect", int(summary.get("incorrect", 0) or 0), "bad"),
        ("Review required", int(summary.get("review_required", 0) or 0), "mid"),
        ("Missing prediction", int(summary.get("missing_prediction", 0) or 0), "mid"),
    ]
    for label, value, cls in cards:
        metric_cls = f"metric {cls}".strip()
        parts.append(
            f"<div class='card'><div class='label'>{_esc(label)}</div>"
            f"<div class='{metric_cls}'>{_esc(value)}</div></div>"
        )
    parts.append("</div>")

    parts.append("<h2>Per subject</h2>")
    parts.append("<div class='card'><table><tr><th>Subject</th><th>Labeled</th><th>Correct</th><th>Incorrect</th><th>Review required</th><th>Missing</th><th>Accuracy</th></tr>")
    if per_subject:
        for row in per_subject:
            pct = float(row.get("accuracy_percent", 0.0) or 0.0)
            cls = _pct_class(pct)
            parts.append(
                f"<tr><td><code>{_esc(row.get('subject', ''))}</code></td>"
                f"<td>{_esc(row.get('labeled', 0))}</td>"
                f"<td>{_esc(row.get('correct', 0))}</td>"
                f"<td>{_esc(row.get('incorrect', 0))}</td>"
                f"<td>{_esc(row.get('review_required', 0))}</td>"
                f"<td>{_esc(row.get('missing_prediction', 0))}</td>"
                f"<td><span class='pill {cls}'>{pct:.2f}%</span></td></tr>"
            )
    else:
        parts.append("<tr><td colspan='7' class='empty'>No per-subject rows present.</td></tr>")
    parts.append("</table></div>")

    parts.append("<h2>Top confusions</h2>")
    parts.append("<div class='card'><table><tr><th>Expected</th><th>Predicted</th><th>Count</th></tr>")
    if confusion:
        for row in confusion[:50]:
            parts.append(
                f"<tr><td><code>{_esc(row.get('expected', ''))}</code></td>"
                f"<td><code>{_esc(row.get('predicted', ''))}</code></td>"
                f"<td>{_esc(row.get('count', 0))}</td></tr>"
            )
    else:
        parts.append("<tr><td colspan='3' class='empty'>No confusion pairs — all labeled predictions matched.</td></tr>")
    parts.append("</table></div>")

    parts.append("<h2>Sample mismatches</h2>")
    parts.append("<div class='card'><table><tr><th>Subject</th><th>Paper</th><th>Q</th><th>Expected</th><th>Predicted</th><th>Metadata path</th></tr>")
    if mismatches:
        for row in mismatches[:100]:
            key = row.get("key", ["", "", "", ""])
            parts.append(
                f"<tr><td><code>{_esc(key[0] if len(key) > 0 else '')}</code></td>"
                f"<td><code>{_esc(key[2] if len(key) > 2 else '')}</code></td>"
                f"<td>{_esc(key[3] if len(key) > 3 else '')}</td>"
                f"<td><code>{_esc(row.get('expected', ''))}</code></td>"
                f"<td><code>{_esc(row.get('predicted', ''))}</code></td>"
                f"<td class='small'>{_esc(row.get('path', ''))}</td></tr>"
            )
    else:
        parts.append("<tr><td colspan='6' class='empty'>No mismatches recorded.</td></tr>")
    parts.append("</table></div>")

    parts.append("<h2>Missing predictions</h2>")
    parts.append("<div class='card'><table><tr><th>Subject</th><th>Paper</th><th>Q</th><th>Expected</th></tr>")
    if missing:
        for row in missing[:100]:
            key = row.get("key", ["", "", "", ""])
            parts.append(
                f"<tr><td><code>{_esc(key[0] if len(key) > 0 else '')}</code></td>"
                f"<td><code>{_esc(key[2] if len(key) > 2 else '')}</code></td>"
                f"<td>{_esc(key[3] if len(key) > 3 else '')}</td>"
                f"<td><code>{_esc(row.get('expected', ''))}</code></td></tr>"
            )
    else:
        parts.append("<tr><td colspan='4' class='empty'>No missing predictions recorded.</td></tr>")
    parts.append("</table></div>")

    parts.append("<p class='small'>Dashboard generated from topic_accuracy_report.json. "
                 "Use the confusion table to drive the next rules/threshold patches.</p>")
    parts.append("</div></body></html>")
    return "".join(parts)


def render_dashboard(report_json: Path, output: Path, title: str = "Topic Accuracy Dashboard") -> Path:
    report = json.loads(report_json.read_text(encoding="utf-8"))
    html_doc = build_dashboard(report, title=title)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_doc, encoding="utf-8")
    return output


def main(argv: Iterable[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--report-json", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--title", default="Topic Accuracy Dashboard")
    args = ap.parse_args(list(argv) if argv is not None else None)
    out = render_dashboard(Path(args.report_json), Path(args.output), title=args.title)
    print(f"[accuracy-dashboard] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
