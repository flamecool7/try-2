#!/usr/bin/env python3
"""tools/build_missing_configs.py — generate subject configs from topic taxonomies.

The subject detector recognises Psychology_9990 / Sociology_9699 /
Accounting_9706 (A-Level) but none had a subjects/*/config.json, so those
papers were skipped with "no approved subject config".  This tool converts the
existing topics/*/*_topics.json taxonomy files into valid
subjects/*/*/config.json profiles (same schema the classifier consumes).

Idempotent: existing config.json files are never overwritten.
"""
import json
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
TOPICS_ROOT = PROJ / "topics"
SUBJECTS_ROOT = PROJ / "subjects"

# syllabus_code -> (level, syllabus_years)
TARGETS = {
    "9990": ("A-Level", ["2023", "2024", "2025", "2026", "2027", "2028"]),
    "9699": ("A-Level", ["2023", "2024", "2025", "2026", "2027", "2028"]),
    "9706": ("A-Level", ["2023", "2024", "2025", "2026", "2027", "2028"]),
}


def build_config(topics_path: Path, code: str, level: str, years) -> dict:
    data = json.loads(topics_path.read_text(encoding="utf-8"))
    subject_name = data.get("subject", "Unknown")
    topics = data.get("topics", {})
    if not topics:
        raise ValueError(f"{topics_path}: no topics")

    names = list(topics.keys())
    subject_key = f"{subject_name}_{code}"

    major_topics = names
    detailed_topics = names
    mapping = {n: n for n in names}
    classification_keywords = {
        n: list(topics[n].get("keywords", [])) for n in names
    }
    specialization_weights = {
        n: float(topics[n].get("weight", 1.0)) for n in names
    }
    syllabus_order = {n: i + 1 for i, n in enumerate(names)}

    return {
        "subject": subject_key,
        "syllabus_code": code,
        "board": "CIE",
        "level": level,
        "syllabus_years": years,
        "official_source": "",
        "version": years[0],
        "major_topics": major_topics,
        "detailed_topics": detailed_topics,
        "mapping": mapping,
        "classification_keywords": classification_keywords,
        "specialization_weights": specialization_weights,
        "syllabus_order": syllabus_order,
        "folder_naming": "Pascal_Snake",
        "validation": {
            "syllabus_code_exists": True,
            "level_correct": True,
            "subject_name_correct": True,
            "major_topics_exist": True,
            "minor_maps_to_major": True,
            "no_duplicate_identifiers": True,
            "folder_safe_names": True,
            "syllabus_year_defined": True,
            "internally_consistent": True,
        },
        "historical_year_policy": "review_required",
    }


def main() -> int:
    built = 0
    for code, (level, years) in TARGETS.items():
        # find the topics file
        topics_file = TOPICS_ROOT / level / f"*{code}*_topics.json"
        candidates = list(TOPICS_ROOT.rglob(f"*{code}*_topics.json"))
        if not candidates:
            print(f"[build-configs] no topics file for {code} — skipped")
            continue
        tp = candidates[0]
        out_dir = SUBJECTS_ROOT / level / f"{tp.stem.replace('_topics', '')}"
        out_file = out_dir / "config.json"
        if out_file.exists():
            print(f"[build-configs] {out_file.name} already exists — skipped")
            continue
        cfg = build_config(tp, code, level, years)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[build-configs] wrote {out_file} "
              f"({len(cfg['major_topics'])} topics)")
        built += 1
    print(f"[build-configs] done: {built} config(s) created")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
