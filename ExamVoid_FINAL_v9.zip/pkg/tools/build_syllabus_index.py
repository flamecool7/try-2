#!/usr/bin/env python3
"""tools/build_syllabus_index.py — build a SEPARATE, discriminative syllabus
vocabulary index from the OFFICIAL Cambridge syllabus PDFs.

Unlike the earlier experiment (merging into config keywords), this writes a
standalone `subjects/{Level}/{Subject}/syllabus_vocab.json` that the classifier
consumes as its OWN supplementary signal.  Two correctness guarantees that
were missing before:

  1. **Exact topic mapping** — syllabus topic headings are matched to config
     topics by direct normalisation (config topic names ARE the official
     syllabus names).  No fuzzy token-overlap routing, so a section's
     vocabulary can never leak into the wrong topic.
  2. **Discriminative filtering** — a term is kept only if it appears in the
     learning outcomes of <= 2 topics (TF-IDF-style).  Generic prose
     ("temperature", "constant", "changes") is dropped; topic-specific terms
     ("equilibrium constant", "nucleon number", "ionisation energy") survive.

Output per subject: {config_topic_name: [terms]} (terms = single content words
>= 4 chars + bigrams, stopword-filtered, per-topic capped).
"""
import json
import re
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parent.parent
SUBJECTS_ROOT = PROJ / "subjects"
CACHE_DIR = PROJ / ".syllabus_cache"

_STOP = {
    "and", "or", "the", "of", "a", "an", "in", "on", "with", "for", "to",
    "as", "at", "by", "is", "are", "was", "were", "be", "been", "being",
    "its", "their", "into", "between", "from", "across", "that", "this",
    "these", "those", "level", "using", "use", "used", "able", "should",
    "candidates", "explain", "describe", "state", "identify", "define",
    "understand", "calculate", "determine", "outline", "suggest", "give",
    "draw", "show", "know", "include", "including", "such", "each", "other",
    "following", "follows", "which", "where", "when", "how", "why", "what",
    "can", "may", "must", "will", "would", "could", "also", "not", "no",
    "any", "all", "some", "than", "then", "there", "here", "about", "over",
    "under", "between", "through", "during", "within", "without", "above",
    "below", "both", "either", "neither", "whether", "because", "therefore",
    "however", "although", "while", "until", "since", "before", "after",
    "less", "more", "most", "least", "very", "only", "just", "per", "via",
    "e.g", "i.e", "etc", "number", "numbers", "term", "terms", "example",
    "examples", "limited", "one", "two", "three", "four", "five", "six",
    "different", "same", "order", "recall", "predict", "deduce", "compare",
    "contrast", "discuss", "evaluate", "assess", "analyse", "analyze",
    "interpret", "demonstrate", "appreciate", "construct", "perform",
    "write", "complete", "produce", "plot", "sketch", "label", "measure",
    "record", "collect", "list", "name", "derive", "affect", "affecting",
    "appropriate", "behaviour", "behaviour", "affect", "names", "fully",
    "strong", "weak", "solution", "solutions", "data", "information",
    "effect", "effects", "factors", "factor", "conditions", "condition",
    "give", "given", "terms", "reaction", "reactions", "substances",
    "substance", "products", "product", "compounds", "compound", "elements",
    "element", "molecules", "molecule", "atoms", "atom", "ions", "ion",
    "electrons", "electron", "energy", "temperature", "pressure", "volume",
    "mass", "concentration", "rate", "rates", "change", "changes", "values",
    "value", "results", "result", "experiment", "experiments", "method",
    "methods", "process", "processes", "system", "systems", "process",
    "total", "range", "table", "graph", "diagram", "equation", "equations",
    "calculate", "calculation", "calculations", "example", "examples",
}


def _extract_terms(text: str) -> set:
    """Content words (>=4 chars) + ADJACENT bigrams from learning-outcome text.

    Bigrams are extracted from the RAW text (adjacent words), NOT from a
    stopword-filtered token list, so noun-phrase order is preserved
    ("conjugate acid" stays "conjugate acid", never "acid conjugate").
    A pair is kept only if both words are meaningful content words."""
    words = re.findall(r"[a-z][a-z\-]+", text.lower())
    out = set()
    # single content words
    for w in words:
        if w not in _STOP and len(w) >= 4 and not w.replace("-", "").isdigit():
            out.add(w)
    # adjacent bigrams (both content words)
    for i in range(len(words) - 1):
        a, b = words[i], words[i + 1]
        if (a not in _STOP and b not in _STOP and len(a) >= 3 and len(b) >= 3
                and not a.replace("-", "").isdigit() and not b.replace("-", "").isdigit()):
            out.add(f"{a} {b}")
    return out

_INT_RE = re.compile(r"^\d{1,2}\s*$")


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", s.lower())


def _fetch(code: str, url: str) -> Path | None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    dest = CACHE_DIR / f"{code}_syllabus.pdf"
    if dest.exists():
        return dest
    if not url or "cambridgeinternational.org" not in url or "..." in url:
        return None
    try:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read()
        if not data.startswith(b"%PDF"):
            return None
        dest.write_bytes(data)
        return dest
    except Exception as e:
        print(f"  [syllabus] fetch failed {code}: {e}")
        return None


def _extract_terms(text: str) -> set:
    """Content words (>=4 chars) + ADJACENT bigrams from learning-outcome text.

    Bigrams are extracted from the RAW text (adjacent words), NOT from a
    stopword-filtered token list, so noun-phrase order is preserved
    ("conjugate acid" stays "conjugate acid", never "acid conjugate").
    A pair is kept only if both words are meaningful content words."""
    words = re.findall(r"[a-z][a-z\-]+", text.lower())
    out = set()
    # single content words
    for w in words:
        if w not in _STOP and len(w) >= 4 and not w.replace("-", "").isdigit():
            out.add(w)
    # adjacent bigrams (both content words)
    for i in range(len(words) - 1):
        a, b = words[i], words[i + 1]
        if (a not in _STOP and b not in _STOP and len(a) >= 3 and len(b) >= 3
                and not a.replace("-", "").isdigit() and not b.replace("-", "").isdigit()):
            out.add(f"{a} {b}")
    return out


def build_index(config_path: Path) -> bool:
    data = json.loads(config_path.read_text(encoding="utf-8"))
    code = str(data.get("syllabus_code", ""))
    url = data.get("official_source", "")
    pdf = _fetch(code, url)
    if pdf is None:
        return False
    try:
        import fitz
    except ImportError:
        import pymupdf as fitz

    doc = fitz.open(str(pdf))
    try:
        lines = []
        for page in doc:
            lines.extend((page.get_text("text") or "").splitlines())
    finally:
        doc.close()

    # topic_name (config) -> its topic name set for heading matching
    topics = data.get("detailed_topics", [])
    topic_by_norm = {_norm(t): t for t in topics}

    # Scan lines for section headings.  Two formats exist across syllabuses:
    #   (a) SAME-LINE  "1.1 Quadratics"  /  "1 Atomic structure"
    #   (b) SPLIT-LINE bare "1" then next line "Atomic structure"
    # A heading is a section boundary IFF its title maps to a config topic
    # (config topic names ARE the official syllabus names).  Learning-outcome
    # numbers ("1" followed by "understand that ...") never map and are skipped.
    same_line_re = re.compile(r"^(\d{1,2}(?:\.\d{1,2})?)\s+(.{3,70})$")

    # Build a list of (line_idx, config_topic) section starts.
    starts = []   # (line_index, config_topic)
    for i, ln in enumerate(lines):
        s = ln.strip()
        # (a) same-line heading
        m = same_line_re.match(s)
        if m:
            title = m.group(2).strip()
            tn = _norm(title)
            if tn in topic_by_norm:
                starts.append((i, topic_by_norm[tn]))
            continue
        # (b) split-line: bare integer then a title line
        if not _INT_RE.match(s):
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if "cambridgeinternational.org" in nxt or nxt == "Back to contents page":
            continue
        if len(nxt) <= 70 and _norm(nxt) in topic_by_norm:
            starts.append((i, topic_by_norm[_norm(nxt)]))

    if not starts:
        return False

    # assign text between consecutive starts to the earlier section's topic.
    # Stop at back-matter markers (appendices, glossaries, data booklets,
    # assessment guidance) so the last topic doesn't absorb the whole tail.
    back_matter = (
        "appendix", "glossary", "data booklet", "mathematical requirements",
        "assessment objectives", "command words", "what else you need to know",
        "additional information", "mathematical formulae", "grade descriptions",
        "summary of key quantities", "subject content overview",
    )
    sections = {}
    for k, (idx, topic) in enumerate(starts):
        end = starts[k + 1][0] if k + 1 < len(starts) else len(lines)
        # truncate at the first back-matter marker within this section
        for j in range(idx, end):
            ls = lines[j].strip().lower()
            if any(ls.startswith(bm) for bm in back_matter):
                end = j
                break
        text = "\n".join(lines[idx:end])
        sections.setdefault(topic, []).append(text)

    # extract terms per topic
    raw = {t: _extract_terms("\n".join(texts)) for t, texts in sections.items()}

    # discriminative filter: a term may appear in <= 3 topics (TF-IDF-style);
    # generic prose ("temperature", "measure") is spread wider and dropped.
    term_topics = {}
    for t, terms in raw.items():
        for term in terms:
            term_topics.setdefault(term, set()).add(t)
    filtered = {}
    for t, terms in raw.items():
        keep = [term for term in terms if len(term_topics[term]) <= 3]
        keep = keep[:1500]   # per-topic cap
        filtered[t] = sorted(keep)

    if not any(filtered.values()):
        return False

    # Degenerate guard: if the heading parse collapsed most content into ONE
    # topic (>= 50% of all terms) or mapped fewer than 4 topics, the section
    # parser does not fit this syllabus's layout — skip rather than ship a
    # cross-contaminated index.
    total_terms = sum(len(v) for v in filtered.values())
    if len(filtered) < 4:
        print(f"  [syllabus-index] {code}: only {len(filtered)} topics mapped — skip")
        return False
    biggest = max(len(v) for v in filtered.values())
    if biggest > 0.5 * total_terms:
        print(f"  [syllabus-index] {code}: one topic holds {biggest}/{total_terms} "
              f"terms — skip (degenerate)")
        return False

    out_file = config_path.parent / "syllabus_vocab.json"
    out_file.write_text(json.dumps(filtered, indent=1, ensure_ascii=False) + "\n",
                        encoding="utf-8")
    total = sum(len(v) for v in filtered.values())
    print(f"  [syllabus-index] {code}: {len(filtered)} topics, {total} terms -> "
          f"{out_file.name}")
    return True


def main() -> int:
    built = 0
    for config_path in sorted(SUBJECTS_ROOT.rglob("config.json")):
        try:
            if build_index(config_path):
                built += 1
        except Exception as e:
            print(f"[syllabus-index] ERROR {config_path}: {e}")
    total = 0
    for f in sorted(SUBJECTS_ROOT.rglob("syllabus_vocab.json")):
        d = json.loads(f.read_text(encoding="utf-8"))
        total += sum(len(v) for v in d.values())
    print(f"[syllabus-index] built {built} indexes; TOTAL syllabus terms = {total}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
