# IB real-paper QP/MS pipeline run — 2026-10-12

## Scope

Processed the authorized XtremePapers May 2025 Biology HL Paper 2 TZ1 question paper and its matching markscheme through `tools/run_universal_batch.py` as one subject-scoped bundle.

- Association key: `IB|IBBI/P2|May|2025`
- QP SHA-256: `0da19a66b629e933a420b52f5e2372a49e6e74d896c1821b7f06333e6484b2e2`
- MS SHA-256: `21ccfa18eb83d309dae58c66a248c62dd33233eaf368a2af318c4d00f441b028`
- Source directory: [XtremePapers May 2025 IB Experimental Sciences](https://papers.xtremepape.rs/index.php?dirpath=./IB/2025+Examination+Session/May+2025+Examination+Session/Experimental+sciences/&order=0)

## Production change

The first real QP/MS run segmented the QP but returned zero MS sections because the current Biology markscheme uses a table layout not covered by the old parser. The IB runtime now recognizes:

- `Question / Answers / Total` table headers as answer pages, without relying on older `M1/A1` codes.
- Repeated top-level question numbers across subparts, collapsing consecutive repeats while still rejecting a non-consecutive sequence error.
- Section B question numbers without a trailing period.
- Right-column `max` rows as closure evidence and safe same-page cuts between separate top-level questions.
- A same-page question crop start at its own row, so it does not inherit the previous question's content.

A synthetic regression test was added at `tests/test_ib_mark_scheme_table_layout.py`.

## Run result

| Document | Segments | Rendered WEBPs | Geometry | Contract |
|---|---:|---:|---|---|
| QP | 10 top-level questions | 12 (two questions tile across pages) | All 2280 px wide; decoded top band 20 px | PASS |
| MS | 10 question-level sections | 10 | All 2280 px wide; decoded top band 20 px | PASS |

Pack assembly produced 10 question packs, zero review items, and zero render failures. The runtime generated ten topic hints, but their topic accuracy has not been independently adjudicated.

## ER and limits

No matching examiner report was listed in the selected session directory. The output leaves the ER binding explicitly unauthorized and attaches no report. No ER from another subject, paper, timezone, or session was used.

This is one real Biology QP/MS validation—not full QP/MS/ER validation or evidence of all-subject IB support. Independent human crop and topic review remains pending. Keep `PROFILE_UNVALIDATED` rows unpromoted. The source PDFs and rendered test crops are temporary under `/tmp`; they are not copied into a project distribution.

## Tests

- Focused IB tests: 22 passed.
- Full project suite: 162 passed; deprecation warnings only.

Machine-readable results and source hashes: `reports/ib_official_pdf_validation.json`.
