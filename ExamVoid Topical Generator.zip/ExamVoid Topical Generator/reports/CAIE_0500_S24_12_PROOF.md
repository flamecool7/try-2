# Proof — English 0500/12 Selective Answer-Line Run

**Paper:** CAIE IGCSE First Language English 0500/12, May/June 2024  
**Final output:** `/tmp/caie_english_0500_s24_12/output/`  
**Run log:** `/tmp/caie_english_0500_s24_12/run.log`

## Final guarded run

```text
[PASS] 0500_s24_12: all paired questions saved: 3/3
[guarded] insert 0500_s24_in_12.pdf: whole_pages=0 sections=3
[PASS] final audit passes: errors=0
[guarded] questions saved: 3
*** ALL GREEN *** 8 stages, 26 checks passed — full guarded run
```

The paper worker reported **70 checks passed**. Final audit: zero errors. No standalone `IN` or `_insert` directories.

## Selective dotted-answer-line behavior

Implemented in both production QP renderers. Lines are preserved on short-answer sections. Cleanup starts only at an explicit instruction asking for at least 200 words; it removes the long-form answer rules from that point and continuation pages, leaving earlier short subparts untouched. Dot-only rows within the long-form answer area are collapsed.

Visual checks on the actual saved QP crops confirmed:

- **Q1:** dotted response lines remain throughout, including short-answer parts and the 120-word summary.
- **Q2:** short response lines remain for (a)–(c); long-form (d), “Write about 200 to 300 words”, has its answer rules removed.
- **Q3:** the 250–350-word talk answer rules are removed; question wording, bullet points, and mark text remain.

## Crop boundaries and insert associations

- **Q1:** starts “Read Text A”, includes (a)–(f), and has no Q2 “Read Text C” leak. Its insert is Text A + B only.
- **Q2:** starts “Read Text C” and ends before the Q3 “Re-read Text C” prompt.
- **Q3:** starts “Re-read Text C”.
- Cambridge “© UCLES 2024”, publication slug, and scrambled imposition artifacts are absent from QP crops.

The six actual QP/insert images are embedded in `reports/CAIE_0500_S24_12_CROPS.html`.

## Per-question insert sidecars

| Question | Attached content | Output |
|---|---|---|
| Q1 | Text A + Text B; no Text C | `Summary_writing/12_Summer_2024_Q1/12_Summer_2024_Q1_IN.webp` — 2280 × 3939, 1,056,998 bytes, SHA-256 `382559fe0095d686669368e18d718a877efdce6b98030d930ccc66eea1e82f09` |
| Q2 | Text C | `Writers_effects_and_language_analysis/12_Summer_2024_Q2/12_Summer_2024_Q2_IN.webp` — 2280 × 2658, 498,714 bytes, SHA-256 `1f8791ab86712733ba33fcf6590088700ac875a4048a3009542adadb65945b02` |
| Q3 | Text C | `Reading_comprehension/12_Summer_2024_Q3/12_Summer_2024_Q3_IN.webp` — 2280 × 2658, 498,714 bytes, SHA-256 `1f8791ab86712733ba33fcf6590088700ac875a4048a3009542adadb65945b02` |

Q2 and Q3 insert hashes match because both attach the same Text C crop.

## Regression results

- Focused crop/insert and selective dotted-rule tests: **29 passed**.
- Full repository test suite: **181 passed**, 6 warnings.
