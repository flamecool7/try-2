"""Export SAT Practice Tests 4-11 into the CAIE-style topical folder tree.

The SAT adapter segments the official QPs, the production SAT classifier routes
questions into the existing SAT domain folders, and the shared gold renderer
creates the QP crop. Official explanation crops and scoring-guide answer text are
copied into the same question folder.

Example:
    python tools/export_sat_caie_tree.py \
      --qp-dir /tmp/sat_official_compat \
      --companions /home/user/SAT_Official_Companions \
      --out /home/user/SAT_CAIE_Style_Output

Output:
    Digital_SAT/<SAT subject>/paper-<test>/<topic>/<variant>_Practice_UNKNOWN_Q<n>/
        <same-folder-name>.webp
        <same-folder-name>_MS.webp
        <same-folder-name>_MS.txt
        metadata.json

Original PDFs stay in --qp-dir/--companions' cache, outside this exported tree.
"""
from __future__ import annotations

import argparse
import json
import shutil
import uuid
from collections import Counter
from pathlib import Path
from typing import Iterable
import sys

import numpy as np
from PIL import Image

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from adapters.pipeline_dispatch import build_document_context
from adapters.sat.adapter import Adapter
from adapters.sat.classification import classify_segments
from adapters.segment_geometry import measure_top_band, render_segment
from core.webp_utils import scrub_barcode_bands

SAT_SUBJECTS = {
    "RW": {
        "subject": "Reading_and_Writing_SATR",
        "spec_code": "SATR",
        "config": PROJECT_ROOT / "subjects_sat/Digital_SAT/Reading_and_Writing_SATR/config.json",
    },
    "MATH": {
        "subject": "Math_SATM",
        "spec_code": "SATM",
        "config": PROJECT_ROOT / "subjects_sat/Digital_SAT/Math_SATM/config.json",
    },
}


def _qid(test: int, section: str, module: int, number: int) -> str:
    return f"SAT_T{test:02d}_{section}_M{module}_Q{number:02d}"


def _load_major_topics(section: str) -> set[str]:
    payload = json.loads(SAT_SUBJECTS[section]["config"].read_text(encoding="utf-8"))
    return set(payload.get("major_topics") or [])


def _metadata(test: int, section: str, module: int, qn: int, topic: str) -> dict:
    component = f"SAT_T{test:02d}_{section}_M{module}"
    stable_key = f"Digital_SAT/{SAT_SUBJECTS[section]['subject']}/paper-{test}/{component}/Q{qn}"
    return {
        "id": str(uuid.uuid5(uuid.NAMESPACE_URL, stable_key)),
        "level": "Digital_SAT",
        "subject": SAT_SUBJECTS[section]["subject"],
        "board": "SAT",
        "topic": [topic],
        "paper": component,
        "question_number": f"Q{qn}",
        "variant": component,
        "season": "Practice",
        "year": "UNKNOWN",
    }


def _first_nonwhite_row(image: Image.Image) -> int | None:
    rgb = np.asarray(image.convert("RGB"))
    rows = np.where(np.any(rgb < 250, axis=(1, 2)))[0]
    return int(rows[0]) if rows.size else None


def _shift_vertical_without_clipping(image: Image.Image, offset: int) -> Image.Image:
    """Shift a crop to compensate for lossy WEBP edge rounding.

    A negative offset is permitted only when every removed source row is white;
    a positive offset pads with white and never clips question content.
    """
    width, height = image.size
    if offset == 0:
        return image.copy()
    if offset > 0:
        shifted = Image.new("RGB", (width, height + offset), "white")
        shifted.paste(image.convert("RGB"), (0, offset))
        return shifted
    cut = -offset
    if cut >= height:
        raise ValueError(f"Unsafe SAT crop top trim: {cut} rows from {height}")
    top = np.asarray(image.convert("RGB"))[:cut]
    if np.any(top < 250):
        raise ValueError("Refusing to trim nonwhite content while calibrating saved QP band")
    return image.crop((0, cut, width, height)).convert("RGB")


def _save_qp_with_exact_white_band(image: Image.Image, path: Path, quality: int) -> int:
    """Save a WEBP whose decoded top 20 rows remain white after lossy encoding.

    The shared renderer supplies the exact source geometry. Lossy WEBP can move
    the first visible glyph pixel by a few rows; test only shifts that add white
    padding or remove verified-white source rows. If a codec quality has no
    stable pixel alignment for a particular crop, step up quality before
    falling back to lossless rather than ship an image that fails the crop lock.
    Returns the quality used (101 denotes the lossless fallback).
    """
    clean = scrub_barcode_bands(image)
    if clean.width != 2280 or measure_top_band(clean) != 20:
        raise ValueError(f"SAT renderer did not provide 2280px/20px QP geometry before save: {clean.size}")
    if np.any(np.asarray(clean.convert("RGB"))[:20] < 250):
        raise ValueError("SAT renderer's verified top band contains a nonwhite pixel")

    path.parent.mkdir(parents=True, exist_ok=True)
    qualities = list(dict.fromkeys([quality, *[q for q in (65, 75, 85, 92, 95, 100) if q > quality]]))
    for current_quality in qualities:
        candidate_offsets = [0]
        candidate = _shift_vertical_without_clipping(clean, 0)
        candidate.save(path, "WEBP", quality=current_quality, method=4)
        candidate.close()
        with Image.open(path) as decoded:
            decoded.load()
            first = _first_nonwhite_row(decoded)
            clean_band = not np.any(np.asarray(decoded.convert("RGB"))[:20] < 250)
            width = decoded.width
        if width == 2280 and first == 20 and clean_band:
            if clean is not image:
                clean.close()
            return current_quality

        # Lossy rounding is not monotonic by row. Search a small window around
        # the observed correction; this avoids needless retries for the common
        # offset-zero case while handling glyphs whose first pixel jumps 19→21.
        if first is not None:
            center = 20 - first
            nearby = [n for n in range(center - 4, center + 5) if n != 0 and abs(n) < 20]
            for offset in sorted(set(nearby), key=lambda n: (abs(n), n)):
                candidate = _shift_vertical_without_clipping(clean, offset)
                candidate.save(path, "WEBP", quality=current_quality, method=4)
                candidate.close()
                with Image.open(path) as decoded:
                    decoded.load()
                    found = _first_nonwhite_row(decoded)
                    clean_band = not np.any(np.asarray(decoded.convert("RGB"))[:20] < 250)
                    width = decoded.width
                if width == 2280 and found == 20 and clean_band:
                    if clean is not image:
                        clean.close()
                    return current_quality

    # Lossless preserves the renderer's already-verified geometry byte-for-byte.
    clean.save(path, "WEBP", lossless=True, method=4)
    with Image.open(path) as decoded:
        decoded.load()
        if decoded.width != 2280 or _first_nonwhite_row(decoded) != 20 or np.any(np.asarray(decoded.convert("RGB"))[:20] < 250):
            if clean is not image:
                clean.close()
            path.unlink(missing_ok=True)
            raise ValueError(f"Could not preserve exact 20px white band after WEBP save: {path}")
    if clean is not image:
        clean.close()
    return 101


def _write_question_folder(
    *,
    out_root: Path,
    qp_pdf: Path,
    segment: dict,
    classification: dict,
    test: int,
    qn: int,
    ms_source_dir: Path,
    quality: int,
    force: bool,
) -> dict:
    section = str(segment["section"]).upper()
    module = int(segment["module"])
    spec = SAT_SUBJECTS[section]
    qid = _qid(test, section, module, qn)
    component = f"SAT_T{test:02d}_{section}_M{module}"
    status = str(classification.get("status") or "REVIEW_REQUIRED")
    candidate_topic = str(classification.get("topic") or "UNKNOWN")
    valid_topics = _load_major_topics(section)
    if status == "HINT" and candidate_topic in valid_topics:
        topic_folder = candidate_topic
        metadata_topic = candidate_topic
    else:
        topic_folder = "review_required"
        metadata_topic = "review_required"
        status = "REVIEW_REQUIRED"

    question_folder_name = f"{component}_Practice_UNKNOWN_Q{qn}"
    question_dir = (
        out_root / "Digital_SAT" / spec["subject"] / f"paper-{test}" /
        topic_folder / question_folder_name
    )
    question_dir.mkdir(parents=True, exist_ok=True)

    qp_name = f"{question_folder_name}.webp"
    ms_name = f"{question_folder_name}_MS.webp"
    txt_name = f"{question_folder_name}_MS.txt"
    qp_out = question_dir / qp_name
    ms_out = question_dir / ms_name
    txt_out = question_dir / txt_name
    metadata_out = question_dir / "metadata.json"

    stable_stem = _qid(test, section, module, qn)
    ms_image_src = ms_source_dir / f"{stable_stem}_MS.webp"
    ms_text_src = ms_source_dir / f"{stable_stem}_MS.txt"
    if not ms_image_src.is_file() or not ms_text_src.is_file():
        raise FileNotFoundError(f"Missing official MS companion for {stable_stem}")

    if force or not qp_out.exists():
        rendered = render_segment(qp_pdf, segment)
        try:
            if rendered.image.width != 2280 or measure_top_band(rendered.image) != 20:
                raise ValueError(f"QP crop geometry failed for {stable_stem}")
            _save_qp_with_exact_white_band(rendered.image, qp_out, quality=quality)
        finally:
            rendered.image.close()
    if force or not ms_out.exists():
        # These official explanation strips were rendered at their native page
        # scale. Keep their 765px raster instead of upscaling it to the CAIE QP
        # width; modest WEBP recompression keeps the full eight-test archive small.
        with Image.open(ms_image_src) as src:
            src.convert("RGB").save(ms_out, "WEBP", quality=85, method=4)
    if force or not txt_out.exists():
        shutil.copy2(ms_text_src, txt_out)
    if force or not metadata_out.exists():
        # Match CAIE's canonical metadata.json contract: only these 10 fields.
        # SAT module identity is encoded into paper/variant/folder IDs so local
        # Q1-Q33/Q1-Q27 restarts never collide. The correct answer and its official
        # scoring-guide provenance live in the required _MS.txt sidecar.
        metadata_out.write_text(
            json.dumps(_metadata(test, section, module, qn, metadata_topic), indent=4) + "\n",
            encoding="utf-8",
        )

    return {
        "id": stable_stem,
        "section": section,
        "module": module,
        "question_number": qn,
        "status": status,
        "topic": metadata_topic,
        "folder": str(question_dir),
        "qp": str(qp_out),
        "ms": str(ms_out),
        "ms_txt": str(txt_out),
        "metadata": str(metadata_out),
    }


def export_test(
    test: int,
    *,
    qp_dir: Path,
    companions_dir: Path,
    out_root: Path,
    quality: int,
    force: bool,
    limit: int = 0,
) -> dict:
    qp_pdf = qp_dir / f"sat-practice-test-{test}-digital.pdf"
    if not qp_pdf.is_file():
        raise FileNotFoundError(qp_pdf)
    ctx = build_document_context(qp_pdf)
    adapter = Adapter()
    segments = adapter.segment(ctx)
    if len(segments) != 120:
        raise ValueError(f"Test {test}: SAT adapter found {len(segments)} QP segments, expected 120")
    classes = classify_segments(ctx, segments, component=f"SAT_T{test:02d}")
    if len(classes) != len(segments):
        raise ValueError(f"Test {test}: classifier output count differs from segment count")
    selected = list(zip(segments, classes))
    if limit:
        selected = selected[:limit]
    ms_test_dir = companions_dir / f"SAT_T{test:02d}"
    results = []
    for segment, classification in selected:
        qn = int(segment["question_number"])
        result = _write_question_folder(
            out_root=out_root,
            qp_pdf=qp_pdf,
            segment=segment,
            classification=classification,
            test=test,
            qn=qn,
            ms_source_dir=ms_test_dir,
            quality=quality,
            force=force,
        )
        results.append(result)
    return {
        "test": test,
        "segments": len(segments),
        "exported": len(results),
        "classification_statuses": dict(Counter(r["status"] for r in results)),
        "topics": dict(Counter(r["topic"] for r in results)),
        "questions": results,
    }


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--qp-dir", type=Path, required=True, help="Directory containing official Test 4-11 QP PDFs")
    parser.add_argument("--companions", type=Path, required=True, help="Flat source companions produced by build_sat_answer_companions.py")
    parser.add_argument("--out", type=Path, required=True, help="CAIE-style output root")
    parser.add_argument("--tests", default="4-11", help="Test range or comma-separated list")
    parser.add_argument("--quality", type=int, default=55, help="QP WEBP quality (the decoded 20px white band is verified after encoding)")
    parser.add_argument("--limit-per-test", type=int, default=0, help="QA-only render limit; 0 exports all 120")
    parser.add_argument("--force", action="store_true", help="Overwrite existing outputs")
    args = parser.parse_args(list(argv) if argv is not None else None)
    tests: list[int] = []
    for part in args.tests.split(","):
        part = part.strip()
        if "-" in part:
            start, end = map(int, part.split("-", 1))
            tests.extend(range(start, end + 1))
        elif part:
            tests.append(int(part))
    if not tests or any(t < 4 or t > 11 for t in tests):
        parser.error("Only SAT Practice Tests 4 through 11 are supported")
    args.out.mkdir(parents=True, exist_ok=True)
    summaries = []
    for test in sorted(set(tests)):
        summary = export_test(
            test,
            qp_dir=args.qp_dir,
            companions_dir=args.companions,
            out_root=args.out,
            quality=args.quality,
            force=args.force,
            limit=args.limit_per_test,
        )
        print(
            f"Test {test}: exported {summary['exported']}/120; "
            f"classification={summary['classification_statuses']}"
        )
        summaries.append({k: v for k, v in summary.items() if k != "questions"})
    audit = {
        "schema_version": "1.0",
        "layout": "CAIE-style topical question folders",
        "level": "Digital_SAT",
        "official_practice_tests": sorted(set(tests)),
        "full_question_count_expected": 120 * len(set(tests)),
        "full_export": not bool(args.limit_per_test),
        "quality": args.quality,
        "root": str(args.out / "Digital_SAT"),
        "tests": summaries,
    }
    (args.out / "SAT_CAIE_LAYOUT_AUDIT.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
