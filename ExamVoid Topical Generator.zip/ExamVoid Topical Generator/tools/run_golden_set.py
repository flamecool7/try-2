#!/usr/bin/env python3
"""Run tools/golden_set_v1.json through the real classifier and score accuracy.

Pure text-level harness (see tools/classify_text.py) — no PDFs, no cropping,
just the same core.classifier.TopicClassifier every board adapter uses in
production. Prints overall + per-subject accuracy and every mismatch with the
engine's own reasoning so failures can be diagnosed quickly.
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from tools.classify_text import load_classifier, classify  # noqa: E402


def main():
    golden_path = REPO / "tools" / "golden_set_v1.json"
    cases = json.loads(golden_path.read_text(encoding="utf-8"))

    results = []
    per_subject = defaultdict(lambda: {"correct": 0, "total": 0})
    mismatches = []

    for case in cases:
        classifier, _cfg = load_classifier(case["config"])
        result = classify(classifier, case["text"], mark_scheme_text=case.get("ms", ""),
                          question_number=case["qn"])
        predicted = result.winning_major
        expected = case["expected"]
        correct = predicted == expected
        per_subject[case["subject"]]["total"] += 1
        if correct:
            per_subject[case["subject"]]["correct"] += 1
        else:
            mismatches.append({
                "subject": case["subject"], "qn": case["qn"],
                "expected": expected, "predicted": predicted,
                "fallback_tier": result.fallback_tier,
                "confidence": round(result.confidence, 3),
                "scores": {k: round(v, 2) for k, v in sorted(result.major_topic_scores.items(),
                                                              key=lambda kv: -kv[1])[:4]},
                "text": case["text"][:140],
            })
        results.append(correct)

    total = len(results)
    correct_n = sum(results)
    print("=" * 70)
    print(f"GOLDEN SET ACCURACY: {correct_n}/{total} = {100.0*correct_n/total:.1f}%")
    print("=" * 70)
    print()
    print("Per subject:")
    for subj, c in sorted(per_subject.items()):
        pct = 100.0 * c["correct"] / c["total"]
        flag = "" if pct == 100 else "  <-- MISSES"
        print(f"  {subj:38s} {c['correct']:2d}/{c['total']:2d}  ({pct:5.1f}%){flag}")

    if mismatches:
        print()
        print("=" * 70)
        print(f"MISMATCHES ({len(mismatches)}):")
        print("=" * 70)
        for m in mismatches:
            print(f"\n[{m['subject']}] Q{m['qn']}")
            print(f"  expected : {m['expected']}")
            print(f"  predicted: {m['predicted']}  (tier={m['fallback_tier']}, confidence={m['confidence']})")
            print(f"  top scores: {m['scores']}")
            print(f"  text: {m['text']}...")

    return 0 if correct_n == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
