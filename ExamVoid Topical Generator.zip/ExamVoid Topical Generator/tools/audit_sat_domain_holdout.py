"""Run a reproducible SAT domain/skill audit against a labeled practice test.

Example:
  python tools/audit_sat_domain_holdout.py \
    --qp data/sat_calibration/sat-practice-test-10-digital.pdf \
    --labels tests/fixtures/sat_practice_test_10_domain_holdout_labels.json \
    --csv reports/sat_practice_test_10_holdout_audit.csv

Expected labels are separately mapped from official answer explanations and the
College Board taxonomy. Coverage and accuracy are reported separately;
REVIEW_REQUIRED is not counted as a correct automatic classification. Skill
accuracy includes only cases with an independently supplied expected_skill.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapters.pipeline_dispatch import build_document_context
from adapters.registry import get_adapter
from adapters.sat.classification import classify_segments

LABELS_PATH = ROOT / "tests" / "fixtures" / "sat_practice_test_10_domain_holdout_labels.json"


def _case_id(section: str, module: int, question: int) -> str:
    section = "RW" if str(section).upper() in {"RW", "READING", "READING_AND_WRITING"} else "MATH"
    return f"{section}M{int(module)}Q{int(question)}"


def run(qp_pdf: Path, labels_path: Path = LABELS_PATH):
    gold = json.loads(labels_path.read_text(encoding="utf-8"))
    labels = {x["id"]: x for x in gold["cases"]}
    ctx = build_document_context(qp_pdf)
    segments = get_adapter("SAT").segment(ctx)
    predictions = classify_segments(ctx, segments, component="SAT_DOMAIN_AUDIT")
    rows = []
    for seg, pred in zip(segments, predictions):
        sid = _case_id(seg.get("section", ""), int(seg.get("module") or 0),
                       int(seg.get("question_number") or 0))
        if sid not in labels:
            raise ValueError(f"No expected label for {sid}")
        label = labels[sid]
        expected = label["expected_topic"]
        auto = pred.get("status") == "HINT"
        guessed = pred.get("topic") if auto else ""
        expected_skill = label.get("expected_skill")
        skill_labeled = bool(expected_skill)
        skill_auto = pred.get("skill_status") == "HINT"
        guessed_skill = pred.get("skill") if skill_auto else ""
        rows.append({
            "id": sid,
            "section": seg.get("section", ""),
            "module": seg.get("module", ""),
            "question": seg.get("question_number", ""),
            "expected_topic": expected,
            "predicted_topic": guessed,
            "status": pred.get("status", ""),
            "domain_correct": bool(auto and guessed == expected),
            "expected_skill": expected_skill or "",
            "predicted_skill": guessed_skill or "",
            "skill_status": pred.get("skill_status", "REVIEW_REQUIRED"),
            "skill_labeled": skill_labeled,
            "skill_correct": bool(skill_labeled and skill_auto and guessed_skill == expected_skill),
            "text_source": pred.get("text_source", ""),
        })
    if len(rows) != int(gold.get("question_count", len(labels))) or set(r["id"] for r in rows) != set(labels):
        raise ValueError(f"QP segmentation/label mismatch: got {len(rows)}, expected {len(labels)} unique items")

    hint_rows = [r for r in rows if r["status"] == "HINT"]
    skill_labeled_rows = [r for r in rows if r["skill_labeled"]]
    skill_auto_rows = [r for r in skill_labeled_rows if r["skill_status"] == "HINT"]
    total = len(rows)
    report = {
        "title": gold.get("title", ""),
        "questions": total,
        "hints": len(hint_rows),
        "reviews": total - len(hint_rows),
        "coverage": round(len(hint_rows) / total, 4) if total else 0,
        "exact_domain_matches_among_hints": sum(r["domain_correct"] for r in hint_rows),
        "hint_accuracy": round(sum(r["domain_correct"] for r in hint_rows) / len(hint_rows), 4) if hint_rows else None,
        "incorrect_hints": [r["id"] for r in hint_rows if not r["domain_correct"]],
        "skill_cases_labeled": len(skill_labeled_rows),
        "skill_hints_on_labeled_cases": len(skill_auto_rows),
        "skill_exact_matches": sum(r["skill_correct"] for r in skill_auto_rows),
        "skill_hint_accuracy": round(sum(r["skill_correct"] for r in skill_auto_rows) / len(skill_auto_rows), 4) if skill_auto_rows else None,
        "incorrect_skill_hints": [r["id"] for r in skill_auto_rows if not r["skill_correct"]],
        "by_section_module": {},
        "by_expected_domain": {},
    }
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["section"], row["module"])].append(row)
    for (section, module), part in sorted(grouped.items()):
        automatic = [r for r in part if r["status"] == "HINT"]
        skill_part = [r for r in part if r["skill_labeled"] and r["skill_status"] == "HINT"]
        report["by_section_module"][f"{section}M{module}"] = {
            "questions": len(part), "hints": len(automatic),
            "reviews": len(part) - len(automatic),
            "coverage": round(len(automatic) / len(part), 4) if part else 0,
            "hint_matches": sum(r["domain_correct"] for r in automatic),
            "hint_accuracy": round(sum(r["domain_correct"] for r in automatic) / len(automatic), 4) if automatic else None,
            "skill_labeled": sum(r["skill_labeled"] for r in part),
            "skill_hints": len(skill_part),
            "skill_matches": sum(r["skill_correct"] for r in skill_part),
            "skill_accuracy": round(sum(r["skill_correct"] for r in skill_part) / len(skill_part), 4) if skill_part else None,
        }
    for domain in sorted({r["expected_topic"] for r in rows}):
        part = [r for r in rows if r["expected_topic"] == domain]
        automatic = [r for r in part if r["status"] == "HINT"]
        report["by_expected_domain"][domain] = {
            "questions": len(part), "hints": len(automatic),
            "reviews": len(part) - len(automatic),
            "hint_matches": sum(r["domain_correct"] for r in automatic),
            "hint_accuracy": round(sum(r["domain_correct"] for r in automatic) / len(automatic), 4) if automatic else None,
        }
    return report, rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--qp", required=True, type=Path, help="Official SAT question PDF")
    parser.add_argument("--labels", type=Path, default=LABELS_PATH, help="Item-level expected-domain/skill JSON")
    parser.add_argument("--csv", type=Path, help="Optional item-level CSV output")
    parser.add_argument("--json", type=Path, help="Optional metrics and item-level JSON output")
    args = parser.parse_args()
    report, rows = run(args.qp, args.labels)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if args.csv:
        args.csv.parent.mkdir(parents=True, exist_ok=True)
        with args.csv.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps({"metrics": report, "items": rows}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
