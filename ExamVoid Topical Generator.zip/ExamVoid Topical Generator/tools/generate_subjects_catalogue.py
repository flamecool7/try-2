#!/usr/bin/env python3
"""Reconcile subjects.json with the subject profiles present in this workspace.

This restores the catalogue generator referenced by the UI. Non-IB rows are
preserved verbatim; IB rows are rebuilt from subjects_ib/DP/*/config.json.
Legacy taxonomy-only codes that duplicate a profiled subject are retained as
aliases on that subject rather than as duplicate rows.

Usage:
    python tools/generate_subjects_catalogue.py          # write subjects.json
    python tools/generate_subjects_catalogue.py --check  # report drift, write nothing
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
CATALOGUE = ROOT / "subjects.json"
PROFILE_ROOT = ROOT / "subjects_ib" / "DP"

# These are the 13 legacy taxonomy-row identifiers in the generated catalogue.
# They are old catalogue codes, not asserted IBO paper-code tokens.
LEGACY_ALIAS_TO_PROFILE = {
    "Biology": "IBBI",
    "Business_Management": "IBBM",
    "Chemistry": "IBCH",
    "Digital_Society": "IBDS",
    "Economics": "IBEC",
    "Geography": "IBGE",
    "History": "IBHI",
    "Language_A_Language_and_Literature": "IBLL",
    "Language_A_Literature": "IBLT",
    "Mathematics_Analysis_and_Approaches": "IBMA",
    "Mathematics_Applications_and_Interpretation": "IBAI",
    "Physics": "IBPH",
    "Psychology": "IBPS",
}

DISPLAY_NAMES = {
    "IBCL": "Classical Languages (Latin)",
    "IBCS": "Computer Science",
    "IBDA": "Dance",
    "IBDT": "Design Technology",
    "IBES": "Environmental Systems and Societies",
    "IBFI": "Film",
    "IBGP": "Global Politics",
    "IBLBF": "Language B French",
    "IBLBS": "Language B Spanish",
    "IBLP": "Literature and Performance",
    "IBMU": "Music",
    "IBPL": "Philosophy",
    "IBSA": "Social and Cultural Anthropology",
    "IBSE": "Sports, Exercise and Health Science",
    "IBTH": "Theatre",
    "IBVA": "Visual Arts",
    "IBWR": "World Religions",
}


def _rel(path: Path, root: Path = ROOT) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _read_profile(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    code = str(data.get("syllabus_code") or "").strip()
    if not code:
        raise ValueError(f"profile has no syllabus_code: {_rel(path)}")
    if not isinstance(data.get("major_topics"), list) or not data["major_topics"]:
        raise ValueError(f"profile has no major_topics: {_rel(path)}")
    if not isinstance(data.get("classification_keywords"), dict) or not data["classification_keywords"]:
        raise ValueError(f"profile has no classification_keywords: {_rel(path)}")
    return data


def build_catalogue(existing: dict, *, root: Path = ROOT,
                    generated_at: Optional[str] = None) -> dict:
    """Return a reconciled catalogue payload without writing files."""
    profile_root = root / "subjects_ib" / "DP"
    old_rows = list(existing.get("subjects") or [])
    old_ib_rows = [r for r in old_rows if str(r.get("board", "")).upper() == "IB"]
    old_profiles = {str(r.get("code") or ""): r for r in old_ib_rows
                    if r.get("profile") and r.get("catalogue_status") == "PROFILE"}
    old_alias_rows = {str(r.get("code") or ""): r for r in old_ib_rows
                      if r.get("catalogue_status") == "TAXONOMY_ONLY"}

    profile_files = sorted(profile_root.glob("*/config.json"))
    if not profile_files:
        raise ValueError(f"no IB DP profiles found under {profile_root}")
    unmapped_legacy_rows = sorted(set(old_alias_rows) - set(LEGACY_ALIAS_TO_PROFILE))
    if unmapped_legacy_rows:
        raise ValueError(f"unmapped legacy IB taxonomy rows: {unmapped_legacy_rows}")

    aliases_by_code: Dict[str, List[str]] = {}
    legacy_by_code: Dict[str, List[dict]] = {}
    for alias, canonical in LEGACY_ALIAS_TO_PROFILE.items():
        aliases_by_code.setdefault(canonical, []).append(alias)
        legacy = old_alias_rows.get(alias)
        if legacy:
            legacy_by_code.setdefault(canonical, []).append({
                "code": alias,
                "taxonomy_reference": legacy.get("taxonomy"),
                "reference_exists": bool(legacy.get("taxonomy") and
                                          (root / str(legacy["taxonomy"])).is_file()),
                "legacy_sources": list(legacy.get("sources") or []),
            })

    ib_rows: List[dict] = []
    seen_codes = set()
    for path in profile_files:
        data = _read_profile(path)
        code = str(data["syllabus_code"]).strip()
        if code in seen_codes:
            raise ValueError(f"duplicate IB profile code: {code}")
        seen_codes.add(code)
        previous = old_profiles.get(code, {})
        display_subject = str(previous.get("subject") or DISPLAY_NAMES.get(code) or "").strip()
        if not display_subject:
            # Conservative fallback: remove the internal code suffix and render
            # the profile slug as words; use DISPLAY_NAMES for irregular names.
            slug = path.parent.name
            marker = f"_{code}"
            if slug.endswith(marker):
                slug = slug[:-len(marker)]
            display_subject = slug.replace("_", " ")
        majors = list(data.get("major_topics") or [])
        keywords = data.get("classification_keywords") or {}
        all_terms = {str(term).strip().casefold() for terms in keywords.values()
                     for term in (terms or []) if str(term).strip()}
        source_url = data.get("official_source") or data.get("specification_pdf") or previous.get("spec_url")
        sha = data.get("syllabus_source_sha256") or previous.get("spec_sha256")
        profile_rel = _rel(path, root)

        row = dict(previous)
        row.update({
            "board": "IB",
            "qualification": "DP",
            "code": code,
            "subject": display_subject,
            "display_name": f"IB DP {display_subject}",
            "profile": profile_rel,
            "catalogue_status": "PROFILE",
            "support_status": previous.get("support_status") or "PROFILE_UNVALIDATED",
            "majors": majors,
            "major_count": len(majors),
            "keywords": int(previous.get("keywords") or len(all_terms)),
            "spec_url": source_url,
            "spec_sha256": sha,
            "taxonomy": None,
            "aliases": sorted(set(aliases_by_code.get(code, []))),
            "sources": [profile_rel],
            "validation_status": (
                "PDF_VALIDATION_PENDING" if source_url
                else "PROFILE_PRESENT_SOURCE_UNVERIFIED_PDF_VALIDATION_PENDING"
            ),
        })
        legacy_refs = list(previous.get("legacy_taxonomy_references") or [])
        for ref in legacy_by_code.get(code, []):
            if ref not in legacy_refs:
                legacy_refs.append(ref)
        if legacy_refs:
            row["legacy_taxonomy_references"] = legacy_refs
        else:
            row.pop("legacy_taxonomy_references", None)
        ib_rows.append(row)

    removed_profile_rows = sorted(set(old_profiles) - seen_codes)
    if removed_profile_rows:
        raise ValueError(f"catalogue profiles no longer exist on disk: {removed_profile_rows}")
    missing_alias_targets = sorted(set(LEGACY_ALIAS_TO_PROFILE.values()) - seen_codes)
    if missing_alias_targets:
        raise ValueError(f"legacy aliases target missing profile codes: {missing_alias_targets}")

    alias_owners: Dict[str, str] = {}
    for row in ib_rows:
        for alias in row.get("aliases", []):
            if alias in seen_codes:
                raise ValueError(f"alias {alias!r} collides with a canonical IB code")
            if alias in alias_owners and alias_owners[alias] != row["code"]:
                raise ValueError(f"alias {alias!r} has multiple owners")
            alias_owners[alias] = row["code"]

    ib_rows.sort(key=lambda r: (str(r["subject"]).casefold(), str(r["code"])))
    non_ib_rows = [r for r in old_rows if str(r.get("board", "")).upper() != "IB"]
    first_ib_pos = next((i for i, r in enumerate(old_rows)
                         if str(r.get("board", "")).upper() == "IB"), len(old_rows))
    insert_at = sum(1 for r in old_rows[:first_ib_pos]
                    if str(r.get("board", "")).upper() != "IB")
    subjects = non_ib_rows[:insert_at] + ib_rows + non_ib_rows[insert_at:]

    counts = Counter(str(r.get("board") or "") for r in subjects)
    old_counts = dict(existing.get("counts") or {})
    board_names = list(existing.get("boards") or [])
    for board in sorted(counts):
        if board and board not in board_names:
            board_names.append(board)
    out = dict(existing)
    out["schema"] = str(existing.get("schema") or "subjects_catalogue/1")
    out["generated_by"] = "tools/generate_subjects_catalogue.py"
    out["generated_at"] = generated_at or str(existing.get("generated_at") or
                                                datetime.now(timezone.utc).replace(microsecond=0).isoformat())
    out["boards"] = board_names
    out["counts"] = {**{b: int(counts.get(b, 0)) for b in board_names}, "total": len(subjects)}
    out["subjects"] = subjects
    return out


def _atomic_write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=path.name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--check", action="store_true", help="check for catalogue drift without writing")
    parser.add_argument("--out", default=str(CATALOGUE), help="catalogue JSON to read/write")
    args = parser.parse_args(argv)
    path = Path(args.out).resolve()
    try:
        current = json.loads(path.read_text(encoding="utf-8"))
        updated = build_catalogue(current, generated_at=str(current.get("generated_at") or ""))
    except Exception as exc:
        parser.exit(2, f"[catalogue] ERROR: {type(exc).__name__}: {exc}\n")
    if args.check:
        if updated == current:
            print(f"[catalogue] OK: {sum(1 for r in updated['subjects'] if r.get('board') == 'IB')} IB profile rows")
            return 0
        print("[catalogue] DRIFT: run tools/generate_subjects_catalogue.py to reconcile")
        return 1
    updated["generated_at"] = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    _atomic_write(path, updated)
    print(f"[catalogue] wrote {path}: {updated['counts'].get('IB', 0)} IB profiles / {updated['counts']['total']} total subjects")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
