"""Build module-aware SAT official answer companions for practice tests 4-11.

College Board publishes a scoring guide (answer key) and a separate Answer
Explanations PDF. This importer extracts the answer explanation for each exact
section/module/question into ``*_MS.webp`` and writes its scoring-guide answer to
``*_MS.txt``. It intentionally does not include source PDFs in the output.

Example:
    python tools/build_sat_answer_companions.py \
      --out /home/user/SAT_Official_Companions \
      --cache-dir /tmp/sat_official_compat

The ID is module-aware because SAT question numbers restart in every module:
``SAT_T04_RW_M1_Q01``. Thus Reading/Writing M1 Q1 and Math M1 Q1 can never be
mistaken for one another.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import fitz  # PyMuPDF
import requests
from PIL import Image

BASE_URL = "https://satsuite.collegeboard.org/media/pdf"
SECTIONS = ("RW", "MATH")
MODULES = (1, 2)
COLUMN_ORDER = (("RW", 1), ("RW", 2), ("MATH", 1), ("MATH", 2))
SCALE = 1.25
PAGE_BODY_TOP = 64.0
PAGE_BODY_BOTTOM_MARGIN = 60.0
QUESTION_HEADING = re.compile(r"^\s*QUESTION\s+(\d{1,2})\s*$", re.I)
MODULE_HEADER = re.compile(
    r"(?:READING\s+AND\s+WRITING|MATH)\s*:\s*MODULE\s*([12])", re.I
)
KEY_ROW = re.compile(r"^\s*(\d{1,2})\s+(.+?)\s*$")
MCQ_CORRECT = re.compile(
    r"\bChoice\s+([ABCD])\s+is\s+(?:(?:the\s+)?best\s+answer|(?:the\s+)?correct\s+answer|correct)\b",
    re.I,
)


@dataclass(frozen=True)
class Marker:
    section: str
    module: int
    question: int
    page_index: int
    y0: float
    bbox: tuple[float, float, float, float]

    @property
    def key(self) -> tuple[str, int, int]:
        return self.section, self.module, self.question


@dataclass
class AnswerEntry:
    answer: str
    page_index: int


def official_urls(test: int) -> dict[str, str]:
    return {
        "scoring_guide": f"{BASE_URL}/scoring-sat-practice-test-{test}-digital.pdf",
        "answer_explanations": f"{BASE_URL}/sat-practice-test-{test}-answers-digital.pdf",
    }


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _download(url: str, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.stat().st_size > 20_000:
        return path
    response = requests.get(url, timeout=90)
    response.raise_for_status()
    if not response.content.startswith(b"%PDF"):
        raise ValueError(f"Official source did not return a PDF: {url}")
    path.write_bytes(response.content)
    return path


def get_sources(test: int, cache_dir: str | Path) -> dict[str, Path]:
    root = Path(cache_dir)
    urls = official_urls(test)
    names = {
        "scoring_guide": f"sat-practice-test-{test}-scoring-digital.pdf",
        "answer_explanations": f"sat-practice-test-{test}-answers-digital.pdf",
    }
    return {kind: _download(url, root / names[kind]) for kind, url in urls.items()}


def _line_records(page: fitz.Page) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for block in page.get_text("dict").get("blocks", []):
        for line in block.get("lines", []):
            text = "".join(span.get("text", "") for span in line.get("spans", [])).strip()
            bbox = tuple(float(v) for v in line.get("bbox", (0, 0, 0, 0)))
            if text and len(bbox) == 4:
                records.append({"text": text, "bbox": bbox})
    return sorted(records, key=lambda r: (r["bbox"][1], r["bbox"][0]))


def _page_section_module(text: str) -> tuple[str, int] | None:
    """Read the repeated official running header that labels each explanation page."""
    # The current College Board PDFs use the exact running-header construction
    # "SAT ANSWER EXPLANATIONS n READING AND WRITING: MODULE 1" (or MATH).
    if "SAT ANSWER EXPLANATIONS" not in text.upper():
        return None
    match = MODULE_HEADER.search(text)
    if not match:
        return None
    section = "RW" if re.search(r"READING\s+AND\s+WRITING\s*:\s*MODULE", text, re.I) else "MATH"
    return section, int(match.group(1))


def _question_markers(page: fitz.Page, section: str, module: int, page_index: int) -> list[Marker]:
    lines = _line_records(page)
    markers: list[Marker] = []
    i = 0
    while i < len(lines):
        text = lines[i]["text"]
        bbox = lines[i]["bbox"]
        match = QUESTION_HEADING.fullmatch(text)
        # Defensive support for PDFs whose text layer separates QUESTION and
        # the number onto adjacent lines; the official Tests 4-11 currently use
        # a single line, but this keeps the importer resilient to reflow.
        if text.upper() == "QUESTION" and i + 1 < len(lines):
            next_text = lines[i + 1]["text"].strip()
            if re.fullmatch(r"\d{1,2}", next_text) and lines[i + 1]["bbox"][1] - bbox[3] < 8:
                n = int(next_text)
                next_bbox = lines[i + 1]["bbox"]
                bbox = (min(bbox[0], next_bbox[0]), bbox[1], max(bbox[2], next_bbox[2]), next_bbox[3])
                markers.append(Marker(section, module, n, page_index, bbox[1], bbox))
                i += 2
                continue
        if match:
            markers.append(Marker(section, module, int(match.group(1)), page_index, bbox[1], bbox))
        i += 1
    return markers


def parse_explanation_markers(doc: fitz.Document) -> tuple[dict[tuple[str, int], list[int]], list[Marker]]:
    module_pages: dict[tuple[str, int], list[int]] = {}
    markers: list[Marker] = []
    for page_index, page in enumerate(doc):
        text = page.get_text()
        module_key = _page_section_module(text)
        if module_key is None:
            continue
        module_pages.setdefault(module_key, []).append(page_index)
        markers.extend(_question_markers(page, module_key[0], module_key[1], page_index))
    markers.sort(key=lambda m: (m.page_index, m.y0))
    return module_pages, markers


def parse_scoring_guide(doc: fitz.Document) -> tuple[dict[tuple[str, int, int], AnswerEntry], int]:
    """Read the four answer-key columns, preserving numeric accepted-answer forms."""
    key_page_index: int | None = None
    key_page: fitz.Page | None = None
    for page_index, page in enumerate(doc):
        low = page.get_text().lower()
        # Some scoring guides repeat a tiny rasterized/text-layer preview of the
        # answer worksheet on the instructions page. Select the actual worksheet
        # title in the top page band, not that embedded preview.
        has_top_answer_key_title = any(
            row["text"].strip().lower() == "answer key" and row["bbox"][1] < 150
            for row in _line_records(page)
        )
        if has_top_answer_key_title and "mark each of your correct answers below" in low:
            key_page_index, key_page = page_index, page
            break
    if key_page is None or key_page_index is None:
        raise ValueError("Could not locate the scoring guide's Answer Key worksheet")

    lines = _line_records(key_page)
    header_xs = sorted(
        r["bbox"][0] for r in lines
        if re.search(r"QUESTION\s*#", r["text"], re.I)
    )
    # Deduplicate near-identical text spans and require all four table columns.
    unique_xs: list[float] = []
    for x in header_xs:
        if not unique_xs or abs(x - unique_xs[-1]) > 20:
            unique_xs.append(x)
    if len(unique_xs) != 4:
        raise ValueError(f"Expected four answer-key columns, found x positions {unique_xs}")

    tables: dict[tuple[str, int], dict[int, str]] = {key: {} for key in COLUMN_ORDER}
    # The answer-key grid encodes the question number and correct response as
    # separate PDF text spans/words. Group words by baseline and use the four
    # QUESTION # x-anchors; do not rely on plain-text extraction's column order.
    words = [w for w in key_page.get_text("words") if 225 <= float(w[1]) <= 640]
    for column, anchor_x in enumerate(unique_xs):
        right = unique_xs[column + 1] - 4.0 if column < 3 else float(key_page.rect.width)
        candidate_words = [w for w in words if anchor_x - 5.0 <= float(w[0]) <= anchor_x + 5.0 and re.fullmatch(r"\d{1,2}", str(w[4]).strip())]
        for candidate in candidate_words:
            qn = int(str(candidate[4]).strip())
            baseline = float(candidate[1])
            row_words = [
                w for w in words
                if anchor_x - 5.0 <= float(w[0]) < right
                and abs(float(w[1]) - baseline) <= 2.0
            ]
            row_words.sort(key=lambda w: float(w[0]))
            answer_tokens = [str(w[4]) for w in row_words if float(w[0]) > float(candidate[0]) + 1.0]
            answer = " ".join(answer_tokens).strip()
            if not answer:
                continue
            section_module = COLUMN_ORDER[column]
            existing = tables[section_module].get(qn)
            if existing is not None and existing != answer:
                raise ValueError(f"Conflicting scoring-guide answers for {section_module} Q{qn}: {existing!r} vs {answer!r}")
            tables[section_module][qn] = answer

    answers: dict[tuple[str, int, int], AnswerEntry] = {}
    for section_module, rows in tables.items():
        if not rows:
            raise ValueError(f"No scoring-guide answers parsed for {section_module}")
        expected_max = max(rows)
        expected = set(range(1, expected_max + 1))
        if set(rows) != expected:
            raise ValueError(f"Noncontiguous answer-key numbers for {section_module}: {sorted(rows)}")
        for qn, answer in rows.items():
            answers[(section_module[0], section_module[1], qn)] = AnswerEntry(answer, key_page_index)
    return answers, key_page_index


def _page_body_bounds(page: fitz.Page) -> tuple[float, float]:
    height = float(page.rect.height)
    lines = [
        line["bbox"] for line in _line_records(page)
        if line["bbox"][1] >= PAGE_BODY_TOP and line["bbox"][3] <= height - PAGE_BODY_BOTTOM_MARGIN
    ]
    if not lines:
        return PAGE_BODY_TOP, height - PAGE_BODY_BOTTOM_MARGIN
    return min(b[1] for b in lines), max(b[3] for b in lines)


def _extract_crop_regions(
    doc: fitz.Document,
    module_pages: dict[tuple[str, int], list[int]],
    markers: list[Marker],
) -> dict[tuple[str, int, int], tuple[list[tuple[int, fitz.Rect]], str, list[int]]]:
    by_module: dict[tuple[str, int], list[Marker]] = {}
    for marker in markers:
        by_module.setdefault((marker.section, marker.module), []).append(marker)
    out: dict[tuple[str, int, int], tuple[list[tuple[int, fitz.Rect]], str, list[int]]] = {}

    for module_key, module_markers in by_module.items():
        pages = module_pages[module_key]
        for index, marker in enumerate(module_markers):
            next_marker = module_markers[index + 1] if index + 1 < len(module_markers) else None
            start_page = marker.page_index
            end_page = next_marker.page_index if next_marker else pages[-1]
            if start_page not in pages or end_page not in pages:
                raise ValueError(f"Explanation marker points outside module page range: {marker}")
            regions: list[tuple[int, fitz.Rect]] = []
            text_lines: list[str] = []
            used_pages: list[int] = []
            for page_index in range(start_page, end_page + 1):
                if page_index not in pages:
                    # Module page ranges are contiguous in all official T4-T11
                    # source PDFs. Fail closed if a future PDF interleaves them.
                    raise ValueError(f"Noncontiguous module pages for {module_key}: page {page_index + 1}")
                page = doc[page_index]
                body_top, body_bottom = _page_body_bounds(page)
                top = max(body_top, marker.y0 - 5.0) if page_index == start_page else body_top
                if next_marker is not None and page_index == end_page:
                    bottom = min(body_bottom, next_marker.y0 - 5.0)
                else:
                    bottom = body_bottom
                if bottom - top < 4:
                    continue
                rect = fitz.Rect(0, top, page.rect.width, bottom)
                regions.append((page_index, rect))
                used_pages.append(page_index + 1)
                for record in _line_records(page):
                    x0, y0, x1, y1 = record["bbox"]
                    if y0 >= top and y1 <= bottom and y0 >= PAGE_BODY_TOP and y1 <= page.rect.height - PAGE_BODY_BOTTOM_MARGIN:
                        text_lines.append(record["text"])
            if not regions:
                raise ValueError(f"Empty explanation crop for {marker.key}")
            out[marker.key] = (regions, "\n".join(text_lines), used_pages)
    return out


def _compose_webp(doc: fitz.Document, regions: list[tuple[int, fitz.Rect]], path: Path) -> None:
    crops: list[Image.Image] = []
    for page_index, rect in regions:
        pix = doc[page_index].get_pixmap(matrix=fitz.Matrix(SCALE, SCALE), clip=rect, alpha=False)
        crops.append(Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB"))
    width = max(img.width for img in crops)
    gap = int(12 * SCALE)
    height = sum(img.height for img in crops) + gap * max(0, len(crops) - 1)
    result = Image.new("RGB", (width, height), "white")
    y = 0
    for image in crops:
        result.paste(image, (0, y))
        y += image.height + gap
        image.close()
    path.parent.mkdir(parents=True, exist_ok=True)
    result.save(path, "WEBP", quality=92, method=6)
    result.close()


def _consistency_status(answer: str, explanation_text: str) -> str:
    if not re.fullmatch(r"[ABCD]", answer.strip(), re.I):
        return "not_applicable_free_response"
    letters = {m.group(1).upper() for m in MCQ_CORRECT.finditer(explanation_text)}
    if not letters:
        return "no_explicit_choice_statement"
    if letters == {answer.strip().upper()}:
        return "matches_scoring_guide"
    return "mismatch_with_scoring_guide" if answer.strip().upper() not in letters else "ambiguous_choice_statements"


def _question_id(test: int, section: str, module: int, question: int) -> str:
    return f"SAT_T{test:02d}_{section}_M{module}_Q{question:02d}"


def _answer_txt(test: int, section: str, module: int, question: int, answer: str, guide_page: int) -> str:
    label = "Reading and Writing" if section == "RW" else "Math"
    return (
        f"Correct answer: {answer}\n"
        f"Verified against: SAT Practice Test #{test} Scoring Guide, p. {guide_page}; "
        f"{label}, Module {module}, Question {question}.\n"
    )


def build_test(test: int, *, out_dir: str | Path, cache_dir: str | Path, force: bool = False) -> dict[str, Any]:
    out_dir, cache_dir = Path(out_dir), Path(cache_dir)
    sources = get_sources(test, cache_dir)
    urls = official_urls(test)
    scoring_doc = fitz.open(sources["scoring_guide"])
    explanation_doc = fitz.open(sources["answer_explanations"])
    try:
        answers, answer_key_page_index = parse_scoring_guide(scoring_doc)
        module_pages, markers = parse_explanation_markers(explanation_doc)
        if not markers:
            raise ValueError(f"No question headings found in Test {test} answer-explanations PDF")
        regions = _extract_crop_regions(explanation_doc, module_pages, markers)
        marker_keys = {m.key for m in markers}
        answer_keys = set(answers)
        if marker_keys != answer_keys:
            missing_explanations = sorted(answer_keys - marker_keys)
            missing_answers = sorted(marker_keys - answer_keys)
            raise ValueError(
                f"Test {test} answer/explanation coverage mismatch; "
                f"missing explanations={missing_explanations[:10]}, "
                f"missing scoring answers={missing_answers[:10]}"
            )

        test_dir = out_dir / f"SAT_T{test:02d}"
        test_dir.mkdir(parents=True, exist_ok=True)
        records: list[dict[str, Any]] = []
        statuses: dict[str, int] = {}
        for marker in markers:
            question_key = marker.key
            entry = answers[question_key]
            crop_regions, explanation_text, source_pages = regions[question_key]
            qid = _question_id(test, marker.section, marker.module, marker.question)
            image_name = f"{qid}_MS.webp"
            answer_name = f"{qid}_MS.txt"
            image_path = test_dir / image_name
            answer_path = test_dir / answer_name
            if force or not image_path.exists():
                _compose_webp(explanation_doc, crop_regions, image_path)
            if force or not answer_path.exists():
                answer_path.write_text(
                    _answer_txt(test, marker.section, marker.module, marker.question, entry.answer, entry.page_index + 1),
                    encoding="utf-8",
                )
            consistency = _consistency_status(entry.answer, explanation_text)
            statuses[consistency] = statuses.get(consistency, 0) + 1
            if consistency == "mismatch_with_scoring_guide":
                raise ValueError(f"Test {test} {qid}: explanation's explicit correct choice conflicts with scoring guide")
            records.append({
                "id": qid,
                "section": "READING_AND_WRITING" if marker.section == "RW" else "MATH",
                "section_code": marker.section,
                "module": marker.module,
                "question_number": marker.question,
                "correct_answer": entry.answer,
                "answer_verification": {
                    "status": "verified_against_official_scoring_guide",
                    "document": "scoring_guide",
                    "source_page": entry.page_index + 1,
                    "key_column": f"{marker.section} Module {marker.module}",
                },
                "explanation_source": {
                    "document": "answer_explanations",
                    "source_pages": source_pages,
                },
                "explanation_answer_consistency": consistency,
                "files": {
                    "ms_explanation_crop": image_name,
                    "ms_answer_text": answer_name,
                    "question_paper_companion_stem": f"{qid}_QP.webp",
                },
            })

        expected_rows = _answer_counts(answers)
        metadata = {
            "schema_version": "1.0",
            "dataset": "College Board SAT Official Practice Test Answer Companions",
            "board": "College Board",
            "program": "SAT",
            "practice_test": test,
            "question_count": len(records),
            "module_counts": {f"{k[0]}_M{k[1]}": count for k, count in expected_rows.items()},
            "sources": {
                "scoring_guide": {"url": urls["scoring_guide"], "sha256": _sha256(sources["scoring_guide"]), "answer_key_page": answer_key_page_index + 1},
                "answer_explanations": {"url": urls["answer_explanations"], "sha256": _sha256(sources["answer_explanations"])},
            },
            "matching": {
                "status": "verified",
                "method": "section + module running header + QUESTION heading; answers read from the matching scoring-guide module column",
                "explanation_answer_consistency_counts": statuses,
            },
            "questions": records,
        }
        (test_dir / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        return metadata
    finally:
        scoring_doc.close()
        explanation_doc.close()


def _answer_counts(answers: dict[tuple[str, int, int], AnswerEntry]) -> dict[tuple[str, int], int]:
    counts: dict[tuple[str, int], int] = {}
    for section, module, _qn in answers:
        counts[(section, module)] = counts.get((section, module), 0) + 1
    return counts


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True, help="separate companion output directory; do not point this inside the clean project ZIP")
    parser.add_argument("--cache-dir", type=Path, default=Path("/tmp/sat_official_compat"), help="outside-project cache for the official source PDFs")
    parser.add_argument("--tests", default="4-11", help="test range (4-11) or comma-separated values, e.g. 4,5,6")
    parser.add_argument("--force", action="store_true", help="regenerate existing image crops and text files")
    args = parser.parse_args(list(argv) if argv is not None else None)
    tests: list[int] = []
    for part in args.tests.split(","):
        part = part.strip()
        if "-" in part:
            start, end = map(int, part.split("-", 1))
            tests.extend(range(start, end + 1))
        elif part:
            tests.append(int(part))
    if not tests or any(t < 4 or t > 11 for t in tests):
        parser.error("Only official SAT Practice Tests 4 through 11 are supported")
    summary = []
    for test in sorted(set(tests)):
        metadata = build_test(test, out_dir=args.out, cache_dir=args.cache_dir, force=args.force)
        counts = metadata["matching"]["explanation_answer_consistency_counts"]
        print(f"Test {test}: {metadata['question_count']} questions; consistency={counts}")
        summary.append({"test": test, "question_count": metadata["question_count"], "module_counts": metadata["module_counts"], "consistency": counts})
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "build_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
