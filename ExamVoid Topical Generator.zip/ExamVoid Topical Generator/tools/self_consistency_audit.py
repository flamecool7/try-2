#!/usr/bin/env python3
"""Self-consistency smoke audit across Maths/Physics/Chemistry/Biology/CompSci.

For every detailed topic in every matching subject config, build a short
synthetic question from that topic's OWN classification_keywords (its most
distinctive, longest phrases) and check the classifier resolves it back to
the major topic that detailed topic maps to.

This is not a substitute for real-question golden-set testing (passing is
necessary but not sufficient for real-world accuracy), but it cheaply
surfaces, at scale, the exact bug classes already found by hand this
project: topics with no usable keywords, keyword collisions where another
topic's vocabulary dominates a topic's own defining terms, and anchor/
override mechanics misfiring. A FAIL here is a strong, free signal of a
real config problem worth a closer look.

Usage:
    python3 tools/self_consistency_audit.py [--subjects physics,chemistry,...]
    python3 tools/self_consistency_audit.py --only subjects_caie/A-Level/Mathematics_9709/config.json
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from tools.classify_text import load_classifier, classify  # noqa: E402

DEFAULT_TARGETS = [
    "mathematics", "further_mathematics", "additional_mathematics",
    "physics", "chemistry", "biology", "computer_science",
    "combined_science", "coordinated_sciences", "science",
]


def find_configs(target_words):
    rows = []
    for cfgpath in sorted(glob.glob(str(REPO / "subjects_*/*/*/config.json"))):
        rel = os.path.relpath(cfgpath, REPO)
        parts = rel.split(os.sep)
        subj = parts[2].lower()
        if any(t in subj for t in target_words):
            rows.append(rel)
    return rows


def synth_text(keywords, min_phrases=2, max_phrases=4):
    """Build a plausible short question stem from a topic's own vocabulary."""
    phrases = [k for k in keywords if isinstance(k, str) and k.strip()]
    # prefer longer (more specific, multi-word) phrases first
    phrases = sorted(set(phrases), key=lambda p: (-len(p.split()), p))
    chosen = phrases[:max_phrases] if len(phrases) >= min_phrases else phrases
    if not chosen:
        return ""
    sentences = [f"Explain {p}." if i == 0 else f"Describe {p}."
                 for i, p in enumerate(chosen)]
    return " ".join(sentences)


def audit_config(cfgpath):
    classifier, cfg = load_classifier(str(REPO / cfgpath))
    kw_map = cfg.classification_keywords or {}
    mapping = cfg.mapping or {}
    out = []
    for det in cfg.detailed_topics:
        expected_major = mapping.get(det, det)
        kws = kw_map.get(det) or kw_map.get(expected_major) or []
        text = synth_text(kws)
        if not text:
            out.append({"config": cfgpath, "detailed": det, "expected": expected_major,
                        "predicted": None, "status": "NO_KEYWORDS", "text": ""})
            continue
        try:
            result = classify(classifier, text, question_number=1)
            predicted = result.winning_major
            status = "OK" if predicted == expected_major else "MISMATCH"
        except Exception as exc:  # pragma: no cover
            predicted = None
            status = f"ERROR:{type(exc).__name__}:{exc}"[:120]
        out.append({"config": cfgpath, "detailed": det, "expected": expected_major,
                    "predicted": predicted, "status": status, "text": text[:160]})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--subjects", default=",".join(DEFAULT_TARGETS))
    ap.add_argument("--only", default=None, help="single config path to audit")
    ap.add_argument("--json-out", default=None)
    args = ap.parse_args()

    configs = [args.only] if args.only else find_configs(args.subjects.split(","))
    print(f"Auditing {len(configs)} configs...\n")

    all_rows = []
    totals = {"OK": 0, "MISMATCH": 0, "NO_KEYWORDS": 0, "ERROR": 0}
    per_config = {}
    for cfgpath in configs:
        rows = audit_config(cfgpath)
        all_rows.extend(rows)
        ok = sum(1 for r in rows if r["status"] == "OK")
        bad = [r for r in rows if r["status"] != "OK"]
        per_config[cfgpath] = (ok, len(rows), bad)
        for r in rows:
            key = r["status"] if r["status"] in totals else "ERROR"
            totals[key] = totals.get(key, 0) + 1

    print(f"{'config':65s} {'ok/total':>10s}")
    for cfgpath, (ok, total, bad) in per_config.items():
        flag = "" if ok == total else "  <-- issues"
        print(f"{cfgpath:65s} {ok:3d}/{total:<5d}{flag}")

    print()
    print("=" * 90)
    print(f"TOTALS: {totals}")
    print("=" * 90)

    print("\nDETAIL OF NON-OK ROWS:\n")
    for cfgpath, (ok, total, bad) in per_config.items():
        if not bad:
            continue
        print(f"--- {cfgpath} ---")
        for r in bad:
            print(f"  [{r['status']}] detailed={r['detailed']} expected={r['expected']} "
                  f"predicted={r['predicted']}")
            print(f"      text: {r['text']}")
        print()

    if args.json_out:
        Path(args.json_out).write_text(json.dumps(all_rows, indent=2), encoding="utf-8")
        print(f"Wrote full detail to {args.json_out}")


if __name__ == "__main__":
    main()
