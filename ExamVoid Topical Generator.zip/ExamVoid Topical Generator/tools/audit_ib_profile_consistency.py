#!/usr/bin/env python3
"""Run a taxonomy-derived runtime smoke audit over every IB DP profile.

This is deliberately a *self-consistency* check, not an accuracy audit: each
synthetic prompt uses a discriminative phrase taken from that same profile's
classification_keywords. Independent official QP/MS labels are required to
claim accuracy.

Usage:
    python tools/audit_ib_profile_consistency.py
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
PROFILE_ROOT = ROOT / "subjects_ib" / "DP"
JSON_OUT = ROOT / "reports" / "ib_profile_consistency_audit.json"
CSV_OUT = ROOT / "reports" / "ib_profile_consistency_audit.csv"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapters.ib.classification import classify_text, load_profile  # noqa: E402


def _normalise_keyword(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _choose_keyword_rows(profile: dict) -> List[Tuple[str, str]]:
    topics = [str(t) for t in profile.get("major_topics", [])]
    keywords = profile.get("classification_keywords") or {}
    term_frequency: Counter[str] = Counter()
    by_topic: Dict[str, List[str]] = {}
    for topic in topics:
        terms = sorted({_normalise_keyword(k) for k in keywords.get(topic, []) if _normalise_keyword(k)})
        by_topic[topic] = terms
        term_frequency.update({t.casefold() for t in terms})

    out: List[Tuple[str, str]] = []
    for topic in topics:
        terms = by_topic.get(topic) or []
        if not terms:
            continue

        def overlap_count(term: str) -> int:
            folded = term.casefold()
            return sum(
                1 for other_topic, other_terms in by_topic.items() if other_topic != topic
                for other in other_terms
                if other.casefold() != folded
                and (other.casefold() in folded or folded in other.casefold())
            )

        # Prefer a keyword with no cross-topic substring collision. This avoids
        # choosing a long phrase whose distinctive tail follows a generic exact
        # token (e.g. "Government of India Act" in a neighbouring topic).
        # Deterministic tie-breaks keep reports reproducible.
        chosen = max(
            terms,
            key=lambda t: (
                -overlap_count(t),
                term_frequency[t.casefold()] == 1,
                len(t.split()) > 1,
                min(len(t), 120),
                t.casefold(),
            ),
        )
        out.append((topic, chosen))
    return out


def _candidate_topics(result: dict) -> List[dict]:
    if result.get("status") == "REVIEW_REQUIRED":
        return list(result.get("candidates") or [])
    return [{"topic": result.get("topic"), "score": None}]


def run_audit(*, profile_root: Path = PROFILE_ROOT) -> dict:
    profiles_out: List[dict] = []
    question_rows: List[dict] = []
    failures: List[dict] = []
    for config_path in sorted(profile_root.glob("*/config.json")):
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
            code = str(config.get("syllabus_code") or "").strip()
            if not code:
                raise ValueError("missing syllabus_code")
            loaded, classifier = load_profile(code)
            if loaded is None or classifier is None:
                raise RuntimeError("profile did not load through IB runtime")
            examples = _choose_keyword_rows(config)
            per_topic: List[dict] = []
            for qn, (topic, keyword) in enumerate(examples, start=1):
                prompt = f"Explain the significance of {keyword}."
                try:
                    result = classify_text(code, prompt, question_number=qn, component="")
                    row = {
                        "profile": config_path.parent.name,
                        "subject_code": code,
                        "subject": str(config.get("qualification") or config.get("subject") or config_path.parent.name),
                        "expected_topic": topic,
                        "keyword": keyword,
                        "status": str(result.get("status") or ""),
                        "predicted_topic": str(result.get("topic") or ""),
                        "confidence": result.get("confidence"),
                        "self_match": bool(result.get("status") == "HINT" and result.get("topic") == topic),
                        "candidates": _candidate_topics(result),
                        "reasoning": str(result.get("reasoning") or "")[:400],
                    }
                except Exception as exc:  # keep the remainder of the board auditable
                    row = {
                        "profile": config_path.parent.name,
                        "subject_code": code,
                        "subject": str(config.get("qualification") or config.get("subject") or config_path.parent.name),
                        "expected_topic": topic,
                        "keyword": keyword,
                        "status": "ERROR",
                        "predicted_topic": "",
                        "confidence": None,
                        "self_match": False,
                        "candidates": [],
                        "reasoning": f"{type(exc).__name__}: {exc}",
                    }
                per_topic.append(row)
                question_rows.append(row)

            hint_count = sum(r["status"] == "HINT" for r in per_topic)
            review_count = sum(r["status"] == "REVIEW_REQUIRED" for r in per_topic)
            match_count = sum(r["self_match"] for r in per_topic)
            profiles_out.append({
                "profile": config_path.parent.name,
                "subject_code": code,
                "subject": str(config.get("qualification") or config.get("subject") or config_path.parent.name),
                "topic_count": len(config.get("major_topics") or []),
                "sampled_topics": len(per_topic),
                "hints": hint_count,
                "reviews": review_count,
                "errors": sum(r["status"] == "ERROR" for r in per_topic),
                "self_matches": match_count,
                "self_match_rate": round(match_count / len(per_topic), 4) if per_topic else 0.0,
                "rows": per_topic,
            })
        except Exception as exc:
            failure = {"profile": config_path.parent.name,
                       "error": f"{type(exc).__name__}: {exc}"}
            failures.append(failure)
            profiles_out.append({"profile": config_path.parent.name, "subject_code": "",
                                 "topic_count": 0, "sampled_topics": 0, "hints": 0,
                                 "reviews": 0, "errors": 1, "self_matches": 0,
                                 "self_match_rate": 0.0, "rows": [], "error": failure["error"]})

    total = len(question_rows)
    hints = sum(row["status"] == "HINT" for row in question_rows)
    reviews = sum(row["status"] == "REVIEW_REQUIRED" for row in question_rows)
    errors = sum(row["status"] == "ERROR" for row in question_rows) + len(failures)
    matches = sum(bool(row["self_match"]) for row in question_rows)
    return {
        "schema": "ib_profile_consistency_audit/1",
        "audit_type": "taxonomy_derived_self_consistency_not_external_accuracy",
        "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "source_scope": "local subjects_ib/DP/*/config.json; synthetic prompts built from each profile's own keyword list",
        "profiles_found": len(list(profile_root.glob("*/config.json"))),
        "profiles_loaded": sum(1 for p in profiles_out if p.get("subject_code")),
        "profiles": profiles_out,
        "summary": {
            "sampled_topic_cases": total,
            "hints": hints,
            "reviews": reviews,
            "errors": errors,
            "self_matches": matches,
            "self_match_rate": round(matches / total, 4) if total else 0.0,
            "coverage_hint_rate": round(hints / total, 4) if total else 0.0,
            "note": "Self-match and HINT rates measure only whether profile-derived synthetic phrases route to their source taxonomy topic. They are not precision/recall or official-paper accuracy.",
        },
        "failures": failures,
    }


def write_outputs(payload: dict, json_path: Path = JSON_OUT, csv_path: Path = CSV_OUT) -> None:
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = ["profile", "subject_code", "subject", "expected_topic", "keyword", "status",
              "predicted_topic", "confidence", "self_match", "candidates", "reasoning"]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for profile in payload["profiles"]:
            for row in profile.get("rows", []):
                out = dict(row)
                out["candidates"] = json.dumps(out.get("candidates") or [], ensure_ascii=False)
                writer.writerow({key: out.get(key, "") for key in fields})


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--profile-root", type=Path, default=PROFILE_ROOT)
    parser.add_argument("--json-out", type=Path, default=JSON_OUT)
    parser.add_argument("--csv-out", type=Path, default=CSV_OUT)
    args = parser.parse_args(argv)
    payload = run_audit(profile_root=args.profile_root)
    write_outputs(payload, args.json_out, args.csv_out)
    print(json.dumps(payload["summary"], indent=2))
    print(f"[IB audit] wrote {args.json_out} and {args.csv_out}")
    return 1 if payload["summary"]["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
