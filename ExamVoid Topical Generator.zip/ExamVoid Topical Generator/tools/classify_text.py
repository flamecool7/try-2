#!/usr/bin/env python3
"""Direct text-level classification harness (bypasses the PDF/crop pipeline).

Lets us test core.classifier.TopicClassifier against raw question text +
mark-scheme text for ANY board (CAIE / AQA / Edexcel / IB / SAT all share the
same classifier, only the subject config.json differs — see
adapters/aqa/classification.py for the production-code precedent this
mirrors).

This is for fast iteration / accuracy measurement only. It is NOT part of the
runtime pipeline and changes nothing about how main.py / run_guarded.py work.

Usage (library):
    from tools.classify_text import load_classifier, classify
    clf, cfg = load_classifier("subjects_caie/A-Level/Physics_9702/config.json")
    result = classify(clf, "A ball is dropped ... calculate the acceleration", marks=4)
    print(result.winning_major, result.detailed_topics[:1])
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from core.config_loader import SubjectConfig  # noqa: E402
from core.classifier import TopicClassifier, ClassificationResult  # noqa: E402

_CLASSIFIER_CACHE: Dict[str, Tuple[Any, Any]] = {}


def load_classifier(config_path: str, use_cache: bool = True):
    """(TopicClassifier, SubjectConfig) for any board's config.json path."""
    key = str(Path(config_path).resolve())
    if use_cache and key in _CLASSIFIER_CACHE:
        return _CLASSIFIER_CACHE[key]
    path = Path(config_path)
    if not path.is_absolute():
        path = REPO / path
    data = json.loads(path.read_text(encoding="utf-8"))
    config = SubjectConfig(data, config_path=path)
    classifier = TopicClassifier(config)
    _CLASSIFIER_CACHE[key] = (classifier, config)
    return classifier, config


def _stub_question(text: str, ms_text: str, question_number: Any, marks: Optional[int],
                    paper_code: str = "test") -> SimpleNamespace:
    """A MatchedQuestion-shaped object carrying raw text only (no PDF/crop involved)."""
    if marks is None:
        found = re.findall(r"\[(\d{1,2})\s*marks?\]", text or "", re.I)
        marks = sum(int(m) for m in found) if found else 0
    qp = SimpleNamespace(text=text or "", marks=marks, paper_code=paper_code,
                         question_number=f"Q{question_number}", number_int=int(question_number or 0),
                         assembled_image=None, images=[])
    ms = SimpleNamespace(text=ms_text or "", marks=marks, paper_code=paper_code,
                        question_number=f"Q{question_number}", number_int=int(question_number or 0),
                        assembled_image=None, images=[]) if ms_text else None
    return SimpleNamespace(question_number=f"Q{question_number}", number_int=int(question_number or 0),
                           qp=qp, ms=ms, paper_code=paper_code, full_qp_code=paper_code, full_ms_code="",
                           year="", season="", variant="", subject="", paper_format="STRUCTURED")


def classify(classifier: TopicClassifier, text: str, mark_scheme_text: str = "",
             question_number: Any = 1, marks: Optional[int] = None) -> ClassificationResult:
    matched = _stub_question(text, mark_scheme_text, question_number, marks)
    return classifier.classify_question(matched, mark_scheme_text=mark_scheme_text or "")


def classify_with_config(config_path: str, text: str, mark_scheme_text: str = "",
                          question_number: Any = 1, marks: Optional[int] = None) -> ClassificationResult:
    classifier, _cfg = load_classifier(config_path)
    return classify(classifier, text, mark_scheme_text, question_number, marks)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", required=True, help="path to a subject config.json")
    ap.add_argument("--text", required=True)
    ap.add_argument("--ms", default="")
    args = ap.parse_args()
    result = classify_with_config(args.config, args.text, args.ms)
    print("winning_major   :", result.winning_major)
    print("detailed_topics :", result.detailed_topics)
    print("fallback_tier   :", result.fallback_tier)
    print("confidence      :", result.confidence)
    print("reasoning       :", result.reasoning)
