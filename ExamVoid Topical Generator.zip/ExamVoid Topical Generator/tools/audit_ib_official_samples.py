#!/usr/bin/env python3
"""Classify a small set of public IB specimen/subject-brief prompts.

This is an external-source smoke audit, not an independently adjudicated
accuracy study. Each expected topic is a human mapping from the quoted prompt
to the repository's existing profile; ambiguous/multi-part prompts should not
be interpreted as gold-standard labels.
"""
from __future__ import annotations

import csv
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT_JSON = ROOT / "reports" / "ib_official_sample_audit.json"
OUT_CSV = ROOT / "reports" / "ib_official_sample_audit.csv"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapters.ib.classification import classify_text  # noqa: E402

# Short question excerpts only. Sources are official IBO specimen papers or
# subject briefs; expected-topic mappings were assigned for this audit.
CASES = [
    {
        "id": "PH-2025-01", "code": "IBPH", "subject": "Physics",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/physics-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "A car has an initial speed of 16 m s-1. It decelerates at 4.0 m s-2 until it stops. What is the distance travelled by the car?",
        "expected_topic": "A1_Kinematics", "label_basis": "motion with constant deceleration",
    },
    {
        "id": "PH-2025-02", "code": "IBPH", "subject": "Physics",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/physics-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "A block accelerates from 15 m s-1 to 20 m s-1. What impulse acts on the block?",
        "expected_topic": "A2_Forces_and_momentum", "label_basis": "impulse/change in momentum",
    },
    {
        "id": "PH-2025-03", "code": "IBPH", "subject": "Physics",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/physics-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "A net force accelerates a body from rest. What is the work done by the force?",
        "expected_topic": "A3_Work_energy_power", "label_basis": "work and kinetic energy",
    },
    {
        "id": "PH-2025-04", "code": "IBPH", "subject": "Physics",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/physics-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "A gas undergoes one cycle of a cyclic process. What is the net change in internal energy of the gas?",
        "expected_topic": "B4_Thermodynamics_HL", "label_basis": "cyclic process/internal energy; HL-specific profile topic",
    },
    {
        "id": "DS-2024-01", "code": "IBDS", "subject": "Digital Society",
        "source_year": 2024, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/digital-society-hl-sl-specimen-papers-1-2-3-en.pdf",
        "question": "Describe two contexts in which collecting data about online activity may lead to privacy concerns for young people.",
        "expected_topic": "DS2_7_Values_and_ethics", "label_basis": "privacy/ethical implications of monitoring",
    },
    {
        "id": "DS-2024-02", "code": "IBDS", "subject": "Digital Society",
        "source_year": 2024, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/digital-society-hl-sl-specimen-papers-1-2-3-en.pdf",
        "question": "Explain two reasons why a machine-learning model using real-time aircraft weather data may have been more accurate in predicting a hurricane's course.",
        "expected_topic": "DS3_2_Algorithms", "label_basis": "machine-learning algorithm and model performance",
    },
    {
        "id": "DS-2024-03", "code": "IBDS", "subject": "Digital Society",
        "source_year": 2024, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/digital-society-hl-sl-specimen-papers-1-2-3-en.pdf",
        "question": "Evaluate an online news organization's decision to use automated journalism exclusively, with reference to one course concept.",
        "expected_topic": "DS3_5_Media", "label_basis": "automated journalism and news media",
    },
    {
        "id": "DS-2024-04", "code": "IBDS", "subject": "Digital Society",
        "source_year": 2024, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/digital-society-hl-sl-specimen-papers-1-2-3-en.pdf",
        "question": "Explain why a human-rights activist might disagree with the use of artificial intelligence in criminal sentencing.",
        "expected_topic": "DS5_2_Governance_and_human_rights", "label_basis": "human rights/governance consequences of AI use",
    },
    {
        "id": "GE-2019-01", "code": "IBGE", "subject": "Geography",
        "source_year": 2019, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/geography-hl-specimen-papers-1-2-3-en.pdf",
        "question": "Examine the impacts of human activity on river hydrographs.",
        "expected_topic": "GA1_Drainage_basin_hydrology", "label_basis": "river hydrographs/drainage-basin hydrology",
    },
    {
        "id": "GE-2019-02", "code": "IBGE", "subject": "Geography",
        "source_year": 2019, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/geography-hl-specimen-papers-1-2-3-en.pdf",
        "question": "Examine the environmental and economic impacts of El Niño events.",
        "expected_topic": "GB1_Ocean_atmosphere", "label_basis": "El Niño/ocean-atmosphere interactions",
    },
    {
        "id": "GE-2019-03", "code": "IBGE", "subject": "Geography",
        "source_year": 2019, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/geography-hl-specimen-papers-1-2-3-en.pdf",
        "question": "Explain how overgrazing can lead to desertification.",
        "expected_topic": "GC2_Extreme_physical_processes", "label_basis": "desertification process in the extreme-environments option",
    },
    {
        "id": "GE-2019-04", "code": "IBGE", "subject": "Geography",
        "source_year": 2019, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/geography-hl-specimen-papers-1-2-3-en.pdf",
        "question": "Examine the role of plate margin type in determining the severity of volcanic hazards.",
        "expected_topic": "GD1_Geophysical_systems", "label_basis": "plate-margin processes and volcanic hazards",
    },
    {
        "id": "HI-2017-01", "code": "IBHI", "subject": "History",
        "source_year": 2017, "source_type": "official subject brief sample prompt",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/history-hl-2020-eng.pdf",
        "question": "Evaluate the international community's intervention in Rwanda and its response to the genocide.",
        "expected_topic": "P1_Conflict_and_intervention", "label_basis": "prescribed subject: conflict and intervention",
    },
    {
        "id": "HI-2028-01", "code": "IBHI", "subject": "History",
        "source_year": 2028, "source_type": "official subject brief sample prompt",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/dp-history-sb-en.pdf",
        "question": "Using three sources, investigate post-Second World War displacement in Europe and whether persecution was the main reason for mass displacement.",
        "expected_topic": "HI28_Regional_In_Depth_Topics", "label_basis": "new-course regional in-depth topic architecture; Europe case requires a school-selected regional topic"
    },
    {
        "id": "CS-2014-01", "code": "IBCS", "subject": "Computer Science",
        "source_year": 2014, "source_type": "official subject brief sample question",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/computer-science---standard-level.pdf",
        "question": "The colour of a pixel can be stored as a 16-bit integer. State how many different colours can be represented and whether the storage system is digital or analog.",
        "expected_topic": "Computer_Organisation_and_Architecture", "label_basis": "binary representation/data storage",
    },
    {
        "id": "PS-2027-01", "code": "IBPS", "subject": "Psychology",
        "source_year": 2027, "source_type": "official subject brief sample question",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/dp_psychology_subjectbrief_en.pdf",
        "question": "Describe how one chemical messenger plays a role in one human behaviour.",
        "expected_topic": "PSY27_Biological_Approach", "label_basis": "new 2027 course content area: biological approach"
    },
    {
        "id": "PS-2027-02", "code": "IBPS", "subject": "Psychology",
        "source_year": 2027, "source_type": "official subject brief sample question",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/dp_psychology_subjectbrief_en.pdf",
        "question": "Explain anchoring bias with reference to one example of human behaviour.",
        "expected_topic": "PSY27_Cognitive_Approach", "label_basis": "new 2027 course content area: cognitive approach; 2027 course is materially revised",
    },
    {
        "id": "WR-2013-01", "code": "IBWR", "subject": "World Religions",
        "source_year": 2013, "source_type": "official subject brief sample question",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/3_worldreligionssl.pdf",
        "question": "Explain Taoist ideas about opposites and their reconciliation.",
        "expected_topic": "Study_of_Religion", "label_basis": "broad religious concepts; Taoism is not explicitly named in the current profile's religion-topic splits",
    },
    {
        "id": "BI-2025-01", "code": "IBBI", "subject": "Biology",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/biology-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "What allows the movement of water under tension in the xylem?",
        "expected_topic": "B7_Transport", "label_basis": "xylem water transport; cohesion is a supporting concept",
    },
    {
        "id": "BI-2025-02", "code": "IBBI", "subject": "Biology",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/biology-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "Which property of DNA explains how genetic information can be replicated accurately?",
        "expected_topic": "A2_Nucleic_acids", "label_basis": "DNA structure and complementary base pairing",
    },
    {
        "id": "CH-2025-01", "code": "IBCH", "subject": "Chemistry",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/chemistry-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "A container holds 30 g of argon and 60 g of neon. What is the ratio of number of atoms of argon to number of atoms of neon?",
        "expected_topic": "S1_4_The_mole", "label_basis": "molar amount and particle ratios",
    },
    {
        "id": "CH-2025-02", "code": "IBCH", "subject": "Chemistry",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/chemistry-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "What is the molecular geometry of the central atom in SF4Cl2?",
        "expected_topic": "S2_2_Covalent_model", "label_basis": "molecular geometry and covalent electron-pair repulsion",
    },
    {
        "id": "CH-2025-03", "code": "IBCH", "subject": "Chemistry",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/chemistry-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "Which molecule has a carbonyl functional group?",
        "expected_topic": "S3_2_Functional_groups", "label_basis": "identification of an organic functional group",
    },
    {
        "id": "CH-2025-04", "code": "IBCH", "subject": "Chemistry",
        "source_year": 2025, "source_type": "official specimen paper",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/chemistry-hl-sl-specimen-papers-1a-2b-2-en.pdf",
        "question": "The block structure of the periodic table groups elements according to which characteristic?",
        "expected_topic": "S3_1_Periodic_table", "label_basis": "organization of the periodic table by electron configuration",
    },
    {
        "id": "BM-2024-01", "code": "IBBM", "subject": "Business management",
        "source_year": 2024, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/business-management-hl-subject-brief-en.pdf",
        "question": "Explain one advantage and one disadvantage for MT of being a small business.",
        "expected_topic": "U1_Types_of_business_entities", "label_basis": "small-business form and business entities",
    },
    {
        "id": "EC-2022-01", "code": "IBEC", "subject": "Economics",
        "source_year": 2022, "source_type": "official subject brief sample question",
        "source_url": "https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/sl-economics-en.pdf",
        "question": "Explain two reasons why a government might set a price ceiling on a good.",
        "expected_topic": "EC2_Government_intervention", "label_basis": "price ceiling as a government intervention in a market",
    },
    {
        "id": "CL-2024-01", "code": "IBCL", "subject": "Classical Languages (Latin)",
        "source_year": 2024, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/classical-language-sl-hl-en.pdf",
        "question": "Outline the arrival of the tidal wave and its aftermath, based on the passage from Ammianus Marcellinus.",
        "expected_topic": "CL24_Text_Author_Audience", "label_basis": "comprehension of the named classical author and passage; current course strand",
    },
    {
        "id": "CL-2024-02", "code": "IBCL", "subject": "Classical Languages (Latin)",
        "source_year": 2024, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/classical-language-sl-hl-en.pdf",
        "question": "Poetry is the ideal literary form for the expression of emotion. Discuss with reference to a prescribed core text in verse and another source.",
        "expected_topic": "CL24_Meaning_Form_Language", "label_basis": "literary form and expression are the focus of the prompt",
    },
    {
        "id": "SE-2014-01", "code": "IBSE", "subject": "Sports, exercise and health science",
        "source_year": 2014, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/sports-exercise-and-health-science-sl-hl-en.pdf",
        "question": "At rest, the arterio-venous oxygen difference is approximately 5 mL of oxygen per 100 mL of blood. What happens to this figure during moderately intense exercise?",
        "expected_topic": "Anatomy_and_Exercise_Physiology", "label_basis": "oxygen extraction and exercise physiology; SL brief vintage",
    },
    {
        "id": "PL-2025-01", "code": "IBPL", "subject": "Philosophy",
        "source_year": 2025, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/university-admission/pdfs/dp-philosophy-brief-sl-hl-en.pdf",
        "question": "Evaluate the claim that there is an irresolvable tension between liberty and our obligations to others.",
        "expected_topic": "PH25_Political_Philosophy", "label_basis": "liberty and obligations to others; current political-philosophy theme",
    },
    {
        "id": "PL-2025-02", "code": "IBPL", "subject": "Philosophy",
        "source_year": 2025, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/university-admission/pdfs/dp-philosophy-brief-sl-hl-en.pdf",
        "question": "To what extent do virtue-based approaches fail to provide practical guidance on how we should act?",
        "expected_topic": "PH25_Ethics", "label_basis": "virtue-based action and practical moral guidance",
    },
    {
        "id": "PL-2025-03", "code": "IBPL", "subject": "Philosophy",
        "source_year": 2025, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/university-admission/pdfs/dp-philosophy-brief-sl-hl-en.pdf",
        "question": "Explain Plato's distinction between knowledge and belief.",
        "expected_topic": "PH25_Epistemology", "label_basis": "knowledge and belief; current course's epistemology theme",
    },
    {
        "id": "LP-2024-01", "code": "IBLP", "subject": "Literature and Performance",
        "source_year": 2024, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/lit-performance-subject-brief-en.pdf",
        "question": "Some literary texts, although set in a particular place or time, convey ideas that are universal. In what ways is this true in two works you have studied?",
        "expected_topic": "Comparative_Study_of_Texts_and_Performance", "label_basis": "comparative literary essay; nearest profile topic",
    },
    {
        "id": "LP-2024-02", "code": "IBLP", "subject": "Literature and Performance",
        "source_year": 2024, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/lit-performance-subject-brief-en.pdf",
        "question": "How do two works you have studied portray the struggle to be understood?",
        "expected_topic": "Comparative_Study_of_Texts_and_Performance", "label_basis": "comparative essay prompt on literary works",
    },
    {
        "id": "GP-2026-01", "code": "IBGP", "subject": "Global Politics",
        "source_year": 2026, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/university-admission/pdfs/global-politics-sl-hl-subject-brief-en.pdf",
        "question": "Using Source C and one example you have studied, explain the reasons why international cooperation may be problematic for some states.",
        "expected_topic": "GP26_Core_Power_and_Political_Processes", "label_basis": "core concepts of power, sovereignty and interdependence in the 2026 course",
    },
    {
        "id": "GP-2026-02", "code": "IBGP", "subject": "Global Politics",
        "source_year": 2026, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/university-admission/pdfs/global-politics-sl-hl-subject-brief-en.pdf",
        "question": "Discuss the view that development always results in inequalities.",
        "expected_topic": "GP26_Development_and_Sustainability", "label_basis": "development and sustainability thematic study in the revised 2026 course",
    },
    {
        "id": "GP-2026-03", "code": "IBGP", "subject": "Global Politics",
        "source_year": 2026, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/university-admission/pdfs/global-politics-sl-hl-subject-brief-en.pdf",
        "question": "To what extent is addressing structural violence increasingly important to achieving lasting peace?",
        "expected_topic": "GP26_Peace_and_Conflict", "label_basis": "peace and conflict thematic study in the revised 2026 course",
    },
    {
        "id": "MA-2021-01", "code": "IBMA", "subject": "Mathematics: Analysis and Approaches",
        "source_year": 2021, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/university-admission/pdfs/dp-mathematics-analysis-and-approaches-specimen-papers-en.pdf",
        "question": "Let A and B be events such that P(A)=0.5, P(B)=0.4 and P(A union B)=0.6. Find P(A given B).",
        "expected_topic": "T4_Probability", "label_basis": "conditional probability; validates only the 2021 course taxonomy, not the 2029 revision",
    },
    {
        "id": "AI-2021-01", "code": "IBAI", "subject": "Mathematics: Applications and Interpretation",
        "source_year": 2021, "source_type": "official specimen paper",
        "source_url": "https://ibo.org/globalassets/new-structure/university-admission/pdfs/dp-mathematics-applications-and-interpretation-specimen-papers-en.pdf",
        "question": "Using a model for the population of Bulbul birds during migration, calculate the time taken for the population to decrease below 1400.",
        "expected_topic": "T2_Function_models", "label_basis": "population modelling; validates only the 2021 course taxonomy, not the 2029 revision",
    },
    {
        "id": "DT-2016-01", "code": "IBDT", "subject": "Design Technology",
        "source_year": 2016, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/design-technology--hl.pdf",
        "question": "At which stage of the product life cycle would user attitudes and behaviours be likely to have greater impact than those of the designer or manufacturer?",
        "expected_topic": "Human_Factors_and_Ergonomics", "label_basis": "legacy 2016 course prompt; not evidence for first-assessment-2027 course",
    },
    {
        "id": "CS-2014-02", "code": "IBCS", "subject": "Computer Science",
        "source_year": 2014, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/computer-science---standard-level.pdf",
        "question": "State the output of a code fragment that assigns a decimal number to a variable and applies a floor operation.",
        "expected_topic": "Computational_Thinking_and_Programming", "label_basis": "legacy 2014 programming prompt; not evidence for first-assessment-2027 course",
    },
    {
        "id": "LB-FR-2020-01", "code": "IBLBF", "subject": "Language B French",
        "source_year": 2020, "source_type": "official Language B brief possible question (theme-level, English text)",
        "source_url": "https://www.ibo.org/contentassets/5895a05412144fe890312bad52b17044/lang-b-2018-en.pdf",
        "question": "What constitutes an identity?",
        "expected_topic": "Identities", "label_basis": "official common Language B theme prompt; not French-language paper validation",
    },
    {
        "id": "LB-ES-2020-01", "code": "IBLBS", "subject": "Language B Spanish",
        "source_year": 2020, "source_type": "official Language B brief possible question (theme-level, English text)",
        "source_url": "https://www.ibo.org/contentassets/5895a05412144fe890312bad52b17044/lang-b-2018-en.pdf",
        "question": "What constitutes an identity?",
        "expected_topic": "Identities", "label_basis": "official common Language B theme prompt; not Spanish-language paper validation",
    },
    {
        "id": "SA-2019-01", "code": "IBSA", "subject": "Social and Cultural Anthropology",
        "source_year": 2019, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/contentassets/5895a05412144fe890312bad52b17044/social-and-cultural-anthropology-sl-hl-2017-en.pdf",
        "question": "How are we the same as and different from each other? Discuss with reference to at least two sources of ethnographic material and examples from the passage.",
        "expected_topic": "AN19_Belonging", "label_basis": "human sameness and difference; broad identity/belonging inquiry",
    },
    {
        "id": "SA-2019-02", "code": "IBSA", "subject": "Social and Cultural Anthropology",
        "source_year": 2019, "source_type": "official subject brief sample question",
        "source_url": "https://www.ibo.org/contentassets/5895a05412144fe890312bad52b17044/social-and-cultural-anthropology-sl-hl-2017-en.pdf",
        "question": "Discuss how the body is constructed through either symbolism or social relations.",
        "expected_topic": "AN19_The_Body", "label_basis": "the body, symbolism, and social relations are explicit",
    },
    {
        "id": "LA-LIT-2024-01", "code": "IBLL", "subject": "Language A: Language and Literature",
        "source_year": 2024, "source_type": "official Literature and Performance sample question, common Paper 1 prompt",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/lit-performance-subject-brief-en.pdf",
        "question": "Some literary texts, although set in a particular place or time, convey ideas that are universal. In what ways is this true in two works you have studied?",
        "expected_topic": "LL2_Time_and_space", "label_basis": "common comparative prompt; explicitly invokes time and place",
    },
    {
        "id": "LA-LIT-2024-02", "code": "IBLT", "subject": "Language A: Literature",
        "source_year": 2024, "source_type": "official Literature and Performance sample question, common Paper 1 prompt",
        "source_url": "https://www.ibo.org/globalassets/new-structure/programmes/dp/pdfs/lit-performance-subject-brief-en.pdf",
        "question": "Some literary texts, although set in a particular place or time, convey ideas that are universal. In what ways is this true in two works you have studied?",
        "expected_topic": "LT2_Time_and_space", "label_basis": "common comparative prompt; explicitly invokes time and place",
    },
    {
        "id": "FI-2026-01", "code": "IBFI", "subject": "Film",
        "source_year": 2026, "source_type": "official assessment-task description from current course page",
        "source_url": "https://www.ibo.org/programmes/diploma-programme/curriculum/the-arts/film/",
        "question": "Analyze how film elements combine to convey meaning in a prescribed film extract, considering its cultural context.",
        "expected_topic": "FILM23_Reading_Film", "label_basis": "film elements and meaning are analyzed in an extract; task paraphrase, not an exam item",
    },
]


# Current official version fit is deliberately separate from the prompt's
# source vintage. A legacy prompt can exercise the legacy runtime but cannot
# certify a revised/current course profile.
PROFILE_VERSION_FIT = {
    "IBBI": "profile and 2025 specimen aligned",
    "IBBM": "profile and 2024 brief aligned",
    "IBCH": "profile and 2025 specimen aligned",
    "IBCL": "first assessment 2024 profile routed separately from legacy root; current topic crosswalk follows official brief strands",
    "IBCS": "legacy root profile retained; first-assessment-2027 profile route implemented; only legacy 2014 prompts tested",
    "IBDA": "first-assessment-2029 route implemented from official update; no question-text probe",
    "IBDT": "legacy root retained; first-assessment-2027 route implemented from official subject brief; only legacy 2016 prompt tested",
    "IBDS": "profile and 2024 specimen aligned",
    "IBEC": "profile and 2022 brief aligned",
    "IBES": "first-assessment-2026 route implemented with eight official-brief topic buckets; no public current question text tested",
    "IBFI": "current guide second edition (first assessment 2023) represented as four task-based topics; one official assessment-task description tested, but no specimen QP text tested",
    "IBGE": "profile and 2019 specimen vintage; current revision status requires guide-level confirmation",
    "IBGP": "first-assessment-2026 route implemented; three official 2026 brief prompts use the routed course profile",
    "IBHI": "legacy root retained; first-assessment-2028 inquiry/case-study route implemented; one new brief prompt smoke-tested",
    "IBLL": "2021 profile vintage; current official page/assessment model broadly consistent",
    "IBLT": "2021 profile vintage; current official page/assessment model broadly consistent",
    "IBLBF": "2020 theme taxonomy retained in 2029 revision; language-specific runtime validation absent",
    "IBLBS": "2020 theme taxonomy retained in 2029 revision; language-specific runtime validation absent",
    "IBLP": "first assessment 2024; broad profile mapping only",
    "IBMA": "2021 root retained; first-assessment-2029 A–E route implements official brief topic map and excludes retired legacy nodes",
    "IBAI": "2021 root retained; first-assessment-2029 A–E route implements official brief topic map",
    "IBMU": "first-assessment-2022 processes and HL contemporary music-maker project represented; no conventional question sample tested",
    "IBPL": "first assessment 2025 profile routed separately from legacy root; core, optional-theme areas, and HL extension represented",
    "IBPH": "profile and 2025 specimen aligned",
    "IBPS": "2019 root retained; first-assessment-2027 approaches/contexts route implemented and sampled with two official brief prompts",
    "IBSA": "2019 inquiry/ethnography areas represented in the current topic map; two brief prompts audited",
    "IBSE": "legacy root retained; first-assessment-2026 three-theme route implemented; only legacy 2014 prompt tested",
    "IBTH": "first-assessment-2024 staging, tradition, collaborative creation, and HL theory tasks represented; no conventional prompt tested",
    "IBVA": "first-assessment-2027 create/connect/communicate route implemented; no conventional QP prompt expected",
    "IBWR": "legacy World Religions root retained; Religion and Society first-assessment-2029 route implemented; only legacy text tested",
}


def run() -> dict:
    rows = []
    for item in CASES: 
        try:
            out = classify_text(item["code"], item["question"], question_number=item["id"], component="",
                                year=str(item.get("source_year") or ""))
            predicted = str(out.get("topic") or "")
            row = {**item, "profile_version_fit": PROFILE_VERSION_FIT.get(item["code"], "not assessed"),
                   "selected_profile_version": str(out.get("profile_version") or ""),
                   "selected_profile_path": str(out.get("profile_path") or ""),
                   "status": str(out.get("status") or ""),
                   "predicted_topic": predicted, "correct_top1": predicted == item["expected_topic"],
                   "confidence": out.get("confidence"),
                   "candidate_topics": out.get("candidates") or out.get("major_scores") or [],
                   "reasoning": str(out.get("reasoning") or "")[:400]}
        except Exception as exc:
            row = {**item, "profile_version_fit": PROFILE_VERSION_FIT.get(item["code"], "not assessed"),
                   "selected_profile_version": "", "selected_profile_path": "",
                   "status": "ERROR", "predicted_topic": "", "correct_top1": False,
                   "confidence": None, "candidate_topics": [],
                   "reasoning": f"{type(exc).__name__}: {exc}"}
        rows.append(row)
    counts = Counter(r["status"] for r in rows)
    exact = sum(r["correct_top1"] for r in rows)
    all_profile_codes = sorted(p.parent.name.rsplit("_", 1)[-1]
                               for p in (ROOT / "subjects_ib" / "DP").glob("*/config.json"))
    tested_profile_codes = sorted({r["code"] for r in rows})
    return {
        "schema": "ib_official_sample_audit/3",
        "audit_type": "official_source_question_text_smoke_test_with_manual_expected_topics",
        "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "limitations": [
            "Prompts are short excerpts/paraphrases from official IB specimen papers or subject briefs, not a balanced exam corpus.",
            "Expected topics are manual mappings to current repository profile identifiers; multi-topic prompts and stale profile versions make some labels provisional.",
            "This measures neither precision/recall nor full-document QP/MS/ER processing, PDF segmentation, markscheme attachment, or subject-bundle isolation.",
            "Runtime receives each record's source_year and selects the corresponding declared profile route; see source_year, selected_profile_version and profile_version_fit.",
            "Declared profile routes are crosswalks from official briefs/update pages, not full paid-guide transcriptions; source-specific calibration remains limited."
            "The number of prompts and subjects is not a measure of coverage quality: full official QP/MS/ER parsing and independent labels are still required.",
        ],
        "summary": {"cases": len(rows), "hints": counts.get("HINT", 0),
                    "reviews": counts.get("REVIEW_REQUIRED", 0), "errors": counts.get("ERROR", 0),
                    "manual_top1_matches": exact,
                    "manual_top1_match_rate": round(exact / len(rows), 4) if rows else 0.0,
                    "repository_profiles": len(all_profile_codes),
                    "profiles_with_sample_text": len(tested_profile_codes),
                    "sample_text_profile_coverage": round(len(tested_profile_codes) / len(all_profile_codes), 4) if all_profile_codes else 0.0,
                    "untested_profile_codes": sorted(set(all_profile_codes) - set(tested_profile_codes))},
        "cases": rows,
    }


def main() -> int:
    payload = run()
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    fields = ["id", "code", "subject", "source_year", "source_type", "source_url", "question",
              "expected_topic", "label_basis", "profile_version_fit", "selected_profile_version", "selected_profile_path", "status", "predicted_topic", "correct_top1",
              "confidence", "candidate_topics", "reasoning"]
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in payload["cases"]:
            row = dict(row)
            row["candidate_topics"] = json.dumps(row["candidate_topics"], ensure_ascii=False)
            writer.writerow({k: row.get(k, "") for k in fields})
    print(json.dumps(payload["summary"], indent=2))
    print(f"[IB official sample audit] wrote {OUT_JSON} and {OUT_CSV}")
    return 1 if payload["summary"]["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
