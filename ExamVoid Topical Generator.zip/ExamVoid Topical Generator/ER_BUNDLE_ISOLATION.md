# ER bundle-isolation fix

## What changed

- Preflight now associates an examiner report only with QP/MS bundles that match its syllabus, session, and year. A component-specific report wins over a series-wide report; equally specific duplicates are left unassigned instead of being selected by scan order.
- Each batch worker verifies the ER identity against its QP bundle and processes that report inside the worker's isolated staging directory. An identity mismatch is refused and cannot contribute classifier evidence or output assets.
- Removed the batch runner's global post-run ER sweep. ER artifacts are committed as part of their own QP/MS bundle.
- Added a final crop-time syllabus/session/year/component check. This closes the bug where a Biology ER could be considered for Chemistry folders merely because both had the same session, paper variant, and question number.

## Existing output

Previously generated ER crops are derived artifacts and are not retroactively repaired by changing the code. Rebuild the bundles once to replace stale/misfiled ER assets:

```sh
python run_pipeline.py --input input --output output --force-all --workers 14
```

Back up the output folder first if it contains manual edits.

## Verification

- `tests/test_er_bundle_isolation.py`: 3 passed
- Full bundled suite: 108 passed
