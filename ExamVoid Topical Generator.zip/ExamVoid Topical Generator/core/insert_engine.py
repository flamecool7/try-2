"""core/insert_engine.py — Insert (source booklet) cropping engine.

NEW MODULE (2026-08-15, maintainer-directed).

Business / Economics / English / Geography papers ship a separate INSERT
booklet (case studies, source extracts, data tables, stimulus material) that
questions reference by label ("Source A", "Figure 1", "Case Study 1", ...).
Historically the pipeline recognised insert files but discarded them.

This engine crops inserts independently of the locked QP/MS croppers (which
are byte-untouched). Per-question referenced sections only — the section(s) a
question's text names ("Source A") are cropped and attached inside that
question folder as ``{QID}_IN.webp``. Multiple sections are stitched vertically.
A separate insert output folder is deliberately never created.

Science "inserts" are actually data booklets (periodic table / formula sheet /
constants) and are skipped as reference data (100% reference-removal
invariant).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
from PIL import Image

try:
    import fitz  # PyMuPDF
except ImportError:
    import pymupdf as fitz

TARGET_WIDTH = 2280

# Section-header grammar: "Source A", "Figure 1", "Case Study 2", "Extract B",
# "Item 3", "Section A", "Stimulus 1", "Exhibit 4", "Table 2", "Diagram 1".
# Also handles Cambridge suffixes like "Source A for Question 1", "Source B: Question 2".
_SECTION_HEADER_RE = re.compile(
    r"^\s*(?P<kind>Source|Figure|Fig\.?|Extract|Case\s*Study|Case|Item|"
    r"Section|Stimulus|Exhibit|Table|Diagram|Photo|Map|Chart|Text)\s*"
    r"(?P<id>[A-Z]|\d{1,3})(?:\s*[:–-]?\s*(?:for\s+)?(?:Questions?|Q\b)?[^\n]*)?\s*$",
    re.IGNORECASE,
)

# Reference-data signals (science data booklet inserts).
_REF_SIGNALS = (
    "periodic table",
    "physical constants",
    "ionisation energies",
    "ionization energies",
    "bond energies",
    "standard entropy",
    "electrode potentials",
    "qualitative analysis",
    "formula sheet",
    "mathematical formulae",
    "data booklet",
    "mf19", "mf9", "mf20",
    "spectroscopy",
    "chemical shift",
)

# Insert cover/instruction-page signals (the front page of an insert carries
# only the "This document has N pages" banner, the "INFORMATION" block and the
# annotate/planning instructions — no stimulus content).
_COVER_SIGNALS = (
    "this insert contains",
    "you may annotate this insert",
    "do not write your answers on the insert",
    "use the blank spaces for planning",
)

# Back-matter signals (copyright / disclosure acknowledgements at the end).
_BACKMATTER_SIGNALS = (
    "permission to reproduce",
    "to avoid the issue of disclosure",
    "copyright acknowledgements",
    "acknowledgements booklet",
    "reasonable effort has been made",
    "publisher (ucles)",
    "cambridge assessment international education",
    "brand name of the university of cambridge",
    "department of the university of cambridge",
    "online in the cambridge",
    "freely available to download",
    "third-party owned material",
    "trace copyright holders",
)


def _classify_page(text: str, has_sections: bool = False) -> str:
    """Return 'cover' | 'backmatter' | 'content' for an insert page."""
    if has_sections:
        return "content"
    t = text.lower()
    if any(s in t for s in _BACKMATTER_SIGNALS):
        return "backmatter"
    cover_hits = sum(1 for s in _COVER_SIGNALS if s in t)
    if cover_hits >= 2:
        return "cover"
    return "content"


@dataclass
class InsertSection:
    id: str                 # full label, e.g. "Source A"
    kind: str               # "Source"
    page_idx: int
    top_pdf: float          # PDF y (pt) of the section header
    bottom_pdf: float       # PDF y (pt) of the section end (next header / page end)
    text: str = ""


@dataclass
class InsertResult:
    pages: List[Image.Image] = field(default_factory=list)   # junk-stripped, 2280px
    sections: List[InsertSection] = field(default_factory=list)
    page_texts: List[str] = field(default_factory=list)
    page_kinds: List[str] = field(default_factory=list)      # 'cover'|'content'|'backmatter'
    is_reference_data: bool = False
    source_name: str = ""


def _detect_reference_data(full_text: str) -> bool:
    t = full_text.lower()
    # periodic table: many element symbols in a compact block
    elements = {"hydrogen", "helium", "lithium", "beryllium", "boron",
                "carbon", "nitrogen", "oxygen", "fluorine", "neon", "sodium",
                "magnesium", "aluminium", "silicon", "phosphorus", "sulfur",
                "chlorine", "argon", "potassium", "calcium", "iron", "copper",
                "zinc", "bromine", "iodine", "silver", "lead", "uranium"}
    if sum(1 for e in elements if re.search(rf"\b{e}\b", t)) >= 20:
        return True
    return any(s in t for s in _REF_SIGNALS)


def _trim_bottom_whitespace(img: Image.Image, pad: int = 24,
                            dark_threshold: int = 248,
                            min_ink_pixels: int = 3) -> Image.Image:
    """Trim excessive empty whitespace from the bottom of an insert crop.

    Preserves all legitimate content (text, tables, borders, diagrams, footnotes).
    Ensures width is kept at exactly img.width (target 2280px).
    pad: padding in pixels below the lowest detected ink row (default 24px per spec).
    dark_threshold: pixel brightness below which a pixel is considered ink (<248).
    min_ink_pixels: minimum number of dark pixels in a row to count as ink,
                    preventing isolated noise artifacts from preventing trim.
    """
    if img.width <= 10 or img.height <= 50:
        return img
    gray = np.asarray(img.convert("L"))
    dark = gray < dark_threshold
    row_counts = dark.sum(axis=1)
    active_rows = np.where(row_counts >= min_ink_pixels)[0]
    if active_rows.size == 0:
        active_rows = np.where(row_counts >= 1)[0]
        if active_rows.size == 0:
            return img

    last_ink_row = int(active_rows.max())
    new_bottom = min(img.height, last_ink_row + pad + 1)
    if new_bottom < img.height and new_bottom > 20:
        return img.crop((0, 0, img.width, new_bottom))
    return img


class InsertEngine:
    def __init__(self, target_width: int = TARGET_WIDTH, quality: int = 95,
                 dpi: int = 150):
        self.target_width = target_width
        self.quality = quality
        self.dpi = dpi

    # ------------------------------------------------------------------
    def _render(self, pdf_path: Path):
        from .pdf_io import render_pdf_with_rotation_info
        return render_pdf_with_rotation_info(str(pdf_path), dpi=self.dpi)

    def _strip_junk(self, page_img: Image.Image, page, scale: float) -> Image.Image:
        """Crop out header/footer junk bands and copyright backmatter, then resize to target width."""
        h = float(page.rect.height)

        # 1. Top boundary: strip top page numbers (y < 55) and running slugs, but preserve section headers and content
        top_pt = 0.0
        for wd in page.get_text("words"):
            y0, y1, txt = wd[1], wd[3], wd[4].strip()
            if y1 < 55 and (re.fullmatch(r"\d{1,3}", txt) or any(s in txt.lower() for s in ("turn", "over", "insert", "ucles"))):
                top_pt = max(top_pt, y1 + 3.0)

        # 2. Bottom boundary: strip footer and copyright/backmatter
        bottom_pt = h
        for b in page.get_text("blocks"):
            txt_l = b[4].lower()
            if any(s in txt_l for s in _BACKMATTER_SIGNALS):
                bottom_pt = min(bottom_pt, b[1] - 8.0)

        for wd in page.get_text("words"):
            y0, txt = wd[1], wd[4].strip().lower()
            if y0 > h * 0.92:
                if any(s in txt for s in ("©", "ucles", "copyright", "turn", "over", "insert", "acknowledgement", "publisher")) or re.fullmatch(r"\d{1,3}", txt):
                    bottom_pt = min(bottom_pt, y0 - 4.0)

        px_top = max(0, int(round(top_pt * scale)))
        px_bottom = min(page_img.height, int(round(bottom_pt * scale)))
        if px_bottom <= px_top:
            px_bottom = page_img.height
            px_top = 0
        img = page_img.crop((0, px_top, page_img.width, px_bottom))

        # resize to 2280 wide
        if img.width != self.target_width:
            scale2 = self.target_width / float(img.width)
            new_h = max(1, int(round(img.height * scale2)))
            img = img.resize((self.target_width, new_h), Image.Resampling.LANCZOS)
        img = _trim_bottom_whitespace(img, pad=24)
        return img

    def _detect_sections(self, doc, page_count: int) -> List[InsertSection]:
        sections: List[InsertSection] = []
        for pi in range(page_count):
            page = doc[pi]
            h = float(page.rect.height)
            lines = page.get_text("dict").get("blocks", [])
            headers = []  # (top_pdf, label)
            backmatter_top = h
            for block in lines:
                for ln in block.get("lines", []):
                    txt = "".join(
                        s.get("text", "") for s in ln.get("spans", [])
                    ).strip()
                    txt_l = txt.lower()
                    if any(bm in txt_l for bm in _BACKMATTER_SIGNALS):
                        backmatter_top = min(backmatter_top, ln["bbox"][1])
                    m = _SECTION_HEADER_RE.match(txt)
                    if not m:
                        continue
                    y0 = ln["bbox"][1]
                    label = f"{m.group('kind').title()} {m.group('id').upper()}".replace("  ", " ")
                    # normalise "Fig." kind
                    label = re.sub(r"^Fig\.?\s", "Figure ", label, flags=re.I)
                    headers.append((y0, label))
            headers.sort(key=lambda x: x[0])

            # Determine footer top on this page (page numbers, © UCLES, [Turn over, printer slugs)
            footer_top = h
            for wd in page.get_text("words"):
                y0_wd, txt_wd = wd[1], wd[4].lower().strip()
                if y0_wd > h * 0.92:
                    if any(s in txt_wd for s in ("©", "ucles", "copyright", "turn", "over", "insert", "acknowledgement", "publisher")) or re.fullmatch(r"\d{1,3}", txt_wd):
                        footer_top = min(footer_top, y0_wd)
            page_content_bottom = min(h, footer_top, backmatter_top - 8.0)

            for i, (y0, label) in enumerate(headers):
                bottom = headers[i + 1][0] if i + 1 < len(headers) else (
                    page_content_bottom if page_content_bottom > y0 else h
                )
                kind = label.split()[0]
                sections.append(InsertSection(
                    id=label, kind=kind, page_idx=pi,
                    top_pdf=y0, bottom_pdf=bottom, text="",
                ))
        return sections

    # ------------------------------------------------------------------
    def process_insert(self, pdf_path) -> Optional[InsertResult]:
        pdf_path = Path(pdf_path)
        try:
            images, scale, rotations, doc = self._render(pdf_path)
        except Exception:
            return None
        try:
            result = InsertResult(source_name=pdf_path.name)
            full_text = ""
            result.sections = self._detect_sections(doc, len(doc))
            section_pages = {s.page_idx for s in result.sections}
            for pi in range(len(doc)):
                pt = doc[pi].get_text("text") or ""
                full_text += pt + "\n"
                result.page_texts.append(pt)
                result.page_kinds.append(_classify_page(pt, has_sections=(pi in section_pages)))
            result.is_reference_data = _detect_reference_data(full_text)
            for pi in range(len(doc)):
                page = doc[pi]
                img = self._strip_junk(images[pi], page, scale)
                result.pages.append(img)
            return result
        finally:
            doc.close()

    # ------------------------------------------------------------------
    def _section_image(self, pdf_path: Path, section: InsertSection) -> Optional[Image.Image]:
        from .pdf_io import render_pdf_with_rotation_info
        images, scale, rotations, doc = render_pdf_with_rotation_info(str(pdf_path), dpi=self.dpi)
        try:
            page = doc[section.page_idx]
            img = images[section.page_idx]
            h = page.rect.height

            # Top boundary: ensure clean padding above section header,
            # but strictly exclude any text above it (such as top page numbers)
            words_above = [
                wd for wd in page.get_text("words")
                if wd[3] <= section.top_pdf
            ]
            if words_above:
                highest_bottom_above = max(wd[3] for wd in words_above)
                top_pt = max(section.top_pdf - 8.0, highest_bottom_above + 3.0)
            else:
                top_pt = max(0.0, section.top_pdf - 8.0)

            # Bottom boundary: stop above any footer, bottom page number, or copyright block
            bottom_pt = section.bottom_pdf

            # Stop above backmatter / copyright acknowledgement block
            for b in page.get_text("blocks"):
                txt_l = b[4].lower()
                if any(sig in txt_l for sig in _BACKMATTER_SIGNALS):
                    if b[1] > section.top_pdf:
                        bottom_pt = min(bottom_pt, b[1] - 8.0)

            for wd in page.get_text("words"):
                y0_wd, txt_wd = wd[1], wd[4].lower().strip()
                if y0_wd > h * 0.92 and y0_wd > section.top_pdf:
                    if any(term in txt_wd for term in ("©", "ucles", "copyright", "turn", "over", "insert", "acknowledgement", "publisher")) or re.fullmatch(r"\d{1,3}", txt_wd):
                        bottom_pt = min(bottom_pt, y0_wd - 4.0)

            # Bound strictly by the last content word that actually belongs to this section
            sec_words = [w for w in page.get_text("words") if section.top_pdf <= w[1] <= bottom_pt]
            if sec_words:
                last_word_bottom = max(w[3] for w in sec_words)
                bottom_pt = min(bottom_pt, last_word_bottom + 14.0)

            top = int(round(top_pt * scale))
            bottom = int(round(bottom_pt * scale))
            top = max(0, top)
            bottom = min(img.height, bottom)
            if bottom <= top:
                return None
            crop = img.crop((0, top, img.width, bottom))
            if crop.width != self.target_width:
                s2 = self.target_width / float(crop.width)
                crop = crop.resize((self.target_width, max(1, int(round(crop.height * s2)))),
                                   Image.Resampling.LANCZOS)
            crop = _trim_bottom_whitespace(crop, pad=24)
            return crop
        finally:
            doc.close()

    # ------------------------------------------------------------------
    def save_webp(self, img: Image.Image, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        img.save(path, "WEBP", quality=self.quality, method=2)


# ---------------------------------------------------------------------------
# Convenience helpers used by the orchestrator
# ---------------------------------------------------------------------------

# The set of labels a question's text may reference.  Matched case-insensitively
# against section ids (e.g. "Source A" references section "Source A").
def referenced_sections(question_text: str, sections: List[InsertSection]) -> List[InsertSection]:
    """Return only sections explicitly named as whole labels in question text."""
    if not question_text or not sections:
        return []
    text = " ".join(str(question_text).split())
    out = []
    for section in sections:
        label = " ".join(section.id.split())
        variants = {label}
        # Cambridge papers may call the same heading "Figure 1" or "Fig. 1".
        variants.add(re.sub(r"^figure\s+", "Fig. ", label, flags=re.IGNORECASE))
        matched = False
        for variant in variants:
            flexible = re.escape(variant).replace(r"\ ", r"\s+")
            if re.search(r"(?<![\w])" + flexible + r"(?![\w])", text, re.IGNORECASE):
                matched = True
                break
        if matched:
            out.append(section)
    return out

def _question_numbers_in_instruction(scope: str) -> set[int]:
    """Parse explicitly named top-level questions, including numeric ranges."""
    numbers: set[int] = set()
    pattern = re.compile(
        r"\bQuestions?\s+(?P<first>\d{1,3})"
        r"(?:\s*\([^)]*\))?"
        r"(?:\s*(?:[-–—]|to)\s*(?:Questions?\s*)?"
        r"(?P<last>\d{1,3})(?:\s*\([^)]*\))?)?",
        re.IGNORECASE,
    )
    for match in pattern.finditer(scope):
        first = int(match.group("first"))
        last = int(match.group("last") or first)
        if 1 <= first <= last <= 100:
            numbers.update(range(first, last + 1))
    return numbers


def _add_explicit_insert_instruction_links(
    question_refs: List[Tuple[str, str]], result: InsertResult,
) -> List[Tuple[str, str]]:
    """Propagate an insert's explicit reading directions to all named questions.

    An insert may say, for example, "Read Text C ... answer Questions 2(a)-(d)
    and Question 3" before the Text C heading. The QP crop for Q3 may not
    repeat that preamble, so crop-text-only linking would omit the insert from
    Q3. Only exact section labels and question numbers written in the direction
    are propagated; adjacent or unnamed questions are never guessed.
    """
    if not question_refs or not result.page_texts or not result.sections:
        return list(question_refs or [])

    targets: dict[str, set[int]] = {}
    for raw_page_text in result.page_texts:
        page_text = " ".join(str(raw_page_text or "").split())
        if not page_text:
            continue
        for section in result.sections:
            label = " ".join(section.id.split())
            flexible = re.escape(label).replace(r"\ ", r"\s+")
            instruction = re.compile(
                r"\b(?:read|study|use|refer\s+to|look\s+at|consider)\s+"
                r"(?:the\s+)?" + flexible +
                r"\b[^.]{0,300}?\banswer\s+(?P<scope>[^.]{1,220})",
                re.IGNORECASE,
            )
            match = instruction.search(page_text)
            if match:
                targets.setdefault(section.id, set()).update(
                    _question_numbers_in_instruction(match.group("scope"))
                )

    if not targets:
        return list(question_refs)

    expanded: List[Tuple[str, str]] = []
    qid_pattern = re.compile(r"(?:^|_)Q(?P<number>\d+)(?:_|$)", re.IGNORECASE)
    for folder, question_text in question_refs:
        qid = qid_pattern.search(Path(folder).name)
        qnumber = int(qid.group("number")) if qid else None
        extra_labels = [label for label, qnumbers in targets.items()
                        if qnumber is not None and qnumber in qnumbers]
        expanded.append((folder, f"{question_text or ''} {' '.join(extra_labels)}".strip()))
    return expanded


def write_insert_outputs(engine: InsertEngine, result: InsertResult,
                         pdf_path: Path, output_root: Path,
                         level: str, subject: str, paper_type_folder: str,
                         paper_code: str,
                         question_refs: List[Tuple[str, str]] = None) -> dict:
    """Attach only explicitly referenced insert sections to their questions.

    Standalone page-level insert output is forbidden: insert material is
    emitted only as ``{QID}_IN.webp`` inside the corresponding question
    folder. Unreferenced or ambiguous sections are not guessed onto a
    question and are never placed in an ``_insert`` directory.
    """
    summary = {"whole_pages": 0, "sections": 0, "reference_data_skipped": False,
               "skipped_pages": 0, "unmatched_sections": []}

    # Replace this paper's former attachments before applying current,
    # clipped question text. This also clears stale inserts when the supplied
    # companion is now recognized as reference data.
    for qfolder_str, _qtext in question_refs or []:
        qfolder = Path(qfolder_str)
        if qfolder.is_dir():
            for stale in qfolder.glob("*_IN*.webp"):
                stale.unlink(missing_ok=True)

    # Repeat the safety decision at the write boundary. A periodic table or
    # science data sheet must never become a per-question `_IN` attachment,
    # even if an upstream caller lost the InsertResult flag.
    reference_text = "\n".join(result.page_texts or []) + "\n" + "\n".join(
        section.text or "" for section in (result.sections or [])
    )
    if result.is_reference_data or _detect_reference_data(reference_text):
        print(f"    [insert] {pdf_path.name}: reference data (data booklet) — "
              f"skipped per 100% reference-removal invariant")
        summary["reference_data_skipped"] = True
        return summary

    question_refs = _add_explicit_insert_instruction_links(question_refs or [], result)
    if not question_refs:
        summary["unmatched_sections"] = [section.id for section in result.sections]
        return summary

    for qfolder_str, qtext in question_refs:
        qfolder = Path(qfolder_str)
        if not qfolder.is_dir():
            continue
        refs = referenced_sections(qtext, result.sections)
        if not refs:
            continue
        imgs = []
        for section in refs:
            img = engine._section_image(pdf_path, section)
            if img is not None:
                imgs.append(img)
        if not imgs:
            continue
        combined = _stitch_vertical(imgs, target_width=engine.target_width)
        target = qfolder / f"{qfolder.name}_IN.webp"
        engine.save_webp(combined, target)
        summary["sections"] += 1

    linked = {
        section.id
        for _folder, qtext in question_refs
        for section in referenced_sections(qtext, result.sections)
    }
    summary["unmatched_sections"] = [section.id for section in result.sections
                                       if section.id not in linked]
    return summary

def _stitch_vertical(images: List[Image.Image], target_width: int = TARGET_WIDTH,
                     gap_px: int = 20) -> Image.Image:
    """Stack a list of (already width-normalised) images into one tall image,
    with a white gap between them.  Returns a single 2280px-wide image."""
    if not images:
        raise ValueError("no images to stitch")
    if len(images) == 1:
        img = images[0]
        if img.width != target_width:
            s = target_width / float(img.width)
            img = img.resize((target_width, max(1, int(round(img.height * s)))),
                             Image.Resampling.LANCZOS)
        return _trim_bottom_whitespace(img, pad=24)
    norm = []
    for im in images:
        if im.width != target_width:
            s = target_width / float(im.width)
            im = im.resize((target_width, max(1, int(round(im.height * s)))),
                           Image.Resampling.LANCZOS)
        norm.append(_trim_bottom_whitespace(im, pad=24))
    total_h = sum(im.height for im in norm) + gap_px * (len(norm) - 1)
    canvas = Image.new("RGB", (target_width, max(1, total_h)), "white")
    y = 0
    for im in norm:
        canvas.paste(im, (0, y))
        y += im.height + gap_px
    return _trim_bottom_whitespace(canvas, pad=24)
