"""Conservatively remove printed dotted answer rules from QP crop images.

Uses the PDF text layer rather than image heuristics: only long runs of literal
period characters are erased. Wording, symbols, and mark labels stay untouched.
Rows made solely from repeated periods are removed vertically as wasted answer
space. This intentionally does not modify the source PDF or any MS/ER content.
"""
from __future__ import annotations

import math
import re
from typing import Iterable

import fitz
from PIL import Image, ImageDraw


_LONG_WORD_RANGE_RE = re.compile(
    r"\b(?:write|answer|compose|produce)\b[^\n]{0,180}?"
    r"\b(\d{3,})\s*(?:to|[-–—])\s*(\d{3,})\s+words?\b",
    re.IGNORECASE,
)
_LONG_SINGLE_WORD_RE = re.compile(
    r"\b(?:write|answer|compose|produce)\b[^\n]{0,180}?"
    r"\b(?:about|approximately|around|at least)\s+(\d{3,})\s+words?\b",
    re.IGNORECASE,
)
_SCIENCE_P5_EXTENDED_CUES = (
    re.compile(r"\bplan\s+(?:a|an|your)\s+(?:laboratory\s+)?(?:experiment|investigation)\b", re.I),
    re.compile(r"\bmethod\s+should\s+be\s+set\s+out\s+in\s+a\s+logical\s+order\b", re.I),
    re.compile(r"\bdetailed\s+enough\s+to\s+let\s+another\s+person\s+follow\s+it\b", re.I),
)
_SUBPART_LINE_RE = re.compile(r"^\s*\(([a-h])\)(?=\s|$)", re.I)
_SCIENCE_P5_CODES = {"9700", "9701", "9702"}


def is_a_level_science_p5(identity_or_code: object, variant: object = "") -> bool:
    """Recognize CAIE Biology/Chemistry/Physics Paper 5 only."""
    code = str(getattr(identity_or_code, "code", "") or identity_or_code or "")
    component = str(variant or getattr(identity_or_code, "variant", "") or "")
    if code in _SCIENCE_P5_CODES and component.startswith("5"):
        return True
    match = re.search(r"(?<!\d)(9700|9701|9702)_[msw]\d{2}_qp_(5[1-3])(?:\b|$)", code, re.I)
    return bool(match)


def is_long_form_answer(text: str, *, minimum_words: int = 200) -> bool:
    """True only when the question explicitly calls for a long-form response.

    Explicit word-count instructions are the safe signal: short-answer lines
    remain printed, while essay/talk responses asking for 200+ words have their
    answer rules removed. A short summary limit (e.g. 120 words) does not match.
    """
    for match in _LONG_WORD_RANGE_RE.finditer(text or ""):
        if int(match.group(1)) >= minimum_words:
            return True
    for match in _LONG_SINGLE_WORD_RE.finditer(text or ""):
        if int(match.group(1)) >= minimum_words:
            return True
    return False


def find_long_form_cue_y(
    page: fitz.Page,
    *,
    clip_y0_pt: float = 0.0,
    clip_y1_pt: float | None = None,
    science_p5: bool = False,
) -> float | None:
    """Find a long essay word-count or Paper 5 extended-method instruction."""
    cues: list[float] = []
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type", 0) != 0:
            continue
        for line in block.get("lines", []):
            text = "".join(span.get("text", "") for span in line.get("spans", []))
            bbox = line.get("bbox")
            if not bbox:
                continue
            long_count = is_long_form_answer(text)
            p5_long_method = science_p5 and any(pattern.search(text) for pattern in _SCIENCE_P5_EXTENDED_CUES)
            if not (long_count or p5_long_method):
                continue
            y0, y1 = float(bbox[1]), float(bbox[3])
            if y1 <= clip_y0_pt or (clip_y1_pt is not None and y0 >= clip_y1_pt):
                continue
            cues.append(y0)
    return min(cues) if cues else None


def _subpart_markers(page: fitz.Page, y0: float, y1: float) -> list[tuple[float, str]]:
    markers: list[tuple[float, str]] = []
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type", 0) != 0:
            continue
        for line in block.get("lines", []):
            text = "".join(span.get("text", "") for span in line.get("spans", []))
            bbox = line.get("bbox")
            if not bbox:
                continue
            top = float(bbox[1])
            match = _SUBPART_LINE_RE.match(text)
            if match and y0 <= top < y1:
                markers.append((top, match.group(1).lower()))
    return sorted(markers)


def plan_answer_rule_cleanup(
    page_segments: Iterable[tuple[fitz.Page, float, float]],
    *,
    science_p5: bool = False,
) -> list[tuple[float, float] | None]:
    """Plan cleanup intervals, preserving short subparts after long responses.

    Each input is a (page, PDF-y-start, PDF-y-end) segment. A long-form cue
    activates cleanup at its own line; on a continuation page, cleanup stops at
    the next distinct alphabetic subpart marker.
    """
    result: list[tuple[float, float] | None] = []
    active = False
    active_part: str | None = None
    for page, y0, y1 in page_segments:
        y0, y1 = float(y0), float(y1)
        markers = _subpart_markers(page, y0, y1)
        cue_y = find_long_form_cue_y(
            page, clip_y0_pt=y0, clip_y1_pt=y1, science_p5=science_p5,
        )
        boundary = None
        if active and active_part is not None:
            boundary = next((top for top, part in markers if part != active_part), None)
            if boundary is not None and cue_y is not None and cue_y >= boundary:
                # The cue is for a later subpart; close the previous answer region.
                active = False
                active_part = None

        if cue_y is not None and not active:
            active = True
            active_part = next((part for top, part in reversed(markers) if top <= cue_y), None)
            # For a newly activated lettered part, stop at the next part label
            # already present on this page; it is a separate short response.
            boundary = (next((top for top, part in markers
                              if top > cue_y and part != active_part), None)
                        if active_part is not None else None)
            start = cue_y
        elif active:
            start = y0
            if active_part is not None:
                boundary = next((top for top, part in markers if part != active_part), None)
        else:
            result.append(None)
            continue

        end = min(y1, boundary) if boundary is not None else y1
        result.append((start, end) if end > start else None)
        if boundary is not None:
            active = False
            active_part = None
    return result


def _union_bbox(boxes: Iterable[Iterable[float]]) -> tuple[float, float, float, float] | None:
    values = [tuple(map(float, box)) for box in boxes]
    if not values:
        return None
    return (
        min(box[0] for box in values),
        min(box[1] for box in values),
        max(box[2] for box in values),
        max(box[3] for box in values),
    )


def _text_lines(page: fitz.Page):
    """Yield (line text, line bbox, character records) from the PDF text layer."""
    raw = page.get_text("rawdict")
    for block in raw.get("blocks", []):
        if block.get("type", 0) != 0:
            continue
        for line in block.get("lines", []):
            chars = [
                char
                for span in line.get("spans", [])
                for char in span.get("chars", [])
            ]
            text = "".join(str(char.get("c", "")) for char in chars)
            bbox = line.get("bbox") or _union_bbox(
                char.get("bbox", ()) for char in chars if char.get("bbox")
            )
            if bbox and text:
                yield text, tuple(map(float, bbox)), chars


def _dot_runs(chars: list[dict], *, min_chars: int, min_width_pt: float):
    """Yield boxes for contiguous, long repeated-period runs in a text line."""
    run: list[dict] = []
    for char in [*chars, {"c": ""}]:  # sentinel flushes the final run
        if str(char.get("c", "")) == "." and char.get("bbox"):
            run.append(char)
            continue
        if len(run) >= min_chars:
            box = _union_bbox(char.get("bbox", ()) for char in run)
            if box and box[2] - box[0] >= min_width_pt:
                yield box
        run = []


def remove_dotted_answer_rules(
    image: Image.Image,
    page: fitz.Page,
    *,
    source_x0_pt: float,
    source_y0_pt: float,
    scale_x: float,
    scale_y: float,
    pdf_clip_y0_pt: float | None = None,
    pdf_clip_y1_pt: float | None = None,
) -> Image.Image:
    """Remove long PDF dot-leaders in a rendered crop and collapse dot-only rows.

    ``source_x0_pt``/``source_y0_pt`` are the PDF coordinates at the image's
    top-left. Scales are rendered pixels per PDF point. Content outside the
    image's clip is ignored, so this helper works for both page-segment crops
    and the vector-first direct-clip renderer.
    """
    if image.width <= 0 or image.height <= 0 or scale_x <= 0 or scale_y <= 0:
        return image

    dot_masks: list[tuple[float, float, float, float]] = []
    answer_row_boxes: list[tuple[float, float]] = []
    for text, line_box, chars in _text_lines(page):
        if pdf_clip_y0_pt is not None and line_box[3] <= pdf_clip_y0_pt:
            continue
        if pdf_clip_y1_pt is not None and line_box[1] >= pdf_clip_y1_pt:
            continue
        content = "".join(ch for ch in text if not ch.isspace())
        dots_only = len(content) >= 8 and all(ch == "." for ch in content)
        if dots_only:
            answer_row_boxes.append((line_box[1], line_box[3]))
            # The entire line is discarded; individual dot masks are redundant.
            continue
        for box in _dot_runs(chars, min_chars=5, min_width_pt=8.0):
            dot_masks.append(box)

    # Erase dot characters at their own locations. A small PDF-space pad clears
    # antialiasing without touching adjacent words or separate mark labels.
    work = image.convert("RGB") if image.mode != "RGB" else image
    work = work.copy()
    draw = ImageDraw.Draw(work)
    for x0, y0, x1, y1 in dot_masks:
        left = math.floor((x0 - source_x0_pt) * scale_x - 1.0)
        right = math.ceil((x1 - source_x0_pt) * scale_x + 1.0)
        top = math.floor((y0 - source_y0_pt) * scale_y - 1.0)
        bottom = math.ceil((y1 - source_y0_pt) * scale_y + 1.0)
        left, right = max(0, left), min(work.width - 1, right)
        top, bottom = max(0, top), min(work.height - 1, bottom)
        if right >= left and bottom >= top:
            draw.rectangle((left, top, right, bottom), fill="white")

    # Consecutive dot-only answer rows are one unused answer-space block, not
    # dozens of meaningful text rows. Merge their modest inter-line gaps too;
    # otherwise the rules vanish but the essay-sized blank panel remains.
    answer_row_boxes.sort()
    merged_pdf: list[list[float]] = []
    for top_pt, bottom_pt in answer_row_boxes:
        if merged_pdf and top_pt - merged_pdf[-1][1] <= 22.0:
            merged_pdf[-1][1] = max(merged_pdf[-1][1], bottom_pt)
        else:
            merged_pdf.append([top_pt, bottom_pt])
    delete_rows = []
    for top_pt, bottom_pt in merged_pdf:
        top = math.floor((top_pt - source_y0_pt) * scale_y - 1.0)
        bottom = math.ceil((bottom_pt - source_y0_pt) * scale_y + 1.0)
        top, bottom = max(0, top), min(work.height, bottom)
        if bottom > top:
            delete_rows.append((top, bottom))
    if not delete_rows:
        return work

    # Merge overlapping pixel bands, then concatenate only retained pixels.
    delete_rows.sort()
    merged: list[list[int]] = []
    for top, bottom in delete_rows:
        if merged and top <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], bottom)
        else:
            merged.append([top, bottom])
    pieces: list[Image.Image] = []
    cursor = 0
    for top, bottom in merged:
        if top > cursor:
            pieces.append(work.crop((0, cursor, work.width, top)))
        cursor = max(cursor, bottom)
    if cursor < work.height:
        pieces.append(work.crop((0, cursor, work.width, work.height)))
    if not pieces:
        return Image.new("RGB", (work.width, 1), "white")
    if len(pieces) == 1:
        return pieces[0]
    result = Image.new("RGB", (work.width, sum(piece.height for piece in pieces)), "white")
    y = 0
    for piece in pieces:
        result.paste(piece, (0, y))
        y += piece.height
    return result
