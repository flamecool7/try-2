"""
er_question_crops.py — per-question Examiner Report PAGE CROPS (2026-08-10)
============================================================================

Additive companion to the LOCKED examiner_report.py (which is not modified):

  * examiner_report.py decides WHICH folders belong to WHICH ER (verified
    identity matching) and writes examiner_report.txt + full-report tiles.
  * THIS module adds the boundary-specific visual crop per question folder,
    following the approved naming convention:

        {variant}_{Season}_{Year}_Q{n}_ER.webp   (e.g. 41_Winter_2025_Q5_ER.webp)
        (+ _part2.webp … tiles automatically when a crop exceeds the WebP
        16383px limit — via webp_utils.save_webp, same rule as the full tiles)

Pipeline parity with MS cropping: the output is a VISUAL CROP of the examiner
report pages for that question (never a text file), exactly 2280px wide.
Cropping philosophy inherited from QP/MS: commentary is NEVER clipped; extra
whitespace is acceptable; page-spanning commentary is stacked vertically just
like the approved full-report renderer does.

Spec-internal bugs avoided (each verified against the real 16-page,
multi-component 9700_m25_er.pdf booklet):

  BUG-1 audit mixed y-coordinates across pages (y_end measured on a different
        page than y_start) → we carry (page, y) pairs end-to-end and stack
        per-page bands.
  BUG-2 audit rendered all pages at 300 dpi into one list (~420 MB, OOM here)
        → pages stream one at a time at 150 dpi; only band crops are kept.
  BUG-3 audit dropped the approved "Questions 1-10" grouped format → we import
        the LOCKED QUESTION_HEADER_PATTERNS set (all four formats, grouped
        included) so this module can never drift from the canonical list.
  BUG-4 audit re-introduced unguarded bare-number headers → bare numbers are
        accepted only inside the scoped specific-questions section, outside
        page header/footer zones, strictly monotone (page numbers rejected).
  BUG-5 audit used substring y-search (bare "2" hijacked to a wrong line) →
        per-line, line-anchored matches only.
  BUG-6 audit bypassed save_webp and re-hit the encoder limit → all saves go
        through webp_utils.save_webp (tiling) at quality 95.
  BUG-7 audit wrote placeholders / misattributed general comments → locked
        policy: no ER match or no boundary → NOTHING is written (status only).
  BUG-8 audit scanned the whole booklet blindly — m25 ER contains MULTIPLE
        papers (the 9700/12 MCQ key pages come FIRST) → scanning is scoped to
        the matching "Paper {syllabus}/{variant}" component section.
  BUG-9 audit had no verification at all → every written crop is verified:
        the segment's own PDF text must contain the opening of the commentary
        the locked writer attached (normalized containment). On mismatch,
        nothing is written ("wrong content" is worse than "no file").

Only dependencies on locked modules are READ-ONLY imports of the canonical
pattern objects; examiner_report.py, pdf_io.py and all golds stay byte-intact.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import fitz  # PyMuPDF
import numpy as np
from PIL import Image

from .examiner_report import (
    BACKMATTER_PATTERN,
    GENERAL_SECTION_LINE,
    QUESTION_HEADER_PATTERNS,
    SPECIFIC_SECTION_LINE,
    SPECIFIC_SECTION_PATTERN,
)
from .webp_utils import save_webp

logger = logging.getLogger(__name__)

# ── Rendering / geometry (proportional; the only absolute is the locked 2280) ──
ER_CROP_DPI = 150                       # matches the approved MS render dpi
TARGET_WIDTH_PX = 2280                  # locked output-width invariant
HEAD_BAND_FRAC = 0.055                  # running-header zone on continuation pages
FOOT_LIMIT_FRAC = 0.945                 # footer zone cut (© UCLES line)
MIN_CROP_HEIGHT_PX = 80                 # a crop must show some commentary

# Bare-number header guards (page-number rejection)
BARE_TOP_EXCLUDE_FRAC = 0.05
BARE_BOTTOM_EXCLUDE_FRAC = 0.92
BARE_MAX_QUESTION = 40

_SEASON_CODE_TO_CANON = {"m": "Spring", "s": "Summer", "w": "Winter"}


def _question_folder_identity(folder: Path):
    """Read the QP identity from a question folder's own canonical metadata.

    The old ER-crop pass grouped folders only by ``variant/season/year``. Since
    the syllabus was omitted, a Biology ER could be cropped into Chemistry Q
    folders from the same session when question numbers happened to overlap.
    Return ``(syllabus, season, year, component, prefix, qnum)`` or ``None``;
    unknown/malformed identities are deliberately excluded.
    """
    import json

    try:
        metadata = json.loads((Path(folder) / "metadata.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None
    paper = str(metadata.get("paper", ""))
    match = re.fullmatch(r"(?P<syll>\d{4})_(?P<season>[msw])(?P<yy>\d{2})_qp_(?P<component>\d{1,3})",
                         paper, re.I)
    qmatch = re.fullmatch(r"Q?(\d+)", str(metadata.get("question_number", "")))
    if not match or not qmatch:
        return None
    syllabus = match.group("syll")
    season = _SEASON_CODE_TO_CANON.get(match.group("season").lower())
    try:
        year = int(metadata.get("year") or (2000 + int(match.group("yy"))))
    except (TypeError, ValueError):
        return None
    component = match.group("component")
    prefix = f"{metadata.get('variant') or component}_{metadata.get('season') or season}_{year}"
    return syllabus, season, year, component, prefix, int(qmatch.group(1))
_RANGE_TAIL = re.compile(r"(\d+)\s*[–-]\s*(\d+)\s*$")
# A standalone section heading marks the end of the preceding numbered ER
# commentary.  It is intentionally line-anchored: a sentence mentioning a
# section remains ordinary commentary.
_ER_SECTION_HEADING_LINE = re.compile(r"^\s*section\s+[A-Z]\s*$", re.IGNORECASE)
# Closing remarks after the final question ("Conclusion", "Common Errors")
# end the last numbered commentary.  Line-anchored, applied to the last
# question only.  Case-sensitive: a wrapped prose word ("...an interesting
# conclusion") must not end the crop.
_ER_CLOSING_HEADING_LINE = re.compile(
    r"^\s*(?:Conclusions?|CONCLUSIONS?|Common\s+[Ee]rrors|COMMON\s+ERRORS)\s*:?\s*$"
)
# A sub-heading inside a question ("Conclusions" in a 9702 practical report)
# is followed by part labels; true closing remarks are not.
_ER_PART_LABEL_LINE = re.compile(r"^\s*\((?:[a-z]|[ivx]{1,4})\)")


# ══════════════════════════════════════════════════════════════════════════════
# Phase 1 — text scan (PDF coordinates; nothing rasterized yet)
# ══════════════════════════════════════════════════════════════════════════════

def _page_lines(page: "fitz.Page") -> List[Tuple[float, str, List[float]]]:
    """[(y0_pt, line_text, [span_sizes])] for every text line of a page."""
    out: List[Tuple[float, str, List[float]]] = []
    d = page.get_text("dict")
    for block in d.get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            text = "".join(s.get("text", "") for s in spans).strip()
            if not text:
                continue
            sizes = [float(s.get("size", 0)) for s in spans if s.get("size")]
            out.append((float(line["bbox"][1]), text, sizes))
    out.sort(key=lambda t: t[0])
    return out


def _page_line_boxes(page: "fitz.Page") -> List[Tuple[float, float, str]]:
    """[(y0_pt, y1_pt, line_text)] for content-aware continuation bounds.

    This is kept separate from _page_lines so the established question-header
    parser and verifier preserve their exact input representation.
    """
    out: List[Tuple[float, float, str]] = []
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            text = "".join(s.get("text", "") for s in line.get("spans", [])).strip()
            if not text:
                continue
            bbox = line.get("bbox", [0, 0, 0, 0])
            out.append((float(bbox[1]), float(bbox[3]), text))
    out.sort(key=lambda row: row[0])
    return out


def _component_scope(
    pages_lines: List[List[Tuple[float, str, List[float]]]],
    syllabus_code: str,
    variant: str,
) -> Tuple[int, int]:
    """Scope scanning to the matching "Paper 9700/22" component of a booklet
    ER. Returns (first_page, last_page_exclusive); falls back to the whole
    document (with a warning) when the marker is absent."""
    start_pat = re.compile(rf"Paper\s+{re.escape(syllabus_code)}/{re.escape(variant)}(?!\d)")
    other_pat = re.compile(rf"Paper\s+{re.escape(syllabus_code)}/(?!{re.escape(variant)}(?!\d))\d\d")
    first = None
    for i, lines in enumerate(pages_lines):
        joined = "\n".join(t for _, t, _ in lines)
        if start_pat.search(joined):
            first = i
            break
    if first is None:
        logger.warning(
            "[er-crops] component marker 'Paper %s/%s' not found; scanning whole document",
            syllabus_code, variant,
        )
        return 0, len(pages_lines)
    last = len(pages_lines)
    for j in range(first + 1, len(pages_lines)):
        joined = "\n".join(t for _, t, _ in pages_lines[j])
        if other_pat.search(joined):
            last = j
            break
    return first, last


def _find_section_and_questions(
    pages_lines: List[List[Tuple[float, str, List[float]]]],
    page_heights: List[float],
    lo: int,
    hi: int,
) -> Tuple[Optional[Tuple[int, float]], List[Tuple[int, int, int, float]], Optional[Tuple[int, float]], str]:
    """Locate the specific-questions section and its question headers.

    Returns (section_start, headers, end_delimiter, winning_format) where
    headers = [(q_start, q_end, page, y_pdf)] — q_start==q_end unless the
    winning format is grouped_range ("Questions 1-10").
    """
    section_start: Optional[Tuple[int, float]] = None
    end_delim: Optional[Tuple[int, float]] = None
    candidates: List[Tuple[int, float, str]] = []
    loose_used = False

    for p in range(lo, hi):
        page_done = False
        for y0, text, _sizes in pages_lines[p]:
            if section_start is None:
                if SPECIFIC_SECTION_LINE.match(text):
                    section_start = (p, y0)
                    continue
                if not loose_used and SPECIFIC_SECTION_PATTERN.search(text):
                    section_start = (p, y0)  # locked two-tier rule, loose tier
                    loose_used = True
                    continue
                continue
            if BACKMATTER_PATTERN.search(text) or GENERAL_SECTION_LINE.match(text):
                end_delim = (p, y0)
                page_done = True
                break
            candidates.append((p, y0, text))
        if page_done:
            break

    if section_start is None:
        return None, [], None, "none"

    # First locked pattern (priority order) that yields ≥1 header wins — the
    # same selection semantics as parse_question_commentaries.
    for fmt, pattern in QUESTION_HEADER_PATTERNS:
        headers: List[Tuple[int, int, int, float]] = []
        seen = set()
        last_num = 0
        for (p, y0, text) in candidates:
            m = pattern.match(text)
            if not m:
                continue
            q_start = int(m.group(1))
            q_end = q_start
            if fmt == "grouped_range":
                rm = _RANGE_TAIL.search(text)
                if rm:
                    q_end = int(rm.group(2))
            if q_start in seen:
                continue
            if fmt == "bare_number":
                ph = page_heights[p]
                if y0 < BARE_TOP_EXCLUDE_FRAC * ph or y0 > BARE_BOTTOM_EXCLUDE_FRAC * ph:
                    continue  # header/footer zone → page number, not a header
                if q_start < 1 or q_start > BARE_MAX_QUESTION or q_start < last_num:
                    continue  # must be a plausible monotone question sequence
                last_num = q_start
            seen.add(q_start)
            headers.append((q_start, q_end, p, y0))
        if headers:
            headers.sort(key=lambda h: (h[2], h[3]))
            return section_start, headers, end_delim, fmt

    return section_start, [], end_delim, "none"


def _median_line_px(lines_by_page: List[List[Tuple[float, str, List[float]]]], scale: float) -> float:
    sizes: List[float] = []
    for lines in lines_by_page:
        for _y, _t, sizes_l in lines:
            sizes.extend(s for s in sizes_l if 7.0 <= s <= 16.0)
    if not sizes:
        return 13.0 * scale  # Cambridge body ≈ 11–12pt
    return float(np.median(sizes)) * scale


def _section_boundary_in_segment(
    pages_lines: List[List[Tuple[float, str, List[float]]]],
    sp: int,
    sy: float,
    ep: int,
    ey: float,
    last: bool = False,
) -> Optional[Tuple[int, float]]:
    """Find a standalone section heading strictly inside one ER question band."""
    for p in range(sp, ep + 1):
        lower = sy if p == sp else 0.0
        upper = ey if p == ep else float("inf")
        for y0, text, _sizes in pages_lines[p]:
            if not lower + 1.0 < y0 < upper - 1.0:
                continue
            if _ER_SECTION_HEADING_LINE.fullmatch(text):
                return p, y0
            if (last and _ER_CLOSING_HEADING_LINE.fullmatch(text)
                    and not _part_label_after(pages_lines, p, y0, ep, ey)):
                return p, y0
    return None


def _part_label_after(pages_lines, sp: int, sy: float, ep: int, ey: float) -> bool:
    """True when a question-part label "(e)" follows (sp, sy) inside the band."""
    for p in range(sp, ep + 1):
        for y0, text, _sizes in pages_lines[p]:
            if (p == sp and y0 <= sy) or (p == ep and y0 >= ey):
                continue
            if _ER_PART_LABEL_LINE.match(text):
                return True
    return False


def _continuation_body_lines(
    line_boxes: List[Tuple[float, float, str]],
    page_height: float,
    y_top: float,
    y_bot: float,
) -> List[Tuple[float, float, str]]:
    """Return body lines in a proposed continuation band (never running header/footer)."""
    return [
        (line_y0, line_y1, text)
        for line_y0, line_y1, text in line_boxes
        if line_y0 >= HEAD_BAND_FRAC * page_height and line_y1 <= FOOT_LIMIT_FRAC * page_height
        and line_y1 > y_top and line_y0 < y_bot
    ]


def _terminal_text_only_tail_is_safe(
    page: "fitz.Page",
    last_body_y1: float,
    y_bot: float,
) -> bool:
    """Whether a final fallback tail can be trimmed after its last body line.

    A terminal ER question sometimes has no following question, section, or
    back-matter heading from which to derive a natural end boundary.  It is
    safe to replace the old near-footer fallback with the final text line only
    if the prospective discarded tail contains no non-text PDF object.  This
    deliberately preserves a terminal chart, table rule, diagram, or image:
    in those cases the conservative existing end boundary remains authoritative.
    """
    lower = last_body_y1 + 1.0
    upper = y_bot - 1.0
    if upper <= lower:
        return False
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type", 0) == 0:
            continue
        bbox = block.get("bbox", [0, 0, 0, 0])
        if float(bbox[3]) > lower and float(bbox[1]) < upper:
            return False
    for drawing in page.get_drawings():
        rect = drawing.get("rect")
        if rect is not None and float(rect.y1) > lower and float(rect.y0) < upper:
            return False
    return True


def _tighten_continuation_band(
    line_boxes: List[Tuple[float, float, str]],
    page_height: float,
    y_top: float,
    y_bot: float,
    *,
    is_continuation_start: bool,
    is_continuation_end: bool,
    is_safe_terminal_text_end: bool = False,
    pad_pt: float,
) -> Tuple[float, float]:
    """Remove only proven continuation-edge or safe terminal-tail whitespace.

    Existing first/last question boundaries remain authoritative. On an
    intermediate continuation edge, PDF line boxes identify the first/last
    real report content. The only terminal exception is a final open fallback
    endpoint whose discarded tail has separately been proven text-only by
    ``_terminal_text_only_tail_is_safe``. If no suitable text line exists, the
    conservative existing band is left unchanged.
    """
    candidates = _continuation_body_lines(line_boxes, page_height, y_top, y_bot)
    if not candidates:
        return y_top, y_bot

    if is_continuation_start:
        first_y0 = candidates[0][0]
        # Only advance the edge when the old generic header band actually
        # leaves more than the intended semantic padding.
        if first_y0 - y_top > pad_pt + 1.0:
            y_top = min(y_bot, first_y0 - pad_pt)
    if is_continuation_end or is_safe_terminal_text_end:
        last_y1 = candidates[-1][1]
        # Same conservative rule at a footer edge.  Text-free drawings/figures
        # keep the old boundary because they cannot establish a text-safe trim.
        if y_bot - last_y1 > pad_pt + 1.0:
            y_bot = max(y_top, last_y1 + pad_pt)
    return y_top, y_bot


# ══════════════════════════════════════════════════════════════════════════════
# Phase 2 — bands in raster space → per-question stacked segments
# ══════════════════════════════════════════════════════════════════════════════

def build_question_crops_for_pdf(
    er_pdf: str | Path,
    syllabus_code: str,
    variant: str,
    wanted_qnums: List[int],
) -> Tuple[Dict[int, Image.Image], Dict[str, str], Dict[int, str], str]:
    """Return ({qnum: 2280px-wide crop}, statuses, {qnum: normalized segment
    text for verification}, winning_format). Memory-safe streaming."""
    statuses: Dict[str, str] = {}
    seg_texts: Dict[int, str] = {}
    doc = fitz.open(str(er_pdf))
    n = len(doc)
    scale = ER_CROP_DPI / 72.0

    pages_lines = [_page_lines(doc[p]) for p in range(n)]
    # Exact line bottoms are needed only for continuation-edge tightening;
    # header detection and verification retain their established _page_lines
    # input above.
    page_line_boxes = [_page_line_boxes(doc[p]) for p in range(n)]
    page_heights = [float(doc[p].rect.height) for p in range(n)]

    lo, hi = _component_scope(pages_lines, syllabus_code, variant)
    start, headers, end_delim, fmt = _find_section_and_questions(
        pages_lines, page_heights, lo, hi
    )
    if start is None or not headers:
        for q in wanted_qnums:
            statuses[f"Q{q}"] = "webp_no_boundary"
        doc.close()
        return {}, statuses, seg_texts, fmt

    med_px = _median_line_px(pages_lines[lo:hi], scale)
    guard_px = int(round(max(18.0, min(60.0, 0.45 * med_px))))
    pad_px = int(round(max(12.0, 0.35 * med_px)))

    # segments in PDF space: [(q_start, q_end, s_page, s_y, e_page, e_y)]
    segments: List[Tuple[int, int, int, float, int, float]] = []
    terminal_open_fallback: List[bool] = []
    for i, (qs, qe, p, y) in enumerate(headers):
        # Narrow terminal exception: only the final question that *starts on
        # the final scoped page with no earlier question header on that page*
        # can use its text-only terminal boundary. This is the proven Q3
        # layout: a fresh-page terminal question with no later delimiter. A
        # final question sharing a page with an earlier question remains on the
        # existing conservative fallback, avoiding collateral boundary changes.
        first_header_on_page = not any(previous[2] == p for previous in headers[:i])
        open_fallback = (
            i + 1 == len(headers)
            and end_delim is None
            and p == hi - 1
            and first_header_on_page
        )
        if i + 1 < len(headers):
            _a, _b, ep, ey = headers[i + 1]
        elif end_delim is not None:
            ep, ey = end_delim
        else:
            ep, ey = hi - 1, page_heights[hi - 1] * FOOT_LIMIT_FRAC

        # Do not let the next section's heading/instructions enter the
        # previous numbered question.  This is a source-coordinate delimiter,
        # so the pixels are absent from the WebP rather than hidden in HTML.
        section_boundary = _section_boundary_in_segment(
            pages_lines, p, y, ep, ey, last=(i + 1 == len(headers))
        )
        if section_boundary is not None:
            ep, ey = section_boundary
            open_fallback = False
        segments.append((qs, qe, p, y, ep, ey))
        terminal_open_fallback.append(open_fallback)

    # per-page bands needed by any segment
    per_page_bands: Dict[int, List[Tuple[int, float, float]]] = {}
    for idx, (_qs, _qe, sp, sy, ep, ey) in enumerate(segments):
        for p in range(sp, ep + 1):
            if p == sp:
                y_top = max(0.0, sy - guard_px / scale)
            else:
                y_top = HEAD_BAND_FRAC * page_heights[p]
            y_bot = (ey - pad_px / scale) if p == ep else page_heights[p] * FOOT_LIMIT_FRAC

            # Tighten only continuation edges.  The start/end question bounds
            # keep their original guards; this narrowly removes the large
            # natural page-break gap and a leaked header fragment (9708/21 Q1)
            # without altering ordinary one-page ER crops.
            pad_pt = pad_px / scale
            body_lines = _continuation_body_lines(
                page_line_boxes[p], page_heights[p], y_top, y_bot
            )
            # A section heading can occur at the very top of the next page.
            # Once its own source-coordinate delimiter has made the remaining
            # band a few header-only points, omit that empty continuation tile
            # rather than stack a leaked running-header fragment beneath the
            # prior question.  The short-band guard preserves any potentially
            # substantive diagram/image continuation.
            if (p != sp and not body_lines and
                    y_bot - y_top <= max(12.0, 2.5 * pad_pt)):
                continue
            # A last question without an explicit following delimiter is the
            # one narrowly safe terminal case. Trim it only when its final
            # source page has real text and no vector/image content in the
            # prospective discarded tail; otherwise retain the former
            # conservative near-footer fallback unchanged.
            terminal_text_end = bool(
                terminal_open_fallback[idx]
                and p == ep
                and body_lines
                and _terminal_text_only_tail_is_safe(doc[p], body_lines[-1][1], y_bot)
            )
            y_top, y_bot = _tighten_continuation_band(
                page_line_boxes[p], page_heights[p], y_top, y_bot,
                is_continuation_start=(p != sp),
                is_continuation_end=(p != ep),
                is_safe_terminal_text_end=terminal_text_end,
                pad_pt=pad_pt,
            )
            if y_bot <= y_top + 1.0:
                continue
            per_page_bands.setdefault(p, []).append((idx, y_top, y_bot))

    # verification text per segment is derived after rendering via the
    # module-level _seg_text_for (subpart-label lines normalized away first)

    parts_by_seg: Dict[int, List[Image.Image]] = {i: [] for i in range(len(segments))}
    for p in sorted(per_page_bands):
        page = doc[p]
        pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        if img.width != TARGET_WIDTH_PX:
            nh = int(round(img.height * TARGET_WIDTH_PX / img.width))
            img = img.resize((TARGET_WIDTH_PX, nh), Image.Resampling.LANCZOS)
        px_per_pt = img.height / float(page.rect.height)
        for (idx, y_top, y_bot) in per_page_bands[p]:
            top = max(0, min(int(round(y_top * px_per_pt)), img.height - 1))
            bot = max(top + 1, min(int(round(y_bot * px_per_pt)), img.height))
            parts_by_seg[idx].append(img.crop((0, top, TARGET_WIDTH_PX, bot)))
        del img, pix
    doc.close()

    out: Dict[int, Image.Image] = {}
    for idx, (qs, qe, _sp, _sy, _ep, _ey) in enumerate(segments):
        parts = parts_by_seg[idx]
        members = list(range(qs, qe + 1))
        if not parts:
            for q in members:
                statuses[f"Q{q}"] = "webp_no_boundary"
            continue
        H = sum(im.height for im in parts)
        if H < MIN_CROP_HEIGHT_PX:
            for q in members:
                statuses[f"Q{q}"] = "webp_no_boundary"
            continue
        canvas = Image.new("RGB", (TARGET_WIDTH_PX, H), "white")
        y = 0
        for im in parts:
            canvas.paste(im, (0, y))
            y += im.height
        stext = _seg_text_for(idx, segments, pages_lines, per_page_bands)
        for q in members:
            out[q] = canvas
            seg_texts[q] = stext
            statuses[f"Q{q}"] = "webp_cropped"
    return out, statuses, seg_texts, fmt


# standalone subpart-label lines: "(a)", "(a) (i)", "(ii)", "i", "iv" …
# (short lowercase-only lines; sentence content is never all-short-tokens)
_SEG_TEXT_SUBPART = re.compile(r"^(?:\([a-z]{1,3}\)\s*)+$|^[a-z]{1,3}$")


def _seg_text_for(idx: int, segments, pages_lines, per_page_bands=None) -> str:
    """Normalized verification text for exactly the rendered segment bands.

    Standalone subpart-label lines ('(a)' / 'a' in the left margin) are dropped
    before normalizing.  When ``per_page_bands`` is supplied, running headers,
    footer strips, and an omitted empty continuation tile are excluded from the
    verifier just as they are from the actual WebP pixels.
    """
    qs, qe, sp, sy, ep, ey = segments[idx]
    rendered_bounds = {}
    if per_page_bands is not None:
        for p, bands in per_page_bands.items():
            for band_idx, y_top, y_bot in bands:
                if band_idx == idx:
                    rendered_bounds[p] = (y_top, y_bot)
                    break
    parts: List[str] = []
    for p in range(sp, ep + 1):
        if rendered_bounds:
            bounds = rendered_bounds.get(p)
            if bounds is None:
                continue
            lower, upper = bounds
        else:
            lower = sy if p == sp else 0.0
            upper = ey if p == ep else float("inf")
        for y0, text, _sz in pages_lines[p]:
            if y0 < lower - 1.0 or y0 >= upper - 1.0:
                continue
            if _SEG_TEXT_SUBPART.match(text.strip()):
                continue
            parts.append(text)
    return re.sub(r"[^a-z0-9]", "", " ".join(parts).lower())

def _commentary_probe(txt_path: Path) -> Optional[str]:
    """Normalized first ~40 chars of the commentary inside the locked writer's
    examiner_report.txt (banner stripped). None when unavailable/too short."""
    try:
        raw = txt_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    body = raw.split("\n\n", 1)[-1] if "=====" in raw else raw
    body = "\n".join(
        l for l in body.splitlines()
        if not l.startswith("=") and not _SEG_TEXT_SUBPART.match(l.strip())
    )
    probe = re.sub(r"[^a-z0-9]", "", body.lower())[:40]
    return probe if len(probe) >= 12 else None


def attach_question_er_crops(er_papers, output_root: str | Path,
                             verified_folders=None) -> Dict[str, object]:
    """Write the boundary-specific {variant}_{Season}_{Year}_Q{n}_ER.webp crop
    -- that question's own ER section, nothing else -- into each question
    folder whose ER identity verified.

    ``verified_folders`` is ``attach_examiner_reports_to_output(...)
    ["verified_folders"]`` (S6). 2026-09-30: folders used to be discovered by
    globbing the whole-report ``<prefix>_ER.webp`` tiles S6 copied into every
    question folder; those tiles are no longer written, so when the list is not
    passed the folders are read from metadata.json instead (the crop builder
    itself is scoped to the matching "Paper <syllabus>/<variant>" section).
    Nothing is written where a boundary cannot be verified (locked policy).
    """
    root = Path(output_root)
    stats: Dict[str, object] = {
        "crops_written": 0,
        "verified": 0,
        "verify_failed": [],
        "status_map": {},
        "errors": [],
        "skipped": [],
    }

    er_list = [p for p in er_papers if getattr(p, "paper_type", None) == "er"]
    if not er_list:
        stats["skipped"].append("no ER papers supplied")
        return stats

    from .examiner_report import remove_whole_report_tiles
    # Key by the entire QP identity, not only component/session/year. The
    # syllabus dimension is mandatory to keep same-session Biology and
    # Chemistry reports in separate worker/output bundles.
    folders: Dict[Tuple[str, str, int, str, str], List[Tuple[Path, int]]] = {}
    candidate_folders = []
    if verified_folders is not None:
        candidate_folders = [Path(folder) for folder, _prefix, _qn in verified_folders]
    else:
        candidate_folders = [meta.parent for meta in root.rglob("metadata.json")]

    seen_folders = set()
    for folder in candidate_folders:
        identity = _question_folder_identity(folder)
        if identity is None:
            continue
        syllabus, season, year, component, prefix, qn = identity
        if verified_folders is not None:
            supplied = next((int(v_qn) for v_folder, _p, v_qn in verified_folders
                             if Path(v_folder) == folder), None)
            # A verified list is the authorization to crop; require its question
            # number to agree with canonical metadata as well.
            if supplied is None or supplied != qn:
                continue
        group_key = (syllabus, season, year, component, prefix)
        entry = (folder, qn)
        if (group_key, entry) not in seen_folders:
            folders.setdefault(group_key, []).append(entry)
            seen_folders.add((group_key, entry))

    # Whole-report tiles from older runs never survive in a question folder.
    for _qfs in folders.values():
        for _qf, _qn in _qfs:
            remove_whole_report_tiles(_qf)

    if not folders:
        stats["skipped"].append("no verified ER question folders found")
        return stats

    for er_paper in er_list:
        er_path = Path(getattr(er_paper, "file_path", ""))
        sm = re.match(r"^(?P<syll>\d{4})_(?P<code>[msw])(?P<yy>\d{2})", er_path.stem)
        if not sm:
            stats["errors"].append(f"unparseable ER filename: {er_path.name}")
            continue
        syll = str(getattr(er_paper, "syllabus_code", "") or sm.group("syll"))
        season = str(getattr(er_paper, "season", "") or
                     _SEASON_CODE_TO_CANON.get(sm.group("code"), "Spring"))
        try:
            year = int(getattr(er_paper, "year", "") or (2000 + int(sm.group("yy"))))
        except (TypeError, ValueError):
            stats["errors"].append(f"unparseable ER year: {er_path.name}")
            continue
        er_component = str(getattr(er_paper, "variant", "") or "")

        for (q_syllabus, q_season, q_year, q_component, prefix), qfolders in sorted(folders.items()):
            # Critical isolation gate: reports can only be considered for the
            # same syllabus + session + year. A component-specific ER narrows
            # that further; a component-less booklet is resolved by its own
            # internal Paper <syllabus>/<component> headings downstream.
            if (q_syllabus != syll or q_season != season or q_year != year):
                continue
            if er_component and not (
                    er_component == q_component
                    or (len(er_component) == 1 and q_component.startswith(er_component))):
                continue
            p_variant = q_component
            wanted = sorted(q for _f, q in qfolders)
            try:
                crops, pstatus, seg_texts, fmt = build_question_crops_for_pdf(
                    er_path, syll, p_variant, wanted
                )
            except Exception as exc:  # never kill the pipeline
                stats["errors"].append(f"{er_path.name}: {exc}")
                continue

            for (qf, qn) in sorted(qfolders, key=lambda t: t[1]):
                key = f"{prefix}_Q{qn}"
                img = crops.get(qn)
                if img is None:
                    stats["status_map"][key] = pstatus.get(f"Q{qn}", "webp_no_boundary")
                    continue
                probe = _commentary_probe(qf / "examiner_report.txt")
                if probe is not None and probe not in seg_texts.get(qn, ""):
                    stats["status_map"][key] = "webp_verify_failed"
                    stats["verify_failed"].append(key)
                    logger.warning("[er-crops] %s: segment text failed containment — not written", key)
                    continue
                dest = qf / f"{prefix}_Q{qn}_ER.webp"
                try:
                    save_webp(img, dest, quality=95)
                except Exception as exc:
                    stats["errors"].append(f"{dest}: {exc}")
                    continue
                stats["crops_written"] += 1
                if probe is not None:
                    stats["verified"] += 1
                stats["status_map"][key] = "webp_cropped"
                logger.info("[er-crops] %s written (%dx%d, fmt=%s)", dest, img.width, img.height, fmt)

    return stats
