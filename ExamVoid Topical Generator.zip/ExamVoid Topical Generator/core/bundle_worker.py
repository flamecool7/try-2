"""Bundle worker (Overseer batch-infrastructure spec, Phase 4 — honest port
onto the REAL locked per-paper stages).

The spec's worker called a fictional API stack (converter.render_pdf_to_images,
question_split.split_questions(qp_images, pages, ...), markscheme.parse_markscheme,
topics_enhanced.classify, organize.route_question, webp_utils.save_question_crop —
the same hallucinated names pipeline.py's docstring lists), never saved MS
crops, and hard-required examiner_report.webp per question. Instead of faking
that, this worker drives the production machinery — the exact stage function
the guarded runner uses (run_guarded.run_paper_stages): locked gold QP/MS
cropping, MCQ answer-grid letters (RS-7), locked classifier, locked
OutputManager routing, locked on-disk stage checks — with the OutputManager
rooted INSIDE the bundle's staging directory (spec rule 6: never write
directly to final output during processing).

Spec rules honoured:
  4  workers receive pre-built bundle args (explicit file paths from the DB)
     and NEVER rescan the input directory;
  5  workers load only THEIR subject's config
     (config_loader.load_subject_config_by_code_and_level), never all 23;
  6  all writes go to <output>/.staging/bundle_<key>/ first;
  7  bundle COMPLETE only after every question saved + validated + committed;
  8  failed bundles keep their staging directory (worker_log.txt included);
  9  the SQLite database is the single source of truth for batch state
     (the per-run .pipeline_state.json inside staging is throwaway scratch
     the real stage function insists on having — it is never committed);
 10  .pipeline_state.json in the REAL output is untouched by batch runs.
"""

import gc
import json
import logging
import os
import shutil
import traceback
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _er_matches_qp_bundle(er_info, qp_info) -> tuple[bool, str]:
    """Fail closed unless this ER belongs to the worker's QP identity.

    ER files may be series-wide (no component in the filename), but their
    syllabus, session, and year must still match exactly. A component-specific
    ER may name the exact QP variant or its paper-number prefix (for example,
    ER variant ``2`` may cover QP variants ``21`` and ``22``).
    """
    if er_info is None or getattr(er_info, "paper_type", None) != "er":
        return False, "file did not parse as an examiner report"
    if getattr(er_info, "identity_status", "") == "REVIEW_REQUIRED":
        return False, "ER filename/cover identity is conflicted"
    for field in ("syllabus_code", "season_letter", "year_short"):
        er_value = str(getattr(er_info, field, "") or "").lower()
        qp_value = str(getattr(qp_info, field, "") or "").lower()
        if not er_value or not qp_value or er_value != qp_value:
            return False, f"{field} mismatch: ER={er_value or 'UNKNOWN'} QP={qp_value or 'UNKNOWN'}"
    er_component = str(getattr(er_info, "variant", "") or "")
    qp_component = str(getattr(qp_info, "variant", "") or "")
    if er_component and not (er_component == qp_component
                             or (len(er_component) == 1 and qp_component.startswith(er_component))):
        return False, f"component mismatch: ER={er_component} QP={qp_component or 'UNKNOWN'}"
    return True, "identity verified"


def _validate_staging(staging_root: Path, paper_format: str | None = None) -> list:
    """Validate staged output before commit (honest replacement of the spec's
    _validate_staging, which hard-required examiner_report.webp on every
    question — that would force-review every ER-less bundle).

    Rules enforced = the production output contract:
      * every question folder has exactly one QP webp, 2280px wide
        (multi-part QP twins use the _partN suffix — count bits-by-stem);
      * metadata.json parses and carries 2280-independent fields the locked
        schema requires (delegated to FinalValidator at batch level; here we
        check parse + question_number);
      * an MS webp UNLESS the folder is a deliberate
        ``review_required_no_ms`` home;
      * a `*_MS.txt` sidecar is permitted only for an MCQ component; all
        other .txt question-folder artifacts are rejected.
    Returns list of error strings; empty = all good.
    """
    from PIL import Image
    from .output_manager import is_topic_review_folder as _is_topic_review

    errors = []
    for path in staging_root.rglob("*"):
        if path.is_dir() and path.name.casefold() in {"in", "insert", "inserts", "_insert"}:
            errors.append(f"standalone insert directory is forbidden: {path}")
    q_folders = [p for p in staging_root.rglob("*")
                 if p.is_dir() and "_Q" in p.name
                 and p.name.rsplit("_Q", 1)[1].isdigit()]
    if not q_folders:
        errors.append(f"no question folders staged under {staging_root}")
        return errors
    for folder in sorted(q_folders):
        webps = [w for w in folder.glob("*.webp") if "_ER" not in w.name]
        qp_webps = [w for w in webps if "_MS" not in w.name and "_CI" not in w.name and "_IN" not in w.name]
        ms_webps = [w for w in webps if w.name.endswith("_MS.webp")]
        if len(qp_webps) != 1:
            errors.append(f"{folder.name}: expected 1 QP webp, found {len(qp_webps)}")
        else:
            try:
                with Image.open(qp_webps[0]) as im:
                    if im.width != 2280:
                        errors.append(f"{folder.name}: QP width {im.width}px != 2280px")
            except Exception as e:
                errors.append(f"{folder.name}: QP image error: {e}")
        meta_path = folder / "metadata.json"
        if not meta_path.exists():
            errors.append(f"{folder.name}: metadata.json missing")
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception as e:
            errors.append(f"{folder.name}: metadata.json invalid: {e}")
            continue
        all_txts = sorted(folder.glob("*.txt"))
        ms_txts = sorted(folder.glob("*_MS.txt"))
        if len(all_txts) != len(ms_txts):
            errors.append(f"{folder.name}: non-MCQ text artifact(s) are forbidden in question folders")
        is_mcq = str(paper_format or "").upper() == "MCQ"
        if ms_txts and not is_mcq:
            errors.append(f"{folder.name}: structured question must not contain an _MS.txt sidecar")
        if ms_webps:
            continue
        # A sidecar is the legitimate MCQ mark-scheme representation. A
        # structured question missing an MS is preserved only under the
        # explicit review sentinel, never as a falsely complete pair.
        from .mcq_output import valid_ms_sidecar as _valid_sidecar
        topic = meta.get("topic")
        sentinel = topic[0] if isinstance(topic, list) and topic else None
        if is_mcq and len(ms_txts) == 1 and _valid_sidecar(ms_txts[0].read_text(encoding="utf-8")):
            pass
        elif sentinel == "review_required_no_ms" and not ms_txts:
            pass
        elif not ms_txts and _is_topic_review(folder, topic):
            pass  # <Topic>/review_required/<QID>: classified no-MS question
        else:
            errors.append(f"{folder.name}: no MS webp and not a valid MCQ sidecar or review_required_no_ms home")
    return errors


def _remove_stale_question_insert_sidecars(output_dir: Path, final_paths: list[tuple[str, str]]) -> list[str]:
    """Keep only current-run insert sidecars in refreshed question folders."""
    expected: dict[Path, set[str]] = {}
    for relative, _absolute in final_paths:
        rel = Path(relative)
        if rel.name == "metadata.json":
            expected.setdefault(Path(output_dir) / rel.parent, set())
        if "_IN" in rel.name and rel.suffix.lower() == ".webp":
            expected.setdefault(Path(output_dir) / rel.parent, set()).add(rel.name)
    removed: list[str] = []
    for folder, names in expected.items():
        if not (folder / "metadata.json").is_file():
            continue
        for stale in folder.glob("*_IN*.webp"):
            if stale.name not in names:
                stale.unlink(missing_ok=True)
                removed.append(str(stale))
    return removed


def _remove_legacy_insert_bundle_output(output_dir: Path, level: str,
                                        subject: str, qp_info) -> list[str]:
    """Delete this paper's obsolete standalone insert folder after a good commit.

    Earlier builds wrote whole insert pages beneath ``_insert/<paper-code>``.
    A successful rebuild now emits only per-question ``_IN.webp`` companions,
    so remove the matching legacy directory without touching any other paper.
    """
    subject_root = Path(output_dir) / str(level) / str(subject)
    paper_code = str(getattr(qp_info, "full_code", "") or "")
    if not paper_code or not subject_root.is_dir():
        return []
    removed: list[str] = []
    for insert_root in sorted(subject_root.rglob("_insert")):
        candidate = insert_root / paper_code
        if candidate.is_dir():
            shutil.rmtree(candidate, ignore_errors=True)
            removed.append(str(candidate))
        elif candidate.is_file():
            candidate.unlink(missing_ok=True)
            removed.append(str(candidate))
        try:
            insert_root.rmdir()  # remove only when empty after this paper's cleanup
        except OSError:
            pass
    if removed:
        logger.info("Removed legacy standalone insert output for %s: %s", paper_code, removed)
    return removed


def _commit_and_register(db, bundle_id, bundle_key, staging_root, output_dir,
                         writer, qc_review_reason=None,
                         replace_existing=True):
    """Move staged question-tree files to the real output (via StagedWriter)
    and register questions + artifacts in the database.
    Returns (ok, committed_folders, errors)."""
    final_paths = []
    for p in sorted(staging_root.rglob("*")):
        if not p.is_file():
            continue
        if p.name.startswith(".") or p.name in (
            "worker_log.txt", "failure_report.txt", "pipeline.sqlite",
            "pipeline.sqlite-wal", "pipeline.sqlite-shm",
        ):
            # Worker scratch/state is never an output artifact. The parent DB
            # owns batch state; the final tree must contain only question assets.
            continue
        rel = p.relative_to(staging_root)
        final_paths.append((str(rel), str(output_dir / rel)))

    committed = writer.commit(
        bundle_key, staging_root, final_paths,
        replace_existing=bool(replace_existing),
    )
    if not committed:
        return False, [], ["staging commit failed (destination conflict or I/O error)"]

    _remove_stale_question_insert_sidecars(output_dir, final_paths)

    # The commit succeeded, so the refreshed tree is now authoritative. Remove
    # stale DB question/artifact rows before registering the new snapshot; this
    # is what makes a QP-only -> QP+MS promotion idempotent.
    db.clear_bundle_questions(bundle_id)

    # Register questions/artifacts from the COMMITTED tree (real bytes only)
    from PIL import Image
    committed_folders = set()
    q_found = 0
    for src_rel, dest_abs in final_paths:
        dest = Path(dest_abs)
        if not dest.exists():
            continue
        folder = dest.parent
        # Register only canonical question folders; per-question ``_IN.webp``
        # companions are already in their metadata-bearing question folder.
        if (folder / "metadata.json").is_file():
            committed_folders.add(folder)
    for folder in sorted(committed_folders):
        meta = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        topic = meta.get("topic")
        topic0 = topic[0] if isinstance(topic, list) and topic else ""
        folder_rel = str(folder.relative_to(output_dir))
        needs_review = ("review_required" in folder.parts)
        q_id = db.register_question(
            bundle_id=bundle_id,
            question_num=str(meta.get("question_number", folder.name.rsplit("_", 1)[-1])),
            topic_assigned=topic0,
            folder_path=folder_rel,
            needs_review=needs_review,
        )
        q_found += 1
        for webp in sorted(folder.glob("*.webp")):
            name = webp.name
            kind = ("ms" if name.endswith("_MS.webp") else ("er" if "_ER" in name else ("ci" if "_CI" in name else ("in" if "_IN" in name else "qp"))))
            try:
                with Image.open(webp) as im:
                    w, h = im.size
            except Exception:
                w = h = None
            db.register_artifact(
                question_id=q_id, kind=kind,
                path=str(webp.relative_to(output_dir)),
                width_px=w, height_px=h, file_size=webp.stat().st_size,
            )
    return True, sorted(str(f.relative_to(output_dir)) for f in committed_folders), []


def _remove_stale_bundle_question_folders(
    output_dir: Path,
    qp_full_code: str,
    committed_folders: set[Path],
    scope_dir: Path | None = None,
) -> list[str]:
    """Remove question folders from an older snapshot of the same QP that
    were not produced by the refreshed run.  This prevents a changed
    classification or question count from leaving duplicate/stale folders.
    """
    output_dir = Path(output_dir).resolve()
    committed = {Path(p).resolve() for p in committed_folders}
    removed = []

    # Determine subject-scoped directory to avoid scanning the entire archive
    if scope_dir is None and committed:
        first_folder = next(iter(committed))
        # Folder is output_dir / Level / Subject / PaperType / Major / Q_folder
        try:
            rel = first_folder.relative_to(output_dir)
            if len(rel.parts) >= 2:
                scope_dir = output_dir / rel.parts[0] / rel.parts[1]
        except Exception:
            scope_dir = None

    search_root = scope_dir if (scope_dir and scope_dir.is_dir()) else output_dir

    # Derive question folder prefixes for this paper (e.g. 32_Summer_2023_ / 32_Summer_23_)
    target_prefixes = None
    try:
        from .paper_identifier import parse_paper_filename
        info = parse_paper_filename(qp_full_code + ".pdf")
        if info and info.variant and info.season and info.year:
            target_prefixes = (
                f"{info.variant}_{info.season}_{info.year}_",
                f"{info.variant}_{info.season}_{info.year_short}_",
            )
    except Exception:
        target_prefixes = None

    candidate_metadatas = []
    if target_prefixes and search_root.is_dir():
        # Fast path: inspect only directories matching the paper's prefix
        for root, dirs, files in os.walk(search_root):
            d_name = os.path.basename(root)
            if d_name.startswith(target_prefixes) and "metadata.json" in files:
                candidate_metadatas.append(Path(root) / "metadata.json")
    else:
        # Safe fallback
        candidate_metadatas = list(search_root.rglob("metadata.json"))

    for metadata in candidate_metadatas:
        if ".staging" in metadata.parts or metadata.parent in committed:
            continue
        try:
            data = json.loads(metadata.read_text(encoding="utf-8"))
        except Exception:
            continue
        if data.get("paper") != qp_full_code:
            continue
        folder = metadata.parent.resolve()
        if folder in committed:
            continue
        try:
            shutil.rmtree(folder)
            removed.append(str(folder))
            # Prune only empty topic/paper-type parents; never climb into the
            # subject or level root.
            parent = folder.parent
            while parent != output_dir and parent.parent != output_dir:
                if parent.exists() and not any(parent.iterdir()):
                    parent.rmdir()
                    parent = parent.parent
                else:
                    break
        except OSError:
            logger.exception("Could not remove stale bundle folder %s", folder)
    if removed:
        print(f"  [bundle] removed {len(removed)} stale question folder(s) for {qp_full_code}")
    return removed


def process_bundle(args: dict) -> dict:
    """
    Process one complete QP/MS(/ER) bundle end-to-end through the REAL
    locked stages, inside staging, then commit + register.

    Standalone function safe for multiprocessing: receives a pre-built
    bundle dict from preflight/the DB and loads only its own subject config.
    Returns status dict.
    """
    bundle_key = args["bundle_key"]
    bundle_id = args["bundle_id"]
    qp_path = Path(args["qp_path"]) if args.get("qp_path") else None
    ms_path = Path(args["ms_path"]) if args.get("ms_path") else None
    # ER identity belongs to this bundle; the same path is used for scoped
    # classifier evidence and worker-local ER output before the atomic commit.
    er_path = Path(args["er_path"]) if args.get("er_path") else None
    insert_path = Path(args["insert_path"]) if args.get("insert_path") else None
    ci_path = Path(args["ci_path"]) if args.get("ci_path") else None
    output_dir = Path(args["output_dir"])
    db_path = Path(args["db_path"])
    syllabus_code = args["syllabus_code"]
    subject = args["subject"]
    level = args["level"]
    year = args.get("year", "")
    quiet = bool(args.get("quiet_worker"))

    from .database import Database
    from .staged_writer import StagedWriter

    db = Database(db_path)
    writer = StagedWriter(output_dir)

    # Resume short-circuit: constant-time identity check (spec rule 9)
    if db.bundle_is_complete(bundle_key):
        return {"status": "already_complete", "bundle_key": bundle_key}

    staging_path = writer.get_staging_path(bundle_key)

    # Worker stdout → staging log when running pooled (readable alongside
    # preserved staging on failure; live prints when workers==1)
    log_fh = None
    if quiet:
        import contextlib
        import sys
        log_fh = open(staging_path / "worker_log.txt", "w", encoding="utf-8", errors="replace")
        sys.stdout = contextlib.redirect_stdout(log_fh).__enter__()
        sys.stderr = contextlib.redirect_stderr(log_fh).__enter__()

    try:
        # ── Input verification (fail-closed) ─────────────────────────
        if qp_path is None or not qp_path.exists():
            raise FileNotFoundError(f"QP input missing for {bundle_key}: {qp_path}")
        if ms_path is not None and not ms_path.exists():
            raise FileNotFoundError(f"MS input missing for {bundle_key}: {ms_path}")
        if er_path is not None and not er_path.exists():
            raise FileNotFoundError(f"ER input missing for {bundle_key}: {er_path}")
        if insert_path is not None and not insert_path.exists():
            raise FileNotFoundError(f"Insert input missing for {bundle_key}: {insert_path}")
        if ci_path is not None and not ci_path.exists():
            raise FileNotFoundError(f"CI input missing for {bundle_key}: {ci_path}")

        db.mark_bundle_processing(bundle_id)

        # ── Identity WITHOUT rescanning the input dir (rule 4) ───────
        from .paper_identifier import parse_paper_filename
        qp_info = parse_paper_filename(qp_path)
        ms_info = parse_paper_filename(ms_path) if ms_path is not None else None
        er_info = parse_paper_filename(er_path) if er_path is not None else None
        insert_info = parse_paper_filename(insert_path) if insert_path is not None else None
        ci_info = parse_paper_filename(ci_path) if ci_path is not None else None
        if qp_info is None:
            raise ValueError(f"cannot re-identify QP {qp_path.name}")
        if ms_path is not None and ms_info is None:
            raise ValueError(f"cannot re-identify MS {ms_path.name}")
        usable_er_info = None
        if er_path is not None:
            er_matches, er_reason = _er_matches_qp_bundle(er_info, qp_info)
            if er_matches:
                usable_er_info = er_info
                logger.info("[er-bundle] %s -> %s (%s)", er_path.name, bundle_key, er_reason)
            else:
                # Preserve QP/MS production, but never let an identity-conflicted
                # or mismatched ER supply classifier evidence or output assets.
                logger.warning("[er-bundle] refusing %s for %s: %s",
                               er_path.name, bundle_key, er_reason)

        # ── This subject's config ONLY (rule 5) ──────────────────────
        from .config_loader import load_subject_config_by_code_and_level
        year_full = str(year)
        if len(year_full) == 2 and year_full.isdigit():
            year_full = "20" + year_full
        config = load_subject_config_by_code_and_level(
            syllabus_code, level, year_full
        )
        if config is None:
            raise ValueError(
                f"no approved subject config for {syllabus_code}/{level}/{year_full}"
            )

        # ── Real locked stages, rooted inside staging (rule 6) ───────
        import sys as _sys
        proj_root = str(Path(__file__).resolve().parent.parent)
        if proj_root not in _sys.path:
            _sys.path.insert(0, proj_root)
        from types import SimpleNamespace
        from run_guarded import Gate, StageAbort, run_paper_stages
        from core.cropping_engine import CroppingEngine
        from core.ms_cropping_engine import ms_engine_for
        from core.qp_ms_matcher import QPMSMatcher
        from core.output_manager import OutputManager
        from core.pipeline_state import PipelineState

        cropping_engine = CroppingEngine(target_width=2280, quality=95, dpi=75)
        # A20: dpi steps down for fat mark schemes (caller-owned parameter;
        # the locked splitter itself is unchanged).
        ms_engine = ms_engine_for(ms_path, target_width=2280, quality=95)
        gate = Gate(staging_path)
        # Throwaway scratch state living INSIDE staging (never committed) —
        # run_paper_stages requires it; the DB is the batch source of truth.
        state = PipelineState.load_or_create(
            staging_path, subject=subject, syllabus_code=syllabus_code, level=level,
        )
        output_mgr = OutputManager(output_root=staging_path)

        local_status, local_error, saved_n = "failed", "worker did not finish", 0
        try:
            run_args = SimpleNamespace(
                low_ram=bool(args.get("low_ram", True)),
                # Full-auto is the default policy. Callers that explicitly
                # request fail-closed behavior pass full_auto=False.
                full_auto=bool(args.get("full_auto", True)),
                output=str(staging_path),
                # P4: only the identity-verified ER selected for this QP/MS
                # bundle may influence classification; unrelated ERs are refused.
                er_path=str(usable_er_info.file_path) if usable_er_info else None,
                # Keep audit traces outside staging so they are not treated as
                # question artifacts during commit, and never touch metadata.
                classification_audit_path=str(
                    output_dir / ".classification_audit" / f"{bundle_key}.jsonl"
                ),
            )
            saved_n = run_paper_stages(
                gate, run_args, bundle_key, qp_info, ms_info, subject, config,
                state, cropping_engine, ms_engine, QPMSMatcher(), output_mgr,
                insert_info=insert_info,
                ci_info=ci_info,
            )
        except StageAbort as e:
            local_status, local_error = "failed", f"stage gate abort: {e}"
        except SystemExit as e:
            local_status, local_error = "failed", f"stage runner exited: code {e.code}"
        else:
            rec = state.papers.get(bundle_key)
            if rec is not None:
                st = rec.status.value if hasattr(rec.status, "value") else str(rec.status)
                local_status = "complete" if st == "complete" else "review_or_failed"
                local_error = rec.error_message or getattr(rec, "review_reason", "") or ""
            else:
                local_status, local_error = "failed", "no local record"

        # ER output belongs to this worker's QP/MS staging bundle, never to a
        # parent-side sweep over the entire output tree. This physical scope is
        # an additional isolation boundary beyond the identity check above:
        # a Biology ER cannot even see Chemistry question metadata here.
        if usable_er_info is not None and local_status in {"complete", "review_or_failed"}:
            try:
                from .examiner_report import attach_examiner_reports_to_output
                from .er_question_crops import attach_question_er_crops
                er_stats = attach_examiner_reports_to_output([usable_er_info], staging_path)
                crop_stats = attach_question_er_crops(
                    [usable_er_info], staging_path,
                    verified_folders=er_stats.get("verified_folders"),
                )
                logger.info(
                    "[er-bundle] %s: verified=%s crops=%s errors=%s",
                    bundle_key, er_stats.get("questions_attached", 0),
                    crop_stats.get("crops_written", 0),
                    (er_stats.get("errors", []) + crop_stats.get("errors", []))[:2],
                )
            except Exception as er_exc:
                # ER is optional evidence/asset. A parser or crop failure must
                # not discard correct QP/MS output; it is logged and surfaced.
                logger.warning("[er-bundle] ER processing failed for %s: %s",
                               bundle_key, er_exc)

        # ── Verdict mapping (local scratch verdict -> batch DB verdict) ──
        review_markers = ("QC needs_review", "MISSING_MS", "CROP_EMPTY")
        commit_ok_shapes = ("complete",) + tuple(review_markers)

        review_folders = [
            p for p in staging_path.rglob("*")
            if p.is_dir() and "review_required" in p.parts
        ]
        if local_status == "complete" and review_folders:
            verdict = "review_required"
            local_error = (
                f"{len(review_folders)} question folder(s) require review; "
                "bundle output is preserved but not marked complete"
            )
        elif local_status == "complete":
            verdict = "complete"
        elif local_status == "review_or_failed":
            # PipelineState has an explicit REVIEW_REQUIRED status even when
            # the crops themselves live in normal topic folders (for example,
            # a paper year outside the verified syllabus editions).
            verdict = "review_required"
            local_error = local_error or "bundle marked REVIEW_REQUIRED by guarded stages"
        elif any(m in local_error for m in review_markers):
            verdict = "review_required"
        else:
            verdict = "failed"

        stage_errors = []
        if local_status in {"complete", "review_or_failed"} or any(
                m in local_error for m in commit_ok_shapes[1:]):
            # CROP_EMPTY stages nothing worth committing; fail review-closed.
            has_questions = any(
                d.is_dir() and "_Q" in d.name
                for d in staging_path.rglob("*")
            )
            if has_questions:
                stage_errors = _validate_staging(
                    staging_path, paper_format=args.get("paper_format")
                )
                if stage_errors:
                    for err in stage_errors:
                        logger.warning(f"Validation: {err}")
                    db.mark_bundle_review(
                        bundle_id, f"{len(stage_errors)} staging validation issues: "
                                   f"{stage_errors[0]}")
                    _finish(log_fh)
                    return {"status": "review_required", "bundle_key": bundle_key,
                            "errors": stage_errors}

                ok, committed, commit_errors = _commit_and_register(
                    db, bundle_id, bundle_key, staging_path, output_dir, writer,
                    replace_existing=bool(args.get("replace_existing", True)))
                if not ok:
                    db.mark_bundle_failed(bundle_id, "Staging commit failed: "
                                          + "; ".join(commit_errors))
                    writer.rollback(bundle_key, staging_path, preserve=True)
                    _finish(log_fh)
                    return {"status": "failed", "bundle_key": bundle_key,
                            "error": "commit_failed"}

                _remove_stale_bundle_question_folders(
                    output_dir,
                    qp_info.full_code,
                    {output_dir / rel for rel in committed},
                    scope_dir=output_dir / level / subject,
                )
                _remove_legacy_insert_bundle_output(output_dir, level, subject, qp_info)

                rec = state.papers.get(bundle_key)
                # Local record counts are zero on review paths (mark_failed
                # never sets them) — fall back to the runner's own saved_n
                # and then the committed-folder count. Never report 0 beside
                # a committed tree.
                found = ((rec.questions_found if rec is not None else 0) or 0) \
                        or saved_n or len(committed)
                saved = ((rec.questions_saved if rec is not None else 0) or 0) \
                        or saved_n or len(committed)

                # Direct callers retain local manifest recording. The batch
                # runner passes manifest_owner='parent' so one parent process
                # serializes every manifest mutation and avoids multi-worker
                # last-writer-wins JSON races.
                if args.get("manifest_owner") != "parent":
                    try:
                        from .manifest import ProcessingManifest
                        manifest = ProcessingManifest.load_or_create(output_dir)
                        input_paths = [p for p in (qp_path, ms_path, er_path, insert_path, ci_path) if p is not None]
                        if verdict == "review_required":
                            manifest.record_bundle_review(bundle_key, input_paths, local_error, committed)
                        else:
                            manifest.record_bundle_completed(bundle_key, input_paths, committed, found, saved)
                        manifest.save()
                    except Exception as e:
                        logger.warning(f"Could not record bundle in processing manifest: {e}")

                if verdict == "review_required":
                    # Crops committed; humans must triage. DB truthfully says so —
                    # and the counts stay visible in progress reporting.
                    db.set_bundle_counts(bundle_id, found, saved)
                    db.mark_bundle_review(bundle_id, local_error)
                else:
                    db.mark_bundle_complete(
                        bundle_id, questions_found=found, questions_saved=saved)
                _finish(log_fh)
                return {"status": verdict, "bundle_key": bundle_key,
                        "questions": saved, "needs_review": [],
                        **({"reason": local_error} if verdict == "review_required" else {})}

        # failed / nothing committable
        if args.get("manifest_owner") != "parent":
            try:
                from .manifest import ProcessingManifest
                manifest = ProcessingManifest.load_or_create(output_dir)
                input_paths = [p for p in (qp_path, ms_path, er_path, insert_path, ci_path) if p is not None]
                manifest.record_bundle_failed(bundle_key, input_paths, local_error or "unknown worker failure")
                manifest.save()
            except Exception:
                pass

        db.mark_bundle_failed(bundle_id, local_error or "unknown worker failure")
        writer.rollback(bundle_key, staging_path, preserve=True)
        gc.collect()
        _finish(log_fh)
        return {"status": verdict if verdict != "complete" else "failed",
                "bundle_key": bundle_key,
                "error": local_error or "unknown worker failure"}

    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"Bundle {bundle_key} failed: {e}")
        if args.get("manifest_owner") != "parent":
            try:
                from .manifest import ProcessingManifest
                manifest = ProcessingManifest.load_or_create(output_dir)
                input_paths = [p for p in (qp_path, ms_path, er_path, insert_path, ci_path) if p is not None]
                manifest.record_bundle_failed(bundle_key, input_paths, str(e))
                manifest.save()
            except Exception:
                pass
        try:
            db.mark_bundle_failed(bundle_id, str(e), tb)
        except Exception:
            logger.error(f"DB mark_bundle_failed also failed for {bundle_key}")
        writer.rollback(bundle_key, staging_path, preserve=True)
        gc.collect()
        _finish(log_fh)
        return {"status": "failed", "bundle_key": bundle_key,
                "error": str(e), "trace": tb}


def _finish(log_fh):
    if log_fh is not None:
        import sys
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
        log_fh.close()
