"""Central control menu and archive utilities for ExamVoid.

The menu keeps board-specific runners explicit: CAIE work uses the Cambridge
pipeline; AQA, Edexcel, IB, and SAT each have their own input folder and use the
universal adapter pipeline. The combined action runs all populated folders.
"""

from __future__ import annotations

import argparse
import configparser
import gc
import json
import logging
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

logger = logging.getLogger("examvoid.control")
SETTINGS_FILE = ROOT_DIR / "settings.ini"


# ==============================================================================
# 1. SETTINGS MANAGER (Item 12)
# ==============================================================================

class SettingsManager:
    """Manages application settings stored in settings.ini with sane defaults."""

    DEFAULT_SETTINGS = {
        "input_folder": "input",
        "output_folder": "output",
        "workers": "auto",
        "low_ram": "auto",
        "performance": "auto",
        "logging_level": "INFO",
    }

    def __init__(self, path: Path | str = SETTINGS_FILE):
        self.path = Path(path).resolve()
        self.settings: Dict[str, str] = dict(self.DEFAULT_SETTINGS)
        self.load()

    def load(self) -> None:
        if not self.path.is_file():
            self.save()
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" in line:
                        k, v = line.split("=", 1)
                        self.settings[k.strip()] = v.strip()
        except Exception as e:
            logger.warning(f"Could not load {self.path}: {e}")

    def save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            lines = [
                "# ExamVoid launcher settings. Keep one key=value per line.",
                "# Relative paths are resolved from the repository root.",
            ]
            for k, v in self.settings.items():
                lines.append(f"{k}={v}")
            lines.append("")
            self.path.write_text("\n".join(lines), encoding="utf-8")
        except Exception as e:
            logger.error(f"Could not save settings to {self.path}: {e}")

    def get(self, key: str, default: Optional[str] = None) -> str:
        return self.settings.get(key, default or self.DEFAULT_SETTINGS.get(key, ""))

    def set(self, key: str, value: str) -> None:
        self.settings[key] = str(value)
        self.save()


# ==============================================================================
# 2. SINGLE-INSTANCE LOCK & STALE LOCK RECOVERY (Item 16)
# ==============================================================================

def is_pid_alive(pid: int) -> bool:
    """Check if process with given PID is actively running across OS platforms."""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        try:
            cmd = ["tasklist", "/FI", f"PID eq {pid}", "/NH"]
            res = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=5)
            return str(pid) in res.stdout
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            # Running as another user or restricted permissions, but still alive
            return True
        except Exception:
            return False


class ExamVoidLock:
    """Atomic single-instance lock with conservative stale-PID recovery.

    Directory creation uses ``exist_ok=False`` so two simultaneous launchers
    cannot both claim the same archive. A lock is removed automatically only
    after its recorded PID is confirmed dead. A live lock is never forcefully
    deleted, because that could corrupt a shared output tree.
    """

    def __init__(self, lock_dir: Path | str):
        self.lock_dir = Path(lock_dir).resolve()
        self.pid_file = self.lock_dir / "pid.txt"
        self.started_file = self.lock_dir / "started.txt"
        self.command_file = self.lock_dir / "command.txt"
        self.owner_file = self.lock_dir / "owner.txt"
        self.owner_token = f"{os.getpid()}-{time.time_ns()}-{uuid.uuid4().hex}"
        self.acquired = False

    def acquire(self, interactive: bool = True, command_desc: str = "ExamVoid") -> bool:
        # A stale lock can be recovered once. If another launcher wins the
        # race after recovery, the second loop reports the live lock normally.
        for _attempt in range(2):
            try:
                self.lock_dir.mkdir(parents=True, exist_ok=False)
            except FileExistsError:
                pid = self._read_pid()
                if pid is not None and not is_pid_alive(pid):
                    print(f"[INFO] Stale lock detected (dead PID {pid}) -> Auto-recovering...")
                    self._remove_stale_lock(expected_pid=pid)
                    continue

                started = (self.started_file.read_text(encoding="utf-8").strip()
                           if self.started_file.exists() else "Unknown")
                print("\n" + "=" * 50)
                print("EXAMVOID IS ALREADY RUNNING")
                print(f"PID: {pid if pid is not None else 'unknown'}")
                print(f"Started: {started}")
                print("=" * 50)
                if not interactive:
                    return False

                print("1. Exit")
                print("2. Recheck lock status")
                choice = input("\nSelect: ").strip()
                if choice == "2":
                    # Recheck only; never tear down a lock held by a living
                    # process. If it has become stale, the next loop recovers.
                    pid = self._read_pid()
                    if pid is not None and not is_pid_alive(pid):
                        print(f"[INFO] Lock is now stale (dead PID {pid}) -> recovering.")
                        self._remove_stale_lock(expected_pid=pid)
                        continue
                return False
            except Exception as e:
                print(f"[ERROR] Could not create run lock at {self.lock_dir}: {e}")
                return False
            else:
                try:
                    self.pid_file.write_text(str(os.getpid()), encoding="utf-8")
                    self.started_file.write_text(time.strftime("%Y-%m-%d %H:%M:%S"), encoding="utf-8")
                    self.command_file.write_text(command_desc, encoding="utf-8")
                    self.owner_file.write_text(self.owner_token, encoding="utf-8")
                    self.acquired = True
                    return True
                except Exception as e:
                    print(f"[ERROR] Could not initialize run lock at {self.lock_dir}: {e}")
                    self._remove_own_lock()
                    return False
        print(f"[ERROR] Could not acquire run lock: {self.lock_dir}")
        return False

    def _remove_stale_lock(self, expected_pid: Optional[int] = None) -> bool:
        """Remove only a verified-dead lock; protect against PID replacement."""
        current_pid = self._read_pid()
        if expected_pid is not None and current_pid != expected_pid:
            return False
        if current_pid is not None and is_pid_alive(current_pid):
            return False
        try:
            shutil.rmtree(self.lock_dir)
            return True
        except FileNotFoundError:
            return True
        except Exception as e:
            logger.warning("Failed to remove stale lock %s: %s", self.lock_dir, e)
            return False

    def _remove_own_lock(self) -> None:
        """Remove the lock only if this object owns the unique token."""
        try:
            if self.owner_file.is_file() and self.owner_file.read_text(encoding="utf-8") == self.owner_token:
                shutil.rmtree(self.lock_dir, ignore_errors=True)
        except Exception as e:
            logger.warning("Failed to remove owned lock %s: %s", self.lock_dir, e)

    def release(self) -> None:
        if self.acquired:
            self._remove_own_lock()
        self.acquired = False

    def _read_pid(self) -> Optional[int]:
        if self.pid_file.is_file():
            try:
                return int(self.pid_file.read_text(encoding="utf-8").strip())
            except Exception:
                return None
        return None

    def __enter__(self):
        if not self.acquire(interactive=False):
            raise RuntimeError(f"Could not acquire lock: {self.lock_dir} is in use.")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

# ==============================================================================
# 3. GRACEFUL SHUTDOWN HANDLER (Item 17)
# ==============================================================================

class GracefulShutdown:
    """Manages signals (SIGINT, SIGTERM) to save manifest and release resources."""

    def __init__(self):
        self.interrupted = False
        self.callbacks: List[Tuple[str, Callable[[], None]]] = []
        self._installed = False
        self._orig_sigint = None
        self._orig_sigterm = None

    def register(self, name: str, cb: Callable[[], None]) -> None:
        self.callbacks.append((name, cb))

    def install(self) -> None:
        if self._installed:
            return
        self._orig_sigint = signal.signal(signal.SIGINT, self._handle_signal)
        try:
            self._orig_sigterm = signal.signal(signal.SIGTERM, self._handle_signal)
        except Exception:
            pass
        self._installed = True

    def uninstall(self) -> None:
        if not self._installed:
            return
        if self._orig_sigint:
            signal.signal(signal.SIGINT, self._orig_sigint)
        if self._orig_sigterm:
            signal.signal(signal.SIGTERM, self._orig_sigterm)
        self._installed = False

    def _handle_signal(self, signum, frame):
        self.interrupted = True
        print("\n\nShutdown requested.")
        print("Finishing current operation...")
        print("Saving manifest...")
        print("Flushing pending writes...")
        print("Releasing resources...")
        for name, cb in reversed(self.callbacks):
            try:
                cb()
            except Exception as e:
                print(f"  [cleanup] Error in {name}: {e}")
        print("Shutdown complete.")
        sys.exit(130)


# ==============================================================================
# 4. ARCHIVE AUDITING & STATISTICS (Items 6 & 9)
# ==============================================================================

def _read_archive_database(output_dir: Path) -> Dict[str, List[dict]]:
    """Read archive SQLite state without creating or mutating it."""
    import sqlite3
    from urllib.parse import quote

    db_path = Path(output_dir) / "pipeline.sqlite"
    if not db_path.is_file():
        return {"files": [], "bundles": [], "questions": [], "artifacts": []}
    try:
        uri = "file:" + quote(str(db_path.resolve()), safe="/") + "?mode=ro"
        conn = sqlite3.connect(uri, uri=True)
        conn.row_factory = sqlite3.Row
        data = {
            "files": [dict(row) for row in conn.execute("SELECT * FROM files")],
            "bundles": [dict(row) for row in conn.execute("SELECT * FROM bundles")],
            "questions": [dict(row) for row in conn.execute("SELECT * FROM questions")],
            "artifacts": [dict(row) for row in conn.execute("SELECT * FROM artifacts")],
        }
        conn.close()
        return data
    except Exception as e:
        logger.warning("Could not read archive database %s: %s", db_path, e)
        return {"files": [], "bundles": [], "questions": [], "artifacts": []}


def _relative_output_path(output_dir: Path, value: str | Path) -> str:
    """Normalize a stored folder/artifact path for audit comparisons."""
    path = Path(value)
    try:
        if path.is_absolute():
            return str(path.resolve().relative_to(output_dir.resolve()))
    except ValueError:
        return str(path)
    return str(path)


class ArchiveAuditor:
    """Perform an explicit, non-destructive archive integrity inspection.

    Batch processing uses SQLite as the source of truth for bundle/question
    state and the JSON manifest for file-level fingerprint lifecycle.  This
    audit reads both stores; it never invokes the crop/classifier pipeline.
    """

    def __init__(self, input_dir: Path, output_dir: Path):
        self.input_dir = Path(input_dir).resolve()
        self.output_dir = Path(output_dir).resolve()

    def audit(self) -> Dict[str, Any]:
        from core.manifest import FileStatus, ProcessingManifest

        manifest = ProcessingManifest.load_or_create(self.output_dir)
        db = _read_archive_database(self.output_dir)
        source_files = list(self.input_dir.rglob("*.pdf")) if self.input_dir.is_dir() else []
        source_paths = {str(p.resolve()) for p in source_files}

        # File-level states are taken from the SHA-256 manifest. Unregistered
        # on-disk PDFs are genuinely new, even before the next preflight.
        file_counts = {status.value: 0 for status in FileStatus}
        for rec in manifest.files.values():
            file_counts[rec.status] = file_counts.get(rec.status, 0) + 1
        file_counts[FileStatus.NEW.value] += len(source_paths - set(manifest.files))

        # Bundle-level states come from the transactional SQLite controller.
        # Direct worker tests can legitimately have only a manifest, so retain
        # a manifest fallback if no database is present yet.
        bundle_counts = {"complete": 0, "failed": 0, "review_required": 0,
                         "pending": 0, "processing": 0}
        if db["bundles"]:
            for row in db["bundles"]:
                status = str(row.get("status", "pending"))
                bundle_counts[status] = bundle_counts.get(status, 0) + 1
        else:
            for record in manifest.bundles.values():
                status = str(record.status).lower()
                bundle_counts[status] = bundle_counts.get(status, 0) + 1

        # Registered artifacts disappearing is an actionable integrity issue.
        missing_outputs = 0
        if db["artifacts"]:
            for row in db["artifacts"]:
                artifact = self.output_dir / row["path"]
                if not artifact.exists():
                    missing_outputs += 1
        else:
            for record in manifest.bundles.values():
                if record.status != "complete":
                    continue
                for art in record.artifacts:
                    artifact = Path(art)
                    if not artifact.is_absolute():
                        artifact = self.output_dir / artifact
                    if not artifact.exists():
                        missing_outputs += 1

        # A question folder is an orphan only if it has canonical metadata but
        # no registered question-row in the authoritative database/manifest.
        registered_folders: Set[str] = set()
        if db["questions"]:
            registered_folders = {
                _relative_output_path(self.output_dir, row["folder_path"])
                for row in db["questions"] if row.get("folder_path")
            }
        else:
            for record in manifest.bundles.values():
                for art in record.artifacts:
                    registered_folders.add(_relative_output_path(self.output_dir, Path(art).parent))

        output_question_folders = set()
        if self.output_dir.is_dir():
            for metadata in self.output_dir.rglob("metadata.json"):
                try:
                    output_question_folders.add(str(metadata.parent.relative_to(self.output_dir)))
                except ValueError:
                    continue
        orphaned_outputs = len(output_question_folders - registered_folders)

        # State consistency: missing source paths registered by either state
        # store, plus complete DB bundles with no registered question data.
        manifest_inconsistencies = sum(
            1 for path in manifest.files if not Path(path).is_file()
        )
        manifest_inconsistencies += sum(
            1 for row in db["files"] if row.get("path") and not Path(row["path"]).is_file()
        )
        if db["bundles"]:
            question_bundle_ids = {row["bundle_id"] for row in db["questions"]}
            manifest_inconsistencies += sum(
                1 for row in db["bundles"]
                if row.get("status") == "complete" and row["id"] not in question_bundle_ids
            )

        return {
            "source_files": len(source_files),
            "completed": bundle_counts.get("complete", 0),
            "failed": bundle_counts.get("failed", 0),
            "needs_review": bundle_counts.get("review_required", 0),
            "new": file_counts.get(FileStatus.NEW.value, 0),
            "changed": file_counts.get(FileStatus.CHANGED.value, 0),
            "pending": bundle_counts.get("pending", 0) + bundle_counts.get("processing", 0),
            "missing_outputs": missing_outputs,
            "orphaned_outputs": orphaned_outputs,
            "manifest_inconsistencies": manifest_inconsistencies,
            "database_available": bool(db["bundles"] or (self.output_dir / "pipeline.sqlite").is_file()),
            "file_statuses": file_counts,
            "bundle_statuses": bundle_counts,
        }

    def print_audit_report(self) -> None:
        res = self.audit()
        print("\n" + "=" * 50)
        print("EXAMVOID ARCHIVE AUDIT")
        print("=" * 50)
        print(f"Source files:              {res['source_files']:,}")
        print(f"Completed bundles:         {res['completed']:,}")
        print(f"Failed bundles:            {res['failed']:,}")
        print(f"Needs review bundles:      {res['needs_review']:,}")
        print(f"Pending/resumable bundles: {res['pending']:,}")
        print(f"New source files:          {res['new']:,}")
        print(f"Changed source files:      {res['changed']:,}")
        print("-" * 50)
        print(f"Missing outputs:           {res['missing_outputs']:,}")
        print(f"Orphaned outputs:          {res['orphaned_outputs']:,}")
        print(f"State inconsistencies:     {res['manifest_inconsistencies']:,}")
        print("=" * 50)


class ArchiveStatistics:
    """Compute archive metrics from real database rows and output bytes.

    Statistics intentionally perform a tree walk only when this explicit view
    is requested; no normal batch path repeatedly scans the archive.
    """

    def __init__(self, input_dir: Path, output_dir: Path):
        self.input_dir = Path(input_dir).resolve()
        self.output_dir = Path(output_dir).resolve()

    def get_stats(self) -> Dict[str, Any]:
        from statistics import median
        from core.manifest import ProcessingManifest

        source_files = list(self.input_dir.rglob("*.pdf")) if self.input_dir.is_dir() else []
        db = _read_archive_database(self.output_dir)
        manifest = ProcessingManifest.load_or_create(self.output_dir)

        if db["questions"]:
            total_questions = len(db["questions"])
        elif self.output_dir.is_dir():
            total_questions = sum(1 for _ in self.output_dir.rglob("metadata.json"))
        else:
            total_questions = 0

        if db["bundles"]:
            variants = {str(row["component"]) for row in db["bundles"] if row.get("component")}
            subjects = {str(row["syllabus_code"]) for row in db["bundles"] if row.get("syllabus_code")}
            statuses = {"complete": 0, "failed": 0, "pending": 0, "review_required": 0, "processing": 0}
            for row in db["bundles"]:
                state = str(row.get("status", "pending"))
                statuses[state] = statuses.get(state, 0) + 1
            durations = [
                float(row["completed_at"]) - float(row["started_at"])
                for row in db["bundles"]
                if row.get("status") == "complete"
                and row.get("started_at") is not None
                and row.get("completed_at") is not None
                and float(row["completed_at"]) >= float(row["started_at"])
            ]
        else:
            variants, subjects = set(), set()
            for f in source_files:
                match = re.search(r"(\d{4})_[a-z]+\d{2}_[a-z]+_(\d{1,2})", f.stem.lower())
                if match:
                    subjects.add(match.group(1))
                    variants.add(match.group(2))
            statuses = {"complete": 0, "failed": 0, "pending": 0, "review_required": 0, "processing": 0}
            for record in manifest.bundles.values():
                state = str(record.status).lower()
                statuses[state] = statuses.get(state, 0) + 1
            durations = []

        input_pdf_bytes = sum(p.stat().st_size for p in source_files)
        webp_bytes = (sum(p.stat().st_size for p in self.output_dir.rglob("*.webp"))
                      if self.output_dir.is_dir() else 0)
        meta_bytes = (sum(p.stat().st_size for p in self.output_dir.rglob("metadata.json"))
                      if self.output_dir.is_dir() else 0)

        duration_total = sum(durations)
        return {
            "files": len(source_files),
            "questions": total_questions,
            "variants": len(variants),
            "subjects": len(subjects),
            "completed": statuses.get("complete", 0),
            "failed": statuses.get("failed", 0),
            "pending": statuses.get("pending", 0) + statuses.get("processing", 0),
            "needs_review": statuses.get("review_required", 0),
            "input_pdf_mb": input_pdf_bytes / (1024 * 1024),
            "webp_mb": webp_bytes / (1024 * 1024),
            "meta_kb": meta_bytes / 1024,
            "average_processing_sec": (duration_total / len(durations)) if durations else None,
            "median_processing_sec": median(durations) if durations else None,
            "worker_throughput_files_per_min": (len(durations) * 60 / duration_total)
                                               if duration_total > 0 else None,
        }

    def print_stats_report(self) -> None:
        s = self.get_stats()
        print("\n" + "=" * 50)
        print("ARCHIVE STATISTICS")
        print("=" * 50)
        print(f"Files:               {s['files']:,}")
        print(f"Questions:           {s['questions']:,}")
        print(f"Variants:            {s['variants']:,}")
        print(f"Subjects:            {s['subjects']:,}")
        print("-" * 50)
        print(f"Completed:           {s['completed']:,}")
        print(f"Failed:              {s['failed']:,}")
        print(f"Pending:             {s['pending']:,}")
        print(f"Needs review:        {s['needs_review']:,}")
        if s["average_processing_sec"] is not None:
            print("-" * 50)
            print(f"Average processing:  {s['average_processing_sec']:.2f} sec/bundle")
            print(f"Median processing:   {s['median_processing_sec']:.2f} sec/bundle")
            print(f"Worker throughput:   {s['worker_throughput_files_per_min']:.2f} bundles/min")
        print("-" * 50)
        print("Storage:")
        print(f"  Input PDFs:        {s['input_pdf_mb']:.2f} MB")
        print(f"  WebP outputs:      {s['webp_mb']:.2f} MB")
        print(f"  Metadata:          {s['meta_kb']:.2f} KB")
        print("=" * 50)


# ==============================================================================
# 5. DRY-RUN PREVIEW (Item 7)
# ==============================================================================

class DryRunPreviewer:
    """Build the exact shared-preflight plan without modifying archive state."""

    def __init__(self, input_dir: Path, output_dir: Path):
        self.input_dir = Path(input_dir).resolve()
        self.output_dir = Path(output_dir).resolve()

    def preview(self, *, retry_failed: bool = False, **filters) -> Dict[str, Any]:
        from core.preflight import Preflight

        plan = Preflight(self.input_dir, self.output_dir, db=None).preview(
            retry_failed=retry_failed, **filters,
        )
        # Compatibility aliases are useful to integrations which showed
        # file-style labels before bundle-level planning was added.
        plan["new_files"] = plan["new"]
        plan["changed_files"] = plan["changed"]
        plan["failed_files"] = plan["failed"]
        plan["already_completed"] = plan["completed"]
        return plan

    def print_preview(self, *, retry_failed: bool = False, **filters) -> None:
        p = self.preview(retry_failed=retry_failed, **filters)
        print("\n" + "=" * 50)
        print("EXAMVOID DRY RUN — NO FILES OR STATE WILL CHANGE")
        print("=" * 50)
        print(f"Source files:           {p['source_files']:,}")
        print(f"Bundles in scope:       {p['bundles_seen']:,}")
        print(f"New bundles:            {p['new']:,}")
        print(f"Changed bundles:        {p['changed']:,}")
        print(f"Pending/resumable:      {p['pending'] + p['processing']:,}")
        print(f"Failed bundles:         {p['failed']:,}")
        print(f"Already completed:      {p['completed']:,}")
        print(f"Needs review:           {p['needs_review']:,}")
        print("-" * 50)
        print(f"Would process now:      {p['would_process']:,}")
        if p["failed"] and not p["retry_failed"]:
            print("Failed bundles are excluded from Process New Files; Resume includes retryable failures.")
        print("No files, manifests, databases, or archive outputs will be modified.")
        print("=" * 50)

# ==============================================================================
# 6. SYSTEM & INSTALLATION VERIFICATION (Item 10)
# ==============================================================================

class SystemVerifier:
    """Verifies runtime environment, libraries, configs, and permissions."""

    def __init__(self, input_dir: Path, output_dir: Path):
        self.input_dir = Path(input_dir).resolve()
        self.output_dir = Path(output_dir).resolve()

    def verify(self) -> Tuple[bool, List[Tuple[str, bool, str]]]:
        checks = []

        # 1. Python version (>= 3.10)
        py_ver = sys.version_info
        py_ok = py_ver >= (3, 10)
        checks.append(("Python >= 3.10", py_ok, f"{py_ver.major}.{py_ver.minor}.{py_ver.micro}"))

        # 2. Required packages
        for pkg, name in [
            ("fitz", "PyMuPDF"),
            ("PIL", "Pillow"),
            ("numpy", "NumPy"),
            ("cv2", "OpenCV"),
            ("reportlab", "ReportLab"),
            ("scipy", "SciPy"),
            ("imagehash", "ImageHash"),
            ("pywt", "PyWavelets"),
            ("requests", "Requests"),
        ]:
            try:
                __import__(pkg)
                checks.append((f"Package {name}", True, "Installed"))
            except ImportError:
                checks.append((f"Package {name}", False, "Missing"))

        # 3. PDF Processing Library
        try:
            import fitz
            doc = fitz.open()
            doc.new_page()
            doc.close()
            checks.append(("PDF processing libraries (PyMuPDF)", True, f"v{fitz.__version__}"))
        except Exception as e:
            checks.append(("PDF processing libraries (PyMuPDF)", False, str(e)))

        # 4. Image Processing Libraries
        try:
            from PIL import Image
            import cv2
            img = Image.new("RGB", (10, 10), color="white")
            checks.append(("Image processing libraries (Pillow, OpenCV)", True, "Ready"))
        except Exception as e:
            checks.append(("Image processing libraries (Pillow, OpenCV)", False, str(e)))

        # 5. Configuration (settings.ini & subject configs)
        settings_ok = SETTINGS_FILE.is_file()
        subjects_ok = (ROOT_DIR / "subjects_caie").is_dir() or (ROOT_DIR / "topics").is_dir()
        checks.append(("Configuration (settings.ini & taxonomy)", settings_ok and subjects_ok, "Verified"))

        # 6. Input directory
        checks.append(("Input directory", self.input_dir.is_dir(), str(self.input_dir)))

        # 7. Output directory
        try:
            self.output_dir.mkdir(parents=True, exist_ok=True)
            checks.append(("Output directory", self.output_dir.is_dir(), str(self.output_dir)))
        except Exception as e:
            checks.append(("Output directory", False, str(e)))

        # 8. Manifest & SQLite access
        from core.manifest import ProcessingManifest
        try:
            m = ProcessingManifest.load_or_create(self.output_dir)
            checks.append(("Manifest & State Store", True, "Accessible"))
        except Exception as e:
            checks.append(("Manifest & State Store", False, str(e)))

        # 9. Write permissions check
        try:
            test_file = self.output_dir / f".perm_test_{os.getpid()}.tmp"
            test_file.write_text("test", encoding="utf-8")
            test_file.unlink()
            checks.append(("Write permissions", True, "Verified"))
        except Exception as e:
            checks.append(("Write permissions", False, str(e)))

        all_ok = all(ok for _, ok, _ in checks)
        return all_ok, checks

    def print_verification_report(self) -> bool:
        all_ok, checks = self.verify()
        print("\n" + "=" * 50)
        print("EXAMVOID SYSTEM CHECK")
        print("=" * 50)
        for label, ok, detail in checks:
            mark = "✓" if ok else "✗"
            status = detail if not ok else ""
            print(f"{mark} {label} {status}".strip())
        print("-" * 50)
        if all_ok:
            print("SYSTEM READY")
        else:
            print("SYSTEM CHECKS FAILED — resolve above issues.")
        print("=" * 50)
        return all_ok


# ==============================================================================
# 7. SAFE TEMPORARY FILE CLEANUP (Item 11)
# ==============================================================================

class SafeCleaner:
    """Clean only ExamVoid-owned temporary resources, conservatively.

    SQLite ``-wal``/``-shm`` files are intentionally *not* removed here:
    SQLite manages them and deleting a live journal risks data loss. A staging
    tree is removed only when no live ExamVoid lock protects an active run.
    """

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir).resolve()

    @property
    def staging_dir(self) -> Path:
        return self.output_dir / ".staging"

    @property
    def lock_dir(self) -> Path:
        return self.output_dir / ".examvoid_run_lock"

    def _live_lock(self) -> bool:
        lock = ExamVoidLock(self.lock_dir)
        pid = lock._read_pid()
        # An unreadable lock is considered live/unsafe; never clean around it.
        return self.lock_dir.exists() and (pid is None or is_pid_alive(pid))

    def _stale_lock(self) -> bool:
        lock = ExamVoidLock(self.lock_dir)
        pid = lock._read_pid()
        return self.lock_dir.exists() and pid is not None and not is_pid_alive(pid)

    def scan_temp_files(self) -> List[Path]:
        """Return only recognized safe files; never wildcard user data."""
        temp_paths: List[Path] = []
        if not self.output_dir.is_dir():
            return temp_paths

        # Atomic manifest writes are the only top-level .tmp files ExamVoid
        # creates. Generic "*.tmp" files are not assumed to be ours.
        temp_paths.extend(
            p for p in self.output_dir.rglob(".proc_manifest_*.tmp") if p.is_file()
        )

        # Failed/interrupted worker staging is owned entirely by ExamVoid, but
        # not safe to touch while another process holds the active lock.
        if self.staging_dir.is_dir() and not self._live_lock():
            temp_paths.extend(p for p in self.staging_dir.rglob("*") if p.is_file())

        # A verified dead lock is a safe cleanup candidate. Its files are
        # returned so the report has an accurate item/size count.
        if self._stale_lock():
            temp_paths.extend(p for p in self.lock_dir.rglob("*") if p.is_file())
        return temp_paths

    def clean(self, interactive: bool = True) -> int:
        temp_files = self.scan_temp_files()
        total_size = sum(p.stat().st_size for p in temp_files if p.is_file())
        stale_lock = self._stale_lock()
        clean_staging = self.staging_dir.is_dir() and not self._live_lock()
        count = len(temp_files)

        print("\n" + "=" * 50)
        print("SAFE TEMPORARY FILE CLEANUP")
        print("=" * 50)
        print(f"Temporary files found: {count}")
        print(f"Estimated size:        {total_size / 1024:.2f} KB ({total_size / (1024 * 1024):.2f} MB)")
        if self._live_lock():
            print("Active ExamVoid lock detected: staging and lock are protected.")
        print("=" * 50)

        if count == 0 and not clean_staging and not stale_lock:
            print("No safe temporary files found.")
            return 0

        if interactive:
            choice = input("\nDelete safe temporary files? [Y/N]: ").strip().upper()
            if choice != "Y":
                print("Cleanup cancelled.")
                return 0

        deleted = 0
        # Remove individual atomic-manifest temporary files first.
        for p in temp_files:
            try:
                if p.is_file() and not self.staging_dir in p.parents and not self.lock_dir in p.parents:
                    p.unlink()
                    deleted += 1
            except OSError:
                logger.warning("Could not remove temporary file %s", p)

        # A stale lock has already had its PID checked immediately above.
        if stale_lock:
            lock = ExamVoidLock(self.lock_dir)
            if lock._remove_stale_lock(expected_pid=lock._read_pid()):
                deleted += sum(1 for p in temp_files if self.lock_dir in p.parents)

        # Remove the staging tree as one owned temporary unit. Count its files
        # rather than generated folders so the report remains meaningful.
        if clean_staging and self.staging_dir.exists():
            staging_files = sum(1 for p in self.staging_dir.rglob("*") if p.is_file())
            shutil.rmtree(self.staging_dir, ignore_errors=True)
            if not self.staging_dir.exists():
                deleted += staging_files

        print(f"[OK] Cleaned {deleted} safe temporary file(s).")
        return deleted

# ==============================================================================
# 8. PERFORMANCE BENCHMARK (Item 14)
# ==============================================================================

class PerformanceBenchmarker:
    """Measure real quick control-plane timings and save a JSON receipt.

    Full crop/classification profiling remains available through the existing
    Developer Tools -> Pipeline Profiler command, because it intentionally
    runs a real fixture and can be considerably slower.
    """

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir).resolve()
        self.benchmarks_dir = ROOT_DIR / "benchmarks"

    def run_benchmark(self) -> Dict[str, Any]:
        from core.dedup import VariantDuplicateIndex
        from core.manifest import ProcessingManifest

        print("\n" + "=" * 50)
        print("RUNNING EXAMVOID PERFORMANCE BENCHMARK")
        print("=" * 50)

        t_start = time.perf_counter()
        times: Dict[str, float] = {}

        # 1. PDF loading and text extraction
        sample_pdf = ROOT_DIR / "fixtures" / "actual_accounting_9706" / "9706_s23_qp_32.pdf"
        if sample_pdf.is_file():
            import fitz
            t0 = time.perf_counter()
            doc = fitz.open(sample_pdf)
            _ = [p.get_text() for p in doc]
            doc.close()
            times["pdf_loading_and_text_ms"] = round((time.perf_counter() - t0) * 1000, 2)
            print(f"  ✓ PDF loading & text extraction: {times['pdf_loading_and_text_ms']} ms")

        # 2. Duplicate detection indexing
        t0 = time.perf_counter()
        v_idx = VariantDuplicateIndex()
        for i in range(200):
            var = str(21 + (i % 3))
            v_idx.check_and_index(f"q_{i}", "9701", var, f"9701_s23_{var}", f"Q{i%10}", f"Sample chemistry reaction calculation step {i}")
        times["dedup_indexing_200_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        print(f"  ✓ Variant-scoped dedup indexing:  {times['dedup_indexing_200_ms']} ms")

        # 3. Manifest stat cache lookup
        t0 = time.perf_counter()
        with tempfile.TemporaryDirectory() as tmp:
            tmp_m = ProcessingManifest.load_or_create(tmp)
            dummy_file = Path(tmp) / "paper.pdf"
            dummy_file.write_bytes(b"%PDF dummy data " * 100)
            tmp_m.scan_input_file(dummy_file)
            for _ in range(500):
                tmp_m.scan_input_file(dummy_file)
        times["manifest_cache_500_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        print(f"  ✓ Manifest change detection:      {times['manifest_cache_500_ms']} ms")

        # 4. OutputManager directory indexing
        from core.output_manager import OutputManager
        with tempfile.TemporaryDirectory() as tmp:
            om = OutputManager(output_root=tmp)
            t0 = time.perf_counter()
            for _ in range(200):
                _ = om._find_existing_question_folders("A-Level", "Accounting_9706", "32_Summer_2024_Q1")
            times["output_manager_lookup_200_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        print(f"  ✓ OutputManager folder index:     {times['output_manager_lookup_200_ms']} ms")

        total_elapsed = round(time.perf_counter() - t_start, 3)
        times["total_benchmark_sec"] = total_elapsed

        # Save a self-describing receipt. Seconds prevent same-minute command
        # invocations from overwriting each other.
        self.benchmarks_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
        benchmark_file = self.benchmarks_dir / f"{stamp}.json"
        receipt = {
            "benchmark_type": "quick_control_plane",
            "generated_local": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "measurements": times,
        }
        benchmark_file.write_text(json.dumps(receipt, indent=2), encoding="utf-8")

        print("-" * 50)
        print(f"Total benchmark time: {total_elapsed} s")
        print(f"Results saved to:     {benchmark_file}")
        print("=" * 50)
        return times


# ==============================================================================
# 9. SCAN NEW PAPERS (Item 19)
# ==============================================================================

class NewFilesScanner:
    """Discovers newly added past paper PDFs in the input directory."""

    def __init__(self, input_dir: Path, output_dir: Path):
        self.input_dir = Path(input_dir).resolve()
        self.output_dir = Path(output_dir).resolve()

    def scan(self) -> List[Path]:
        from core.manifest import ProcessingManifest, FileStatus

        manifest = ProcessingManifest.load_or_create(self.output_dir)
        source_files = list(self.input_dir.rglob("*.pdf")) if self.input_dir.is_dir() else []
        new_files = []

        for f in source_files:
            # Fast stat comparison avoids re-hashing unchanged files; a hash is
            # computed only when the timestamp/size changed. This mutates the
            # in-memory preview record only and does not save the manifest.
            rec, requires_processing = manifest.scan_input_file(f)
            if requires_processing or rec.status in (FileStatus.NEW.value, FileStatus.CHANGED.value):
                new_files.append(f)

        return sorted(new_files)

    def print_scan_report(self) -> List[Path]:
        new_files = self.scan()
        print("\n" + "=" * 50)
        print("NEW OR CHANGED FILES DETECTED")
        print("=" * 50)
        if not new_files:
            print("No new files detected. Archive is up to date.")
            print("=" * 50)
            return []

        for f in new_files[:10]:
            print(f"  {f.name}")
        if len(new_files) > 10:
            print(f"  ... and {len(new_files) - 10} more files")

        print("-" * 50)
        print(f"{len(new_files)} new file(s) detected.")
        print("=" * 50)
        return new_files


# ==============================================================================
# 10. MAIN CONTROL MENU (Item 1)
# ==============================================================================

class ControlMenu:
    """Interactive production control center for ExamVoid."""

    def __init__(self):
        self.settings_mgr = SettingsManager()
        self._reload_paths_from_settings()

    def _reload_paths_from_settings(self) -> None:
        """Apply persisted paths immediately after Settings changes."""
        self.input_dir = (ROOT_DIR / self.settings_mgr.get("input_folder", "input")).resolve()
        self.board_input_dirs = {
            board: self.input_dir / board
            for board in ("CAIE", "AQA", "EDEXCEL", "IB", "SAT")
        }
        for folder in self.board_input_dirs.values():
            folder.mkdir(parents=True, exist_ok=True)
        self.caie_input_dir = self.board_input_dirs["CAIE"]
        self.aqa_input_dir = self.board_input_dirs["AQA"]
        self.edexcel_input_dir = self.board_input_dirs["EDEXCEL"]
        self.ib_input_dir = self.board_input_dirs["IB"]
        self.sat_input_dir = self.board_input_dirs["SAT"]
        self.output_dir = (ROOT_DIR / self.settings_mgr.get("output_folder", "output")).resolve()
        self.lock = ExamVoidLock(self.output_dir / ".examvoid_run_lock")

    def _get_archive_header_stats(self) -> Tuple[int, int, int]:
        """Return compact state counts without walking the archive tree."""
        from core.manifest import FileStatus, ProcessingManifest
        manifest = ProcessingManifest.load_or_create(self.output_dir)
        total = len(manifest.files)
        db_path = self.output_dir / "pipeline.sqlite"
        if db_path.is_file():
            try:
                import sqlite3
                conn = sqlite3.connect(str(db_path))
                rows = conn.execute("SELECT status, COUNT(*) FROM bundles GROUP BY status").fetchall()
                conn.close()
                counts = {str(status): int(n) for status, n in rows}
                return total, counts.get("complete", 0), counts.get("pending", 0) + counts.get("processing", 0)
            except Exception:
                pass
        completed = sum(1 for f in manifest.files.values() if f.status == FileStatus.COMPLETED.value)
        pending = sum(1 for f in manifest.files.values()
                      if f.status in (FileStatus.NEW.value, FileStatus.PROCESSING.value,
                                      FileStatus.CHANGED.value))
        return total, completed, pending

    def render_header(self) -> None:
        total, completed, pending = self._get_archive_header_stats()
        rule = "  " + "=" * 74
        print(rule)
        print("  EXAMVOID / ADVANCED CONTROL CENTER")
        print("  Archive tools, system checks, settings, and developer utilities")
        print(rule)
        print(f"  Archive   {total:,} files  |  {completed:,} complete  |  {pending:,} pending")
        print(f"  CAIE      {self.caie_input_dir}")
        print(f"  AQA       {self.aqa_input_dir}")
        print(f"  EDEXCEL   {self.edexcel_input_dir}")
        print(f"  IB        {self.ib_input_dir}")
        print(f"  SAT       {self.sat_input_dir}")
        print(f"  Output    {self.output_dir}")

    def render_menu(self) -> None:
        if sys.stdin.isatty() and sys.stdout.isatty():
            os.system("cls" if os.name == "nt" else "clear")
        self.render_header()
        print("""
  CAIE PIPELINE  ->  input/CAIE
  --------------------------------------------------------------------------
    [1]  Process new CAIE files
    [2]  Resume or process pending CAIE files
    [3]  Process selected CAIE files
    [4]  Reprocess all CAIE files

  OTHER BOARD PIPELINES  ->  universal adapters
  --------------------------------------------------------------------------
   [15]  AQA       input/AQA
   [16]  EDEXCEL   input/EDEXCEL
   [17]  IB        input/IB
   [18]  SAT       input/SAT

  ALL BOARDS
  --------------------------------------------------------------------------
   [19]  Run every populated board folder through its own pipeline

  ARCHIVE
  --------------------------------------------------------------------------
    [5]  Audit archive
    [6]  Preview changes
    [7]  Generate proof
    [8]  View statistics

  OUTPUT
  --------------------------------------------------------------------------
   [20]  Make a topical worksheet (PDF)
   [21]  Build a topical index page (HTML)

  SYSTEM
  --------------------------------------------------------------------------
    [9]  Verify installation
   [10]  Clean temporary files
   [11]  Settings

  DEVELOPER
  --------------------------------------------------------------------------
   [12]  Performance benchmark
   [13]  Run regression tests
   [14]  Developer tools

    [0]  Back to the main menu
  --------------------------------------------------------------------------
  Enter an option number and press Enter.
""")

    def run(self) -> None:
        # Batch execution owns SIGINT/SIGTERM while workers are active so it
        # can finish/cancel work safely, flush the manifest, and then release
        # the lock. The menu itself handles Ctrl+C around input below.
        while True:
            self.render_menu()
            try:
                choice = input("  Select option [0-21] > ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\nExiting ExamVoid.")
                break

            if choice == "0":
                print("Exiting ExamVoid.")
                break
            elif choice == "1":
                self.process_new_files()
            elif choice == "2":
                self.resume_pending()
            elif choice == "3":
                self.process_selected_files()
            elif choice == "4":
                self.reprocess_everything()
            elif choice == "5":
                self.audit_archive()
            elif choice == "6":
                self.preview_changes()
            elif choice == "7":
                self.generate_proof()
            elif choice == "8":
                self.show_statistics()
            elif choice == "9":
                self.verify_installation()
            elif choice == "10":
                self.cleanup_temp_files()
            elif choice == "11":
                self.settings_menu()
            elif choice == "12":
                self.run_benchmark()
            elif choice == "13":
                self.run_regression_tests()
            elif choice == "14":
                self.developer_tools_menu()
            elif choice == "15":
                self.other_boards_batch("AQA")
            elif choice == "16":
                self.other_boards_batch("EDEXCEL")
            elif choice == "17":
                self.other_boards_batch("IB")
            elif choice == "18":
                self.other_boards_batch("SAT")
            elif choice == "19":
                self.all_board_batch()
            elif choice == "20":
                self.make_worksheet()
            elif choice == "21":
                self.build_index_page()
            else:
                print("\nInvalid selection. Try again.")

            input("\nPress Enter to continue...")

    # --- Output Handlers (task 15: worksheet export + index page) ---

    def _tool(self, name: str):
        import importlib.util  # noqa: PLC0415
        spec = importlib.util.spec_from_file_location(name, ROOT_DIR / "tools" / f"{name}.py")
        mod = importlib.util.module_from_spec(spec)
        sys.path.insert(0, str(ROOT_DIR / "tools"))
        spec.loader.exec_module(mod)
        return mod

    def make_worksheet(self) -> None:
        """Topical worksheet PDF: questions, then mark schemes at the back."""
        print(f"\n--> Make Topical Worksheet  (output folder: {self.output_dir})")
        try:
            ws = self._tool("make_worksheet")
            if input("  List subjects and topics first? [y/N]: ").strip().lower() == "y":
                ws.list_contents(ws.index_rows(self.output_dir))
            subject = input("  Subject code or name (e.g. 9702): ").strip()
            topic = input("  Topic folder name (e.g. Waves): ").strip()
            if not topic:
                print("  A topic is required.")
                return
            years = input("  Years (e.g. 2019-2024, blank = all): ").strip()
            paper = input("  Paper number (blank = all): ").strip()
            answers = input("  Mark schemes: [e]nd / [a]fter each / [n]one (default end): ").strip().lower()
            answers = {"a": "after_each", "n": "none"}.get(answers[:1], "end")
            secondary = input("  Include cross-topic questions (runner-up topic)? [y/N]: ").strip().lower() == "y"
            ws.make(self.output_dir, subject=subject, topic=topic, years=years, paper=paper,
                    answers=answers, include_secondary=secondary)
        except Exception as exc:
            print(f"  Worksheet failed: {exc}")

    def build_index_page(self) -> None:
        """One self-contained HTML page: subject -> topic -> questions (+ duplicates)."""
        print(f"\n--> Build Topical Index Page  (output folder: {self.output_dir})")
        try:
            page = self._tool("build_index_page")
            page.main(["--output", str(self.output_dir)])
        except Exception as exc:
            print(f"  Index page failed: {exc}")

    # --- Processing Handlers ---

    def process_new_files(self) -> None:
        """Default incremental run: processes only new and changed papers."""
        print("\n--> Starting Process New Files...")
        self._execute_batch(resume=True, retry_failed=False, force_all=False)

    def resume_pending(self) -> None:
        """Resumes interrupted or pending runs and retryable failed files."""
        print("\n--> Resuming Pending & Interrupted Bundles...")
        self._execute_batch(resume=True, retry_failed=True, force_all=False)

    def process_selected_files(self) -> None:
        """Run a precise scope through the existing shared batch queue.

        Selection never creates a second pipeline: preflight still discovers
        valid QP/MS/ER/Insert relationships, while the queue matcher limits
        execution to the selected bundle(s).
        """
        print("\n" + "=" * 50)
        print("PROCESS SELECTED FILES")
        print("=" * 50)
        print("1. Filter by Subject or Syllabus Code")
        print("2. Filter by Paper Variant (e.g. 21, 22, 31, 32, 42)")
        print("3. Filter by Exam Year or Session (e.g. 2024, s24, w23)")
        print("4. Single File (must be beneath input/CAIE)")
        print("5. Folder (must be beneath input/CAIE)")
        print("0. Cancel")

        subchoice = input("\nSelect filter: ").strip()
        if subchoice == "1":
            value = input("Enter Subject name or four-digit syllabus code: ").strip()
            if value:
                if re.fullmatch(r"\d{4}", value):
                    self._execute_batch(syllabus_code_filter=value, resume=True)
                else:
                    self._execute_batch(subject_filter=value, resume=True)
        elif subchoice == "2":
            variant = input("Enter Variant (e.g. 21, 22): ").strip()
            if variant:
                self._execute_batch(variant_filter=variant, resume=True)
        elif subchoice == "3":
            value = input("Enter Exam Year or Session (e.g. 2024, s24, w23): ").strip()
            if value:
                session_pattern = r"(?i)(?:sp|spec(?:imen)?|mj|on|fm|[mswfj])[-_]?\d{2,4}"
                if re.fullmatch(session_pattern, value):
                    self._execute_batch(session=value, resume=True)
                else:
                    self._execute_batch(year_filter=value, resume=True)
        elif subchoice == "4":
            raw = input("Enter path to input PDF: ").strip()
            if raw:
                candidate = Path(raw).expanduser().resolve()
                if not candidate.is_file():
                    print(f"[ERROR] File not found: {candidate}")
                    return
                try:
                    candidate.relative_to(self.caie_input_dir.resolve())
                except ValueError:
                    print("[ERROR] Selected file is outside the CAIE input folder.")
                    print(f"Move it under {self.caie_input_dir} or update Settings first.")
                    return
                print(f"Processing only the linked bundle for: {candidate.name}")
                self._execute_batch(selected_paths={str(candidate)}, resume=True)
        elif subchoice == "5":
            raw = input("Enter input subfolder path: ").strip()
            if raw:
                folder = Path(raw).expanduser().resolve()
                if not folder.is_dir():
                    print(f"[ERROR] Folder not found: {folder}")
                    return
                try:
                    folder.relative_to(self.caie_input_dir.resolve())
                except ValueError:
                    print("[ERROR] Selected folder is outside the CAIE input folder.")
                    print(f"Choose a folder beneath {self.caie_input_dir} or update Settings first.")
                    return
                self._execute_batch(selected_folder=str(folder), resume=True)
    def reprocess_everything(self) -> None:
        """Destructive re-run requiring typed explicit confirmation."""
        print("\n" + "!" * 50)
        print("WARNING:")
        print("This will reprocess the entire archive from scratch.")
        print("This operation is expensive and discards cached completion status.")
        print("!" * 50)
        confirm = input("\nType:\nREPROCESS EVERYTHING\n\nto continue: ").strip()
        if confirm == "REPROCESS EVERYTHING":
            print("[CONFIRMED] Reprocessing entire archive...")
            self._execute_batch(force_all=True, resume=False)
        else:
            print("[ABORTED] Full reprocessing cancelled.")

    @staticmethod
    def _has_pdf_files(folder: Path) -> bool:
        return folder.is_dir() and any(
            path.is_file() and path.suffix.lower() == ".pdf"
            for path in folder.rglob("*")
        )

    def other_boards_batch(self, board: str) -> None:
        """Run one non-CAIE board folder through the universal adapter engine."""
        board = board.upper()
        if board not in {"AQA", "EDEXCEL", "IB", "SAT"}:
            print(f"[ERROR] Unsupported universal board: {board}")
            return
        input_dir = self.board_input_dirs[board]
        print("\n" + "=" * 64)
        print(f"{board} - UNIVERSAL ADAPTER PIPELINE")
        print("=" * 64)
        print("This runs only the selected board folder; other board folders are untouched.")
        print(f"Input:  {input_dir}")
        print(f"Output: {self.output_dir}")
        if not self._has_pdf_files(input_dir):
            print(f"\n[ERROR] No {board} PDFs found in {input_dir}")
            return
        enable_ocr = input("Enable optional OCR for scanned/image-only PDFs? [y/N]: ").strip().lower() == "y"
        self._execute_universal_batch(input_dir=str(input_dir), enable_ocr=enable_ocr)

    def all_board_batch(self) -> None:
        """Run each populated board folder through its own specialist pipeline."""
        folders = [(board, self.board_input_dirs[board])
                   for board in ("CAIE", "AQA", "EDEXCEL", "IB", "SAT")]
        populated = [(board, folder) for board, folder in folders
                     if self._has_pdf_files(folder)]
        print("\n" + "=" * 64)
        print("BOARD PIPELINES - RUN ALL POPULATED FOLDERS")
        print("=" * 64)
        for board, folder in folders:
            engine = "Cambridge" if board == "CAIE" else "Universal adapters"
            state = "ready" if any(board == item for item, _ in populated) else "empty"
            print(f"{board:<8} {folder}  [{engine}; {state}]")
        print(f"Output:  {self.output_dir}")
        if not populated:
            print("\n[ERROR] No PDFs found. Put each board's PDFs in its matching input subfolder.")
            return

        universal_populated = [(board, folder) for board, folder in populated if board != "CAIE"]
        enable_ocr = False
        if universal_populated:
            enable_ocr = input("\nEnable optional OCR for scanned other-board PDFs? [y/N]: ").strip().lower() == "y"

        results = []
        for board, folder in populated:
            if board == "CAIE":
                print("\n[CAIE] Starting Cambridge pipeline...")
                code = self._execute_batch(input_dir=str(folder))
            else:
                print(f"\n[{board}] Starting universal adapter pipeline...")
                code = self._execute_universal_batch(
                    input_dir=str(folder), enable_ocr=enable_ocr,
                )
            results.append((board, code))

        failures = [(board, code) for board, code in results if code not in (0, 2)]
        reviews = [board for board, code in results if code == 2]
        if failures:
            print("\n[ERROR] Failed board pipeline(s): " + ", ".join(board for board, _ in failures))
        elif reviews:
            print("\n[WARN] Review required in: " + ", ".join(reviews))
        else:
            print("\n[OK] All populated board folders finished.")

    def _execute_universal_batch(
        self, *, input_dir: str, enable_ocr: bool = False,
    ) -> int:
        """Run one non-CAIE board folder through the adapter engine."""
        inp = Path(input_dir)
        out = Path(self.output_dir)
        if not self._has_pdf_files(inp):
            print(f"\n[ERROR] No PDF files found in input directory: {inp}")
            return 1
        if not self.lock.acquire(interactive=True, command_desc="ExamVoid Universal Board Batch"):
            print("[ABORTED] Could not acquire single-instance lock.")
            return 1
        try:
            from tools.run_universal_batch import run_batch
            audit = run_batch(
                inp, out, include_sat=True, include_ib=True,
                limit_per_paper=0, enable_ocr=enable_ocr,
            )
            counts = audit.get("counts", {})
            print("\nUniversal batch complete.")
            print(f"  PDFs:          {counts.get('pdfs', 0)}")
            print(f"  Render passes: {counts.get('render_pass', 0)}")
            print(f"  Render fails:  {counts.get('render_fail', 0)}")
            print(f"  Indexed-only:  {counts.get('indexed_only', 0)}")
            print(f"  Review needed: {counts.get('review_required', 0)}")
            print(f"  Report:        {out / 'UNIVERSAL_BATCH_AUDIT.md'}")
            if counts.get("render_fail", 0):
                return 1
            if counts.get("review_required", 0):
                return 2
            return 0
        finally:
            self.lock.release()

    # --- Archive Tools Handlers ---

    def audit_archive(self) -> None:
        auditor = ArchiveAuditor(self.input_dir, self.output_dir)
        auditor.print_audit_report()

    def preview_changes(self) -> None:
        previewer = DryRunPreviewer(self.input_dir, self.output_dir)
        previewer.print_preview()

    def generate_proof(self) -> None:
        """Build visual proof from already-generated artifacts, never re-crop."""
        print("\n" + "=" * 50)
        print("GENERATE PROOF REPORT")
        print("=" * 50)
        print("1. Visual Proof: Full Archive")
        print("2. Visual Proof: Subject")
        print("3. Visual Proof: Paper Variant")
        print("4. Visual Proof: Exam Year or Session")
        print("5. Visual Proof: Latest Processed Items")
        print("6. Visual Proof: Accounting 2024")
        print("7. Control-Plane / Locked-Component Integrity Suite")
        print("0. Cancel")
        c = input("\nSelect: ").strip()
        visual_tool = str(ROOT_DIR / "tools" / "build_archive_proof.py")
        visual_cmd = [sys.executable, visual_tool, "--output-root", str(self.output_dir)]
        if c == "1":
            subprocess.run(visual_cmd, cwd=str(ROOT_DIR))
        elif c == "2":
            subject = input("Subject name or syllabus code: ").strip()
            if subject:
                subprocess.run(visual_cmd + ["--subject", subject], cwd=str(ROOT_DIR))
        elif c == "3":
            variant = input("Paper variant (e.g. 21, 22, 31, 32): ").strip()
            if variant:
                subprocess.run(visual_cmd + ["--variant", variant], cwd=str(ROOT_DIR))
        elif c == "4":
            value = input("Exam year or session (e.g. 2024, s24, summer): ").strip()
            if value:
                session_pattern = r"(?i)(?:sp|spec(?:imen)?|mj|on|fm|[mswfj])[-_]?\d{2,4}|summer|winter|spring|may-june|october-november"
                flag = "--session" if re.fullmatch(session_pattern, value) else "--year"
                subprocess.run(visual_cmd + [flag, value], cwd=str(ROOT_DIR))
        elif c == "5":
            subprocess.run(visual_cmd + ["--new-only"], cwd=str(ROOT_DIR))
        elif c == "6":
            subprocess.run(visual_cmd + ["--subject", "Accounting", "--year", "2024"], cwd=str(ROOT_DIR))
        elif c == "7":
            subprocess.run([sys.executable, str(ROOT_DIR / "tools" / "run_proof.py"), "--suite", "--check"], cwd=str(ROOT_DIR))

    def show_statistics(self) -> None:
        stats = ArchiveStatistics(self.input_dir, self.output_dir)
        stats.print_stats_report()

    def verify_installation(self) -> None:
        verifier = SystemVerifier(self.input_dir, self.output_dir)
        verifier.print_verification_report()

    def cleanup_temp_files(self) -> None:
        cleaner = SafeCleaner(self.output_dir)
        cleaner.clean(interactive=True)

    def run_benchmark(self) -> None:
        benchmarker = PerformanceBenchmarker(self.output_dir)
        benchmarker.run_benchmark()

    def run_regression_tests(self) -> None:
        print("\n--> Running Regression Tests...")
        subprocess.run(["pytest", "-q", str(ROOT_DIR / "tools" / "test_production_scenarios.py")], cwd=str(ROOT_DIR))

    def developer_tools_menu(self) -> None:
        while True:
            print("\n" + "=" * 50)
            print("DEVELOPER TOOLS")
            print("=" * 50)
            print("1. Pipeline Profiler")
            print("2. Test Cropping")
            print("3. Test Classification")
            print("4. Test Duplicate Detection")
            print("5. Test Manifest Lifecycle")
            print("6. Run Full Pytest Suite")
            print("0. Back to Main Menu")
            c = input("\nSelect: ").strip()
            if c == "0":
                break
            elif c == "1":
                subprocess.run([sys.executable, str(ROOT_DIR / "tools" / "profile_pipeline.py")], cwd=str(ROOT_DIR))
            elif c == "2":
                subprocess.run(["pytest", "-q", str(ROOT_DIR / "tests" / "test_igcse_low_ram_crop.py")], cwd=str(ROOT_DIR))
            elif c == "3":
                subprocess.run(["pytest", "-q", str(ROOT_DIR / "tests" / "test_classification_buffs.py")], cwd=str(ROOT_DIR))
            elif c == "4":
                subprocess.run(["pytest", "-q", str(ROOT_DIR / "tests" / "test_scalability_and_manifest.py")], cwd=str(ROOT_DIR))
            elif c == "5":
                subprocess.run([sys.executable, str(ROOT_DIR / "tools" / "test_production_scenarios.py")], cwd=str(ROOT_DIR))
            elif c == "6":
                subprocess.run(["pytest", "-q"], cwd=str(ROOT_DIR))
            input("\nPress Enter to continue...")

    def settings_menu(self) -> None:
        """Edit only settings that the current architecture implements."""
        while True:
            print("\n" + "=" * 50)
            print("EXAMVOID SETTINGS")
            print("=" * 50)
            print(f"1. Input Folder:     {self.settings_mgr.get('input_folder')}")
            print(f"2. Output Folder:    {self.settings_mgr.get('output_folder')}")
            print(f"3. Workers:          {self.settings_mgr.get('workers')}")
            print(f"4. Low RAM Mode:     {self.settings_mgr.get('low_ram')}")
            print(f"5. Performance:      {self.settings_mgr.get('performance')}")
            print("0. Back")

            c = input("\nChange setting [0-5]: ").strip()
            if c == "0":
                self._reload_paths_from_settings()
                break
            elif c in {"1", "2"}:
                label = "input" if c == "1" else "output"
                val = input(f"New {label} folder path: ").strip()
                if val:
                    self.settings_mgr.set(f"{label}_folder", val)
                    self._reload_paths_from_settings()
            elif c == "3":
                val = input("Workers (auto or a positive integer up to 64): ").strip().lower()
                if val == "auto" or (val.isdigit() and 1 <= int(val) <= 64):
                    self.settings_mgr.set("workers", val)
                else:
                    print("[ERROR] Workers must be 'auto' or an integer from 1 to 64.")
            elif c in {"4", "5"}:
                key = "low_ram" if c == "4" else "performance"
                val = input(f"{key} (auto, true, false): ").strip().lower()
                if val in {"auto", "true", "false"}:
                    self.settings_mgr.set(key, val)
                else:
                    print("[ERROR] Value must be auto, true, or false.")
    # --- Internal Batch Runner Execution ---

    def _execute_batch(
        self,
        input_dir: Optional[str] = None,
        output_dir: Optional[str] = None,
        resume: bool = True,
        retry_failed: bool = False,
        force_all: bool = False,
        subject_filter: Optional[str] = None,
        syllabus_code_filter: Optional[str] = None,
        session: Optional[str] = None,
        year_filter: Optional[str] = None,
        variant_filter: Optional[str] = None,
        selected_paths: Optional[Set[str]] = None,
        selected_folder: Optional[str] = None,
    ) -> int:
        from core.batch_runner import run_pipeline

        inp = Path(input_dir or self.caie_input_dir)
        out = Path(output_dir or self.output_dir)

        if not self._has_pdf_files(inp):
            print(f"\n[ERROR] No PDF files found in input directory: {inp}")
            print("Please place Cambridge past paper PDFs into input/CAIE.")
            return 1

        if not self.lock.acquire(interactive=True, command_desc="ExamVoid Batch Pipeline"):
            print("[ABORTED] Could not acquire single-instance lock.")
            return 1

        try:
            workers_cfg = self.settings_mgr.get("workers", "auto")
            workers_int = int(workers_cfg) if workers_cfg.isdigit() else None
            low_ram = self.settings_mgr.get("low_ram", "auto") != "false"

            result = run_pipeline(
                pdf_dir=str(inp),
                output_dir=str(out),
                workers=workers_int,
                resume=resume,
                retry_failed=retry_failed,
                force_all=force_all,
                low_ram=low_ram,
                full_auto=True,
                subject_filter=subject_filter,
                syllabus_code_filter=syllabus_code_filter,
                session=session,
                year_filter=year_filter,
                variant_filter=variant_filter,
                selected_paths=selected_paths,
                selected_folder=selected_folder,
            )
            return 130 if result.get("interrupted") else (0 if result.get("failed", 0) == 0 else 1)
        finally:
            self.lock.release()


def main():
    parser = argparse.ArgumentParser(description="ExamVoid Topical Generator Control System")
    parser.add_argument("--menu", action="store_true", help="Launch interactive control menu")
    parser.add_argument("--audit", action="store_true", help="Run archive audit")
    parser.add_argument("--stats", action="store_true", help="Display archive statistics")
    parser.add_argument("--sys-check", action="store_true", help="Run system installation check")
    parser.add_argument("--cleanup", action="store_true", help="Clean safe temporary files")
    parser.add_argument("--dry-run", action="store_true", help="Preview changes without modifying archive")
    parser.add_argument("--benchmark", action="store_true", help="Run performance benchmark")
    parser.add_argument("--scan-new", action="store_true", help="Scan input for newly added past papers")
    parser.add_argument("--universal-batch", action="store_true", help="Run universal AQA/Edexcel batch routing (IB gated until official PDFs are supplied)")
    parser.add_argument("--include-sat", action="store_true", help="Include SAT in universal batch routing")
    parser.add_argument("--include-ib", action="store_true", help="Include IB only after official IB PDFs are supplied for validation")
    parser.add_argument("--universal-limit-per-paper", type=int, default=0, help="Debug limiter for universal batch")
    parser.add_argument("--enable-ocr", action="store_true", help="Attempt optional Tesseract OCR for image-only universal-batch PDFs")
    parser.add_argument("--input", default=None, help="Override configured input folder")
    parser.add_argument("--output", default=None, help="Override configured output folder")
    args = parser.parse_args()

    sm = SettingsManager()
    inp = (Path(args.input) if args.input else ROOT_DIR / sm.get("input_folder", "input")).resolve()
    out = (Path(args.output) if args.output else ROOT_DIR / sm.get("output_folder", "output")).resolve()

    if args.audit:
        ArchiveAuditor(inp, out).print_audit_report()
    elif args.stats:
        ArchiveStatistics(inp, out).print_stats_report()
    elif args.sys_check:
        SystemVerifier(inp, out).print_verification_report()
    elif args.cleanup:
        SafeCleaner(out).clean(interactive=False)
    elif args.dry_run:
        DryRunPreviewer(inp, out).print_preview()
    elif args.benchmark:
        PerformanceBenchmarker(out).run_benchmark()
    elif args.scan_new:
        NewFilesScanner(inp, out).print_scan_report()
    elif args.universal_batch:
        from tools.run_universal_batch import run_batch
        audit = run_batch(inp, out, include_sat=args.include_sat, include_ib=args.include_ib, limit_per_paper=args.universal_limit_per_paper, enable_ocr=args.enable_ocr)
        print(json.dumps(audit.get("counts", {}), indent=2, sort_keys=True))
    else:
        # Default or --menu
        ControlMenu().run()


if __name__ == "__main__":
    main()
