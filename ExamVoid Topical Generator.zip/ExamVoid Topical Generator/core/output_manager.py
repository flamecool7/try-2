"""
Output Manager - Universal component supporting IGCSE + A-Level
Implements:
- JSON inside question folder (R1 previous fix)
- Topic folder is a byte-for-byte copy of metadata.json topic[0] (canonical)
- No empty folders, only create when actual question classified (R4)
- Winning major via point system, no duplication (R5,R6)
- Question folder naming Variant_Season_Year_QuestionNumber e.g., 41_Winter_2025_Q2 (R7)
- NEW: Paper type separation P2_AS_Structured, P4_A2_Structured, MCQ_P1 etc. (user request)
  Structure: Level/Subject/PaperType/Major/QuestionFolder/
  Example: A-Level/Chemistry_9701/P2_AS_Structured/Equilibria/41_Winter_2025_Q2/
"""

from pathlib import Path
from typing import List, Dict
from PIL import Image
from .qp_ms_matcher import MatchedQuestion
from .classifier import ClassificationResult
from .config_loader import SubjectConfig
import json
import logging
import re
import shutil

logger = logging.getLogger(__name__)

# Audit fix-group 7 C4: fields that must never persist in metadata.json.
FORBIDDEN_METADATA_FIELDS = {
    "topic_details", "primary", "secondary", "needs_review",
    "topic_scores", "primary_topic", "secondary_topics",
}

# Paper type folders - from gold-standard organize.py
_PAPER_FOLDER_BY_N = {
    2: "P2_AS_Structured",
    3: "P3_Practical_Skills",
    4: "P4_A2_Structured",
    5: "P5_Plan_Analysis",
    6: "P6_Alt_to_Practical",
}

_CS_9618_PAPER_FOLDERS = {
    1: "P1_Theory_Fundamentals",
    2: "P2_Problem_Solving_Programming",
    3: "P3_Advanced_Theory",
    4: "P4_Practical",
}

# User-requested maths paper-title folders.
_MATHS_PAPER_TITLE_FOLDERS = {
    "9709": {
        1: "Pure Maths 1",
        2: "Pure Maths 2",
        3: "Pure Maths 3",
        4: "Mechanics 1",
        5: "Statistics 1",
        6: "Statistics 2",
    },
    "9231": {
        1: "Further Pure Maths 1",
        2: "Further Pure Maths 2",
        3: "Further Mechanics 1",
        4: "Further Statistics 1",
    },
    "0580": {
        1: "Non-Calculator Core",
        2: "Calculator Core",
        3: "Non-Calculator Extended",
        4: "Calculator Extended",
    },
    "0606": {
        1: "Additional Maths Paper 1",
        2: "Additional Maths Paper 2",
    },
}

_MATHS_PAPER_TITLE_NAMES = {
    name for mapping in _MATHS_PAPER_TITLE_FOLDERS.values() for name in mapping.values()
}

# Non-topical deliverables intentionally stored beside generated questions.
# The ER-only organizer writes here and must survive topical cleanup/audits.
_AUXILIARY_OUTPUT_DIRS = {"Examiner_Reports", "board_path", "paper_failures", ".run_report", "worksheets"}  # board_path: the guarded


#: JSON files a *companion* pipeline writes into the same output root.
#:
#: A mixed-board run puts the Cambridge tree (`IGCSE/…`) and the universal router's tree (`final/…`)
#: in ONE folder, because that is the folder the user browses and the indexer indexes. Each pipeline
#: writes a few audit/state JSONs at the root; the other pipeline's R8 orphan scan then treated them
#: as question artifacts — and `check_no_orphan_json` (validation.py) *deletes* what it flags, so a
#: second run into the same folder **deleted the universal batch's manifests and the app's
#: `index_sources.json` sidecar** (found live 2026-09-28: the sidecar that lets the indexer find the
#: original papers was gone after one mixed re-run). These names are exemptions at the OUTPUT ROOT
#: only — never inside a question folder — and each one is printed when kept, matching the dotfile,
#: grade-threshold and `_insert` exemptions above.
PIPELINE_COMPANION_JSON = frozenset({
    "universal_batch_audit.json",     # tools/run_universal_batch.py
    "association_manifest.json",      # tools/run_universal_batch.py
    "source_manifest.json",           # tools/run_universal_batch.py
    "question_pack_manifest.json",    # adapters/pack_assembler.py
    "index_sources.json",             # server.py: staged name -> the user's real paper, for the indexer
})


def _is_pipeline_companion_json(path, output_root) -> bool:
    """True for a companion JSON sitting directly in the output root (never a nested question file)."""
    try:
        return (Path(path).parent.resolve() == Path(output_root).resolve()
                and Path(path).name in PIPELINE_COMPANION_JSON)
    except OSError:
        return False
# runner's adapter-driven non-CAIE subtree (2026-09-21); never CAIE-clean it.
# paper_failures: run_guarded's failure records - the cleanup must not eat
# the reports that explain why a paper failed (found 2026-09-21).

def _is_mcq_paper(paper_code: str, syllabus: str = None) -> bool:
    """Unified-MCQ round (STEP-7 audit): MCQ status comes ONLY from
    core.mcq_registry.is_mcq (RULE 1). Thin adapter for the legacy call
    signature; syllabus=None keeps the historical any-syllabus P1 behaviour."""
    code = str(paper_code or "").lstrip("0")
    if not code or code[0] != "1":
        return False
    if syllabus is None:
        return True
    from .mcq_registry import is_mcq
    return is_mcq(str(syllabus), code)

# IGCSE paper-format round (user decision taxonomy=rename): suffix per
# resolved format. Names feed folder tokens in core/validation.py.
_IGCSE_FORMAT_SUFFIX = {"MCQ": "MCQ", "STRUCTURED": "Structured",
                        "PRACTICAL": "Practical", "ATP": "ATP", "ESSAY": "Essay"}


def _igcse_folder_map():
    """Lazy accessor for paper_identifier.IGCSE_COMPONENT_MAP — single source
    of truth, so the detection side and the folder side can never disagree."""
    try:
        from .paper_identifier import IGCSE_COMPONENT_MAP
        return IGCSE_COMPONENT_MAP
    except Exception:
        return {}


def _paper_type_folder(paper_code: str, syllabus_code: str = None,
                       paper_format: str = None, **kwargs) -> str:
    """Return the universal physical paper folder name ``paper-N``.

    Format (MCQ/structured/practical) is handled by the strategy and file
    contract, not encoded into the directory name. This also makes new subject
    profiles consistent without requiring a new folder-name mapping.
    """
    code = str(paper_code or "").lstrip("0") or str(paper_code or "")
    try:
        n = int(code[0]) if code and code[0].isdigit() else 2
    except Exception:
        n = 2
    return f"paper-{n}"

REVIEW_FOLDER_NAME = "review_required"

# Specimen papers get their own folder INSIDE each topic:
#   <Level>/<Subject>/paper-N/<Topic>/specimen_paper/<QID>/
# Only the topic-level container changes; the topic folder is still the
# topic, so every topic-name check keeps working via topic_dir_of().
SPECIMEN_FOLDER_NAME = "specimen_paper"


def _is_specimen_season(season) -> bool:
    """True for specimen papers (season token 'Specimen' / letters 'sp')."""
    return str(season or "").strip().lower() in {"specimen", "sp"}


def topic_dir_of(question_folder) -> Path:
    """The topic directory a question folder belongs to, whether it sits
    directly under the topic, under ``specimen_paper/``, or under
    ``review_required/`` (optionally inside ``specimen_paper/``)."""
    p = Path(question_folder).parent
    if p.name == REVIEW_FOLDER_NAME:
        p = p.parent
    if p.name == SPECIMEN_FOLDER_NAME:
        p = p.parent
    return p


def is_topic_review_folder(question_folder: Path, topics=None) -> bool:
    """True when ``question_folder`` is a topic-scoped no-mark-scheme review home:

        .../<Topic>/review_required/<QID>/   with metadata topic[0] == <Topic>

    A QP that arrives without a mark scheme is still classified into its
    syllabus topic, then parked in the ``review_required`` folder INSIDE that
    topic (user requirement 2026-09-30). ``topics`` may be passed when the
    caller already parsed metadata.json; otherwise it is read from disk.
    """
    question_folder = Path(question_folder)
    parent = question_folder.parent
    if parent.name != REVIEW_FOLDER_NAME:
        return False
    if topics is None:
        try:
            topics = json.loads((question_folder / "metadata.json").read_text(encoding="utf-8")).get("topic")
        except Exception:
            return False
    if not isinstance(topics, list) or not topics or not isinstance(topics[0], str):
        return False
    topic0 = topics[0]
    if topic0.startswith(REVIEW_FOLDER_NAME):
        return False  # a sentinel, i.e. the flat subject-level review folder
    grand = parent.parent
    if grand.name == SPECIMEN_FOLDER_NAME:
        grand = grand.parent
    return grand.name == topic0


def _is_review_required_no_ms(question_folder: Path) -> bool:
    """RS-5 (Overseer review_required): True when this folder is a deliberate
    no-mark-scheme review home — the only place a missing MS webp is legal.

    Two shapes qualify:
      * flat   ``<Subject>/review_required/<QID>`` with the
        ``review_required_no_ms`` sentinel (topic could not be determined);
      * topic-scoped ``.../<Topic>/review_required/<QID>`` whose metadata
        topic[0] is that topic (see ``is_topic_review_folder``).
    """
    if question_folder.parent.name != "review_required":
        return False
    try:
        t = json.loads((question_folder / "metadata.json").read_text(encoding="utf-8")).get("topic")
    except Exception:
        return False
    if isinstance(t, list) and bool(t) and t[0] == "review_required_no_ms":
        return True
    return is_topic_review_folder(question_folder, t)


def _is_review_required_no_qp(question_folder: Path) -> bool:
    """2026-08-15: True when this folder is a review_required/missing_qp home —
    the only place a missing QP webp is legal (MS crop preserved instead)."""
    if question_folder.parent.name != "review_required":
        return False
    try:
        t = json.loads((question_folder / "metadata.json").read_text(encoding="utf-8")).get("topic")
    except Exception:
        return False
    return isinstance(t, list) and bool(t) and t[0] == "review_required_no_qp"


def _is_paper_type_dir_name(name: str) -> bool:
    if re.fullmatch(r"paper-\d+", str(name), re.IGNORECASE):
        return True
    if name == "loading..":
        return True
    if name in _MATHS_PAPER_TITLE_NAMES:
        return True
    if name.startswith("P") and ("_Structured" in name or "_MCQ" in name or "MCQ" in name
                                  or "Practical" in name or "_ATP" in name or "_Essay" in name
                                  or "Plan_Analysis" in name or "Alt_to_Practical" in name
                                  or name.startswith("P1_") or name.startswith("P2_")
                                  or name.startswith("P3_") or name.startswith("P4_")):
        return True
    return False


def _legacy_paper_folder_number(name: str) -> int | None:
    """Map the previous descriptive paper-folder names to paper-N."""
    if re.fullmatch(r"paper-\d+", str(name), re.IGNORECASE):
        return None
    for title, mapping in _MATHS_PAPER_TITLE_FOLDERS.items():
        for number, legacy in mapping.items():
            if name == legacy:
                return number
    m = re.match(r"^P(\d+)(?:_|$)", str(name), re.IGNORECASE)
    if m:
        return int(m.group(1))
    return None


def _merge_directory_contents(source: Path, target: Path) -> None:
    """Merge a legacy paper directory into paper-N without overwriting a
    refreshed destination file. Identical files are discarded; conflicts keep
    the destination and leave a loud log entry."""
    target.mkdir(parents=True, exist_ok=True)
    for child in list(source.iterdir()):
        dest = target / child.name
        if not dest.exists():
            shutil.move(str(child), str(dest))
        elif child.is_dir() and dest.is_dir():
            _merge_directory_contents(child, dest)
            if child.exists() and not any(child.iterdir()):
                child.rmdir()
        elif child.is_file() and dest.is_file():
            try:
                same = child.read_bytes() == dest.read_bytes()
            except OSError:
                same = False
            if same:
                child.unlink()
            else:
                logger.warning("Legacy folder conflict retained at %s; destination wins", dest)
    if source.exists() and not any(source.iterdir()):
        source.rmdir()


class OutputManager:
    def __init__(self, output_root: str | Path = "output", target_width=2280, quality=95):
        self.output_root = Path(output_root)
        self.target_width = target_width
        self.quality = quality
        self.output_root.mkdir(parents=True, exist_ok=True)
        self._subject_question_index: dict[tuple[str, str], dict[str, set[Path]]] = {}

    def _get_subject_index(self, level: str, subject: str) -> dict[str, set[Path]]:
        if not hasattr(self, "_subject_question_index"):
            self._subject_question_index = {}
        key = (level, subject)
        if key not in self._subject_question_index:
            self._build_subject_index(level, subject)
        return self._subject_question_index[key]

    def _build_subject_index(self, level: str, subject: str) -> None:
        key = (level, subject)
        index: dict[str, set[Path]] = {}
        subject_root = self.output_root / level / subject
        if subject_root.exists():
            import os
            for root, dirs, _ in os.walk(subject_root):
                p = Path(root)
                name = p.name
                if "_" in name and ("_Q" in name or name.startswith("Q") or name.split("_")[-1].startswith("Q")):
                    index.setdefault(name, set()).add(p)
                elif "review_required" in p.parts and "_" in name:
                    index.setdefault(name, set()).add(p)
        self._subject_question_index[key] = index

    def _find_existing_question_folders(self, level: str, subject: str, question_folder_name: str) -> list[Path]:
        index = self._get_subject_index(level, subject)
        folders = index.get(question_folder_name, set())
        valid = [f for f in folders if f.is_dir()]
        if len(valid) != len(folders):
            index[question_folder_name] = set(valid)
        return valid

    def _register_question_folder(self, level: str, subject: str, question_folder_name: str, folder_path: Path) -> None:
        index = self._get_subject_index(level, subject)
        index.setdefault(question_folder_name, set()).add(folder_path)

    def _unregister_question_folder(self, level: str, subject: str, question_folder_name: str, folder_path: Path) -> None:
        index = self._get_subject_index(level, subject)
        if question_folder_name in index:
            index[question_folder_name].discard(folder_path)

    def _is_auxiliary_path(self, path: Path) -> bool:
        try:
            rel = Path(path).resolve().relative_to(self.output_root.resolve())
        except (ValueError, OSError):
            return False
        return bool(rel.parts) and rel.parts[0] in _AUXILIARY_OUTPUT_DIRS

    def get_major_topic_path(self, level: str, subject: str, paper_type_folder: str, topic: str) -> Path:
        """
        Get path for major topic folder including level and paper type
        NEW STRUCTURE with paper type separation: Level/Subject/PaperType/Major
        Example: A-Level/Chemistry_9701/P2_AS_Structured/Equilibria/
        """
        # CRITICAL: Folder name must be direct copy of winning_topic, exact string
        # Preserves comma, semicolon per R10
        if paper_type_folder:
            return self.output_root / level / subject / paper_type_folder / topic
        else:
            return self.output_root / level / subject / topic

    def get_question_folder_path(self, level: str, subject: str, paper_type_folder: str, major_topic: str, question_folder_name: str) -> Path:
        major_path = self.get_major_topic_path(level, subject, paper_type_folder, major_topic)
        return major_path / question_folder_name

    def save_question_pair(self, matched: MatchedQuestion, classification: ClassificationResult, config: SubjectConfig) -> Dict[str, Path]:
        """
        Save QP/MS webp + metadata.json inside question folder
        NEW STRUCTURE: Level/Subject/PaperType/Major/QuestionFolder/
        Example: A-Level/Chemistry_9701/P2_AS_Structured/Equilibria/41_Winter_2025_Q2/
                 ├── 41_Winter_2025_Q2.webp
                 ├── 41_Winter_2025_Q2_MS.webp
                 └── metadata.json

        (No examiner_report.txt or other free-form text is a delivery artifact;
        only an MCQ `_MS.txt` answer-grid sidecar is permitted.)

        CRITICAL: Folder name = winning_topic exact, no transformation
        Question folder = Variant_Season_Year_QuestionNumber exact
        """
        winning_major = classification.winning_major
        subject = config.subject
        level = config.level

        # Determine paper type folder: P2_AS_Structured, P4_A2_Structured, MCQ_P1, etc.
        # Use matched.variant (e.g., 22 -> P2, 42 -> P4, 12 -> MCQ_P1)
        # Also use syllabus code for CS 9618 special handling
        paper_type_folder = _paper_type_folder(
            matched.variant,
            syllabus_code=config.syllabus_code,
            paper_format=getattr(matched, "paper_format", ""),
        )

        # Validate winning_major is actual syllabus major topic
        if winning_major not in config.major_topics:
            broad_categories = ["Organic_Chemistry", "Inorganic_Chemistry", "Physical_Chemistry"]
            if winning_major in broad_categories:
                print(f"[OutputManager] WARNING: Winning topic {winning_major} is broad category, not actual syllabus topic for {config.subject}")

        # RS-17 (spec: no `loading` folders, no pre-created topic folders, no
        # topic=[] math metadata): Mathematics 9709/9231/0580 classify at
        # question level into official topic names; the recorded topic[0] drives
        # the physical folder like every other subject. Zero-evidence questions
        # never reach here — S5 routes them to review_required upstream.
        json_data = self._generate_json_data(matched, classification, config)
        # The actual topic string recorded in JSON is the only source for
        # the physical topic-folder name.
        assigned_topic = json_data["topic"][0]
        if not isinstance(assigned_topic, str) or not assigned_topic:
            raise ValueError("metadata topic[0] must be a non-empty topic string")
        major_path = self.get_major_topic_path(level, subject, paper_type_folder, assigned_topic)
        major_path.mkdir(parents=True, exist_ok=True)

        # Question folder naming: Variant_Season_Year_QuestionNumber
        variant = matched.variant
        season = matched.season
        year = matched.year
        qnum = matched.question_number

        question_folder_name = f"{variant}_{season}_{year}_{qnum}"
        container = major_path / SPECIMEN_FOLDER_NAME if _is_specimen_season(season) else major_path
        question_folder = container / question_folder_name

        if True:  # RS-17: staging branch deleted; invariant applies to every subject.
            # Audit fix-group 6 C3: single-folder invariant enforcement.
            # If a same-named question folder already exists under a DIFFERENT
            # topic folder, writing here would duplicate the question into a
            # second physical topic (forbidden by invariant R?). Log loudly and
            # skip the write; same-folder rewrites (idempotent re-runs) are fine.
            dupes = [
                d for d in self._find_existing_question_folders(level, subject, question_folder_name)
                if d != question_folder
            ]
            if dupes:
                unc_dupes = [d for d in dupes if self.UNC_FOLDER in d.parts]
                real_dupes = [d for d in dupes if self.UNC_FOLDER not in d.parts]
                if not real_dupes:
                    # RS-5 promotion: the question now has a REAL classification
                    # (e.g. MS arrived and the paper re-ran). Retire the stale
                    # review_required twin so the single-folder invariant holds.
                    for d in unc_dupes:
                        print(f"[OutputManager] promotion: retiring review_required twin {d} "
                              f"(real classification arrived for {question_folder_name})")
                        shutil.rmtree(d)
                        self._unregister_question_folder(level, subject, question_folder_name, d)
                        # <Topic>/review_required/ left empty -> remove it too.
                        try:
                            if d.parent.name == self.UNC_FOLDER and not any(d.parent.iterdir()):
                                d.parent.rmdir()
                        except OSError:
                            pass
                else:
                    if getattr(self, "replace_existing", False):
                        # The bundle was explicitly requeued because its input
                        # snapshot changed.  Remove only the stale placement
                        # for this same question; the new JSON topic[0] will
                        # become the sole canonical folder below.
                        for d in real_dupes:
                            print(f"[OutputManager] reprocess: replacing stale placement {d}")
                            shutil.rmtree(d)
                            self._unregister_question_folder(level, subject, question_folder_name, d)
                        for d in unc_dupes:
                            shutil.rmtree(d)
                            self._unregister_question_folder(level, subject, question_folder_name, d)
                    else:
                        logger.error(
                            "INVARIANT VIOLATION: %s already exists at %s — skipping write (no duplicate)",
                            question_folder_name, real_dupes[0],
                        )
                        return {"skipped_duplicate": True, "existing": real_dupes[0],
                                "question_folder": real_dupes[0]}

        question_folder.mkdir(parents=True, exist_ok=True)
        self._register_question_folder(level, subject, question_folder_name, question_folder)

        # File names inside question folder: same base as folder name
        qp_path = question_folder / f"{question_folder_name}.webp"
        ms_path = question_folder / f"{question_folder_name}_MS.webp"
        json_path = question_folder / "metadata.json"

        # IGCSE paper-format round (user decision mcq_ms=letters): an MCQ
        # question has NO mark-scheme image — Cambridge publishes a bare
        # answer grid. The extracted grid letter rides in metadata
        # (ms_answer); an MS webp is never fabricated from it.
        _mcq_answer = getattr(matched, "ms_answer", None)
        # A missing `full_ms_code` distinguishes true QP-only mode from an
        # MCQ whose supplied MS simply lacked a letter.  The latter keeps the
        # literal empty-sidecar contract; the former uses the explicit
        # MS_UNAVAILABLE placeholder so full-auto QP-only output passes the
        # normal staging validator.
        _qp_only_missing = (
            getattr(matched, "ms", None) is None
            and not getattr(matched, "full_ms_code", None)
        )
        # Unified-MCQ round (approved Q2=additive, Q3=literal-writer): MCQ
        # status from the registry (RULE 1). User requirement (2026-08-14):
        # metadata.json carries ONLY the canonical 11 fields — the answer
        # letter rides in the `*_MS.txt` sidecar (written below), never in
        # metadata. _MS.txt is ALWAYS written for MCQ components — letter+\n,
        # or EMPTY+loud when the letter is unavailable (Rule 3: never skip).
        from .mcq_registry import is_mcq as _reg_is_mcq
        _mcq_paper = (
            str(getattr(matched, "paper_format", "")).upper() == "MCQ"
            or _reg_is_mcq(getattr(config, "syllabus_code", ""),
                           getattr(matched, "variant", ""),
                           getattr(matched, "year", None))
        )

        _ms_missing = getattr(matched, "ms", None) is None
        if _ms_missing and not _mcq_paper:
            # The canonical delivery contract permits `_MS.txt` only for an
            # MCQ answer-grid sidecar. Refuse to publish a structured QP-only
            # folder; callers must use save_review_required_question instead.
            self._unregister_question_folder(level, subject, question_folder_name, question_folder)
            try:
                if question_folder.exists() and not any(question_folder.iterdir()):
                    question_folder.rmdir()
            except OSError:
                pass
            raise ValueError(
                "Structured question has no usable mark-scheme crop; "
                "route it through review_required_no_ms instead of writing an _MS.txt placeholder"
            )

        self._save_image(matched.qp.assembled_image, qp_path)
        if not _mcq_paper and not _ms_missing:
            self._save_image(matched.ms.assembled_image, ms_path)

        # Save the same canonical metadata that supplied the folder name.
        # Only the canonical 11 fields persist (user requirement 2026-08-14).
        from .json_generator import canonical_metadata
        json_data = canonical_metadata(json_data)
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, indent=4)

        _ms_txt = None
        if _mcq_paper and not _qp_only_missing:
            from .mcq_output import write_mcq_ms, validate_mcq_ms_file
            _ms_txt = write_mcq_ms(question_folder, question_folder_name,
                                   _mcq_answer)
            if not validate_mcq_ms_file(_ms_txt):
                print(f"[OutputManager] ! MCQ _MS.txt empty/invalid for "
                      f"{question_folder_name} (letter {_mcq_answer!r}) — "
                      f"visible to audit (Rule 3/4)")
        elif _mcq_paper and _qp_only_missing:
            from .mcq_output import PLACEHOLDER_MS_CONTENT
            _ms_txt = question_folder / f"{question_folder_name}_MS.txt"
            _ms_txt.write_text(PLACEHOLDER_MS_CONTENT + "\n", encoding="utf-8")
        # REASON.txt is no longer a question-folder artifact. Remove one left
        # by an older run regardless of whether this snapshot is QP-only.
        (question_folder / "REASON.txt").unlink(missing_ok=True)

        assert qp_path.exists(), f"QP not saved: {qp_path}"
        if not _mcq_paper and not _ms_missing:
            assert ms_path.exists(), f"MS not saved: {ms_path}"
        assert json_path.exists(), f"JSON not saved: {json_path}"
        # RS-17: staging branch deleted — folder/topic[0] invariant holds for
        # every subject, Mathematics included.
        assert major_path.name == assigned_topic, (
            f"Topic folder {major_path.name!r} != metadata topic[0] {assigned_topic!r}"
        )

        return {
            "qp": qp_path,
            "ms": None if (_mcq_paper or _ms_missing) else ms_path,
            "ms_txt": _ms_txt,
            "json": json_path,
            "major": major_path,
            "paper_type": paper_type_folder,
            "question_folder": question_folder,
            "question_folder_name": question_folder_name,
            "winning_major": winning_major,
            "assigned_topic": assigned_topic,
            "level": level
        }

    UNC_FOLDER = "review_required"  # RS-5 (Overseer review_required directive)
    UNC_SENTINELS = {"classification_failed": "review_required",
                     "no_markscheme": "review_required_no_ms",
                     "missing_qp": "review_required_no_qp",
                     "review_required": "review_required"}
    UNC_REASON_MESSAGES = {
        "review_required": (
            "This question needs human review before it can be routed to an "
            "official syllabus topic.\n\n"
            "Possible causes:\n"
            "- No deterministic text / formula / diagram evidence for any "
            "official topic (spec: ambiguous input must surface REVIEW_REQUIRED "
            "rather than guess)\n"
            "- Extraction-poor scan; consider a higher-quality source PDF\n\n"
            "Action: Review manually and move to the correct topic folder."
        ),
        "classification_failed": (
            "This question could not be confidently assigned "
            "to any topic in the taxonomy.\n\n"
            "Possible causes:\n"
            "- Question text is too short or diagram-only\n"
            "- Topic keywords not in taxonomy JSON\n"
            "- All topic scores below minimum threshold\n\n"
            "Action: Review manually and move to correct topic."
        ),
        "no_markscheme": (
            "No mark scheme was found for this question.\n\n"
            "Possible causes:\n"
            "- MS PDF was not provided for this paper\n"
            "- Question number not found in MS PDF\n"
            "- MS PDF filename does not match QP filename\n\n"
            "Action: Locate the correct MS PDF and reprocess."
        ),
        "missing_qp": (
            "No question paper (QP) was found for this bundle, so the question "
            "could not be cropped or classified.\n\n"
            "The mark-scheme crop is preserved here for reference.\n\n"
            "Action: Locate the correct QP PDF and reprocess the bundle."
        ),
    }

    def save_review_required_question(self, matched, reason: str, config) -> Dict[str, Path]:
        """RS-5 (Overseer review_required directive, user-approved decisions):
        route a question to output/{Level}/{Subject}/review_required/{QID}/.

        Decisions applied: desperate_only trigger (callers check fallback_tier),
        adopt_keep_crop (QP crop ALWAYS saved — never discard a crop),
        single_level structure, quality_scorer reporting, and run-level reason
        logging. Review folders keep their canonical assets and metadata; the
        reason is written to the run log/report, not into each question folder.

        Rule 4 honored: the review_required folder is only created when a question
        actually lands in it. Returns the folder dict (or skipped_duplicate).
        """
        assert reason in self.UNC_SENTINELS, f"unknown review_required reason: {reason}"
        level, subject = config.level, config.subject
        variant, season, year, qnum = matched.variant, matched.season, matched.year, matched.question_number
        question_folder_name = f"{variant}_{season}_{year}_{qnum}"
        major_path = self.output_root / level / subject / self.UNC_FOLDER
        question_folder = major_path / question_folder_name

        # A REAL classified twin wins outright: never shadow it with an
        # review_required duplicate (inverse of the promotion rule in
        # save_question_pair, which deletes the review_required twin when a real
        # classification later arrives).
        dupes = [d for d in self._find_existing_question_folders(level, subject, question_folder_name)
                 if d != question_folder
                 and self.UNC_FOLDER not in d.parts]
        if dupes:
            logger.error(
                "REVIEW_REQUIRED SKIP: %s already has a real classified folder at %s - not shadowing",
                question_folder_name, dupes[0],
            )
            return {"skipped_duplicate": True, "existing": dupes[0],
                    "question_folder": dupes[0]}
        # A topic-scoped review twin (<Topic>/review_required/<QID>) from an
        # earlier run is superseded by this flat review home.
        for d in self._find_existing_question_folders(level, subject, question_folder_name):
            if d != question_folder and self.UNC_FOLDER in d.parts:
                shutil.rmtree(d, ignore_errors=True)
                self._unregister_question_folder(level, subject, question_folder_name, d)
                try:
                    if d.parent.name == self.UNC_FOLDER and not any(d.parent.iterdir()):
                        d.parent.rmdir()
                except OSError:
                    pass

        question_folder.mkdir(parents=True, exist_ok=True)
        self._register_question_folder(level, subject, question_folder_name, question_folder)
        qp_path = question_folder / f"{question_folder_name}.webp"
        self._save_image(matched.qp.assembled_image, qp_path)
        ms_path = None
        if getattr(matched, "ms", None) is not None:
            ms_path = question_folder / f"{question_folder_name}_MS.webp"
            self._save_image(matched.ms.assembled_image, ms_path)

        import uuid as _uuid
        json_data = {
            "id": str(_uuid.uuid4()),
            "level": level,
            "subject": subject,
            "board": getattr(config, "board", "CIE"),
            "topic": [self.UNC_SENTINELS[reason]],
            "paper": matched.full_qp_code,
            "question_number": matched.question_number,
            "variant": variant,
            "season": season,
            "year": year,
        }
        # IGCSE paper-format round (mcq_ms=letters): if this question came
        # from an MCQ paper, its extracted grid letter IS the mark scheme.
        # User requirement (2026-08-14): metadata stays canonical — the
        # letter rides in the `*_MS.txt` sidecar written below.
        _mcq_answer_unc = getattr(matched, "ms_answer", None)
        from .mcq_registry import is_mcq as _reg_is_mcq_u
        _mcq_paper_unc = (
            str(getattr(matched, "paper_format", "")).upper() == "MCQ"
            or _reg_is_mcq_u(getattr(config, "syllabus_code", ""),
                             getattr(matched, "variant", ""),
                             getattr(matched, "year", None))
        )
        json_path = question_folder / "metadata.json"
        # Only the canonical 11 fields persist (user requirement 2026-08-14).
        from .json_generator import canonical_metadata
        json_data = canonical_metadata(json_data)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(json_data, f, indent=4)
        if _mcq_paper_unc:
            # Unified-MCQ (Q3=literal): ALWAYS write _MS.txt (letter or
            # empty+loud); validated immediately (Rule 4).
            from .mcq_output import write_mcq_ms, validate_mcq_ms_file
            _ms_txt_unc = write_mcq_ms(question_folder, question_folder_name,
                                       _mcq_answer_unc)
            if not validate_mcq_ms_file(_ms_txt_unc):
                print(f"[OutputManager] ! MCQ UNC _MS.txt empty/invalid for "
                      f"{question_folder_name}")

        # The reason is deliberately reported by the guarded stage/run report,
        # not stored as REASON.txt inside the question folder.
        print(f"[OutputManager] REVIEW_REQUIRED reason={reason}: "
              f"{matched.full_qp_code} {matched.question_number}")

        assert qp_path.exists(), f"QP not saved: {qp_path}"
        assert json_path.exists(), f"JSON not saved: {json_path}"
        print(f"[OutputManager] REVIEW_REQUIRED ({reason}): {matched.full_qp_code} {matched.question_number} -> {question_folder.relative_to(self.output_root)}")
        return {
            "qp": qp_path, "ms": ms_path, "json": json_path,
            "major": major_path, "paper_type": self.UNC_FOLDER,
            "question_folder": question_folder,
            "question_folder_name": question_folder_name,
            "winning_major": self.UNC_FOLDER,
            "assigned_topic": self.UNC_SENTINELS[reason],
            "reason": reason, "level": level,
        }

    def promote_topic_review_mcq(self, level, subject, question_folder_name, letter):
        """MCQ twin of the MS-image promotion: the found answer grid's letter
        is written to ``<QID>_MS.txt`` (the normal MCQ layout)."""
        flat = self.output_root / level / subject / self.UNC_FOLDER / question_folder_name
        return self._promote_topic_review_with_ms(level, subject, question_folder_name,
                                                  None, flat, mcq_letter=letter)

    def _promote_topic_review_with_ms(self, level, subject, question_folder_name,
                                      ms_crop, flat_folder, mcq_letter=None):
        """Pair a newly found MS with the QP already parked in
        ``<Topic>/review_required/<QID>/``; returns the save dict or None."""
        img = getattr(ms_crop, "assembled_image", None) if ms_crop is not None else None
        if img is None and not mcq_letter:
            return None
        candidates = []
        for d in self._find_existing_question_folders(level, subject, question_folder_name):
            if d.parent.name != self.UNC_FOLDER or d == flat_folder:
                continue
            if not (d / f"{question_folder_name}.webp").exists():
                continue
            if not is_topic_review_folder(d):
                continue
            candidates.append(d)
        if not candidates:
            # also catch folders an index/registry has not seen yet
            subj_root = self.output_root / level / subject
            if subj_root.is_dir():
                for pat in (f"paper-*/*/{self.UNC_FOLDER}/{question_folder_name}",
                            f"paper-*/*/{SPECIMEN_FOLDER_NAME}/{self.UNC_FOLDER}/{question_folder_name}"):
                    for d in subj_root.glob(pat):
                        if (d / f"{question_folder_name}.webp").exists() and d != flat_folder:
                            candidates.append(d)
        if not candidates:
            return None
        src = sorted(candidates, key=lambda p: str(p))[0]
        topic_dir = src.parent.parent
        dest = topic_dir / question_folder_name
        if dest.exists():
            return None  # a real pair already exists; caller's twin check handles it
        shutil.move(str(src), str(dest))
        self._unregister_question_folder(level, subject, question_folder_name, src)
        self._register_question_folder(level, subject, question_folder_name, dest)
        try:
            if not any(src.parent.iterdir()):
                src.parent.rmdir()
        except OSError:
            pass
        txt = dest / f"{question_folder_name}_MS.txt"
        if mcq_letter:
            from .mcq_output import write_mcq_ms
            ms_path = write_mcq_ms(dest, question_folder_name, mcq_letter)
        else:
            # An MCQ placeholder (empty _MS.txt) is superseded by the real MS.
            try:
                if txt.exists() and not txt.read_text(encoding="utf-8", errors="ignore").strip():
                    txt.unlink()
            except OSError:
                pass
            ms_path = dest / f"{question_folder_name}_MS.webp"
            self._save_image(img, ms_path)
        (dest / "REASON.txt").unlink(missing_ok=True)
        # A flat missing_qp copy of this MS from an earlier MS-only run is
        # now redundant.
        if flat_folder.exists():
            shutil.rmtree(flat_folder, ignore_errors=True)
            self._unregister_question_folder(level, subject, question_folder_name, flat_folder)
            try:
                if not any(flat_folder.parent.iterdir()):
                    flat_folder.parent.rmdir()
            except OSError:
                pass
        topic_dir = topic_dir_of(dest)
        topic = topic_dir.name
        print(f"[OutputManager] MS MATCHED: {question_folder_name} -> paired with its QP, "
              f"filed under {dest.relative_to(self.output_root)}")
        return {
            "ms": ms_path, "json": dest / "metadata.json",
            "major": topic_dir, "paper_type": topic_dir.parent.name,
            "question_folder": dest, "question_folder_name": question_folder_name,
            "winning_major": topic, "assigned_topic": topic,
            "reason": "ms_matched_to_review_qp", "level": level,
            "promoted_from_review": True,
        }

    def save_missing_qp_question(self, ms_crop, variant, season, year,
                                 full_ms_code, config) -> Dict[str, Path]:
        """2026-08-15 (user requirement): a bundle whose QP is missing (after
        fetch attempts) still has its MS cropped and preserved in
        review_required/missing_qp so a human can locate the QP and reprocess.
        Folders contain `{QID}_MS.webp` + metadata.json (sentinel topic); the
        missing-QP reason is reported in the run log/report."""
        reason = "missing_qp"
        level, subject = config.level, config.subject
        question_number = getattr(ms_crop, "question_number", "Q?")
        question_folder_name = f"{variant}_{season}_{year}_{question_number}"
        major_path = self.output_root / level / subject / self.UNC_FOLDER
        question_folder = major_path / question_folder_name

        # A real classified twin wins outright; never shadow it.
        dupes = [d for d in self._find_existing_question_folders(level, subject, question_folder_name)
                 if d != question_folder
                 and self.UNC_FOLDER not in d.parts]
        if dupes:
            logger.error(
                "REVIEW_REQUIRED SKIP (missing_qp): %s already has a real "
                "classified folder at %s - not shadowing",
                question_folder_name, dupes[0],
            )
            return {"skipped_duplicate": True, "existing": dupes[0],
                    "question_folder": dupes[0]}

        # 2026-09-30 (user requirement): "when I find the mark scheme, match it
        # to its QP and categorize it". If this question was filed earlier
        # WITHOUT a mark scheme it sits in <paper-N>/<Topic>/review_required/
        # <QID>/ with its QP crop. Pair the MS with it right here: move the
        # folder up into <Topic>/<QID>/ and add <QID>_MS.webp - exactly the
        # layout of a normally paired question.
        promoted = self._promote_topic_review_with_ms(
            level, subject, question_folder_name, ms_crop, question_folder)
        if promoted is not None:
            return promoted

        question_folder.mkdir(parents=True, exist_ok=True)
        self._register_question_folder(level, subject, question_folder_name, question_folder)
        ms_path = question_folder / f"{question_folder_name}_MS.webp"
        img = getattr(ms_crop, "assembled_image", None)
        if img is not None:
            self._save_image(img, ms_path)

        import uuid as _uuid
        json_data = {
            "id": str(_uuid.uuid4()),
            "level": level,
            "subject": subject,
            "board": getattr(config, "board", "CIE"),
            "topic": [self.UNC_SENTINELS[reason]],
            "paper": full_ms_code,
            "question_number": question_number,
            "variant": variant,
            "season": season,
            "year": year,
        }
        from .json_generator import canonical_metadata
        json_path = question_folder / "metadata.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(canonical_metadata(json_data), f, indent=4)

        # The missing-QP reason is reported by the run log/report. No
        # The missing-QP reason is written to the launcher/report, not into
        # the preserved MS-only question folder.
        print(f"[OutputManager] REVIEW_REQUIRED reason={reason}: "
              f"{full_ms_code} {question_number}")

        assert json_path.exists(), f"JSON not saved: {json_path}"
        print(f"[OutputManager] REVIEW_REQUIRED ({reason}): {full_ms_code} "
              f"{question_number} -> {question_folder.relative_to(self.output_root)}")
        return {
            "ms": ms_path, "json": json_path,
            "major": major_path, "paper_type": self.UNC_FOLDER,
            "question_folder": question_folder,
            "question_folder_name": question_folder_name,
            "winning_major": self.UNC_FOLDER,
            "assigned_topic": self.UNC_SENTINELS[reason],
            "reason": reason, "level": level,
        }

    # Compatibility alias for old callers/tests. The implementation writes to
    # review_required, never to an Uncategorized directory.
    save_uncategorized_question = save_review_required_question

    def save_topic_review_question(self, matched, classification, config) -> Dict[str, Path]:
        """No-mark-scheme question, classified into its topic (2026-09-30).

        Instead of the flat ``<Subject>/review_required/<QID>`` home, the QP is
        classified like any other question and parked in the review folder
        INSIDE its topic, mirroring the normal topic path:

            <Level>/<Subject>/paper-N/<Topic>/review_required/<QID>/
                ├── <QID>.webp
                └── metadata.json      (topic = [<Topic>, ...detailed])

        metadata.json keeps the canonical fields; ``topic`` records the
        classification exactly like a normal question (topic[0] == <Topic>).
        The review state is carried by the path. When the MS later arrives and
        the paper is re-run, ``save_question_pair`` retires this folder (it
        sits under ``review_required``) and writes the real pair.
        """
        level, subject = config.level, config.subject
        paper_type_folder = _paper_type_folder(
            matched.variant,
            syllabus_code=config.syllabus_code,
            paper_format=getattr(matched, "paper_format", ""),
        )
        json_data = self._generate_json_data(matched, classification, config)
        assigned_topic = json_data["topic"][0]
        if not isinstance(assigned_topic, str) or not assigned_topic:
            raise ValueError("metadata topic[0] must be a non-empty topic string")
        topic_path = self.get_major_topic_path(level, subject, paper_type_folder, assigned_topic)
        _spec_container = topic_path / SPECIMEN_FOLDER_NAME if _is_specimen_season(matched.season) else topic_path
        major_path = _spec_container / self.UNC_FOLDER
        question_folder_name = f"{matched.variant}_{matched.season}_{matched.year}_{matched.question_number}"
        question_folder = major_path / question_folder_name

        dupes = [d for d in self._find_existing_question_folders(level, subject, question_folder_name)
                 if d != question_folder]
        real_dupes = [d for d in dupes if self.UNC_FOLDER not in d.parts]
        if real_dupes and not getattr(self, "replace_existing", False):
            # A REAL classified pair wins outright; never shadow it.
            logger.error(
                "REVIEW_REQUIRED SKIP: %s already has a real classified folder at %s - not shadowing",
                question_folder_name, real_dupes[0],
            )
            return {"skipped_duplicate": True, "existing": real_dupes[0],
                    "question_folder": real_dupes[0]}
        # Stale placements of this same question are retired so the
        # single-folder invariant holds: the old flat review home, a
        # review folder under a different topic, or (on an explicit
        # reprocess) a previous real placement.
        for d in dupes:
            print(f"[OutputManager] retiring stale placement {d} -> {question_folder}")
            shutil.rmtree(d, ignore_errors=True)
            self._unregister_question_folder(level, subject, question_folder_name, d)
            try:
                if d.parent.name == self.UNC_FOLDER and not any(d.parent.iterdir()):
                    d.parent.rmdir()
            except OSError:
                pass

        question_folder.mkdir(parents=True, exist_ok=True)
        self._register_question_folder(level, subject, question_folder_name, question_folder)
        qp_path = question_folder / f"{question_folder_name}.webp"
        self._save_image(matched.qp.assembled_image, qp_path)
        (question_folder / "REASON.txt").unlink(missing_ok=True)

        from .json_generator import canonical_metadata
        json_data = canonical_metadata(json_data)
        json_path = question_folder / "metadata.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(json_data, f, indent=4)

        from .mcq_registry import is_mcq as _reg_is_mcq_t
        if (str(getattr(matched, "paper_format", "")).upper() == "MCQ"
                or _reg_is_mcq_t(getattr(config, "syllabus_code", ""),
                                 getattr(matched, "variant", ""),
                                 getattr(matched, "year", None))):
            # Same MCQ contract as the flat review home: an _MS.txt sidecar is
            # always written (letter, or empty + loud when unavailable).
            from .mcq_output import write_mcq_ms, validate_mcq_ms_file
            _ms_txt = write_mcq_ms(question_folder, question_folder_name,
                                   getattr(matched, "ms_answer", None))
            if not validate_mcq_ms_file(_ms_txt):
                print(f"[OutputManager] ! MCQ topic-review _MS.txt empty/invalid for "
                      f"{question_folder_name}")

        assert qp_path.exists(), f"QP not saved: {qp_path}"
        assert json_path.exists(), f"JSON not saved: {json_path}"
        assert topic_path.name == assigned_topic, (
            f"Topic folder {topic_path.name!r} != metadata topic[0] {assigned_topic!r}"
        )
        print(f"[OutputManager] REVIEW_REQUIRED (no_markscheme, topic={assigned_topic}): "
              f"{matched.full_qp_code} {matched.question_number} -> "
              f"{question_folder.relative_to(self.output_root)}")
        return {
            "qp": qp_path, "ms": None, "json": json_path,
            "major": major_path, "paper_type": paper_type_folder,
            "question_folder": question_folder,
            "question_folder_name": question_folder_name,
            "winning_major": classification.winning_major,
            "assigned_topic": assigned_topic,
            "reason": "no_markscheme", "level": level,
        }

    def _generate_json_data(self, matched: MatchedQuestion, classification: ClassificationResult, config: SubjectConfig) -> dict:
        # Keep this writer in lock-step with JSONGenerator; the folder is driven
        # by its topic[0], never by a separately generated identifier.
        from .json_generator import JSONGenerator
        return JSONGenerator().generate_json(matched, classification, config)

    def _save_image(self, image: Image.Image, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        if image.mode in ('RGBA', 'LA'):
            bg = Image.new('RGB', image.size, 'white')
            bg.paste(image, mask=image.split()[-1])
            image = bg
        elif image.mode != 'RGB':
            image = image.convert('RGB')

        # User requirement (2026-08-14): no barcodes in any crop. The
        # seam/edge scrubber cannot see mid-page barcode bands, so every
        # image that reaches the disk passes the full-canvas scrubber.
        from .webp_utils import scrub_barcode_bands, save_webp
        image = scrub_barcode_bands(image)

        if image.size[0] != self.target_width:
            w, h = image.size
            new_h = int((self.target_width / w) * h)
            image = image.resize((self.target_width, new_h), Image.LANCZOS)

        # RS-64: anchor the visible top white band to exactly 20 rows above the
        # first ink, as CROPPING_LOCK.md Amendment 2 requires.
        #
        # This is the ONLY correct place for it. Two transforms above run after
        # any anchor applied earlier in the crop engine and undo it:
        #   * scrub_barcode_bands paints barcode bands white, which can only ADD
        #     white above first ink (measured bands of 82/93 px);
        #   * the exact-width LANCZOS resize scales the band by 2280/w, shrinking
        #     a 20px pre-cut to 15/16 px.
        # Every image that reaches disk passes through here, so anchoring last
        # guarantees the invariant on the written artefact rather than on an
        # intermediate that is subsequently modified.
        #
        # Gold's implementation is reused, never reimplemented. It only crops or
        # pads the top edge - width, bottom and multipage seams are untouched -
        # and it asserts every removed row is white, so it cannot clip content.
        # MS crops are excluded: they come from the RULE-6 pristine MS engine,
        # whose geometry must not change.
        if "_MS" not in path.name and "_CI" not in path.name and "_IN" not in path.name:
            try:
                from cambridge_qb import question_split as _gold_qs
                _anchor = getattr(_gold_qs, "_align_top_white_band_final", None)
                if _anchor is not None:
                    image = _anchor(image)
                else:
                    print(f"[OutputManager] top-band anchor unavailable in gold "
                          f"question_split - band left unanchored for {path.name}")
            except AssertionError:
                # Gold refused to trim because it would remove ink. Save the image
                # unmodified and flag it - never force the band, never clip.
                print(f"[OutputManager] ! top-band anchor REFUSED for {path.name} "
                      f"(would clip ink) - saved unanchored, needs review")
            except Exception as _band_err:
                print(f"[OutputManager] top-band anchor skipped for {path.name}: "
                      f"{_band_err}")

        # One file per crop. A crop taller than the WebP 16383px limit is
        # scaled to fit inside that file and padded back to 2280px (A16: QP
        # and MS alike). Do not write ``<stem>_partN.webp``.
        save_webp(image, path, quality=self.quality)

    def ensure_no_duplicate_distribution(self):
        from collections import defaultdict
        question_to_majors = defaultdict(set)

        for qp_file in self.output_root.rglob("*.webp"):
            if self._is_auxiliary_path(qp_file):
                continue
            if "_MS" in qp_file.name or "_CI" in qp_file.name or "_IN" in qp_file.name:
                continue
            question_folder = qp_file.parent
            # For new structure with paper type: Level/Subject/PaperType/Major/Q
            # Major is parent of Q folder's parent? Actually Q folder parent is major, major parent is paper type, paper type parent is subject
            # For duplicate check, we need major folder
            major_folder = question_folder.parent
            # If major folder is actually paper type? Check
            # Our structure: Level/Subject/PaperType/Major/Q
            # So Q parent = Major, Major parent = PaperType, PaperType parent = Subject
            # For old structure without paper type: Level/Subject/Major/Q

            json_path = question_folder / "metadata.json"
            base = None
            if json_path.exists():
                try:
                    with open(json_path, 'r') as f:
                        data = json.load(f)
                        paper = data.get("paper", "unknown")
                        qnum = data.get("question_number", "")
                        base = f"{paper}_{qnum}"
                except Exception as e:
                    print(f"[OutputManager] Warning duplicate check JSON parse failed {question_folder}: {e}")
                    base = str(question_folder)
            else:
                base = str(question_folder)

            question_to_majors[base].add(str(major_folder))

        errors = []
        fixed = []
        for base_q, majors in question_to_majors.items():
            if len(majors) > 1:
                errors.append(f"Duplicate placement for {base_q} in {len(majors)} majors: {majors} - must be exactly ONE per R5,R6")

        return errors, fixed

    def migrate_legacy_paper_folders(self) -> list[str]:
        """Rename/merge descriptive paper directories into paper-N.

        This is output-tree maintenance only; no QP/MS crop code is called.
        """
        moved = []
        if not self.output_root.exists():
            return moved
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith("."):
                continue
            for subject_dir in [d for d in level_dir.iterdir() if d.is_dir()]:
                for item in list(subject_dir.iterdir()):
                    if not item.is_dir():
                        continue
                    number = _legacy_paper_folder_number(item.name)
                    if number is None:
                        continue
                    target = subject_dir / f"paper-{number}"
                    if target == item:
                        continue
                    _merge_directory_contents(item, target)
                    moved.append(f"{item} -> {target}")
                    logger.info("Migrated legacy paper folder: %s -> %s", item, target)
        return moved

    def _expand_topic_review(self, major_dir: Path, question_folders: list, removed: list) -> list:
        """Replace a ``<Topic>/review_required`` container with the question
        folders inside it, so cleanup judges each parked no-MS question on its
        own instead of deleting the container as an "invalid question folder".
        An empty container is pruned."""
        if major_dir.name == self.UNC_FOLDER:
            return question_folders
        out = []
        for q in question_folders:
            if q.name == SPECIMEN_FOLDER_NAME:
                # Judge the specimen papers inside it one by one, exactly as
                # if they sat directly under the topic.
                subs = [d for d in q.iterdir() if d.is_dir()]
                if not subs and not any(q.iterdir()):
                    shutil.rmtree(q, ignore_errors=True)
                    removed.append(str(q))
                    continue
                out.extend(self._expand_topic_review(q, subs, removed))
                continue
            if q.name != self.UNC_FOLDER:
                out.append(q)
                continue
            subs = [d for d in q.iterdir() if d.is_dir()]
            if not subs and not any(q.iterdir()):
                shutil.rmtree(q, ignore_errors=True)
                removed.append(str(q))
                continue
            out.extend(subs)
        return out

    def cleanup_empty_and_invalid_folders(self):
        self.migrate_legacy_paper_folders()
        removed = []
        # These historical, per-question text artifacts are no longer part of
        # the delivery contract. Remove only these known generated names; do
        # not assume an arbitrary user-authored *.txt file is disposable.
        for stale_text in list(self.output_root.rglob("REASON.txt")) + list(self.output_root.rglob("examiner_report.txt")):
            if self._is_auxiliary_path(stale_text):
                continue
            try:
                stale_text.unlink()
                removed.append(str(stale_text))
            except OSError:
                logger.warning("Could not remove legacy question text artifact: %s", stale_text)
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.') or level_dir.name in _AUXILIARY_OUTPUT_DIRS:
                continue

            subject_dirs = []
            if level_dir.name in ["IGCSE", "A-Level"]:
                subject_dirs = [d for d in level_dir.iterdir() if d.is_dir()]
            else:
                subject_dirs = [level_dir]

            for subject_dir in subject_dirs:
                if not subject_dir.is_dir():
                    continue
                if subject_dir.name in {"Mathematics_9709", "Further_Mathematics_9231"}:
                    # Reference folders are intentionally empty until manual categorization.
                    continue
                # Subject may contain paper type folders or major folders directly
                # Check for paper type folders first
                for item in subject_dir.iterdir():
                    if not item.is_dir():
                        continue

                    # Item could be paper type folder (P2_AS_Structured) or major folder (if old structure without paper type)
                    # Determine if it's paper type folder by name pattern P?_
                    is_paper_type = _is_paper_type_dir_name(item.name)
                    
                    if is_paper_type:
                        # This is paper type folder, contains major folders
                        paper_type_dir = item
                        for major_dir in paper_type_dir.iterdir():
                            if not major_dir.is_dir():
                                continue
                            if major_dir.name in {"_insert", "_confidential"}:
                                continue  # insert booklet crops (2026-08-15)
                            if major_dir.name == "json":
                                import shutil
                                shutil.rmtree(major_dir)
                                removed.append(str(major_dir))
                                continue

                            question_folders = [d for d in major_dir.iterdir() if d.is_dir()]
                            if not question_folders:
                                import shutil
                                shutil.rmtree(major_dir)
                                removed.append(str(major_dir))
                                continue

                            valid_q = 0
                            question_folders = self._expand_topic_review(major_dir, question_folders, removed)
                            for q_folder in question_folders:
                                qp_exists = len(list(q_folder.glob("*.webp"))) > 0 and len([f for f in q_folder.glob("*.webp") if "_MS" not in f.name and "_INSERT" not in f.name and "_IN" not in f.name and "_CI" not in f.name]) > 0
                                ms_exists = len(list(q_folder.glob("*_MS.webp"))) > 0 or len(list(q_folder.glob("*_MS.txt"))) > 0
                                json_exists = (q_folder / "metadata.json").exists()
                                # Review folders are preserved by their
                                # canonical metadata plus whichever real asset
                                # exists (QP or MS). Reasons live in the run
                                # report, not inside question folders.
                                if (qp_exists and json_exists) or (ms_exists and json_exists):
                                    valid_q += 1
                                else:
                                    import shutil
                                    shutil.rmtree(q_folder)
                                    removed.append(str(q_folder))

                            if valid_q == 0:
                                import shutil
                                shutil.rmtree(major_dir)
                                removed.append(str(major_dir))

                        # After cleaning majors inside paper type, check if paper type folder is empty
                        if not any(d.is_dir() for d in paper_type_dir.iterdir()):
                            import shutil
                            shutil.rmtree(paper_type_dir)
                            removed.append(str(paper_type_dir))

                    else:
                        # Item is major folder directly under subject (old structure without paper type) or new structure if paper type omitted
                        major_dir = item
                        if major_dir.name == "grade_thresholds":
                            # Grade-threshold sidecars (grade_threshold.py,
                            # 2026-08-15) are leaf data folders (json/txt only,
                            # no question subfolders) — never pruned as an
                            # "empty major folder".
                            continue
                        if major_dir.name == "json":
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))
                            continue

                        # Check for direct webp in major (old invalid)
                        direct_webp = list(major_dir.glob("*.webp"))
                        if direct_webp:
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))
                            continue

                        question_folders = [d for d in major_dir.iterdir() if d.is_dir()]
                        if not question_folders:
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))
                            continue

                        valid_q = 0
                        question_folders = self._expand_topic_review(major_dir, question_folders, removed)
                        for q_folder in question_folders:
                            all_webp = list(q_folder.glob("*.webp"))
                            qp_exists = len([f for f in all_webp if "_MS" not in f.name and "_INSERT" not in f.name and "_IN" not in f.name and "_CI" not in f.name]) > 0
                            ms_exists = len(list(q_folder.glob("*_MS.webp"))) > 0 or len(list(q_folder.glob("*_MS.txt"))) > 0
                            json_exists = (q_folder / "metadata.json").exists()
                            # Review folders are preserved by canonical
                            # metadata plus their QP or MS asset; the reason is
                            # reported outside the question folder.
                            if (qp_exists and json_exists) or (ms_exists and json_exists):
                                valid_q += 1
                            else:
                                import shutil
                                shutil.rmtree(q_folder)
                                removed.append(str(q_folder))

                        if valid_q == 0:
                            import shutil
                            shutil.rmtree(major_dir)
                            removed.append(str(major_dir))

        return removed

    def validate_qp_ms_pairs(self, auto_heal: bool = True) -> List[str]:
        """Validate output tree. Returns a list of error strings.

        Audit fix-group 7 (maintainer-approved adaptations applied):
          C1  Folder name == metadata topic[0] — AUTO-HEALED by moving the
              question folder under the correct topic folder (was error-only).
          C4  Forbidden-field rescan: strip + rewrite any metadata.json found
              containing forbidden fields (belt-and-suspenders; the writer
              already strips them).
          C2  File presence per question folder: QP webp + MS webp +
              metadata.json are errors when missing. examiner_report.txt is
              only checked when an ER was supplied for the paper, and then
              only as a WARNING (legit statuses like `no_verified_er` produce
              no per-question txt by design — maintainer decision: no
              placeholder ER files).
              ADAPTATION: `*_ER.webp` renders are full-page report images, not
              2280px question crops — they are EXCLUDED from "QP present" and
              width checks (the old code let an ER webp masquerade as a QP
              file and would false-flag or false-pass).
          C3  Width invariant 2280 re-checked for QP and MS crops (not _ER).
          C5  Empty-folder pruning — EXCLUDING Math/Further-Math reference
              staging trees (`paper-N` folders), whose empty topic folders are
              intentional staging structure.
        """
        errors: List[str] = []

        # ---------- Phase 0a: forbidden-field rescan + folder/topic auto-heal ----------
        for json_file in list(self.output_root.rglob("metadata.json")):
            if self._is_auxiliary_path(json_file):
                continue
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
            except Exception as e:
                errors.append(f"Invalid JSON {json_file}: {e}")
                continue

            found = [f for f in FORBIDDEN_METADATA_FIELDS if f in data]
            if found:
                for f in found:
                    data.pop(f, None)
                json_file.write_text(json.dumps(data, indent=4), encoding="utf-8")
                logger.info("Stripped forbidden fields %s from %s", found, json_file)

            q_folder = json_file.parent
            major_folder = q_folder.parent
            topics = data.get("topic", [])
            assigned_topic = topics[0] if isinstance(topics, list) and topics else None
            if not assigned_topic:
                continue  # manual/reference staging (topic=[]) — nothing to heal
            if assigned_topic in ("review_required", "review_required_no_ms",
                                  "review_required_no_qp"):
                # RS-5: review_required routing is deliberate; the sentinel must
                # never be auto-healed into a physical topic folder name.
                continue
            if is_topic_review_folder(q_folder, topics):
                # <Topic>/review_required/<QID>: topic[0] is the grandparent by
                # design (no-MS question classified, parked for review).
                continue
            if assigned_topic != major_folder.name:
                if auto_heal:
                    correct_dir = major_folder.parent / assigned_topic
                    dest = correct_dir / q_folder.name
                    if dest.exists():
                        errors.append(f"Cannot auto-heal {q_folder}: destination exists {dest}")
                    else:
                        correct_dir.mkdir(parents=True, exist_ok=True)
                        shutil.move(str(q_folder), str(dest))
                        logger.info("Auto-healed routing: %s -> %s", q_folder, dest)
                else:
                    errors.append(
                        f"Topic folder {major_folder.name!r} != JSON topic[0] {assigned_topic!r} for {json_file}"
                    )

        # Phase 0b: legacy .jsonc cleanup (pairs with json_generator C3).
        for stale in list(self.output_root.rglob("*.jsonc")):
            if self._is_auxiliary_path(stale):
                continue
            stale.unlink()
            logger.info("Removed legacy %s", stale)

        # ---------- Phase 1: per-question folder checks (healed tree) ----------
        for json_file in self.output_root.rglob("metadata.json"):
            if self._is_auxiliary_path(json_file):
                continue
            question_folder = json_file.parent
            major_folder = question_folder.parent

            all_webp = list(question_folder.glob("*.webp"))
            # ADAPTATION: exclude examiner-report page renders from QP/MS logic.
            qp_files = [f for f in all_webp if "_MS" not in f.name and "_ER" not in f.name and "_INSERT" not in f.name and "_IN" not in f.name and "_CI" not in f.name]
            ms_files = list(question_folder.glob("*_MS.webp"))

            if len(qp_files) == 0 and not _is_review_required_no_qp(question_folder):
                errors.append(f"Question folder {question_folder} missing QP webp - invalid per R9")
            if len(ms_files) == 0 and not _is_review_required_no_ms(question_folder):
                # IGCSE paper-format round (mcq_ms=letters): MCQ folders carry
                # the extracted grid letter in the `*_MS.txt` sidecar, never an
                # MS webp. User requirement (2026-08-14): metadata.json is
                # canonical 11 fields only — the sidecar is the single source
                # of the letter.
                from .mcq_output import valid_ms_sidecar as _valid_sidecar
                _txt_files = list(question_folder.glob("*_MS.txt"))
                if _txt_files:
                    _tl = _txt_files[0].read_text(encoding="utf-8").strip()
                    if not _valid_sidecar(_tl):
                        errors.append(f"Question folder {question_folder}: _MS.txt invalid content ({_tl!r}) - expected A-D letter or MS_UNAVAILABLE placeholder")
                else:
                    errors.append(f"Question folder {question_folder} missing MS webp - invalid per R9")

            # C3 width invariant. QP crops MUST be 2280 (locked QP pipeline
            # guarantee). MS crops come from the LOCKED gold MS path, which by
            # design does not normalise width (observed: 751px at main.py's
            # dpi=75 construction) — MS width is reported as a warning, never
            # an error, since the MS path must not be "fixed". _ER renders
            # are excluded entirely (full-page report images).
            for wf in qp_files:
                try:
                    with Image.open(wf) as im:
                        im.verify()
                    with Image.open(wf) as im:
                        if im.size[0] != self.target_width:
                            errors.append(f"Width not 2280 for {wf}: {im.size[0]}")
                except Exception as e:
                    errors.append(f"Invalid webp {wf}: {e}")
            for wf in ms_files:
                try:
                    with Image.open(wf) as im:
                        im.verify()
                    with Image.open(wf) as im:
                        if im.size[0] != self.target_width:
                            logger.warning(
                                "MS crop width %d != %d for %s (locked gold MS path — expected, not an error)",
                                im.size[0], self.target_width, wf,
                            )
                except Exception as e:
                    errors.append(f"Invalid webp {wf}: {e}")

            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                qnum = data.get("question_number", "")
                if qnum and qnum not in question_folder.name:
                    errors.append(f"JSON question_number {qnum} not in folder name {question_folder.name} in {json_file}")
                text_files = sorted(question_folder.glob("*.txt"))
                paper_match = re.match(r"(\d{4})_", str(data.get("paper", "")))
                from .mcq_registry import is_mcq as _is_mcq
                sidecar_ok = (
                    len(text_files) == 1 and text_files[0].name.endswith("_MS.txt")
                    and paper_match is not None
                    and _is_mcq(paper_match.group(1), str(data.get("variant", "")),
                                data.get("year"))
                )
                if text_files and not sidecar_ok:
                    errors.append(
                        f"Question folder {question_folder}: text artifacts are only permitted for MCQ _MS.txt sidecars"
                    )

                # Per-question examiner_report.txt was retired by the final
                # delivery contract. ER visual WebPs may be present, but text
                # commentary remains a run-level/report artifact instead.
            except Exception as e:
                errors.append(f"Invalid JSON {json_file}: {e}")

        for json_file in self.output_root.rglob("*.json"):
            if self._is_auxiliary_path(json_file):
                continue
            # 2026-08-10 (approved amendment RS-2, guarded-runner finding V2b):
            # dotfiles are state/tooling, not question artifacts — most
            # importantly .pipeline_state.json (RS-1 crash-resume). Same
            # protection as validation.py V2; loud, never silent.
            if json_file.name.startswith("."):
                print(f"[OutputManager] kept dotfile state JSON (not an orphan): {json_file.name}")
                continue
            if "_insert" in json_file.parts:
                # insert booklet manifest (2026-08-15): kept, never orphan-flagged
                print(f"[OutputManager] kept insert manifest JSON (not an orphan): {json_file.name}")
                continue
            if json_file.parent.name == "grade_thresholds":
                # A15 (2026-09-22): S7b grade-threshold sidecar — same protection
                # validation.check_no_orphan_json has had since RS-51; this scan
                # was the second surface still flagging it on every real run.
                print(f"[OutputManager] kept grade-threshold JSON (not an orphan): {json_file.name}")
                continue
            if _is_pipeline_companion_json(json_file, self.output_root):
                print(f"[OutputManager] kept companion pipeline JSON (not an orphan): {json_file.name}")
                continue
            if json_file.name != "metadata.json":
                errors.append(f"Orphan JSON not named metadata.json: {json_file}")

        # ---------- Phase 2: structural checks (paper-type + legacy layouts) ----------
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.') or level_dir.name in _AUXILIARY_OUTPUT_DIRS:
                continue
            subject_dirs = []
            if level_dir.name in ["IGCSE", "A-Level"]:
                subject_dirs = [d for d in level_dir.iterdir() if d.is_dir()]
            else:
                subject_dirs = [level_dir]

            for subject_dir in subject_dirs:
                for item in subject_dir.iterdir():
                    if not item.is_dir():
                        continue
                    is_paper_type = _is_paper_type_dir_name(item.name)
                    if is_paper_type:
                        paper_type_dir = item
                        for major_dir in paper_type_dir.iterdir():
                            if not major_dir.is_dir():
                                continue
                            if major_dir.name in {"_insert", "_confidential"}:
                                continue  # insert booklet crops (2026-08-15)
                            direct_webp = [w for w in major_dir.glob("*.webp") if "_ER" not in w.name]
                            if direct_webp:
                                errors.append(f"Found webp directly in major folder {major_dir} - must be inside question subfolders")
                    else:
                        major_dir = item
                        if major_dir.name == "json":
                            continue
                        direct_webp = [w for w in major_dir.glob("*.webp") if "_ER" not in w.name]
                        if direct_webp:
                            errors.append(f"Found webp directly in major folder {major_dir} - must be inside question subfolders (new structure requires PaperType/Major/Q)")

        # ---------- Phase 3: empty-folder prune (math staging protected) ----------
        def _in_math_staging(p: Path) -> bool:
            return any(
                re.fullmatch(r"paper-\d+", a.name)
                for a in p.parents
                if a.is_relative_to(self.output_root)
            )

        dirs = [d for d in self.output_root.rglob("*") if d.is_dir()]
        dirs.sort(key=lambda d: len(d.parts), reverse=True)  # deepest first
        for folder in dirs:
            if folder == self.output_root or self._is_auxiliary_path(folder):
                continue
            if _in_math_staging(folder):
                continue  # intentional empty reference-topic folders (9709/9231)
            if not any(folder.iterdir()):
                folder.rmdir()
                logger.debug("Pruned empty folder: %s", folder)

        return errors

