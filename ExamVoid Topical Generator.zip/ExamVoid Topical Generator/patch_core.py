#!/usr/bin/env python3
"""One-time, idempotent patch for core/validation.py.

Why this exists
---------------
The final S8 audit scans every *.json under the output root and rejects any
file that is not a metadata.json inside a question folder. Its auxiliary-path
test only looks at the FIRST path component, so the audit tree
``.run_report/papers/<paper>.json`` sitting inside a bundle staging directory
(``.staging/bundle_<key>/.run_report/...``) is not recognised as auxiliary.

Effect on you: the audit reports FAILED (errors=1), the paper is counted as
"review required" instead of "complete", and --resume can no longer skip it.
The crops themselves are correct - only the bookkeeping is wrong.

What this does
--------------
Excludes auxiliary trees (``.run_report``, ``paper_failures``, ``worksheets``)
at any depth, not just depth 0. Verified: audit goes from FAILED (errors=1)
to PASSED (errors=0).

Safe to run repeatedly - it detects the patch and does nothing the 2nd time.
Nothing else in the pipeline is touched.
"""

from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

OLD_ANCHOR = "        return bool(rel.parts) and rel.parts[0] in AUXILIARY_OUTPUT_DIRS"

NEW_ANCHOR = '''        if not rel.parts:
            return False
        # auxiliary at depth 0, OR any .run_report / paper_failures tree nested
        # inside a bundle staging dir (which is itself auxiliary)
        if rel.parts[0] in AUXILIARY_OUTPUT_DIRS:
            return True
        return any(part in _NESTED_AUXILIARY for part in rel.parts[:-1])'''

NESTED_CONST = '_NESTED_AUXILIARY = {".run_report", "paper_failures", "worksheets"}'

MARKER = "_NESTED_AUXILIARY"


def find_repo() -> Path | None:
    for cand in (HERE, *HERE.parents):
        if (cand / "core" / "validation.py").is_file():
            return cand
    for cand in HERE.rglob("core/validation.py"):
        return cand.parent.parent
    return None


def main() -> int:
    repo = find_repo()
    if repo is None:
        print("patch_core: core/validation.py not found - nothing to do.")
        print("            (run this from inside the generator folder)")
        return 0

    target = repo / "core" / "validation.py"
    src = target.read_text(encoding="utf-8")

    if MARKER in src:
        print(f"patch_core: {target.relative_to(repo.parent)} already patched - skipping.")
        return 0

    if OLD_ANCHOR not in src:
        print(f"patch_core: {target.name} has an unexpected shape - leaving it alone.")
        print("            (not an error; the audit will still work, just noisier)")
        return 0

    out = src.replace(OLD_ANCHOR, NEW_ANCHOR, 1)

    # add the constant next to AUXILIARY_OUTPUT_DIRS
    lines = out.splitlines(keepends=True)
    for i, line in enumerate(lines):
        if line.startswith("AUXILIARY_OUTPUT_DIRS"):
            lines.insert(i + 1, NESTED_CONST + "\n")
            break
    else:  # pragma: no cover - defensive
        print("patch_core: could not place the constant - leaving file alone.")
        return 0
    out = "".join(lines)

    try:
        compile(out, str(target), "exec")
    except SyntaxError as exc:
        print(f"patch_core: refusing to write - patched file would not compile ({exc})")
        return 1

    target.write_text(out, encoding="utf-8")
    print(f"patch_core: patched {target.relative_to(repo.parent)}")
    print("            audit now ignores nested .run_report trees.")
    print("            run this once; it will skip itself next time.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
