#!/usr/bin/env python3
r"""Audit an input folder: exactly which PDFs the pipeline will DROP, and why.

The pipeline rejects a PDF at one of three gates. This tells you which gate,
for every file, so you can decide what is worth fixing before a long run.

    gate 1  Could not identify        - no filename pattern matched at all
    gate 2  no approved subject config- identified, but no subjects_caie config
    gate 3  ok                        - will be processed

Usage
-----
    python audit_input.py                     # audits .\input
    python audit_input.py --input C:\\papers  # audits another folder
    python audit_input.py --show 40           # list up to 40 dropped filenames
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
for _cand in (HERE, *HERE.parents):
    if (_cand / "core" / "paper_identifier.py").is_file():
        REPO = _cand
        break
else:
    sys.exit("[fatal] core/paper_identifier.py not found - run this from the repo")
sys.path.insert(0, str(REPO))

# Subject codes that HAVE a config, so gate 2 is answered without loading them.
_CONFIG_DIR = REPO / "subjects_caie"


def configured_codes() -> set[str]:
    codes: set[str] = set()
    for cfg in _CONFIG_DIR.rglob("config.json"):
        m = re.search(r"_(\d{4})/config\.json$", str(cfg).replace("\\", "/"))
        if m:
            codes.add(m.group(1))
    return codes


def classify(name: str, codes: set[str]):
    """-> (gate, code, detail)"""
    from core.paper_identifier import parse_paper_filename
    info = parse_paper_filename(name)
    if info is None:
        return 1, None, "no filename pattern matched"
    code = str(getattr(info, "syllabus_code", "") or "")
    if code and code not in codes:
        return 2, code, "identified but no approved subject config"
    if not code:
        return 1, None, "identified with an empty syllabus code"
    return 3, code, "ok"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", "-i", default=str(REPO / "input"))
    ap.add_argument("--show", "-s", type=int, default=25,
                    help="how many dropped filenames to list (default 25)")
    args = ap.parse_args()

    inp = Path(args.input)
    if not inp.is_dir():
        print(f"[audit] no such folder: {inp}")
        return 1

    codes = configured_codes()
    print(f"[audit] {len(codes)} subject configs found in subjects_caie/")
    print(f"[audit] scanning {inp} ...")

    pdfs = sorted(p for p in inp.rglob("*")
                  if p.is_file() and p.suffix.lower() == ".pdf")
    if not pdfs:
        print("[audit] no PDFs found")
        return 0

    gate = Counter()
    dropped: list[tuple[str, str]] = []
    missing_codes = Counter()
    ok_codes = Counter()

    for p in pdfs:
        g, code, _detail = classify(p, codes)   # full path: the site-specimen
                                              # path reads the cover, so it needs one
        gate[g] += 1
        if g == 1:
            dropped.append((p.name, "could not identify"))
        elif g == 2:
            missing_codes[code] += 1
            dropped.append((p.name, f"no config for {code}"))
        else:
            ok_codes[code] += 1

    total = len(pdfs)
    lost = gate[1] + gate[2]
    print()
    print("=" * 68)
    print("  INPUT AUDIT")
    print("=" * 68)
    print(f"  total PDFs            : {total:,}")
    print(f"  will be processed     : {gate[3]:,}  ({100*gate[3]/total:.1f}%)")
    print(f"  DROPPED               : {lost:,}  ({100*lost/total:.1f}%)")
    print(f"    gate 1 unidentified : {gate[1]:,}")
    print(f"    gate 2 no config    : {gate[2]:,}")
    print()

    if ok_codes:
        print("  subjects that WILL run:")
        line = "   "
        for c, n in ok_codes.most_common():
            item = f"{c}({n}) "
            if len(line) + len(item) > 66:
                print(line)
                line = "   "
            line += item
        if line.strip():
            print(line)
        print()

    if missing_codes:
        print("  identified but NO config (real subjects being lost):")
        for c, n in missing_codes.most_common():
            print(f"    {c}  {n} file(s)")
        print()

    # Group the unidentified ones by their shape, so a pattern fix is obvious.
    shapes = Counter()
    for name, _ in dropped:
        if "could not identify" not in _:
            continue
        n = name[:-4].lower()
        if "specimen" in n:
            shapes["hyphenated specimen  (XXXX-YYYY-specimen-paper-N)"] += 1
        elif "transcript" in n:
            shapes["transcript  (... Transcript NN)"] += 1
        elif "role play" in n:
            shapes["role play cards  (... Role Play Cards NN)"] += 1
        elif "teachers notes" in n or "teacher" in n:
            shapes["teachers notes"] += 1
        else:
            shapes["other"] += 1
    if shapes:
        print("  unidentified, grouped by filename shape:")
        for s, n in shapes.most_common():
            print(f"    {n:5d}  {s}")
        print()

    shown = 0
    for name, why in dropped:
        if shown >= args.show:
            print(f"    ... and {len(dropped) - shown} more (raise --show to list them)")
            break
        print(f"    [{why}] {name}")
        shown += 1

    print()
    print("  gate 1 = no filename pattern matched. Fixable by adding a pattern.")
    print("  gate 2 = subject config missing. Fixable by adding a config.")
    print("  Files that are transcripts / teacher notes / role-play cards are")
    print("  usually NOT needed for topical generation - only fix those if you")
    print("  actually want them.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
