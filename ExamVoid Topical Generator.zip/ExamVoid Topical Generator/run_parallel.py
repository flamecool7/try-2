#!/usr/bin/env python3
"""Parallel, RAM-guarded driver for the CAIE cropping pipeline.

Use this instead of `run_guarded.py` when you have more than one core and more
than ~2.5 GB of RAM. It calls the project's own sanctioned parallel runner
(`core/batch_runner.run_pipeline`), which:

  * runs bundles in a ProcessPoolExecutor (run_guarded.py is sequential by
    design -- it spawns ONE isolated subprocess per paper and clamps
    --workers to "recorded, not honoured"),
  * clamps concurrency against measured MemAvailable before every batch
    (PER_WORKER_PEAK_MB = 1100, PARENT_RESERVE_MB = 400),
  * resumes by default (completed bundles never re-run),
  * routes QP cropping through the RAM-safe streaming path (low_ram=True),
  * runs the S6/S7/S8 attach + audit ONCE after all workers instead of
    re-walking the output tree per paper.

Classification logic, DPI, crop geometry, target width and every fail-closed
gate are untouched: this only changes HOW MANY papers run at once.

Examples
--------
    # everything, auto worker count (RAM-guarded)
    python3 run_parallel.py --input ./input --output ./output

    # force 6 workers and show why the guard allows/refuses it
    python3 run_parallel.py --input ./input --output ./output --workers 6 --verbose

    # split the job across machines/processes (disjoint slices, same output dir)
    python3 run_parallel.py --subject 9708 --output ./output
    python3 run_parallel.py --syllabus-code 9702 --output ./output
    python3 run_parallel.py --session s23 --output ./output
    python3 run_parallel.py --year 23 --output ./output

    # dry run: preflight + worker/guard decision, zero processing
    python3 run_parallel.py --input ./input --output ./output --dry-run
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
# Locate the repo root (the directory that contains core/ and run_guarded.py).
REPO = None
_cands = [HERE, *HERE.parents]
for _sub in ("", "extracted/TopicalGenerator_CLI_Updated", "TopicalGenerator_CLI_Updated"):
    _cands += [HERE / _sub] if _sub else []
for _cand in _cands:
    if (_cand / "core" / "batch_runner.py").is_file():
        REPO = _cand
        break
if REPO is None:  # last resort: shallow search
    for _hit in HERE.rglob("core/batch_runner.py"):
        REPO = _hit.parent.parent
        break
if REPO is None:
    sys.exit(f"[error] could not find core/batch_runner.py near {HERE}")
sys.path.insert(0, str(REPO))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", "-i", default=str(REPO / "input"))
    ap.add_argument("--output", "-o", default=str(REPO / "output"))
    ap.add_argument("--workers", "-w", type=int, default=None,
                    help="requested workers (None = auto: 6 on >=16GB, 4 on >=12GB, "
                         "2 otherwise, then clamped by the RAM guard)")
    ap.add_argument("--session", default=None, help="e.g. s23, m23, w23, specimen")
    ap.add_argument("--year", default=None, help="two- or four-digit exam year")
    ap.add_argument("--subject", default=None, help="substring match on subject")
    ap.add_argument("--syllabus-code", default=None, help="exact syllabus code, e.g. 9708")
    ap.add_argument("--level", default=None, choices=("IGCSE", "A-Level"))
    ap.add_argument("--variant", default=None)
    ap.add_argument("--no-low-ram", action="store_true",
                    help="disable the RAM-safe streaming QP path. Only if you have "
                         "RAM to burn; it RAISES peak RSS and makes the headroom "
                         "gate in run_guarded.py wait longer.")
    ap.add_argument("--retry-failed", action="store_true",
                    help="re-attempt bundles previously marked failed")
    ap.add_argument("--force-all", action="store_true",
                    help="ignore resume and reprocess every bundle")
    ap.add_argument("--dry-run", action="store_true", help="preflight only")
    ap.add_argument("--verbose", "-v", action="store_true",
                    help="print the RAM-guard decision and timing")
    args = ap.parse_args()

    from core.batch_runner import (PER_WORKER_PEAK_MB, PARENT_RESERVE_MB,
                                   _auto_worker_request, available_mem_mb,
                                   guard_decision, run_pipeline)

    inp = Path(args.input)
    if not inp.is_dir():
        print(f"[error] input directory not found: {inp}")
        return 1

    avail = available_mem_mb()
    want = args.workers if args.workers is not None else _auto_worker_request()
    conc, reasons = guard_decision(want, avail)
    print(f"[plan] input={inp}")
    print(f"[plan] output={Path(args.output).resolve()}")
    print(f"[plan] requested workers={want}  MemAvailable={avail}MB")
    print(f"[plan] effective concurrency={conc}  "
          f"(budget {PER_WORKER_PEAK_MB}MB/worker + {PARENT_RESERVE_MB}MB reserve)")
    for r in reasons:
        print(f"[plan]   {r}")
    if conc < want:
        print("[plan] NOTE: the RAM guard clamped you. More workers on this box "
              "means the OOM killer, not speed.")
    if avail is not None and avail < PER_WORKER_PEAK_MB + PARENT_RESERVE_MB:
        print("[plan] WARNING: not even one worker's budget fits in MemAvailable. "
              "Free RAM (close the browser/other runs) before starting, or expect "
              "the headroom gate to stall each paper.")

    t0 = time.time()
    result = run_pipeline(
        pdf_dir=str(inp),
        output_dir=str(args.output),
        workers=args.workers,
        resume=not args.force_all,
        retry_failed=args.retry_failed,
        force_all=args.force_all,
        low_ram=not args.no_low_ram,
        full_auto=True,
        session=args.session,
        year_filter=args.year,
        subject_filter=args.subject,
        syllabus_code_filter=args.syllabus_code,
        level_filter=args.level,
        variant_filter=args.variant,
        dry_run=args.dry_run,
    )
    if args.verbose or args.dry_run:
        print(f"[done] {time.time() - t0:.1f}s  {result}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
