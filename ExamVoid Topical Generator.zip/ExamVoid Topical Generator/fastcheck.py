"""fastcheck.py - drop-in progress + worker-count check for the crop batch.

Paste this next to your own script and:

    from fastcheck import plan, report

    p = plan("/path/to/output")            # reads state, does the maths
    print(report(p))                       # human-readable one-screen summary
    if p["mode"] == "unfinished_only":
        for code in p["codes"]:
            ...                            # only these subjects are left

No third-party imports. Uses the project's own RAM guard when it can find it,
and falls back to the same arithmetic inline so it works even if the repo root
is not on sys.path.

Why this exists: run_guarded.py records progress in <output>/.pipeline_state.json
while the parallel runner uses <output>/pipeline.sqlite and never reads it. So
the batch runner reports "Completed: 0" even when your output tree is full of
finished crops. Switching runners mid-run therefore redoes finished work -- this
tells you how much that would cost before you commit to it.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

# Mirrors core/batch_runner.py so the fallback arithmetic matches the real guard.
PER_WORKER_PEAK_MB = 1100
PARENT_RESERVE_MB = 400
SWITCH_THRESHOLD = 0.80          # above this, do NOT redo finished work
DEFAULT_SEC_PER_PAPER = 70.0     # only a starting guess; replaced by measured data
RATE_FILENAME = ".fastpack_rate.json"


def rate_path(output) -> Path:
    """Where the measured per-paper rate for THIS machine is cached."""
    return Path(output) / RATE_FILENAME


def load_rate(output) -> dict | None:
    """Read the rate measured on a previous run here, if any.

    The ETA must not depend on one machine's speed. Every run records how long
    it actually took per paper, and that number is used next time. Falls back
    to None when nothing has been measured yet.
    """
    f = rate_path(output)
    if not f.exists():
        return None
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
        sec = float(d.get("sec_per_paper") or 0)
        if sec <= 0:
            return None
        return d
    except Exception:
        return None


def save_rate(output, sec_per_paper: float, papers: int, workers: int) -> None:
    """Record the measured rate so future ETAs reflect THIS box, not a guess."""
    try:
        rate_path(output).write_text(json.dumps({
            "sec_per_paper": round(float(sec_per_paper), 2),
            "papers": int(papers),
            "workers": int(workers),
        }), encoding="utf-8")
    except Exception:
        pass


def sec_per_paper(output) -> float:
    """Measured rate if we have one, else the neutral starting guess."""
    r = load_rate(output)
    return float(r["sec_per_paper"]) if r else DEFAULT_SEC_PER_PAPER


# --------------------------------------------------------------------------
# 1. How much work has run_guarded.py already finished?
# --------------------------------------------------------------------------
def read_progress(output) -> tuple[int, int, list[tuple[str, int]]]:
    """-> (total_bundles, complete, [(syllabus_code, unfinished_count), ...])"""
    sf = Path(output) / ".pipeline_state.json"
    if not sf.exists():
        return 0, 0, []
    try:
        papers = (json.loads(sf.read_text(encoding="utf-8")) or {}).get("papers", {}) or {}
    except Exception:
        return 0, 0, []

    done = 0
    codes: dict[str, int] = {}
    for key, rec in papers.items():
        if str((rec or {}).get("status", "?")).lower() == "complete":
            done += 1
        else:
            code = str(key).split("_")[0]
            codes[code] = codes.get(code, 0) + 1
    return len(papers), done, sorted(codes.items())


# --------------------------------------------------------------------------
# 2. How many workers can this box actually run?
# --------------------------------------------------------------------------
def worker_budget(requested=None) -> dict:
    """-> {workers, avail_mb, cores, reasons, clamped}"""
    reasons: list[str] = []
    total_mb, avail = _mem_stats_mb()
    blind = avail is None

    conc = None
    try:
        import sys
        _cands = [Path.cwd(), *Path.cwd().parents]
        for _sub in ("extracted/TopicalGenerator_CLI_Updated",
                     "TopicalGenerator_CLI_Updated"):
            _cands.append(Path.cwd() / _sub)
        for _cand in _cands:
            if (_cand / "core" / "batch_runner.py").is_file():
                sys.path.insert(0, str(_cand))
                break
        from core.batch_runner import guard_decision
        auto = _auto_workers(total_mb)
        want = requested if requested is not None else auto
        conc, reasons = guard_decision(want, avail)
        if blind:
            reasons.append("MEM BLIND: no /proc, no psutil, no Win32 API - the "
                           "RAM guard cannot see your memory and will trust "
                           "whatever number you pass")
    except Exception:
        auto = _auto_workers(total_mb)
        want = requested if requested is not None else auto
        if blind:
            conc = want
            reasons.append("MEM BLIND: RAM unknown - trusting requested value")
        else:
            conc = max(1, (avail - PARENT_RESERVE_MB) // PER_WORKER_PEAK_MB)
            reasons.append(
                f"RAM-GUARD (inline): {avail}MB available -> "
                f"({avail} - {PARENT_RESERVE_MB}) // {PER_WORKER_PEAK_MB} = {conc}"
            )

    cores = os.cpu_count() or 1
    workers = min(conc, cores)
    clamped = workers < (requested if requested is not None else auto)
    if workers > cores:
        workers, clamped = cores, True
    return {"workers": workers, "avail_mb": avail, "cores": cores,
            "reasons": reasons, "clamped": clamped, "auto": auto}


# --------------------------------------------------------------------------
# 3. Put the two together: what should we actually do?
# --------------------------------------------------------------------------
def count_input_pdfs(input_dir) -> dict:
    """Count what is actually in the input folder.

    The ETA used to fall back to a hardcoded 2000 when no state file existed,
    which produced nonsense like "19.4 h" on a folder never run. Counting the
    real files is strictly better.

    -> {"pdfs", "qps", "mss", "others"}
    """
    d = Path(input_dir)
    if not d.is_dir():
        return {"pdfs": 0, "qps": 0, "mss": 0, "others": 0}
    pdfs = qps = mss = others = 0
    for p in d.rglob("*"):
        if not p.is_file() or p.suffix.lower() != ".pdf":
            continue
        pdfs += 1
        low = p.name.lower()
        if "_qp_" in low:
            qps += 1
        elif "_ms_" in low:
            mss += 1
        else:
            others += 1
    return {"pdfs": pdfs, "qps": qps, "mss": mss, "others": others}


def plan(output, workers=None, input_dir=None) -> dict:
    """-> everything you need to decide switch-vs-finish and how wide to run."""
    total, done, unfinished = read_progress(output)
    found = count_input_pdfs(input_dir) if input_dir else None
    frac = (done / total) if total else 0.0
    budget = worker_budget(workers)

    if total == 0:
        mode, codes = "fresh", []
    elif frac > SWITCH_THRESHOLD and unfinished:
        mode, codes = "unfinished_only", [c for c, _ in unfinished]
    else:
        mode, codes = "redo_all", []

    if mode == "unfinished_only":
        remaining = sum(n for _, n in unfinished)
    elif found and found["qps"]:
        remaining = found["qps"]
    elif total:
        remaining = total
    else:
        remaining = 0
    rate = sec_per_paper(output)
    eta_h = remaining * rate / max(1, budget["workers"]) / 3600

    return {
        "output": str(output),
        "input": str(input_dir) if input_dir else None,
        "found": found,
        "total": total,
        "done": done,
        "pct_complete": round(frac * 100, 1),
        "unfinished": unfinished,
        "mode": mode,                      # fresh | redo_all | unfinished_only
        "codes": codes,                    # syllabus codes still to do
        "workers": budget["workers"],
        "cores": budget["cores"],
        "avail_mb": budget["avail_mb"],
        "reasons": budget["reasons"],
        "clamped": budget["clamped"],
        "eta_hours": round(eta_h, 1),
        "redo_cost_hours": round(done * rate
                                 / max(1, budget["workers"]) / 3600, 1),
        "sec_per_paper": round(rate, 1),
        "rate_measured": bool(load_rate(output)),
    }


def report(p: dict) -> str:
    lines = [f"output          : {p['output']}"]
    if p.get("input"):
        lines.append(f"input           : {p['input']}")
    if p.get("found"):
        f = p["found"]
        lines.append(f"pdfs in input   : {f['pdfs']} "
                     f"({f['qps']} QP, {f['mss']} MS, {f['others']} other)")
    lines.append(f"progress        : {p['done']}/{p['total']} complete "
                 f"({p['pct_complete']}%)")
    lines += [
        f"workers         : {p['workers']}  (cores={p['cores']}, "
        f"MemAvailable={p['avail_mb']}MB)",
        f"mode            : {p['mode']}",
        f"eta             : ~{p['eta_hours']} h",
    ]
    if p["clamped"]:
        lines.append(f"  ! worker count was clamped - pass --workers {p['cores']} "
                     f"to use the whole machine")
    if p["mode"] == "unfinished_only":
        lines.append(f"codes left      : " + ", ".join(p["codes"]))
    elif p["mode"] == "redo_all" and p["done"]:
        lines.append(f"  ! switching redoes {p['done']} finished bundle(s) "
                     f"(~{p['redo_cost_hours']} h)")
    for r in p["reasons"]:
        lines.append(f"  - {r}")
    return "\n".join(lines)


def _auto_workers(total_mb):
    """Mirror core/batch_runner._auto_worker_request, but Windows-safe.

    The project's version reads psutil, then /proc/meminfo. On Windows with
    neither installed it falls through to `requested = 2` -- the exact
    "2 workers / 19.4 h" trap.
    """
    if total_mb is None:
        return 6
    if total_mb >= 16 * 1024:
        return 6
    if total_mb >= 12 * 1024:
        return 4
    return 2


def _mem_stats_mb():
    """-> (total_mb, available_mb); either may be None if unknowable."""
    try:
        with open("/proc/meminfo", encoding="ascii", errors="ignore") as fh:
            total = avail = None
            for line in fh:
                if line.startswith("MemTotal:"):
                    total = int(line.split()[1]) // 1024
                elif line.startswith("MemAvailable:"):
                    avail = int(line.split()[1]) // 1024
            if total or avail:
                return total, avail
    except OSError:
        pass
    try:
        import psutil
        vm = psutil.virtual_memory()
        return int(vm.total // (1024 * 1024)), int(vm.available // (1024 * 1024))
    except Exception:
        pass
    try:
        import ctypes

        class _MSX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        m = _MSX()
        m.dwLength = ctypes.sizeof(_MSX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            return (int(m.ullTotalPhys // (1024 * 1024)),
                    int(m.ullAvailPhys // (1024 * 1024)))
    except Exception:
        pass
    return None, None


def _mem_available_mb():
    """MemAvailable in MB. /proc -> psutil -> Win32 GlobalMemoryStatusEx."""
    return _mem_stats_mb()[1]


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(
        description="Progress + worker-budget check. Counts the PDFs actually "
                    "present in the input folder so the ETA is real.")
    ap.add_argument("--output", "-o", default="output")
    ap.add_argument("--input", "-i", default="input")
    ap.add_argument("--workers", "-w", type=int, default=None)
    a = ap.parse_args()
    print(report(plan(a.output, a.workers, input_dir=a.input)))
