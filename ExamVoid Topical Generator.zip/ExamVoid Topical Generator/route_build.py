#!/usr/bin/env python3
"""Route a build to the door that actually handles the papers in input/.

Why this exists
---------------
The repo has two independent build doors and they do NOT overlap:

  * ``run_pipeline.py`` -- the Cambridge (CAIE) pipeline. RAM-guarded parallel
    via ``--workers N``. This is the one that crops and classifies CAIE papers.
  * ``tools/run_universal_batch.py`` -- the AQA / Edexcel / IB / SAT router,
    parallel via ``--jobs N``. By design it refuses CAIE papers and records them
    as REVIEW_REQUIRED ("CAIE document - the Cambridge pipeline handles this
    paper ... the universal router is non-CAIE by design").

Pointing the wrong door at a folder produces zero crops and a folder full of
review_required entries, which looks exactly like a broken run.

There is also a third door that is a trap: ``run_guarded.py --workers N``
*records* the worker count but stays sequential on purpose
("per-paper isolation stays sequential for RAM safety ... for parallel bundles
use run_pipeline.py --workers N").

So this script looks at what is actually in ``input/`` and dispatches:

    any CAIE paper   ->  run_pipeline.py  --workers N   (parallel, RAM-guarded)
    no CAIE paper    ->  run_universal_batch.py --jobs N (parallel)

Usage
-----
    python route_build.py --input input --output output --jobs 14
    python route_build.py --input input --output output --jobs 14 --dry-run
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE
for _cand in (HERE, *HERE.parents):
    if (_cand / "core" / "batch_runner.py").is_file():
        REPO = _cand
        break
sys.path.insert(0, str(REPO))

# How many input PDFs to look at before deciding. The identifier is filename
# driven and cheap, but opening 2239 PDFs to answer "any CAIE here?" is not,
# and the answer almost never changes after the first few files.
PROBE_LIMIT = 300


def classify(input_dir: Path, probe_limit: int = PROBE_LIMIT):
    """-> (caie_count, other_count, boards, probed)"""
    from core.paper_identifier import identify_non_caie_paper

    pdfs = sorted(p for p in input_dir.rglob("*")
                  if p.is_file() and p.suffix.lower() == ".pdf")
    if not pdfs:
        return 0, 0, {}, 0

    caie = other = 0
    boards: dict[str, int] = {}
    for n, pdf in enumerate(pdfs[:probe_limit], start=1):
        try:
            info = identify_non_caie_paper(pdf)
        except Exception:
            info = None
        if info is None:
            caie += 1
            if caie:                      # one CAIE hit is enough to decide
                return caie, other, boards, n
        else:
            other += 1
            b = str(getattr(info, "board", "?") or "?")
            boards[b] = boards.get(b, 0) + 1
    return caie, other, boards, min(len(pdfs), probe_limit)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", "-i", default=str(REPO / "input"))
    ap.add_argument("--output", "-o", default=str(REPO / "output"))
    ap.add_argument("--jobs", "-j", type=int, default=14,
                    help="workers for whichever door is chosen (default 14). "
                         "This is a REQUEST: both doors clamp it to what free "
                         "RAM actually holds, so it can never oversubscribe.")
    ap.add_argument("--prune-stale-dirs", action="store_true",
                    help="pass --prune-stale-dirs to the universal router")
    ap.add_argument("--dry-run", action="store_true",
                    help="say which door would run, then stop")
    args = ap.parse_args()

    inp = Path(args.input)
    out = Path(args.output)
    if not inp.is_dir():
        print(f"[route] no input folder: {inp}")
        return 1

    t0 = time.time()
    caie, other, boards, probed = classify(inp)
    total = len([p for p in inp.rglob("*")
                 if p.is_file() and p.suffix.lower() == ".pdf"])

    print(f"[route] looked at {probed} of {total} PDF(s) in {time.time() - t0:.1f}s")
    print(f"[route] CAIE papers: {caie}   other boards: {other}"
          + (f"  {boards}" if boards else ""))

    if caie:
        door = "caie"
        cmd = [sys.executable, "-u", str(REPO / "run_pipeline.py"),
               "--input", str(inp), "--output", str(out),
               "--workers", str(args.jobs)]
        why = ("CAIE papers present - Cambridge pipeline, RAM-guarded parallel. "
               f"{args.jobs} worker(s) requested.")
    else:
        door = "universal"
        cmd = [sys.executable, "-u",
               str(REPO / "tools" / "run_universal_batch.py"),
               "--input", str(inp), "--output", str(out),
               "--jobs", str(args.jobs)]
        if args.prune_stale_dirs:
            cmd.append("--prune-stale-dirs")
        why = (f"no CAIE papers - universal router for {boards or 'AQA/Edexcel/IB/SAT'}, "
               f"{args.jobs} job(s) requested.")

    print(f"[route] door: {door}")
    print(f"[route] {why}")

    if args.dry_run:
        print("[route] dry run - nothing launched")
        print("        " + " ".join(cmd))
        return 0

    print()
    return subprocess.call(cmd)


if __name__ == "__main__":
    sys.exit(main())
