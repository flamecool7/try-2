#!/usr/bin/env sh
# =====================================================================
#  run_fast.sh  --  macOS / Linux equivalent of RUN_FAST.bat
#
#  Usage:   sh run_fast.sh
#
#  It cd's to its own location, so it does not matter where the repo
#  lives. No configuration needed: it installs anything missing,
#  applies a one-time audit fix, and runs the crop batch as wide as
#  your RAM allows.
# =====================================================================
cd "$(dirname "$0")" || exit 1

echo "============================================================"
echo "  Topical Generator - fast parallel run"
echo "  folder: $(pwd)"
echo "============================================================"

if command -v python3 >/dev/null 2>&1; then
    PY=python3
elif command -v python >/dev/null 2>&1; then
    PY=python
else
    echo
    echo "  ERROR: python3 is not on your PATH."
    echo "  Install Python 3.9+ and retry."
    echo
    exit 1
fi

if [ ! -f run_guarded.py ]; then
    echo
    echo "  ERROR: run_guarded.py is not in this folder."
    echo "  Put this script next to run_guarded.py, core/ and input/."
    echo
    exit 1
fi

if [ ! -f core/batch_runner.py ]; then
    echo
    echo "  ERROR: core/batch_runner.py not found - wrong folder."
    echo
    exit 1
fi

# 1. Make sure input/ and output/ exist, so a fresh unzip works.
[ -d input ]  || mkdir -p input
[ -d output ] || mkdir -p output

# 2. Install missing dependencies - only if something is actually missing,
#    so repeat launches are instant.
if ! "$PY" -c "import fitz, numpy, cv2, imagehash, pywt, scipy" >/dev/null 2>&1; then
    echo
    echo "  Installing missing Python dependencies - this happens once."
    echo "  (If it looks stuck it is downloading; later runs skip this.)"
    echo
    "$PY" -m pip install --quiet --disable-pip-version-check \
        PyMuPDF numpy "opencv-python-headless" imagehash PyWavelets scipy \
        || "$PY" -m pip install --quiet --disable-pip-version-check -r requirements.txt
    echo
    echo "  Dependencies done."
    echo
fi

# 3. One-time, safe, idempotent audit fix.
if [ -f patch_core.py ]; then
    "$PY" patch_core.py || echo "  patch_core.py reported a problem - continuing anyway."
fi

# 4. Go.
echo
echo "  First 1-2 minutes look silent: every PDF in input/ is being"
echo "  identified before anything is printed. \"[alive]\" lines mean"
echo "  it IS working. A \"[OK] <paper>\" line appears per finished paper."
echo

"$PY" start_fast.py --input input --output output --go --workers 14 --pause

echo
echo "============================================================"
echo "  FINISHED"
echo "============================================================"
