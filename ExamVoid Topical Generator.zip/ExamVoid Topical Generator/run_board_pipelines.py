#!/usr/bin/env python3
"""Run the board-specific pipeline(s) for papers in the matching input folders.

Input layout:
    input/CAIE       -> Cambridge/CAIE pipeline
    input/AQA        -> universal AQA adapter pipeline
    input/EDEXCEL    -> universal Edexcel adapter pipeline
    input/IB         -> universal IB adapter pipeline
    input/SAT        -> universal SAT adapter pipeline

A board folder must contain only papers for that board. ``--board ALL`` runs
all populated folders sequentially, preserving each board's own pipeline.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

BOARD_DIRS = {
    "CAIE": "CAIE",
    "AQA": "AQA",
    "EDEXCEL": "EDEXCEL",
    "IB": "IB",
    "SAT": "SAT",
}


def contains_pdfs(folder: Path) -> bool:
    return folder.is_dir() and any(
        path.is_file() and path.suffix.lower() == ".pdf"
        for path in folder.rglob("*")
    )


def command_for(board: str, input_dir: Path, output_dir: Path, *,
                workers: int, jobs: int, enable_ocr: bool,
                prune_stale_dirs: bool) -> list[str]:
    root = Path(__file__).resolve().parent
    if board == "CAIE":
        return [sys.executable, str(root / "run_pipeline.py"),
                "--input", str(input_dir), "--output", str(output_dir),
                "--workers", str(workers)]
    command = [sys.executable, str(root / "tools" / "run_universal_batch.py"),
               "--input", str(input_dir), "--output", str(output_dir),
               "--include-ib", "--include-sat", "--jobs", str(jobs)]
    if enable_ocr:
        command.append("--enable-ocr")
    if prune_stale_dirs:
        command.append("--prune-stale-dirs")
    return command


def main() -> int:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default=str(root / "input"),
                        help="Root containing CAIE/AQA/EDEXCEL/IB/SAT subfolders")
    parser.add_argument("--output", default=str(root / "output"))
    parser.add_argument("--board", choices=[*BOARD_DIRS, "ALL"], default="ALL",
                        help="One board folder or ALL populated folders")
    parser.add_argument("--workers", type=int, default=14,
                        help="Requested CAIE workers (RAM-guarded by its pipeline)")
    parser.add_argument("--jobs", type=int, default=14,
                        help="Requested universal workers (RAM-guarded by its pipeline)")
    parser.add_argument("--enable-ocr", action="store_true",
                        help="Enable optional OCR for scanned non-CAIE papers")
    parser.add_argument("--prune-stale-dirs", action="store_true",
                        help="Remove empty stale output directories in universal runs")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show the selected board folders and commands without running")
    args = parser.parse_args()

    input_root = Path(args.input).expanduser().resolve()
    output_dir = Path(args.output).expanduser().resolve()
    if not input_root.is_dir():
        print(f"[ERROR] Input root does not exist: {input_root}")
        return 1

    requested = list(BOARD_DIRS) if args.board == "ALL" else [args.board]
    populated = [board for board in requested
                 if contains_pdfs(input_root / BOARD_DIRS[board])]
    if not populated:
        if args.board == "ALL":
            print("[ERROR] No PDFs found in any board folder under:", input_root)
            for folder in BOARD_DIRS.values():
                print(f"  - {input_root / folder}")
        else:
            expected = input_root / BOARD_DIRS[args.board]
            print(f"[ERROR] No {args.board} PDFs found in {expected}")
        return 1

    if args.board == "ALL":
        empty = [board for board in requested if board not in populated]
        print("[boards] Running populated folders through separate pipelines:")
        print("[boards] " + ", ".join(populated))
        if empty:
            print("[boards] Empty folders skipped: " + ", ".join(empty))

    results: list[tuple[str, int]] = []
    for board in populated:
        board_input = input_root / BOARD_DIRS[board]
        command = command_for(
            board, board_input, output_dir,
            workers=args.workers, jobs=args.jobs,
            enable_ocr=args.enable_ocr, prune_stale_dirs=args.prune_stale_dirs,
        )
        print(f"\n[{board}] Pipeline: {'Cambridge' if board == 'CAIE' else 'Universal adapter'}")
        print(f"[{board}] Input:  {board_input}")
        print(f"[{board}] Output: {output_dir}")
        if args.dry_run:
            print("[dry-run] " + " ".join(command))
            results.append((board, 0))
            continue
        code = subprocess.call(command, cwd=str(root))
        results.append((board, code))

    failures = [(board, code) for board, code in results if code not in (0, 2)]
    reviews = [board for board, code in results if code == 2]
    if failures:
        print("\n[ERROR] Failed board pipeline(s): " + ", ".join(board for board, _ in failures))
        return 1
    if reviews:
        print("\n[WARN] Review required in: " + ", ".join(reviews))
        return 2
    print("\n[OK] All selected board pipelines completed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
