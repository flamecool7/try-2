# Clean distribution contents

This shareable Topical Generator archive contains application source, configuration, tests, and text-based reports. It intentionally excludes exam-paper PDFs and derived page/question crop images, including the optional SAT calibration paper set. No QP/MS/ER papers used for the 9701/41 verification run are included.

The reference-page exclusion update is in `core/vector_first_cropper.py` and `run_guarded.py`, with a regression test in `tests/test_vector_first_reference_exclusion.py`.

The archive includes ready-to-use `input/CAIE/`, `input/AQA/`, `input/EDEXCEL/`, `input/IB/`, `input/SAT/`, and `output/` folders. Put authorized source PDFs only in their matching board folder. CAIE uses the Cambridge pipeline; AQA, Edexcel, IB, and SAT each use the universal adapter pipeline against only their own folder. Combined runs process every populated board folder sequentially; board inputs are never merged. The folders contain instructions only—no exam papers or generated page/question images are bundled.

The optional SAT holdout audit script remains in `tools/`, but its official PDF inputs are not bundled; provide those locally if you choose to rerun that audit.
