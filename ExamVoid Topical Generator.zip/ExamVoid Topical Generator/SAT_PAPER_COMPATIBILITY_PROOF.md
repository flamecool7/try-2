# Official SAT paper-layout compatibility proof

**Result:** the current SAT runtime processed all eight official College Board question-paper PDFs for Practice Tests 4–11. After one real-paper parser fix, each paper produced **four modules and 120/120 sequential question segments**, with 120 distinct question IDs within that test.

## Test method and structural criteria

The check used the project’s real SAT adapter selected through the adapter registry, `build_document_context()` on each downloaded PDF, `Adapter._module_ranges()`, `Adapter.segment()`, and `classify_segments()`. This was not a synthetic-only check.

For each source paper, the pass criteria were:

1. Detect R&W Module 1 and 2, then Math Module 1 and 2.
2. Match the printed module counts: 33, 33, 27, and 27 questions.
3. Segment every module’s local question sequence from Q1 to its declared final question, with no gaps or duplicates.
4. Produce 120 segments and 120 distinct IDs for the paper.

## Official-paper results

Page ranges are one-based PDF pages. `Module-first` means the heading is printed as “Module N” before the section title; `Section-first` means the section title/count precedes “Module N.”

| Practice test | PDF pages | Heading layout | R&W M1 | R&W M2 | Math M1 | Math M2 | Segments / distinct IDs | Sequence check |
|---:|---:|---|---|---|---|---|---:|---|
| 4 | 56 | Module-first | 4–17 (33) | 18–31 (33) | 32–39 (27) | 40–56 (27) | 120 / 120 | Pass |
| 5 | 56 | Module-first | 4–17 (33) | 18–31 (33) | 32–41 (27) | 42–56 (27) | 120 / 120 | Pass |
| 6 | 56 | Module-first | 4–17 (33) | 18–31 (33) | 32–43 (27) | 44–56 (27) | 120 / 120 | Pass |
| 7 | 56 | Module-first | 4–19 (33) | 20–31 (33) | 32–41 (27) | 42–56 (27) | 120 / 120 | Pass |
| 8 | 56 | Module-first | 4–17 (33) | 18–31 (33) | 32–41 (27) | 42–56 (27) | 120 / 120 | Pass |
| 9 | 56 | Module-first | 4–17 (33) | 18–31 (33) | 32–39 (27) | 40–56 (27) | 120 / 120 | Pass |
| 10 | 56 | Module-first | 4–17 (33) | 18–31 (33) | 32–43 (27) | 44–56 (27) | 120 / 120 | Pass |
| 11 | 52 | Section-first | 4–17 (33) | 18–31 (33) | 32–41 (27) | 42–52 (27) | 120 / 120 | Pass |

**Aggregate:** 8/8 papers passed structural checks; 32/32 modules matched their declared counts; 960 question segments were emitted across the eight papers. Tests 4–10 exercise the module-first layout and Test 11 exercises the section-first layout.

## Real-paper defect found and fixed

Practice Test 9’s Q1 and Q2 markers are encoded in the PDF text layer as decorated spans (`. 1 ,` and `. 2 , ________`) rather than standalone digits or dash-only tabs. The old marker regex missed those two markers; because the module segmenter requires a sequential start, that caused it to suppress the rest of R&W Module 2 as well.

The runtime regex in `adapters/sat/adapter.py` now accepts comma decoration around a question number while still rejecting ordinary text/equations. Regression assertions were added to `tests/test_sat_classification_golden.py`. Re-running the actual Test 9 PDF after the fix recovered Q1–Q33 and brought that paper to 120/120. This is direct evidence of a defect exposed and corrected by the real-paper compatibility run.

## Classification output (coverage only, not accuracy)

The same runtime call produced the following classification statuses. These counts report auto-hint versus review routing only; they **do not measure correctness** because the question domains were not independently labeled for this audit.

| Practice test | HINT | REVIEW_REQUIRED |
|---:|---:|---:|
| 4 | 119 | 1 |
| 5 | 114 | 6 |
| 6 | 104 | 16 |
| 7 | 103 | 17 |
| 8 | 120 | 0 |
| 9 | 102 | 18 |
| 10 | 99 | 21 |
| 11 | 117 | 3 |

Tests 8 and 11 were previously used in classification tuning/calibration; those HINT rates are not independent validation. This proof’s acceptance result is segmentation compatibility, not classification accuracy.

## Source and verification records

The eight official URLs, HTTP status, byte sizes, and full SHA-256 hashes are in [`SAT_PAPER_COMPATIBILITY_AUDIT.json`](SAT_PAPER_COMPATIBILITY_AUDIT.json). Each download returned HTTP 200 and passed the PDF signature check. Total downloaded size: **37,166,051 bytes (37.17 MB; 35.44 MiB)**. The PDFs and any derived question crops are not included in the project or its distribution.

## Crop-image evidence

A separate visual pack is available as [`SAT_CROP_VISUAL_PROOF.pdf`](/home/user/SAT_CROP_VISUAL_PROOF.pdf), with its sample metadata in [`SAT_CROP_VISUAL_PROOF_INDEX.csv`](/home/user/SAT_CROP_VISUAL_PROOF_INDEX.csv). It contains 42 crops rendered through the same `adapters.segment_geometry.render_segment()` path used by the runtime: one Q1 sample for each of the 32 paper/module combinations, the Test 9 R&W Module 2 Q1–Q3 marker sequence, and each module’s final question from Tests 4 and 11. The visual review also exposed the empty-tail issue: the long SAT column divider was being treated as question ink. The shared render path now detects and removes only the narrow repeated dotted/vector gutter stroke on either side of the SAT columns, so the existing gold cropper can trim to the question. Ordinary solid graph axes are left intact. Every displayed crop measured **2280 px wide with the expected 20 px top white band**. This is a representative visual sample pack; the structural audit above covers every one of the 960 segments.

Regression verification after the parser change:

- SAT golden/regression file: **12 passed**.
- Full project test suite after crop-whitespace cleanup: **154 passed**, with 5 deprecation warnings.
