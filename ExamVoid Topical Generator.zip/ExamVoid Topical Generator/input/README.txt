INPUT FOLDER LAYOUT

Sort papers into the correct, board-specific subfolder:
  CAIE/       Cambridge International papers
  AQA/        AQA papers
  EDEXCEL/    Pearson Edexcel papers
  IB/         International Baccalaureate papers
  SAT/        SAT papers

Each folder has its own README. Keep a paper's question paper (QP), mark
scheme (MS), insert, and examiner report (ER) together in the matching folder.
Do not mix board families. The combined run processes each populated folder
separately through its board's appropriate pipeline.

No exam-paper PDFs are bundled; add your own authorized files before running.
