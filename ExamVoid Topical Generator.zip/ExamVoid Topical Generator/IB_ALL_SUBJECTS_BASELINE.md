# IB DP — all-subject catalogue and validation baseline

**Last updated:** 2026-10-12

## Outcome

The catalogue mismatch has been reconciled and the current-course topic maps are being kept distinct from legacy versions where the guide changed. `subjects.json` has **30 canonical IB DP profile rows**, one per config in `subjects_ib/DP/`, instead of 26 rows that represented 13 profiled subjects twice and omitted 17 configs.

- **13 existing subjects** retain their `SUPPORTED` status and profile details.
- **17 newly registered configs** remain `PROFILE_UNVALIDATED`; their existence does not establish official topic or PDF-runtime coverage.
- The 13 old taxonomy-only codes are preserved as `aliases` on canonical profile rows. Their old taxonomy paths are retained only as legacy references and are not advertised as active taxonomies.
- `subjects.json` totals are **30 IB / 169 overall**; non-IB rows were preserved.
- `tools/generate_subjects_catalogue.py --check` reports the catalogue is in sync.

The 17 initially unvalidated configs are Classical Languages (Latin), Computer Science, Dance, Design Technology, Environmental Systems and Societies, Film, Global Politics, Language B French, Language B Spanish, Literature and Performance, Music, Philosophy, Social and Cultural Anthropology, Sports, Exercise and Health Science, Theatre, Visual Arts and World Religions.

## Implementation and existing tests

- Added `tools/generate_subjects_catalogue.py`, referenced by the UI. It rebuilds IB rows from the existing profile configs, preserves other boards verbatim, checks profile/alias collisions, and supports `--check`.
- Updated the topical-index and subject-detection catalogue readers to resolve aliases to canonical profile rows.
- Replaced the booklet-builder's stale hard-coded catalogue total with the live count.
- Added regression tests for one-row-per-profile coverage, alias resolution, non-IB preservation and profile/topic presence.
- A taxonomy-derived runtime smoke audit sampled **all 554 root-profile topic keys**: 554/554 returned HINTs and selected the source profile's expected topic, with zero review cases or execution errors. This is a **self-consistency check only**: each synthetic prompt was built from the profile it tests. Per-topic detail is in `reports/ib_profile_consistency_audit.json` and `.csv`; reproduce with `python tools/audit_ib_profile_consistency.py`.
- Full project suite: **162 passed, deprecation warnings only** after the current version-routing, current-profile crosswalk, catalogue, ER identity-guard, and current Biology markscheme-table parser changes.

## Official-source reconciliation and runtime diagnostic

`IB_OFFICIAL_SUBJECT_VALIDATION.md` now records:

- **30/30** profile names reconciled to the IBO 2026 *All DP subjects* list, with level and History caveats.
- **16 explicit version-route files:** the 14 repository rows across 13 IBO update-cycle streams (first assessment 2026–2029), plus separate legacy/new-cohort routes for Classical Languages (2024) and Philosophy (2025). Anthropology, Music, Theatre and Film have updated current-course root topic maps and first-assessment metadata. The scheduled streams are ESS, Global Politics, SEHS, Computer Science, Design Technology, Psychology, Visual Arts, History, Dance, Language B French/Spanish, Mathematics AA/AI, and Religion and Society replacing World Religions. Version/cohort fit is separate from catalogue identity.
- The official-source diagnostic now has **48 prompt/task-text probes across 25/30 profiles**: **30 HINT, 18 REVIEW_REQUIRED, 0 errors**. The provisional manually assigned topic matched top-1 in 22 cases. This is not an accuracy estimate: labels are provisional, multi-topic prompts are reduced to one manual label, and several profiles have sparse or no official sample text.
- Five profiles remain without text probes in this pass: Dance, ESS, Music, Theatre and Visual Arts. Their assessment/source characteristics differ; practical/portfolio evidence or current official paper material is needed.
- **Real QP/MS pipeline evidence added 2026-10-12:** a May 2025 Biology HL Paper 2 TZ1 QP and its exact matching MS from the authorized XtremePapers archive were bundled under `IB|IBBI/P2|May|2025`. The runtime emitted 10 QP question segments (12 crops) and 10 MS question crops; all passed the width/top-band contract, pack assembly reported 10 packs and zero review items, and the full suite passed 162 tests. The current table-style MS format required and now has a production parser fix plus a regression test. No matching ER was listed for that session directory; it was not replaced by another paper's report. This is one QP/MS-only paper, not full QP/MS/ER or all-profile PDF validation. Direct IBO downloads remain blocked with HTTP 403.

Reproduce the current official-source sample audit with `python tools/audit_ib_official_samples.py`. Outputs: `reports/ib_official_sample_audit.json` and `.csv`. Do not promote all-subject IB runtime coverage based on catalogue reconciliation, the 48 prompts, or the 554 self-consistency cases.

The earlier Math AA runtime changes and limited 2021 specimen-text diagnostic are recorded in `IB_MATH_AA_FIRST_PASS.md`; they do not establish coverage of other profiles or the 2029 AA course.

## Next stage

1. Expand beyond the one Biology HL Paper 2 QP/MS pair using authorized subject/version bundles. Direct IBO PDF retrieval remains blocked (HTTP 403); use only sources covered by the user's confirmed permission, and obtain a matching ER where the archive actually publishes one.
2. Continue with independent prompt-topic adjudication and a non-tuned holdout. The 48-case diagnostic and 554 profile-derived self-consistency probes are not accuracy evidence.
3. Obtain authorized official QP/MS/ER bundles for all available profiles and course versions. Process each subject in isolation, with its ER alongside that same subject's QP/MS; never attach an ER to another subject.
4. Inspect official question segmentation and page crops; independently review expected topics; report per-version coverage, false hints, review rate and execution errors. Keep `PROFILE_UNVALIDATED` rows unpromoted until official PDF processing, independent labels, crop review and bundle isolation pass.
