#!/usr/bin/env python3
"""One command: decide, then run the crop batch as fast as this box allows.

Wraps the project's own RAM-guarded parallel runner (core/batch_runner) with the
one decision you should not have to make by hand:

    switch to the parallel runner, or finish what run_guarded.py started?

That decision matters because the two runners do NOT share state
(.pipeline_state.json vs pipeline.sqlite) -- the batch runner reports
"Completed: 0" even when pointed at an output tree full of finished question
folders. Switching mid-run therefore redoes finished work. At 14 workers a full
redo is ~2.8 h, so it is cheap early and expensive late.

Logic
------
  1. Read <output>/.pipeline_state.json -> how much is already complete.
  2. workers = min(nproc, RAM-guard limit)   [RAM guard: 1100 MB/worker + 400 MB]
  3. <= 80 % complete  -> one parallel run over everything (redo is cheap).
     >  80 % complete  -> one parallel run per UNFINISHED syllabus code,
                          sequentially, so finished subjects are never touched.
  4. Print the plan. Nothing runs without --go.

Usage
-----
    python3 start_fast.py --output ./output            # show the plan
    python3 start_fast.py --output ./output --go       # actually run it
    python3 start_fast.py --output ./output --go --workers 8   # override
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = None
for _cand in (HERE, *HERE.parents):
    if (_cand / "core" / "batch_runner.py").is_file():
        REPO = _cand
        break
if REPO is None:  # shallow search as a last resort
    for _hit in HERE.rglob("core/batch_runner.py"):
        REPO = _hit.parent.parent
        break
if REPO is None:
    sys.exit(f"[fatal] could not locate core/batch_runner.py near {HERE}")
sys.path.insert(0, str(REPO))

try:                                    # same folder as this script
    sys.path.insert(0, str(HERE))
    from fastcheck import load_rate, save_rate, sec_per_paper
except Exception:                       # pragma: no cover - keep working anyway
    def load_rate(_o):
        return None

    def save_rate(_o, *_a, **_k):
        return None

    def sec_per_paper(_o):
        return 70.0

SWITCH_THRESHOLD = 0.80          # above this, do not redo finished work
PAPERS = 2000                    # only used if the input folder cannot be read


def count_input_pdfs(input_dir) -> dict:
    """-> {"pdfs","qps","mss","others"} actually present in the input folder."""
    d = Path(input_dir)
    if not d.is_dir():
        return {"pdfs": 0, "qps": 0, "mss": 0, "others": 0}
    pdfs = qps = mss = others = 0
    for p in d.rglob("*"):
        if not p.is_file() or p.suffix.lower() != ".pdf":
            continue
        pdfs += 1
        low = p.name.lower()
        if "_qp_" in low:
            qps += 1
        elif "_ms_" in low:
            mss += 1
        else:
            others += 1
    return {"pdfs": pdfs, "qps": qps, "mss": mss, "others": others}


def read_progress(output: Path):
    """-> (total, complete, unfinished_codes) from run_guarded's state file."""
    sf = output / ".pipeline_state.json"
    if not sf.exists():
        return 0, 0, []
    try:
        papers = (json.loads(sf.read_text(encoding="utf-8")) or {}).get("papers", {}) or {}
    except Exception:
        return 0, 0, []
    done = unfinished = 0
    codes: dict[str, int] = {}
    for key, rec in papers.items():
        status = str((rec or {}).get("status", "?")).lower()
        if status == "complete":
            done += 1
        else:
            unfinished += 1
            code = str(key).split("_")[0]
            codes[code] = codes.get(code, 0) + 1
    return done + unfinished, done, sorted(codes.items())


def worker_budget(requested=None):
    """-> (workers, avail_mb, reasons) using the project's own RAM guard."""
    from core.batch_runner import (PARENT_RESERVE_MB, PER_WORKER_PEAK_MB,
                                   _auto_worker_request, available_mem_mb,
                                   guard_decision)
    avail = available_mem_mb()
    auto_raw = _auto_worker_request()
    want = requested if requested is not None else auto_raw
    conc, reasons = guard_decision(want, avail)
    cores = os.cpu_count() or want
    final = min(conc, cores) if requested is None else conc
    return final, avail, reasons, cores, PER_WORKER_PEAK_MB, PARENT_RESERVE_MB, auto_raw


class _Heartbeat:
    """Print a liveness line every N seconds while a long silent stage runs.

    The preflight identifies every input PDF before printing anything, which on
    a 2239-file folder is 30-95 seconds of total silence. That is
    indistinguishable from a hang from the outside.
    """

    def __init__(self, every=15.0, prefix="  [alive]"):
        self.every = every
        self.prefix = prefix
        self._stop = threading.Event()
        self._t0 = time.time()
        self._thread = None

    def _run(self):
        while not self._stop.wait(self.every):
            el = time.time() - self._t0
            print(f"{self.prefix} {el:6.0f}s elapsed - still working "
                  f"(identifying PDFs, this is normal)", flush=True)

    def __enter__(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)
        print(f"  [alive] finished in {time.time() - self._t0:.0f}s", flush=True)
        return False


def _completed(output) -> int:
    """Bundles the state file marks complete - used to measure the real rate."""
    sf = Path(output) / ".pipeline_state.json"
    if not sf.exists():
        return 0
    try:
        papers = (json.loads(sf.read_text(encoding="utf-8")) or {}).get("papers", {}) or {}
    except Exception:
        return 0
    return sum(1 for v in papers.values()
               if str((v or {}).get("status", "?")).lower() == "complete")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", "-i", default=str(REPO / "input"))
    ap.add_argument("--output", "-o", default=str(REPO / "output"))
    ap.add_argument("--workers", "-w", type=int, default=None,
                    help="override the computed worker count (default: min(auto, cores))")
    ap.add_argument("--go", action="store_true",
                    help="actually launch. Without it this only prints the plan.")
    ap.add_argument("--pause", action="store_true",
                    help="wait for Enter before exiting (so a double-clicked window "
                         "does not flash shut before you can read/copy the output)")
    ap.add_argument("--min-workers", type=int, default=0,
                    help="OPT-IN safety gate: refuse to start below this many "
                         "workers without typing YES. Default 0 = never block, "
                         "only warn. Set 4 if you would rather stop than run "
                         "slow: at 1 worker a 358-bundle run is ~7 h.")
    ap.add_argument("--yes", action="store_true",
                    help="skip the low-worker confirmation prompt")
    ap.add_argument("--dry-run", action="store_true",
                    help="show the plan and the exact command, then stop - "
                         "nothing is processed")
    args = ap.parse_args()

    out = Path(args.output)
    inp = Path(args.input)
    (workers, avail, reasons, cores, per_worker, reserve,
     auto_raw) = worker_budget(args.workers)

    total, done, unfinished = read_progress(out)
    found = count_input_pdfs(inp)
    frac = (done / total) if total else 0.0

    print("=" * 68)
    print("PLAN")
    print("=" * 68)
    print(f"  input              : {inp}")
    print(f"  pdfs in input      : {found['pdfs']} "
          f"({found['qps']} QP, {found['mss']} MS, {found['others']} other)")
    print(f"  output             : {out}")
    print(f"  cores              : {cores}")
    print(f"  MemAvailable       : {avail} MB")
    print(f"  worker budget      : {per_worker} MB/worker + {reserve} MB reserve")
    print(f"  workers to use     : {workers}"
          + ("" if args.workers else "  (auto)"))
    for r in reasons:
        print(f"    - {r}")
    if args.workers is None and auto_raw < cores:
        print(f"    ! auto request ({auto_raw}) is below your core count ({cores}).")
        print(f"      Pass --workers {cores} to use the whole machine.")
    if args.workers is not None and workers < args.workers:
        if workers < args.min_workers:
            # A big clamp is a real problem - make it impossible to miss.
            print()
            print("  " + "#" * 62)
            print(f"  #  RAM GUARD CLAMPED YOU: asked for {args.workers}, got {workers}")
            print("  #" + " " * 62)
            print(f"  #  MemAvailable seen : {avail} MB")
            print(f"  #  budget            : {per_worker} MB/worker + {reserve} MB reserve")
            print(f"  #  -> ({avail} - {reserve}) // {per_worker} = "
                  f"{max(1, (avail - reserve) // per_worker) if avail else '?'} worker(s)")
            print("  #")
            print("  #  This is not a bug. Something else is holding your RAM.")
            print("  #  Usually: an old run_guarded.py window still open, a browser,")
            print("  #  or another copy of this script. Close them and re-run.")
            print("  #" + " " * 62)
        else:
            # A small clamp is just honest budgeting - say so and move on.
            print(f"    note: asked for {args.workers} workers, RAM guard granted "
                  f"{workers} (MemAvailable {avail} MB). That is the correct number.")
    if workers > cores:
        print(f"    ! refusing to exceed {cores} cores: oversubscription slows this down.")
    if workers <= 2 and found and found.get("qps", 0) > 20:
        print(f"    ! Only {workers} worker(s) - this will take about "
              f"{found['qps'] * sec_per_paper(out) / max(1, workers) / 3600:.1f} h.")
        print(f"      It IS running. Free RAM and re-run to go faster.")

    # Opt-in gate. Default off: a blocked prompt looks exactly like the
    # "nothing is happening" bug this pack exists to fix, so we warn and run.
    if args.min_workers and workers < args.min_workers and not args.yes:
        print()
        print("  " + "!" * 62)
        print(f"  !  ONLY {workers} WORKER(S) - ETA is roughly "
              f"{found['qps'] * sec_per_paper(out) / max(1, workers) / 3600:.1f} h")
        print("  !  You asked for a fast run. This is not one.")
        print("  !" + " " * 61)
        print("  !  Fix: close everything else, then run  python memcheck.py")
        print("  !  You want MemAvailable above ~12000 MB for 10+ workers.")
        print("  !" + " " * 61)
        print("  !  Type YES (capitals) to run anyway at this slow rate,")
        print("  !  or anything else to abort.")
        print("  " + "!" * 62)
        try:
            if input("  > ").strip() != "YES":
                print("  aborted - nothing was processed.")
                return 0
        except (EOFError, KeyboardInterrupt):
            print("  aborted - nothing was processed.")
            return 0
        print("  continuing at the slow rate, as requested.")

    if total == 0:
        print(f"  prior state        : none found - fresh run")
        print(f"  mode               : PARALLEL, everything")
        print(f"  ETA                : ~{found['qps'] * sec_per_paper(out) / workers / 3600:.1f} h"
              f"  ({found['qps']} QP bundle(s) found in input)")
        plan = [("all", None)]
    else:
        print(f"  prior state        : {done}/{total} complete ({frac:.0%})")
        if frac > SWITCH_THRESHOLD and unfinished:
            print(f"  mode               : PARALLEL, unfinished subjects only "
                  f"({len(unfinished)} subject(s))")
            print(f"                      finished work will NOT be redone")
            eta_left = sum(n for _, n in unfinished)
            print(f"  ETA                : ~{eta_left * sec_per_paper(out) / workers / 3600:.1f} h"
                  f"  ({eta_left} bundle(s) left; {found['qps']} QP in input)")
            plan = [(f"{code} ({n} bundle(s))", code) for code, n in unfinished]
        else:
            print(f"  mode               : PARALLEL, everything")
            print(f"  WARNING            : switching redoes the {done} already-complete "
                  f"bundle(s)")
            _scope = found['qps'] or total or PAPERS
            _r = sec_per_paper(out)
            print(f"  ETA                : ~{_scope * _r / workers / 3600:.1f} h"
                  f"  (redo cost ~{done * _r / workers / 3600:.1f} h)")
            plan = [("all", None)]

    print()
    print("  jobs to launch:")
    for label, code in plan:
        cmd = ["python3", "run_parallel.py", "--input", str(inp),
               "--output", str(out), "--workers", str(workers)]
        if code:
            cmd += ["--syllabus-code", code]
        print(f"    {' '.join(cmd)}    # {label}")

    if not args.go:
        print()
        print("  DRY PLAN ONLY - re-run with --go to launch.")

    if args.pause:
        try:
            input("\n[press Enter to close this window] ")
        except (EOFError, KeyboardInterrupt):
            pass
    if not args.go:
        return 0

    if args.dry_run:
        print()
        print("  (dry run - nothing will be processed)")
        return 0

    print()
    print("=" * 68)
    print("RUNNING")
    print("=" * 68)
    print("  NOTE: the first ~1-2 minutes are silent while every PDF is")
    print("  identified. [alive] lines below mean it is working, not stuck.")
    print("  A [OK] <paper> line appears as each paper finishes.")
    failures = []
    for label, code in plan:
        cmd = [sys.executable, "-u", str(HERE / "run_parallel.py"),
               "--input", str(inp), "--output", str(out),
               "--workers", str(workers)]
        if code:
            cmd += ["--syllabus-code", code]
        before = _completed(out)
        print(f"\n[start_fast] === {label} ===", flush=True)
        t0 = time.time()
        with _Heartbeat(every=15.0):
            rc = subprocess.call(cmd)
        dt = time.time() - t0
        newly = max(0, _completed(out) - before)
        if rc == 0 and newly > 0:
            rate = dt / newly
            save_rate(out, rate, newly, workers)
            print(f"[start_fast] measured {rate:.1f}s per paper on this box "
                  f"({newly} papers in {dt / 60:.1f}m) - saved for next time")
        print(f"[start_fast] {label} finished rc={rc} in {dt:.0f}s")
        if rc != 0:
            failures.append((label, rc))
    if failures:
        print(f"\n[start_fast] {len(failures)} job(s) failed: {failures}")
        return 1
    print("\n[start_fast] all jobs finished.")

    if args.pause:
        try:
            input("[press Enter to close this window] ")
        except (EOFError, KeyboardInterrupt):
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
