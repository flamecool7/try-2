# Digital SAT classification: runtime, calibration, and holdout audit

## Current work status — 2026-10-12

### SAT Practice Test 11 format and calibration work

The official College Board paper-format Practice Test 11 uses a different module-heading order from the earlier PDFs and inserts answer-entry directions before some Math question pages. The SAT adapter now tracks section context across those pages, recognizes section-first headings, ignores the timing schedule on the back page, and excludes answer-entry instructions from question-marker candidates. It segments the real 120-question Test 11 PDF into the correct 33/33 Reading and Writing and 27/27 Math module sequences. Two phantom Q1 crops from the instruction pages are prevented.

The SAT classifier now has narrow runtime rules for explicit main-topic/evidence prompts and clear Math families that the shared scorer previously left for review or misrouted: geometry relations, equations/inequalities, exponential models, percentage/data questions, and unit conversions. These are production-path changes in `adapters/sat/classification.py`, not test-only patches. Ambiguous plot/function prompts remain review-required.

Test 11 calibration audit: **117/120 HINTs (97.5% coverage), 117/117 exact broad-domain matches among HINTs, and 3 REVIEW_REQUIRED** (RWM2Q16, MATHM1Q23, MATHM2Q19). Labels are manual taxonomy crosswalks, not College Board item-level tags. The official answer explanations were accessed and these labels were used during calibration, so the result is **in-sample only**, not independent validation or a general accuracy guarantee. The calibration label fixture is `tests/fixtures/sat_practice_test_11_domain_calibration_labels.json`; source PDFs were not retained in the cleaned workspace.

**Holdout status:** Practice Test 10's previously reported 94/120 coverage and 89/94 match rate describe the earlier classifier version. Those metrics predate the current rules; its known error patterns have since been considered, so do not present Test 10 as an untouched holdout for the current runtime. A fresh, unused paper is still needed for independent post-change validation.

SAT regression tests: **12 passed**. Full project suite after these changes: **151 passed, 5 deprecation warnings**.

## Runtime behavior

- The SAT adapter segments Reading and Writing and Math into module-aware records. Tests 4–10 segment all 120 questions in the audited PDFs.
- SAT questions use the production SAT-specific broad-domain classifier and skill tagger in `adapters/sat/classification.py`, with the College Board profiles in `subjects_sat/Digital_SAT/`.
- Outputs remain advisory: a question is either a `HINT` or `REVIEW_REQUIRED`; individual skill hints are separately tagged. A HINT is not a guarantee.
- Classification reads the PDF text layer, not OCR. The SAT runtime now also uses existing page-layout bboxes to recognize small raised exponents, which helps distinguish a baseline linear form such as `6x` from a power such as `x^3` when text order is ambiguous.

## What changed after the first Practice Test 8 run

Practice Test 8 first produced **94 automatic domain HINTs, 26 reviews, and 2 incorrect HINTs**. I used its official answer explanations to tune the runtime: expanded discriminating cues for common Reading and Writing evidence/synthesis tasks and Math equations, percentages, functions, geometry, and systems; added the layout-based exponent signal and a system-of-equations skill priority. The two original domain errors (MATHM1Q20 and MATHM2Q6) and the skill error (MATHM2Q11) are corrected in the calibrated Test 8 run.

**Test 8 is now calibration data, not an independent holdout.** Its post-tuning 120/120 agreement is in-sample and must not be represented as a general accuracy guarantee. Practice Tests 6 and 7 were also calibration data.

## Results

Labels are manual crosswalks from question stems and official answer-explanation rationales to the College Board taxonomy. College Board does not publish per-question domain/skill tags for these PDFs.

| Dataset | Role | Questions | Automatic domain HINTs | Exact matches among HINTs | Interpretation |
|---|---|---:|---:|---:|---|
| College Board sample | In-sample smoke test | 33 | 33/33 | 33/33 | Small development sample; skill layer 32/33 under the documented legacy-label allowance. |
| Practice Test 4 | Coverage check | 120 | 117/120 (97.5%) | Not independently labeled | Coverage only. |
| Practice Test 5 | Coverage check | 120 | 114/120 (95.0%) | Not independently labeled | Coverage only. |
| Practice Test 6 | Calibration | 120 | 99/120 (82.5%) | 97/99 (98.0%) | Two incorrect HINTs; not an independent estimate. |
| Practice Test 7 | Calibration | 120 | 97/120 (80.8%) | 95/97 (97.9%) | Two incorrect HINTs; explanations informed prior rule work. |
| Practice Test 8 | **Calibration after tuning** | 120 | **120/120 (100%)** | **120/120 (100%)** | In-sample only; all 26 prior review items were assigned, and both prior domain errors were corrected. |
| Practice Test 10 | **Independent holdout** | 120 | **94/120 (78.3%)** | **89/94 (94.7%)** | Predictions were saved before reviewing its official answer explanations; no tuning used its labels. |

On the Test 10 holdout, Reading and Writing produced 60 HINTs, all correct; Math produced 34 HINTs, 29 correct. There were 26 review cases and five incorrect automatic HINTs, all in Math:

- MATHM1Q3: linear cost inequality; predicted PSDA, labeled Algebra.
- MATHM1Q5: linear speed function; predicted PSDA, labeled Algebra.
- MATHM1Q12: decreasing linear function; predicted Advanced Math, labeled Algebra.
- MATHM1Q23: circle equation; predicted Advanced Math, labeled Geometry and Trigonometry.
- MATHM2Q18: exponential function; predicted Algebra, labeled Advanced Math.

The five mistakes are left unchanged so Test 10 remains an honest holdout. They show the remaining Math-domain calibration risk.

### Skill layer

On Practice Test 8, the calibrated run matched **54/54** expected skill labels among the 54 questions with automatic skill HINTs. This is an in-sample calibration result, not an independent skill-accuracy estimate. The previous MATHM2Q11 skill error was corrected by prioritizing the “system of two linear equations” skill over the generic “value of x” cue. Practice Test 10 was not used for skill tuning or scored for skill accuracy.

## Reproducible artifacts

- Test 8 calibration labels: `tests/fixtures/sat_practice_test_8_domain_calibration_labels.json`
- Test 8 calibration audit: `reports/sat_practice_test_8_calibration_audit.csv` and `.json`
- Test 10 independent holdout labels: `tests/fixtures/sat_practice_test_10_domain_holdout_labels.json`
- Test 10 item-level and aggregate holdout audit: `reports/sat_practice_test_10_holdout_audit.csv` and `.json`
- Test 6 and Test 7 calibration labels/reports: `tests/fixtures/sat_practice_test_6_domain_holdout_labels.json`, `tests/fixtures/sat_practice_test_7_domain_calibration_labels.json`, and matching `reports/sat_practice_test_{6,7}_calibration_audit.*` files.
- Official QP and answer PDFs are optional local calibration inputs; they are intentionally excluded from the clean redistribution ZIP. Supply them locally under `data/sat_calibration/` only when rerunning the SAT holdout audit.

Run the current independent holdout audit from the project root:

```bash
python tools/audit_sat_domain_holdout.py \
  --qp data/sat_calibration/sat-practice-test-10-digital.pdf \
  --labels tests/fixtures/sat_practice_test_10_domain_holdout_labels.json \
  --csv reports/sat_practice_test_10_holdout_audit.csv \
  --json reports/sat_practice_test_10_holdout_audit.json
```

## Tests and limitations

```bash
python -m pytest -q tests/test_sat_classification_golden.py
python -m pytest -q
```

The latest full suite passed **118 tests**, with 5 deprecation warnings. These static-PDF results do not cover every SAT question, all formula layouts, OCR, or future taxonomy changes. Test 10's 94.7% HINT accuracy on a single test is an observed sample result—not a probability guarantee for a future full paper. Keep review fallback for genuinely ambiguous formulas and continue validating new rules on a fresh untouched paper.
