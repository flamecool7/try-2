"""IB Mathematics AA runtime checks using official IBO specimen text.

The official specimen PDF is indexed by IBO/search, but its binary is blocked
from this workspace. These checks cover text identity and topic-classifier
smoke behavior only; they do not validate rendered PDF crops or markscheme
geometry.
"""
from adapters.base import DocumentContext
from adapters.ib.adapter import Adapter
from adapters.ib.classification import _stub, classify_text, load_profile


SPECIMEN_URL = (
    "https://ibo.org/globalassets/new-structure/university-admission/pdfs/"
    "dp-mathematics-analysis-and-approaches-specimen-papers-en.pdf"
)


def _ctx(text: str, *, name: str = "maa-hl-p1.txt") -> DocumentContext:
    return DocumentContext(
        path=name,
        filename=name,
        stem=name.rsplit(".", 1)[0],
        suffix="." + name.rsplit(".", 1)[-1],
        first_page_text=text[:1200],
        full_text=text,
        source_url=SPECIMEN_URL,
    )


def _single_paper_text() -> str:
    return """International Baccalaureate
Mathematics: analysis and approaches
Higher level
Paper 1
Specimen paper
SPEC/5/MATAA/HP1/ENG/TZ0/XX
Instructions to candidates
Answer all questions.
1. [Maximum mark: 5]
Find the derivative of the function.
"""


def test_ib_math_aa_subject_and_native_component_identity():
    adapter = Adapter()
    ctx = _ctx(_single_paper_text())

    subject = adapter.identify_subject(ctx)
    assert any(e.field == "subject" and e.value == "Mathematics: analysis and approaches" for e in subject)
    assert any(e.field == "subject_code" and e.value == "IBMA" for e in subject)

    labels = adapter._segment_identity(ctx)
    assert labels["subject_code"] == "IBMA"
    assert labels["component"] == "P1"
    assert labels["paper_number"] == "1"
    assert labels["level"] == "HL"
    assert labels["timezone"] == "TZ0"
    assert labels["session"] == "SPECIMEN"


def test_text_only_ib_segments_use_document_identity_not_english_a_defaults():
    segments = Adapter().segment(_ctx(_single_paper_text()))

    assert len(segments) == 1
    seg = segments[0]
    assert seg["id"] == "IB_IBMA_P1_Q1"
    assert seg["component"] == "P1"
    assert seg["text_only"] is True
    assert seg["pages"] == []
    assert seg["metadata"]["renderable"] is False
    assert seg["metadata"]["ib_subject_code"] == "IBMA"
    assert seg["metadata"]["ib_level"] == "HL"
    assert seg["metadata"]["ib_spec_code"] == "SPEC/5/MATAA/HP1/ENG/TZ0/XX"
    assert "EnglishA" not in seg["id"]
    assert "official IBO extracted text" in seg["metadata"]["source"]


def test_combined_or_ambiguous_ib_papers_fail_closed_instead_of_cross_labeling():
    adapter = Adapter()
    mixed_qp_ms = _single_paper_text() + "\nMarkscheme\nSPEC/5/MATAA/HP1/ENG/TZ0/XX/M\n1. A1 [1]\n"
    assert adapter.segment(_ctx(mixed_qp_ms, name="mixed.txt")) == []

    mixed_components = _single_paper_text() + "\nSPEC/5/MATAA/HP2/ENG/TZ0/XX\nPaper 2\n2. [Maximum mark: 5]\n"
    assert adapter.segment(_ctx(mixed_components, name="combined.txt")) == []


def test_ib_classifier_normalizes_ib_paper_codes_without_empty_math_variant():
    assert _stub("x", "Q3", "P2").variant == "2"
    assert _stub("x", 3, "IBMA/2").variant == "2"
    assert _stub("x", 3, "SPEC/5/MATAA/HP2/ENG/TZ0/XX").variant == "2"
    assert _stub("x", "Q3", "P2").number_int == 3


def test_ib_math_aa_specimen_classification_smoke():
    config, classifier = load_profile("IBMA")
    assert config is not None and classifier is not None
    assert config.subject == "IB_IBMA"  # bypasses Cambridge-only math component labels

    financial = classify_text(
        "IBMA",
        "On 1st January 2020, Laurie invests $P in an account that pays a nominal annual "
        "interest rate of 5.5%, compounded quarterly.",
        question_number=2,
        component="P2",
    )
    assert financial["status"] == "HINT"
    assert financial["topic"] == "T1_Financial_maths"

    complex_numbers = classify_text(
        "IBMA",
        "The complex numbers w and z satisfy w/z = 2i and z* - 3w = 5 + 5i. "
        "Find w and z in the form a + bi where a and b are integers.",
        question_number=8,
        component="P2",
    )
    assert complex_numbers["status"] == "HINT"
    assert complex_numbers["topic"] == "T1_Complex_numbers_HL"

    weighted_die = classify_text(
        "IBMA",
        "A six-sided biased die is weighted so the probability of obtaining a six is 7/10. "
        "It is tossed five times. Find the probability of at most three sixes and the third "
        "six on the fifth toss.",
        question_number=3,
        component="P2",
    )
    assert weighted_die["status"] == "HINT"
    # Current output is the broad probability node. The audit note flags the
    # narrower discrete-binomial topic as a specificity question, not a verified
    # exact-match result.
    assert weighted_die["topic"] in {"T4_Probability", "T4_Discrete_binomial"}

    combined_logs_and_trigonometry = classify_text(
        "IBMA",
        "Show that log_3(cos(2x) + 2) = log_9(cos(2x) + 2). Hence solve "
        "log_3(2 sin x) = log_9(cos(2x) + 2) for 0 < x < pi/2.",
        question_number=6,
        component="P1",
    )
    assert combined_logs_and_trigonometry["status"] in {"HINT", "REVIEW_REQUIRED"}
