from __future__ import annotations

import fitz
import pytest
from PIL import Image

from tools.build_sat_answer_companions import (
    _consistency_status,
    _question_id,
    parse_explanation_markers,
    parse_scoring_guide,
)
from tools.export_sat_caie_tree import (
    _metadata,
    _save_qp_with_exact_white_band,
    _shift_vertical_without_clipping,
)


def _synthetic_scoring_guide() -> fitz.Document:
    doc = fitz.open()
    page = doc.new_page(width=612, height=792)
    page.insert_text((45, 95), "Answer Key", fontsize=18)
    page.insert_text((45, 125), "Mark each of your correct answers below, then add them up to get your raw score on each module.", fontsize=7)
    anchors = (65.5, 154.0, 259.0, 382.2)
    for x in anchors:
        page.insert_text((x, 195), "QUESTION #", fontsize=7)
    rows = (
        ("B", "D", "9", "600"),
        ("A", "C", "361/8; 45.12; 45.13", "2"),
        ("D", "B", "5", "A"),
    )
    for qn, values in enumerate(rows, start=1):
        y = 240 + (qn - 1) * 12
        for x, answer in zip(anchors, values):
            page.insert_text((x, y), str(qn), fontsize=7)
            page.insert_text((x + 24, y), answer, fontsize=7)
    return doc


def _synthetic_explanations() -> fitz.Document:
    doc = fitz.open()
    page = doc.new_page(width=612, height=792)
    page.insert_text((57, 48), "SAT ANSWER EXPLANATIONS n READING AND WRITING: MODULE 1", fontsize=8)
    page.insert_text((57, 90), "QUESTION 1", fontsize=10)
    page.insert_text((57, 112), "Choice B is the best answer because the passage supports it.", fontsize=9)
    page.insert_text((57, 150), "QUESTION 2", fontsize=10)
    page.insert_text((57, 172), "Choice A is correct. The evidence supports this option.", fontsize=9)
    page.insert_text((57, 210), "QUESTION 3", fontsize=10)
    page.insert_text((57, 232), "The correct answer is 600.", fontsize=9)
    return doc


def test_scoring_guide_parser_keeps_module_columns_and_free_response_variants():
    doc = _synthetic_scoring_guide()
    try:
        answers, page_index = parse_scoring_guide(doc)
    finally:
        doc.close()
    assert page_index == 0
    assert len(answers) == 12
    assert answers[("RW", 1, 1)].answer == "B"
    assert answers[("RW", 2, 1)].answer == "D"
    assert answers[("MATH", 1, 2)].answer == "361/8; 45.12; 45.13"
    assert answers[("MATH", 2, 3)].answer == "A"


def test_explanation_headings_are_module_aware_and_exact():
    doc = _synthetic_explanations()
    try:
        module_pages, markers = parse_explanation_markers(doc)
    finally:
        doc.close()
    assert module_pages == {("RW", 1): [0]}
    assert [(m.section, m.module, m.question) for m in markers] == [
        ("RW", 1, 1), ("RW", 1, 2), ("RW", 1, 3)
    ]
    assert _question_id(4, "RW", 1, 1) == "SAT_T04_RW_M1_Q01"
    assert _question_id(4, "MATH", 2, 1) == "SAT_T04_MATH_M2_Q01"


def test_answer_consistency_check_handles_mcq_and_student_produced_responses():
    assert _consistency_status("B", "Choice B is the best answer. Choice A is incorrect.") == "matches_scoring_guide"
    assert _consistency_status("C", "Choice B is the best answer.") == "mismatch_with_scoring_guide"
    assert _consistency_status("168", "The correct answer is 168.") == "not_applicable_free_response"


def test_caie_style_metadata_keeps_canonical_fields_and_module_identity():
    rw = _metadata(4, "RW", 1, 1, "Craft_and_Structure")
    math = _metadata(4, "MATH", 1, 1, "Algebra")
    assert list(rw) == ["id", "level", "subject", "board", "topic", "paper", "question_number", "variant", "season", "year"]
    assert rw["level"] == "Digital_SAT"
    assert rw["subject"] == "Reading_and_Writing_SATR"
    assert rw["topic"] == ["Craft_and_Structure"]
    assert rw["paper"] == "SAT_T04_RW_M1"
    assert math["paper"] == "SAT_T04_MATH_M1"
    assert rw["id"] != math["id"]


def test_saved_sat_qp_crop_keeps_exact_white_top_band(tmp_path):
    image = Image.new("RGB", (2280, 100), "white")
    # Visible question ink starts at row 20, matching render_segment's crop contract.
    for x in range(100, 110):
        image.putpixel((x, 20), (0, 0, 0))
    output = tmp_path / "sat_qp.webp"
    _save_qp_with_exact_white_band(image, output, quality=85)
    with Image.open(output) as saved:
        saved.load()
        assert saved.size == (2280, 100)
        rgb = list(saved.convert("RGB").crop((0, 0, 2280, 20)).getdata())
        assert all(min(pixel) >= 250 for pixel in rgb)
        assert saved.getpixel((100, 20))[0] < 250
    image.close()


def test_vertical_band_calibration_only_trims_verified_white_rows():
    image = Image.new("RGB", (20, 40), "white")
    for y in range(20, 30):
        for x in range(5, 15):
            image.putpixel((x, y), (0, 0, 0))
    shifted = _shift_vertical_without_clipping(image, -3)
    assert shifted.size == (20, 37)
    assert shifted.getpixel((5, 17)) == (0, 0, 0)
    with pytest.raises(ValueError):
        _shift_vertical_without_clipping(image, -21)
    image.close()
    shifted.close()
