"""Production regressions for selective, PDF-text-aware answer-rule cleanup."""
import fitz
import numpy as np
from PIL import Image

from core import vector_first_cropper as vc
from core.dotted_rule_cleanup import (
    find_long_form_cue_y,
    is_a_level_science_p5,
    is_long_form_answer,
    plan_answer_rule_cleanup,
    remove_dotted_answer_rules,
)
from core.question_split import PageCropInfo, PageSegment, crop_page_segments


DOTS = "." * 72


def _chars_for_line(page, required_text):
    for block in page.get_text("rawdict")["blocks"]:
        for line in block.get("lines", []):
            chars = [c for span in line.get("spans", []) for c in span.get("chars", [])]
            if required_text in "".join(c.get("c", "") for c in chars):
                return chars
    raise AssertionError(f"No text line containing {required_text!r}")


def _ink_count(image, box):
    x0, y0, x1, y1 = box
    gray = np.asarray(image.convert("L"))
    return int((gray[max(0, y0):min(gray.shape[0], y1),
                     max(0, x0):min(gray.shape[1], x1)] < 210).sum())


def test_long_form_classifier_keeps_short_prompts_and_recognizes_essay_word_counts():
    assert not is_long_form_answer("Give two reasons and use your own words.")
    assert not is_long_form_answer("Your summary should not be more than 120 words.")
    assert is_long_form_answer("Write about 200 to 300 words.")
    assert is_long_form_answer("Write about 250 to 350 words.")
    assert is_long_form_answer("Compose approximately 250 words for your speech.")


def test_science_p5_identity_and_long_written_method_cues_are_narrowly_gated():
    assert is_a_level_science_p5("9700_s24_qp_52")
    assert is_a_level_science_p5("9701_w23_qp_51")
    assert is_a_level_science_p5("9702_m25_qp_53")
    assert not is_a_level_science_p5("9702_s24_qp_42")
    assert not is_a_level_science_p5("0620_s24_qp_52")

    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 120), "Plan a laboratory experiment to test this relationship.", fontsize=10)
    assert find_long_form_cue_y(page, science_p5=False) is None
    assert find_long_form_cue_y(page, science_p5=True) is not None

    method_doc = fitz.open()
    method_page = method_doc.new_page(width=595, height=842)
    method_page.insert_text((50, 120), "Your method should be set out in a logical order", fontsize=10)
    assert find_long_form_cue_y(method_page, science_p5=True) is not None
    assert find_long_form_cue_y(method_page, science_p5=False) is None


def test_science_p5_long_method_cleanup_stops_at_next_short_subpart():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 100), "(b) Describe your method.", fontsize=10)
    page.insert_text((50, 125), "Your method should be set out in a logical order and be detailed enough to let another person follow it.", fontsize=10)
    page.insert_text((50, 160), DOTS, fontsize=10)
    page.insert_text((50, 220), "(c) State one result.", fontsize=10)
    page.insert_text((50, 245), DOTS, fontsize=10)

    region = plan_answer_rule_cleanup(
        [(page, 50.0, 300.0)], science_p5=True,
    )[0]
    cue_y = find_long_form_cue_y(page, clip_y0_pt=50, clip_y1_pt=300, science_p5=True)
    c_heading = next(
        line["bbox"][1]
        for block in page.get_text("dict")["blocks"]
        for line in block.get("lines", [])
        if "(c) State one result" in "".join(s.get("text", "") for s in line.get("spans", []))
    )
    assert region is not None
    assert region[0] == cue_y
    assert region[1] == c_heading
    # The short subpart's dotted response line is below the cleanup interval.
    c_answer = next(
        line["bbox"][1]
        for block in page.get_text("dict")["blocks"]
        for line in block.get("lines", [])
        if "...." in "".join(s.get("text", "") for s in line.get("spans", []))
        and line["bbox"][1] > c_heading
    )
    assert c_answer > region[1]


def test_consecutive_dot_only_rows_are_collapsed_as_one_answer_space_block():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    for y in (180, 202, 224, 246, 268, 290):
        page.insert_text((50, y), DOTS, fontsize=10)

    scale = 2.0
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    cleaned = remove_dotted_answer_rules(
        image, page, source_x0_pt=0, source_y0_pt=0,
        scale_x=scale, scale_y=scale,
    )

    # Deleting the printed glyph rows alone leaves the inter-line gaps. The
    # cleanup should remove their full contiguous block, including those gaps.
    assert cleaned.height < image.height - 200


def test_cleanup_starts_at_the_long_essay_instruction_not_earlier_short_answer_lines():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 120), "(a) Give one reason.", fontsize=10)
    page.insert_text((50, 145), DOTS, fontsize=10)
    page.insert_text((50, 190), "(b) Write about 250 to 350 words.", fontsize=10)
    page.insert_text((50, 220), DOTS, fontsize=10)

    cue_y = find_long_form_cue_y(page, clip_y0_pt=90, clip_y1_pt=250)
    assert cue_y is not None and 170 < cue_y < 190
    image = vc.render_clip(
        page, 90, 250, remove_long_answer_rules=True,
        answer_rule_start_y_pt=cue_y,
    )
    x0, x1 = vc.page_clip_bounds(page)
    scale = vc.TARGET_WIDTH / (x1 - x0)
    dots = [
        c for block in page.get_text("rawdict")["blocks"]
        for line in block.get("lines", [])
        for span in line.get("spans", [])
        for c in span.get("chars", []) if c.get("c") == "."
    ]
    upper = [c for c in dots if c["bbox"][1] < cue_y]
    lower = [c for c in dots if c["bbox"][1] > cue_y]
    def box(chars):
        return (int((min(c["bbox"][0] for c in chars) - x0) * scale),
                int((min(c["bbox"][1] - 90 for c in chars) * scale)),
                int((max(c["bbox"][2] for c in chars) - x0) * scale) + 1,
                int((max(c["bbox"][3] - 90 for c in chars) * scale)) + 1)
    assert _ink_count(image, box(upper)) > 10
    assert _ink_count(image, box(lower)) == 0


def test_vector_crop_runtime_only_cleans_long_form_and_preserves_question_content():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 120), "Explain the reason: " + DOTS, fontsize=10)
    page.insert_text((520, 120), "[2]", fontsize=10)
    page.insert_text((50, 160), DOTS, fontsize=10)  # answer-rule-only row
    page.insert_text((50, 200), "The word 'ellipsis...' stays.", fontsize=10)

    # The default short-question crop keeps its answer dots.
    short_image = vc.render_clip(page, 90, 225)
    # Explicit essay cleanup removes leaders and collapses a dot-only row.
    image = vc.render_clip(page, 90, 225, remove_long_answer_rules=True)
    x0, x1 = vc.page_clip_bounds(page)
    scale = vc.TARGET_WIDTH / (x1 - x0)

    # Dotted leaders disappear only in the long-form crop, while the question
    # wording and separate mark label remain raster-visible.
    prompt = page.search_for("Explain the reason")[0]
    mark = page.search_for("[2]")[0]
    dot_chars = [c for c in _chars_for_line(page, DOTS) if c["c"] == "."]
    dot_box = (int((min(c["bbox"][0] for c in dot_chars) - x0) * scale),
               int((min(c["bbox"][1] - 90 for c in dot_chars) * scale)),
               int((max(c["bbox"][2] for c in dot_chars) - x0) * scale) + 1,
               int((max(c["bbox"][3] - 90 for c in dot_chars) * scale)) + 1)
    prompt_box = (int((prompt.x0 - x0) * scale), int((prompt.y0 - 90) * scale),
                  int((prompt.x1 - x0) * scale) + 1, int((prompt.y1 - 90) * scale) + 1)
    mark_box = (int((mark.x0 - x0) * scale), int((mark.y0 - 90) * scale),
                int((mark.x1 - x0) * scale) + 1, int((mark.y1 - 90) * scale) + 1)
    assert _ink_count(short_image, dot_box) > 10  # short-answer lines are retained
    assert _ink_count(image, dot_box) == 0       # essay rules are removed
    assert _ink_count(image, prompt_box) > 10
    assert _ink_count(image, mark_box) > 2

    # The dot-only answer row was removed vertically, reducing blank crop area.
    unclean = page.get_pixmap(matrix=fitz.Matrix(scale, scale),
                              clip=fitz.Rect(x0, 90, x1, 225), alpha=False)
    assert image.height < unclean.height - 20

    # A short legitimate ellipsis (three periods) is not treated as a rule.
    ellipsis = page.search_for("ellipsis...")[0]
    removed_rows = unclean.height - image.height
    ellipsis_box = (int((ellipsis.x0 - x0) * scale), int((ellipsis.y0 - 90) * scale) - removed_rows,
                    int((ellipsis.x1 - x0) * scale) + 1,
                    int((ellipsis.y1 - 90) * scale) + 1 - removed_rows)
    assert _ink_count(image, ellipsis_box) > 2


def test_gold_splitter_preserves_short_subpart_rows_before_essay_cue():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 120), "(a) Give one reason.", fontsize=10)
    page.insert_text((50, 145), DOTS, fontsize=10)
    page.insert_text((50, 190), "(b) Write about 250 to 350 words.", fontsize=10)
    page.insert_text((50, 220), DOTS, fontsize=10)

    scale = 3.0
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
    raster = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    info = PageCropInfo(0, 0, 0, pix.width, pix.height, pix.width, pix.height)
    segments = [PageSegment(0, 0, raster.height)]
    cue_y = find_long_form_cue_y(page, clip_y0_pt=0, clip_y1_pt=page.rect.height)
    assert cue_y is not None

    short = crop_page_segments([raster], segments, doc=doc, crop_infos={0: info})[0]
    partial = crop_page_segments(
        [raster], segments, doc=doc, crop_infos={0: info},
        answer_rule_start_y_pt=[cue_y],
    )[0]
    all_clean = crop_page_segments(
        [raster], segments, doc=doc, crop_infos={0: info},
        remove_long_answer_rules=True,
    )[0]
    assert short.height > partial.height > all_clean.height


def test_gold_question_split_segment_path_cleans_only_when_question_is_long_form():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 120), "Give a response: " + DOTS, fontsize=10)
    page.insert_text((50, 160), DOTS, fontsize=10)
    page.insert_text((50, 220), "[15]", fontsize=10)

    render_scale = 3.0
    pix = page.get_pixmap(matrix=fitz.Matrix(render_scale, render_scale), alpha=False)
    raster = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    info = PageCropInfo(page_index=0, left=0, top=0, right=pix.width,
                        bottom=pix.height, orig_w=pix.width, orig_h=pix.height)
    seg = [PageSegment(page_index=0, y0=0, y1=raster.height)]

    clean = crop_page_segments(
        [raster], seg, doc=doc, crop_infos={0: info}, remove_long_answer_rules=True
    )[0]
    short = crop_page_segments([raster], seg, doc=doc, crop_infos={0: info})[0]
    assert clean.height < short.height - 20

    # Short splitter calls preserve their answer-rule dots (same visible width).
    assert short.height > 700

    # The shared cleaner preserves a standalone mark allocation below a row it
    # collapses; account for that intentional vertical shift in the test ROI.
    sx = pix.width / page.rect.width
    sy = pix.height / page.rect.height
    cropped = remove_dotted_answer_rules(
        raster, page, source_x0_pt=0, source_y0_pt=0, scale_x=sx, scale_y=sy,
    )
    mark = page.search_for("[15]")[0]
    removed_rows = raster.height - cropped.height
    mark_box = (int(mark.x0 * sx), int(mark.y0 * sy) - removed_rows,
                int(mark.x1 * sx) + 1, int(mark.y1 * sy) + 1 - removed_rows)
    assert _ink_count(cropped, mark_box) > 2
