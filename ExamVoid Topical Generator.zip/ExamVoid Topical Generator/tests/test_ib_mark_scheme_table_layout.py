from __future__ import annotations

from adapters.base import DocumentContext
from adapters.ib.adapter import Adapter


def _line(text: str, x: float, y: float) -> dict:
    width = max(8.0, len(text) * 5.0)
    return {"text": text, "bbox": [x, y, x + width, y + 12.0]}


def _page(index: int, lines: list[dict]) -> dict:
    return {
        "page_index": index,
        "size": [842.0, 595.0],
        "text": "\n".join(line["text"] for line in lines),
        "lines": lines,
    }


def _biology_ms_context() -> DocumentContext:
    title = _page(0, [
        _line("May 2025 Biology Higher level Paper 2 Markscheme", 42.6, 70.0),
        # Numbered guidance is front matter, not the answer table.
        _line("1.", 42.6, 130.0),
        _line("2.", 42.6, 155.0),
    ])
    header = lambda y: [
        _line("Question", 60.0, y),
        _line("Answers", 300.0, y),
        _line("Notes", 630.0, y),
        _line("Total", 771.0, y),
    ]
    page1 = _page(1, [
        _line("Section A", 390.0, 70.0),
        *header(90.0),
        _line("1.", 51.4, 120.0), _line("a", 79.7, 120.0), _line("Answer for Q1a", 136.3, 120.0),
        _line("1.", 51.4, 155.0), _line("b", 79.7, 155.0), _line("Answer for Q1b", 136.3, 155.0),
        _line("2", 781.9, 185.0), _line("max", 774.0, 198.0),
        _line("2.", 51.4, 235.0), _line("a", 79.7, 235.0), _line("Answer for Q2a", 136.3, 235.0),
        _line("1", 781.9, 255.0), _line("max", 774.0, 268.0),
    ])
    page2 = _page(2, [
        *header(90.0),
        _line("3.", 51.4, 120.0), _line("a", 79.7, 120.0), _line("Answer for Q3a", 136.3, 120.0),
        _line("2", 781.9, 170.0), _line("max", 774.0, 183.0),
    ])
    page3 = _page(3, [
        _line("Section B", 390.0, 70.0),
        _line("Extended response questions carry a quality mark.", 51.1, 100.0),
        _line("The answer should be clear and succinct.", 51.1, 120.0),
        _line("4.", 51.4, 200.0), _line("a", 79.7, 200.0), _line("Answer for Q4a", 136.3, 200.0),
    ])
    page4 = _page(4, [
        *header(90.0),
        _line("4", 51.4, 120.0), _line("b", 79.7, 120.0), _line("Continuation of Q4", 136.3, 120.0),
        _line("3", 781.9, 180.0), _line("max", 774.0, 193.0),
    ])
    pages = [title, page1, page2, page3, page4]
    full_text = "\n".join(page["text"] for page in pages)
    return DocumentContext(
        path="biology-paper-2-markscheme.pdf",
        filename="biology-paper-2-markscheme.pdf",
        stem="biology-paper-2-markscheme",
        suffix=".pdf",
        first_page_text=title["text"],
        full_text=full_text,
        page_count=len(pages),
        layout={"pages": pages},
    )


def test_ib_biology_table_mark_scheme_splits_repeated_question_rows_and_shared_page():
    ctx = _biology_ms_context()
    adapter = Adapter()

    starts = adapter._ms_question_starts(ctx)
    assert [(qn, page) for qn, page, _top, _bottom in starts] == [
        (1, 1), (2, 1), (3, 2), (4, 3)
    ]

    segments = adapter.segment_mark_scheme(ctx)
    assert [segment["question_number"] for segment in segments] == [1, 2, 3, 4]
    # Q1 and Q2 share a page; the second crop must start at Q2's row rather than
    # duplicating Q1 and the page header. Q4's continuation remains with Q4.
    q1, q2, _q3, q4 = segments
    assert len(q1["pages"]) == 1 and q1["pages"][0]["rect"][3] < 235.0
    assert len(q2["pages"]) == 1 and q2["pages"][0]["rect"][1] > 200.0
    assert [p["page_index"] for p in q4["pages"]] == [3, 4]
