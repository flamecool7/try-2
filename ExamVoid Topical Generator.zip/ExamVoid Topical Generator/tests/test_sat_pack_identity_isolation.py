"""SAT module-local question numbers must not collide in packs or topic routing."""
import json
from pathlib import Path

from adapters.pack_assembler import assemble_session_packs, _collect_companions


def test_same_local_question_number_in_four_sat_modules_remains_four_packs(tmp_path):
    session = tmp_path / "final" / "SAT" / "SAT_T4" / "Practice_UNKNOWN"
    qp_dir = session / "QP" / "sat-practice-test-4-digital"
    qp_dir.mkdir(parents=True)
    identities = [
        ("RWM1Q1", "Craft_and_Structure", "RW", 1),
        ("RWM2Q1", "Information_and_Ideas", "RW", 2),
        ("MATHM1Q1", "Algebra", "MATH", 1),
        ("MATHM2Q1", "Geometry_and_Trigonometry", "MATH", 2),
    ]
    hints = []
    for canonical, topic, section, module in identities:
        (qp_dir / f"SAT_T4_Practice_UNKNOWN_{canonical}.webp").write_bytes(b"fake-webp")
        hints.append({
            "question_number": 1,
            "canonical_question": canonical,
            "section": section,
            "module": module,
            "topic": topic,
            "status": "HINT",
            "confidence": 0.9,
        })
    (qp_dir / "topic_hints.json").write_text(json.dumps(hints), encoding="utf-8")

    companions = _collect_companions(session)
    assert set(companions) == {canonical for canonical, *_ in identities}

    result = assemble_session_packs(session)
    assert result["packs"] == 4
    assert {item["canonical_question"] for item in result["review_items"]} == {
        canonical for canonical, *_ in identities
    }
    assert all(item["reason"] == "MISSING_MS" for item in result["review_items"])

    packs = sorted((session / "PACKS").rglob("metadata.json"))
    assert len(packs) == 4
    metadata = [json.loads(path.read_text(encoding="utf-8")) for path in packs]
    assert {item["canonical_question"] for item in metadata} == {
        canonical for canonical, *_ in identities
    }
    assert all(item["question_number"] == 1 for item in metadata)
    assert {(item["section"], item["module"]) for item in metadata} == {
        (section, module) for _, _, section, module in identities
    }
