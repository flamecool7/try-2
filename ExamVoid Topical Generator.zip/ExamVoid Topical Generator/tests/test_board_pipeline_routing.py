"""Routing invariants for board-isolated pipeline dispatch."""
from pathlib import Path

from run_board_pipelines import BOARD_DIRS, command_for, contains_pdfs


def test_board_input_folders_are_distinct():
    assert BOARD_DIRS == {
        "CAIE": "CAIE",
        "AQA": "AQA",
        "EDEXCEL": "EDEXCEL",
        "IB": "IB",
        "SAT": "SAT",
    }


def test_caie_uses_cambridge_pipeline_with_only_its_folder(tmp_path):
    input_dir = tmp_path / "input" / "CAIE"
    output_dir = tmp_path / "output"
    command = command_for(
        "CAIE", input_dir, output_dir,
        workers=7, jobs=9, enable_ocr=False, prune_stale_dirs=True,
    )
    assert Path(command[1]).name == "run_pipeline.py"
    assert command[command.index("--input") + 1] == str(input_dir)
    assert command[command.index("--output") + 1] == str(output_dir)
    assert "--workers" in command
    assert "--jobs" not in command


def test_non_caie_board_uses_universal_pipeline_with_its_own_folder(tmp_path):
    output_dir = tmp_path / "output"
    for board in ("AQA", "EDEXCEL", "IB", "SAT"):
        input_dir = tmp_path / "input" / board
        command = command_for(
            board, input_dir, output_dir,
            workers=7, jobs=9, enable_ocr=True, prune_stale_dirs=True,
        )
        assert Path(command[1]).name == "run_universal_batch.py"
        assert command[command.index("--input") + 1] == str(input_dir)
        assert command[command.index("--output") + 1] == str(output_dir)
        assert "--enable-ocr" in command
        assert "--prune-stale-dirs" in command
        assert "--jobs" in command
        assert "--workers" not in command


def test_pdf_discovery_is_recursive_and_case_insensitive(tmp_path):
    folder = tmp_path / "SAT"
    assert not contains_pdfs(folder)
    nested = folder / "practice"
    nested.mkdir(parents=True)
    (nested / "paper.PDF").write_bytes(b"%PDF-test")
    assert contains_pdfs(folder)
