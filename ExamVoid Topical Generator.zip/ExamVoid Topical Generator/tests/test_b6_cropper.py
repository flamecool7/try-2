"""B6 cropper fixes: section headings, numbered passages, trailing pages, stimulus starts."""
import fitz

from core import vector_first_cropper as vc
from core.vector_first_cropper import Marker

DOTS = "." * 120


def _m(number, page, y, text=None):
    return Marker(number=number, page=page, y0=y - 9, y1=y + 2, x0=50,
                  text=text or f"{number} Question text", score=1.0, reason="test")


def _page(doc, rows):
    page = doc.new_page(width=595, height=842)
    for x, y, text in rows:
        page.insert_text((x, y), text, fontsize=10)
    return page


def test_section_heading_needs_a_real_heading():
    r = vc.SECTION_HEADING_RE
    for t in ["Section A", "SECTION B", "Section 3", "Section C: Devised piece",
              "Section B Read the following passage", "DOCUMENT 1",
              "Answer one question from this section."]:
        assert r.match(t), t
    for t in ["section is from 300380 to 330380", "section Y.", "Section X of the journey"]:
        assert not r.match(t), t


def test_answer_lines_page_is_trailing_admin():
    doc = fitz.open()
    _page(doc, [(60, 120 + 26 * i, DOTS) for i in range(20)])
    assert vc._page_is_trailing_admin(doc[0])


def test_caie_footer_credit_slug_and_imposition_text_are_cut_from_question_crop():
    doc = fitz.open()
    page = _page(doc, [(50, 120, "Question 1: a short chemistry question."),
                       (50, 680, "." * 80 + " [4]"),
                       (50, 780, "© UCLES 2024"),
                       (250, 780, "06_0500_12_2024_1.15"),
                       (170, 796, "ĬÍĊ®Ġ³íËõÏđÅĢÆñÈþ×")])

    footer_top = min(line.y0 for line in vc.lines_from_page(page)
                     if "ucles" in line.text.lower())
    body_bottom = vc.page_body_bottom(page)
    crop_text = vc.extract_text_for_segment(page, 0.0, body_bottom)

    assert body_bottom <= footer_top
    assert "UCLES" not in crop_text
    assert "06_0500_12_2024_1.15" not in crop_text
    assert "ĬÍĊ" not in crop_text
    assert "[4]" in crop_text  # real answer/mark lines above the footer stay intact


def test_low_final_mark_keeps_answer_page():
    # 0457/0478: the last answer page ends with the question total near the footer
    doc = fitz.open()
    _page(doc, [(60, 120 + 26 * i, DOTS) for i in range(24)] + [(520, 780, "[24]")])
    assert not vc._page_is_trailing_admin(doc[0])


def test_part_label_line_keeps_page():
    # 9626: '(b) Rootkit ......' is a sub-part, not furniture
    doc = fitz.open()
    _page(doc, [(60, 120, "(b) Rootkit " + DOTS)] + [(60, 150 + 26 * i, DOTS) for i in range(10)])
    assert not vc._page_is_trailing_admin(doc[0])


def test_graph_page_keeps_page():
    # 9715: a grid drawn as many thin strokes is content
    doc = fitz.open()
    page = _page(doc, [])
    for i in range(11):
        page.draw_line((100 + 30 * i, 200), (100 + 30 * i, 500), width=0.3)
        page.draw_line((100, 200 + 30 * i), (400, 200 + 30 * i), width=0.3)
    assert not vc._page_is_trailing_admin(doc[0])


def _passage_doc(with_marks=True):
    doc = fitz.open()
    mk = lambda s: s if with_marks else ""
    _page(doc, [(50, 120, "1 Explain the first claim."), (520, 160, mk("[2]")),
                (50, 300, "2 Explain the second claim."), (520, 340, mk("[3]"))])
    _page(doc, [(50, 120, "1 It is often said that cities grow."),
                (50, 200, "2 Many people move for work."),
                (50, 280, "3 Some return home later.")])
    _page(doc, [(50, 120, "3 Evaluate the passage."), (520, 160, mk("[6]"))])
    markers = [_m(1, 0, 120), _m(2, 0, 300), _m(1, 1, 120), _m(2, 1, 200), _m(3, 1, 280), _m(3, 2, 120)]
    return doc, markers


def test_numbered_passage_is_dropped():
    doc, markers = _passage_doc()
    kept = vc._drop_numbered_passages(doc, markers)
    assert [(m.number, m.page) for m in kept] == [(1, 0), (2, 0), (3, 2)]


def test_numbered_passage_guard_skips_papers_without_marks():
    doc, markers = _passage_doc(with_marks=False)  # MCQ-style: no '[n]' anywhere
    assert vc._drop_numbered_passages(doc, markers) == markers


def test_stimulus_page_opens_next_group():
    # 0510 P1: 'Exercise 2' + reading text sit on the page before question 2
    doc = fitz.open()
    _page(doc, [(50, 120, "1 What does the writer say?"), (520, 160, "[1]")])
    _page(doc, [(50, 100, "Exercise 2"), (50, 140, "Read the article about underground homes."),
                (50, 180, "Many families now live below ground.")])
    _page(doc, [(50, 120, "2 Complete the notes."), (520, 160, "[4]")])
    q1, q2 = _m(1, 0, 120), _m(2, 2, 120)
    first = vc.segment_for_marker(doc, q1, q2, None)
    second = vc.segment_for_marker(doc, q2, None, q1)
    assert all(seg.page == 0 for seg in first)
    assert second[0].page == 1 and second[0].y0 < 100
    assert vc.segment_for_marker(doc, q2, None)[0].page == 2  # old call style unchanged


def test_source_prompt_on_next_question_page_stays_out_of_previous_multipage_crop():
    # Real 0500/12 layout: the next question's "Read Text C" direction sits
    # above Q2 on a page reached while Q1 spans multiple earlier pages. The
    # prompt must start Q2 rather than ride at the bottom of Q1.
    doc = fitz.open()
    _page(doc, [(50, 120, "1 First question body."),
                (50, 200, "Further answer space for Question 1."),
                (50, 240, "[5]")])
    _page(doc, [(50, 78, "Read Text C, and then answer Questions 2(a)-(d) on this"),
                (50, 96, "question paper."),
                (50, 145, "Question 2"),
                (50, 175, "Explain the passage."),
                (520, 220, "[3]")])
    q1, q2 = _m(1, 0, 120), _m(2, 1, 145, text="Question 2")

    q1_segments = vc.segment_for_marker(doc, q1, q2)
    q2_segments = vc.segment_for_marker(doc, q2, None, q1)
    q1_text = "\\n".join(vc.extract_text_for_segment(doc[s.page], s.y0, s.y1)
                         for s in q1_segments)
    q2_text = "\\n".join(vc.extract_text_for_segment(doc[s.page], s.y0, s.y1)
                         for s in q2_segments)

    assert all(segment.page == 0 for segment in q1_segments)
    assert "Read Text C" not in q1_text
    assert q2_segments[0].page == 1
    assert q2_segments[0].y0 < 70.0
    assert "Read Text C" in q2_text


def test_re_read_source_prompt_is_cut_from_previous_question_and_kept_with_next():
    doc = fitz.open()
    _page(doc, [(50, 120, "2 Second question body."),
                (50, 240, "Further answer space for Question 2."),
                (520, 280, "[10]")])
    _page(doc, [(50, 78, "Re-read Text C, and answer Question 3 on this"),
                (50, 96, "question paper."),
                (50, 145, "Question 3"),
                (50, 175, "Explain your response."),
                (520, 220, "[5]")])
    q2, q3 = _m(2, 0, 120), _m(3, 1, 145, text="Question 3")

    q2_segments = vc.segment_for_marker(doc, q2, q3)
    q3_segments = vc.segment_for_marker(doc, q3, None, q2)
    q2_text = "\\n".join(vc.extract_text_for_segment(doc[s.page], s.y0, s.y1)
                         for s in q2_segments)
    q3_text = "\\n".join(vc.extract_text_for_segment(doc[s.page], s.y0, s.y1)
                         for s in q3_segments)

    assert all(segment.page == 0 for segment in q2_segments)
    assert "Re-read Text C" not in q2_text
    assert q3_segments[0].page == 1
    assert q3_segments[0].y0 < 70.0
    assert "Re-read Text C" in q3_text


def test_heading_marker_is_not_its_own_group_heading():
    doc = fitz.open()
    page = _page(doc, [(50, 100, "Exercise 3"), (50, 140, "Read the text."), (50, 400, "Exercise 4")])
    assert vc._group_heading_y(page, _m(4, 0, 400, text="Exercise 4")) is None


def test_context_line_regex():
    assert vc._CONTEXT_LINE_RE.match("You will hear a talk about bees.")
    assert vc._CONTEXT_LINE_RE.match("You hear two friends talking.")
    assert not vc._CONTEXT_LINE_RE.match("Your answer should be brief.")
