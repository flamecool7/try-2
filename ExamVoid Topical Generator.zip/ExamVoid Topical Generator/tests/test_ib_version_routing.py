from __future__ import annotations

from adapters.base import DocumentContext
from adapters.ib.adapter import Adapter, _IB_SUBJECT_TITLES
from adapters.ib.classification import classify_segments, load_profile, profile_path


def _ctx(text: str, name: str = "ib-paper.txt") -> DocumentContext:
    return DocumentContext(
        path=name,
        filename=name,
        stem=name.rsplit(".", 1)[0],
        suffix="." + name.rsplit(".", 1)[-1],
        first_page_text=text[:1600],
        full_text=text,
        source_url="https://www.ibo.org/sample-exam-papers/",
    )


def test_version_routes_keep_legacy_and_revised_profiles_distinct():
    assert profile_path("IBES", 2025).name == "config.json"
    assert "versions/2026/config.json" in str(profile_path("IBES", 2026))
    old_ess, _ = load_profile("IBES", 2025)
    new_ess, _ = load_profile("IBES", 2026)
    assert len(old_ess.major_topics) == 6
    assert len(new_ess.major_topics) == 8
    assert old_ess is not new_ess

    old_math, _ = load_profile("IBMA", 2028)
    new_math, _ = load_profile("IBMA", 2029)
    assert "T1_Financial_maths" in old_math.major_topics
    assert "T1_Financial_maths" not in new_math.major_topics
    assert new_math.major_topics == [
        "MAA29_A_Number_and_Algebra", "MAA29_B_Functions", "MAA29_C_Geometry",
        "MAA29_D_Probability_and_Statistics", "MAA29_E_Calculus",
    ]

    world_religions, _ = load_profile("IBWR", 2028)
    religion_society, _ = load_profile("IBWR", 2029)
    assert world_religions.major_topics != religion_society.major_topics
    assert religion_society.subject == "Religion_and_Society_IBWR"

    # The current and legacy Classical Languages/Philosophy cohorts are distinct.
    assert profile_path("IBCL", 2023).name == "config.json"
    assert "versions/2024/config.json" in str(profile_path("IBCL", 2024))
    assert profile_path("IBPL", 2024).name == "config.json"
    assert "versions/2025/config.json" in str(profile_path("IBPL", 2025))
    latin_legacy, _ = load_profile("IBCL", 2023)
    latin_current, _ = load_profile("IBCL", 2024)
    philosophy_legacy, _ = load_profile("IBPL", 2024)
    philosophy_current, _ = load_profile("IBPL", 2025)
    assert latin_legacy.major_topics != latin_current.major_topics
    assert philosophy_legacy.major_topics != philosophy_current.major_topics
    assert "PH25_HL_Contemporary_Issues" in philosophy_current.major_topics

    # Other reconciled profiles identify their current first-assessment cohort;
    # dates outside that explicit range fail closed instead of borrowing it.
    for code, year, version_fragment in (
        ("IBSA", 2019, "first assessment 2019"),
        ("IBMU", 2022, "first assessment 2022"),
        ("IBTH", 2024, "first assessment 2024"),
        ("IBFI", 2023, "first assessment 2023"),
    ):
        from adapters.ib.classification import classify_text
        assert version_fragment in classify_text(code, "sample", year=str(year))["profile_version"]
    assert profile_path("IBSA", 2018) is None
    assert classify_text("IBSA", "How are people the same?", year="2018")["status"] == "REVIEW_REQUIRED"

    from core.topic_suggest import subject_topics
    assert len(subject_topics("IB", "IBMA", year=2028)) == 44
    assert subject_topics("IB", "IBMA", year=2029) == new_math.major_topics


def test_ib_subject_title_resolution_covers_all_thirty_profile_codes():
    adapter = Adapter()
    assert len(_IB_SUBJECT_TITLES) == 30
    for code, (display, _aliases) in _IB_SUBJECT_TITLES.items():
        ctx = _ctx(f"International Baccalaureate\nDiploma Programme\n{display}\nPaper 1")
        evidence = adapter.identify_subject(ctx)
        codes = [str(e.value) for e in evidence if e.field == "subject_code"]
        assert code in codes, (display, codes)


def test_all_declared_ib_version_routes_are_unique_supported_and_non_orphaned():
    import json
    from pathlib import Path

    project = Path(__file__).resolve().parents[1]
    roots = sorted((project / "subjects_ib" / "DP").glob("*/config.json"))
    declared = set()
    route_count = 0
    for root in roots:
        root_data = json.loads(root.read_text(encoding="utf-8"))
        seen_years = set()
        for route in root_data.get("version_routes") or []:
            first = int(route["first_assessment"])
            assert first not in seen_years
            seen_years.add(first)
            target = (root.parent / route["profile"]).resolve()
            assert target.is_relative_to(root.parent.resolve())
            assert target.is_file()
            version = json.loads(target.read_text(encoding="utf-8"))
            assert version["board"] == "IB"
            assert version["syllabus_code"] == root_data["syllabus_code"]
            assert str(first) in {str(y) for y in version["syllabus_years"]}
            assert version.get("official_source")
            assert len(version["major_topics"]) == len(set(version["major_topics"]))
            declared.add(target)
            route_count += 1
    version_files = {p.resolve() for p in (project / "subjects_ib" / "DP").glob("*/versions/*/config.json")}
    assert route_count == 16
    assert declared == version_files


def test_runtime_segment_classifier_uses_document_subject_and_assessment_year():
    text = (
        "International Baccalaureate\nDiploma Programme\nGlobal politics\n"
        "May 2026\nPaper 1\nInstructions to candidates\nAnswer all questions.\n"
        "1. Using Source C, explain how sovereignty and interdependence can make "
        "international cooperation problematic for states."
    )
    ctx = _ctx(text, "global-politics-paper-1.txt")
    segments = Adapter().segment(ctx)
    assert len(segments) == 1
    assert segments[0]["metadata"]["ib_subject_code"] == "IBGP"

    routed = classify_segments(ctx, segments, component="Paper 1", year="2026")
    assert len(routed) == 1
    assert routed[0]["spec"] == "IBGP"
    assert routed[0]["profile_version"] == "Global politics — first assessment 2026"
    assert routed[0]["topic"] == "GP26_Core_Power_and_Political_Processes"
    assert routed[0]["text_source"] == "text_only_prompt"

    legacy = classify_segments(ctx, segments, component="Paper 1", year="2025")
    assert legacy[0]["profile_path"].endswith("Global_Politics_IBGP/config.json")
    assert legacy[0]["profile_version"] == "2024"
