from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import core.er_question_crops as er_crops
from core.bundle_worker import _er_matches_qp_bundle
from core.preflight import Preflight


class _Image:
    width = 2280
    height = 240


def test_worker_refuses_an_er_from_another_syllabus_or_session():
    qp = SimpleNamespace(
        syllabus_code="0620", season_letter="s", year_short="24", variant="22"
    )
    biology_er = SimpleNamespace(
        paper_type="er", identity_status="FILENAME_RESOLVED",
        syllabus_code="0610", season_letter="s", year_short="24", variant=""
    )
    wrong_session_er = SimpleNamespace(
        paper_type="er", identity_status="FILENAME_RESOLVED",
        syllabus_code="0620", season_letter="w", year_short="24", variant=""
    )

    assert _er_matches_qp_bundle(biology_er, qp) == (
        False, "syllabus_code mismatch: ER=0610 QP=0620"
    )
    assert _er_matches_qp_bundle(wrong_session_er, qp) == (
        False, "season_letter mismatch: ER=w QP=s"
    )
    wrong_component_er = SimpleNamespace(
        paper_type="er", identity_status="FILENAME_RESOLVED",
        syllabus_code="0620", season_letter="s", year_short="24", variant="42"
    )
    assert _er_matches_qp_bundle(wrong_component_er, qp) == (
        False, "component mismatch: ER=42 QP=22"
    )


def test_er_crop_scopes_to_the_same_syllabus_even_if_both_folders_are_verified(
    tmp_path, monkeypatch
):
    biology = tmp_path / "biology" / "Q-folder"
    chemistry = tmp_path / "chemistry" / "Q-folder"
    biology.mkdir(parents=True)
    chemistry.mkdir(parents=True)

    for folder, syllabus in ((biology, "0610"), (chemistry, "0620")):
        (folder / "metadata.json").write_text(json.dumps({
            "paper": f"{syllabus}_s24_qp_22",
            "variant": "22",
            "season": "Summer",
            "year": 2024,
            "question_number": "Q1",
        }), encoding="utf-8")

    er_path = tmp_path / "0610_s24_er.pdf"
    er_path.touch()
    biology_er = SimpleNamespace(
        file_path=er_path,
        paper_type="er",
        syllabus_code="0610",
        season="Summer",
        season_letter="s",
        year=2024,
        year_short="24",
        variant="",
    )

    calls = []

    def fake_build(path, syllabus, component, wanted):
        calls.append((syllabus, component, list(wanted)))
        return ({1: _Image()}, {}, {}, "mock")

    monkeypatch.setattr(er_crops, "build_question_crops_for_pdf", fake_build)
    monkeypatch.setattr(er_crops, "save_webp", lambda image, path, quality: None)
    monkeypatch.setattr(
        "core.examiner_report.remove_whole_report_tiles", lambda folder: 0
    )

    # The input list deliberately contains both subjects, reproducing the old
    # global post-run pass. The ER must still reach only its Biology QP folder.
    verified = [
        (str(biology), "22_Summer_2024", 1),
        (str(chemistry), "22_Summer_2024", 1),
    ]
    stats = er_crops.attach_question_er_crops(
        [biology_er], tmp_path, verified_folders=verified
    )

    assert calls == [("0610", "22", [1])]
    assert stats["crops_written"] == 1
    assert not list(chemistry.glob("*_ER.webp"))


def test_preflight_assigns_a_biology_er_only_to_biology_bundles(tmp_path):
    preflight = object.__new__(Preflight)
    identified = [
        {
            "path": tmp_path / "0620_s24_qp_22.pdf", "kind": "qp",
            "syllabus_code": "0620", "subject": "Chemistry", "level": "IGCSE",
            "season": "s", "year": "24", "component": "22",
            "paper_format": "STRUCTURED",
        },
        {
            "path": tmp_path / "0610_s24_qp_22.pdf", "kind": "qp",
            "syllabus_code": "0610", "subject": "Biology", "level": "IGCSE",
            "season": "s", "year": "24", "component": "22",
            "paper_format": "STRUCTURED",
        },
        {
            "path": tmp_path / "0610_s24_er.pdf", "kind": "er",
            "syllabus_code": "0610", "subject": "Biology", "level": "IGCSE",
            "season": "s", "year": "24", "component": "",
            "paper_format": "STRUCTURED",
        },
    ]

    bundles = preflight._group_bundles(identified)

    chemistry = bundles["0620_s24_22"]
    biology = bundles["0610_s24_22"]
    assert chemistry["er_path"] is None
    assert biology["er_path"] == tmp_path / "0610_s24_er.pdf"
