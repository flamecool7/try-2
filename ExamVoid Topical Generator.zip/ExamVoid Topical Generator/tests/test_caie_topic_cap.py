from __future__ import annotations

from types import SimpleNamespace

from core.classifier import (
    ClassificationResult,
    TopicClassifier,
    _caie_secondary_topic,
)
from core.config_loader import load_subject_config_by_code_and_level
from core.json_generator import JSONGenerator


def _caie_config():
    cfg = load_subject_config_by_code_and_level("0620", "IGCSE", None)
    assert cfg is not None
    return cfg


def test_caie_defaults_to_two_topics_but_other_shared_engine_users_keep_four():
    cfg = _caie_config()
    assert str(cfg.board).upper() in {"CIE", "CAIE"}
    classifier = TopicClassifier(cfg, classification_memory=None)
    assert classifier.max_topics == 2

    qp = SimpleNamespace(
        text=("1 (a) Explain how covalent bonds form in methane. [2] "
              "(b) Calculate the relative formula mass of methane. [2]"),
        marks=4, images=[], image=None, assembled_image=None,
    )
    matched = SimpleNamespace(
        qp=qp, ms=None, ms_answer=None, variant="42", year=2025, season="m",
        question_number="Q1", number_int=1, paper_format="STRUCTURED",
        full_qp_code="0620_m25_qp_42",
    )
    result = classifier.classify_question(matched, force_winner=True)
    assert result.max_topics == 2
    assert len(result.detailed_topics) <= 2

    # The same core engine is reused by other board adapters; the CAIE cap must
    # not silently change their legacy four-topic behavior.
    cfg.board = "AQA"
    assert TopicClassifier(cfg, classification_memory=None).max_topics == 4


def test_caie_post_refinement_cannot_reintroduce_weak_runner_up(monkeypatch):
    import core.classification_engine as engine

    def add_weak_runner_up(classifier, _view, result, **_kwargs):
        primary = list(result.detailed_topics or [])[:1]
        weak = next(topic for topic in classifier.config.detailed_topics if topic not in primary)
        result.detailed_topics = primary + [weak]
        return result

    monkeypatch.setattr(engine, "refine", add_weak_runner_up)
    cfg = _caie_config()
    classifier = TopicClassifier(cfg, classification_memory=None)
    qp = SimpleNamespace(
        text="1 (a) Explain how covalent bonds form in methane. [2]",
        marks=2, images=[], image=None, assembled_image=None,
    )
    matched = SimpleNamespace(
        qp=qp, ms=None, ms_answer=None, variant="42", year=2025, season="m",
        question_number="Q1", number_int=1, paper_format="STRUCTURED",
        full_qp_code="0620_m25_qp_42",
    )
    result = classifier.classify_question(matched, force_winner=True)
    assert len(result.detailed_topics) <= 1


def test_caie_second_topic_requires_independent_assessed_subpart_evidence():
    # A distinct marked subpart carries a clear second-topic signal.
    assert _caie_secondary_topic(
        ["Acid_base", "Electrolysis"],
        {"Acid_base": 12.0, "Electrolysis": 5.0},
        {"Acid_base": {0: 8.0, 1: 1.0}, "Electrolysis": {0: 0.5, 1: 4.0}},
        {0: 7, 1: 3},
        10,
    ) == "Electrolysis"

    # A near-tie on the same shared subpart is controversial, not a second tag.
    assert _caie_secondary_topic(
        ["Acid_base", "Electrolysis"],
        {"Acid_base": 12.0, "Electrolysis": 5.0},
        {"Acid_base": {0: 5.0}, "Electrolysis": {0: 4.8}},
        {0: 10},
        10,
    ) == ""

    # Even a separate part is not enough when the runner-up lacks material
    # direct evidence.
    assert _caie_secondary_topic(
        ["Acid_base", "Electrolysis"],
        {"Acid_base": 12.0, "Electrolysis": 2.9},
        {"Acid_base": {0: 8.0, 1: 1.0}, "Electrolysis": {0: 0.5, 1: 4.0}},
        {0: 7, 1: 3},
        10,
    ) == ""


def test_caie_question_metadata_contains_at_most_two_topic_labels():
    cfg = _caie_config()
    winner = cfg.major_topics[0]
    details = list(cfg.detailed_topics[:4])
    result = ClassificationResult(
        detailed_topics=details,
        major_topic_scores={winner: 5.0},
        winning_major=winner,
        topic_marks_breakdown={},
        reasoning="synthetic cap contract",
        max_topics=2,
    )
    matched = SimpleNamespace(
        paper_code="0620_m25_42",
        full_qp_code="0620_m25_qp_42",
        question_number="Q1",
        variant="42",
        year=2025,
        season="m",
    )

    metadata = JSONGenerator().generate_json(matched, result, cfg)
    assert len(metadata["topic"]) <= 2
    assert metadata["topic"][0] == winner
