"""The RAM-safe vector-first QP runtime must drop terminal reference pages."""
from pathlib import Path

import fitz

from core.chemistry_reference import classify_page
from core.vector_first_cropper import CambridgeCropper


_SYMBOLS = (
    "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Cu Zn "
    "Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe "
    "Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt "
    "Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr"
)


def _paper_with_terminal_reference_pages(path: Path) -> Path:
    doc = fitz.open()

    q = doc.new_page(width=595, height=842)
    q.insert_text((50, 110), "1 Explain why this reaction occurs.", fontsize=11)
    q.insert_text((520, 760), "[2]", fontsize=11)

    blank = doc.new_page(width=595, height=842)
    blank.insert_text((50, 420), "BLANK PAGE", fontsize=11)

    constants = doc.new_page(width=595, height=842)
    constants.insert_textbox(
        (45, 50, 550, 350),
        "Important values, constants and standards\n"
        "molar gas constant R = 8.31 J K-1 mol-1\n"
        "Faraday constant F = 9.65 x 10^4 C mol-1\n"
        "Avogadro constant L = 6.022 x 10^23 mol-1\n"
        "specific heat capacity of water c = 4.18 kJ kg-1 K-1",
        fontsize=11,
    )

    table = doc.new_page(width=595, height=842)
    table.insert_text((45, 55), "The Periodic Table of the Elements", fontsize=12)
    symbols = _SYMBOLS.split()
    y = 95
    for start in range(0, len(symbols), 12):
        row = " ".join(symbols[start : start + 12])
        table.insert_text((45, y), row, fontsize=10)
        y += 22
    doc.save(path)
    doc.close()
    return path


def test_low_ram_vector_cropper_excludes_terminal_constants_and_periodic_table(tmp_path):
    source = _paper_with_terminal_reference_pages(tmp_path / "9701_s24_qp_41.pdf")
    with fitz.open(source) as doc:
        assert classify_page(doc, 2, len(doc), syllabus_code="9701").category == "data_booklet_constants"
        assert classify_page(doc, 3, len(doc), syllabus_code="9701").category == "periodic_table"

    analysis, results = CambridgeCropper(tmp_path / "crops").crop_qp(source)

    assert analysis.selected_numbers == [1]
    assert [r.number for r in results] == [1]
    # The vector-first crop's own page ledger proves it used only the question
    # page; neither the appended constants sheet nor the periodic table rode on.
    assert results[0].pages == [1]
    assert "Important values" not in results[0].text
    assert "Periodic Table" not in results[0].text
    assert {item["category"] for item in analysis.excluded_reference_pages} >= {
        "blank_page", "data_booklet_constants", "periodic_table"
    }
