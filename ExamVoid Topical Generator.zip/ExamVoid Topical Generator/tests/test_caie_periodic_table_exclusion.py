from __future__ import annotations

from types import SimpleNamespace

import fitz
from PIL import Image, ImageDraw

from core.insert_engine import InsertEngine, InsertResult, write_insert_outputs
from core.question_split import (
    PageCropInfo,
    build_question_segments,
    remove_unnecessary_pages,
)


_SYMBOLS = (
    "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr "
    "Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm "
    "Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr "
    "Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og"
)


def _pdf_with_question_then_periodic_table(tmp_path, *, cover_first=False):
    path = tmp_path / "chemistry.pdf"
    doc = fitz.open()
    first = doc.new_page()
    if cover_first:
        first.insert_text((48, 48), "Cambridge International\nInstructions to candidates\nDo not write on this page")
    else:
        first.insert_text((48, 80), "1. Explain how the element reacts. [2]")
    table = doc.new_page()
    table.insert_textbox(
        (40, 40, 550, 790),
        "The Periodic Table of the Elements\n" + "\n".join(_SYMBOLS.split()[i:i + 12][0] + " " + " ".join(_SYMBOLS.split()[i + 1:i + 12])
                                                   for i in range(0, len(_SYMBOLS.split()), 12)),
        fontsize=11,
    )
    doc.save(path)
    return doc, path


def _page_images():
    originals, cropped, infos = [], [], {}
    for idx in range(2):
        im = Image.new("RGB", (2480, 3508), "white")
        if idx == 0:
            ImageDraw.Draw(im).rectangle((80, 180, 600, 230), fill="black")
        originals.append(im)
        cropped.append(im.copy())
        infos[idx] = PageCropInfo(
            page_index=idx, left=0, top=0, right=2480, bottom=3508,
            orig_w=2480, orig_h=3508,
        )
    return originals, cropped, infos


def test_terminal_periodic_table_is_never_added_to_last_question(tmp_path):
    doc, _path = _pdf_with_question_then_periodic_table(tmp_path)
    cfg = SimpleNamespace(syllabus_code="0620")
    try:
        # The normal pre-pass excludes it.
        kept = remove_unnecessary_pages(doc, [Image.new("RGB", (10, 10))] * 2, cfg)
        assert kept == [0]

        # Defense in depth: even if an upstream caller mistakenly passes the
        # periodic-table page as kept, segmentation must not append it to Q1.
        originals, cropped, infos = _page_images()
        segments, _safe, notes = build_question_segments(
            [(0, 80.0, 1)], [0, 1], originals, cropped, infos, doc, cfg,
        )
        assert [segment.page_index for segment in segments[1]] == [0]
        assert any("periodic-table reference excluded" in note for note in notes)
    finally:
        doc.close()


def test_empty_keep_fallback_never_restores_terminal_periodic_table(tmp_path):
    doc, _path = _pdf_with_question_then_periodic_table(tmp_path, cover_first=True)
    cfg = SimpleNamespace(syllabus_code="0620")
    try:
        kept = remove_unnecessary_pages(doc, [Image.new("RGB", (10, 10))] * 2, cfg)
        assert 1 not in kept
    finally:
        doc.close()


def test_periodic_table_insert_is_rejected_at_question_attachment_boundary(tmp_path):
    result = InsertResult(
        page_texts=["The Periodic Table of the Elements", _SYMBOLS],
        is_reference_data=False,  # simulate a lost upstream flag
    )
    summary = write_insert_outputs(
        InsertEngine(), result, tmp_path / "reference.pdf", tmp_path / "out",
        "IGCSE", "Chemistry_0620", "", "0620_s25_qp_42",
        question_refs=[(str(tmp_path / "Q1"), "Use Source A to answer the question.")],
    )
    assert summary["reference_data_skipped"] is True
    assert not (tmp_path / "out").exists()
