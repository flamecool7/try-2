from __future__ import annotations

import fitz
import numpy as np
from PIL import Image, ImageDraw

from adapters.base import DocumentContext
from adapters.registry import get_adapter
from adapters.segment_geometry import PageRect, _remove_sat_gutter_rule, _sanitise_top_band
from adapters.output_contracts import validate_segments


class _FakePage:
    def __init__(self, *, text_boxes=None, drawings=None):
        self.rect = fitz.Rect(0.0, 0.0, 612.0, 792.0)
        self._text_boxes = text_boxes or []
        self._drawings = drawings or []

    def get_text(self, _kind):
        blocks = []
        for text, bbox in self._text_boxes:
            blocks.append({"lines": [{"spans": [{"text": text}], "bbox": bbox}]})
        return {"blocks": blocks}

    def get_drawings(self):
        return [{"rect": fitz.Rect(*bbox)} for bbox in self._drawings]


def test_channel_colored_residue_is_cleared_from_the_verified_top_band():
    image = Image.new("RGB", (2280, 80), "white")
    # A near-white WebP/LANCZOS color residue can pass the grayscale cutoff
    # while still failing the channel-strict on-disk crop contract.
    image.putpixel((31, 19), (249, 250, 250))
    image.putpixel((32, 19), (249, 250, 250))
    ImageDraw.Draw(image).rectangle((100, 20, 150, 30), fill=(0, 0, 0))
    fixed = _sanitise_top_band(image)
    array = np.asarray(fixed)
    assert np.all(array[:20] == 255)
    assert array[20, 100].min() == 0
    image.close()
    fixed.close()


def _image_with_dotted_gutter():
    # One rendered point per pixel: crop x=34..307, y=90..520.
    image = Image.new("RGB", (273, 430), "white")
    draw = ImageDraw.Draw(image)
    # Question text and answer options; content must survive gutter cleanup.
    draw.rectangle((24, 60, 190, 95), fill="black")
    draw.rectangle((24, 220, 130, 238), fill="black")
    # Dotted vertical divider at about source x=297, continuing far below content.
    for y in range(5, 425, 4):
        draw.rectangle((262, y, 264, y), fill="black")
    return image


def test_sat_old_text_layer_gutter_is_removed_without_touching_question_content():
    page = _FakePage(text_boxes=[
        ("." * 50, (294.5, 100.0, 303.5, 500.0)),
    ])
    image = _image_with_dotted_gutter()

    assert _remove_sat_gutter_rule(image, page, PageRect(0, (34.0, 90.0, 307.0, 520.0)), 0)
    pixels = np.asarray(image)
    assert pixels[75, 70].min() < 10       # question text remains
    assert pixels[230, 70].min() < 10      # lower answer content remains
    assert pixels[350, 263].min() > 245    # decorative line is removed below and beside content
    assert pixels[30, 263].min() > 245


def test_sat_new_vector_gutter_is_removed_on_both_columns_but_solid_axis_is_not():
    dotted_page = _FakePage(drawings=[(297.0, 100.0, 297.0, 500.0)])
    dotted = _image_with_dotted_gutter()
    assert _remove_sat_gutter_rule(dotted, dotted_page, PageRect(0, (34.0, 90.0, 307.0, 520.0)), 0)
    assert np.asarray(dotted)[350, 263].min() > 245

    # In the right column the central divider sits on the crop's left edge.
    right_page = _FakePage(drawings=[(315.0, 100.0, 315.0, 500.0)])
    right = Image.new("RGB", (271, 430), "white")  # source x=311..582
    right_draw = ImageDraw.Draw(right)
    right_draw.rectangle((50, 60, 190, 95), fill="black")
    for y in range(5, 425, 4):
        right_draw.rectangle((3, y, 5, y), fill="black")
    assert _remove_sat_gutter_rule(right, right_page, PageRect(0, (311.0, 90.0, 582.0, 520.0)), 1)
    assert np.asarray(right)[350, 4].min() > 245
    assert np.asarray(right)[75, 70].min() < 10

    # A continuous plot axis can be geometrically near the gutter but lacks the
    # repeated dot/dash signature; it must be preserved as question content.
    axis_page = _FakePage(drawings=[(297.0, 100.0, 297.0, 500.0)])
    axis = Image.new("RGB", (273, 430), "white")
    ImageDraw.Draw(axis).line((263, 5, 263, 425), fill="black", width=1)
    assert not _remove_sat_gutter_rule(axis, axis_page, PageRect(0, (34.0, 90.0, 307.0, 520.0)), 0)
    assert np.asarray(axis)[350, 263].min() < 10


def test_sat_adapter_marks_column_side_for_gutter_cleanup():
    pages = []
    headings = [
        "Module 1\nReading and Writing\n1 QUESTIONS",
        "Module 2\nReading and Writing\n1 QUESTIONS",
        "Module 1\nMath\n1 QUESTIONS",
        "Module 2\nMath\n1 QUESTIONS",
    ]
    for index, text in enumerate(headings):
        x0 = 40.0 if index % 2 == 0 else 320.0
        lines = [
            {"text": "1", "bbox": [x0, 120.0, x0 + 6.0, 134.0]},
            {"text": "A representative question stem", "bbox": [x0 + 20.0, 145.0, x0 + 220.0, 160.0]},
        ]
        pages.append({"text": text, "size": [612.0, 792.0], "lines": lines})
    ctx = DocumentContext(
        path="synthetic.pdf", filename="synthetic.pdf", stem="synthetic", suffix=".pdf",
        size_bytes=0, sha256="", page_count=4, first_page_text=headings[0],
        full_text="\f".join(headings), has_text_layer=True, text_chars_per_page=[len(x) for x in headings],
        layout={"pages": pages},
    )
    segments = get_adapter("SAT").segment(ctx)
    assert len(segments) == 4
    assert [s["metadata"]["sat_column"] for s in segments] == [0, 1, 0, 1]
    assert [s["canonical_question"] for s in segments] == [
        "RWM1Q1", "RWM2Q1", "MATHM1Q1", "MATHM2Q1",
    ]
    assert all(s["metadata"]["layout_archetype"] == "sat_two_column_moduled"
               for s in segments)
    assert all(s["metadata"]["crop_plan"]["board_id"] == "SAT" for s in segments)
    assert validate_segments("SAT", segments) == []
