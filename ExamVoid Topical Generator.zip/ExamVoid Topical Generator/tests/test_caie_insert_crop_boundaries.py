from __future__ import annotations

from types import SimpleNamespace

import fitz
from PIL import Image

from adapters.base import DocumentContext
from adapters.companion_segments import TextCompanion
from adapters.source_mapping import link_sources_to_questions
from core.bundle_worker import (
    _remove_legacy_insert_bundle_output,
    _remove_stale_question_insert_sidecars,
    _validate_staging,
)
from core.cropping_engine import GOLD_AVAILABLE, gold_question_split
from core.insert_engine import (
    InsertEngine,
    InsertResult,
    InsertSection,
    referenced_sections,
    write_insert_outputs,
)
from core.question_split import (
    PageCropInfo,
    _detect_markers,
    build_question_segments,
    extract_question_text,
)


def _synthetic_qp(tmp_path):
    path = tmp_path / "read_text_qp.pdf"
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((48, 110), "1")
    page.insert_text((48, 132), "Read Text A and answer the question. [2]")
    page.insert_text((48, 190), "Explain Source A. [2]")
    # This prompt is Q2's heading even though it appears before the printed 2.
    page.insert_text((48, 310), "Read Text B")
    page.insert_text((48, 344), "2")
    page.insert_text((48, 370), "Explain Source B. [2]")
    doc.save(path)
    return path


def test_read_text_b_prompt_is_cut_from_q1_and_kept_with_q2(tmp_path):
    path = _synthetic_qp(tmp_path)
    doc = fitz.open(path)
    try:
        markers, confident = _detect_markers(doc)
        assert confident
        assert [marker[2] for marker in markers] == [1, 2]

        originals = [Image.new("RGB", (2480, 3508), "white")]
        cropped = [originals[0].copy()]
        infos = {0: PageCropInfo(0, 0, 0, 2480, 3508, 2480, 3508)}
        segments, split_confident, _notes = build_question_segments(
            markers, [0], originals, cropped, infos, doc,
            SimpleNamespace(syllabus_code="9093"),
        )
        assert split_confident
        q1_text = extract_question_text(doc, segments[1], infos)
        q2_text = extract_question_text(doc, segments[2], infos)
        assert "Read Text B" not in q1_text
        assert "Read Text B" in q2_text
        assert "Source A" in q1_text
        assert "Source B" not in q1_text
        assert "Source B" in q2_text
    finally:
        doc.close()


def test_insert_sections_attach_only_to_their_question_without_insert_folder(tmp_path, monkeypatch):
    q1 = tmp_path / "output" / "Topic" / "paper_Q1"
    q2 = tmp_path / "output" / "Topic" / "paper_Q2"
    q1.mkdir(parents=True)
    q2.mkdir(parents=True)
    sections = [
        InsertSection("Text A", "Text", 0, 50.0, 300.0, "Text A text"),
        InsertSection("Text B", "Text", 0, 300.0, 600.0, "Text B text"),
    ]
    result = InsertResult(sections=sections, page_texts=["Text A text. Text B text."])
    engine = InsertEngine(target_width=2280, quality=95)

    colors = {"Text A": (210, 20, 20), "Text B": (20, 40, 210)}
    monkeypatch.setattr(
        engine,
        "_section_image",
        lambda _pdf, section: Image.new("RGB", (2280, 180), colors[section.id]),
    )
    summary = write_insert_outputs(
        engine,
        result,
        tmp_path / "insert.pdf",
        tmp_path / "output",
        "IGCSE",
        "English_9093",
        "paper-1",
        "9093_s24_qp_12",
        question_refs=[
            (str(q1), "Q1: Read Text A. Answer the question."),
            (str(q2), "Q2: Read Text B."),
        ],
    )

    assert summary["whole_pages"] == 0
    assert summary["sections"] == 2
    assert (q1 / "paper_Q1_IN.webp").is_file()
    assert (q2 / "paper_Q2_IN.webp").is_file()
    assert not list((tmp_path / "output").rglob("_insert"))
    assert not list((tmp_path / "output").rglob("IN"))

    with Image.open(q1 / "paper_Q1_IN.webp") as im:
        red = im.convert("RGB").getpixel((10, 10))
    with Image.open(q2 / "paper_Q2_IN.webp") as im:
        blue = im.convert("RGB").getpixel((10, 10))
    assert red[0] > red[2] + 80
    assert blue[2] > blue[0] + 80


def test_insert_preamble_links_all_explicitly_named_questions(tmp_path, monkeypatch):
    folders = []
    for qn in (1, 2, 3):
        folder = tmp_path / "output" / "Topic" / f"paper_Q{qn}"
        folder.mkdir(parents=True)
        folders.append(folder)

    section = InsertSection("Text C", "Text", 0, 100.0, 600.0, "Text C content")
    result = InsertResult(
        sections=[section],
        page_texts=[
            "Read Text C, and then answer Questions 2(a)-(d) and Question 3 "
            "on the question paper. Text C: a short passage."
        ],
    )
    engine = InsertEngine(target_width=2280, quality=95)
    monkeypatch.setattr(
        engine,
        "_section_image",
        lambda _pdf, _section: Image.new("RGB", (2280, 120), "white"),
    )

    summary = write_insert_outputs(
        engine, result, tmp_path / "insert.pdf", tmp_path / "output",
        "IGCSE", "English_0500", "paper-1", "0500_s24_qp_12",
        question_refs=[
            (str(folders[0]), "Question 1 body, no text reference."),
            (str(folders[1]), "Question 2 body, Text C prompt."),
            (str(folders[2]), "Question 3 body, prompt was on the insert."),
        ],
    )

    assert summary["sections"] == 2
    assert not (folders[0] / "paper_Q1_IN.webp").exists()
    assert (folders[1] / "paper_Q2_IN.webp").is_file()
    assert (folders[2] / "paper_Q3_IN.webp").is_file()


def test_source_linking_reads_only_the_question_page_band():
    ctx = DocumentContext(
        path="synthetic.pdf", filename="synthetic.pdf", stem="synthetic", suffix=".pdf",
        layout={"pages": [{
            "page_index": 0,
            "text": "Read Text A\\nQ1 body\\nRead Text B\\nQ2 body",
            "lines": [
                {"text": "Read Text A", "bbox": [48, 50, 180, 66]},
                {"text": "Q1 body", "bbox": [48, 90, 150, 106]},
                {"text": "Read Text B", "bbox": [48, 250, 180, 266]},
                {"text": "Q2 body", "bbox": [48, 290, 150, 306]},
            ],
        }]},
    )
    segments = [
        {"question_number": 1, "canonical_question": "Q1",
         "pages": [{"page_index": 0, "rect": (0, 0, 600, 200)}]},
        {"question_number": 2, "canonical_question": "Q2",
         "pages": [{"page_index": 0, "rect": (0, 200, 600, 400)}]},
    ]
    sources = [
        TextCompanion(1, "Text A", "Text A content", [0], 0.9, "synthetic"),
        TextCompanion(2, "Text B", "Text B content", [0], 0.9, "synthetic"),
    ]
    links = link_sources_to_questions(ctx, segments, sources)
    linked = {int(row["question_number"]):
              [item["source"]["canonical_question"] for item in row["sources"]]
              for row in links}
    assert linked == {1: ["Text A"], 2: ["Text B"]}


def test_insert_label_requires_a_whole_label_match():
    source_a = InsertSection("Source A", "Source", 0, 0.0, 100.0)
    source_ab = InsertSection("Source AB", "Source", 0, 100.0, 200.0)
    assert referenced_sections("Use Source AB now.", [source_a, source_ab]) == [source_ab]


def test_universal_insert_index_does_not_create_a_user_facing_in_tree(tmp_path):
    import tools.run_universal_batch as batch

    pdf = tmp_path / "source_insert.pdf"
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((48, 80), "Source A")
    page.insert_text((48, 110), "A short source passage for the question.")
    doc.save(pdf)
    doc.close()
    output = tmp_path / "output"
    ident = SimpleNamespace(board="AQA", component="8462_1H", season="June", year="2023")

    scratch = tmp_path / "scratch"
    result = batch._write_insert_source_index(pdf, ident, output, scratch_dir=scratch)

    assert result["document_type"] == "IN"
    assert str(result["output_dir"]).startswith(str(scratch))
    assert not (output / "final").exists()
    assert list(scratch.rglob("*.webp"))


def test_universal_insert_attach_uses_question_specific_sidecars_and_removes_in_tree(tmp_path):
    import json
    import tools.run_universal_batch as batch

    output = tmp_path / "output"
    session = output / "final" / "AQA" / "8462_1H" / "June_2023"
    qp_doc = session / "QP" / "qp_source"
    qp_doc.mkdir(parents=True)
    for qn in (1, 2):
        (qp_doc / f"8462_Q{qn}.webp").write_bytes(b"crop")
    (qp_doc / "source_links.json").write_text(json.dumps([
        {"question_number": 1, "sources": [{"source": {"canonical_question": "Text A"}}]},
        {"question_number": 2, "sources": [{"source": {"canonical_question": "Text B"}}]},
    ]), encoding="utf-8")

    # Prior versions placed sections under final/.../IN; that folder is not
    # consumed and must be deleted during the migration pass.
    legacy = session / "IN" / "old_insert"
    legacy.mkdir(parents=True)
    (legacy / "stale.webp").write_bytes(b"stale")

    scratch = tmp_path / "scratch"
    section_dir = scratch / "final" / "AQA" / "8462_1H" / "June_2023" / "IN" / "insert_pdf"
    section_dir.mkdir(parents=True)
    Image.new("RGB", (2280, 80), (220, 20, 20)).save(section_dir / "insert_Text_A_IN.webp", "WEBP")
    Image.new("RGB", (2280, 80), (20, 40, 220)).save(section_dir / "insert_Text_B_IN.webp", "WEBP")

    stats = batch._attach_insert_sections(output, insert_work_dir=scratch)

    assert stats["attached"] == 2
    assert not (session / "IN").exists()
    with Image.open(qp_doc / "Q1_IN.webp") as im:
        q1_color = im.convert("RGB").getpixel((5, 5))
    with Image.open(qp_doc / "Q2_IN.webp") as im:
        q2_color = im.convert("RGB").getpixel((5, 5))
    assert q1_color[0] > q1_color[2] + 80
    assert q2_color[2] > q2_color[0] + 80


def test_real_cropping_engine_uses_the_maintained_runtime_splitter():
    # The CAIE runtime used to import the pristine original_reference splitter,
    # bypassing core.question_split.py and its crop-boundary/reference fixes.
    import core.question_split as maintained_splitter

    assert GOLD_AVAILABLE
    assert gold_question_split is maintained_splitter


def test_staging_rejects_standalone_in_or_insert_directories(tmp_path):
    (tmp_path / "IN").mkdir()
    errors = _validate_staging(tmp_path)
    assert any("standalone insert directory is forbidden" in error for error in errors)


def test_bundle_refresh_drops_stale_question_insert_sidecars(tmp_path):
    folder = tmp_path / "A-Level" / "Chemistry_9701" / "paper-1" / "Organic" / "9701_s24_qp_12_Q1"
    folder.mkdir(parents=True)
    (folder / "metadata.json").write_text("{}", encoding="utf-8")
    stale = folder / "9701_s24_qp_12_Q1_IN.webp"
    stale.write_bytes(b"old source A + B")
    current = folder / "9701_s24_qp_12_Q1.webp"
    current.write_bytes(b"current QP")

    removed = _remove_stale_question_insert_sidecars(
        tmp_path,
        [
            (str(current.relative_to(tmp_path)), str(current)),
            (str((folder / "metadata.json").relative_to(tmp_path)), str(folder / "metadata.json")),
        ],
    )

    assert removed == [str(stale)]
    assert not stale.exists()


def test_successful_rebuild_removes_only_the_matching_legacy_insert_folder(tmp_path):
    subject_root = tmp_path / "A-Level" / "Chemistry_9701"
    old_paper = subject_root / "paper-1" / "_insert" / "9701_s24_qp_12"
    other_paper = subject_root / "paper-1" / "_insert" / "9701_s24_qp_13"
    old_paper.mkdir(parents=True)
    other_paper.mkdir(parents=True)
    (old_paper / "page.webp").write_bytes(b"legacy")
    (other_paper / "page.webp").write_bytes(b"other bundle")

    removed = _remove_legacy_insert_bundle_output(
        tmp_path, "A-Level", "Chemistry_9701",
        SimpleNamespace(full_code="9701_s24_qp_12"),
    )

    assert removed == [str(old_paper)]
    assert not old_paper.exists()
    assert (other_paper / "page.webp").read_bytes() == b"other bundle"
    assert (subject_root / "paper-1" / "_insert").is_dir()
