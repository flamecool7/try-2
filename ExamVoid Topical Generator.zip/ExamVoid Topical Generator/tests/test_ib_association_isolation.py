from __future__ import annotations

from pathlib import Path

import fitz

from adapters.associations import associate_documents, identify_document
from adapters.ib.adapter import Adapter
from adapters.pipeline_dispatch import build_document_context


def _pdf(path: Path, title: str, kind: str, *, paper: str = "Paper 1") -> Path:
    doc = fitz.open()
    page = doc.new_page()
    body = [
        "International Baccalaureate",
        title,
        paper,
        "May 2026",
        kind,
    ]
    if kind == "Question Paper":
        body += ["Instructions to candidates", "Answer all questions.", "1. State one relevant concept."]
    page.insert_text((48, 48), "\n".join(body))
    doc.save(path)
    doc.close()
    return path


def test_ib_identity_is_subject_and_paper_scoped_for_qp_ms_er(tmp_path):
    bio_qp = _pdf(tmp_path / "biology-qp.pdf", "Biology", "Question Paper")
    bio_ms = _pdf(tmp_path / "biology-ms.pdf", "Biology", "Markscheme")
    bio_er = _pdf(tmp_path / "biology-er.pdf", "Biology", "Examiner Report")
    chem_qp = _pdf(tmp_path / "chemistry-qp.pdf", "Chemistry", "Question Paper")

    ids = [identify_document(p) for p in (bio_qp, bio_ms, bio_er, chem_qp)]
    assert [(i.board, i.document_type, i.syllabus_code, i.component) for i in ids] == [
        ("IB", "QP", "IBBI", "IBBI/P1"),
        ("IB", "MS", "IBBI", "IBBI/P1"),
        ("IB", "ER", "IBBI", "IBBI/P1"),
        ("IB", "QP", "IBCH", "IBCH/P1"),
    ]

    groups = associate_documents((bio_qp, bio_ms, bio_er, chem_qp))
    biology = groups["IB|IBBI/P1|May|2026"]
    chemistry = groups["IB|IBCH/P1|May|2026"]
    assert set(biology["documents"]) == {"QP", "MS", "ER"}
    assert set(chemistry["documents"]) == {"QP"}
    assert not biology["review_required"]
    assert not chemistry["review_required"]


def test_ib_identity_reads_title_after_a_license_notice_cover_page(tmp_path):
    path = tmp_path / "paper.pdf"
    doc = fitz.open()
    page = doc.new_page()
    page.insert_textbox((48, 48, 540, 780),
                        "© International Baccalaureate Organization 2025\n"
                        "All rights reserved. No part of this product may be reproduced.", fontsize=11)
    page = doc.new_page()
    page.insert_textbox((48, 48, 540, 780),
                        "13 May 2025\nBiology\nHigher level\nPaper 2\n"
                        "Instructions to candidates\nAnswer all questions.", fontsize=11)
    doc.save(path)
    doc.close()

    identity = identify_document(path)
    assert (identity.board, identity.document_type, identity.syllabus_code,
            identity.component, identity.season, identity.year) == (
        "IB", "QP", "IBBI", "IBBI/P2", "May", "2025",
    )


def test_ib_qp_segmentation_ignores_numbered_citations_after_reference_tail(tmp_path):
    path = tmp_path / "biology-paper.pdf"
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((48, 48), "© International Baccalaureate Organization 2025\nAll rights reserved.")
    page = doc.new_page()
    page.insert_text((48, 48),
                     "13 May 2025\nBiology\nHigher level\nPaper 2\n"
                     "Instructions to candidates\nAnswer all questions.\n1. First question")
    page = doc.new_page()
    page.insert_text((48, 48), "– 2 –\n2. Second question")
    page.insert_text((82, 100), "1. Indented response item")
    page.insert_text((82, 120), "2. Another indented item")
    page = doc.new_page()
    page.insert_text((48, 48), "Disclaimer:\nReference material follows.\nReferences:\n2. Author, 2020.\n3. Source, 2021.")
    doc.save(path)
    doc.close()

    segments = Adapter().segment(build_document_context(path))
    assert [segment["question_number"] for segment in segments] == [1, 2]
    assert all(page["page_index"] != 3 for segment in segments for page in segment["pages"])


def test_unscoped_ib_report_is_reviewed_not_attached_by_subject_guess(tmp_path):
    bio_qp = _pdf(tmp_path / "biology-qp.pdf", "Biology", "Question Paper")
    subject_er = _pdf(tmp_path / "biology-er.pdf", "Biology", "Examiner Report", paper="")

    qp = identify_document(bio_qp)
    er = identify_document(subject_er)
    assert qp.component == "IBBI/P1"
    assert er.component == "IBBI/UNSCOPED"

    groups = associate_documents((bio_qp, subject_er))
    er_group = groups["IB|IBBI/UNSCOPED|May|2026"]
    assert er_group["review_required"] is True
    assert any("not attached by subject guess" in note for note in er_group["notes"])
    assert "ER" not in groups["IB|IBBI/P1|May|2026"]["documents"]
