"""The catalogue covers every IB DP profile without duplicate subject rows."""
from __future__ import annotations

import json
from pathlib import Path

from tools.generate_subjects_catalogue import ROOT, build_catalogue


def _catalogue() -> dict:
    return json.loads((ROOT / "subjects.json").read_text(encoding="utf-8"))


def test_ib_catalogue_is_one_canonical_row_per_profile_and_preserves_other_boards():
    current = _catalogue()
    reconciled = build_catalogue(current)
    current_non_ib = [r for r in current["subjects"] if r.get("board") != "IB"]
    next_non_ib = [r for r in reconciled["subjects"] if r.get("board") != "IB"]
    assert next_non_ib == current_non_ib

    ib_rows = [r for r in reconciled["subjects"] if r.get("board") == "IB"]
    profiles = sorted(Path(ROOT / "subjects_ib/DP").glob("*/config.json"))
    assert len(ib_rows) == len(profiles) == 30
    assert len({r["code"] for r in ib_rows}) == 30
    assert all(r["catalogue_status"] == "PROFILE" for r in ib_rows)
    assert all((ROOT / r["profile"]).is_file() for r in ib_rows)
    assert reconciled["counts"]["IB"] == 30
    assert reconciled["counts"]["total"] == len(reconciled["subjects"])


def test_legacy_taxonomy_codes_are_aliases_and_do_not_create_duplicate_rows():
    reconciled = build_catalogue(_catalogue())
    by_code = {r["code"]: r for r in reconciled["subjects"] if r.get("board") == "IB"}

    assert "Biology" in by_code["IBBI"]["aliases"]
    assert "Mathematics_Analysis_and_Approaches" in by_code["IBMA"]["aliases"]
    assert by_code["IBBI"]["legacy_taxonomy_references"][0]["reference_exists"] is False
    assert all(r.get("catalogue_status") != "TAXONOMY_ONLY" for r in by_code.values())


def test_catalogue_consumers_resolve_ib_aliases_to_canonical_profile_rows():
    # Use the generated in-memory payload to verify both code lookup contracts.
    reconciled = build_catalogue(_catalogue())
    profile = next(r for r in reconciled["subjects"] if r.get("code") == "IBMA")
    aliases = set(profile["aliases"])
    assert "Mathematics_Analysis_and_Approaches" in aliases

    # The production helper functions read subjects.json, so exercise them after
    # the repository file has been reconciled by the generation step.
    from tools import build_topical_index, detect_subjects

    catalogue_codes = build_topical_index._catalogue_codes()
    catalogue_rows = build_topical_index._catalogue_rows()
    detector_rows = detect_subjects._catalogue_index()
    assert "Mathematics_Analysis_and_Approaches" in catalogue_codes["IB"]
    assert catalogue_rows[("IB", "Mathematics_Analysis_and_Approaches")]["code"] == "IBMA"
    assert detector_rows["Biology"][0]["code"] == "IBBI"


def test_profile_codes_are_unique_and_every_profile_has_classifiable_topics():
    ib_rows = [r for r in _catalogue()["subjects"] if r.get("board") == "IB"]
    assert len(ib_rows) == 30
    for row in ib_rows:
        cfg = json.loads((ROOT / row["profile"]).read_text(encoding="utf-8"))
        assert cfg["syllabus_code"] == row["code"]
        assert cfg.get("major_topics")
        assert cfg.get("classification_keywords")


def test_all_ib_topics_route_their_own_profile_keyword_in_self_consistency_audit():
    from tools.audit_ib_profile_consistency import run_audit

    payload = run_audit()
    summary = payload["summary"]
    assert payload["profiles_found"] == payload["profiles_loaded"] == 30
    assert summary["sampled_topic_cases"] == 554
    assert summary["errors"] == 0
    assert summary["reviews"] == 0
    assert summary["self_matches"] == 554
    # These are profile-derived smoke phrases, not independent accuracy labels.
    assert payload["audit_type"] == "taxonomy_derived_self_consistency_not_external_accuracy"
