"""Golden regression set for Digital SAT domain classification.

The 33 cases are derived from College Board's Digital SAT Sample Questions and
Answer Explanations. Expected domains/skills are the official labels printed in
that source. The adapter under test is the same profile-backed TopicClassifier
wrapper used by the SAT segment path; this measures coverage on a small labeled
set, not universal or future-paper accuracy.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from types import SimpleNamespace

from adapters.sat.classification import (
    _sat_segment_math_signals,
    classify_segments,
    classify_text,
)
from adapters.sat.adapter import Adapter as SATAdapter, _has_ink_to_the_left, _question_marker_number

ROOT = Path(__file__).resolve().parents[1]
GOLDEN_PATH = ROOT / "tests" / "fixtures" / "sat_college_board_sample_golden.json"
GOLDEN = json.loads(GOLDEN_PATH.read_text(encoding="utf-8"))


def test_official_college_board_sample_domains_are_automatically_classified():
    cases = GOLDEN["cases"]
    assert len(cases) == 33
    results = []
    for case in cases:
        question_number = int(re.search(r"\d+$", case["id"]).group())
        module_component = "RWM1" if case["spec"] == "SATR" else "MATHM1"
        result = classify_text(
            case["spec"], case["text"], question_number=question_number,
            component=module_component,
        )
        results.append((case, result))

    # High-coverage acceptance criterion on this official labeled sample: do not
    # silently route any item to the wrong folder, and avoid review for these
    # sufficiently text-rich cases. Real PDFs with weak/missing text still retain
    # the classifier's REVIEW_REQUIRED fallback.
    assert all(result["status"] == "HINT" for _, result in results)
    assert all(result["topic"] == case["expected_topic"] for case, result in results)
    assert all(0.0 <= result["confidence"] < 1.0 for _, result in results)

    # Skills are narrower than the domain taxonomy. On this in-sample official
    # sample, emit a skill hint only where a distinctive stem cue exists; the
    # one ambiguous grammar stem intentionally remains review-required.
    skill_hints = [(case, result) for case, result in results
                   if result["skill_status"] == "HINT"]
    assert len(skill_hints) == 32
    for case, result in skill_hints:
        expected = case["official_skill"]
        # The current College Board taxonomy splits the sample PDF's combined
        # nonlinear-equations label into its two more specific skill buckets.
        if expected == "Nonlinear equations in one variable and systems of equations in two variables":
            assert result["skill"] in {
                "Nonlinear equations in one variable", "Systems of equations in two variables"}
        else:
            assert result["skill"] == expected
    assert sum(r["skill_status"] == "REVIEW_REQUIRED" for _, r in results) == 1


def test_segment_classification_routes_each_section_to_its_sat_profile():
    rw_text = "As used in the text, what does the word quality most nearly mean?"
    math_text = "The scatterplot shows the relationship between variables; use the line of best fit."
    ctx = SimpleNamespace(layout={"pages": [{
        "text": rw_text + "\n" + math_text,
        "lines": [
            {"text": rw_text, "bbox": [10.0, 10.0, 400.0, 30.0]},
            {"text": math_text, "bbox": [10.0, 60.0, 400.0, 80.0]},
        ],
    }]})
    segments = [
        {"question_number": 7, "section": "RW", "module": 1,
         "pages": [{"page_index": 0, "rect": [0.0, 0.0, 500.0, 45.0]}]},
        {"question_number": 13, "section": "MATH", "module": 1,
         "pages": [{"page_index": 0, "rect": [0.0, 50.0, 500.0, 90.0]}]},
    ]

    rw, math = classify_segments(ctx, segments, component="SAT_T1")
    assert (rw["spec"], rw["topic"], rw["status"]) == (
        "SATR", "Craft_and_Structure", "HINT")
    assert (math["spec"], math["topic"], math["status"]) == (
        "SATM", "Problem_Solving_and_Data_Analysis", "HINT")
    assert rw["text_source"] == math["text_source"] == "rect"


def test_weak_or_missing_text_keeps_review_fallback():
    result = classify_text("SATR", "", question_number=1, component="RWM1")
    assert result["topic"] == "UNKNOWN"
    assert result["status"] == "REVIEW_REQUIRED"
    assert result["confidence"] == 0.0


def test_hyphen_before_sat_question_number_is_part_of_marker_not_content():
    # Observed in College Board SAT Practice Test 5: the ``-`` is a tab glyph
    # immediately before the printed question number, so it must not cause the
    # adapter to discard Q1 and every following question in that module.
    lines = [
        ("-", (35.6, 328.4, 39.6, 341.7)),
        ("1", (42.4, 324.1, 49.8, 337.5)),
    ]
    assert not _has_ink_to_the_left(lines, 42.4, 324.1, 337.5, 0)

    # But normal text before a number remains a content cue, not a question tab.
    content_lines = [
        ("x", (35.6, 328.4, 39.6, 341.7)),
        ("1", (42.4, 324.1, 49.8, 337.5)),
    ]
    assert _has_ink_to_the_left(content_lines, 42.4, 324.1, 337.5, 0)


def test_sat_question_marker_with_dashes_in_one_text_span_is_read():
    # College Board Practice Test 7 merges its Q23 tab and the horizontal rule
    # into one PDF text span instead of exposing a standalone digit marker.
    assert _question_marker_number("- 23 - - - -") == 23
    assert _question_marker_number("−24—") == 24
    # Test 9 combines the question number with punctuation/rules in one text span.
    assert _question_marker_number(". 1 ,") == 1
    assert _question_marker_number(". 2 , ________") == 2
    assert _question_marker_number("23 + 4") is None
    assert _question_marker_number("question 23") is None


def test_test7_calibration_error_regressions():
    # These are diagnostic examples from Test 7, which was used to tune the
    # broad-domain rules. Practice Test 8 was later used for calibration; Test 10
    # is the current independent holdout.
    cases = [
        ("SATR", "While researching a topic, a student has taken notes. The student wants to use a quotation to challenge a claim. Which choice uses relevant information from the notes?", 32, "RWM1", "Expression_of_Ideas", "HINT", "Rhetorical Synthesis"),
        ("SATM", "A box of cereal costs $2 and strawberries cost $1.90 per pound. Which of the following equations can be used to find p, the number of pounds, if the total cost is $9.60?", 4, "MATHM1", "Algebra", "HINT", None),
        ("SATM", "What is an x-coordinate of an x-intercept of the graph of y = 3(x - 14)(x + 5)(x + 4)?", 7, "MATHM1", "Advanced_Math", "HINT", None),
        ("SATM", "The function f is defined by f(x) = 1/2(x + 6). What is the value of f(4)?", 10, "MATHM1", "UNKNOWN", "REVIEW_REQUIRED", None),
        ("SATM", "The graph of a system of an absolute value function and a linear function is shown. What is the solution to this system of two equations?", 11, "MATHM1", "Advanced_Math", "HINT", None),
        ("SATM", "An attendee won S square tokens and C circle tokens worth a total of 1,120 points. The equation 80S + 90C = 1,120 represents this situation. How many more points is a circle token worth than a square token?", 11, "MATHM2", "Algebra", "HINT", None),
        ("SATM", "In the given system of equations, k is a positive integer constant. The system has no real solutions. What is the least possible value of k?", 27, "MATHM2", "Advanced_Math", "HINT", None),
    ]
    for spec, text, number, component, topic, status, skill in cases:
        result = classify_text(spec, text, question_number=number, component=component)
        assert (result["topic"], result["status"]) == (topic, status)
        if skill is not None:
            assert (result["skill"], result["skill_status"]) == (skill, "HINT")


def test_sat_math_layout_signal_distinguishes_baseline_x_from_superscript():
    baseline = SimpleNamespace(layout={"pages": [{"lines": [
        {"text": "The function g is defined by", "bbox": [10, 100, 110, 114]},
        {"text": "x", "bbox": [120, 100, 126, 110]},
        {"text": "( ) = 6", "bbox": [126, 100, 160, 114]},
    ]}]})
    raised = SimpleNamespace(layout={"pages": [{"lines": [
        {"text": "The function f is defined by f x = 8x", "bbox": [10, 200, 145, 214]},
        {"text": "3", "bbox": [146, 197, 151, 205]},
        {"text": "+ 4", "bbox": [153, 200, 170, 214]},
    ]}]})
    segment = {"pages": [{"page_index": 0, "rect": [0, 90, 200, 130]}]}
    raised_segment = {"pages": [{"page_index": 0, "rect": [0, 190, 200, 230]}]}

    assert _sat_segment_math_signals(baseline, segment)["superscript_exponent"] is False
    assert _sat_segment_math_signals(raised, raised_segment)["superscript_exponent"] is True

    linear = classify_text(
        "SATM", "The function g is defined by g(x)=6x. For what value of x is g(x)=54?",
        question_number=6, component="MATHM2", math_signals={"superscript_exponent": False})
    nonlinear = classify_text(
        "SATM", "The function f is defined by f(x)=8x^3+4. What is the value of f(2)?",
        question_number=7, component="MATHM2", math_signals={"superscript_exponent": True})
    assert (linear["topic"], linear["status"]) == ("Algebra", "HINT")
    assert (nonlinear["topic"], nonlinear["status"]) == ("Advanced_Math", "HINT")


def test_sat_system_skill_beats_generic_value_of_x_skill_cue():
    result = classify_text(
        "SATM",
        "The solution to the given system of equations is (x, y). What is the value of x?",
        question_number=11,
        component="MATHM2",
    )
    assert result["topic"] == "Algebra"
    assert (result["skill"], result["skill_status"]) == (
        "Systems of two linear equations in two variables", "HINT")


def test_sat_module_ranges_accept_section_before_module_heading_and_ignore_timing_schedule():
    ctx = SimpleNamespace(layout={"pages": [
        {"text": "The questions in this section address a number of important reading and writing skills.\n"
                 "Reading and Writing\n33 QUESTIONS\nModule\n1\n", "lines": []},
        {"text": "CONTINUE\nModule\n1\n", "lines": []},
        {"text": "The questions in this section address a number of important reading and writing skills.\n"
                 "Reading and Writing\n33 QUESTIONS\nModule\n2\n", "lines": []},
        {"text": "The questions in this section address a number of important math skills.", "lines": []},
        {"text": "CONTINUE\nModule\n1\n", "lines": []},
        {"text": "CONTINUE\nModule\n2\n", "lines": []},
        {"text": "GENERAL DIRECTIONS\nReading and Writing, Module 1: 39 minutes\n"
                 "Math, Module 2: 43 minutes\n", "lines": []},
    ]})

    modules = SATAdapter()._module_ranges(ctx)
    assert [(m["section"], m["module"], m["start_page"], m["declared_count"])
            for m in modules] == [
        ("RW", 1, 0, 33),
        ("RW", 2, 2, 33),
        ("MATH", 1, 4, None),
        ("MATH", 2, 5, None),
    ]


def test_sat_module_ranges_keep_legacy_module_before_section_heading():
    ctx = SimpleNamespace(layout={"pages": [
        {"text": "Module 1\nReading and Writing\n27 QUESTIONS", "lines": []},
        {"text": "CONTINUE\nModule 1\n", "lines": []},
        {"text": "Module 2\nReading and Writing\n27 QUESTIONS", "lines": []},
        {"text": "Module 1\nMath\n22 QUESTIONS", "lines": []},
        {"text": "CONTINUE\nModule 1\n", "lines": []},
        {"text": "Module 2\nMath\n22 QUESTIONS", "lines": []},
    ]})

    modules = SATAdapter()._module_ranges(ctx)
    assert [(m["section"], m["module"], m["start_page"], m["declared_count"])
            for m in modules] == [
        ("RW", 1, 0, 27),
        ("RW", 2, 2, 27),
        ("MATH", 1, 3, 22),
        ("MATH", 2, 5, 22),
    ]


def test_sat_module_intro_answer_instructions_do_not_become_a_phantom_q1(monkeypatch):
    pages = [
        {"text": "The questions in this section address a number of important math skills.\n"
                 "Module 1\nFor multiple-choice questions, solve each problem, choose the correct\nanswer.",
         "lines": [], "size": [612, 792]},
        {"text": "CONTINUE\nModule 1\nActual first question", "lines": [], "size": [612, 792]},
        {"text": "CONTINUE\nModule 2\n", "lines": [], "size": [612, 792]},
    ]
    ctx = SimpleNamespace(layout={"pages": pages})
    adapter = SATAdapter()
    monkeypatch.setattr(adapter, "_question_positions", lambda _ctx, p:
                        [(1, 200.0, 40.0, 0)] if p in (0, 1) else [])

    segments = adapter.segment(ctx)
    assert len(segments) == 1
    assert segments[0]["question_number"] == 1
    assert segments[0]["pages"][0]["page_index"] == 1


def test_sat_explicit_domain_rules_cover_clear_reading_and_math_stems():
    cases = [
        ("SATR", "A short passage describes an unusual animal behavior. Which choice best states the main topic of the text?",
         "Information_and_Ideas"),
        ("SATR", "According to the graph, which city had the largest population in 1891?",
         "Information_and_Ideas"),
        ("SATR", "Which finding, if true, would most strongly support the researchers' claim?",
         "Information_and_Ideas"),
        ("SATM", "Which equation has the same solution as the given equation?",
         "Algebra"),
        ("SATM", "A student gave 10% of the harvested tomatoes away. How many did the student give away?",
         "Problem_Solving_and_Data_Analysis"),
        ("SATM", "A random sample of 300 customers was surveyed. What is the best estimate for the population?",
         "Problem_Solving_and_Data_Analysis"),
        ("SATM", "Two lines intersect, forming acute and obtuse angles. What is the sum of two angles?",
         "Geometry_and_Trigonometry"),
        ("SATM", "In triangle QRS, which expression represents the length of a side using cos Q?",
         "Geometry_and_Trigonometry"),
        ("SATM", "A circle in the xy-plane has a given radius. What is the equation of the circle?",
         "Geometry_and_Trigonometry"),
        ("SATM", "The given linear equations model two quantities. Which graph represents this situation?",
         "Algebra"),
        ("SATM", "The population doubled every 75 years. What was its population at the earlier date?",
         "Advanced_Math"),
        ("SATM", "The equation models bacteria in a growth medium with a positive constant. What was the initial amount?",
         "Advanced_Math"),
        ("SATM", "Which equation gives the number of players eliminated at the end of round r?",
         "Advanced_Math"),
        ("SATM", "A dot plot shows measured diameters. How many observations equal 16 inches?",
         "Problem_Solving_and_Data_Analysis"),
        ("SATM", "Convert square nautical miles to square kilometers using the given conversion rate.",
         "Problem_Solving_and_Data_Analysis"),
        # A repeated percentage change in a function is exponential, not a basic percent-of question.
        ("SATM", "For a function, each increase in x by 1 makes its value decrease by 80%. What is f(2)?",
         "Advanced_Math"),
    ]
    for spec, text, expected in cases:
        result = classify_text(spec, text, question_number=1, component="RWM1" if spec == "SATR" else "MATHM1")
        assert (result["topic"], result["status"]) == (expected, "HINT"), (text, result)

