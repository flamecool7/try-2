from __future__ import annotations

import hashlib
import json
from pathlib import Path

import fitz

from adapters.associations import identify_document
from tools.crop_noncaie_segments import build_context
from tools.run_universal_batch import (_attach_insert_sections, _process_document)


def _pdf(path: Path, kind: str, body: list[str], *, subject: str = "Biology") -> Path:
    doc = fitz.open()
    page = doc.new_page()
    page.insert_textbox(
        (42, 42, 550, 780),
        "\n".join(["International Baccalaureate", subject, "Paper 1", "May 2026", kind, *body]),
        fontsize=11,
    )
    doc.save(path)
    doc.close()
    return path


def test_ib_worker_processes_exact_qp_ms_er_bundle_in_one_task(tmp_path):
    qp = _pdf(tmp_path / "biology-qp.pdf", "Question Paper", [
        "Instructions to candidates", "Answer all questions.",
        "1. Explain how DNA replication copies genetic information.",
    ])
    ms = _pdf(tmp_path / "biology-ms.pdf", "Markscheme", [
        "1. [1] DNA strands separate. A1",
    ])
    er = _pdf(tmp_path / "biology-er.pdf", "Examiner Report", [
        "Examiner report", "Paper 1", "Question 1",
        "Candidates should refer to DNA replication.",
    ])
    ident = identify_document(qp)
    assert ident.component == "IBBI/P1"

    outcome = _process_document({
        "pdf": str(qp),
        "ident": ident,
        "output_dir": str(tmp_path / "output"),
        "ctx": build_context(qp),
        "ib_bundle": {"ms_pdf": str(ms), "er_pdf": str(er)},
        "pdf_sha256": "",
        "use_cache": False,
        "limit": 0,
    })

    assert outcome["kind"] == "ib_bundle"
    assert outcome["result"]["board"] == "IB"
    assert outcome["ms_result"]["document_type"] == "MS"
    assert outcome["er_result"]["document_type"] == "ER"
    assert outcome["er_binding"]["authorized"] is True
    qp_identity = Path(outcome["result"]["output_dir"]) / "ib_bundle_identity.json"
    er_identity = Path(outcome["er_result"]["output_dir"]) / "document_identity.json"
    assert qp_identity.is_file() and er_identity.is_file()
    expected_scope = "/final/IB/IBBI_P1/May_2026/"
    assert expected_scope in outcome["result"]["output_dir"].replace("\\", "/")
    assert expected_scope in outcome["ms_result"]["output_dir"].replace("\\", "/")
    assert expected_scope in outcome["er_result"]["output_dir"].replace("\\", "/")


def test_universal_pdf_pipeline_keeps_ib_er_inside_its_subject_bundle(tmp_path):
    from tools.run_universal_batch import run_batch

    input_dir = tmp_path / "input"
    output_dir = tmp_path / "output"
    input_dir.mkdir()
    _pdf(input_dir / "biology-qp.pdf", "Question Paper", [
        "Instructions to candidates", "Answer all questions.",
        "1. Explain how DNA replication copies genetic information.",
    ])
    _pdf(input_dir / "biology-ms.pdf", "Markscheme", ["1. [1] DNA strands separate. A1"])
    _pdf(input_dir / "biology-er.pdf", "Examiner Report", [
        "Examiner report", "Paper 1", "Question 1", "Candidates should refer to DNA replication.",
    ])
    _pdf(input_dir / "chemistry-qp.pdf", "Question Paper", [
        "Instructions to candidates", "Answer all questions.",
        "1. Explain the role of a catalyst in a chemical reaction.",
    ], subject="Chemistry")
    _pdf(input_dir / "chemistry-ms.pdf", "Markscheme", [
        "1. [1] A catalyst provides an alternative pathway. A1",
    ], subject="Chemistry")

    audit = run_batch(input_dir, output_dir, include_ib=True, limit_per_paper=1,
                      jobs=1, use_cache=False)
    assert audit["counts"]["render_attempts"] == 2
    assert audit["counts"]["er_attached"] == 1
    groups = audit["associations"]
    assert "ER" in groups["IB|IBBI/P1|May|2026"]["documents"]
    assert "ER" not in groups["IB|IBCH/P1|May|2026"]["documents"]

    er_files = list((output_dir / "final" / "IB").rglob("Q1_ER.webp"))
    assert er_files
    assert all("IBBI_P1" in str(path) for path in er_files)
    assert not list((output_dir / "final" / "IB" / "IBCH_P1").rglob("*_ER.webp"))


def test_ib_er_copy_time_guard_rejects_stale_and_wrong_subject_artifacts(tmp_path):
    from tools.run_universal_batch import _canonical_file_id

    source_dir = tmp_path / "sources"
    source_dir.mkdir()
    qp = _pdf(source_dir / "biology-qp.pdf", "Question Paper", [
        "Instructions to candidates", "Answer all questions.", "1. Explain DNA replication.",
    ])
    er = _pdf(source_dir / "biology-er.pdf", "Examiner Report", [
        "Examiner report", "Paper 1", "Question 1", "DNA replication was understood.",
    ])
    wrong_er = _pdf(source_dir / "chemistry-er.pdf", "Examiner Report", [
        "Examiner report", "Paper 1", "Question 1", "Catalysts were misunderstood.",
    ], subject="Chemistry")
    qp_ident = identify_document(qp)
    er_ident = identify_document(er)
    wrong_ident = identify_document(wrong_er)
    assert qp_ident.association_key == er_ident.association_key
    assert wrong_ident.association_key != qp_ident.association_key

    output = tmp_path / "output"
    session = output / "final" / "IB" / "IBBI_P1" / "May_2026"
    good_qp = session / "QP" / "biology-paper"
    stale_qp = session / "QP" / "stale-paper"
    good_er = session / "ER" / "biology-report"
    wrong_er_dir = session / "ER" / "misfiled-chemistry-report"
    for folder in (good_qp, stale_qp, good_er / "SECTIONS", wrong_er_dir / "SECTIONS"):
        folder.mkdir(parents=True, exist_ok=True)

    qp_crop = good_qp / "IBBI_P1_May_2026_Q1.webp"
    qp_crop.write_bytes(b"qp crop")
    (stale_qp / "IBBI_P1_May_2026_Q1.webp").write_bytes(b"stale qp crop")

    qp_sha = hashlib.sha256(qp.read_bytes()).hexdigest()
    er_sha = hashlib.sha256(er.read_bytes()).hexdigest()
    wrong_sha = hashlib.sha256(wrong_er.read_bytes()).hexdigest()
    (good_qp / "ib_bundle_identity.json").write_text(json.dumps({
        "schema": 1, "board": "IB", "qp_association_key": qp_ident.association_key,
        "qp_source_pdf": str(qp.resolve()), "qp_source_sha256": qp_sha,
        "er": {"authorized": True, "association_key": er_ident.association_key,
               "source_pdf": str(er.resolve()), "source_sha256": er_sha},
    }), encoding="utf-8")
    (good_er / "document_identity.json").write_text(json.dumps({
        "schema": 1, "board": "IB", "document_type": "ER",
        "association_key": er_ident.association_key, "source_pdf": str(er.resolve()),
        "source_sha256": er_sha,
    }), encoding="utf-8")
    (good_er / "SECTIONS" / "IBBI_P1_May_2026_Q1_ER.webp").write_bytes(b"biology ER crop")

    # This artifact is physically under the Biology session path, but its actual
    # PDF identity says Chemistry. The copy-time re-identification must reject it.
    (wrong_er_dir / "document_identity.json").write_text(json.dumps({
        "schema": 1, "board": wrong_ident.board, "document_type": wrong_ident.document_type,
        "association_key": wrong_ident.association_key, "source_pdf": str(wrong_er.resolve()),
        "source_sha256": wrong_sha,
    }), encoding="utf-8")
    (wrong_er_dir / "SECTIONS" / "IBCH_P1_May_2026_Q1_ER.webp").write_bytes(b"chemistry ER crop")

    stats = _attach_insert_sections(output)
    assert stats["er_attached"] == 1
    assert (good_qp / "Q1_ER.webp").read_bytes() == b"biology ER crop"
    assert not (stale_qp / "Q1_ER.webp").exists()
    assert len(stats["er_identity_rejections"]) >= 2
