# Update: reference pages are excluded from QP crops

This full Topical Generator package includes the reference-page exclusion fix in the production RAM-safe/vector-first question-paper crop path. It uses the shared page classifier to filter reference pages before selecting QP markers and again during page-segment construction, and trims the final question boundary to the last question-content page. The guarded runner logs excluded pages.

## Regression and verification

- Added `tests/test_vector_first_reference_exclusion.py`, covering a question paper followed by a blank page, constants/data sheet, and terminal periodic table.
- Full test suite: **147 passed**.
- Real CAIE 9701/41 Paper 4 validation: Q9 crop uses source PDF pages 23–25; blank page 26, constants page 27, and periodic-table page 28 are excluded.

This changes future processing. Existing previously generated output crops are not rewritten until their papers are reprocessed.
