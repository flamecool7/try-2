@echo off
setlocal EnableExtensions DisableDelayedExpansion
title ExamVoid Topical Generator

rem ============================================================================
rem ExamVoid Topical Generator - primary Windows menu launcher.
rem
rem BOARD INPUT LAYOUT:
rem   input\CAIE / input\AQA / input\EDEXCEL / input\IB / input\SAT
rem CAIE uses the Cambridge pipeline; AQA, Edexcel, IB, and SAT use their
rem universal adapters. Option 3 runs each populated folder; options 12-16
rem run one board only. Keep each input folder board-specific.
rem
rem   no arguments  -> show this menu
rem   any arguments -> forward them to run_pipeline.py
rem ============================================================================

rem --- 1. work from the folder this file lives in -----------------------------
cd /d "%~dp0"
if errorlevel 1 (
    echo   [ERROR] Could not switch to the project folder: "%~dp0"
    echo   Move the extracted project to a writable local folder and try again.
    goto FATAL
)

rem --- 2. the project must be complete ---------------------------------------
if not exist "server.py" (
    echo   [ERROR] server.py is missing: this launcher must sit in the project root.
    goto FATAL
)
if not exist "run_pipeline.py" (
    echo   [ERROR] run_pipeline.py is missing: extract the complete ZIP first.
    goto FATAL
)

rem --- 3. find Python: project venv first, then the system -------------------
set "PYTHON_EXE="
set "PYTHON_ARGS="
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=.venv\Scripts\python.exe"
if not defined PYTHON_EXE if exist "venv\Scripts\python.exe" set "PYTHON_EXE=venv\Scripts\python.exe"
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where py.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
    if defined PYTHON_EXE set "PYTHON_ARGS=-3"
)
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)
if not defined PYTHON_EXE (
    echo   [ERROR] Python 3 was not found: not in .venv\ or venv\, and not on PATH.
    echo   Install Python 3.10+ with "Add python.exe to PATH" ticked, then run this again.
    goto FATAL
)

rem --- 4. folders this launcher reads and writes -----------------------------
if not defined TOPICAL_PORT set "TOPICAL_PORT=8765"
if not defined TOPICAL_DATA set "TOPICAL_DATA=%CD%\_app_data"
if not defined TOPICAL_BATCH_OUT set "TOPICAL_BATCH_OUT=%CD%\output"
set "IN_DIR=%CD%\input"
set "CAIE_DIR=%IN_DIR%\CAIE"
set "AQA_DIR=%IN_DIR%\AQA"
set "EDEXCEL_DIR=%IN_DIR%\EDEXCEL"
set "IB_DIR=%IN_DIR%\IB"
set "SAT_DIR=%IN_DIR%\SAT"
set "OUT_DIR=%TOPICAL_BATCH_OUT%"
if not exist "%TOPICAL_DATA%" mkdir "%TOPICAL_DATA%" 2>nul
if not exist "%TOPICAL_DATA%" (
    echo   [ERROR] Could not create the data folder: "%TOPICAL_DATA%"
    echo   Set TOPICAL_DATA to a folder this user can write to, then run this again.
    goto FATAL
)
if not exist "%IN_DIR%" mkdir "%IN_DIR%" 2>nul
if not exist "%CAIE_DIR%" mkdir "%CAIE_DIR%" 2>nul
if not exist "%AQA_DIR%" mkdir "%AQA_DIR%" 2>nul
if not exist "%EDEXCEL_DIR%" mkdir "%EDEXCEL_DIR%" 2>nul
if not exist "%IB_DIR%" mkdir "%IB_DIR%" 2>nul
if not exist "%SAT_DIR%" mkdir "%SAT_DIR%" 2>nul

rem --- 5. arguments go straight to the pipeline -------------------------------
if not "%~1"=="" goto FORWARD

rem --- 6. soft dependency check: warn, never block ----------------------------
"%PYTHON_EXE%" %PYTHON_ARGS% -c "import fitz, PIL, numpy" >nul 2>nul
if errorlevel 1 (
    echo   [WARN] Some Python packages are not installed yet; the build options
    echo          stay unavailable until this succeeds once:
    echo              "%PYTHON_EXE%" -m pip install -r requirements.txt
    echo.
)

rem --- 7. the menu ------------------------------------------------------------
color 0B
:MENU
cls
echo.
echo   +------------------------------------------------------------------------+
echo   ^|  EXAMVOID  /  TOPICAL GENERATOR                                        ^|
echo   ^|  Turn question papers into organized, topic-based packs.                ^|
echo   +------------------------------------------------------------------------+
echo.
echo   PROJECT SETUP
echo   --------------------------------------------------------------------------
echo     Python   %PYTHON_EXE% %PYTHON_ARGS%
echo     Input    %IN_DIR%
echo     Output   %OUT_DIR%
echo.
echo   GET STARTED
echo   --------------------------------------------------------------------------
echo     [1]  Open the local app in your browser
echo     [2]  Open the output folder
echo.
echo   BOARD PIPELINES
echo   --------------------------------------------------------------------------
echo     [3]  Run all populated board folders through their own pipelines
echo    [12]  CAIE       %CAIE_DIR%       Cambridge pipeline
echo    [13]  AQA        %AQA_DIR%        Universal adapter pipeline
echo    [14]  EDEXCEL    %EDEXCEL_DIR%    Universal adapter pipeline
echo    [15]  IB         %IB_DIR%         Universal adapter pipeline
echo    [16]  SAT        %SAT_DIR%        Universal adapter pipeline
echo.
echo   ORGANIZE OUTPUT
echo   --------------------------------------------------------------------------
echo     [4]  Scan papers           Save a subject-detection report
echo     [5]  Refresh topical index Index the packs already in output
echo     [6]  Create a booklet      Use a booklet request JSON file
echo     [7]  Rebuild from scratch  Clears output, then runs option 3
echo.
echo   CHECK AND EXPLORE
echo   --------------------------------------------------------------------------
echo     [8]  Validate generated output
echo     [9]  Check subject configurations
echo    [10]  Run a demo for configured subjects
echo    [11]  Open full control menu  Audit, statistics, benchmark, settings
echo.
echo   [0]  Exit
echo   --------------------------------------------------------------------------
echo   Type an option number and press Enter.
echo.
set "CHOICE="
set /p "CHOICE=   Select option [0-16] ^> "
if "%CHOICE%"=="1" goto APP
if "%CHOICE%"=="2" goto OPENOUT
if "%CHOICE%"=="3" goto BATCH
if "%CHOICE%"=="4" goto SCAN
if "%CHOICE%"=="5" goto INDEX
if "%CHOICE%"=="6" goto BOOKLET
if "%CHOICE%"=="7" goto CLEAN
if "%CHOICE%"=="8" goto VALIDATE
if "%CHOICE%"=="9" goto CONFIGS
if "%CHOICE%"=="10" goto DEMO
if "%CHOICE%"=="11" goto CONTROL
if "%CHOICE%"=="12" goto CAIE_ONLY
if "%CHOICE%"=="13" goto AQA_ONLY
if "%CHOICE%"=="14" goto EDEXCEL_ONLY
if "%CHOICE%"=="15" goto IB_ONLY
if "%CHOICE%"=="16" goto SAT_ONLY
if "%CHOICE%"=="0" goto END
echo.
echo   [!] Unknown option. Choose a number from 0 to 16.
call :STOPPAUSE
goto MENU

rem ============================================================================
rem  THE APP
rem ============================================================================
:APP
echo.
echo   Starting the app on http://127.0.0.1:%TOPICAL_PORT%
echo     data folder   %TOPICAL_DATA%
echo     batch output  %TOPICAL_BATCH_OUT%
echo.
echo   The server opens in its own window; close that window to stop the app.
echo   Leave it running while you browse the packs in your browser.
echo.
start "ExamVoid Topical App" cmd /k ""%PYTHON_EXE%" %PYTHON_ARGS% server.py --host 127.0.0.1 --port %TOPICAL_PORT% --data-dir "%TOPICAL_DATA%" --root "%TOPICAL_BATCH_OUT%""
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:%TOPICAL_PORT%/"
call :STOPPAUSE
goto MENU

:OPENOUT
if not exist "%OUT_DIR%" (
    echo.
    echo   There is no output folder yet: %OUT_DIR%
    echo   Option 3 builds the packs and creates it.
    call :STOPPAUSE
    goto MENU
)
start "" explorer "%OUT_DIR%"
goto MENU

rem ============================================================================
rem  BUILD
rem ============================================================================
:BATCH
call :NEED_PDFS
if errorlevel 1 goto MENU
call :RUN_BATCH
goto MENU

:CAIE_ONLY
set "SELECTED_BOARD=CAIE"
goto RUN_ONE_BOARD

:AQA_ONLY
set "SELECTED_BOARD=AQA"
goto RUN_ONE_BOARD

:EDEXCEL_ONLY
set "SELECTED_BOARD=EDEXCEL"
goto RUN_ONE_BOARD

:IB_ONLY
set "SELECTED_BOARD=IB"
goto RUN_ONE_BOARD

:SAT_ONLY
set "SELECTED_BOARD=SAT"
goto RUN_ONE_BOARD

:RUN_ONE_BOARD
call :NEED_SELECTED_PDFS
if errorlevel 1 goto MENU
echo.
echo   Running %SELECTED_BOARD% through its board-specific pipeline...
call :RUN_SELECTED_BOARD
set "APP_EXIT=%ERRORLEVEL%"
call :REPORT_SINGLE_PIPELINE
goto MENU

:SCAN
echo.
echo   Scanning %IN_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% tools\detect_subjects.py --input "%IN_DIR%" --out "%TOPICAL_DATA%\detected_subjects.json"
echo.
echo   Report: %TOPICAL_DATA%\detected_subjects.json
call :STOPPAUSE
goto MENU

:INDEX
echo.
echo   Indexing %OUT_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% tools\build_topical_index.py --batch-out "%OUT_DIR%" --out "%TOPICAL_DATA%\topical_index.json"
echo.
echo   Index: %TOPICAL_DATA%\topical_index.json
call :STOPPAUSE
goto MENU

:BOOKLET
echo.
set "REQUEST="
set "OUT_PDF="
set /p "REQUEST=     Booklet request JSON [%TOPICAL_DATA%\draft_booklet.json]: "
if not defined REQUEST set "REQUEST=%TOPICAL_DATA%\draft_booklet.json"
set /p "OUT_PDF=     Write the PDF to [%TOPICAL_DATA%\booklet.pdf]: "
if not defined OUT_PDF set "OUT_PDF=%TOPICAL_DATA%\booklet.pdf"
echo.
"%PYTHON_EXE%" %PYTHON_ARGS% tools\build_booklet.py --booklet "%REQUEST%" --index "%TOPICAL_DATA%\topical_index.json" --out "%OUT_PDF%" --fit flow
echo.
echo   PDF: %OUT_PDF%
call :STOPPAUSE
goto MENU

:CLEAN
echo.
echo   This deletes everything in %OUT_DIR% and rebuilds all populated board folders.
set "CONFIRM="
set /p "CONFIRM=     Delete the output and build again? Type Y to continue: "
if /I not "%CONFIRM%"=="Y" goto MENU
call :NEED_PDFS
if errorlevel 1 goto MENU
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
if exist "%OUT_DIR%" (
    echo.
    echo   [ERROR] Could not delete %OUT_DIR%
    echo   A file in it is open in another program - close it and try again.
    call :STOPPAUSE
    goto MENU
)
call :RUN_BATCH
goto MENU

rem ============================================================================
rem  CHECK
rem ============================================================================
:VALIDATE
echo.
echo   Validating %OUT_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% run_guarded.py --validate --output "%OUT_DIR%"
if errorlevel 1 (
    echo.
    echo   [ERROR] Validation reported problems. The output above names them.
    call :STOPPAUSE
    goto MENU
)
echo.
echo   [OK] Validation completed.
call :STOPPAUSE
goto MENU

:CONFIGS
echo.
echo   Validating every subject configuration
"%PYTHON_EXE%" %PYTHON_ARGS% -c "from core.config_loader import validate_all_configs; print(validate_all_configs())"
if errorlevel 1 (
    echo.
    echo   [ERROR] Configuration validation failed. The report above names every problem.
    call :STOPPAUSE
    goto MENU
)
echo.
echo   [OK] Configuration validation completed.
call :STOPPAUSE
goto MENU

:DEMO
echo.
echo   Building a demo for every configured subject into %OUT_DIR%
"%PYTHON_EXE%" %PYTHON_ARGS% main.py --input "%IN_DIR%" --output "%OUT_DIR%" --demo --demo-all --clean --validate
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" (
    echo.
    echo   [OK] Demo completed. Opening %OUT_DIR%
    start "" explorer "%OUT_DIR%"
    call :STOPPAUSE
    goto MENU
)
echo.
echo   [ERROR] The demo returned error code %APP_EXIT%. The output above has the details.
call :STOPPAUSE
goto MENU

rem ============================================================================
rem  MORE
rem ============================================================================
:CONTROL
echo.
echo   Opening the full control menu. Exit it to come back here.
echo.
"%PYTHON_EXE%" %PYTHON_ARGS% run_pipeline.py --menu
call :STOPPAUSE
goto MENU

rem ============================================================================
rem  Helpers. Each one owns exactly one command, so the menu never repeats it.
rem ============================================================================
:RUN_BATCH
call :COUNT_BOARD_PDFS
"%PYTHON_EXE%" %PYTHON_ARGS% run_board_pipelines.py --input "%IN_DIR%" --output "%OUT_DIR%" --board ALL --workers 14 --jobs 14 --prune-stale-dirs
set "APP_EXIT=%ERRORLEVEL%"
call :REPORT_SINGLE_PIPELINE
exit /b %APP_EXIT%

:RUN_SELECTED_BOARD
"%PYTHON_EXE%" %PYTHON_ARGS% run_board_pipelines.py --input "%IN_DIR%" --output "%OUT_DIR%" --board "%SELECTED_BOARD%" --workers 14 --jobs 14 --prune-stale-dirs
exit /b %ERRORLEVEL%

:REPORT_SINGLE_PIPELINE
if "%APP_EXIT%"=="0" (
    echo.
    echo   [OK] Pipeline run completed.
) else if "%APP_EXIT%"=="2" (
    echo.
    echo   [WARN] Pipeline run completed with items requiring review.
) else (
    echo.
    echo   [ERROR] Pipeline returned code %APP_EXIT%.
)
if exist "%OUT_DIR%" start "" explorer "%OUT_DIR%"
call :STOPPAUSE
exit /b 0

:COUNT_BOARD_PDFS
set "CAIE_PDF_COUNT=0"
set "AQA_PDF_COUNT=0"
set "EDEXCEL_PDF_COUNT=0"
set "IB_PDF_COUNT=0"
set "SAT_PDF_COUNT=0"
if exist "%CAIE_DIR%" for /r "%CAIE_DIR%" %%F in (*.pdf) do set /a CAIE_PDF_COUNT+=1 >nul
if exist "%AQA_DIR%" for /r "%AQA_DIR%" %%F in (*.pdf) do set /a AQA_PDF_COUNT+=1 >nul
if exist "%EDEXCEL_DIR%" for /r "%EDEXCEL_DIR%" %%F in (*.pdf) do set /a EDEXCEL_PDF_COUNT+=1 >nul
if exist "%IB_DIR%" for /r "%IB_DIR%" %%F in (*.pdf) do set /a IB_PDF_COUNT+=1 >nul
if exist "%SAT_DIR%" for /r "%SAT_DIR%" %%F in (*.pdf) do set /a SAT_PDF_COUNT+=1 >nul
exit /b 0

:NEED_PDFS
call :COUNT_BOARD_PDFS
if not "%CAIE_PDF_COUNT%"=="0" exit /b 0
if not "%AQA_PDF_COUNT%"=="0" exit /b 0
if not "%EDEXCEL_PDF_COUNT%"=="0" exit /b 0
if not "%IB_PDF_COUNT%"=="0" exit /b 0
if not "%SAT_PDF_COUNT%"=="0" exit /b 0
echo.
echo   No PDFs found in the board folders under %IN_DIR%.
echo   Use CAIE, AQA, EDEXCEL, IB, or SAT subfolders, then choose this option again.
call :STOPPAUSE
exit /b 1

:NEED_SELECTED_PDFS
call :COUNT_BOARD_PDFS
if "%SELECTED_BOARD%"=="CAIE" if not "%CAIE_PDF_COUNT%"=="0" exit /b 0
if "%SELECTED_BOARD%"=="AQA" if not "%AQA_PDF_COUNT%"=="0" exit /b 0
if "%SELECTED_BOARD%"=="EDEXCEL" if not "%EDEXCEL_PDF_COUNT%"=="0" exit /b 0
if "%SELECTED_BOARD%"=="IB" if not "%IB_PDF_COUNT%"=="0" exit /b 0
if "%SELECTED_BOARD%"=="SAT" if not "%SAT_PDF_COUNT%"=="0" exit /b 0
echo.
echo   No %SELECTED_BOARD% PDFs found in %IN_DIR%\%SELECTED_BOARD%.
echo   Put that board's papers in its matching folder, then try again.
call :STOPPAUSE
exit /b 1

:STOPPAUSE
echo.
echo   Press any key to go back to the menu...
pause >nul
exit /b 0

rem ============================================================================
rem  Command-line use, diagnostics, and the two ways out
rem ============================================================================
:FORWARD
"%PYTHON_EXE%" %PYTHON_ARGS% run_pipeline.py %*
set "APP_EXIT=%ERRORLEVEL%"
if "%APP_EXIT%"=="0" goto END
echo.
echo   [ERROR] run_pipeline.py returned error code %APP_EXIT%.
echo   Press any key to close this window...
pause >nul
goto END

:FATAL
echo.
echo   Press any key to close this window...
pause >nul
exit /b 1

:END
endlocal
exit /b 0
