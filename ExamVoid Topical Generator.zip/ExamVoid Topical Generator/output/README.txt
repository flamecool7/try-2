OUTPUT FOLDER

Generated topic packs, crops, logs, and run reports are written here when you run the Topical Generator.

This clean project distribution contains no generated question crops or paper-derived output. The folder is intentionally empty apart from this note.
