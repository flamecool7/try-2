import ctypes
class M(ctypes.Structure):
    _fields_ = [('L', ctypes.c_ulong), ('Load', ctypes.c_ulong),
                ('Tot', ctypes.c_ulonglong), ('Av', ctypes.c_ulonglong),
                ('TP', ctypes.c_ulonglong), ('AP', ctypes.c_ulonglong),
                ('TV', ctypes.c_ulonglong), ('AV', ctypes.c_ulonglong),
                ('AE', ctypes.c_ulonglong)]
m = M()
m.L = ctypes.sizeof(M)
ok = ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
avail_mb = int(m.Av // (1024 * 1024))
print('GlobalMemoryStatusEx ok :', bool(ok))
print('total RAM               :', round(m.Tot / 1024**3, 2), 'GB')
print('AVAILABLE right now     :', round(m.Av / 1024**3, 2), 'GB')
print('RAM guard would allow   :', max(1, (avail_mb - 400) // 1100), 'workers')
print()
if avail_mb < 1500:
    print('  -> Something else is eating your RAM. Close it and re-check.')
elif avail_mb < 3000:
    print('  -> Only ~1-2 workers fit. Free more RAM for a fast run.')
else:
    print('  -> Plenty of room. If the pack still says 1 worker, psutil')
    print('     is missing or reporting wrong; see below.')
try:
    import psutil
    vm = psutil.virtual_memory()
    print()
    print('psutil IS installed      : total', round(vm.total/1024**3, 2),
          'GB, avail', round(vm.available/1024**3, 2), 'GB')
except ImportError:
    print()
    print('psutil NOT installed     : run  pip install psutil')
