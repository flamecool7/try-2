#!/usr/bin/env python3
"""Cross-platform RAM diagnostic - Windows, Linux and macOS.

Shows you exactly what the RAM guard in this pack sees, so you can tell the
difference between "the guard is wrong" and "something else is eating RAM".

    python3 memcheck.py
"""
from __future__ import annotations

import ctypes
import os
import platform
import sys
from pathlib import Path

PER_WORKER_MB = 1100          # mirrors core/batch_runner.py
RESERVE_MB = 400


# --------------------------------------------------------------------------
def _win_avail_mb() -> int | None:
    """GlobalMemoryStatusEx via ctypes - the same call the guard itself uses."""
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    try:
        st = MEMORYSTATUSEX()
        st.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
            return None
        return int(st.ullAvailPhys // (1024 * 1024)), int(st.ullTotalPhys // (1024 * 1024))
    except Exception:
        return None


def _linux_avail_mb() -> int | None:
    """/proc/meminfo MemAvailable - the number the guard actually reads."""
    try:
        info: dict[str, int] = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            if ":" not in line:
                continue
            k, _, v = line.partition(":")
            parts = v.split()
            if parts:
                info[k.strip()] = int(parts[0])          # kB
        if "MemAvailable" in info:
            return info["MemAvailable"] // 1024, info.get("MemTotal", 0) // 1024
        if "MemFree" in info:
            return info["MemFree"] // 1024, info.get("MemTotal", 0) // 1024
    except Exception:
        pass
    return None


def _mac_avail_mb() -> int | None:
    try:
        import subprocess
        total = int(subprocess.check_output(
            ["sysctl", "-n", "hw.memsize"]).strip()) // (1024 * 1024)
        # vm_stat gives pages; page size via host_statistics is awkward, use 4096
        out = subprocess.check_output(["vm_stat"]).decode()
        free = 0
        for line in out.splitlines():
            low = line.lower()
            if low.startswith("pages free") or low.startswith("pages inactive"):
                num = "".join(c for c in line.split(":")[-1] if c.isdigit())
                if num:
                    free += int(num) * 4096
        return free // (1024 * 1024), total
    except Exception:
        return None


def _psutil_avail_mb() -> tuple[int, int] | None:
    try:
        import psutil
        vm = psutil.virtual_memory()
        return int(vm.available // (1024 * 1024)), int(vm.total // (1024 * 1024))
    except Exception:
        return None


def _shm_free_mb() -> int | None:
    try:
        st = os.statvfs("/dev/shm")
        return int(st.f_bavail * st.f_frsize // (1024 * 1024))
    except Exception:
        return None


# --------------------------------------------------------------------------
def main() -> int:
    print(f"platform            : {platform.system()} {platform.release()}")
    print(f"cpu cores           : {os.cpu_count()}")
    print()

    result = None
    how = ""
    if platform.system() == "Windows":
        result, how = _win_avail_mb(), "GlobalMemoryStatusEx"
    elif platform.system() == "Linux":
        result, how = _linux_avail_mb(), "/proc/meminfo"
    elif platform.system() == "Darwin":
        result, how = _mac_avail_mb(), "sysctl + vm_stat"

    if result is None:
        result, how = _psutil_avail_mb(), "psutil"

    if result is None:
        print("Could not read memory on this platform without psutil.")
        print("Install it:  pip install psutil")
        print()
        print("The pack will then allow 6 workers as a safe default.")
        return 1

    avail_mb, total_mb = result
    workers = max(1, (avail_mb - RESERVE_MB) // PER_WORKER_MB)

    print(f"read via            : {how}")
    print(f"total RAM           : {total_mb / 1024:.1f} GB")
    print(f"AVAILABLE right now : {avail_mb / 1024:.1f} GB")
    print(f"RAM guard allows    : {workers} worker(s)")
    print(f"  arithmetic        : ({avail_mb} - {RESERVE_MB}) // {PER_WORKER_MB} = {workers}")
    print()

    shm = _shm_free_mb()
    if shm is not None:
        print(f"/dev/shm (scratch)  : {shm / 1024:.1f} GB free  (pinned RAM, used for crops)")

    ps = _psutil_avail_mb()
    if ps is None:
        print("psutil              : NOT installed")
        print("                      pip install psutil")
        print("                      (without it the native reader above is used,")
        print("                       which is fine - it is the same number)")
    else:
        print(f"psutil              : installed, reports {ps[0] / 1024:.1f} GB available")

    print()
    if avail_mb < 1500:
        print("-> Something else is eating your RAM. Close it and re-run this.")
        print("   Until then the guard will only grant 1 worker, which is slow.")
    elif avail_mb < 3000:
        print("-> Only 1-2 workers fit. Free more RAM before a fast run.")
    elif avail_mb < 6000:
        print("-> 4-5 workers fit. Decent, but not the fast path.")
    else:
        print("-> Plenty of room. A fast run will use the machine properly.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
