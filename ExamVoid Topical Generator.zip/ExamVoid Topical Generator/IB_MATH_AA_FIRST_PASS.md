# IB Mathematics: Analysis & Approaches — first pass

**Scope selected:** Mathematics: analysis and approaches (HL/SL), both runtime topic classification and QP/MS processing. This is an initial implementation check, **not** a full-paper validation.

## Source and access status

- Official IBO specimen bundle: [Mathematics: analysis and approaches specimen papers 1, 2 and 3](https://ibo.org/globalassets/new-structure/university-admission/pdfs/dp-mathematics-analysis-and-approaches-specimen-papers-en.pdf), first examinations in 2021. The official indexed description lists HL papers 1–3 and their markschemes, plus SL papers 1–2 and their markschemes. [IBO source](https://ibo.org/globalassets/new-structure/university-admission/pdfs/dp-mathematics-analysis-and-approaches-specimen-papers-en.pdf)
- The IBO PDF binary was **not** available in the workspace: direct retrieval returned HTTP 403, and the page-fetch tool could not retrieve this PDF. No access-control workaround was attempted. I used only question text exposed by the official indexed result; no original PDF, layout, complete MS, or crops were locally available.
- The current IBMA profile is the first-assessment-2021 taxonomy. A separate official Math AA subject brief now identifies a first-assessment-2029 version; this first pass does not validate that newer syllabus. Before covering 2029 exams, the profile/year routing needs a sourced version update. [2029 IBO brief](https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/sb_maths_analysis_en.pdf)
- The board config remains `IMPLEMENTED_PENDING_PDF_ACCESS_VALIDATION`; it was not promoted to validated.

## Runtime changes

Implemented in the actual IB adapter/runtime:

1. **Math AA subject recognition:** `MATAA` now resolves to the existing `IBMA` profile and the display subject `Mathematics: analysis and approaches`.
2. **IB component identity:** the `SPEC/.../MATAA/HP1/.../TZ0/...` code resolves to Paper 1, HL and TZ0; specimen status is read from the document evidence.
3. **Removed unsafe text fallback labels:** text-only IB segments no longer inherit `English A`, Paper 2 or an unconditional `SPECIMEN` label. IDs include the subject profile and paper, e.g. `IB_IBMA_P1_Q1`.
4. **Fail-closed bundle handling:** mixed QP+MS text, multiple paper codes, or multiple paper numbers produce no text segments, rather than duplicate question IDs or subject/component cross-labels. Text-only output is explicitly non-renderable. The markscheme path also refuses ambiguous multi-component documents.
5. **IB Math classifier routing:** paper identifiers such as `P1`, `IBMA/2`, and `.../HP2/...` are normalized to the paper number before reaching the shared classifier; question numbers such as `Q3` are accepted. The IB adapter bypasses the legacy Cambridge/GCE generic Math paper-category branch when loading an IB Math profile, so the IB topic taxonomy is used.

## Classification smoke sample

Four question-text fragments surfaced from the official HL specimen index were passed through `adapters.ib.classification.classify_text("IBMA", ...)`:

| Specimen item | Runtime output | Reading |
|---|---|---|
| Paper 2 Q2 — investment at 5.5%, compounded quarterly | `HINT` — `T1_Financial_maths`, 0.970 | Directly topical signal; plausible match |
| Paper 2 Q3 — biased die, five tosses, probability of numbers of sixes | `HINT` — `T4_Probability`, 0.732 | Broad probability label; review whether the narrower `T4_Discrete_binomial` is preferable |
| Paper 2 Q8 — solve equations with complex numbers | `HINT` — `T1_Complex_numbers_HL`, 0.970 | Directly topical signal; plausible match |
| Paper 1 Q6 — logarithms and trigonometric equation in one item | `REVIEW_REQUIRED` — `UNKNOWN` | Conservative result for a mixed-topic / notation-sensitive prompt |

Observed smoke coverage: **3/4 HINTs (75%)**. This is **not** an accuracy score: the sample is tiny, question text came from indexed excerpts, and there is no independently adjudicated topic-label set. Q3 is the clearest specificity question; no tuning was made from these four examples.

## Checks

- New IB Math AA tests: **5 passed**.
- Full project suite after all-subject profile smoke checks: **128 passed, 5 deprecation warnings**.
- Test coverage is for identity parsing, safe text-only labels, fail-closed mixed-document handling, paper-code normalization and classifier smoke behavior. It does **not** establish real PDF segmentation or crop geometry.

## To complete real QP/MS validation

Provide an individual official specimen QP and its matching markscheme (same level and paper), or a locally accessible official PDF. Then run the PDF/layout pipeline on that exact pair, verify question spans and MS association, and audit topic labels against a reviewed question-level reference. Until that is done, keep IB support pending validation.
