@echo off
REM ===================================================================
REM  CHECK_ONLY.bat -- shows progress and the worker count RUN_FAST
REM  will actually use. Starts NOTHING. Safe to run.
REM ===================================================================
cd /d "%~dp0"

if not exist run_guarded.py (
  echo   ERROR: put this .bat in the folder containing run_guarded.py
  pause
  exit /b 1
)

echo ============================================================
echo   Progress check only - nothing will be processed
echo   folder: %CD%
echo ============================================================
echo.
python fastcheck.py --output output --input input --workers 14
echo.
echo ------------------------------------------------------------
echo   That used 14 workers, which is what RUN_FAST.bat launches
echo   with, so the ETA shown is the real one.
echo ------------------------------------------------------------
echo.
echo   To start the run, double-click RUN_FAST.bat.
echo.
pause
