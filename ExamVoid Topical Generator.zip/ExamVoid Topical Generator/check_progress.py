#!/usr/bin/env python3
"""How much work has run_guarded.py already done, and what is left.

run_guarded.py records its state in <output>/.pipeline_state.json.
core/batch_runner.py (the parallel runner) uses <output>/pipeline.sqlite and
does NOT read that file -- I verified this: point the batch runner at an output
tree that already contains finished question folders and it still reports
"New: 157, Completed: 0".

So before you switch runners, run this to see what you would be redoing.

    python3 check_progress.py --output ./output
    python3 check_progress.py --output ./output --syllabus-codes   # emit filter args
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE
for _cand in (HERE, *HERE.parents):
    if (_cand / "core" / "batch_runner.py").is_file():
        REPO = _cand
        break
sys.path.insert(0, str(REPO))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", "-o", default=str(REPO / "output"))
    ap.add_argument("--input", "-i", default=str(REPO / "input"),
                    help="used only to report how many bundles exist in total")
    ap.add_argument("--syllabus-codes", action="store_true",
                    help="print one --syllabus-code <code> per unfinished subject")
    args = ap.parse_args()

    out = Path(args.output)
    state_file = out / ".pipeline_state.json"
    if not state_file.exists():
        print(f"[progress] no {state_file} -- run_guarded.py has not run here, "
              f"or used a different --output.")
        print("[progress] A fresh parallel run is safe: nothing to redo.")
        return 0

    try:
        payload = json.loads(state_file.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[progress] could not parse {state_file}: {exc}")
        return 1

    papers = payload.get("papers", {}) or {}
    if not papers:
        print(f"[progress] {state_file} has no paper records.")
        return 0

    by_status = Counter()
    unfinished_by_code = {}
    for key, rec in papers.items():
        status = str((rec or {}).get("status", "?")).lower()
        by_status[status] += 1
        if status not in ("complete",):
            code = str(key).split("_")[0]
            unfinished_by_code.setdefault(code, 0)
            unfinished_by_code[code] += 1

    total = sum(by_status.values())
    done = by_status.get("complete", 0)
    print(f"[progress] {state_file}")
    print(f"[progress] bundles recorded : {total}")
    for status, n in by_status.most_common():
        print(f"[progress]   {status:<18} {n}")
    print(f"[progress] already complete : {done}  ({done / total:.0%})")
    print(f"[progress] still to do      : {total - done}")

    if args.syllabus_codes and unfinished_by_code:
        print("\n[progress] hand only these to the parallel runner:")
        for code in sorted(unfinished_by_code):
            print(f"    python3 run_parallel.py --syllabus-code {code} "
                  f"--output {out}   # {unfinished_by_code[code]} bundle(s) left")
        print("\n[progress] ...and leave these alone (already complete): "
              + ", ".join(sorted(set(k.split('_')[0] for k in papers)
                                 - set(unfinished_by_code))))
    elif args.syllabus_codes:
        print("\n[progress] everything is complete -- nothing to hand over.")

    # Sanity check: is the parallel runner's DB also present?
    db = out / "pipeline.sqlite"
    print(f"\n[progress] parallel-runner DB: {db} "
          f"({'present' if db.exists() else 'absent -- a fresh run starts from zero'})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
