"""SAT (College Board) questions classified by the SAME machinery as Cambridge subjects.

Twin of ``adapters.aqa.classification`` / ``adapters.edexcel.classification``, with profile
discovery pointed at ``subjects_sat/`` instead. A SAT subject profile lives in
``subjects_sat/<Qualification>/<Subject_Code>/config.json`` in the Cambridge ``SubjectConfig``
schema (major_topics, detailed_topics, mapping, classification_keywords, specialization_weights,
syllabus_order, official_source ...). It is loaded into ``core.config_loader.SubjectConfig`` and
classified by ``core.classifier.TopicClassifier`` — the same engine every other board uses, never
a parallel keyword scorer.

Unlike AQA/Edexcel, SAT has no spec/syllabus numeric code baked into component strings the same
way; the two subjects shipped here use short board-internal codes (SATR, SATM) which double as
both the ``syllabus_code`` and the directory suffix, consistent with the IB adapter's convention
for codes like ``IBES``/``IBGP``.

Fallback (allowed by the work order, never primary): a spec code with no profile here, or a
profile that fails to load, falls back to ``adapters.nonib_topics`` (the Phase-0 vocabulary) and
says so (``engine: nonib_fallback``).
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Optional

from adapters import nonib_topics as _fallback

PROJ = Path(__file__).resolve().parent.parent.parent
PROFILE_ROOT = PROJ / "subjects_sat"

_CACHE: Dict[str, Any] = {}


def profile_path(spec_code: str) -> Optional[Path]:
    for cfg in sorted(PROFILE_ROOT.glob(f"*/*_{spec_code}/config.json")):
        return cfg
    return None


def load_profile(spec_code: str):
    """(SubjectConfig, TopicClassifier) for a spec code, or (None, None) when no profile exists."""
    if spec_code in _CACHE:
        return _CACHE[spec_code]
    path = profile_path(spec_code)
    if path is None:
        _CACHE[spec_code] = (None, None)
        return _CACHE[spec_code]
    from core.config_loader import SubjectConfig
    from core.classifier import TopicClassifier
    data = json.loads(path.read_text(encoding="utf-8"))
    config = SubjectConfig(data, config_path=path)
    classifier = TopicClassifier(config)          # no classification memory: never auto-populated
    _CACHE[spec_code] = (config, classifier)
    return _CACHE[spec_code]


def _stub(text: str, question_number: Any, component: str, year: str = "", season: str = "") -> SimpleNamespace:
    """A MatchedQuestion-shaped object carrying the crop's own text (marks read from the text)."""
    marks = sum(int(m) for m in re.findall(r"\[(\d{1,2})\s*marks?\]", text or "", re.I))
    qp = SimpleNamespace(text=text or "", marks=marks, paper_code=component, question_number=f"Q{question_number}",
                         number_int=int(question_number or 0), assembled_image=None, images=[])
    variant = (component.split("/")[1] if "/" in component else "") or ""
    return SimpleNamespace(question_number=f"Q{question_number}", number_int=int(question_number or 0),
                           qp=qp, ms=None, paper_code=component, full_qp_code=component, full_ms_code="",
                           year=year or "", season=season or "", variant=variant, subject="", paper_format="STRUCTURED")


def _confidence(result) -> float:
    """Calibrated like the Phase-0 formula, from the classifier's own major scores: margin between the
    winner and the runner-up plus the winner's strength against the 1.5-point floor."""
    scores = dict(result.major_topic_scores or {})
    if not scores or not result.winning_major:
        return 0.0
    top = float(scores.get(result.winning_major, 0.0))
    others = sorted((float(v) for k, v in scores.items() if k != result.winning_major), reverse=True)
    second = others[0] if others else 0.0
    margin = (top - second) / top if top > 0 else 0.0
    strength = min(1.0, top / 6.0)
    return round(min(0.97, 0.50 + 0.30 * margin + 0.20 * strength), 3)


def _classify_skill(config, text: str, domain: str) -> Dict[str, Any]:
    """Attach an official SAT skill within an already-selected domain.

    Domain scoring remains on the shared TopicClassifier. Skill cues are a
    second, narrower SAT-only layer: a clear top cue becomes an advisory skill
    hint; missing or tied evidence keeps the skill at REVIEW_REQUIRED without
    changing the broad-domain result or its routing.
    """
    catalog = dict(getattr(config, "data", {}).get("skills", {}) or {})
    candidates = [(str(name), meta) for name, meta in catalog.items()
                  if isinstance(meta, dict) and str(meta.get("domain", "")) == domain]
    if not candidates or not text:
        return {"skill": "UNKNOWN", "skill_confidence": 0.0,
                "skill_status": "REVIEW_REQUIRED", "skill_evidence": []}

    # Reuse the classifier's normalization and separator-tolerant matcher so
    # PDF line wraps/hyphens are handled consistently with domain cues.
    from core.classifier import _keyword_pattern, _normalize_text
    norm, _ = _normalize_text(text)
    ranked = []
    for name, meta in candidates:
        matched = []
        best = 0.0
        for cue in meta.get("keywords", []):
            cue = str(cue).strip()
            if cue and _keyword_pattern(cue).search(norm):
                # Longer, more diagnostic phrases outrank generic short tokens.
                words = len(re.findall(r"[A-Za-z0-9]+", cue))
                score = float(words * 2 + min(len(cue), 40) / 40.0)
                matched.append(cue)
                best = max(best, score)
        if best:
            ranked.append((best, name, matched))
    ranked.sort(key=lambda row: (-row[0], row[1]))
    if not ranked:
        return {"skill": "UNKNOWN", "skill_confidence": 0.0,
                "skill_status": "REVIEW_REQUIRED", "skill_evidence": []}
    top_score, top_name, top_evidence = ranked[0]
    runner_up = ranked[1][0] if len(ranked) > 1 else 0.0
    # A cue collision is not resolved alphabetically. Leave the skill for
    # review while preserving the already validated broad domain.
    if runner_up and (top_score == runner_up or top_score - runner_up < 1.0):
        return {"skill": "UNKNOWN", "skill_confidence": 0.0,
                "skill_status": "REVIEW_REQUIRED",
                "skill_evidence": sorted(set(top_evidence + ranked[1][2]))[:4],
                "skill_candidates": [name for _, name, _ in ranked[:3]]}
    confidence = round(min(0.95, 0.60 + 0.04 * (top_score - runner_up)), 3)
    return {"skill": top_name, "skill_confidence": confidence,
            "skill_status": "HINT", "skill_evidence": top_evidence[:4]}


def _sat_affine_parameter_function(text: str) -> bool:
    """Recognize the printed affine form f(x)=ax+b despite PDF line order."""
    from core.classifier import _normalize_text
    norm, _ = _normalize_text(text or "")
    match = re.search(
        r"function\s+f\s+is\s+defined\s+by(?P<formula>.{0,120}?)where\s+a\s+and\s+b\s+are\s+constants",
        norm, re.S,
    )
    if not match:
        return False
    formula = match.group("formula")
    # The extracted notation commonly reads "f x a x b ( ) = +". Require
    # the affine a-x-b product/sum structure and decline powers/radicals.
    has_affine_terms = bool(re.search(r"\ba\s+x\s+b\b", formula))
    has_addition = "+" in formula
    has_nonlinear_marker = bool(re.search(r"(?:\^|\b(?:2|3)\b|squared|sqrt|root|/)", formula))
    return has_affine_terms and has_addition and not has_nonlinear_marker


def _sat_segment_math_signals(ctx, seg) -> Dict[str, bool]:
    """Read light formula-layout evidence from DocumentContext without reopening the PDF.

    In SAT text extraction, a printed exponent may be emitted as an isolated
    small text line. Compare its bbox with adjacent baseline text; this helps
    distinguish 6x from 6^x in function stems whose reading order is otherwise
    ambiguous. This is a narrow signal, not a general symbolic-math parser.
    """
    layout = getattr(ctx, "layout", {}) or {}
    pages = layout.get("pages", []) if isinstance(layout, dict) else []
    for loc in seg.get("pages", []) or []:
        try:
            page_idx = int(loc.get("page_index", -1))
            rect = tuple(float(v) for v in loc.get("rect", ()))
        except (TypeError, ValueError):
            continue
        if len(rect) != 4 or page_idx < 0 or page_idx >= len(pages):
            continue
        page = pages[page_idx]
        lines = page.get("lines", []) if isinstance(page, dict) else []
        inside = []
        for line in lines:
            bbox = line.get("bbox") or ()
            if len(bbox) != 4:
                continue
            x0, y0, x1, y1 = (float(v) for v in bbox)
            if x1 < rect[0] or x0 > rect[2] or y1 < rect[1] or y0 > rect[3]:
                continue
            inside.append((str(line.get("text", "")).strip(), (x0, y0, x1, y1)))
        baseline_heights = [b[3] - b[1] for t, b in inside if len(t) >= 4]
        if not baseline_heights:
            continue
        baseline_height = sorted(baseline_heights)[len(baseline_heights) // 2]
        for token, tb in inside:
            if not re.fullmatch(r"(?:[0-9]{1,2}|[xy])", token.lower()):
                continue
            token_height = tb[3] - tb[1]
            if token_height > baseline_height * 0.70:
                continue
            for base_text, bb in inside:
                if len(base_text) < 4 or not (tb[1] + 1.0 < bb[1] <= tb[1] + 7.0):
                    continue
                horizontal_gap = max(0.0, bb[0] - tb[2], tb[0] - bb[2])
                if horizontal_gap <= 20.0:
                    return {"superscript_exponent": True}
    return {"superscript_exponent": False}


def _sat_domain_override(spec_code: str, text: str) -> Optional[tuple[str, str]]:
    """High-precision SAT domain cues for clear stems the shared scorer misses.

    These are topic-family rules, not per-question lookups. They are deliberately
    narrow: a strong structural or mathematical cue may promote a review or
    correct a conflicting broad-domain winner; ambiguous items stay in review.
    """
    from core.classifier import _normalize_text
    norm, _ = _normalize_text(text or "")
    norm = re.sub(r"\s+", " ", norm).strip()
    raw = str(text or "").lower()
    code = str(spec_code or "").upper()

    if code == "SATR":
        if re.search(r"main topic of the text|main idea of the text|central idea of the text", norm):
            return "Information_and_Ideas", "SAT stem explicitly asks for the text's main topic/idea"
        if re.search(r"which finding.{0,100}(?:support|challenge|weaken)|"
                     r"which choice best supports the claim|what can most reasonably be inferred", norm):
            return "Information_and_Ideas", "SAT command asks for evidence or an inference"
        if re.search(r"according to the (?:graph|table|chart).{0,160}(?:which|what)", norm):
            return "Information_and_Ideas", "SAT Reading and Writing question asks for a graph/table inference"
        return None

    if code != "SATM":
        return None

    # Explicit geometric objects/relations outrank algebraic notation embedded
    # in the same stem (e.g. an angle expression or a circle equation).
    if (("acute" in norm and "obtuse" in norm and "angle" in norm)
            or ("triangle" in norm and re.search(r"\b(?:sin|cos|tan|angle|hypotenuse|length)\b", norm))
            or ("rectangle" in norm and re.search(r"\barea\b", norm))
            or ("rectangular prism" in norm)
            or ("circle" in norm and re.search(r"\b(?:radius|center|circumference)\b", norm))
            or ("circle" in norm and re.search(r"\b(?:equation of|equation defining)\b", norm))
            or ("intersect at point" in norm and "length" in norm)
            or (re.search(r"\bsegments?\b.{0,90}\bintersect at point\b", norm)
                and re.search(r"\b(?:length|triangle|figure)\b", norm))):
        return "Geometry_and_Trigonometry", "SAT stem explicitly identifies a geometric object or relation"

    # Explicit nonlinear models take precedence over everyday percent language:
    # repeated percentage decay of a function is exponential, not a percent-of
    # calculation in the PSDA sense.
    if ("doubled every" in norm
            or ("bacteria" in norm and "growth medium" in norm and "positive constant" in norm)
            or ("players" in norm and "eliminated" in norm and "round" in norm and "equation" in norm)
            or ("one solution to the given equation can be written" in norm)
            or "distinct real solutions" in norm
            or ("each increase in x" in norm and re.search(r"\bfunction\b.{0,100}%", raw))):
        return "Advanced_Math", "SAT stem encodes a quadratic or exponential model"

    # Percent, sampling, summary statistics, plots, and unit conversion are
    # the SAT PSDA domain; require a recognizable applied/data cue.
    if ("%" in raw or re.search(r"\bpercent(?:age)?\b", norm)):
        if re.search(r"\b(?:number|value|amount|less than|greater than|of them|of the|increase|decrease)\b", norm):
            return "Problem_Solving_and_Data_Analysis", "SAT applied percentage/rate question"
    if (re.search(r"\b(?:dot plot|histogram|scatterplot|line of best fit|mean|median|standard deviation)\b", norm)
            or ("graph" in norm and "interpretation of the point" in norm)
            or ("selected" in norm and "at random" in norm and re.search(r"\b(?:estimate|survey|customers|sample)\b", norm))
            or ("nautical mile" in norm and "kilometer" in norm)):
        return "Problem_Solving_and_Data_Analysis", "SAT data-analysis, sampling, or unit-conversion cue"

    # Clear linear-equation/model tasks whose formulas are often scrambled by
    # text extraction. Avoid extending this to undecidable plotted models.
    if ("same solution as the given equation" in norm
            or "graphs of the equations in the given system intersect" in norm
            or ("possible combinations" in norm and "equation gives" in norm)
            or ("which graph represents this situation" in norm and "equations represent" in norm)
            or ("which of the following graphs represents this situation" in norm and "equations represent" in norm)
            or ("linear equations" in norm and "which graph represents" in norm)
            or ("which inequality represents the relationship" in norm and "can buy" in norm)
            or ("shaded region" in norm and "inequality" in norm)):
        return "Algebra", "SAT stem explicitly asks about an equivalent/linear equation or inequality"

    return None


def classify_text(spec_code: str, text: str, *, question_number: Any = 0, component: str = "",
                  year: str = "", season: str = "", math_signals: Optional[Dict[str, bool]] = None) -> Dict[str, Any]:
    config, classifier = load_profile(spec_code)
    if classifier is None:
        out = _fallback.classify_segment_topic("SAT", text, component=component)
        out["engine"] = "nonib_fallback"
        out.update({"skill": "UNKNOWN", "skill_confidence": 0.0,
                    "skill_status": "REVIEW_REQUIRED", "skill_evidence": []})
        return out
    from core.classifier import _normalize_text
    result = classifier.classify_question(_stub(text, question_number, component or spec_code, year, season))
    tier = getattr(result, "fallback_tier", "scored")

    # A generic "function is defined by" cue can suggest Advanced Math even
    # when the printed rule is linear. For segment classification, use the
    # existing PDF-layout bboxes to distinguish a baseline x (e.g. 6x) from a
    # small raised exponent (e.g. x^3). If the formula is still ambiguous in a
    # text-only call, preserve REVIEW_REQUIRED rather than guessing.
    if spec_code == "SATM":
        norm, _ = _normalize_text(text or "")
        input_question = bool(re.search(
            r"for\s+what\s+value\s+of\s+x\s+(?:(?:does|is)\s+)?(?:f|g)\s*\(?\s*x", norm))
        function_evaluation = bool(re.search(
            r"what\s+is\s+the\s+value\s+of\s+f\s*(?:\(\s*\w+\s*\)|\s+\d+)", norm))
        generic_function_definition = bool(re.search(
            r"function\s+(?:f|g)\s+is\s+defined\s+by", norm))
        explicit_nonlinear = bool(re.search(
            r"\b(?:quadratic|exponential|polynomial|rational|radical|nonlinear|squared|parabola|minimum|maximum)\b|"
            r"\bx\s*\^\s*\d|distinct\s+real\s+solutions|zero\s+product|absolute\s+value|\\/|√|\|",
            norm,
        ))
        raised_power = bool((math_signals or {}).get("superscript_exponent"))
        if generic_function_definition and (input_question or function_evaluation):
            if raised_power or explicit_nonlinear:
                if result.winning_major == "Advanced_Math" and tier == "review_required":
                    tier = "scored"
            elif math_signals is None:
                tier = "review_required"
            else:
                # A baseline-only function form with no nonlinear marker is a
                # linear-function/linear-equation task for this adaptive rule.
                domain_scores = dict(result.major_topic_scores or {})
                top = max((float(v) for v in domain_scores.values()), default=0.0)
                domain_scores["Algebra"] = max(float(domain_scores.get("Algebra", 0.0)), top + 0.25)
                result.major_topic_scores = domain_scores
                result.winning_major = "Algebra"
                result.detailed_topics = ["Algebra"]
                result.reasoning = str(getattr(result, "reasoning", "")) + " | SAT baseline linear-function form"
                tier = "scored"

    # A clearly extracted f(x)=ax+b form is linear even when the shared
    # classifier's generic function cue leans toward Advanced Math.
    if spec_code == "SATM" and _sat_affine_parameter_function(text):
        domain_scores = dict(result.major_topic_scores or {})
        top = max((float(v) for v in domain_scores.values()), default=0.0)
        domain_scores["Algebra"] = max(float(domain_scores.get("Algebra", 0.0)), top + 0.25)
        result.major_topic_scores = domain_scores
        result.winning_major = "Algebra"
        result.detailed_topics = ["Algebra"]
        result.reasoning = str(getattr(result, "reasoning", "")) + " | SAT affine-function form f(x)=ax+b"
        if tier == "review_required":
            tier = "scored"

    rule_applied = False
    rule_reason = ""
    override = _sat_domain_override(spec_code, text)
    if override:
        rule_topic, rule_reason = override
        if tier == "review_required" or result.winning_major != rule_topic:
            # Keep override evidence auditable and prevent a contradictory
            # low-scoring runner-up from becoming a secondary folder label.
            result.major_topic_scores = {rule_topic: 3.0}
            result.winning_major = rule_topic
            result.detailed_topics = [rule_topic]
            result.reasoning = str(getattr(result, "reasoning", "")) + f" | SAT override: {rule_reason}"
            tier = "scored"
            rule_applied = True

    scores = dict(result.major_topic_scores or {})
    ranked = sorted(scores.items(), key=lambda kv: (-float(kv[1]), kv[0]))
    if tier in ("review_required", "alphabetical_first", "paper_hint") or not result.winning_major:
        # fail closed exactly like a Cambridge question with insufficient direct evidence
        return {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED", "evidence": [],
                "secondary": [], "spec": spec_code, "engine": "sat_topic_classifier", "fallback_tier": tier,
                "candidates": [{"topic": k, "score": round(float(v), 3)} for k, v in ranked[:3]],
                "reasoning": str(getattr(result, "reasoning", ""))[:300],
                "skill": "UNKNOWN", "skill_confidence": 0.0,
                "skill_status": "REVIEW_REQUIRED", "skill_evidence": []}
    weights = dict(getattr(config, "specialization_weights", {}) or {})
    aspects = {k for k, w in weights.items() if float(w) < 1.0}
    pool = [(k, v) for k, v in ranked if k != result.winning_major and (not aspects or k in aspects)]
    secondary = [k for k, v in pool if float(v) >= 1.5][:2]
    evidence = list(result.detailed_topics or [])[:4]
    if rule_applied:
        evidence.append(f"SAT rule: {rule_reason}")
    evidence.append(f"score {scores.get(result.winning_major, 0):.2f}")
    return {"topic": result.winning_major, "confidence": 0.78 if rule_applied else _confidence(result), "status": "HINT",
            "evidence": evidence,
            "secondary": secondary, "spec": spec_code, "engine": "sat_topic_classifier", "fallback_tier": tier,
            "major_scores": {k: round(float(v), 3) for k, v in ranked[:4]},
            "reasoning": str(getattr(result, "reasoning", ""))[:300],
            **_classify_skill(config, text, result.winning_major)}


def classify_segments(ctx, segments, component: str = "", year: str = "", season: str = ""):
    """Classify SAT/PSAT adapter segments using their official subject profile.

    The section/module metadata is authoritative for the subject: Reading and
    Writing uses SATR; Math uses SATM. Segment text is taken from the same crop
    rectangles used by the renderer, with a page-text fallback recorded in the
    result, matching the universal-batch segment contract.
    """
    out = []
    for seg in segments:
        section = str(seg.get("section") or "").strip().upper()
        if section in {"RW", "READING", "READING_AND_WRITING"}:
            spec_code, section_code = "SATR", "RW"
        elif section in {"MATH", "MATHEMATICS"}:
            spec_code, section_code = "SATM", "MATH"
        else:
            # A segment without module identity cannot safely select a profile.
            out.append({
                "question_number": seg.get("question_number"),
                "canonical_question": seg.get("canonical_question"),
                "topic": "UNKNOWN", "confidence": 0.0,
                "status": "REVIEW_REQUIRED", "evidence": [], "secondary": [],
                "spec": "", "engine": "sat_classifier",
                "reasoning": "SAT segment is missing its Reading and Writing/Math section label",
                "text_source": "unavailable",
            })
            continue

        text, source = _fallback._segment_text(ctx, seg)
        try:
            module = int(seg.get("module") or 0)
        except (TypeError, ValueError):
            module = 0
        module_component = f"{section_code}M{module}" if module in (1, 2) else str(component or spec_code)
        cls = classify_text(
            spec_code, text,
            question_number=seg.get("question_number") or 0,
            component=module_component,
            year=year,
            season=season,
            math_signals=_sat_segment_math_signals(ctx, seg) if spec_code == "SATM" else None,
        )
        out.append({
            "question_number": seg.get("question_number"),
            "canonical_question": seg.get("canonical_question"),
            "text_source": source,
            **cls,
        })
    return out
