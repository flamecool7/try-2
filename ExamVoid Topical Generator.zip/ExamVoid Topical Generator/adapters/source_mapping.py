"""Conservative source/insert-to-question linking.

This maps only explicit labels mentioned in the question text, for example
"Use Source A" or "Figure 2 shows". It never infers an attachment solely from
order or subject matter.
"""
from __future__ import annotations

import re
from dataclasses import asdict
from typing import Any, Dict, Iterable, List

from adapters.base import DocumentContext
from adapters.companion_segments import TextCompanion


def _segment_text(ctx: DocumentContext, seg: Dict[str, Any]) -> str:
    """Read only the source-page bands that actually belong to this question.

    A segment can share a physical PDF page with the next question. Reading the
    page's full text used to pull a later ``Read Text B`` instruction into Q1's
    source-link text even when the rendered Q1 crop stopped above it.
    """
    pages = (ctx.layout or {}).get("pages") or []
    parts: List[str] = []
    for sp in seg.get("pages") or []:
        pi = int(sp.get("page_index", -1))
        if not (0 <= pi < len(pages)):
            continue
        page = pages[pi]
        rect = sp.get("rect") or sp.get("bbox")
        lines = page.get("lines") or []
        if isinstance(rect, (list, tuple)) and len(rect) == 4:
            left, top, right, bottom = map(float, rect)
            selected = []
            for line in lines:
                bbox = line.get("bbox") or []
                if len(bbox) != 4:
                    continue
                x0, y0, x1, y1 = map(float, bbox)
                if x1 > left and x0 < right and y1 > top and y0 < bottom:
                    selected.append((y0, x0, str(line.get("text", ""))))
            selected.sort(key=lambda row: (row[0], row[1]))
            # A clipped segment with no coordinate-bearing OCR/text lines is
            # unavailable, not permission to fall back to the entire page.
            text = "\n".join(row[2] for row in selected if row[2].strip())
        else:
            text = str(page.get("text", ""))
        if text.strip():
            parts.append(text)
    return "\n".join(parts)


def _label_variants(label: str) -> List[str]:
    words = " ".join(label.split())
    out = [words]
    m = re.match(r"(Source|Extract|Figure|Fig\.|Item)\s+([A-Z]|\d{1,2})\b", words, re.I)
    if m:
        head, ident = m.group(1), m.group(2)
        out.extend([f"{head} {ident}", f"{head.rstrip('.')} {ident}"])
        if head.lower().startswith("fig"):
            out.append(f"Figure {ident}")
    return sorted(set(out), key=len, reverse=True)


def link_sources_to_questions(ctx: DocumentContext, qp_segments: Iterable[Dict[str, Any]], sources: Iterable[TextCompanion]) -> List[Dict[str, Any]]:
    links: List[Dict[str, Any]] = []
    source_list = list(sources)
    for seg in qp_segments:
        text = _segment_text(ctx, seg)
        if not text.strip():
            continue
        found = []
        for src in source_list:
            for variant in _label_variants(src.canonical_question):
                if re.search(r"\b" + re.escape(variant) + r"\b", text, re.I):
                    found.append({"label": src.canonical_question, "source": asdict(src), "matched_text": variant})
                    break
        if found:
            links.append({
                "question_number": seg.get("question_number"),
                "canonical_question": seg.get("canonical_question"),
                "sources": found,
                "confidence": 0.88,
                "reason": "explicit source label appears in question text",
            })
    return links
