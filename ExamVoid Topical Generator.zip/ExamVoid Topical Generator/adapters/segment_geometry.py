"""Shared segment -> gold-geometry bridge for non-CAIE board adapters.

This module deliberately does NOT implement a second crop engine. Board adapters
only detect document-specific boundaries and return source-page rectangles. This
bridge renders those rectangles and delegates final image geometry to the locked
Cambridge gold primitives:

* ``assemble_multipage_question`` for whitespace trimming, stitching, LANCZOS
  width normalisation and the 30 px inter-page gap;
* ``enforce_exact_width_2280`` as a defensive final width guard;
* ``_align_top_white_band_final`` for the locked 20 px visible top band.

The adapters themselves never open or OCR PDFs; they consume ``DocumentContext``.
Opening the PDF here is the shared rendering step after boundaries are known.
"""
from __future__ import annotations

import gc
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import fitz  # PyMuPDF
import numpy as np
from PIL import Image

from original_reference.cambridge_qb.multipage_optimizer import (
    assemble_multipage_question,
    enforce_exact_width_2280,
)
from original_reference.cambridge_qb.question_split import _align_top_white_band_final

TARGET_WIDTH = 2280
AQA_JOIN_PADDING_TB = 12   # see render_segment: keeps AQA page joins under the 60 px blank-run guarantee
RENDER_DPI = 300

#: Lossless WEBP encoder effort. Measured 2026-09-29 on the AQA 8462/1H June 2023 crops
#: (the six largest, 2280x3000-11216 px): method 4 produces *byte-identical* files to the
#: earlier method 6 on 6 of 6 crops while encoding ~3 % faster, and every method decodes to
#: the exact source pixels (lossless is lossless -- method only buys effort, never quality).
#: The batch saves through this constant so the choice is one line to re-measure.
WEBP_LOSSLESS_METHOD = 4

#: Exact-width rendering (2026-09-29). The locked assembler normalises the *trimmed* crop to
#: TARGET_WIDTH with LANCZOS, which on adapter rects -- already tight to a question's ink --
#: was a pure upscale of a 300 dpi page raster (2231 px -> 2280 px, measured) costing 6.0 s of
#: a 35.7 s demo batch (17 %). Rendering each page rectangle at the scale that lands it on
#: TARGET_WIDTH makes both the trim and the width guard no-ops for those rects (`trim_page_section`
#: returns the image untouched when the content bbox is full; `enforce_exact_width_2280` returns
#: when the width already matches), so the expensive resample disappears. Crops whose rect does
#: contain whitespace still take the locked path, just with a ratio nearer 1. The cap below keeps
#: a narrow clip (half-column inserts) from asking the rasteriser for a absurd scale; past it the
#: locked path upscales exactly as it always did.
EXACT_WIDTH_MAX_SCALE = 6.0

#: See ``exact_width_scale``: exact-width rendering is only taken when the needed scale is
#: within this factor of the 300 dpi default, so a narrow clip never costs more pixels than
#: the legacy path (which would have run its resample either way).
EXACT_WIDTH_SCALE_TOLERANCE = 1.35

#: libwebp refuses any dimension above this (measured 2026-09-23: a 26-page mark scheme
#: rendered as a single segment raised "Image size exceeds WebP limit of 16383 pixels" and
#: aborted the whole batch). The output contract (adapters/output_contracts.py) is tighter
#: still -- height must stay *below* the limit -- so crops are assembled to fit
#: ``MAX_CROP_HEIGHT`` in the first place; see ``render_segment_tiles``.
WEBP_MAX_DIM = 16383
MAX_CROP_HEIGHT = 16000




@dataclass(frozen=True)
class PageRect:
    """One source-page segment in PDF points."""

    page_index: int
    rect: tuple[float, float, float, float]


@dataclass
class RenderedSegment:
    """Rendered image plus provenance returned by the bridge."""

    segment_id: str
    image: Image.Image
    source_pages: List[int]
    metadata: Dict[str, Any] = field(default_factory=dict)


def _rect_from_any(raw: Any) -> tuple[float, float, float, float]:
    if isinstance(raw, fitz.Rect):
        return (float(raw.x0), float(raw.y0), float(raw.x1), float(raw.y1))
    if isinstance(raw, Mapping):
        if "rect" in raw:
            return _rect_from_any(raw["rect"])
        return (float(raw["x0"]), float(raw["y0"]), float(raw["x1"]), float(raw["y1"]))
    if isinstance(raw, Sequence) and len(raw) == 4:
        return (float(raw[0]), float(raw[1]), float(raw[2]), float(raw[3]))
    raise TypeError(f"Unsupported rectangle: {raw!r}")


def _pages_from_segment(seg: Mapping[str, Any]) -> List[PageRect]:
    pages = seg.get("pages")
    if not pages and "page_index" in seg:
        pages = [{"page_index": seg["page_index"], "rect": seg.get("rect") or seg.get("clip")}]
    out: List[PageRect] = []
    for item in pages or []:
        page_index = int(item.get("page_index", item.get("page", 0)))
        rect = _rect_from_any(item.get("rect") or item.get("clip") or item)
        out.append(PageRect(page_index=page_index, rect=rect))
    return out


def render_page_rect(doc: fitz.Document, page_rect: PageRect, *, dpi: int = RENDER_DPI,
                     scale: float | None = None, snap_width: int | None = None) -> Image.Image:
    """Render one source rectangle at a fixed DPI (or explicit px-per-point ``scale``) into RGB.

    ``scale`` wins when given, letting a caller ask for an exact pixel width instead of a DPI
    (see ``exact_width_scale`` and the EXACT_WIDTH_MAX_SCALE note above).

    ``snap_width`` asks for the raster to come out at exactly that pixel width. MuPDF sizes a
    pixmap by rounding the device-space clip, so a factor of ``target / width`` regularly lands
    one pixel over (measured: 2281 px for 512 pt and 535.3 pt clips), and one pixel over is
    enough to send the locked assembler into a full LANCZOS pass of the whole canvas. When the
    first raster misses by a hair the factor is corrected from the measured overshoot and drawn
    once more; a raster that still misses is returned as-is and the locked path handles it.
    """

    page = doc[page_rect.page_index]
    clip = fitz.Rect(*page_rect.rect) & page.rect
    if clip.is_empty or clip.width <= 1 or clip.height <= 1:
        return Image.new("RGB", (TARGET_WIDTH, 20), "white")
    factor = float(scale) if scale is not None else dpi / 72.0
    pix = page.get_pixmap(matrix=fitz.Matrix(factor, factor), clip=clip, alpha=False)
    if snap_width and pix.width != snap_width and abs(pix.width - snap_width) <= max(3, snap_width // 50):
        factor *= float(snap_width) / float(pix.width)
        pix = page.get_pixmap(matrix=fitz.Matrix(factor, factor), clip=clip, alpha=False)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def _sat_gutter_rule_bbox(page: fitz.Page, clip: fitz.Rect, sat_column: int) -> tuple[float, float, float, float] | None:
    """Locate the long central SAT column divider inside either column's clip.

    Older official practice papers expose the divider as a vertical dotted text span;
    newer paper-layout PDFs draw it as a thin vector line. It is page furniture, not
    question content. The crop assembler's ink-based trim otherwise treats that line
    as content all the way to the bottom of the page.
    """
    page_mid = float(page.rect.width) / 2.0

    def near_gutter_edge(x0: float, x1: float) -> bool:
        if sat_column == 0:
            return clip.x1 - 20.0 <= x0 <= clip.x1 + 1.0
        return clip.x0 - 1.0 <= x1 and x0 <= clip.x0 + 20.0

    candidates: list[tuple[float, float, float, float]] = []
    try:
        for block in page.get_text("dict").get("blocks", []):
            for line in block.get("lines", []) or []:
                text = "".join(span.get("text", "") for span in line.get("spans", [])).strip()
                box = line.get("bbox")
                if not text or not box or len(box) != 4:
                    continue
                compact = "".join(ch for ch in text if not ch.isspace())
                x0, y0, x1, y1 = map(float, box)
                if (len(compact) >= 8 and set(compact) <= {".", "…"}
                        and x1 - x0 <= 20.0 and y1 - y0 >= 200.0
                        and abs((x0 + x1) / 2.0 - page_mid) <= 20.0
                        and near_gutter_edge(x0, x1)
                        and y1 >= clip.y1 - 40.0):
                    candidates.append((x0, y0, x1, y1))
    except Exception:
        # Text spans are one representation only; vector-rule detection below is
        # independent, and ordinary crops keep their established path on failure.
        pass
    try:
        for drawing in page.get_drawings():
            box = drawing.get("rect")
            if box is None:
                continue
            x0, y0, x1, y1 = map(float, (box.x0, box.y0, box.x1, box.y1))
            if (x1 - x0 <= 1.5 and y1 - y0 >= 250.0
                    and abs((x0 + x1) / 2.0 - page_mid) <= 20.0
                    and near_gutter_edge(x0, x1)
                    and y1 >= clip.y1 - 40.0):
                # Vector lines have zero width; widen only the search box, not
                # the final crop, so antialiased stroke pixels are found.
                candidates.append((x0 - 2.0, y0, x1 + 2.0, y1))
    except Exception:
        pass
    if not candidates:
        return None
    return max(candidates, key=lambda box: box[3] - box[1])


def _remove_sat_gutter_rule(image: Image.Image, page: fitz.Page, page_rect: PageRect,
                           sat_column: int) -> bool:
    """Remove the decorative SAT column divider so normal ink trimming can work.

    The dotted/vector line runs almost the full page height and is not part of a
    question; the shared gold crop geometry therefore mistakes it for content and
    retains a large blank tail. Only the narrow pixel columns exhibiting the
    repeated divider pattern are cleared. Text, figures, and all other pixels are
    left intact, after which the standard cropper trims to the actual question.
    """
    clip = fitz.Rect(*page_rect.rect) & page.rect
    if clip.is_empty or clip.width <= 1 or clip.height <= 1:
        return False
    rule = _sat_gutter_rule_bbox(page, clip, sat_column)
    if rule is None:
        return False

    gray = np.asarray(image.convert("L"))
    height, width = gray.shape
    sx, sy = width / clip.width, height / clip.height
    x0, y0, x1, y1 = rule
    rx0 = max(0, min(width, int(round((x0 - clip.x0) * sx))))
    rx1 = max(0, min(width, int(round((x1 - clip.x0) * sx))))
    ry0 = max(0, min(height, int(round((y0 - clip.y0) * sy))))
    ry1 = max(0, min(height, int(round((y1 - clip.y0) * sy))))
    if rx1 <= rx0 or ry1 - ry0 < 40:
        return False

    # Keep only narrow columns that exhibit the repeated dot/dash pattern of
    # the divider, not nearby table/graph strokes. Solid axes have few runs and
    # are deliberately not classified as page furniture.
    dark_limit = 246
    rule_rows = gray[ry0:ry1, rx0:rx1] < dark_limit
    columns: list[int] = []
    rule_span = max(1, ry1 - ry0)
    for offset in range(rule_rows.shape[1]):
        active = rule_rows[:, offset]
        runs = int(np.count_nonzero(active & ~np.r_[False, active[:-1]]))
        if runs >= 12 and int(active.sum()) >= max(30, int(0.10 * rule_span)):
            columns.append(rx0 + offset)
    if not columns or len(columns) > 12:
        return False

    # This exact narrow, repeated-dot/dash stroke is the page's column divider.
    # Removing it is safe for question content and lets the existing shared
    # assembler find the real bottom of text/figures instead of the page rule.
    rgb = np.asarray(image.convert("RGB")).copy()
    rgb[:, columns, :] = 255
    image.paste(Image.fromarray(rgb, "RGB"))
    return True


def exact_width_scale(page_rects: Sequence[PageRect], *, target_width: int = TARGET_WIDTH,
                      max_scale: float = EXACT_WIDTH_MAX_SCALE,
                      dpi: int = RENDER_DPI) -> float | None:
    """Px-per-point scale that renders the widest rectangle of a segment at ``target_width``.

    Returns ``None`` when no usable width is known, which callers read as "use the DPI path".
    Every page of one segment shares the returned scale -- the assembler aligns pages by their
    content bounds, so a per-page scale would slide columns against each other.

    Exact width only pays off while the rasteriser is not asked for far more pixels than the
    300 dpi default would have produced: for a near-full-width rect the scale is 4.26 px/pt
    against the legacy 4.17 (a 4 % render increase that deletes the 2280 resample), but a
    half-column rect would need ~8 px/pt -- 3.8x the pixels -- to save the same one resample,
    which the locked path runs anyway. Past the tolerance the legacy DPI path is returned so a
    narrow clip is never rendered more expensively than it is today.
    """

    widths = [float(pr.rect[2]) - float(pr.rect[0]) for pr in page_rects]
    widths = [w for w in widths if w > 1.0]
    if not widths:
        return None
    needed = float(target_width) / max(widths)
    if needed > (dpi / 72.0) * EXACT_WIDTH_SCALE_TOLERANCE:
        return None
    return min(needed, float(max_scale))


def exact_scale_for_segment(segment: Mapping[str, Any], *, target_width: int = TARGET_WIDTH,
                            max_scale: float = EXACT_WIDTH_MAX_SCALE,
                            dpi: int = RENDER_DPI) -> float | None:
    """``exact_width_scale`` for a segment dict (the scale ``render_segment_tiles`` will pick).

    Callers that need the effective scale *before* rendering -- the crop cache keys on it --
    ask here so the key can never disagree with what the renderer used.
    """

    return exact_width_scale(_pages_from_segment(segment), target_width=target_width,
                             max_scale=max_scale, dpi=dpi)


def render_segment(pdf_path: str | Path, segment: Mapping[str, Any], *, dpi: int = RENDER_DPI,
                   scale: float | None = None) -> RenderedSegment:
    """Render one adapter segment through locked gold geometry."""

    page_rects = _pages_from_segment(segment)
    if not page_rects:
        raise ValueError(f"segment has no pages: {segment!r}")
    sat_column = (segment.get("metadata") or {}).get("sat_column")
    with fitz.open(str(pdf_path)) as doc:
        pieces = []
        for page_rect in page_rects:
            piece = render_page_rect(doc, page_rect, dpi=dpi, scale=scale)
            if sat_column in (0, 1):
                _remove_sat_gutter_rule(piece, doc[page_rect.page_index], page_rect, int(sat_column))
            pieces.append(piece)
    if str(segment.get("board") or "").upper() == "AQA" and len(pieces) > 1:
        # AQA fix round FIX 3 (2026-09-23): the locked assembler's defaults join pages with
        # 24 px + 30 px + 24 px of white (≈83 px after the 2280 resize). The user-facing
        # guarantee for AQA multi-page crops is "no full-width blank run > 60 px mid-crop",
        # so AQA pieces are trimmed with 12 px top/bottom padding: 12 + 30 + 12 = 54 px at
        # render dpi, ≈58 px after resize. The assembler itself is untouched (locked); this
        # only passes one of its documented parameters, for AQA segments only.
        assembled = assemble_multipage_question(pieces, target_width=TARGET_WIDTH, padding_tb=AQA_JOIN_PADDING_TB)
    else:
        assembled = assemble_multipage_question(pieces, target_width=TARGET_WIDTH)
    assembled = enforce_exact_width_2280(assembled, target_width=TARGET_WIDTH)
    assembled = _finalise_band(assembled)
    return RenderedSegment(
        segment_id=str(segment.get("id") or segment.get("question_id") or segment.get("question_number")),
        image=assembled,
        source_pages=[pr.page_index for pr in page_rects],
        metadata=dict(segment.get("metadata") or {}),
    )


#: The shipped output contract (adapters/output_contracts.py) reads the top band strictly: ANY pixel
#: whose smallest channel is below 250 inside the first 20 rows fails the crop. The locked band
#: alignment uses the older "first row with at least two pixels below 250" reading, so a resampling
#: residue can survive above the content row. Measured on the A-level Mathematics 7357 mark schemes
#: (2026-09-24): 25 of 53 crops carried exactly one pixel valued 248 or 249 -- the rounding ghost of
#: the black table rule two rows below it -- and the batch failed every one of them. A pixel that
#: light is not content in the required blank guard band, so the bridge clears it above the
#: first-content anchor; pixels at and below that anchor are left untouched.
_TOP_BAND_PX = 20


def _sanitise_top_band(img: Image.Image, target_px: int = _TOP_BAND_PX) -> Image.Image:
    """Whiten near-white resampling residue inside the required white top band (see above).

    Only rows ABOVE the first content row -- where "content" is the same criterion the band
    alignment uses, a row with at least two grayscale pixels below 250 -- are touched, and only
    within the first ``target_px`` rows. The output contract is channel-strict, while the old
    grayscale residue pass missed colored resampling ghosts such as RGB=(249, 250, 250). Whiten
    near-white pixels with ANY channel below 250 in this empty guard band; content at or below the
    detected first row, and darker pixels elsewhere, remain unchanged.
    """

    rgb = np.asarray(img.convert("RGB"))
    if rgb.ndim != 3 or rgb.shape[0] < 3 or rgb.shape[1] < 3:
        return img
    gray = np.asarray(img.convert("L"))
    ink_rows = np.where((gray < 250).sum(axis=1) >= 2)[0]
    anchor = int(ink_rows.min()) if ink_rows.size else gray.shape[0]
    limit = min(int(target_px), anchor)
    if limit <= 0:
        return img
    residue = np.any(rgb[:limit] < 250, axis=2)
    if not residue.any():
        return img
    out = rgb.copy()
    out[:limit][residue] = 255
    return Image.fromarray(out, "RGB")


def _finalise_band(img: Image.Image) -> Image.Image:
    """Locked 20 px top band, then the contract-strict reading of it (see _sanitise_top_band)."""

    return _sanitise_top_band(_align_top_white_band_final(img))


def _assemble_pieces(pieces: List[Image.Image], board: Any) -> Image.Image:
    if str(board or "").upper() == "AQA" and len(pieces) > 1:
        return assemble_multipage_question(pieces, target_width=TARGET_WIDTH, padding_tb=AQA_JOIN_PADDING_TB)
    return assemble_multipage_question(pieces, target_width=TARGET_WIDTH)


#: Conservative cost of one inter-page join in assembled pixels (AQA: 12 pt + 30 px + 12 pt
#: at 300 dpi ≈ 130 px). Only used to *plan* tile runs before anything is rendered.
_JOIN_ESTIMATE_PX = 130
#: Keep the planner clear of the hard limit so an estimate miss still fits.
_TILE_PLAN_MARGIN_PX = 400


def _plan_tile_runs(page_rects: Sequence[PageRect], page_widths: Sequence[float],
                    max_height: int) -> List[List[int]]:
    """Group page indices into runs whose assembled height should stay under ``max_height``.

    Planning is deliberately estimate-only: the alternative (assemble, measure, split,
    re-assemble) holds every page of a long question in memory at once, which is what
    killed the 8464/P/1H June 2023 run on an 8-page question in a 2 GB container.
    ``render_segment_tiles`` still verifies the real height and splits again if an
    estimate ever comes up short.
    """

    limit = max(1, max_height - _TILE_PLAN_MARGIN_PX)
    runs: List[List[int]] = []
    current: List[int] = []
    height = 0.0
    for index, page_rect in enumerate(page_rects):
        width = float(page_widths[index] or 0.0) or float(page_rect.rect[2] - page_rect.rect[0])
        page_height = (page_rect.rect[3] - page_rect.rect[1]) * (TARGET_WIDTH / width) if width else 0.0
        addition = page_height + (_JOIN_ESTIMATE_PX if current else 0.0)
        if current and height + addition > limit:
            runs.append(current)
            current, height = [index], page_height
        else:
            current.append(index)
            height += addition
    if current:
        runs.append(current)
    return runs


def release_memory() -> None:
    """Return freed arenas to the OS after a 300 dpi crop has been assembled or encoded.

    A 2280 px wide A4 crop is a 30-100 MB raster and libwebp's lossless encoder (method=6)
    needs a comparable scratch buffer, so the render/save loop hands glibc back roughly half
    a gigabyte at a time. glibc keeps those freed blocks in its arenas by default, which is
    fine for a one-shot process but not for a batch: rendering 8462/2H June 2023 question by
    question the resident set climbed monotonically (87 -> 1193 MB measured) and the kernel
    killed the run at question 2. Trimming after each crop keeps the footprint flat -- the
    same release the test-suite ``conftest`` performs between tests. Pixels are untouched, so
    the shipped WEBPs are byte-identical.
    """

    gc.collect()
    try:  # glibc-only; a no-op (and never fatal) on any other libc/platform.
        import ctypes

        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


def _render_tile_run(doc: "fitz.Document", page_rects: Sequence[PageRect], ids: Sequence[int],
                     board: Any, dpi: int, scale: float | None = None,
                     snap_width: int | None = None, sat_column: int | None = None) -> Image.Image:
    pieces = []
    for i in ids:
        page_rect = page_rects[i]
        piece = render_page_rect(doc, page_rect, dpi=dpi, scale=scale, snap_width=snap_width)
        if sat_column in (0, 1):
            _remove_sat_gutter_rule(piece, doc[page_rect.page_index], page_rect, int(sat_column))
        pieces.append(piece)
    try:
        image = _finalise_band(
            enforce_exact_width_2280(_assemble_pieces(pieces, board), target_width=TARGET_WIDTH)
        )
    finally:
        del pieces
    # Pieces are 300 dpi A4 rasterisations (~35 MB each) and the assembler holds another copy while
    # it works; releasing them before the next tile keeps a multi-tile question from stacking peaks
    # (the full-suite run on this 2 GB container was killed at 90 % before this line existed).
    release_memory()
    return image


def render_segment_tiles(pdf_path: str | Path, segment: Mapping[str, Any], *, dpi: int = RENDER_DPI,
                         scale: float | None = None, snap_width: int | None = None,
                         max_height: int = MAX_CROP_HEIGHT) -> List[RenderedSegment]:
    """Render one adapter segment, split at page boundaries when the crop would be too tall.

    A segment's height is set by its aspect ratio, not by the render dpi: the assembler
    always normalises to 2280 px wide, so a question whose source region is much taller
    than a page is wide (measured: 8464/P/1H June 2023 Q2, eight pages; 8464/B/1H Q7, six)
    cannot be one WEBP image at all -- the format's own ceiling is 16383 px and the output
    contract requires strictly less. Splitting at *page* boundaries keeps every tile on the
    locked geometry path (same assembler, same width normalisation, and each tile gets the
    verified 20 px top white band), where slicing pixels mid-page would cut a line of text
    in half. Long questions therefore ship as ``<id>_p1ofN.webp`` tiles.

    Ordinary segments -- the overwhelming majority -- come back as a single tile, so callers
    only branch when they care.
    """

    page_rects = _pages_from_segment(segment)
    if not page_rects:
        raise ValueError(f"segment has no pages: {segment!r}")
    if scale is None:
        scale = exact_width_scale(page_rects)
        if scale is not None and snap_width is None:
            # Auto exact-width mode: land every page on TARGET_WIDTH so the locked assembler
            # finds a canvas already at 2280 and skips its whole-canvas LANCZOS pass.
            snap_width = TARGET_WIDTH
    board = segment.get("board")
    sat_column = (segment.get("metadata") or {}).get("sat_column")
    with fitz.open(str(pdf_path)) as doc:
        page_widths = [float(doc[pr.page_index].rect.width) for pr in page_rects]
    queue: List[List[int]] = _plan_tile_runs(page_rects, page_widths, max_height)
    runs: List[tuple[List[int], Image.Image]] = []
    with fitz.open(str(pdf_path)) as doc:
        while queue:
            ids = queue.pop(0)
            image = _render_tile_run(doc, page_rects, ids, board, dpi, scale, snap_width,
                                     sat_column=sat_column)
            if image.height > max_height and len(ids) > 1:
                # The estimate came up short; cut this run in half and try again.
                del image
                release_memory()
                middle = len(ids) // 2
                queue.insert(0, ids[middle:])
                queue.insert(0, ids[:middle])
                continue
            runs.append((list(ids), image))

    base_id = str(segment.get("id") or segment.get("question_id") or segment.get("question_number"))
    total = len(runs)
    out: List[RenderedSegment] = []
    for number, (page_ids, image) in enumerate(runs, start=1):
        metadata = dict(segment.get("metadata") or {})
        metadata["tile"] = {"index": number, "count": total, "pages": page_ids, "max_height": max_height}
        out.append(RenderedSegment(
            segment_id=base_id if total == 1 else f"{base_id}_p{number}of{total}",
            image=image,
            source_pages=[page_rects[i].page_index for i in page_ids],
            metadata=metadata,
        ))
    return out


def render_segments(pdf_path: str | Path, segments: Iterable[Mapping[str, Any]], *, dpi: int = RENDER_DPI) -> List[RenderedSegment]:
    """Render every segment, flattened across tiles (use ``render_segment`` for one crop)."""

    out: List[RenderedSegment] = []
    for seg in segments:
        out.extend(render_segment_tiles(pdf_path, seg, dpi=dpi))
    return out


def _tile_limit_downscale(img: Image.Image, limit: int = MAX_CROP_HEIGHT) -> Image.Image:
    """Last-resort guard: shrink an assembled crop that exceeds the format's dimension limit.

    Reached only if a single source page (or a segment that cannot be split) is itself
    taller than the limit, which A4 at 2280 px width never is (≈3225 px). It exists so a
    production run degrades to a slightly smaller crop instead of dying mid-batch.
    """

    if img.height <= limit:
        return img
    ratio = limit / img.height
    resized = img.resize((img.width, limit), Image.LANCZOS)
    del ratio
    return _finalise_band(resized)


def measure_crop(img: Image.Image) -> Dict[str, Any]:
    """Width, height, locked top band, and the contract's top-band ink reading -- in memory.

    ``measure_top_band`` is the locked criterion the audit records (first row with at least two
    pixels below gray 250); ``top_band_ink`` is the stricter reading the shipped output contract
    applies to the decoded file (ANY channel below 250 inside the first 20 rows). Both run on the
    image already in memory, which lossless WEBP round-trips bit-exactly (verified 2026-09-29 on
    the real crops: decoded bytes == source bytes for methods 4 and 6), so measuring here is the
    same verdict as decoding the written file -- without the decode. See output_contracts.
    """

    arr = np.asarray(img if img.mode == "RGB" else img.convert("RGB"))
    rows = arr[: min(_TOP_BAND_PX, arr.shape[0])]
    ink = bool(rows.size and (rows[:, :, :3] < 250).any())
    # Same criterion as measure_top_band, applied to the 20-row head only (the band the contract
    # requires); a crop whose first ink sits below row 20 falls back to the locked full reading.
    head = np.asarray(Image.fromarray(rows, "RGB").convert("L"))
    ink_rows = np.where((head < 250).sum(axis=1) >= 2)[0]
    band: int | None = int(ink_rows.min()) if ink_rows.size else None
    if band is None and img.height > rows.shape[0]:
        band = measure_top_band(img)
    return {"width": int(img.width), "height": int(img.height), "top_band": band, "top_band_ink": ink}


def measurement_for(measurements: Mapping[str, Mapping[str, Any]], path: str | Path) -> Dict[str, Any]:
    """One recorded crop's geometry, keyed by the written path.

    The recorded keys are ``str(path)`` on purpose: the same structure is written to
    ``measurements.json`` and read back by tests and reports, so the string form is the canonical
    boundary representation and a ``Path`` key would not survive JSON. Callers therefore look a
    crop up through this function instead of building the key themselves -- handing a ``Path`` to
    a plain dict lookup used to be an ``AttributeError`` in a profiling harness, which is exactly
    the kind of interface mismatch that costs a run to notice.
    """

    key = str(path)
    if key in measurements:
        return dict(measurements[key])
    alt = str(Path(path).resolve())
    if alt in measurements:
        return dict(measurements[alt])
    raise KeyError(f"no recorded measurements for {key!r} "
                   f"(recorded: {len(measurements)} crop(s)); the crop was not rendered or was measured elsewhere")


def save_rendered_segments(rendered: Iterable[RenderedSegment], output_dir: str | Path, *, quality: int = 95,
                           measurements: Dict[str, Dict[str, Any]] | None = None,
                           method: int = WEBP_LOSSLESS_METHOD) -> List[Path]:
    """Save rendered QP crops as WEBP files; returns the written paths.

    File naming follows the segment id: one question is one file. A segment that had to be
    split (``render_segment_tiles``) arrives here as several ``<id>_p1ofN.webp`` tiles.

    When ``measurements`` is given, each written file's geometry is recorded there under its
    path (see ``measure_crop``) so callers do not have to re-open and re-decode what they just
    encoded -- that re-decode measured 4.7 s of a 35.7 s demo batch, 13 % of the run.
    """

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    written: List[Path] = []
    for item in rendered:
        path = out / f"{item.segment_id}.webp"
        img = item.image.convert("RGB") if item.image.mode != "RGB" else item.image
        img = _tile_limit_downscale(img)
        if measurements is not None:
            measurements[str(path)] = measure_crop(img)
        # Lossless WEBP preserves the post-anchor white band exactly for this
        # verification bridge. The production OutputManager remains authoritative
        # for final banks; this utility's job is to prove adapter boundaries
        # through the locked geometry without WEBP quantisation shifting faint ink.
        img.save(path, "WEBP", lossless=True, quality=quality, method=method)
        written.append(path)
        # libwebp's lossless scratch and any P->RGB copy are dead once the file is on disk.
        release_memory()
    return written


def measure_top_band(img: Image.Image) -> int | None:
    """Locked criterion: first row with at least two pixels below gray 250."""

    import numpy as np

    gray = np.asarray(img.convert("L"))
    ink_rows = np.where((gray < 250).sum(axis=1) >= 2)[0]
    if ink_rows.size == 0:
        return None
    return int(ink_rows.min())
