"""International Baccalaureate adapter.

This adapter is deliberately conservative. IB papers are not Cambridge-like:
timezone, level, language and paper number are native IB identity fields. The
adapter consumes official sample/specimen text where available and can segment
question prompts in the English A Paper 2 specimen once a PDF/layout context is
available. It does not invent unavailable timezone/session data.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from adapters.base import BoardAdapter, DocumentContext, Evidence
from adapters.common_text import page_size, pages_from_layout, page_texts
from adapters.layout_profiles import LayoutArchetype, crop_plan, select_layout_archetype

_SPEC_CODE = re.compile(r"\bSPEC/([0-9])/([A-Z0-9]+)/([A-Z]+)([0-9])?/([A-Z]{3})/TZ([0-9])/XX(?:/([A-Z]))?\b")
# Printed cover-title aliases for course papers that do not expose a SPEC code.
# Long, exact phrases are preferred; short generic course names are considered
# only on first-page text, not arbitrary question-body occurrences.
_IB_SUBJECT_TITLES = {
    "IBBI": ("Biology", ("biology",)),
    "IBBM": ("Business management", ("business management",)),
    "IBCH": ("Chemistry", ("chemistry",)),
    "IBCL": ("Classical languages: Latin", ("classical languages: latin", "classical languages latin", "latin")),
    "IBCS": ("Computer science", ("computer science",)),
    "IBDA": ("Dance", ("dance",)),
    "IBDT": ("Design technology", ("design technology",)),
    "IBDS": ("Digital society", ("digital society",)),
    "IBEC": ("Economics", ("economics",)),
    "IBES": ("Environmental systems and societies", ("environmental systems and societies", "environmental systems & societies")),
    "IBFI": ("Film", ("film",)),
    "IBGE": ("Geography", ("geography",)),
    "IBGP": ("Global politics", ("global politics",)),
    "IBHI": ("History", ("history",)),
    "IBLL": ("Language A: language and literature", ("language a: language and literature", "language a language and literature")),
    "IBLT": ("Language A: literature", ("language a: literature", "language a literature")),
    "IBLBF": ("Language B French", ("language b french", "french b", "french language b")),
    "IBLBS": ("Language B Spanish", ("language b spanish", "spanish b", "spanish language b")),
    "IBLP": ("Literature and performance", ("literature and performance",)),
    "IBMA": ("Mathematics: analysis and approaches", ("mathematics: analysis and approaches", "mathematics analysis and approaches", "mathematics aa")),
    "IBAI": ("Mathematics: applications and interpretation", ("mathematics: applications and interpretation", "mathematics applications and interpretation", "mathematics ai")),
    "IBMU": ("Music", ("music",)),
    "IBPL": ("Philosophy", ("philosophy",)),
    "IBPH": ("Physics", ("physics",)),
    "IBPS": ("Psychology", ("psychology",)),
    "IBSA": ("Social and cultural anthropology", ("social and cultural anthropology",)),
    "IBSE": ("Sports, exercise and health science", ("sports, exercise and health science", "sports exercise and health science")),
    "IBTH": ("Theatre", ("theatre",)),
    "IBVA": ("Visual arts", ("visual arts",)),
    "IBWR": ("World religions / Religion and society", ("world religions", "religion and society")),
}
# A question start is "1." possibly followed by its text. The text is OPTIONAL on
# purpose: real IB papers (measured on the mirror-sourced May 2024 AA HL Paper 1,
# 2026-09-21) put the number alone on its line with the question following
# underneath, so requiring "\s+(.+)" matched nothing on a real paper and silently
# dropped the whole document to the text-only fallback.
_Q_PROMPT = re.compile(r"^\s*(\d{1,2})\.(?:\s+(.+))?\s*$", re.M)


# --- Question-paper page geometry (multi-page questions) ------------------------
# Measured on the mirror-sourced May 2024 AA HL Paper 1 (17 pp, 2026-09-21):
#   * question markers sit at x0=42.5, the leftmost content of any kind at 42.5
#     and the widest text at x1=555.8;
#   * every page carries furniture at the top (page label " - N - " and running
#     code "2224 - 7101", y 40.6-52.9) and at the bottom (a barcode at y 777.8-
#     812.7 with the paper code below it, plus printer register combs that bleed
#     off the page);
#   * content stops at y=770.8 on every question page (the answer-space border),
#     so a crop ending at the legacy h-46=796 clipped through the barcode.
# A question that needs more room continues on the next page under the printed
# header "(Question 9 continued)" - the question paper, unlike the mark scheme,
# says so in words, so a question's page span is every content page up to the
# next question's start page. Instruction pages ("Please do not write on this
# page ... will not be marked") are paper furniture and never join a span.
_QP_PAGE_TOP = 58.0           # continuation top: clears the 40.6-52.9 furniture band
_QP_FIRST_TOP_PAD = 12.0      # clearance above a question's own first line
_QP_LEFT = 30.0               # 12.5pt clear of the leftmost content (42.5)
_QP_RIGHT_PAD = 30.0          # 26.5pt clear of the widest text (555.8)
_QP_BOTTOM_PAD = 68.0         # content ends 770.8; barcode starts 777.8 (h-68 = 774.0)
_QP_SAME_PAGE_GAP = 8.0       # cut between two questions sharing one page
_QP_CONTINUED = re.compile(r"^\(Question\s+\d+\s+continued\)$", re.I)
_QP_INSTRUCTION = re.compile(
    r"please do not write on this page|answers written on this page", re.I)


def _qp_is_question_page(page: Mapping[str, Any]) -> bool:
    """True for a page that can carry question content.

    Blank pages and the "Please do not write on this page / Answers written on
    this page will not be marked" notices are furniture: they belong to no
    question and must not be added to a question's page span.
    """
    lines = _ms_page_lines(page)
    if not lines:
        return False
    page_text = str(page.get("text") or "\n".join(line[3] for line in lines))
    # Some recent IB papers append a bibliography after the final question. Its
    # numbered citations (e.g. "2.", "3.") look exactly like fresh question
    # starts to the generic marker recognizer; the page is source apparatus, not
    # a candidate question page, and must not extend the last crop or create Qs.
    has_reference_tail = bool(re.search(r"(?im)^\s*References\s*:\s*$", page_text))
    has_disclaimer = bool(re.search(r"(?im)^\s*Disclaimer\s*:\s*$", page_text))
    if has_reference_tail and has_disclaimer:
        return False
    return not any(_QP_INSTRUCTION.search(text) for _, _, _, text in lines)


# --- Mark-scheme geometry ------------------------------------------------------
# Measured on the mirror-sourced May 2024 AA HL Paper 1 markscheme (33 pp,
# 2026-09-21). Ink extents across the 27 answer pages, text AND vector rules:
#   x0 = 42.6  question-number column (a vertical rule shares this x)
#   x1 = 572.9 a rule on p9 (widest text line reaches 570.1)
#   y1 = 796.6 the closing "Total [17 marks]" row and a rule on p28
# Page furniture is the label " - N - " (x0 282.5/285.5) and the running code
# "2224 - 7101M" (x0 484.3); both sit at y 47.1-59.5 on EVERY answer page, so a
# crop that starts above 59.5 picks up page furniture and one that ends before
# 796.6 clips the last row. These boxes are therefore derived from this
# document's own ink, NOT inherited from the question paper: a question paper's
# widest line stops at x1=555.8 and it has no content past y=772, while this
# mark scheme is 16pt wider on the right and 25pt deeper. Same lesson as the AQA
# mark scheme: a crop box is a property of the document type, never of the board.
_MS_MARK_CODES = re.compile(r"^\(?[MARC]\d?\)?$|^AG$")   # (M1) A1 M1 AG R1 ...
_MS_TOTAL_ROW = re.compile(r"^\s*Total\s*\[", re.I)
_MS_FURNITURE_BOTTOM = 62.0   # bottom of the page-label band (59.5) + slack
_MS_PAGE_TOP = 66.0           # continuation-page top: clears the band, above body (83.3)
_MS_FIRST_TOP_PAD = 12.0      # clearance above the first ink of a first page
_MS_LEFT = 30.0               # 12.6pt clear of the leftmost ink (42.6)
_MS_RIGHT_PAD = 16.0          # 6.4pt clear of the rightmost ink (572.9)
_MS_BOTTOM_PAD = 36.0         # 9.4pt clear of the deepest ink (796.6)
_MS_MARKER_MAX_X0 = 60.0      # question numbers sit at x0 42.6-50.2
_MS_ROW_TOL = 2.0             # vertical tolerance when merging ink into visual rows
_MS_SAME_PAGE_GAP = 8.0       # cut between two questions sharing one page
# Recent IB sciences markschemes use table rows such as "1." / "8" in the
# question column, followed by subpart letters in a separate column. Older IB
# layouts use prose markers with the question text on the same line.
_MS_TABLE_QUESTION = re.compile(r"^\s*(\d{1,2})(?:\.(?:\s+.*)?|\s+.*)?$")
_MS_TABLE_HEADER_LABELS = {"question", "answers", "total"}
_MS_TABLE_MAX_ROW = re.compile(r"^max$", re.I)


def _ms_page_lines(page: Mapping[str, Any]) -> List[Tuple[float, float, float, str]]:
    out: List[Tuple[float, float, float, str]] = []
    for line in page.get("lines") or []:
        bbox = line.get("bbox") or []
        text = str(line.get("text", "")).strip()
        if len(bbox) == 4 and text:
            out.append((float(bbox[1]), float(bbox[3]), float(bbox[0]), text))
    return out


def _ms_body_lines(page: Mapping[str, Any]) -> List[Tuple[float, float, float, str]]:
    """Lines below the page furniture band, i.e. real markscheme content."""
    return [l for l in _ms_page_lines(page) if l[0] >= _MS_FURNITURE_BOTTOM]


def _ms_has_answer_table_header(page: Mapping[str, Any]) -> bool:
    """Recognize the repeated Question/Answers/Total grid in newer IB sciences MS PDFs."""
    labels = {" ".join(text.split()).strip().casefold()
              for _, _, _, text in _ms_page_lines(page)}
    return _MS_TABLE_HEADER_LABELS.issubset(labels)


def _ms_is_answer_page(page: Mapping[str, Any]) -> bool:
    """True when the page carries IB markscheme answers, not numbered front matter.

    Older markschemes expose M1/A1/AG codes in the right-hand marks column.
    Recent Biology-style tables do not, so accept their explicit Question / Answers
    / Total header. The Section A/B first page is also valid when it has a top-level
    question-number row; the prose guidance page before Section B has no such row.
    """
    lines = _ms_page_lines(page)
    if any(x0 > 480.0 and bool(_MS_MARK_CODES.match(text)) for _, _, x0, text in lines):
        return True
    if _ms_has_answer_table_header(page):
        return True
    has_section_heading = any(re.fullmatch(r"Section\s+[AB]", text.strip(), re.I)
                              for _, _, _, text in lines)
    has_question_row = any(x0 <= _MS_MARKER_MAX_X0 and _MS_TABLE_QUESTION.match(text)
                           for y0, y1, x0, text in _ms_body_lines(page))
    return has_section_heading and has_question_row


def _ms_bands(lines: Sequence[Tuple[float, float, float, str]]) -> List[List[float]]:
    """Merge ink into visual rows by vertical overlap.

    A markscheme row is not one line object: the stacked superscripts of a row
    report fragments whose tops start ABOVE the row's main text (measured: on p7
    the "10^(1/3)" superscripts start at y0=86.5 while the row's "2. (a)" starts
    at y0=98.2). Anything that reads "ink above y" as "the previous question's
    tail" therefore misreads a question's own first row, which is why the
    boundary test below works on merged rows and not on raw line boxes.
    """
    bands: List[List[float]] = []
    for y0, y1 in sorted((l[0], l[1]) for l in lines):
        if bands and y0 <= bands[-1][1] + _MS_ROW_TOL:
            bands[-1][1] = max(bands[-1][1], y1)
        else:
            bands.append([y0, y1])
    return bands


def _ms_borrows_page_top(page: Mapping[str, Any], y0: float, y1: float) -> bool:
    """True when substantive preamble ink sits above a question marker.

    In the newer table layout, the repeated column header is not content owned by
    the next question. Ignore those labels, but keep real material such as the
    Section B extended-response instructions. Legacy layouts retain the measured
    merged-row check because their marks-column fragments can sit above a marker.
    """
    if _ms_has_answer_table_header(page):
        headings = {"question", "answers", "notes", "total", "section a", "section b"}
        return any(line_y0 < y0 and line_y1 <= y0 + _MS_ROW_TOL
                   and " ".join(text.split()).strip().casefold() not in headings
                   for line_y0, line_y1, _x0, text in _ms_body_lines(page))
    bands = _ms_bands(_ms_body_lines(page))
    for top, bottom in bands:
        if top <= y1 and bottom >= y0:
            return any(b[1] < top for b in bands)
    return False


def _ms_has_total_row(page: Mapping[str, Any]) -> bool:
    for _y0, _y1, x0, text in _ms_page_lines(page):
        if _MS_TOTAL_ROW.match(text):
            return True
        # Newer IB science schemes mark the closing row with a right-column
        # total plus a separate "max" note rather than "Total [n marks]".
        if x0 > 700.0 and _MS_TABLE_MAX_ROW.fullmatch(text.strip()):
            return True
    return False


class Adapter(BoardAdapter):
    BOARD_ID = "IB"
    BOARD_NAMES = ["International Baccalaureate", "IB", "IBO"]
    CONFIG_FILE = "config/boards/ib.yaml"

    def normalize_name(self, raw: str) -> str:
        return re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")

    def _hay(self, ctx: DocumentContext) -> str:
        return f"{ctx.filename}\n{ctx.first_page_text}\n{ctx.full_text}".lower()

    def identify_document(self, ctx: DocumentContext) -> List[Evidence]:
        hay = self._hay(ctx)
        out: List[Evidence] = []
        if "international baccalaureate" in hay or "ibo.org" in hay:
            out.append(Evidence("board_signature", "board", self.BOARD_ID, 0.95, "IB/IBO source text", "document"))
        if _SPEC_CODE.search(ctx.full_text or ctx.first_page_text or ""):
            out.append(Evidence("component_code", "board", self.BOARD_ID, 1.0, "IB SPEC code present", "document"))
        return out

    def identify_subject(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        out: List[Evidence] = []
        if "English A: literature" in text:
            out.append(Evidence("first_page_text", "subject", "English A: literature", 0.95, "official specimen title", "document"))
            out.append(Evidence("qualification_code", "subject_code", "A1ENG", 0.75, "English A literature specimen code family", "document"))
        elif "Biology" in text and "Paper 1A" in text:
            out.append(Evidence("first_page_text", "subject", "Biology", 0.9, "official specimen title", "document"))
            out.append(Evidence("qualification_code", "subject_code", "BIOLO", 0.75, "Biology specimen code family", "document"))

        # Most live course papers are title-bearing rather than SPEC specimens.
        # Some recent papers put the IB copyright/license notice on page 1 and
        # the actual subject/paper title on page 2; inspect only the first two
        # physical pages, not the question body, when resolving the title.
        title_pages = (ctx.layout or {}).get("pages") or []
        if title_pages:
            title_text = "\n".join(str(page.get("text") or "") for page in title_pages[:2])
        else:
            page_text = (ctx.full_text or text).split("\f")
            title_text = "\n".join(page_text[:2]) if len(page_text) > 1 else (ctx.first_page_text or text)
        title_matches = []
        for code, (display, aliases) in _IB_SUBJECT_TITLES.items():
            for alias in aliases:
                pattern = r"(?<![A-Za-z0-9])" + re.escape(alias).replace(r"\ ", r"\s+") + r"(?![A-Za-z0-9])"
                if re.search(pattern, title_text, re.I):
                    title_matches.append((len(alias), code, display, alias))
        if title_matches:
            longest = max(match[0] for match in title_matches)
            best = {(code, display) for length, code, display, _alias in title_matches if length == longest}
            if len(best) == 1:
                code, display = next(iter(best))
                if not any(e.field == "subject_code" for e in out):
                    out.append(Evidence("first_page_text", "subject", display, 0.94,
                                        "official course title on first page", "document"))
                    out.append(Evidence("first_page_text", "subject_code", code, 0.94,
                                        "course title maps to canonical IB profile", "document"))

        m = _SPEC_CODE.search(text)
        is_mataa = bool(re.search(r"mathematics\s*:\s*analysis\s+and\s+approaches", text, re.I))
        is_mataa = is_mataa or bool(m and m.group(2) == "MATAA")
        if is_mataa:
            out.append(Evidence("first_page_text", "subject", "Mathematics: analysis and approaches", 0.98,
                                "official IB subject title / MATAA component code", "document"))
            out.append(Evidence("component_code", "subject_code", "IBMA", 0.98,
                                "MATAA maps to the IBMA runtime subject profile", "document"))
            if m:
                out.append(Evidence("component_code", "ib_subject_number", "MATAA", 1.0,
                                    f"IB code {m.group(0)!r}", "document"))
        elif m and not any(e.field == "subject_code" for e in out):
            native_code = m.group(2)
            profile_code = {"MATAA": "IBMA", "MATAI": "IBAI"}.get(native_code, native_code)
            out.append(Evidence("component_code", "subject_code", profile_code, 0.9,
                                f"IB code {m.group(0)!r}", "document"))
        return out

    def identify_qualification(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        if "Diploma" in text or "Higher and standard level" in text or "Higher level" in text:
            return [Evidence("first_page_text", "qualification", "DP", 0.9, "DP specimen wording / HL-SL levels", "document")]
        return []

    def identify_session(self, ctx: DocumentContext) -> List[Evidence]:
        """Read the examination session the document prints.

        Real IB covers carry it as a date line ("1 May 2024 | Zone A afternoon")
        or a session label ("May 2024"); specimens carry "SPEC/". The token is
        matched against this adapter's OWN config session table, and it is
        anchored to a following four-digit year ON PURPOSE: "may" is an English
        modal verb, and every IB page-1 copyright notice reads "No part of this
        product may be reproduced ..." - matching that would stamp a false May
        session on every paper in the corpus. Validated against real mirror-sourced
        papers (2026-09-21, A4): both the QP and its markscheme resolve to May 2024.
        """
        text = ctx.full_text or ctx.first_page_text or ""
        out: List[Evidence] = []
        if "Specimen paper" in text or "SPEC/" in text:
            # field is "season": that is the name every consumer asks for
            # (adapters.associations._ask("identify_session", "season")). Emitting
            # "session" here made the evidence invisible (found 2026-09-21).
            out.append(Evidence("first_page_text", "season", "SPECIMEN", 1.0, "specimen paper", "document"))
        session_year: Optional[int] = None
        for spec in self.sessions():
            token = str(getattr(spec, "name", "") or "").strip()
            if len(token) < 3:
                continue
            m = re.search(r"\b" + re.escape(token) + r"\s+(20\d{2}|19\d{2})\b", text)
            if m:
                out.append(Evidence("first_page_text", "season", spec.name, 0.9,
                                    f"session date line {m.group(0)!r}", "document"))
                session_year = int(m.group(1))
                break
        if session_year is not None:
            out.append(Evidence("first_page_text", "year", session_year, 0.9,
                                "year taken from the session date line", "document"))
            return out
        m = re.search(r"©\s*International Baccalaureate Organization\s*(20\d{2}|19\d{2})", text)
        if m:
            out.append(Evidence("first_page_text", "year", int(m.group(1)), 0.7, "copyright/source year, not an exam session", "document"))
        return out

    def identify_component(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        out: List[Evidence] = []
        # The previous check could only ever match "Paper 2", so a real Paper 1 or
        # Paper 3 could only be named by the legacy fallback parser - two
        # authorities for the same field. Now the adapter supplies it, and stays
        # silent when the document names more than one paper (UNKNOWN over a guess).
        papers: List[str] = []
        for m in re.finditer(r"\bPaper\s+([123])\b", text, re.I):
            if m.group(1) not in papers:
                papers.append(m.group(1))
        if len(papers) == 1:
            out.append(Evidence("first_page_text", "component", f"Paper {papers[0]}", 0.9,
                                f"Paper {papers[0]} title", "document"))
            out.append(Evidence("first_page_text", "paper_number", papers[0], 0.9,
                                f"Paper {papers[0]} title", "document"))
        if "Higher and standard level" in text or "Higher and Standard level" in text:
            out.append(Evidence("first_page_text", "level", "HL_SL", 0.85, "Higher and standard level", "document"))
        m = _SPEC_CODE.search(text)
        if m:
            out.append(Evidence("component_code", "component", m.group(0), 0.95, "IB native SPEC code", "document"))
            out.append(Evidence("component_code", "timezone", f"TZ{m.group(6)}", 0.95, "timezone from IB SPEC code", "document"))
        return out

    def identify_document_type(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.full_text or ctx.first_page_text or ""
        if re.search(r"examiner.?s? report|report on the examination", text, re.I):
            return [Evidence("header_footer", "document_type", "ER", 0.9, "IB examiner report title", "document")]
        if "Markscheme" in text or "marking notes" in text:
            return [Evidence("header_footer", "document_type", "MS", 0.85, "markscheme/marking notes text", "document")]
        # "Answer one question" is the ESSAY-paper wording. Real science and
        # mathematics papers say "answer all questions" (measured on the
        # mirror-sourced May 2024 AA HL Paper 1, 2026-09-21), so requiring the
        # essay wording typed every maths paper as UNKNOWN.
        if "Instructions to candidates" in text and re.search(r"answer (all|one) question", text, re.I):
            return [Evidence("header_footer", "document_type", "QP", 0.9, "IB question-paper instructions", "document")]
        return []

    def identify_question_structure(self, ctx: DocumentContext) -> List[Evidence]:
        segs = self.segment(ctx)
        if segs:
            return [Evidence("document_structure", "question_count", len(segs), 0.9, "IB prompt segmentation", "document")]
        return []

    def identify_mark_scheme(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "MS"]

    def identify_examiner_report(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "ER"]

    def segments_document(self) -> bool:
        return True

    def segments_mark_scheme(self) -> bool:
        return True

    def _ms_question_starts(self, ctx: DocumentContext) -> List[Tuple[int, int, float, float]]:
        """(question number, page_index, marker top, marker bottom) per top-level start.

        Some IB sciences markschemes repeat the top-level number beside every
        subpart and omit the trailing period in Section B. Collapse only adjacent
        repeats; a non-consecutive duplicate remains a structural error in the
        sequence check below.
        """
        raw: List[Tuple[int, int, float, float]] = []
        for page in pages_from_layout(ctx):
            if not _ms_is_answer_page(page):
                continue
            page_index = int(page.get("page_index", 0))
            for y0, y1, x0, text in _ms_body_lines(page):
                match = _MS_TABLE_QUESTION.match(text)
                if match and x0 <= _MS_MARKER_MAX_X0:
                    raw.append((int(match.group(1)), page_index, y0, y1))
        raw.sort(key=lambda item: (item[1], item[2]))
        out: List[Tuple[int, int, float, float]] = []
        for item in raw:
            if out and item[0] == out[-1][0]:
                continue
            out.append(item)
        return out

    def segment_mark_scheme(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        """Segment an IB markscheme into one region per top-level question.

        Returns ``[]`` -- never a partial set -- when the document does not
        present a clean 1..N of question starts, so the caller falls back to
        QP-only routing instead of emitting a markscheme whose coverage is
        quietly wrong. Two measured rules drive the page spans:

        1. A question owns whole pages, from its start page up to (but not
           including) the next question's start page, except when two questions
           share one page -- then the cut sits at the current question's own
           "Total [n marks]" row. Whole pages are deliberate: on this document 8
           of the 12 boundaries have the next question starting part-way down a
           page, and the ink above a marker is sometimes that question's own
           preamble (Q8's "Note:" block on p17, "Section B" above Q10 on p21).
        2. Such a borrowed page top is only trusted when the PREVIOUS question
           is provably closed by a "Total [n marks]" row on the page before.
           Without that row the segmentation refuses: guessing the boundary
           would silently drop marks.
        """
        if not self._text_scope_is_unambiguous(ctx):
            return []
        starts = self._ms_question_starts(ctx)
        if not starts:
            return []
        numbers = [item[0] for item in starts]
        # Strict 1..N in page order: one stray "10." (front matter p5 prints one
        # at x0=42.6) or a duplicated number means this is not a document whose
        # structure was understood, so refuse rather than emit a partial scheme.
        if numbers != list(range(1, len(numbers) + 1)):
            return []

        pages = {int(page.get("page_index", 0)): page for page in pages_from_layout(ctx)}
        answer_pages = sorted(pi for pi, page in pages.items() if _ms_is_answer_page(page))
        if not answer_pages:
            return []
        last_answer_page = answer_pages[-1]

        labels = self._segment_identity(ctx)
        if labels["subject_code"] == "UNKNOWN" or labels["component"] == "UNKNOWN":
            return []
        archetype = select_layout_archetype(self.BOARD_ID, ctx)
        segments: List[Dict[str, Any]] = []

        for idx, (qn, page_index, marker_top, marker_bottom) in enumerate(starts):
            if page_index not in pages:
                return []
            next_start = starts[idx + 1] if idx + 1 < len(starts) else None
            next_page = next_start[1] if next_start else last_answer_page + 1

            previous_same_page = idx > 0 and starts[idx - 1][1] == page_index
            if (idx > 0 and not previous_same_page
                    and _ms_borrows_page_top(pages[page_index], marker_top, marker_bottom)):
                if not _ms_has_total_row(pages.get(page_index - 1) or {}):
                    return []

            if next_page == page_index:
                # Two questions share one page. Prefer the explicit closure row;
                # table-style IB MS files use a right-column "max" marker instead
                # of "Total [n marks]". If neither is printed, the next top-level
                # row is still a verified table boundary, so cut immediately above it.
                totals = [b for a, b, x0, text in _ms_page_lines(pages[page_index])
                          if ( _MS_TOTAL_ROW.match(text)
                               or (x0 > 700.0 and _MS_TABLE_MAX_ROW.fullmatch(text.strip())) )
                          and marker_bottom < a < next_start[2]]
                if totals:
                    bottom = min(next_start[2] - 1.0, max(totals) + _MS_SAME_PAGE_GAP)
                elif _ms_has_answer_table_header(pages[page_index]):
                    bottom = next_start[2] - _MS_SAME_PAGE_GAP
                else:
                    return []
                if bottom <= marker_bottom:
                    return []
                page_rects = [(page_index, bottom)]
            else:
                page_rects = [(p, None) for p in range(page_index, next_page)]

            page_boxes: List[Dict[str, Any]] = []
            for p, cut in page_rects:
                w, h = page_size(ctx, p)
                body = _ms_body_lines(pages[p])
                if p == page_index:
                    if previous_same_page:
                        # Start after the preceding question's last row; using the
                        # page's first ink here would duplicate the earlier question.
                        top = max(_MS_PAGE_TOP, marker_top - _MS_FIRST_TOP_PAD)
                    else:
                        # A question's first page starts at that page's first ink,
                        # so a genuine preamble above the marker travels with it.
                        first_ink = min((line[0] for line in body), default=marker_top)
                        top = max(_MS_PAGE_TOP, first_ink - _MS_FIRST_TOP_PAD)
                else:
                    top = _MS_PAGE_TOP
                bottom = h - _MS_BOTTOM_PAD if cut is None else cut
                page_boxes.append({"page_index": p, "rect": (_MS_LEFT, top, w - _MS_RIGHT_PAD, bottom)})
            if not page_boxes:
                continue

            segments.append({
                "id": f"IB_{labels['subject_code']}_{labels['component']}_Q{qn}_MS",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": labels["component"],
                "pages": page_boxes,
                "metadata": {
                    "document_type": "MS",
                    "source_pages": [box["page_index"] + 1 for box in page_boxes],
                    "ib_level": labels["level"],
                    "ib_subject": labels["subject"],
                    "ib_subject_code": labels["subject_code"],
                    "paper_number": labels["paper_number"],
                    "timezone": labels["timezone"],
                    "ib_spec_code": labels["ib_spec_code"],
                    "session": labels["session"],
                    "layout_archetype": archetype.value,
                    "crop_plan": crop_plan(self.BOARD_ID, ctx),
                    "ms_geometry": (
                        "whole answer pages per question; first page top = that page's first ink - 12pt "
                        "(floor 66pt, below the page-label band at 47.1-59.5); continuation top 66pt; "
                        "box (30.0, top, w-16.0, h-36.0) measured against this markscheme's own ink "
                        "(x0 42.6, x1 572.9, y1 796.6) -- NOT the question paper's box"
                    ),
                },
            })
        return segments

    def _layout_question_positions(self, ctx: DocumentContext) -> List[Tuple[int, int, float]]:
        out: List[Tuple[int, int, float]] = []
        for page in pages_from_layout(ctx):
            if not _qp_is_question_page(page):
                continue
            pi = int(page.get("page_index", 0))
            for line in page.get("lines") or []:
                txt = str(line.get("text", "")).strip()
                m = _Q_PROMPT.match(txt)
                if not m:
                    continue
                bbox = line.get("bbox") or []
                if len(bbox) == 4:
                    # Actual top-level question labels align with the left paper
                    # margin. Indented numbered subparts / labels within data
                    # graphics also match _Q_PROMPT but are not new questions.
                    # The smallest real-paper label is x0≈42.5pt; x0≈72pt is
                    # already an indented part, so keep a small measured margin.
                    if float(bbox[0]) <= 60.0:
                        out.append((int(m.group(1)), pi, float(bbox[1])))
        return sorted(out, key=lambda t: (t[1], t[2], t[0]))

    def _segment_identity(self, ctx: DocumentContext) -> Dict[str, str]:
        """Labels for a segment, taken from THIS document's own evidence."""
        text = ctx.full_text or ctx.first_page_text or ""
        component = "UNKNOWN"
        level = "UNKNOWN"
        subject = "UNKNOWN"
        subject_code = "UNKNOWN"
        for ev in self.identify_component(ctx):
            value = str(getattr(ev, "value", "") or "")
            if ev.field == "component" and re.fullmatch(r"Paper\s+[123]", value):
                component = "P" + value.split()[-1]
            elif ev.field == "level":
                level = value
        for ev in self.identify_subject(ctx):
            if ev.field == "subject":
                subject = str(ev.value)
            elif ev.field == "subject_code":
                subject_code = str(ev.value)

        # A paper-code family is authoritative when the title does not give a
        # unique paper number. Ignore the optional /M suffix in the identity key:
        # it distinguishes the markscheme from the QP, not a different subject,
        # level, paper or timezone.
        spec_codes = list(_SPEC_CODE.finditer(text))
        spec_identities = {
            (m.group(2), m.group(3), m.group(4) or "", m.group(5), m.group(6))
            for m in spec_codes
        }
        if len(spec_identities) == 1 and spec_codes:
            m = spec_codes[0]
            if component == "UNKNOWN" and m.group(4):
                component = f"P{m.group(4)}"
            if level == "UNKNOWN":
                level = "HL" if m.group(3).startswith("H") else "SL" if m.group(3).startswith("S") else "UNKNOWN"
            if subject_code == "UNKNOWN":
                subject_code = "IBMA" if m.group(2) == "MATAA" else m.group(2)

        if level == "UNKNOWN":
            higher = bool(re.search(r"\bHigher level\b", text))
            standard = bool(re.search(r"\bStandard level\b", text))
            if higher and not standard:
                level = "HL"
            elif standard and not higher:
                level = "SL"
        session = "UNKNOWN"
        for ev in self.identify_session(ctx):
            if ev.field == "season":
                session = str(ev.value)
                break
        timezone = f"TZ{spec_codes[0].group(6)}" if len(spec_identities) == 1 and spec_codes else "UNKNOWN"
        spec_code = spec_codes[0].group(0) if len(spec_identities) == 1 and spec_codes else "UNKNOWN"
        paper_number = component[1:] if re.fullmatch(r"P[123]", component) else "UNKNOWN"
        return {"component": component, "level": level, "session": session,
                "subject": subject, "subject_code": subject_code,
                "timezone": timezone, "paper_number": paper_number,
                "ib_spec_code": spec_code}

    def _text_scope_is_unambiguous(self, ctx: DocumentContext) -> bool:
        """Refuse combined/mixed files rather than duplicate or cross-label prompts."""
        text = ctx.full_text or ctx.first_page_text or ""
        spec_identities = {
            (m.group(2), m.group(3), m.group(4) or "", m.group(5), m.group(6))
            for m in _SPEC_CODE.finditer(text)
        }
        if len(spec_identities) > 1:
            return False
        paper_numbers = set(re.findall(r"\bPaper\s+([123])\b", text, re.I))
        if len(paper_numbers) > 1:
            return False
        has_qp = bool("Instructions to candidates" in text and re.search(r"answer (all|one) question", text, re.I))
        has_ms = bool(re.search(r"\bMarkscheme\b|\bMark\s+scheme\b", text, re.I))
        if has_qp and has_ms:
            return False
        return True

    def segment(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        text = ctx.full_text or ctx.first_page_text or ""
        # A combined specimen PDF (or a combined QP+MS text dump) is not one
        # component. Returning no segments is safer than duplicate Q1 IDs or a
        # markscheme crop being treated as a question-paper crop.
        if not self._text_scope_is_unambiguous(ctx):
            return []
        has_qp_instructions = bool("Instructions to candidates" in text and
                                   re.search(r"answer (all|one) question", text, re.I))
        if re.search(r"\bMarkscheme\b|\bMark\s+scheme\b", text, re.I) and not has_qp_instructions:
            return []

        # Layout path: real PDF/layout present, renderable by segment_geometry.
        positions = self._layout_question_positions(ctx)
        if positions:
            labels = self._segment_identity(ctx)
            if labels["subject_code"] == "UNKNOWN":
                return []
            archetype = select_layout_archetype(self.BOARD_ID, ctx)
            layout_pages = pages_from_layout(ctx)
            segments: List[Dict[str, Any]] = []
            for idx, (qn, page_index, y) in enumerate(positions):
                next_position = positions[idx + 1] if idx + 1 < len(positions) else None

                # One segment per question, over ALL of its pages. A question that
                # needs more room continues under a printed "(Question N continued)"
                # header (Q9 of the real paper holds its "sketch the graph" part on
                # the second page); cropping only the start page silently dropped
                # that answer space. Pages run up to, but never include, the page
                # the next question starts on.
                share_page_cut = None
                if next_position is not None and next_position[1] == page_index:
                    share_page_cut = max(40.0, next_position[2] - _QP_SAME_PAGE_GAP)
                    page_numbers = [page_index]
                else:
                    last = next_position[1] if next_position is not None else len(layout_pages)
                    page_numbers = [p for p in range(page_index, last)
                                    if _qp_is_question_page(layout_pages[p])]
                if not page_numbers:
                    continue

                # Margins measured on the real paper (May 2024 AA HL Paper 1,
                # 2026-09-21): question numbers sit at x0=42.5 and the widest text
                # reaches x1=555.8, so the original 48.0 margin CLIPPED the number
                # of every question it cropped (only the period survived). 30 pt
                # symmetric margins cover the full text extent; the bottom stops at
                # h-68 because a lower edge cut through the page barcode. Same rule
                # the AQA mark scheme needed: measure ink per document, never
                # inherit a box.
                page_boxes: List[Dict[str, Any]] = []
                for p in page_numbers:
                    w, h = page_size(ctx, p)
                    top = max(_QP_PAGE_TOP, y - _QP_FIRST_TOP_PAD) if p == page_index else _QP_PAGE_TOP
                    bottom = h - _QP_BOTTOM_PAD
                    if share_page_cut is not None and p == page_numbers[-1]:
                        bottom = min(bottom, share_page_cut)
                    page_boxes.append({"page_index": p, "rect": (_QP_LEFT, top, w - _QP_RIGHT_PAD, bottom)})

                segments.append({
                    "id": f"IB_{labels['subject_code']}_{labels['component']}_Q{qn}",
                    "question_number": qn,
                    "board": self.BOARD_ID,
                    "component": labels["component"],
                    "canonical_question": qn,
                    "pages": page_boxes,
                    "metadata": {"source_page": page_index + 1,
                                 "source_pages": [box["page_index"] + 1 for box in page_boxes],
                                 "ib_level": labels["level"],
                                 "ib_subject": labels["subject"],
                                 "ib_subject_code": labels["subject_code"],
                                 "paper_number": labels["paper_number"],
                                 "timezone": labels["timezone"],
                                 "ib_spec_code": labels["ib_spec_code"],
                                 "session": labels["session"], "layout_archetype": archetype.value,
                                 "crop_plan": crop_plan(self.BOARD_ID, ctx),
                                 "naming_decision": "IB segment labelled from document evidence, not the specimen fixture"},
                })
            return segments

        # Text-only proof path: identity still comes from the document. This path
        # is not renderable and never invents a subject, paper, level or session.
        labels = self._segment_identity(ctx)
        source_ref = str(ctx.source_url or ctx.provenance.get("source_url", "")).lower()
        is_official_ibo = "ibo.org" in source_ref
        if labels["subject_code"] == "UNKNOWN" or labels["component"] == "UNKNOWN":
            return []
        prompts = [(int(m.group(1)), (m.group(2) or "").strip()) for m in _Q_PROMPT.finditer(text)]
        if not prompts:
            return []
        source_note = ("official IBO extracted text; PDF geometry unavailable" if is_official_ibo
                       else "text-only source; PDF geometry unavailable")
        archetype = (LayoutArchetype.TEXT_ONLY_OFFICIAL_SOURCE.value if is_official_ibo
                     else select_layout_archetype(self.BOARD_ID, ctx).value)
        return [{
            "id": f"IB_{labels['subject_code']}_{labels['component']}_Q{qn}",
            "question_number": qn,
            "board": self.BOARD_ID,
            "component": labels["component"],
            "canonical_question": f"Q{qn}",
            "pages": [],
            "text_only": True,
            "metadata": {"prompt": prompt, "source": source_note, "renderable": False,
                         "document_type": "QP", "ib_subject": labels["subject"],
                         "ib_subject_code": labels["subject_code"],
                         "ib_level": labels["level"], "paper_number": labels["paper_number"],
                         "timezone": labels["timezone"], "ib_spec_code": labels["ib_spec_code"],
                         "session": labels["session"], "layout_archetype": archetype,
                         "crop_plan": crop_plan(self.BOARD_ID, ctx)},
        } for qn, prompt in prompts]
