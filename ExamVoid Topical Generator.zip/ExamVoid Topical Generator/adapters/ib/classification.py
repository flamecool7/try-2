"""IB questions classified by the SAME machinery as Cambridge subjects.

Twin of ``adapters.edexcel.classification`` (profile discovery pointed at
``subjects_ib/`` instead of ``subjects_edexcel/``). IB-only note: components
carry paper letters (``IBBI/1A``, ``IBBI/1B``, ``IBBI/2``); core's per-paper
gate reads the variant's first character, so 1A/1B both gate to paper "1"
with no adjustment needed (no zero-padded variants exist on this board).

An IB subject profile lives in
``subjects_ib/<Programme>/<Subject_Code>/config.json`` in the Cambridge
``SubjectConfig`` schema. It is loaded into
``core.config_loader.SubjectConfig`` and classified by
``core.classifier.TopicClassifier`` — never a parallel keyword scorer.

Nothing under ``core/`` changes; CAIE behaviour is byte-identical.

IB vocabularies are PROVISIONAL (guides paywalled; built from official
subject briefs + IBO pages + CAIE-cognate vocab — see each profile's
validation/provenance notes). Full-standard profiles need user-supplied
guides.

Fallback (allowed by the work order, never primary): a spec code with no
profile here, or a profile that fails to load, falls back to
``adapters.nonib_topics`` (the Phase-0 vocabulary) and says so
(``engine: nonib_fallback``).
"""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Iterable, Optional

from adapters import nonib_topics as _fallback

PROJ = Path(__file__).resolve().parent.parent.parent
PROFILE_ROOT = PROJ / "subjects_ib"

_CACHE: Dict[tuple[str, str], Any] = {}


def _root_profile_path(spec_code: str) -> Optional[Path]:
    code = str(spec_code or "").strip().upper()
    for cfg in sorted(PROFILE_ROOT.glob(f"*/*_{code}/config.json")):
        return cfg
    return None


def profile_path(spec_code: str, year: Any = None) -> Optional[Path]:
    """Resolve the IB course profile for a paper's assessment year.

    Root ``config.json`` files retain their legacy/current cohort taxonomy.
    Explicit ``version_routes`` on those files select separate revised-course
    configs from their first-assessment year onward. Unknown years deliberately
    select the root profile rather than guessing a future syllabus. Root profiles
    can themselves be the current guide when no distinct legacy/new-course
    transition is tracked for that subject.
    """
    root = _root_profile_path(spec_code)
    if root is None:
        return None
    try:
        assessment_year = int(str(year).strip()) if year not in (None, "") else None
    except (TypeError, ValueError):
        assessment_year = None
    if assessment_year is None:
        return root
    try:
        data = json.loads(root.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return root
    eligible = []
    for route in data.get("version_routes") or []:
        try:
            first_assessment = int(route.get("first_assessment"))
        except (TypeError, ValueError):
            continue
        if first_assessment <= assessment_year:
            eligible.append((first_assessment, route))
    if eligible:
        _first_assessment, selected = max(eligible, key=lambda item: item[0])
        target = (root.parent / str(selected.get("profile") or "")).resolve()
        # A declared route that is missing must fail closed; returning the old root
        # would silently classify a new-course paper against the wrong taxonomy.
        if not target.is_file():
            return None
    else:
        target = root
    try:
        selected_data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    supported_years = {str(y) for y in selected_data.get("syllabus_years") or []}
    # Historical/future years outside an explicitly declared cohort do not get
    # silently scored with the nearest profile. They go to review/fallback.
    if supported_years and str(assessment_year) not in supported_years:
        return None
    return target


def load_profile(spec_code: str, year: Any = None):
    """(SubjectConfig, TopicClassifier) for a code/cohort, or (None, None)."""
    path = profile_path(spec_code, year)
    key = (str(spec_code or "").strip().upper(), str(path or "<missing>"))
    if key in _CACHE:
        return _CACHE[key]
    if path is None:
        _CACHE[key] = (None, None)
        return _CACHE[key]
    from core.config_loader import SubjectConfig
    from core.classifier import TopicClassifier
    data = json.loads(path.read_text(encoding="utf-8"))
    config = SubjectConfig(data, config_path=path)
    if str(data.get("board", "")).upper() == "IB" and "mathematics" in str(config.subject).lower():
        # The shared core's legacy component-category branch treats every
        # mathematics-named profile as a Cambridge/GCE paper. Those generic
        # categories do not exist in the IB taxonomy. Give this classifier a
        # board-local subject key so it uses the IB profile's question topics.
        config.subject = f"IB_{key[0]}"
    classifier = TopicClassifier(config)          # no classification memory: never auto-populated
    _CACHE[key] = (config, classifier)
    return _CACHE[key]


def _stub(text: str, question_number: Any, component: str, year: str = "", season: str = "") -> SimpleNamespace:
    """A MatchedQuestion-shaped object carrying the crop's own text (marks read from the text)."""
    import re
    marks = sum(int(m) for m in re.findall(r"\[(\d{1,2})\s*marks?\]", text or "", re.I))
    qn_match = re.search(r"\d+", str(question_number or "0"))
    qn_int = int(qn_match.group(0)) if qn_match else 0
    qp = SimpleNamespace(text=text or "", marks=marks, paper_code=component, question_number=f"Q{qn_int}",
                         number_int=qn_int, assembled_image=None, images=[])
    # IB paper IDs are not Cambridge two-digit variants. Normalize the IB
    # paper number explicitly so the shared classifier never receives an empty
    # component (which would make the legacy mathematics branch raise before
    # falling back to the IB topic profile).
    component_text = str(component or "")
    paper_match = re.search(r"\b(?:HP|SP)([123])\b", component_text, re.I)
    if paper_match is None:
        paper_match = re.fullmatch(r"(?:P|Paper\s*)?([123])", component_text.strip(), re.I)
    if paper_match is None:
        for part in reversed(component_text.split("/")):
            paper_match = re.fullmatch(r"(?:P|Paper\s*)?([123])", part.strip(), re.I)
            if paper_match:
                break
    variant = paper_match.group(1) if paper_match else ""
    return SimpleNamespace(question_number=f"Q{qn_int}", number_int=qn_int,
                           qp=qp, ms=None, paper_code=component, full_qp_code=component, full_ms_code="",
                           year=year or "", season=season or "", variant=variant, subject="", paper_format="STRUCTURED")


def _confidence(result) -> float:
    """Calibrated like the Phase-0 formula, from the classifier's own major scores: margin between the
    winner and the runner-up plus the winner's strength against the 1.5-point floor."""
    scores = dict(result.major_topic_scores or {})
    if not scores or not result.winning_major:
        return 0.0
    top = float(scores.get(result.winning_major, 0.0))
    others = sorted((float(v) for k, v in scores.items() if k != result.winning_major), reverse=True)
    second = others[0] if others else 0.0
    margin = (top - second) / top if top > 0 else 0.0
    strength = min(1.0, top / 6.0)
    return round(min(0.97, 0.50 + 0.30 * margin + 0.20 * strength), 3)


def classify_text(spec_code: str, text: str, *, question_number: Any = 0, component: str = "",
                  year: str = "", season: str = "") -> Dict[str, Any]:
    config, classifier = load_profile(spec_code, year=year)
    selected_path = profile_path(spec_code, year=year)
    if classifier is None:
        # A known subject with an unsupported cohort (or a broken declared route)
        # must not be relabelled by the broad non-IB fallback. Keep it reviewable.
        if _root_profile_path(spec_code) is not None and year not in (None, ""):
            return {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED",
                    "evidence": [], "secondary": [], "spec": str(spec_code or "").upper(),
                    "engine": "ib_topic_classifier", "fallback_tier": "unsupported_assessment_year",
                    "profile_version": "unavailable", "profile_path": "", "candidates": [],
                    "reasoning": f"No declared IB profile for assessment year {year}"}
        out = _fallback.classify_segment_topic("IB", text, component=component)
        out["engine"] = "nonib_fallback"
        out["spec"] = str(spec_code or "").upper()
        out["profile_version"] = "unavailable"
        return out
    result = classifier.classify_question(_stub(text, question_number, component or spec_code, year, season))
    tier = getattr(result, "fallback_tier", "scored")
    scores = dict(result.major_topic_scores or {})
    ranked = sorted(scores.items(), key=lambda kv: (-float(kv[1]), kv[0]))
    if tier in ("review_required", "alphabetical_first", "paper_hint") or not result.winning_major:
        # fail closed exactly like a Cambridge question with insufficient direct evidence
        return {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED", "evidence": [],
                "secondary": [], "spec": spec_code, "engine": "ib_topic_classifier", "fallback_tier": tier,
                "profile_version": str(json.loads(selected_path.read_text(encoding="utf-8")).get("version") or "unknown") if selected_path else "unknown",
                "profile_path": str(selected_path.relative_to(PROJ)) if selected_path else "",
                "candidates": [{"topic": k, "score": round(float(v), 3)} for k, v in ranked[:3]],
                "reasoning": str(getattr(result, "reasoning", ""))[:300]}
    weights = dict(getattr(config, "specialization_weights", {}) or {})
    aspects = {k for k, w in weights.items() if float(w) < 1.0}      # 0475 precedent: forms primary, aspects secondary
    pool = [(k, v) for k, v in ranked if k != result.winning_major and (not aspects or k in aspects)]
    secondary = [k for k, v in pool if float(v) >= 1.5][:2]
    profile_data = json.loads(selected_path.read_text(encoding="utf-8")) if selected_path else {}
    return {"topic": result.winning_major, "confidence": _confidence(result), "status": "HINT",
            "evidence": list(result.detailed_topics or [])[:4] + [f"score {scores.get(result.winning_major, 0):.2f}"],
            "secondary": secondary, "spec": spec_code, "engine": "ib_topic_classifier", "fallback_tier": tier,
            "profile_version": str(profile_data.get("version") or "unknown"),
            "profile_path": str(selected_path.relative_to(PROJ)) if selected_path else "",
            "major_scores": {k: round(float(v), 3) for k, v in ranked[:4]},
            "reasoning": str(getattr(result, "reasoning", ""))[:300]}


def classify_segments(ctx, segments: Iterable[Dict[str, Any]], component: str = "",
                      year: Any = "", season: str = "") -> list[Dict[str, Any]]:
    """Classify IB QP segments in the production universal-batch pipeline.

    Subject identity comes from the IB adapter's document evidence or the
    segment metadata; no filename inference or cross-subject default is used.
    Assessment year selects the matching legacy/revised profile.
    """
    from adapters.ib.adapter import Adapter

    adapter = Adapter()
    labels = adapter._segment_identity(ctx)
    out: list[Dict[str, Any]] = []
    for seg in segments:
        metadata = seg.get("metadata") or {}
        spec_code = str(metadata.get("ib_subject_code") or labels.get("subject_code") or "").strip().upper()
        text, source = _fallback._segment_text(ctx, seg)
        if not text and metadata.get("prompt"):
            text = str(metadata.get("prompt") or "")
            source = "text_only_prompt"
        qn = seg.get("question_number")
        seg_component = str(seg.get("component") or component or labels.get("component") or "")
        if not spec_code or spec_code == "UNKNOWN":
            cls = {"topic": "UNKNOWN", "confidence": 0.0, "status": "REVIEW_REQUIRED",
                   "evidence": [], "secondary": [], "spec": "", "engine": "ib_topic_classifier",
                   "profile_version": "unresolved", "reasoning": "IB subject code not uniquely identified from document evidence"}
        else:
            cls = classify_text(spec_code, text, question_number=qn, component=seg_component,
                                year=str(year or ""), season=season)
        out.append({"question_number": qn,
                    "canonical_question": seg.get("canonical_question"),
                    "text_source": source,
                    "subject_code": spec_code,
                    **cls})
    return out
