# SAT official answer companions (Practice Tests 4–11)

The College Board bundle does not provide a separate traditional mark-scheme PDF. It provides a **scoring guide** (answer key and score conversion) and a separate **Answer Explanations** PDF. The import stage creates these per-question companions:

- `_MS.webp` — crop of that question's official worked answer explanation.
- `_MS.txt` — the correct answer copied from the corresponding scoring-guide module column, with source-page provenance. Student-produced-response alternatives are preserved as printed.

## Final delivery: CAIE-style topical tree

`tools/export_sat_caie_tree.py` runs the actual SAT adapter, SAT topic classifier, and shared crop renderer, then writes per-question folders in the same subject → paper → topic → question pattern used by the CAIE output tree:

```text
Digital_SAT/
  Reading_and_Writing_SATR/
    paper-4/
      Craft_and_Structure/
        SAT_T04_RW_M1_Practice_UNKNOWN_Q1/
          SAT_T04_RW_M1_Practice_UNKNOWN_Q1.webp
          SAT_T04_RW_M1_Practice_UNKNOWN_Q1_MS.webp
          SAT_T04_RW_M1_Practice_UNKNOWN_Q1_MS.txt
          metadata.json
  Math_SATM/
    paper-4/
      Algebra/
        SAT_T04_MATH_M1_Practice_UNKNOWN_Q1/
          SAT_T04_MATH_M1_Practice_UNKNOWN_Q1.webp
          SAT_T04_MATH_M1_Practice_UNKNOWN_Q1_MS.webp
          SAT_T04_MATH_M1_Practice_UNKNOWN_Q1_MS.txt
          metadata.json
```

`paper-4` is official Practice Test 4. Unresolved runtime classifications go under `paper-4/review_required/`; they are not forced into a topic. `RW` means Reading and Writing, and `M1`/`M2` are the module. Section and module are encoded into `paper`, `variant`, and the question-folder name because SAT numbers restart in every module. QP crops are 2280 px wide and retain the verified 20 px white top band after encoding; WEBP quality is 55 to keep the eight-test crop pack manageable without reducing its pixel dimensions; the saved band is checked after encoding. The explanation crop is kept at its native 765 px page scale rather than enlarged without adding detail (WEBP quality 85).

## CAIE-compatible `metadata.json`

Each question folder has its own canonical metadata file (the same 10 fields as the CAIE output contract):

```json
{
  "id": "<stable UUID>",
  "level": "Digital_SAT",
  "subject": "Reading_and_Writing_SATR",
  "board": "SAT",
  "topic": ["Craft_and_Structure"],
  "paper": "SAT_T04_RW_M1",
  "question_number": "Q1",
  "variant": "SAT_T04_RW_M1",
  "season": "Practice",
  "year": "UNKNOWN"
}
```

The correct answer and scoring-guide provenance stay in `_MS.txt`, alongside the official explanation image. This preserves the canonical metadata contract rather than adding SAT-only keys to every CAIE-style question record. A representative record from the actual output is in `SAT_OFFICIAL_METADATA_SAMPLE.json`.

## Build commands

First download/extract the official answer companions (source PDFs stay outside the output):

```bash
python tools/build_sat_answer_companions.py \
  --out /path/to/answer-companion-staging \
  --cache-dir /tmp/sat_official_compat \
  --tests 4-11
```

Then render and classify QP crops into the CAIE-style tree:

```bash
python tools/export_sat_caie_tree.py \
  --qp-dir /tmp/sat_official_compat \
  --companions /path/to/answer-companion-staging \
  --out /path/to/SAT_CAIE_Style_Output \
  --tests 4-11
```

The export contains 960 per-question folders. Original QP, scoring-guide, and answer-explanation PDFs are not copied into it or the clean Topical Generator distribution.

## Validation

- Tests 4–11: 120/120 questions per test; all four modules have their official coverage (RW M1 33, RW M2 33, Math M1 27, Math M2 27).
- Answer-key/explanation matching: no explicit conflicts. Per test, all 106 multiple-choice answers have an explanation choice matching the scoring guide; the remaining 14 are free response and are checked directly against the key.
- QP routing uses the existing runtime classifier: 878 questions have a SAT domain topic and 82 are routed to `review_required`. Test 8 has 120 topic hints; Test 10 has 21 review cases, so its calibrated behavior is not treated as independent validation.
- Full repository test suite: 157 passed before the layout correction; the new tree exporter also has focused save-band and canonical-metadata regressions.
