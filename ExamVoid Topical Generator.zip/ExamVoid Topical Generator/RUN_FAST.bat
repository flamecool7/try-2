@echo off
REM ===================================================================
REM  RUN_FAST.bat  --  double-click this. Nothing else to configure.
REM
REM  Put THIS FILE in the folder that contains run_guarded.py
REM  (the same folder that has core\, input\ and output\).
REM  It cd's to its own location, so the path does not matter.
REM
REM  What it does, in order:
REM    1. checks python is on PATH
REM    2. installs any missing Python dependencies (once; then instant)
REM    3. applies a one-time, idempotent audit fix
REM    4. runs the crop batch as wide as your RAM allows
REM
REM  You do not choose a worker count. The RAM guard picks it.
REM ===================================================================
cd /d "%~dp0"

echo ============================================================
echo   Topical Generator - fast parallel run
echo   folder: %CD%
echo ============================================================

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo   ERROR: python is not on your PATH.
  echo.
  echo   Install Python 3.9+ from python.org and on the first screen
  echo   tick "Add python.exe to PATH", then retry.
  echo.
  pause
  exit /b 1
)

if not exist run_guarded.py (
  echo.
  echo   ERROR: run_guarded.py is not in this folder.
  echo.
  echo   Move RUN_FAST.bat into the folder that contains
  echo   run_guarded.py, core\, input\ and output\.
  echo.
  pause
  exit /b 1
)

if not exist core\batch_runner.py (
  echo.
  echo   ERROR: core\batch_runner.py not found - wrong folder.
  echo.
  pause
  exit /b 1
)

REM ---------------------------------------------------------------
REM  1. Make sure input\ and output\ exist, so a fresh unzip works.
REM ---------------------------------------------------------------
if not exist input  mkdir input
if not exist output mkdir output

REM ---------------------------------------------------------------
REM  2. Install missing dependencies. Only runs pip at all when
REM     something is actually missing, so repeat launches are instant.
REM     The gold splitter (original_reference) needs PyMuPDF, numpy,
REM     opencv, imagehash, PyWavelets and scipy.
REM ---------------------------------------------------------------
python -c "import fitz, numpy, cv2, imagehash, pywt, scipy" >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Installing missing Python dependencies - this happens once.
  echo   (If it looks stuck it is downloading; a slow connection takes
  echo    a few minutes. Later runs skip this entirely.)
  echo.
  python -m pip install --quiet --disable-pip-version-check PyMuPDF numpy "opencv-python-headless" imagehash PyWavelets scipy
  if errorlevel 1 (
    echo.
    echo   WARNING: the automatic install did not finish.
    echo   Trying again with the full requirements file...
    echo.
    python -m pip install --quiet --disable-pip-version-check -r requirements.txt
  )
  echo.
  echo   Dependencies done.
  echo.
)

REM ---------------------------------------------------------------
REM  3. One-time, safe, idempotent. Fixes the final audit counting
REM     every paper as "review required" because of a nested
REM     .run_report path. Prints "already patched - skipping" on
REM     every later run, so it costs nothing.
REM ---------------------------------------------------------------
if exist patch_core.py (
  python patch_core.py
)

REM ---------------------------------------------------------------
REM  4. Go. --workers 14 is only a request: the RAM guard grants
REM     min(14, (MemAvailable - 400) / 1100) and never oversubscribes
REM     your cores. No prompt, nothing to type.
REM ---------------------------------------------------------------
echo.
echo   The first 1-2 minutes look silent: every PDF in input\ is
echo   being identified before anything is printed. "[alive]" lines
echo   below mean it IS working. A [OK] line appears as each
echo   paper finishes.
echo.

python start_fast.py --input input --output output --go --workers 14 --pause

echo.
echo ============================================================
echo   FINISHED
echo ============================================================
pause
