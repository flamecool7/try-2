@echo off
REM ===================================================================
REM  RUN_FAST.bat  --  double-click this. Nothing else to configure.
REM
REM  Put THIS FILE in the folder that contains run_guarded.py
REM  (the same folder that has core\, input\ and output\).
REM  It cd's to its own location, so the path does not matter.
REM
REM  Asks for 14 workers. The RAM guard may clamp that down to whatever
REM  your free memory actually supports -- that is deliberate and it
REM  will tell you loudly if it happens.
REM ===================================================================
cd /d "%~dp0"

echo ============================================================
echo   Topical Generator - fast parallel run
echo   folder: %CD%
echo ============================================================

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo   ERROR: python is not on your PATH.
  echo   Install Python and tick "Add to PATH", then retry.
  echo.
  pause
  exit /b 1
)

if not exist run_guarded.py (
  echo.
  echo   ERROR: run_guarded.py is not in this folder.
  echo.
  echo   Move RUN_FAST.bat into the folder that contains
  echo   run_guarded.py, core\, input\ and output\.
  echo.
  pause
  exit /b 1
)

if not exist core\batch_runner.py (
  echo.
  echo   ERROR: core\batch_runner.py not found - wrong folder.
  echo.
  pause
  exit /b 1
)

echo.
python start_fast.py --input input --output output --go --workers 14 --min-workers 4 --pause
echo.
echo ============================================================
echo   FINISHED
echo ============================================================
pause
