# IB DP subject validation — catalogue, syllabus version, and runtime samples

**Audit date:** 2026-10-10  
**Repository scope:** all 30 profile rows in `subjects_ib/DP/`  
**Decision:** version-aware classification and subject-isolated bundle routing are implemented for the 30 profiles; **official-PDF validation is still pending**. Do not promote full IB PDF-runtime support from this audit.

## Executive result

- **Catalogue identity:** all 30 repository profiles correspond to a DP subject in the IBO's 2026 *All DP subjects* catalogue. This verifies presence and broad level availability, not topic coverage.
- **Version reconciliation:** the 14 scheduled update-cycle rows plus two additional Classical Languages/Philosophy course transitions have **16 explicit version-route files**; legacy roots stay distinct where the guide changed. Anthropology, Music, Theatre and Film now carry reconciled current-course root maps. The production IB classifier/topic helper route by assessment year and fail closed to review outside declared cohort ranges.
- **Runtime sample audit:** **48 official-source prompt/task excerpts** were passed through actual `classify_text` with each record’s `source_year` for **25/30 profiles**. Result: **30 HINT, 18 REVIEW_REQUIRED, 0 execution errors**. The provisional manual topic ID matched top-1 in **22** cases; this is **not** an accuracy estimate.
- **Unexamined by prompt text:** Dance, ESS, Music, Theatre and Visual Arts. Their accessible current materials either do not provide a conventional public question sample in the brief, use practical/portfolio assessments, or need current-version source material. ESS is particularly important: the first-assessment-2026 course is current, but no current sample question was included.
- **Real-paper PDF validation:** one May 2025 Biology HL Paper 2 TZ1 QP/MS pair was retrieved from the authorized XtremePapers IB archive and processed together by `tools/run_universal_batch.py`. The subject/paper/session association matched exactly (`IB|IBBI/P2|May|2025`). The QP produced 10 top-level questions and 12 image crops; the MS produced 10 question-level crops. Every crop passed the 2280 px width / decoded 20 px top-band contract; both document contracts passed, with 10 packs and zero review items. This real run exposed an unsupported current Biology MS table layout (repeated question numbers, Section B numbers without periods, and `max` closure rows); the actual IB runtime parser and a regression test were updated. No examiner report was listed in that session directory, so the bundle explicitly leaves ER binding unauthorized and attaches none. This is QP/MS real-paper validation, not full QP/MS/ER or all-subject validation. Details and SHA-256 values are in `reports/ib_official_pdf_validation.json`; source PDFs and crops remain under `/tmp` and are not part of a distribution archive.

Reproduce the smoke audit with `python tools/audit_ib_official_samples.py`. Machine-readable cases and outputs are `reports/ib_official_sample_audit.json` and `.csv` (schema `/3`). They record the supplied `source_year`, selected profile version/path, expected topic, prediction and status.

## Official catalogue reconciliation

Source: IBO [2026 All DP subjects list](https://ibo.org/globalassets/new-structure/programmes/dp/pdfs/all-dp-subjects-list-en.pdf). All repository rows match an official-list identity (including naming variants such as `Digital Society`/`Digital Societies` and `Classical Languages (Latin)`/`Latin`). Literature and Performance and World Religions are SL-only in the current catalogue; History's HL offerings are regional courses represented by one combined repository profile.

| Repository profile | Official-list subject / group | Available levels | Catalogue check |
|---|---|---|---|
| Biology | Biology — Sciences | SL/HL | Listed |
| Business Management | Business Management — Individuals and societies | SL/HL | Listed |
| Chemistry | Chemistry — Sciences | SL/HL | Listed |
| Classical Languages (Latin) | Latin — Language acquisition | SL/HL | Listed |
| Computer Science | Computer Science — Sciences | SL/HL | Listed |
| Dance | Dance — Arts | SL/HL | Listed |
| Design Technology | Design Technology — Sciences | SL/HL | Listed |
| Digital Society | Digital Societies — Individuals and societies | SL/HL | Listed |
| Economics | Economics — Individuals and societies | SL/HL | Listed |
| Environmental Systems and Societies | Environmental Systems and Societies — interdisciplinary | SL/HL | Listed |
| Film | Film — Arts | SL/HL | Listed |
| Geography | Geography — Individuals and societies | SL/HL | Listed |
| Global Politics | Global Politics — Individuals and societies | SL/HL | Listed |
| History | History — Individuals and societies; regional HL courses | SL; regional HL | Listed; combined profile |
| Language A: Language and Literature | Language A: Language and Literature — Studies in language and literature | SL/HL | Listed |
| Language A: Literature | Language A: Literature — Studies in language and literature | SL/HL | Listed |
| Language B French | French B — Language acquisition | SL/HL | Listed |
| Language B Spanish | Spanish B — Language acquisition | SL/HL | Listed |
| Literature and Performance | Literature and Performance — Studies in language and literature | SL only | Listed |
| Mathematics: Analysis and Approaches | Mathematics: Analysis and Approaches — Mathematics | SL/HL | Listed |
| Mathematics: Applications and Interpretation | Mathematics: Applications and Interpretation — Mathematics | SL/HL | Listed |
| Music | Music — Arts | SL/HL | Listed |
| Philosophy | Philosophy — Individuals and societies | SL/HL | Listed |
| Physics | Physics — Sciences | SL/HL | Listed |
| Psychology | Psychology — Individuals and societies | SL/HL | Listed |
| Social and Cultural Anthropology | Social and Cultural Anthropology — Individuals and societies | SL/HL | Listed |
| Sports, Exercise and Health Science | Sports, Exercise and Health Science — Sciences | SL/HL | Listed |
| Theatre | Theatre — Arts | SL/HL | Listed |
| Visual Arts | Visual Arts — Arts | SL/HL | Listed |
| World Religions | World Religions — Individuals and societies | SL only | Listed; replacement begins 2029 |

This checks the 30 profiles present in this repository; it does not claim the repository covers all IB languages, sub-courses or every regional variant.

## Official course-version schedule and profile fit

The IBO [curriculum-updates index](https://www.ibo.org/university-admission/latest-curriculum-updates/) groups new courses by first assessment. It records 3 affected profiles in 2026, 4 in 2027, 1 in 2028 and 6 in 2029: **14 repository rows** across 13 streams. Two additional routes separate Classical Languages (first assessment 2024) and Philosophy (first assessment 2025) from their retained legacy roots, for **16 explicit version routes/files across 15 streams**. Four other reconciled profiles have current official topic maps in their roots. `adapters/ib/classification.py` selects the latest declared route whose first-assessment year is ≤ the paper year; missing routes and years outside declared cohort ranges fail closed to review. Legacy and revised profiles remain distinct where the course revision is tracked.

| Profile | Official current/new course version | Repository fit and topic reconciliation | Official-text runtime evidence |
|---|---|---|---|
| Biology (`IBBI`) | First assessment 2025 | Profile version matches the current specimen vintage. | 2 current specimens |
| Business Management (`IBBM`) | First assessment 2024 | Profile version matches the current brief; one prompt's narrow subtopic mapping is ambiguous. | 1 current brief sample |
| Chemistry (`IBCH`) | First assessment 2025 | Profile version matches the current specimen vintage. | 4 current specimens |
| Classical Languages—Latin (`IBCL`) | First assessment 2024 | Three-topic current profile maps meaning/form/language; text/author/audience; time/space/culture. Separate 2024 profile route; legacy root retained. | 2 current brief samples; 2 HINT / 2 provisional top-1 matches |
| Computer Science (`IBCS`) | New course first assessment 2027 | Existing profile resembles the old course. New course is organized around Theme A concepts of CS (fundamentals, networks, databases, machine learning) and Theme B computational thinking/problem-solving (programming, OOP, HL abstract data types). A distinct 2027 profile is now routed by assessment year; legacy root retained. | 2 old-course 2014 prompts only; not current validation |
| Dance (`IBDA`) | New course first assessment 2029 | Existing profile emphasizes techniques/performance, composition, world dance and critique. New course is organized as investigating, experimenting and presenting dance, plus an HL dance project; The distinct 2029 investigate/experiment/present profile is now routed by assessment year. | No question text tested; practical/creative assessment |
| Design Technology (`IBDT`) | New course first assessment 2027 | Existing topic names reflect the old 2016 syllabus. New course's framework is design theory, design in practice and design in context; user-centred design and redesign process have greater prominence. A distinct 2027 profile is now routed by assessment year; legacy root retained. | 1 old-course 2016 prompt only |
| Digital Society (`IBDS`) | First assessment 2024 | Profile version matches current official specimen vintage; some concept prompts have adjacent/multi-topic labels. | 4 current specimens |
| Economics (`IBEC`) | First assessment 2022 | Profile version matches the current brief. | 1 current brief sample |
| Environmental Systems and Societies (`IBES`) | New course first assessment 2026 | Current profile has six broad topics; current official brief has eight topics (foundation, ecology, biodiversity/conservation, water, land, atmosphere/climate, natural resources, human populations/urban systems) and three HL lenses (law, ecological economics, ethics). A distinct 2026 profile now maps all eight brief topics; legacy six-topic profile retained for earlier cohorts. | No public current sample question tested |
| Film (`IBFI`) | Current second-edition guide; first assessment 2023 | Four current task topics: reading film, contextualizing film, production roles, and HL collaborative production; official guide URL recorded in the profile. | 1 official assessment-task description; 1 HINT / provisional top-1 match; not specimen QP text |
| Geography (`IBGE`) | Official specimen vintage first examinations 2019 | Config says 2019. Runtime sample coverage is weak on short command-style items; confirm no later guide revision before calling current. | 4 specimens |
| Global Politics (`IBGP`) | New course first assessment 2026 | Existing profile's legacy buckets (power/relations, rights, development, peace/conflict, issues) are only a partial crosswalk. New course integrates a core with thematic studies in rights/justice, development/sustainability, peace/conflict, engagement project and an HL global-political-challenges extension. A distinct 2026 profile maps the core and three thematic studies; legacy profile retained for earlier cohorts. | 3 genuine current 2026 brief prompts; profile mismatch probe |
| History (`IBHI`) | New course first assessment 2028 | Existing profile says first assessment 2017 and has a long legacy topic list. The new course uses historical inquiry, concepts, paired case studies, global themes and regional in-depth topics. A distinct 2028 inquiry/case-study/global-theme/regional-depth profile is routed; 2017-era root retained. | 1 legacy 2017 prompt + 1 new 2028 prompt; both review |
| Language A: Language and Literature (`IBLL`) | First assessment 2021 course; current page reviewed | Profile's exploration-area taxonomy broadly aligns. The sample is a Paper 1/2-style common comparative prompt, not a fresh paper for every language. | 1 shared 2024 brief prompt |
| Language A: Literature (`IBLT`) | First assessment 2021 course; current page reviewed | Profile's exploration-area taxonomy broadly aligns. The shared prompt routed to a different profile topic than its provisional label; review its granularity. | 1 shared 2024 brief prompt |
| Language B French (`IBLBF`) | Enhanced course first assessment 2029 | Five prescribed themes are retained and the assessment model remains the same; profile's five theme labels are broadly compatible. A distinct 2029 profile retains the five prescribed themes, matching the official course update; the English brief question is not French-paper validation. | 1 common theme question in English |
| Language B Spanish (`IBLBS`) | Enhanced course first assessment 2029 | Distinct 2029 profile route mirrors the retained five themes; language-specific question material is not tested. | 1 common theme question in English |
| Literature and Performance (`IBLP`) | First assessment 2024 | Broad profile categories need finer mapping to the current integrated literature/performance work. | 2 current brief sample prompts |
| Mathematics: Analysis and Approaches (`IBMA`) | Refined course first assessment 2029 | Current profile/specimen vintage is 2021. The 2029 course removes financial applications and bivariate data at SL/HL, proof by counterexample and Euler's method at HL; 2021 root is retained and a separate 2029 A–E profile is routed; the 2021 specimen remains legacy-only. | 1 legacy 2021 specimen only |
| Mathematics: Applications and Interpretation (`IBAI`) | Refined course first assessment 2029 | Current profile/specimen vintage is 2021. The new brief removes/logically reworks content including logarithms and trapezoidal approximation (SL) and several HL items; a distinct 2029 A–E profile is routed from the official subject brief; the 2021 specimen remains legacy-only. | 1 legacy 2021 specimen only |
| Music (`IBMU`) | First assessment 2022 course; current page/brief reviewed | Current root profile maps exploring music in context, experimenting with music, presenting music, plus the HL contemporary music-maker project. Assessment is portfolio/performance based. | No question text tested |
| Philosophy (`IBPL`) | First assessment 2025 | Distinct 2025 profile route preserves the prior root and maps “Being human,” all seven optional themes, and the HL contemporary-issues extension. | 3 current brief samples; 3 HINT / 3 provisional top-1 matches |
| Physics (`IBPH`) | First assessment 2025 | Profile version matches current specimen vintage; two unit/topic errors warrant targeted review. | 4 current specimens |
| Psychology (`IBPS`) | New course first assessment 2027 | Config says first assessment 2019. New structure integrates six concepts, three approaches, four applied contexts, research methods, an IA research proposal and HL extensions. The two 2027 brief prompts test the revised course against the old profile; a distinct first-assessment-2027 profile is routed; the 2019 root remains for earlier cohorts. | 2 genuine 2027 brief prompts; not validation of old profile |
| Social and Cultural Anthropology (`IBSA`) | Current course/brief first assessment 2019 | Root profile maps the nine official areas of inquiry (belonging, classifying the world, communication/expression/technology, conflict, development, health/illness/healing, movement/time/space, production/exchange/consumption, the body). | 2 2019 brief samples; 2 HINT / 2 provisional top-1 matches |
| Sports, Exercise and Health Science (`IBSE`) | New course first assessment 2026 | Existing profile has five broad units; current course is built around exercise physiology/nutrition, biomechanics, sports psychology/motor learning, with removed/absorbed old options and a redesigned assessment. A separate first-assessment-2026 profile now uses the three official themes; the 2014/2018 profile is retained for legacy cohorts. | 1 old 2014 prompt only; not current validation |
| Theatre (`IBTH`) | First assessment 2024; current brief | Root profile maps staging play texts, exploring world theatre traditions, collaboratively creating original theatre, and the HL theatre-theory performance task. | No conventional question prompt tested |
| Visual Arts (`IBVA`) | New course first assessment 2027 | The 2027 course is non-examination based and reframes learning as art-making inquiry across create/connect/communicate, with portfolio, connection study or artist project and selected resolved works. The distinct first-assessment-2027 create/connect/communicate profile is routed. It is coursework-based and is not certified by ordinary QP prompts. | No question text; new course is non-exam based |
| World Religions (`IBWR`) | Replaced by Religion and Society, first assessment 2029 | Current profile is for the legacy SL World Religions course. The replacement is a substantial redesign: foundations of religious studies plus concepts (change, identity, interpretation, power), open-selected traditions and contextual inquiry; a distinct first-assessment-2029 Religion and Society profile is routed; the legacy World Religions profile remains separate. | 1 legacy 2013 prompt only |

### Version-route implementation

The 14 route files now exist at `subjects_ib/DP/<profile>/versions/<first-assessment-year>/config.json`. Runtime routes cover:

- **2026:** ESS, Global Politics, SEHS.
- **2027:** Computer Science, Design Technology, Psychology, Visual Arts.
- **2028:** History.
- **2029:** Dance, Language B French and Spanish, Mathematics AA and AI, and Religion and Society (under canonical repository code `IBWR`).

The new profiles are concise classifier crosswalks from official IBO briefs/update pages, not full guide transcriptions. This matters most where official guides are paywalled or course material is school-selected; these maps require official-paper testing before support promotion.

**Production changes:** `adapters/ib/classification.py` now resolves year-aware profiles and returns selected version/path; `adapters/ib/adapter.py` recognizes all 30 course titles; `tools/run_universal_batch.py` passes session year into IB classification and bundles uniquely keyed IB QP/MS/ER documents in one worker task. Subject/paper keys scope output directories and ER attachment. Unscoped or ambiguous ERs are kept separate and marked for review, never broadcast by question number.

Official update index: [DP curriculum updates](https://www.ibo.org/university-admission/latest-curriculum-updates/). Current guides/updates used include [ESS](https://www.ibo.org/university-admission/latest-curriculum-updates/environmental-systems-and-societies-updates/), [Global Politics](https://www.ibo.org/university-admission/latest-curriculum-updates/global-politics-updates/), [SEHS](https://www.ibo.org/university-admission/latest-curriculum-updates/sports-exercise-and-health-science-updates/), [Psychology](https://www.ibo.org/university-admission/latest-curriculum-updates/psychology-updates/), [Computer Science](https://www.ibo.org/university-admission/latest-curriculum-updates/computer-science-updates/), [Design Technology](https://www.ibo.org/university-admission/latest-curriculum-updates/design-technology-updates/), [Visual Arts](https://www.ibo.org/university-admission/latest-curriculum-updates/visual-arts-updates/), [History](https://www.ibo.org/university-admission/latest-curriculum-updates/history-updates/), [Dance](https://www.ibo.org/university-admission/latest-curriculum-updates/dance-updates/), [Language B](https://www.ibo.org/university-admission/latest-curriculum-updates/language-b-updates/), [Mathematics AA](https://www.ibo.org/university-admission/latest-curriculum-updates/dp-mathematics-analysis-and-approaches-updates/), [Mathematics AI](https://www.ibo.org/university-admission/latest-curriculum-updates/dp-mathematics-applications-and-interpretation-updates/), and [Religion and Society](https://www.ibo.org/university-admission/latest-curriculum-updates/dp-religion-and-society-update/).

## Official-source runtime sample audit

This is a source-text smoke test of the actual runtime—not a corpus benchmark. The case file contains short official sample questions where available, plus explicitly marked course-assessment-task descriptions/theme prompts where the subject does not use a conventional question paper. Source and profile years differ; legacy cases are retained as legacy diagnostics but do not validate a revised course.

| Subject | Cases | HINT | REVIEW_REQUIRED | Exact provisional topic-ID matches |
|---|---:|---:|---:|---:|
| Physics | 4 | 4 | 0 | 2 |
| Digital Society | 4 | 3 | 1 | 0 |
| Geography | 4 | 1 | 3 | 0 |
| History | 2 | 1 | 1 | 1 |
| Computer Science | 2 | 0 | 2 | 0 |
| Psychology | 2 | 2 | 0 | 2 |
| World Religions | 1 | 0 | 1 | 0 |
| Biology | 2 | 2 | 0 | 2 |
| Chemistry | 4 | 3 | 1 | 3 |
| Business management | 1 | 1 | 0 | 0 |
| Economics | 1 | 1 | 0 | 1 |
| Classical Languages (Latin) | 2 | 2 | 0 | 2 |
| Sports, exercise and health science | 1 | 0 | 1 | 0 |
| Philosophy | 3 | 3 | 0 | 3 |
| Literature and Performance | 2 | 0 | 2 | 0 |
| Global Politics | 3 | 3 | 0 | 3 |
| Mathematics: Analysis and Approaches | 1 | 0 | 1 | 0 |
| Mathematics: Applications and Interpretation | 1 | 0 | 1 | 0 |
| Design Technology | 1 | 0 | 1 | 0 |
| Language B French | 1 | 0 | 1 | 0 |
| Language B Spanish | 1 | 0 | 1 | 0 |
| Social and Cultural Anthropology | 2 | 2 | 0 | 2 |
| Language A: Language and Literature | 1 | 0 | 1 | 0 |
| Language A: Literature | 1 | 1 | 0 | 0 |
| Film | 1 | 1 | 0 | 1 |
| **Total** | **48** | **30** | **18** | **22** |
Top-1 exact matches are based on hand-written single-topic labels, some necessarily provisional for multi-topic questions, legacy taxonomy, short excerpts and crosswalk prompts. A review may be the safe result where the profile or evidence is inadequate. Conversely, a HINT is not proof that a topic is correct. Do not use the provisional match ratio as an accuracy rate.

The 5 profiles without prompt text are `IBDA`, `IBES`, `IBMU`, `IBTH`, `IBVA`. The current materials for Dance, Music, Theatre and Visual Arts are substantially practical/coursework/portfolio based; ESS's accessible current brief did not furnish a sample question. This means appropriate validation must include the relevant structured artifacts or protected/current QP material, not synthesize exam questions and call them official.

## What remains unvalidated

- One real Biology HL Paper 2 QP/MS pair from May 2025 TZ1 has now passed the production PDF runner, including exact subject-scoped association, 10 QP question segments, 10 MS question segments, crop geometry, and pack assembly. This is the only real IB bundle processed in this run. The XtremePapers listing did not contain a matching ER; no ER from another paper or subject was substituted, and the output binding remains explicitly unauthorized. See `reports/ib_official_pdf_validation.json`.
- Synthetic PDF fixtures exercise QP, MS, and ER worker bundling and verify a uniquely keyed Biology ER is attached only to the matching Biology QP; a new copy-time identity guard rejects stale, changed, and wrong-subject artifacts. These fixtures remain implementation tests, not official-paper bundle validation.
- **Partial real-paper validation:** the Biology QP yields 10 top-level questions / 12 crops and its paired MS yields 10 question-level crops; all 22 image outputs satisfy the 2280 px / 20 px top-band contract. This is one paper and no independent visual review was performed. ER segmentation remains unvalidated on a real IB document because the matching report was not listed. Preserve the invariant: **never attach an ER to a different subject or bundle**.
- No independent reviewers adjudicated the expected topic IDs. Current labels are audit hypotheses, not gold labels.
- No broad independent holdout or calibration set exists; 48 prompts across 25 profiles are still a diagnostic sample.
- The 554 profile-keyword cases remain a separate root-profile self-consistency test only; they are not external accuracy evidence for revised routes.

Full project suite: **162 passed, deprecation warnings only** after the IB cover-page/title parsing, real-paper question-marker/reference-page fixes, and the new table-style IB markscheme segmentation regression. The May 2025 Biology QP/MS run passed but had no matching ER and no independent crop/topic adjudication. Catalogue checking is separate from classifier validation. Keep `PROFILE_UNVALIDATED` rows unpromoted until current-version, subject-isolated bundles (including ER where available) have been processed and independently reviewed; this one QP/MS paper does not establish all-subject support.
