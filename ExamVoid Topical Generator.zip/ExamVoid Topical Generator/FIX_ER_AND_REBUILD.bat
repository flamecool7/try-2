@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  ExamVoid - rebuild bundles with ER isolation
echo ============================================================
echo.
echo Before continuing, make a copy of the existing output folder.
echo This rebuilds all bundles so old misfiled ER crops are replaced.
echo.

if not exist "run_pipeline.py" (
    echo ERROR: run_pipeline.py was not found.
    echo Put this .bat file in the ExamVoid Topical Generator project folder.
    pause
    exit /b 1
)

if not exist "input" mkdir "input"
if not exist "output" mkdir "output"

set "PY=python"
where py >nul 2>nul
if not errorlevel 1 set "PY=py"

"%PY%" -c "import fitz, numpy, cv2, imagehash, pywt, scipy" >nul 2>nul
if errorlevel 1 (
    echo Installing required Python packages...
    "%PY%" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo ERROR: dependency installation failed.
        pause
        exit /b 1
    )
)

echo.
echo Starting full rebuild with --force-all; requesting 14 workers.
echo The RAM guard may lower the actual worker count for safety.
echo.
"%PY%" run_pipeline.py --input "%~dp0input" --output "%~dp0output" --force-all --workers 14
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo Rebuild finished successfully.
) else (
    echo Rebuild exited with code %RC%. Check the output above for details.
)
pause
exit /b %RC%
