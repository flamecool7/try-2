FAST PARALLEL RUN -- READ THIS FIRST
====================================

WHAT THIS IS
  A drop-in launcher for the Topical Generator you already have.
  It does NOT contain the generator itself -- it cannot, because the
  gold-standard cropper (original_reference/cambridge_qb) is not
  present in the copy this pack was built from. Zipping that copy
  would ship you a cropper that fails at stage S2.

  So: use the TopicalGenerator_CLI_Updated folder you already have,
  and drop these files INTO it.

HOW TO INSTALL (10 seconds)
  1. Unzip this pack anywhere.
  2. Copy RUN_FAST.bat into the folder that contains run_guarded.py
     (the one with core\, input\ and output\ inside it).
  3. Copy the four .py files into that same folder.

HOW TO RUN
  Double-click RUN_FAST.bat.

  It will:
    - print how much work is already done
    - launch the RAM-guarded parallel runner at 14 workers
    - print [OK] <paper>: N questions as each paper finishes
    - wait for you to press Enter when done, so you can read it

WHAT IT CHANGES
  Nothing about classification. It calls the SAME function
  (run_guarded.run_paper_stages) with the SAME CroppingEngine
  settings. It only runs 14 papers at once instead of 1.

THE ONE THING TO KNOW
  The parallel runner keeps its own state file (pipeline.sqlite),
  separate from run_guarded.py's .pipeline_state.json. So it does
  NOT resume work run_guarded.py already finished -- it starts
  fresh. At 14 workers a full 2000-paper redo is ~2.8 h, so this
  is usually fine. If the progress line says you are past ~90%,
  stop and ask before letting it redo everything.

IF SOMETHING GOES WRONG
  - "RAM warning: 14 workers needs ~21.0GB, system has 16.0GB"
    -> advisory only, not a gate. Ignore it and let it run.
  - A paper fails -> its log is in output\.staging\<paper>\worker_log.txt
  - Nothing seems to happen -> it is working; each worker's own
    output is redirected, but the parent still prints [OK] lines.
