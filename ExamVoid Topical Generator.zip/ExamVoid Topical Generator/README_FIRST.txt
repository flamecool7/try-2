EXAMVOID TOPICAL GENERATOR — RUN GUIDE

WINDOWS
  1. Install Python 3.10+ and enable “Add Python to PATH”.
  2. Put each board's PDFs in its matching folder:
       input\CAIE\       Cambridge International
       input\AQA\        AQA
       input\EDEXCEL\    Pearson Edexcel
       input\IB\         International Baccalaureate
       input\SAT\        SAT
     Keep a paper's question paper (QP), mark scheme (MS), insert, and
     examiner report (ER) together in that board's folder.
  3. Double-click run.bat.

BOARD PIPELINES
  Option 3 runs every populated board folder, separately:
    input\CAIE\       -> Cambridge / CAIE pipeline
    input\AQA\        -> Universal AQA adapter
    input\EDEXCEL\    -> Universal Edexcel adapter
    input\IB\         -> Universal IB adapter
    input\SAT\        -> Universal SAT adapter
  Options 12–16 run only CAIE, AQA, EDEXCEL, IB, or SAT respectively.
  Option 7 clears output and rebuilds all populated board folders.

The advanced control menu (run.bat option 11) also has individual board
choices [1]–[4] for CAIE and [15]–[18] for AQA, EDEXCEL, IB, and SAT;
[19] runs all populated board folders separately.
The pipelines share the output location, but never combine papers from
multiple board input folders in a single run.

MAC / LINUX
  Install dependencies with: python3 -m pip install -r requirements.txt
  Run the interactive control menu with: python3 run_pipeline.py --menu
  Or run an individual board or every populated board folder:
    python3 run_board_pipelines.py --input input --output output --board CAIE
    python3 run_board_pipelines.py --input input --output output --board AQA
    python3 run_board_pipelines.py --input input --output output --board ALL

The local browser app is available from run.bat option 1 on Windows or with
python3 server.py. Generated packs, crops, and reports are written to output\.
The clean runtime package intentionally contains no source exam PDFs or output
artifacts; add authorized PDFs to the matching input subfolder before running.
