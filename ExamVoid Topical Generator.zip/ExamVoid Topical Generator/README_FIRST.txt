==============================================================
  TOPICAL GENERATOR - TURNKEY
==============================================================

This is the complete generator, already set up to run fast.
There is nothing to configure.

HOW TO USE IT
  1. Unzip this folder anywhere.
  2. Put your PDFs in the  input\  folder.
  3. Double-click  RUN_FAST.bat     (Windows)
     or run        sh run_fast.sh    (Mac / Linux)

That is the whole thing.

WHAT THE LAUNCHER DOES FOR YOU
  - Creates input\ and output\ if they are missing.
  - Installs any missing Python dependencies on first run. After that
    it checks and skips, so later launches start instantly.
  - Applies a one-time, idempotent audit fix. It prints
    "already patched - skipping" on every run after the first.
  - Picks the worker count itself from your free RAM. You never choose.
  - Prints "[alive]" lines so you can tell it is working.

WHAT IT DOES NOT DO
  - It does not change classification, DPI, crop size, WebP quality,
    or the question-number detection rules. Those are untouched.
  - It does not delete anything from your input folder.
  - It never asks you to type anything.

THE FIRST 1-2 MINUTES LOOK SILENT
  Every PDF in input\ is identified before anything is printed. On a
  2239-file folder that is 30-95 seconds with no output at all. This
  is normal. The "[alive]" lines appear every 15 seconds, and a
  "[OK] <paper>" line appears as each paper finishes.

ABOUT THE WORKER COUNT
  The launcher asks for 14 and the RAM guard grants
      min(14, (MemAvailable - 400) / 1100)
  capped at your core count. On a fresh-booted 16 GB box that is
  13-14 workers. If your RAM is busy it grants fewer and says so.
  It never blocks -- it warns and runs, because a prompt that waits
  for input looks exactly like a hang.

  You may also see "RAM warning: 14 workers needs ~21.0GB". That is
  advisory only, not a gate. Ignore it.

WHY IT IS FASTER
  The original runner processes one paper at a time: ~358 papers at
  ~70 s each is about 7 hours. This runs them in parallel with an
  isolated staging directory and state file per worker, so accuracy
  is identical. At 13-14 workers the same work is well under an hour.

  The ETA you see is measured, not guessed. Each run records how long
  it actually took per paper into  output\.fastpack_rate.json  and uses
  that number next time. A slow PC automatically gets a slow ETA.

WHICH LAUNCHER TO USE
  RUN_FAST.bat   the fastest path. 14 workers requested, RAM-guarded,
                 with an [alive] heartbeat and a measured ETA. Use this
                 for a big CAIE batch.

  run.bat        your original menu launcher. Option 3 "Build topic packs"
                 now runs at 8 workers and auto-routes: CAIE papers go to
                 run_pipeline.py --workers 8, everything else (AQA, Edexcel,
                 IB, SAT) goes to run_universal_batch.py --jobs 8.
                 Both are clamped by free RAM.

  Why routing is needed: the two build engines do not overlap. The
  universal router deliberately refuses CAIE papers ("the Cambridge
  pipeline handles this paper ... the universal router is non-CAIE by
  design"), and run_guarded.py --workers N records the count but stays
  sequential by design. route_build.py picks the right one for you.

SITE-DOWNLOADED SPECIMEN PAPERS (fixed)
  Files named 662622-2025-specimen-paper-1.pdf or
  671804-2025-specimen-paper-1-mark-scheme.pdf used to be dropped with
  "Could not identify" or "no approved subject config for 2025".

  Cause: the leading 5-7 digits are the download site's file id, not a
  syllabus code, so the fallback code regex skipped them and matched the
  YEAR instead - identifying the paper as "syllabus 2025".

  Fix: a pattern for that shape, plus the syllabus code is read from the
  document cover, which carries the canonical "0620/02" stamp. If the cover
  cannot supply a code the file is REFUSED, never guessed.

  Still not handled, by design: Transcript / Teachers Notes / Role Play
  Cards files. Those are language-subject support material, not question
  papers. Say the word if you want them too.

  Run  python audit_input.py  to see exactly which files will be dropped
  and why, before you commit to a long run.

SPECIMEN PAPERS GET THEIR OWN FOLDER
  Specimen papers now sit inside their topic, in a specimen_paper folder:
    <Level>/<Subject>/paper-N/<Topic>/specimen_paper/<QID>/
  Normal past papers are unchanged: <Level>/<Subject>/paper-N/<Topic>/<QID>/

IF YOU WANT TO CHECK WITHOUT RUNNING
  Double-click  CHECK_ONLY.bat   -- shows progress and the worker
  count, and starts nothing.

OTHER FILES (optional, for reference)
  start_fast.py      the launcher logic
  run_parallel.py    the parallel runner
  fastcheck.py       progress reader used by CHECK_ONLY.bat
  check_progress.py  hand-over command for part-done runs
  memcheck.py        cross-platform RAM diagnostic
  patch_core.py      the one-time audit fix (safe to run any time)
  run_fast.sh        Mac/Linux launcher
