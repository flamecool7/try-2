"""Pearson Edexcel adapter.

Handles the real 9FM0/3C format measured in docs/research. The adapter excludes
physical gutter boxes before handing rectangles to the shared gold geometry
bridge, so margin ink cannot become the top-band anchor.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from adapters.base import BoardAdapter, DocumentContext, Evidence
from adapters.common_text import first_line_y, full_page_clip, line_matches, page_size, page_texts
from adapters.layout_profiles import LayoutArchetype, crop_plan

# The paper half allows 1-2 digits (not just 1): confirmed 2026-10 on a real
# 9MA0/01 Pure Mathematics cover -- the old [0-9][A-Z]{0,2} required a \b right
# after the FIRST digit of "01", which doesn't exist between two digits, so the
# whole regex silently failed on every zero-padded two-digit Edexcel paper
# number. identify_subject/identify_component both depend on this pattern, so
# syllabus_code (and therefore the subject-aware half of association_key) came
# back empty for any such paper even though identify_document still resolved a
# component -- via the separate, more permissive legacy-heuristic regex -- which
# masked the gap until syllabus_code was checked directly.
_COMPONENT = re.compile(r"\b([0-9][A-Z]{2,3}[0-9])\s*/\s*([0-9]{1,2}[A-Z]{0,2})\b")
# A mark scheme's own cover never prints the QP's compact "1MA1/1H" slash code --
# confirmed 2026-10 on real Edexcel GCSE 1MA1/1H and A-level 9MA0/01 mark schemes,
# both of which instead print "In Mathematics (1MA1)" and "Paper 1H"/"Paper 01" as
# separate lines. Without this, identify_component found nothing for any MS and
# every mark scheme in the corpus associated as board/UNKNOWN/season/year.
_MS_QUALIFICATION = re.compile(r"\(([0-9][A-Z]{2,3}[0-9])\)")
# Paper numbers can be zero-padded two digits ("Paper 01" on a 9MA0 mark scheme) as
# well as a single digit plus tier letter ("Paper 1H"); [0-9]{1,2} covers both
# instead of just the latter.
_MS_PAPER = re.compile(r"\bPaper\s+([0-9]{1,2}[A-Z]{0,2})\b")
_PAGE_REF = re.compile(r"\*[A-Z]\d{5}A\d{2,3}\d{2}\*")
# Matches a question's own opening line in EITHER real format this adapter has to
# support: "1.\tFind" (period-numbered -- the 9FM0/3C paper this file was
# originally written against) and "1 Work out" (bare-numbered -- confirmed
# 2026-10 on a real Edexcel GCSE 1MA1/1H paper, where EVERY question uses this
# form and the old period-only regex matched nothing on the whole document).
# The lookahead requires a capital letter or "(" right after the number so a
# stray numeric fragment ("2 2", a fraction numerator split across PDF text
# runs) can't qualify.
_Q_START = re.compile(r"^\s*(\d{1,2})\.?\s+(?=[A-Z(])")
# Edexcel's own universal convention: every question, in both numbering formats
# above, ends with exactly one "(Total for Question N is M marks)" line that
# never changes shape between specs. This is the authoritative anchor the start
# regex alone could not be (found 2026-10, same GCSE paper): it lets a real
# per-page question count be cross-checked, and it lets a question whose own
# opening line cannot be found still be bounded correctly instead of silently
# merged into its neighbour.
_Q_END = re.compile(r"Total\s+for\s+Question\s+(\d{1,2})\s+is", re.I)
_CONT = re.compile(r"Question\s+(\d{1,2})\s+continued", re.I)


class Adapter(BoardAdapter):
    BOARD_ID = "EDEXCEL"
    BOARD_NAMES = ["Pearson Edexcel", "Edexcel", "Pearson"]
    CONFIG_FILE = "config/boards/edexcel.yaml"

    def normalize_name(self, raw: str) -> str:
        return re.sub(r"[^A-Za-z0-9]+", "_", str(raw)).strip("_")

    def _hay(self, ctx: DocumentContext) -> str:
        return f"{ctx.filename}\n{ctx.first_page_text}\n{ctx.full_text}".lower()

    def identify_document(self, ctx: DocumentContext) -> List[Evidence]:
        hay = self._hay(ctx)
        out: List[Evidence] = []
        if "pearson edexcel" in hay or "edexcel" in hay:
            out.append(Evidence("board_signature", "board", self.BOARD_ID, 1.0, "Pearson/Edexcel text", "document"))
        if _PAGE_REF.search(ctx.full_text or ctx.first_page_text or ""):
            out.append(Evidence("header_footer", "board", self.BOARD_ID, 0.85, "Edexcel page-reference code, not CAIE barcode", "page furniture"))
        return out

    def identify_subject(self, ctx: DocumentContext) -> List[Evidence]:
        text = ctx.first_page_text or ""
        out: List[Evidence] = []
        m = _COMPONENT.search(text)
        if m:
            out.append(Evidence("qualification_code", "syllabus_code", m.group(1), 0.95, f"component {m.group(0)!r}", "page 1"))
            out.append(Evidence("component_code", "component", f"{m.group(1)}/{m.group(2)}", 0.95, f"component {m.group(0)!r}", "page 1"))
        else:
            qm = _MS_QUALIFICATION.search(text)
            if qm:
                out.append(Evidence("qualification_code", "syllabus_code", qm.group(1), 0.85,
                                    f"qualification code {qm.group(0)!r} (mark scheme cover form)", "page 1"))
        if "further mathematics" in text.lower():
            out.append(Evidence("first_page_text", "subject", "Further Mathematics", 0.9, "cover subject title", "page 1"))
        return out

    def identify_qualification(self, ctx: DocumentContext) -> List[Evidence]:
        low = (ctx.first_page_text or "").lower()
        if "level 3 gce" in low or "advanced" in low:
            return [Evidence("first_page_text", "qualification", "A-LEVEL", 0.9, "Level 3 GCE Advanced on cover", "page 1")]
        return []

    def identify_session(self, ctx: DocumentContext) -> List[Evidence]:
        """Read the series and year the cover actually prints.

        The series token is matched against this adapter's OWN config session
        table (``sessions[].aliases``), so adding a series is a config change,
        not a code change - the same pattern as the AQA adapter.

        The emitted value is the session NAME ("June"), not the calendar season
        word ("Summer"). The universal identity layer, the association keys and
        the batch directory contract all speak month names, so hardcoding
        "Summer" made Edexcel disagree with every other board - found 2026-09-21
        when the adapter-first identify_document started consuming this value;
        it had been masked by the legacy fallback.
        """
        text = ctx.first_page_text or ""
        low = text.lower()
        out: List[Evidence] = []
        m = re.search(r"\b(19\d{2}|20\d{2}|[3-9]\d{2})\b", text)
        if m:
            out.append(Evidence("first_page_text", "year", int(m.group(1)), 0.9, "year on cover", "page 1"))
        if "specimen" in low:
            out.append(Evidence("first_page_text", "season", "Specimen", 1.0, "Specimen material", "page 1"))
        for spec in self.sessions():
            found = None
            for alias in [spec.name] + list(getattr(spec, "aliases", None) or []):
                token = str(alias or "").strip().lower()
                # Single letters ("s", "j") are filename hints, not cover text.
                if len(token) >= 3 and re.search(r"\b" + re.escape(token), low):
                    found = token
                    break
            if found:
                out.append(Evidence("first_page_text", "season", spec.name, 0.9,
                                    f"series token {found!r} on cover", "page 1"))
                break
        if not found:
            # A GCSE question paper's own cover prints the literal sitting date
            # ("Friday 19 May 2023"), never the series name -- its own mark scheme
            # for the identical paper is headed "Summer 2023" instead, which DOES
            # match the "June" session's "summer" alias above. Confirmed 2026-10 on
            # a real Edexcel GCSE 1MA1/1H QP vs its own mark scheme: the QP/MS pair
            # used to resolve to two different seasons (UNKNOWN vs June) and could
            # not associate. Same defect, same fix shape as the IB November/October
            # one found earlier this session: fall back to the sitting date's
            # calendar month and look it up against each session's own "months"
            # list (config/boards/edexcel.yaml) rather than a literal name match.
            dm = re.search(r"\b(January|February|March|April|May|June|July|August|"
                           r"September|October|November|December)\s+(20\d{2}|19\d{2})\b", text)
            if dm:
                month_num = (["january", "february", "march", "april", "may", "june", "july",
                             "august", "september", "october", "november", "december"]
                            .index(dm.group(1).lower()) + 1)
                for spec in self.sessions():
                    if month_num in (getattr(spec, "months", None) or []):
                        out.append(Evidence("first_page_text", "season", spec.name, 0.85,
                                            f"sitting date {dm.group(0)!r} falls in the "
                                            f"{spec.name} session's configured months", "page 1"))
                        break
        return out

    def identify_component(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        text = ctx.first_page_text or ""
        m = _COMPONENT.search(text)
        if m:
            # "component" is the FULL code ("9FM0/3C"), not the bare paper letter
            # ("3C"): the paper number alone does not discriminate, because two
            # different Edexcel syllabuses in one session can both have a "3C".
            # This matches the AQA adapter (full code as component, board-native
            # number as paper_number) and the directory naming the batch runner
            # already derives. Fixed 2026-09-21; the adapter-first association
            # change had made the bare paper letter win for the first time.
            out.append(Evidence("component_code", "component", f"{m.group(1)}/{m.group(2)}", 1.0, f"paper reference {m.group(0)!r}", "page 1"))
            out.append(Evidence("component_code", "paper_number", m.group(2)[:1], 0.85, "first digit of Edexcel paper component", "page 1"))
        else:
            # Mark scheme cover form: "In Mathematics (1MA1)" + "Paper 1H" on
            # separate lines, never the QP's compact "1MA1/1H". Confirmed 2026-10
            # on real 1MA1/1H and 9MA0/01 mark schemes -- without this a QP and its
            # own mark scheme resolved to different components and could never
            # associate (one a real code, the other UNKNOWN).
            qm = _MS_QUALIFICATION.search(text)
            pm = _MS_PAPER.search(text)
            if qm and pm:
                out.append(Evidence("component_code", "component", f"{qm.group(1)}/{pm.group(1)}", 0.85,
                                    f"qualification {qm.group(0)!r} + {pm.group(0)!r} (mark scheme cover form)", "page 1"))
                out.append(Evidence("component_code", "paper_number", pm.group(1)[:1], 0.7,
                                    "first digit of Edexcel paper component (mark scheme cover form)", "page 1"))
        return out

    def identify_document_type(self, ctx: DocumentContext) -> List[Evidence]:
        low = (ctx.first_page_text or "").lower()
        if "mark scheme" in low:
            return [Evidence("header_footer", "document_type", "MS", 0.95, "mark scheme heading", "page 1")]
        if "examiner report" in low or "resultsplus" in low:
            return [Evidence("header_footer", "document_type", "ER", 0.9, "examiner report/resultsplus", "page 1")]
        if "answer all questions" in (ctx.full_text or "").lower() and "paper reference" in low:
            return [Evidence("header_footer", "document_type", "QP", 0.9, "question-paper cover + instructions", "page 1")]
        return []

    def identify_question_structure(self, ctx: DocumentContext) -> List[Evidence]:
        segs = self.segment(ctx)
        return [Evidence("document_structure", "question_count", len(segs), 0.95, "Edexcel numbered starts with continuations", "document")] if segs else []

    def identify_mark_scheme(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "MS"]

    def identify_examiner_report(self, ctx: DocumentContext) -> List[Evidence]:
        return [e for e in self.identify_document_type(ctx) if e.value == "ER"]

    def segments_document(self) -> bool:
        return True

    def _body_rect(self, ctx: DocumentContext, page_index: int, *, start: bool,
                    start_y: Optional[float] = None,
                    bottom_override: Optional[float] = None) -> tuple[float, float, float, float]:
        w, h = page_size(ctx, page_index)
        # Explicitly exclude the physical "DO NOT WRITE IN THIS AREA" gutters.
        # Real P61181A pages are 651.97 x 898.58 and carry full-height gutter
        # rasters at x 0.0-54.7 and 596.9-651.6 (measured 2026-09-21, 100 dpi
        # ink runs); the mathematical body is x 62.6-589.7 and question numbers
        # start at x 71. The old left=45.0 sat *inside* the left hatch, so ~10pt
        # of cross-hatch was cropped into the left edge of every page, and the
        # old right=55.0 (edge 596.97) grazed the right gutter. 56.0/57.0 clear
        # both: edge 594.97, 5.3pt right of the widest body ink, 1.9pt left of
        # the gutter. left=59.0 additionally clears the gutter *raster*'s own
        # 34.0-57.8pt placement rect, so the crop-edge audit reports no cut
        # objects there at all.
        #
        # The box width is bounded from below by the WEBP 16383px height limit,
        # not by taste: Q7 is a five-page question and segment pages render at
        # 2280 / box_width px per pt, so a narrower box pushes the stacked image
        # past the limit. At 535.97pt of body Q7 assembles to 16143px (< 16383);
        # at the old 552.0pt it was ~16089px - already tight. Verified by
        # re-cropping the real paper: Q7 came out 2280x16023px.
        left = 59.0
        right = 57.0
        y = 72.0
        if start:
            y0 = start_y if start_y is not None else first_line_y(ctx, page_index, r"^\s*\d{1,2}\.?\s+(?=[A-Z(])")
            if y0 is not None:
                y = max(55.0, y0 - 10.0)
        else:
            y0 = first_line_y(ctx, page_index, r"Question\s+\d+\s+continued")
            if y0 is not None:
                y = max(55.0, y0 - 8.0)
        # Bottom: body ink ends at 823.2 on every page while the barcode strip
        # ("*P61181A0228*", the label row and "Turn over") runs 829.4-863.0, so
        # the old h-52.0 = 846.6 sliced the barcode in half - the IB QP defect
        # again. h-72.5 = 826.08 sits in the empty window: 2.9pt below content
        # and 0.3pt above the footer page number glyph (826.4-838.8) which the
        # h-72.0 edge shaved by 0.2pt (A4f, found by a solid-object cross test),
        # 2.8pt above the barcode.
        bottom = h - 72.5
        if bottom_override is not None:
            # A real GCSE paper (1MA1/1H, confirmed 2026-10) routinely fits 2-3 short
            # questions on one page -- the next question's own opening line can fall
            # on this SAME page, well above where h-72.5 would otherwise run this
            # rect to. Without this clip, the earlier question's crop silently
            # swallowed the next question's text too (both questions then show the
            # next question's content; the next question's own crop still looked
            # right, so this was easy to miss without a per-page question count).
            # bottom_override is the next question's OWN raw opening-line y (not yet
            # offset) -- apply the identical max(55, y0-10) the "start" branch above
            # uses for that same line, so this rect's bottom lines up with (never
            # overlaps) the next rect's top, then back off one more point for safety.
            next_top = max(55.0, bottom_override - 10.0)
            bottom = min(bottom, max(y + 1.0, next_top - 1.0))
        return (left, y, w - right, bottom)

    def segment(self, ctx: DocumentContext) -> List[Dict[str, Any]]:
        texts = page_texts(ctx)
        n_pages = len(texts)

        # Ends first: "(Total for Question N is M marks)" is Edexcel's own universal
        # convention and does not change shape between the period-numbered and
        # bare-numbered start formats, so it anchors segmentation even when the
        # start regex can't find (or can't trust) a particular opening line.
        ends: Dict[int, tuple[int, float]] = {}
        for i in range(n_pages):
            for m, y in line_matches(ctx, i, _Q_END.pattern):
                if y is not None:
                    ends[int(m.group(1))] = (i, y)
        if not ends:
            # No end markers at all -- this isn't an Edexcel-numbered QP this
            # adapter knows how to bound (e.g. a mark scheme or examiner report
            # routed here by mistake). Refuse rather than guess at boundaries.
            return []

        ordered = sorted(ends)
        starts: Dict[int, tuple[int, float]] = {}
        cursor_page, cursor_y = 0, -1.0
        for qn in ordered:
            end_page, end_y = ends[qn]
            found = None
            for p in range(max(cursor_page, 1), end_page + 1):
                text = texts[p]
                # Covers and answer spaces can contain stray numbers; require the
                # real answer-space furniture or instructions on the page too.
                if not ("DO NOT WRITE IN THIS AREA" in text or "Answer ALL questions" in text):
                    continue
                for m, y in line_matches(ctx, p, _Q_START.pattern):
                    if y is None or int(m.group(1)) != qn:
                        continue
                    if p == cursor_page and y <= cursor_y:
                        continue
                    if p == end_page and y > end_y:
                        continue
                    found = (p, y)
                    break
                if found is not None:
                    break
            if found is None:
                # Could not confirm this question's own opening line (unexpected
                # formatting on this particular page) -- still never drop the
                # question: start right where the previous one left off instead
                # of losing the content entirely.
                found = (cursor_page, cursor_y) if cursor_y >= 0 else (max(cursor_page, 1), 55.0)
            starts[qn] = found
            cursor_page, cursor_y = end_page, end_y

        component_ev = self.identify_component(ctx)
        component = next((e.value for e in component_ev if e.field == "component"), None) or "UNKNOWN"
        component_safe = re.sub(r"[^A-Za-z0-9]+", "_", str(component)).strip("_") or "UNKNOWN"

        segments: List[Dict[str, Any]] = []
        for idx, qn in enumerate(ordered):
            start_page, start_y = starts[qn]
            end_page, end_y = ends[qn]
            next_same_page_y = None
            if idx + 1 < len(ordered):
                next_page, next_y = starts[ordered[idx + 1]]
                if next_page == end_page:
                    next_same_page_y = next_y
            pages = []
            for p in range(start_page, end_page + 1):
                is_start_page = (p == start_page)
                is_end_page = (p == end_page)
                pages.append({
                    "page_index": p,
                    "rect": self._body_rect(
                        ctx, p, start=is_start_page,
                        start_y=(start_y if is_start_page else None),
                        bottom_override=(next_same_page_y if is_end_page else None),
                    ),
                })
            segments.append({
                "id": f"{component_safe}_Q{qn}",
                "question_number": qn,
                "canonical_question": f"Q{qn}",
                "board": self.BOARD_ID,
                "component": component,
                "pages": pages,
                "metadata": {"source_pages": [p + 1 for p in range(start_page, end_page + 1)], "layout_archetype": LayoutArchetype.EDEXCEL_GUTTER_NUMBERED_BOOKLET.value, "crop_plan": crop_plan(self.BOARD_ID, ctx), "page_reference_pattern": "Edexcel page reference excluded separately from CAIE barcode regex"},
            })
        return segments
