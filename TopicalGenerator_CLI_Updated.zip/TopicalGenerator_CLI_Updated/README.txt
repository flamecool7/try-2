TOPICAL GENERATOR — CLEAN CLI RELEASE

This package contains only the topical-generation CLI and the source modules/data it requires.
It excludes the web app, bulk examiner-report collections, test PDFs, prior outputs, logs, QA galleries, and development tests.

QUICK START (Windows)
1. Put source PDFs in the input folder.
2. Double-click RUN_TOPICAL_GENERATOR.bat.
3. Find generated material in output.

DIRECT COMMAND
  python run_guarded.py --input input --output output --clean

Install dependencies manually if needed:
  python -m pip install -r requirements.txt

The --clean option removes an earlier generated run before rebuilding it. Keep source PDFs only in input.
Verified CAIE support includes standard and specimen QP/MS processing, with tested examiner-report component isolation.
