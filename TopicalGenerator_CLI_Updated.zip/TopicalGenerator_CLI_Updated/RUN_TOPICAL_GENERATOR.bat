@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv || goto :fail
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt || goto :fail
python run_guarded.py --input input --output output --clean
set CODE=%ERRORLEVEL%
echo.
echo Finished with exit code %CODE%.
pause
exit /b %CODE%
:fail
echo.
echo Setup or execution failed.
pause
exit /b 1
