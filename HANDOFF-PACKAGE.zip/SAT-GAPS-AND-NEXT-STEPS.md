# SAT gaps + next steps (supplement to HANDOFF.md)

Read `HANDOFF.md` first. This covers only what it does not.

## 1. SAT answer keys — real URLs, NOT yet downloaded
- https://satsuite.collegeboard.org/media/pdf/psat-8-9-practice-test-1-scoring-guide.pdf
- https://satsuite.collegeboard.org/media/pdf/scoring-psat-nmsqt-practice-test-2.pdf
Confirmed-good host pattern: `satsuite.collegeboard.org/media/pdf/<name>.pdf`.
A 404 here returns ~32 KB of HTML — verify `file` says PDF before trusting a download.

## 2. SAT Answer Explanations — filename UNKNOWN, do not guess
College Board publishes a separate Answer Explanations PDF per practice test. The
filename was never confirmed. Find the real link (Reddit r/Sat and r/psat megathreads
are how the URLs above were found) rather than guessing — guessed names 404.

## 3. SAT classification accuracy — the real problem
SAT taxonomy is **2 files / 8 nodes / 34 concepts** vs CAIE **78 / 670 / 1389**.
SAT questions will classify at low confidence or fall through to UNKNOWN far more than
CAIE. This is a corpus gap, not a code bug. Seed the expansion from the College Board
assessment-framework and skills-insight PDFs already in `docs/research/`.

## 4. Confirm document-type coverage
The adapters most likely crop **question papers only**. MS / ER / Insert are separate
engines with separate geometry:
- MS: `core/ms_cropping_engine.py` (CAIE only; RS-64 deliberately excludes MS crops so
  RULE-6 pristine geometry is untouched)
- ER: `core/examiner_report_gold` (CAIE only)
No non-CAIE mark scheme or examiner report exists on disk. The Edexcel paper sourced was
an "Unused Original" QP whose Reddit thread states no mark scheme exists for it.

## 5. QP<->MS<->ER<->Insert association is NOT built (HANDOFF.md open issue #4)

## 6. Before any pipeline run
`pip install -r requirements.txt` — packages are stripped between sessions; the first run
otherwise fails with `ModuleNotFoundError: No module named 'fitz'`.
Never write output to `/tmp` (993 MB RAM-backed tmpfs on a ~2 GB box; OOM-kills workers).
Expect `424 passed, 58 skipped` and proof `overall PASS` as the pre-adapter baseline; the
58 skips are environmental (missing fixture corpus), not failures.
