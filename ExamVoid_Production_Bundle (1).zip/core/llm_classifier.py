"""llm_classifier.py — Optional Internet / LLM Classification Fallback Bridge (2026-08-26).

Provides an optional internet/LLM classification fallback when local keyword
confidence is low or when explicitly requested. Uses requests to query an LLM
API endpoint (OpenAI / Anthropic / custom) if configured, with graceful offline
fallback. Does not touch any cropping mechanisms.
"""

from __future__ import annotations

import os
import json
import logging
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)


def query_llm_classifier(question_text: str, available_topics: List[str], api_key: Optional[str] = None) -> Optional[str]:
    """Query an LLM API (if available and configured) to categorize a question."""
    key = api_key or os.environ.get("EXAMVOID_LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not key or not question_text:
        return None

    try:
        import requests
        url = os.environ.get("EXAMVOID_LLM_ENDPOINT", "https://api.openai.com/v1/chat/completions")
        headers = {
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        }
        prompt = (
            "You are an expert Cambridge examiner and syllabus classifier.\n"
            f"Available topics: {json.dumps(available_topics)}\n\n"
            f"Classify the following exam question into exactly ONE of the available topics above. "
            f"Return ONLY the exact topic string, with no other text.\n\n"
            f"Question Text:\n{question_text[:3000]}"
        )
        payload = {
            "model": os.environ.get("EXAMVOID_LLM_MODEL", "gpt-4o-mini"),
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
            "max_tokens": 100,
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
            # Match against available topics
            for topic in available_topics:
                if topic.lower() in content.lower():
                    return topic
    except Exception as exc:
        logger.debug(f"[LLMClassifier] API query failed (falling back to local): {exc}")

    return None
