"""bundle_cache.py — Granular SHA-256 content-hash cache manifest for incremental runs (2026-08-26).

Tracks input file fingerprints (QP, MS, ER) and intermediate processing states
so partial re-runs and incremental additions skip redundant parsing entirely.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Optional


def file_sha256(path: Path, chunk_size: int = 65536) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


class BundleCacheManifest:
    """Manages `bundle_cache_manifest.json` for incremental extraction caching."""

    def __init__(self, output_root: Path):
        self.output_root = Path(output_root)
        self.manifest_path = self.output_root / "bundle_cache_manifest.json"
        self.data: Dict[str, dict] = self._load()

    def _load(self) -> dict:
        if self.manifest_path.exists():
            try:
                return json.loads(self.manifest_path.read_text(encoding="utf-8"))
            except Exception:
                return {}
        return {}

    def save(self):
        self.output_root.mkdir(parents=True, exist_ok=True)
        try:
            self.manifest_path.write_text(json.dumps(self.data, indent=2, sort_keys=True), encoding="utf-8")
        except Exception:
            pass

    def is_cached(self, base_key: str, qp_path: Optional[Path], ms_path: Optional[Path]) -> bool:
        if base_key not in self.data:
            return False
        entry = self.data[base_key]
        cached_qp_hash = entry.get("qp_sha256")
        cached_ms_hash = entry.get("ms_sha256")

        current_qp_hash = file_sha256(qp_path) if qp_path and qp_path.exists() else None
        current_ms_hash = file_sha256(ms_path) if ms_path and ms_path.exists() else None

        if cached_qp_hash == current_qp_hash and cached_ms_hash == current_ms_hash:
            return True
        return False

    def mark_cached(self, base_key: str, qp_path: Optional[Path], ms_path: Optional[Path], metadata: Optional[dict] = None):
        self.data[base_key] = {
            "qp_sha256": file_sha256(qp_path) if qp_path and qp_path.exists() else None,
            "ms_sha256": file_sha256(ms_path) if ms_path and ms_path.exists() else None,
            "metadata": metadata or {},
        }
        self.save()
