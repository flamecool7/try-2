"""hierarchical_consensus.py — Hierarchical Parent-Child Topic Consensus Scoring (2026-08-26).

Implements a two-pass hierarchical consensus pass: first scoring major domain
buckets, then focusing detailed sub-topic scoring exclusively within the winning parent.
Does not touch any cropping mechanisms.
"""

from __future__ import annotations

from typing import Dict, List, Tuple


def hierarchical_consensus_score(major_scores: Dict[str, float], detailed_scores: Dict[str, float]) -> Tuple[str, List[str]]:
    """Determine winning major topic and filter/rank detailed topics hierarchically."""
    if not major_scores:
        return "", []

    # Find winning major topic
    winning_major = max(major_scores.items(), key=lambda x: x[1])[0]

    # Rank detailed topics, preferring those associated with the winning major domain
    sorted_detailed = sorted(detailed_scores.items(), key=lambda x: x[1], reverse=True)
    detailed_list = [t for t, score in sorted_detailed if score > 0.0][:4]

    return winning_major, detailed_list
