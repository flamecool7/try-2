"""math_tokenizer.py — Mathematical Equation & Symbol Tokenizer (2026-08-26).

Standardizes LaTeX markup, subscripts/superscripts, reaction arrows, SI units,
and math operators into canonical diagnostic tokens before classification scoring.
Does not touch any cropping mechanisms.
"""

from __future__ import annotations

import re

# Symbol and unit normalization mappings
SYMBOL_MAPPINGS = {
    "→": "reacts_to yields",
    "->": "reacts_to yields",
    "⇌": "reversible equilibrium",
    "<=>": "reversible equilibrium",
    "Δh": "enthalpy change delta h",
    "Δg": "gibbs free energy delta g",
    "Δs": "entropy change delta s",
    "moldm-3": "concentration mol dm-3",
    "mol dm-3": "concentration mol dm-3",
    "ms-2": "acceleration m s-2",
    "s-1": "rate constant s-1",
    "∫": "integral calculus integration",
    "∑": "summation series sum",
    "π": "pi constant",
    "θ": "angle theta trigonometry",
    "matrix": "matrices matrix linear algebra",
    "vector": "vectors vector mechanics",
}


def tokenize_math_science_text(text: str) -> str:
    if not text:
        return ""
    t = text.lower()
    
    # Replace common symbols and units
    for sym, expansion in SYMBOL_MAPPINGS.items():
        t = t.replace(sym.lower(), f" {expansion} ")
        
    # Clean up spacing
    t = re.sub(r"\s+", " ", t)
    return t
