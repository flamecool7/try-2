"""memory_governor.py — Proactive Low-RAM Memory Watermark Governor (2026-08-26).

Monitors system memory during heavy multi-page worker runs. If available
RAM drops below safety watermarks, it dynamically forces garbage collection,
clears internal caches, and throttles concurrency to prevent OOM killer crashes.
"""

from __future__ import annotations

import ctypes
import gc
import logging
import time
from pathlib import Path

logger = logging.getLogger(__name__)


def get_mem_available_mb() -> int | None:
    try:
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except Exception:
        return None
    return None


def malloc_trim():
    try:
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


class MemoryGovernor:
    """Proactive RAM monitor and governor."""

    def __init__(self, warning_threshold_mb: int = 500, critical_threshold_mb: int = 250):
        self.warning_mb = warning_threshold_mb
        self.critical_mb = critical_threshold_mb

    def check_and_reclaim(self, worker_name: str = "") -> bool:
        """Check available memory; if low, force GC and malloc_trim.

        Returns True if memory is at critical levels.
        """
        avail = get_mem_available_mb()
        if avail is None:
            return False

        if avail < self.critical_mb:
            logger.warning(f"[MemoryGovernor] CRITICAL RAM available ({avail}MB) for {worker_name}. Forcing emergency GC and trim.")
            gc.collect(2)
            malloc_trim()
            time.sleep(1.0)
            return True
        elif avail < self.warning_mb:
            logger.info(f"[MemoryGovernor] Low RAM available ({avail}MB). Running proactive GC.")
            gc.collect()
            malloc_trim()
        return False
