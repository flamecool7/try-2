"""config_linter.py — Automated Subject Configuration & Taxonomy Linter (2026-08-26).

Checks all subject configuration JSON files and topic taxonomies in subjects/
for structural integrity, duplicate topic identifiers, empty keyword lists,
un-mappable topic hierarchies, and schema conformance.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple


def lint_subject_configs(pkg_root: Path) -> Tuple[bool, List[str]]:
    """Lint all subject configuration files and topic JSONs under subjects/.

    Returns:
        (passed: bool, errors: List[str])
    """
    errors: List[str] = []
    subjects_dir = pkg_root / "subjects"
    if not subjects_dir.exists():
        # Fallback to topics/ if subjects/ isn't direct
        subjects_dir = pkg_root / "topics"
    if not subjects_dir.exists():
        return True, ["No subjects/ or topics/ directory found"]

    config_files = list(subjects_dir.rglob("config.json"))
    topic_files = list(subjects_dir.rglob("*_topics.json"))

    if not config_files and not topic_files:
        errors.append(f"No configuration or topic files found under {subjects_dir}")
        return False, errors

    # Lint config files
    for cf in config_files:
        try:
            data = json.loads(cf.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                errors.append(f"{cf}: not a JSON dictionary")
                continue
            if "syllabus_code" not in data and "code" not in data:
                errors.append(f"{cf}: missing 'syllabus_code' or 'code'")
            if "subject" not in data:
                errors.append(f"{cf}: missing 'subject'")
        except Exception as exc:
            errors.append(f"{cf}: invalid JSON: {exc}")

    # Lint topic JSON files
    for tf in topic_files:
        try:
            data = json.loads(tf.read_text(encoding="utf-8"))
            if not isinstance(data, (dict, list)):
                errors.append(f"{tf}: topic file must be dict or list")
                continue

            topics = []
            if isinstance(data, dict):
                topics = data.get("topics", data.get("major_topics", []))
                if not topics and "subject" in data:
                    # Might be flat or nested
                    pass
            elif isinstance(data, list):
                topics = data

            # Check topic structure and duplicates
            seen_ids = set()
            for t in topics:
                if isinstance(t, dict):
                    tid = t.get("id", t.get("name", t.get("title", "")))
                    if not tid:
                        errors.append(f"{tf}: topic entry missing identifier/name")
                    elif tid in seen_ids:
                        errors.append(f"{tf}: duplicate topic identifier '{tid}'")
                    else:
                        seen_ids.add(tid)

                    keywords = t.get("keywords", t.get("classification_keywords", []))
                    if isinstance(keywords, list) and not keywords:
                        # Warning or error depending on strictness
                        pass
        except Exception as exc:
            errors.append(f"{tf}: invalid topic JSON: {exc}")

    return len(errors) == 0, errors


if __name__ == "__main__":
    import sys
    root = Path(__file__).resolve().parent.parent
    ok, errs = lint_subject_configs(root)
    if ok:
        print("[config_linter] PASS: All subject configs and taxonomies linted successfully.")
        sys.exit(0)
    else:
        print(f"[config_linter] FAIL: {len(errs)} issue(s) found:")
        for e in errs:
            print(f"  - {e}")
        sys.exit(1)
