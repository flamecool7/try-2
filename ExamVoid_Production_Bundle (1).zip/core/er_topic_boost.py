"""er_topic_boost.py — Examiner-Report Guided Topic Refinement (2026-08-26).

Reads extracted question-specific examiner commentary from examiner_report.txt
and applies a calibrated confidence boost to matching topics in the scoring matrix.
Does not touch any cropping mechanisms.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List


def get_examiner_report_boost(question_folder: Path, topic_keywords: Dict[str, List[str]]) -> Dict[str, float]:
    """Scan examiner_report.txt inside the question folder and compute score boosts."""
    boosts: Dict[str, float] = {}
    qfolder = Path(question_folder)
    er_path = qfolder / "examiner_report.txt"
    if not er_path.exists():
        return boosts

    try:
        content = er_path.read_text(encoding="utf-8").lower()
    except Exception:
        return boosts

    for topic, keywords in topic_keywords.items():
        hits = sum(1 for kw in keywords if kw.lower() in content)
        if hits > 0:
            # Calibrated boost proportional to term hits
            boosts[topic] = min(0.25, 0.05 * hits)

    return boosts
