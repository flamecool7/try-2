"""semantic_classifier.py — Context-Aware Semantic Similarity & Term Density (2026-08-26).

Provides semantic concept overlap and sliding n-gram similarity scoring to
disambiguate borderline classification calls. Does not touch any cropping mechanisms.
"""

from __future__ import annotations

import math
import re
from typing import Dict, List


def compute_term_density_score(text: str, keywords: List[str]) -> float:
    if not text or not keywords:
        return 0.0
    text_lower = text.lower()
    words = re.findall(r"\w+", text_lower)
    total_words = len(words)
    if total_words == 0:
        return 0.0

    matches = 0
    for kw in keywords:
        kw_lower = kw.lower()
        # Count occurrences (sub-phrase or exact token)
        count = text_lower.count(kw_lower)
        if count > 0:
            matches += count * len(kw_lower.split())

    # Density ratio with logarithmic dampening
    density = matches / float(total_words)
    return float(1.0 - math.exp(-10.0 * density))
