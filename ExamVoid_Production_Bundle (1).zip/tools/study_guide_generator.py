"""study_guide_generator.py — Automated HTML/Markdown Topical Study Guide Generator (2026-08-26).

Compiles generated question crops, mark schemes, and examiner reports for a
specific major topic into a beautifully formatted HTML study guide document.
Does not touch any cropping mechanisms.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def generate_study_guide(output_root: Path, subject: str, topic_name: str, dest_html: Path):
    output_root = Path(output_root)
    topic_folders = []
    
    # Search for matching topic folder across paper type folders
    for path in output_root.rglob(topic_name):
        if path.is_dir():
            for qfolder in path.iterdir():
                if qfolder.is_dir() and (qfolder / "metadata.json").exists():
                    topic_folders.append(qfolder)

    html_parts = [
        "<!DOCTYPE html>",
        "<html><head><meta charset='utf-8'>",
        f"<title>Study Guide: {topic_name}</title>",
        "<style>",
        "body { font-family: sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; line-height: 1.5; background: #f8fafc; color: #1e293b; }",
        "h1, h2 { color: #0284c7; }",
        ".question-card { background: white; border: 1px solid #cbd5e1; border-radius: 8px; padding: 20px; margin-bottom: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }",
        ".meta { font-size: 0.85rem; color: #64748b; margin-bottom: 10px; }",
        "img { max-width: 100%; height: auto; border: 1px solid #e2e8f0; margin: 10px 0; border-radius: 4px; }",
        "pre { background: #f1f5f9; padding: 10px; border-radius: 4px; overflow-x: auto; font-size: 0.85rem; }",
        "</style>",
        f"</head><body>",
        f"<h1>Topical Study Guide: {topic_name}</h1>",
        f"<p>Subject: <b>{subject}</b> | Generated question folders found: {len(topic_folders)}</p><hr>",
    ]

    for qf in sorted(topic_folders):
        meta_path = qf / "metadata.json"
        er_path = qf / "examiner_report.txt"
        ms_txt_path = qf / f"{qf.name}_MS.txt"
        
        meta = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                pass

        paper = meta.get("paper", qf.parent.name)
        qnum = meta.get("question_number", qf.name)
        season = meta.get("season", "")
        year = meta.get("year", "")

        html_parts.append("<div class='question-card'>")
        html_parts.append(f"<h2>Question {qnum} ({paper})</h2>")
        html_parts.append(f"<div class='meta'>Series: {season} {year} | Paper: {paper} | Topics: {', '.join(meta.get('topic', []))}</div>")

        # Question image
        qp_img = qf / f"{qf.name}.webp"
        if qp_img.exists():
            # Use relative path or data URI if standalone, here relative to output html
            rel_qp = os_relpath(qp_img, dest_html.parent)
            html_parts.append(f"<div><b>Question Paper:</b><br><img src='{rel_qp}' alt='Question Crop'></div>")

        # Mark Scheme
        ms_webp = qf / f"{qf.name}_MS.webp"
        if ms_webp.exists():
            rel_ms = os_relpath(ms_webp, dest_html.parent)
            html_parts.append(f"<div><b>Mark Scheme:</b><br><img src='{rel_ms}' alt='Mark Scheme Crop'></div>")
        elif ms_txt_path.exists():
            txt = ms_txt_path.read_text(encoding="utf-8")
            html_parts.append(f"<div><b>Mark Scheme (Answer):</b><pre>{txt}</pre></div>")

        # Examiner Report
        if er_path.exists():
            ertxt = er_path.read_text(encoding="utf-8")
            html_parts.append(f"<div><b>Examiner Commentary:</b><pre>{ertxt}</pre></div>")

        html_parts.append("</div>")

    html_parts.append("</body></html>")
    dest_html.parent.mkdir(parents=True, exist_ok=True)
    dest_html.write_text("\n".join(html_parts), encoding="utf-8")
    print(f"[StudyGuide] Generated study guide at {dest_html} ({len(topic_folders)} questions included)")


def os_relpath(target: Path, start: Path) -> str:
    import os
    try:
        return os.path.relpath(target, start)
    except Exception:
        return str(target)


def main():
    ap = argparse.ArgumentParser(description="Generate topical study guide HTML from generated question bank")
    ap.add_argument("--output", default="output", help="Path to output root")
    ap.add_argument("--subject", default="Chemistry_9701", help="Subject folder name")
    ap.add_argument("--topic", default="Reaction_kinetics", help="Exact topic folder name")
    ap.add_argument("--dest", default="output/study_guide.html", help="Destination HTML file path")
    args = ap.parse_args()

    generate_study_guide(Path(args.output), args.subject, args.topic, Path(args.dest))


if __name__ == "__main__":
    raise SystemExit(main())
