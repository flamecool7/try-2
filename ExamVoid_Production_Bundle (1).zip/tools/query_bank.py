"""query_bank.py — SQLite-Powered Query & Export CLI for ExamVoid (2026-08-26).

Allows searching the local pipeline database and generated question banks by
syllabus code, subject, season, year, or topic without walking directories.
Does not touch any cropping mechanisms or locked files.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path


def query_database(db_path: Path, syllabus_code: str = None, subject: str = None, status: str = None):
    if not db_path.exists():
        print(f"[Query] Database not found at {db_path}")
        return

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    query = "SELECT * FROM bundles WHERE 1=1"
    params = []

    if syllabus_code:
        query += " AND syllabus_code = ?"
        params.append(syllabus_code)
    if status:
        query += " AND status = ?"
        params.append(status)

    cursor = conn.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    print(f"\n[Query] Found {len(rows)} matching bundle(s):")
    for r in rows:
        print(f"  - Key: {r['bundle_key']} | Code: {r['syllabus_code']} | Status: {r['status']} | Season: {r['season']} {r['year']}")


def main():
    ap = argparse.ArgumentParser(description="Query ExamVoid Question Bank Database")
    ap.add_argument("--db", default="output/pipeline.sqlite", help="Path to pipeline.sqlite")
    ap.add_argument("--code", default=None, help="Filter by syllabus code (e.g. 9701)")
    ap.add_argument("--status", default=None, help="Filter by bundle status (e.g. complete, failed, review_required)")
    args = ap.parse_args()

    db = Path(args.db)
    query_database(db, syllabus_code=args.code, status=args.status)


if __name__ == "__main__":
    raise SystemExit(main())
