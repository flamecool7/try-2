"""quarantine_review.py — Active Learning & Misclassification Quarantine Tool (2026-08-26).

Logs human-verified topic corrections into a reinforcement store
(output/classification_corrections.json) so the classifier can check and
reinforce from previous corrections. Does not touch any cropping mechanisms.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def record_correction(output_root: Path, question_id: str, corrected_topic: str):
    store_path = Path(output_root) / "classification_corrections.json"
    corrections = {}
    if store_path.exists():
        try:
            corrections = json.loads(store_path.read_text(encoding="utf-8"))
        except Exception:
            pass

    corrections[question_id] = corrected_topic
    store_path.write_text(json.dumps(corrections, indent=2), encoding="utf-8")
    print(f"[ActiveLearning] Recorded correction: Question {question_id} -> {corrected_topic}")


def main():
    ap = argparse.ArgumentParser(description="Active Learning Quarantine Review Tool")
    ap.add_argument("--output", default="output", help="Path to output root")
    ap.add_argument("--qid", required=True, help="Question ID or folder name")
    ap.add_argument("--topic", required=True, help="Corrected winning topic")
    args = ap.parse_args()

    record_correction(Path(args.output), args.qid, args.topic)


if __name__ == "__main__":
    raise SystemExit(main())
