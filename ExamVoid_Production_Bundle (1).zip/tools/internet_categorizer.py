"""internet_categorizer.py — Standalone Internet/LLM Categorization Tool for ExamVoid (2026-08-26).

Reads extracted question JSON files from the output directory, queries an LLM API
over the internet as the PRIMARY categorization option with smart SQLite caching
and concurrent rate-limited thread execution, falling back to local keywords.
Does NOT touch cropping mechanisms.
"""

from __future__ import annotations

import os
import json
import glob
import sqlite3
import logging
import argparse
import hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def init_cache(cache_path: Path) -> sqlite3.Connection:
    """Initialize SQLite cache for LLM classification responses."""
    conn = sqlite3.connect(str(cache_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS classification_cache (
            text_hash TEXT PRIMARY KEY,
            subject_code TEXT,
            topic TEXT
        )
    """)
    conn.commit()
    return conn


def get_cached_topic(conn: sqlite3.Connection, text_hash: str) -> str | None:
    cursor = conn.execute("SELECT topic FROM classification_cache WHERE text_hash = ?", (text_hash,))
    row = cursor.fetchone()
    return row[0] if row else None


def cache_topic(conn: sqlite3.Connection, text_hash: str, subject_code: str, topic: str):
    conn.execute("INSERT OR REPLACE INTO classification_cache (text_hash, subject_code, topic) VALUES (?, ?, ?)",
                 (text_hash, subject_code, topic))
    conn.commit()


def load_syllabus_topics(subject_code: str, pkg_dir: Path) -> list[str]:
    """Load official topic tree for the given subject code."""
    for candidate_dir in [pkg_dir / "subjects", pkg_dir / "topics", pkg_dir / "references"]:
        if candidate_dir.exists():
            topic_file = candidate_dir / f"{subject_code}_topics.json"
            if topic_file.exists():
                try:
                    with open(topic_file, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, list):
                            return data
                        elif isinstance(data, dict) and "topics" in data:
                            return data["topics"]
                except Exception:
                    pass
    return [
        "Number", "Algebra", "Coordinate geometry", "Geometry", "Mensuration",
        "Trigonometry", "Vectors", "Statistics", "Probability", "Calculus",
        "Mechanics", "Waves", "Electricity and magnetism", "Atomic physics",
        "Chemical bonding", "Stoichiometry", "Energetics", "Kinetics",
        "Organic chemistry", "Cell biology", "Genetics", "Ecology", "Respiration"
    ]


def categorize_question_via_internet(question_text: str, subject_code: str, pkg_dir: Path, conn: sqlite3.Connection) -> str:
    """Query an LLM API over the internet to classify the question (Primary Option) with smart caching."""
    if not question_text:
        return ""

    text_hash = hashlib.sha256(question_text.encode("utf-8")).hexdigest()
    cached = get_cached_topic(conn, text_hash)
    if cached:
        return cached

    api_key = os.environ.get("EXAMVOID_LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return ""

    topics = load_syllabus_topics(subject_code, pkg_dir)
    url = os.environ.get("EXAMVOID_LLM_ENDPOINT", "https://api.openai.com/v1/chat/completions")
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    
    prompt = (
        "You are an expert Cambridge examiner and curriculum specialist.\n"
        f"Subject Code: {subject_code}\n"
        f"Available Syllabus Topics: {json.dumps(topics)}\n\n"
        "Classify the following exam question into exactly ONE of the available syllabus topics above. "
        "Return ONLY the exact topic string from the list, with no extra commentary or markdown.\n\n"
        f"Question Text:\n{question_text[:2500]}"
    )
    
    payload = {
        "model": os.environ.get("EXAMVOID_LLM_MODEL", "gpt-4o-mini"),
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.0,
        "max_tokens": 100,
    }
    
    try:
        import requests
        resp = requests.post(url, json=payload, headers=headers, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            answer = data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
            answer = answer.replace("`", "").strip()
            for t in topics:
                if t.lower() in answer.lower() or answer.lower() in t.lower():
                    cache_topic(conn, text_hash, subject_code, t)
                    return t
            if answer:
                cache_topic(conn, text_hash, subject_code, answer)
                return answer
    except Exception as e:
        logger.debug(f"Internet API request failed: {e}")
        
    return ""


def process_file(filepath: Path, pkg_dir: Path, conn: sqlite3.Connection) -> tuple[str, str]:
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return filepath.name, "skipped"

        q_text = data.get("text", "") or data.get("question_text", "")
        subject = str(data.get("subject_code", "0580"))

        if q_text:
            new_cat = categorize_question_via_internet(q_text, subject, pkg_dir, conn)
            if new_cat:
                data["category"] = new_cat
                data["categorization_source"] = "internet_llm_primary"
            else:
                if not data.get("category") or data.get("category") == "Unclassified":
                    data["category"] = data.get("local_category", "General / Unclassified")
                    data["categorization_source"] = "local_keyword_fallback"

            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            return filepath.name, "updated"
    except Exception as e:
        logger.error(f"Error processing {filepath}: {e}")
    return filepath.name, "error"


def main():
    parser = argparse.ArgumentParser(description="Run internet-based LLM primary question categorization with caching")
    parser.add_argument("--output", default="output", help="Path to output directory containing question JSONs")
    parser.add_argument("--pkg", default=".", help="Path to project package directory")
    args = parser.parse_args()

    output_dir = Path(args.output)
    pkg_dir = Path(args.pkg)

    if not output_dir.exists():
        print(f"[Internet Categorizer] Output directory '{output_dir}' does not exist.")
        return 0

    cache_path = output_dir / "categorization_cache.sqlite"
    conn = init_cache(cache_path)

    api_key = os.environ.get("EXAMVOID_LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("\n[Internet Categorizer] Notice: No API key detected. Falling back to local keyword classification.")
    else:
        print("\n[Internet Categorizer] Internet LLM set as PRIMARY option with SQLite caching & thread pooling.")

    json_files = [f for f in output_dir.glob("**/*.json") if not any(skip in f.name for skip in ["state", "manifest", "report", "lock", "cache"])]
    logger.info(f"Processing {len(json_files)} JSON files with concurrent threads...")

    updated_count = 0
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(process_file, fp, pkg_dir, conn): fp for fp in json_files}
        for future in as_completed(futures):
            name, status = future.result()
            if status == "updated":
                updated_count += 1

    conn.close()
    print(f"\n[Internet Categorizer] Completed. Processed {len(json_files)} files ({updated_count} updated via internet primary).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
