"""live_dashboard.py — Live Progress Web Dashboard (2026-08-26).

Provides a lightweight local HTTP server exposing real-time pipeline telemetry
(active workers, completed bundles, success/review/fail counts, memory usage)
and a clean browser dashboard for monitoring headless or containerized runs.
"""

from __future__ import annotations

import json
import os
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path


class DashboardHandler(BaseHTTPRequestHandler):
    output_root: Path = Path("output")

    def do_GET(self):
        if self.path == "/api/status" or self.path == "/status":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            data = self._gather_telemetry()
            self.wfile.write(json.dumps(data, indent=2).encode("utf-8"))
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_DASHBOARD.encode("utf-8"))

    def _gather_telemetry(self) -> dict:
        state_file = self.output_root / ".pipeline_state.json"
        papers = {}
        completed = 0
        failed = 0
        review = 0
        if state_file.exists():
            try:
                payload = json.loads(state_file.read_text(encoding="utf-8"))
                papers = payload.get("papers", {})
                for p in papers.values():
                    status = str(p.get("status", "")).lower()
                    if "complete" in status:
                        completed += 1
                    elif "fail" in status:
                        failed += 1
                    elif "review" in status:
                        review += 1
            except Exception:
                pass

        # Memory info
        mem_avail = None
        try:
            with open("/proc/meminfo", encoding="utf-8") as fh:
                for line in fh:
                    if line.startswith("MemAvailable:"):
                        mem_avail = int(line.split()[1]) // 1024
        except Exception:
            pass

        question_folders = 0
        if self.output_root.exists():
            question_folders = len([p for p in self.output_root.rglob("*_Q*") if p.is_dir()])

        return {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "output_root": str(self.output_root),
            "memory_available_mb": mem_avail,
            "question_folders_count": question_folders,
            "bundles": {
                "total": len(papers),
                "completed": completed,
                "failed": failed,
                "review_required": review,
            },
            "papers": papers,
        }

    def log_message(self, format, *args):
        # Silence default request logging to keep console clean
        pass


HTML_DASHBOARD = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>ExamVoid Live Progress Dashboard</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { color: #38bdf8; border-bottom: 2px solid #334155; padding-bottom: 10px; }
        .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-top: 20px; }
        .card { background: #1e293b; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border-left: 4px solid #38bdf8; }
        .card.success { border-left-color: #22c55e; }
        .card.warning { border-left-color: #eab308; }
        .card.danger { border-left-color: #ef4444; }
        .card h3 { margin: 0 0 10px 0; color: #94a3b8; font-size: 0.9rem; text-transform: uppercase; }
        .card .value { font-size: 2rem; font-weight: bold; }
        .section { margin-top: 30px; background: #1e293b; padding: 20px; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { text-align: left; padding: 10px; border-bottom: 1px solid #334155; font-size: 0.9rem; }
        th { color: #94a3b8; }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold; }
        .badge.complete { background: #166534; color: #bbf7d0; }
        .badge.failed { background: #991b1b; color: #fecaca; }
        .badge.review { background: #854d0e; color: #fef08a; }
        .footer { margin-top: 30px; text-align: center; color: #64748b; font-size: 0.8rem; }
    </style>
    <script>
        async function fetchStatus() {
            try {
                let res = await fetch('/api/status');
                let data = await res.json();
                document.getElementById('total-bundles').innerText = data.bundles.total;
                document.getElementById('completed-bundles').innerText = data.bundles.completed;
                document.getElementById('review-bundles').innerText = data.bundles.review_required;
                document.getElementById('failed-bundles').innerText = data.bundles.failed;
                document.getElementById('question-crops').innerText = data.question_folders_count;
                document.getElementById('mem-avail').innerText = (data.memory_available_mb !== null ? data.memory_available_mb + ' MB' : 'N/A');
                document.getElementById('last-updated').innerText = data.timestamp;

                let tbody = document.getElementById('papers-tbody');
                tbody.innerHTML = '';
                for (let [k, p] of Object.entries(data.papers)) {
                    let tr = document.createElement('tr');
                    let statusClass = 'complete';
                    let st = (p.status || '').toLowerCase();
                    if (st.includes('fail')) statusClass = 'failed';
                    else if (st.includes('review')) statusClass = 'review';

                    tr.innerHTML = `<td><b>${k}</b></td><td><span class="badge ${statusClass}">${p.status || 'unknown'}</span></td><td>${p.questions_saved || 0}</td><td>${p.updated_at || ''}</td>`;
                    tbody.appendChild(tr);
                }
            } catch (e) {
                console.error(e);
            }
        }
        setInterval(fetchStatus, 3000);
        window.onload = fetchStatus;
    </script>
</head>
<body>
    <div class="container">
        <h1>ExamVoid Live Progress Dashboard</h1>
        <p>Real-time telemetry and pipeline execution monitor. Auto-refreshes every 3 seconds.</p>
        
        <div class="cards">
            <div class="card success">
                <h3>Completed Bundles</h3>
                <div class="value" id="completed-bundles">0</div>
            </div>
            <div class="card warning">
                <h3>Review Required</h3>
                <div class="value" id="review-bundles">0</div>
            </div>
            <div class="card danger">
                <h3>Failed Bundles</h3>
                <div class="value" id="failed-bundles">0</div>
            </div>
            <div class="card">
                <h3>Question Crops</h3>
                <div class="value" id="question-crops">0</div>
            </div>
            <div class="card">
                <h3>Available RAM</h3>
                <div class="value" id="mem-avail">--</div>
            </div>
        </div>

        <div class="section">
            <h3>Active Pipeline Bundles</h3>
            <table>
                <thead>
                    <tr>
                        <th>Bundle Key</th>
                        <th>Status</th>
                        <th>Questions Saved</th>
                        <th>Last Updated</th>
                    </tr>
                </thead>
                <tbody id="papers-tbody">
                    <tr><td colspan="4" style="text-align:center; color:#64748b;">Loading telemetry...</td></tr>
                </tbody>
            </table>
        </div>

        <div class="footer">
            ExamVoid Agent Mode &bull; Last updated: <span id="last-updated">--</span>
        </div>
    </div>
</body>
</html>
"""


def start_dashboard_server(port: int = 8080, output_root: Path = Path("output")):
    DashboardHandler.output_root = Path(output_root)
    server = HTTPServer(("0.0.0.0", port), DashboardHandler)
    print(f"[Dashboard] Live Progress Dashboard running at http://0.0.0.0:{port}/")
    server.serve_forever()


if __name__ == "__main__":
    start_dashboard_server()
