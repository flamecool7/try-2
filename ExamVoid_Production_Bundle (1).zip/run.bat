@echo off
setlocal EnableExtensions DisableDelayedExpansion

title ExamVoid Topical Generator
color 0B

rem ============================================================================
rem ExamVoid Topical Generator - real-run launcher
rem
rem Double-click: runs a REAL full-auto incremental batch. No dry-run is used
rem by this launcher.
rem --menu:      opens the real-run dashboard.
rem --help:      shows command-line help.
rem
rem The launcher keeps metadata.json and locked crop mechanisms untouched.
rem Every real run writes:
rem   report.txt                 latest send-to-support report
rem   logs\run_YYYYMMDD_HHMMSS.txt   complete console log
rem   logs\report_YYYYMMDD_HHMMSS.txt timestamped copy of the report
rem ============================================================================

set "EXAMVOID_COLOR=always"
set "PROJECT_DIR=%~dp0"
cd /d "%PROJECT_DIR%"
if errorlevel 1 goto DIRECTORY_ERROR
set "PROJECT_DIR=%CD%"
set "INPUT_DIR=%PROJECT_DIR%\input"
set "OUTPUT_DIR=%PROJECT_DIR%\output"
set "LOG_DIR=%PROJECT_DIR%\logs"
set "LOCK_DIR=%OUTPUT_DIR%\.examvoid_run_lock"
set "REPORT_SESSION="
set "REPORT_SUBJECT="

if not exist "%PROJECT_DIR%\run_pipeline.py" goto PROJECT_NOT_FOUND
if not exist "%PROJECT_DIR%\run_guarded.py" goto PROJECT_NOT_FOUND

call :FIND_PYTHON
if errorlevel 1 goto PYTHON_ERROR
call :LOAD_SETTINGS
call :PROFILE_RAM
call :REFRESH_STATS

if /I "%~1"=="--menu" goto MENU
if /I "%~1"=="--help" goto HELP
if "%~1"=="" goto AUTO_RUN
rem Explicit command-line options are still REAL runs. The launcher supplies
rem the configured input/output paths and safe full-auto defaults.
goto COMMAND_LINE

:FIND_PYTHON
set "PYTHON_EXE="
set "PYTHON_ARGS="
if exist "%PROJECT_DIR%\.venv\Scripts\python.exe" set "PYTHON_EXE=%PROJECT_DIR%\.venv\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%PROJECT_DIR%\venv\Scripts\python.exe" set "PYTHON_EXE=%PROJECT_DIR%\venv\Scripts\python.exe"
if defined PYTHON_EXE goto :eof
for /f "delims=" %%P in ('where py.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
if defined PYTHON_EXE set "PYTHON_ARGS=-3"
if defined PYTHON_EXE goto :eof
for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
if not defined PYTHON_EXE exit /b 1
exit /b 0

:LOAD_SETTINGS
set "SETTINGS_FILE=%PROJECT_DIR%\settings.ini"
set "CFG_INPUT="
set "CFG_OUTPUT="
set "CFG_WORKERS="
set "CFG_LOW_RAM="
set "CFG_PERFORMANCE="
if exist "%SETTINGS_FILE%" (
    for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%SETTINGS_FILE%") do (
        if /I "%%A"=="input_folder" set "CFG_INPUT=%%B"
        if /I "%%A"=="output_folder" set "CFG_OUTPUT=%%B"
        if /I "%%A"=="workers" set "CFG_WORKERS=%%B"
        if /I "%%A"=="low_ram" set "CFG_LOW_RAM=%%B"
        if /I "%%A"=="performance" set "CFG_PERFORMANCE=%%B"
    )
)
if defined CFG_INPUT set "INPUT_DIR=%CFG_INPUT%"
if defined CFG_OUTPUT set "OUTPUT_DIR=%CFG_OUTPUT%"
set "LOCK_DIR=%OUTPUT_DIR%\.examvoid_run_lock"
exit /b 0

:PROFILE_RAM
set "TOTAL_RAM_GB="
for /f "delims=" %%B in ('powershell -NoProfile -Command "try { [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB) } catch { 8 }" 2^>nul') do set "TOTAL_RAM_GB=%%B"
echo %TOTAL_RAM_GB%| findstr /r "^[0-9][0-9]*$" >nul || set "TOTAL_RAM_GB=8"

rem Auto profile: 16GB+ machines request six workers, 12GB+ request four,
rem and smaller machines request two. The Python RAM guard may still clamp
rem the actual concurrency if other programs are using the available memory.
set "WORKER_COUNT="
if defined CFG_WORKERS if /I not "%CFG_WORKERS%"=="auto" set "WORKER_COUNT=%CFG_WORKERS%"
if not defined WORKER_COUNT (
    if %TOTAL_RAM_GB% GEQ 16 (set "WORKER_COUNT=2") else if %TOTAL_RAM_GB% GEQ 12 (set "WORKER_COUNT=2") else (set "WORKER_COUNT=2")
)

set "PERFORMANCE_MODE=false"
if /I "%CFG_PERFORMANCE%"=="true" set "PERFORMANCE_MODE=true"
if /I "%CFG_PERFORMANCE%"=="auto" if %TOTAL_RAM_GB% GEQ 16 set "PERFORMANCE_MODE=true"
if not defined CFG_PERFORMANCE if %TOTAL_RAM_GB% GEQ 16 set "PERFORMANCE_MODE=true"

set "PROFILE_FLAGS=--workers %WORKER_COUNT%"
set "PROFILE_LABEL=%TOTAL_RAM_GB% GB: RAM-safe profile, %WORKER_COUNT% requested worker(s)"
if /I "%CFG_LOW_RAM%"=="false" (
    set "PROFILE_FLAGS=--full-ram --workers %WORKER_COUNT%"
    set "PROFILE_LABEL=%TOTAL_RAM_GB% GB: full production raster profile, %WORKER_COUNT% worker(s)"
)
if /I "%PERFORMANCE_MODE%"=="true" (
    set "PROFILE_FLAGS=--performance --workers %WORKER_COUNT%"
    set "PROFILE_LABEL=%TOTAL_RAM_GB% GB: auto/full performance profile, %WORKER_COUNT% requested worker(s)"
)
exit /b 0

:REFRESH_STATS
set "PDF_COUNT=0"
if exist "%INPUT_DIR%" for /r "%INPUT_DIR%" %%F in (*.pdf) do set /a PDF_COUNT+=1
set "OUTPUT_STATUS=not created"
if exist "%OUTPUT_DIR%" set "OUTPUT_STATUS=ready"
if exist "%OUTPUT_DIR%\pipeline.sqlite" set "OUTPUT_STATUS=resume database found"
if exist "%OUTPUT_DIR%\.pipeline_state.json" set "OUTPUT_STATUS=resume state found"
exit /b 0

:SHOW_HEADER
cls
echo.
echo ================================================================================
echo                         EXAMVOID TOPICAL GENERATOR
echo ================================================================================
echo  Project : %PROJECT_DIR%
echo  Input   : %INPUT_DIR%  ^(%PDF_COUNT% PDF file(s)^)
echo  Output  : %OUTPUT_DIR%  ^(%OUTPUT_STATUS%^)
echo  Profile : %PROFILE_LABEL%
echo  Policy  : FULL-AUTO / REAL RUN / LOCAL FILES ONLY
echo  Report  : %PROJECT_DIR%\report.txt
echo ================================================================================
echo.
exit /b 0

:AUTO_RUN
call :CHECK_INPUT
if errorlevel 1 goto FATAL
call :SHOW_HEADER
echo Starting REAL incremental full-auto processing using local PDFs only.
echo Unchanged complete bundles will be skipped automatically.
echo Input audit, timestamped log, and report.txt will be written.
echo.
call :RUN_BATCH --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --trust-self %PROFILE_FLAGS%
set "APP_EXIT=%ERRORLEVEL%"
goto FINAL_EXIT

:MENU
call :SHOW_HEADER
echo  [1] REAL run - all new/changed papers
 echo [2] REAL run - retry failed bundles
 echo [3] REAL run - selected session/year ^(s26, summer, m26, winter, specimen^)
 echo [4] REAL run - clean generated output first
 echo [5] Validate existing output
 echo [6] Validate subject configurations
 echo [7] REAL run - organize ERs only (no QP/MS, no topics)
 echo [8] Check examiner-report inventory
 echo [9] More tools (dependencies / open folders / clear lock)
 echo [0] Exit
 echo.
choice /c 1234567890 /n /m "Select an option: "
if errorlevel 10 goto EXIT
if errorlevel 9 goto TOOLS_MENU
if errorlevel 8 goto CHECK_ERS
if errorlevel 7 goto ER_ORGANIZER
if errorlevel 6 goto CONFIGS
if errorlevel 5 goto VALIDATE
if errorlevel 4 goto CLEAN_RUN
if errorlevel 3 goto RUN_SESSION
if errorlevel 2 goto RUN_RETRY
if errorlevel 1 goto RUN_MENU

goto MENU

:RUN_MENU
set "REPORT_SESSION="
set "REPORT_SUBJECT="
call :CHECK_INPUT
if not errorlevel 1 call :RUN_BATCH --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --trust-self %PROFILE_FLAGS%
set "APP_EXIT=%ERRORLEVEL%"
pause
goto MENU

:RUN_RETRY
set "REPORT_SESSION="
set "REPORT_SUBJECT="
call :CHECK_INPUT
if not errorlevel 1 call :RUN_BATCH --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --trust-self --retry-failed %PROFILE_FLAGS%
set "APP_EXIT=%ERRORLEVEL%"
pause
goto MENU

:RUN_SESSION
call :SHOW_HEADER
set "SESSION_FILTER="
echo.
set /p "SESSION_FILTER=Enter session/year (examples: s26, summer, m26, winter, sp): "
if not defined SESSION_FILTER (
    echo No session entered. Returning to menu.
    pause
    goto MENU
)
set "REPORT_SESSION=%SESSION_FILTER%"
set "REPORT_SUBJECT="
call :CHECK_INPUT
if not errorlevel 1 call :RUN_BATCH --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --trust-self --session "%SESSION_FILTER%" %PROFILE_FLAGS%
set "APP_EXIT=%ERRORLEVEL%"
set "REPORT_SESSION="
pause
goto MENU

:CLEAN_RUN
call :SHOW_HEADER
if exist "%LOCK_DIR%" (
    echo [ERROR] A run appears to be active: %LOCK_DIR%
    pause
    goto MENU
)
choice /c YN /n /m "Delete generated output and start a fresh REAL run? [Y/N]: "
if errorlevel 2 goto MENU
if exist "%OUTPUT_DIR%" rmdir /s /q "%OUTPUT_DIR%"
mkdir "%OUTPUT_DIR%" >nul 2>nul
set "REPORT_SESSION="
set "REPORT_SUBJECT="
call :CHECK_INPUT
if not errorlevel 1 call :RUN_BATCH --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --trust-self %PROFILE_FLAGS%
set "APP_EXIT=%ERRORLEVEL%"
pause
goto MENU

:VALIDATE
call :SHOW_HEADER
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"
set "VALIDATE_LOG=%LOG_DIR%\validate_latest.txt"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
"%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\run_guarded.py" --validate --output "%OUTPUT_DIR%" > "%VALIDATE_LOG%" 2>&1
set "APP_EXIT=%ERRORLEVEL%"
type "%VALIDATE_LOG%"
if "%APP_EXIT%"=="0" echo [OK] Output audit passed.
if "%APP_EXIT%"=="2" echo [WARN] Output is valid but contains review-required records.
if "%APP_EXIT%" NEQ "0" if "%APP_EXIT%" NEQ "2" call :APPLICATION_ERROR %APP_EXIT%
pause
goto MENU

:CONFIGS
call :SHOW_HEADER
set "CONFIG_LOG=%LOG_DIR%\config_validation_latest.txt"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
"%PYTHON_EXE%" %PYTHON_ARGS% -u -c "from core.config_loader import validate_all_configs; ok, errors = validate_all_configs(); print('PASS' if ok else errors); raise SystemExit(0 if ok else 1)" > "%CONFIG_LOG%" 2>&1
set "APP_EXIT=%ERRORLEVEL%"
type "%CONFIG_LOG%"
if "%APP_EXIT%"=="0" (echo [OK] All subject configurations validate.) else (call :APPLICATION_ERROR %APP_EXIT%)
pause
goto MENU

:ER_ORGANIZER
call :SHOW_HEADER
set "ER_INPUT="
echo.
echo ER-only mode: this needs only Examiner Report PDFs.
echo It will crop them and place them under output\Examiner_Reports\Level\Subject\Session\Paper_N.
set /p "ER_INPUT=Enter the extracted ER folder path: "
if not defined ER_INPUT (
    echo No ER folder supplied. Returning to menu.
    pause
    goto MENU
)
if not exist "%ER_INPUT%" (
    echo [ERROR] ER folder was not found: %ER_INPUT%
    pause
    goto MENU
)
set "ER_OUTPUT=%OUTPUT_DIR%\Examiner_Reports"
if not exist "%ER_OUTPUT%" mkdir "%ER_OUTPUT%"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
call :MAKE_STAMP
set "ER_LOG=%LOG_DIR%\er_organizer_%RUN_STAMP%.txt"
echo.
echo Running ER-only organizer. Log: %ER_LOG%
"%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\tools\organize_examiner_reports.py" --input "%ER_INPUT%" --output "%ER_OUTPUT%" --pkg "%PROJECT_DIR%" > "%ER_LOG%" 2>&1
set "ER_EXIT=%ERRORLEVEL%"
type "%ER_LOG%"
echo.
echo ER organizer report: %ER_OUTPUT%\organizer_report.txt
if "%ER_EXIT%"=="0" echo [OK] ER-only organization completed.
if "%ER_EXIT%" NEQ "0" echo [WARN] ER-only organization returned code %ER_EXIT%. Check organizer_report.txt.
pause
goto MENU

:CHECK_ERS
call :SHOW_HEADER
if exist "%PROJECT_DIR%\check_existing_ers.bat" (
    call "%PROJECT_DIR%\check_existing_ers.bat"
) else if exist "%PROJECT_DIR%\list_missing_examiner_reports.bat" (
    call "%PROJECT_DIR%\list_missing_examiner_reports.bat"
) else (
    echo No examiner-report checker was found beside run.bat.
    echo Use the separate ExamVoid_ER_Checker folder for ERs stored elsewhere.
    pause
)
goto MENU

:TOOLS_MENU
call :SHOW_HEADER
echo  [1] Open input, output, logs, and reports
 echo [2] Install/repair Python dependencies
 echo [3] Clear a stale run lock
 echo [4] Run Internet / LLM Categorizer (Optional)
 echo [0] Back to main menu
 echo.
choice /c 12340 /n /m "Select a tool: "
if errorlevel 5 goto MENU
if errorlevel 4 goto RUN_INTERNET_CAT
if errorlevel 3 goto CLEAR_LOCK
if errorlevel 2 goto DEPENDENCIES
if errorlevel 1 goto OPEN_FOLDERS
goto TOOLS_MENU

:RUN_INTERNET_CAT
call :SHOW_HEADER
echo Running Internet / LLM Categorizer...
"%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\tools\internet_categorizer.py" --output "%OUTPUT_DIR%" --pkg "%PROJECT_DIR%"
pause
goto TOOLS_MENU

:CLEAR_LOCK
if exist "%LOCK_DIR%" (
    rmdir /s /q "%LOCK_DIR%" >nul 2>nul
    echo [OK] Run lock cleared: %LOCK_DIR%
) else (
    echo No run lock found.
)
pause
goto TOOLS_MENU

:DEPENDENCIES
call :SHOW_HEADER
echo Checking core Python packages...
"%PYTHON_EXE%" %PYTHON_ARGS% -c "import fitz, PIL, numpy, cv2, requests; print('Core dependencies available.')"
if not errorlevel 1 (
    pause
    goto MENU
)
echo Dependencies are missing. Installing requirements.txt...
"%PYTHON_EXE%" %PYTHON_ARGS% -m pip install -r "%PROJECT_DIR%\requirements.txt"
if errorlevel 1 (call :APPLICATION_ERROR %ERRORLEVEL%) else (echo [OK] Dependencies installed.)
pause
goto MENU

:OPEN_FOLDERS
if not exist "%INPUT_DIR%" mkdir "%INPUT_DIR%"
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
start "" "%INPUT_DIR%"
start "" "%OUTPUT_DIR%"
start "" "%LOG_DIR%"
if exist "%PROJECT_DIR%\report.txt" start "" "%PROJECT_DIR%\report.txt"
goto MENU

:RUN_BATCH
call :REFRESH_STATS
call :CHECK_INPUT
if errorlevel 1 exit /b 1
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"
call :ACQUIRE_LOCK
if errorlevel 1 exit /b 1
call :MAKE_STAMP
set "RUN_LOG=%LOG_DIR%\run_%RUN_STAMP%.txt"
set "AUDIT_LOG=%LOG_DIR%\input_audit_%RUN_STAMP%.txt"
set "REPORT_ARCHIVE=%LOG_DIR%\report_%RUN_STAMP%.txt"
set "RUN_STARTED=%DATE% %TIME%"
call :SHOW_HEADER
echo Running a REAL batch. Console output is being saved to:
echo   %RUN_LOG%
echo.
echo Command: python run_pipeline.py %*
echo.

rem Pre-run identity audit. This is only a safety check; the following command
rem is always a real processing run.
"%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\tools\build_run_report.py" --audit-only --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --project "%PROJECT_DIR%" --report "%PROJECT_DIR%\input_audit.txt" > "%AUDIT_LOG%" 2>&1
if exist "%PROJECT_DIR%\input_audit.txt" (
    echo ---------------- INPUT AUDIT ----------------
    type "%PROJECT_DIR%\input_audit.txt"
    echo -------------- END INPUT AUDIT --------------
    echo.
)

rem Run without dry-run. Stream live progress while saving the exact same
rem output to a UTF-8 log, with a heartbeat during quiet PDF operations.
"%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\tools\run_with_log.py" --log "%RUN_LOG%" -- "%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\run_pipeline.py" %*
set "APP_EXIT=%ERRORLEVEL%"
set "RUN_FINISHED=%DATE% %TIME%"

rem Always build the small report, including when the Python runner fails.
"%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\tools\build_run_report.py" --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --project "%PROJECT_DIR%" --log "%RUN_LOG%" --report "%PROJECT_DIR%\report.txt" --archive "%REPORT_ARCHIVE%" --exit-code "%APP_EXIT%" --started "%RUN_STARTED%" --finished "%RUN_FINISHED%" --session "%REPORT_SESSION%" --subject "%REPORT_SUBJECT%" --profile "%PROFILE_LABEL%" > "%LOG_DIR%\report_builder_%RUN_STAMP%.txt" 2>&1
if exist "%PROJECT_DIR%\report.txt" (
    echo.
    echo Latest support report: %PROJECT_DIR%\report.txt
)
call :RELEASE_LOCK
if "%APP_EXIT%"=="0" (
    echo.
    echo [OK] REAL batch completed successfully.
    choice /c YN /n /m "Would you like to run internet/LLM categorization on unclassified questions now? [Y/N]: "
    if not errorlevel 2 (
        echo Running internet categorizer tool...
        "%PYTHON_EXE%" %PYTHON_ARGS% -u "%PROJECT_DIR%\tools\internet_categorizer.py" --output "%OUTPUT_DIR%" --pkg "%PROJECT_DIR%"
    )
    echo Opening output folder.
    start "" "%OUTPUT_DIR%"
    exit /b 0
)
if "%APP_EXIT%"=="2" (
    echo.
    echo [WARN] REAL batch completed with review-required records.
    echo Report: %PROJECT_DIR%\report.txt
    start "" "%OUTPUT_DIR%"
    exit /b 2
)
echo.
call :APPLICATION_ERROR %APP_EXIT%
exit /b %APP_EXIT%

:ACQUIRE_LOCK
if exist "%LOCK_DIR%" (
    echo [ERROR] Another ExamVoid run appears to be active.
    echo Lock: %LOCK_DIR%
    if exist "%LOCK_DIR%\started.txt" type "%LOCK_DIR%\started.txt"
    exit /b 1
)
2>nul mkdir "%LOCK_DIR%"
if errorlevel 1 (
    echo [ERROR] Could not create run lock: %LOCK_DIR%
    exit /b 1
)
> "%LOCK_DIR%\started.txt" echo Started %DATE% %TIME%
> "%LOCK_DIR%\command.txt" echo %*
exit /b 0

:RELEASE_LOCK
if exist "%LOCK_DIR%" rmdir /s /q "%LOCK_DIR%" >nul 2>nul
exit /b 0

:MAKE_STAMP
set "RUN_STAMP="
for /f "delims=" %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss" 2^>nul') do if not defined RUN_STAMP set "RUN_STAMP=%%T"
if not defined RUN_STAMP set "RUN_STAMP=%RANDOM%"
exit /b 0

:CHECK_INPUT
call :REFRESH_STATS
if %PDF_COUNT% LEQ 0 (
    echo.
    echo [ERROR] No PDF files were found under "%INPUT_DIR%".
    echo Add QP/MS PDFs, then run the launcher again.
    exit /b 1
)
exit /b 0

:COMMAND_LINE
rem Explicit switches remain real runs. Common example:
rem   run.bat --session s26
call :RUN_BATCH --input "%INPUT_DIR%" --output "%OUTPUT_DIR%" --trust-self %PROFILE_FLAGS% %*
set "APP_EXIT=%ERRORLEVEL%"
goto FINAL_EXIT

:HELP
echo.
echo ExamVoid Topical Generator launcher
 echo.
echo Double-click run.bat for a REAL full-auto incremental batch.
echo run.bat --menu          Open the real-run dashboard.
echo run.bat --session s26   Process only May-June/Summer 2026 bundles.
echo run.bat --help          Show this help.
echo.
echo Every real run creates report.txt plus a timestamped log under logs\.
echo Send report.txt here when something fails.
echo.
echo Menu option 7 runs ER-only organization into output\Examiner_Reports\.
echo It needs only ER PDFs and does not categorize them by topic.
echo.
echo Normal mode is local-only: no online source comparison and no downloads.
echo Missing-MS/QP/ER fetching is explicit opt-in only via the Python commands.
echo.
pause
goto EXIT

:APPLICATION_ERROR
echo [ERROR] The Topical Generator failed.
echo.
if exist "%PROJECT_DIR%\report.txt" (
    echo -------- ACTUAL PROBLEM --------
    findstr /B /C:"Category" /C:"Stage" /C:"Reason" "%PROJECT_DIR%\report.txt"
    echo ---------------------------------
    echo Full support report: %PROJECT_DIR%\report.txt
) else (
    echo No report.txt was created. Check the run log above.
)
exit /b %~1

:DIRECTORY_ERROR
echo [ERROR] Cannot switch to the project directory.
goto FATAL

:PROJECT_NOT_FOUND
echo [ERROR] run_pipeline.py/run_guarded.py was not found beside run.bat.
echo Extract the complete project before launching it.
goto FATAL

:PYTHON_ERROR
echo [ERROR] No usable Python 3 runtime was found.
echo Install Python 3.10+ or restore the project's virtual environment.
goto FATAL

:FATAL
set "APP_EXIT=1"
echo.
pause
goto FINAL_EXIT

:EXIT
if not defined APP_EXIT set "APP_EXIT=0"

:FINAL_EXIT
set "FINAL_RC=%APP_EXIT%"
endlocal & exit /b %FINAL_RC%
