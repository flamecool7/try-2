# Edexcel Batch 5 — Real Paper Verification Addendum (Final Edexcel Sourcing Push)

## Scope

This batch is the result of a final, dedicated effort to source and test the Edexcel
subjects that remained untested across Batches 1–4: French (1FR0), Spanish (1SP0),
A-level Design & Technology (9DT0), GCSE Religious Studies (1RA0), A-level Law
(9LW0), and A-level Sociology (9SC0). Per standing instruction ("finish Edexcel if
you can; if you can't, proceed with IB"), each subject was pursued until either a
genuine free official paper was found, or unsourceability was confirmed.

**Outcome: 3 of 6 subjects were sourced and tested. 3 were confirmed unsourceable
and dropped — one of them (Law) for a newly-discovered structural reason, not just
lack of a free copy.**

### Subjects sourced and tested (3 subjects / 5 files)

| Subject | Code | Paper | Series | Source |
|---|---|---|---|---|
| GCSE Religious Studies | 1RA0/1A (Catholic Christianity) | QP + MS | June 2023 | revisionworld.com (official session zip bundle, extracted) |
| GCSE French | 1FR0/3H (Reading, Higher) | QP + MS | June 2023 | revisionworld.com (direct PDF) |
| A-level Design & Technology (Product Design) | 9DT0/01 | QP+MS combined in one document | **Specimen / Sample Assessment Materials (SAM)**, not a live sitting | designandtechbase.com, re-hosting official Pearson-published SAM |

All three source PDFs were independently verified before the pipeline run:
genuine `%PDF` files, correct page counts (20, 20, 54 pages respectively), and
real extractable text matching the expected paper (e.g. 1FR0 QP page 1 reads
"Please check the examination details below…"; 9DT0 SAM page 1 reads "A Level
Design and Technology Sample Assessment Materials… (9DT0)"). The source
documents are not at fault for any result below.

### Subjects searched but dropped (3 subjects)

1. **Spanish (1SP0)** — June 2023 Reading papers (1SP0/3F, 1SP0/3H) were
   confirmed to exist on myexampapers.uk and revisionworld.com, but direct
   fetchable PDF URLs could not be extracted (myexampapers.uk's listing page
   did not resolve via the page fetcher; revisionworld.com's Spanish page was
   not reached before time/effort limits). Dropped as a time-boxing decision,
   not a confirmed dead end — a different fetch approach could likely find it
   in a future session.
2. **GCSE Religious Studies (1RA0) note** — originally logged as a dead end
   because Revision World only exposes **zip bundles** (not individual PDFs)
   for this subject's 2023 session. This was resolved in this batch by
   downloading and extracting the zip directly (`EdexcelARSGCSE2023Papers.zip`
   / `...MarkScheme.zip`) to pull out the Option 1A (Catholic Christianity)
   files — so RS was in fact successfully tested (see table above). Listed
   here only to correct the prior "dead end" status.
3. **A-level Law (9LW0) — now confirmed unsourceable for a structural reason,
   not just lack of a free copy.** Repeated, targeted web searches (including
   directly against qualifications.pearson.com) turned up no domestic UK GCE
   A-level Law papers under any Edexcel code. Cross-checking against Pearson's
   own qualification documentation confirms **Pearson Edexcel does not offer a
   domestic UK GCE A-level in Law at all** — Law is only available from
   Edexcel as an **International Advanced Level** (IAL, specification code
   `YLA1`), a distinct qualification with different codes, papers, and content
   that international schools sit instead of a UK A-level. This means the
   `Law_9LW0` entry in the subject catalogue being worked through in this
   campaign may reference a qualification that does not exist in the form
   assumed (a GCE A-level with a "9LW0"-style domestic code). This is a
   **data-integrity issue in the subject list itself**, separate from and
   upstream of anything the processing pipeline does.
4. **A-level Sociology (9SC0)** — no free past paper could be found under this
   code from any aggregator, confirming the finding from Batch 4 prep for a
   second time. One secondary source (revisiongenie.com) referred to Edexcel
   A-level Sociology under a different code, "9SO0", while Pearson's own 2023/24
   Information Manual excerpt retrieved during this search did not show a
   Sociology entry at all in the alphabetical range where it should appear
   (between Psychology 9PS0 and Statistics 9ST0). This is inconclusive on its
   own, but combined with the total absence of any free past paper under
   either code, it raises the same suspicion as Law: **the catalogue entry's
   code may not correspond to a real, current Pearson Edexcel domestic
   specification.** Treated as unsourceable and dropped.

---

## Pipeline Run

```
python3 tools/run_universal_batch.py --input input/batch_edexcel5 --output output/batch_edexcel5_run --jobs 1
```

Self-reported summary:
```
pdfs: 5, identities: 5
render_attempts: 2, render_pass: 2, render_fail: 0
ms_segments: 0
question_packs: 0, pack_review_items: 0
review_required: 3 (companion_review: 3)
```

## Manual Audit Findings

### 1. Zero content survived from every single document — 0 of 5 (worse than Batch 4)

Every `segments.json` produced by this run is empty (`[]`), and **no `.webp`
image files exist anywhere in the output tree at all** — not for the 2 QPs,
not for the 3 MS documents, not even partially. This is a complete regression
to zero, worse than Batch 4 (which had at least 1 of 5 documents — the D&T MS
— produce some content). Combined with prior batches, **every real Edexcel
Question Paper tested since Batch 2 (now 17 of 17) has produced zero
segmented content**, and Edexcel Mark Schemes are now also trending to zero
(4 of the last 8 MS documents tested across Batches 4–5 produced nothing).

### 2. Self-reported health metrics again contradict the actual output

- `render_pass: 2` is reported, implying 2 of the 5 documents were
  successfully rasterized — yet **zero `.webp` files exist on disk for any
  document**, including those 2. Either the render step's "pass" status does
  not correspond to any image actually being persisted, or persisted images
  are being deleted/not written to the `final/` tree without being reflected
  in the summary.
- `text_layer_checked: 5` with only 2 `render_attempts` suggests 3 documents
  were judged to have usable text layers and skipped rasterization — but
  those 3 also produced 0 segments, so the text-extraction path failed
  silently too.
- Every QP's `contract_report.json` again reports `"status": "PASS"` with an
  empty issues list, despite containing literally zero extracted content —
  the same blind-spot documented in every batch since Batch 2.
- MS documents are flagged `REVIEW_REQUIRED` but with an empty issues list
  (no diagnostic detail), consistent with prior batches.

### 3. The bundled QP+MS document (9DT0 SAM) was entirely misclassified

The Design & Technology Sample Assessment Materials document contains both
the question paper and mark scheme in a single 54-page PDF (a common format
for specimen/sample materials, as opposed to live Question Paper and Mark
Scheme files published separately). The pipeline filed this **entire document
as an MS only** — no corresponding QP folder was created for it at all — and
additionally mis-detected its date as "2017" (`UNKNOWN_2017`) despite the
cover page clearly reading "Sample Assessment Materials" with Pearson's
current branding and no literal "2017" date within the first page's visible
text. This is a new failure mode not seen in earlier batches: single-document
QP+MS bundles are not split or dual-filed, they are silently collapsed into
one category and lose half their intended content type.

### 4. Subject identification: correct for the two single-purpose documents, lost for every MS

Both of the separately-published documents (1FR0 French and 1RA0 RS) had
their **QP** correctly filed under the right subject code and paper/option
(`1FR0_3H`, `1RA0_1A`) — a continuation of the partial identification
improvement seen in Batch 4. However, **all three MS documents** (including
those from the same two subjects) were filed under `EDEXCEL/UNKNOWN`,
losing subject identification entirely despite being paired with a QP that
was correctly identified in the very same run. The date sub-folder shows the
inverse pattern: QPs landed in a literal `"UNKNOWN_2023"` folder (half-correct:
year detected, but rendered as a string that never resolves to a real
"June_2023"-style path), while the MS documents that lost their subject did
get the fully correct `June_2023` date folder. Subject and date identification
are evidently decided independently and neither one reliably predicts the
other.

### 5. Zero packs assembled (continuing the trend from Batches 3–4)

`question_pack_manifest.json` reports `"packs": 0` across all 4 session
folders — consistent with Batch 4's all-time low and worse than Batch 3's
14 (defective) packs. With zero segmented content on either side, there is
nothing for the pack assembler to work with.

---

## Conclusion

This final Edexcel sourcing push successfully located and tested 3 of the 6
previously-untested subjects (French, Religious Studies, and — as a
best-effort specimen substitute — A-level Design & Technology), and
definitively closed out the remaining 3:

- **Spanish (1SP0)** — real papers exist freely online; not sourced this
  session due to fetch-tooling limitations, not unavailability. Could be
  revisited.
- **A-level Law (9LW0)** — **newly discovered to likely not exist as a
  domestic UK GCE A-level under Edexcel at all** (Law is Edexcel-International-only,
  under a different specification, `YLA1`). This is the most significant
  finding of this batch: it suggests at least one entry in the subject
  catalogue driving this campaign may itself be invalid, independent of any
  pipeline defect.
- **A-level Sociology (9SC0)** — confirmed unsourceable for a third time;
  possible (unconfirmed) code mismatch with a tentative "9SO0" found in one
  secondary source.

On the processing side, this batch is the **worst content-survival result of
the entire real-paper campaign**: all 5 documents (both QPs and all 3 MS)
produced zero segments and zero rendered images, continuing and extending the
pattern established in Batches 3–4. Across all 5 Edexcel batches now run
(41 subjects attempted in total across the whole campaign), no real paper
outside the original Batch 1/2 tested set has reliably survived the pipeline
intact, and the pipeline's own self-reported health signals (`contract_report`
PASS status, `render_pass` counts) have never once correctly flagged any of
this empty output.

**This represents the practical limit of further Edexcel sourcing effort for
this campaign.** Per the standing instruction, work now proceeds to IB.
