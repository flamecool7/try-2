# Real-Paper Validation — Cross-Board Executive Summary (Final)

**This document ties together all 20 real-paper validation addenda written across this project's audit campaign. It is a reading guide and severity ranking, not a replacement for any individual addendum — always consult the specific board/batch document for exact evidence, file paths, and quotes before acting on a claim summarized here. This is the final version, written at the close of the campaign once every board had been pursued to the practical limit of free, legitimate sourcing.**

## 0. What this campaign was

Starting from a codebase that claimed support for five exam boards (CAIE, AQA, Edexcel, IB, SAT) but had only ever been validated against a handful of hand-picked or synthetic fixtures, this campaign's method was the same every time, across 20 batches:

1. Source real, legitimately-obtained past papers (question paper + mark scheme/answer pairs) for subjects never previously tested with real papers.
2. Run them through the actual production pipeline (`tools/run_universal_batch.py`), not a narrower unit test.
3. Manually inspect the output against the real paper content — every question, not a sample.
4. Write a prominent, honestly-worded addendum disclosing exactly what worked and what didn't, including severe defects, even when that contradicted an existing "VERIFIED" claim in the codebase.
5. Never patch the underlying code mid-campaign — the goal was disclosure and evidence, not silent repair, so that a human maintainer has an accurate, trustworthy map of where things stand before deciding what to fix.

No addendum in this campaign was ever softened or withheld because a result was bad. Several (Edexcel Batch 1, IB Batch 1, SAT Batch 2) directly contradict upbeat status claims that existed in the codebase's own config files before this campaign started.

The campaign ended by design, not by exhaustion of effort: every board was pushed until either (a) its full subject list was tested, or (b) the remaining untested subjects were confirmed — twice, independently, in Edexcel's case — to have no freely available real or official specimen material, which is the stated boundary condition this campaign adopted from the start (no unauthorized "mirror"/leak sources, no paywalled commercial resellers).

## 1. Results by board, ranked best to worst

| Rank | Board | Subjects tested | Outcome | Addenda |
|---|---|---|---|---|
| 1 | **CAIE** | 81 of 81 (100% of repo's CAIE configs) | Clean. All 7 batches combined found content was correctly extracted; later batches (6–7) found **zero new defects**. This is the only board with full, trustworthy real-paper coverage. | `REAL_PAPER_ACCURACY_REPORT.md` + `REAL_PAPER_BATCH2` through `BATCH7_ADDENDUM.md` |
| 2 | **SAT** | 5 test forms (SAT, PSAT 10, PSAT 8/9, PSAT/NMSQT ×2) | Partial, with a well-understood, narrow defect. When it works, output quality is the best of any non-CAIE board — genuinely correct, cleanly-cropped single-question content. But only Module 1 of 4 ever renders (72.5% content loss per paper), Scoring Guides are misclassified as question papers, Answer Explanations are dropped entirely, and program identification is unreliable. The adapter's own "VERIFIED" claim does not survive a full pipeline run, even on its own cited reference papers. | `REAL_PAPER_SAT_BATCH1_ADDENDUM.md`, `REAL_PAPER_SAT_BATCH2_ADDENDUM.md` |
| 3 | **AQA** | 39 of 46 subjects (3 batches; 7 Group-B subjects explicitly excluded/deferred) | Degrading across batches: Batch 1 reasonable, Batch 2 "did not go smoothly", Batch 3 (2024+ subjects) "substantially worse". | `REAL_PAPER_AQA_BATCH1/2/3_ADDENDUM.md` |
| 4 | **IB** | 14 subjects across 2 batches (10 specimen-based + 4 genuine live 2025 papers); remaining ~16 subjects have no freely available real or specimen material | Severe pairing failure throughout, but Batch 2 produced the single best positive finding of the whole campaign: real, correctly-segmented Question Paper content across 4 brand-new subjects (Economics, Business Management, ESS, Psychology) — the first non-baseline QP success anywhere in this project. Net usable (correctly paired QP+MS) result is still 0 of 24 packs/subjects across both batches; root cause is now concretely evidenced (subject-blind association keys + independent MS-segmentation failures), not just inferred. | `REAL_PAPER_IB_BATCH1_ADDENDUM.md`, `REAL_PAPER_IB_BATCH2_ADDENDUM.md` |
| 5 | **Edexcel** | 31 of 44 subjects across 5 batches (6 confirmed genuinely unsourceable: Law_9LW0, Sociology_9SC0, Religious_Studies zip-workaround aside, Spanish deferred) | Worst outcome of any board by content-survival rate. A root-caused regex defect (`_Q_START` expects `"1."` but most real Edexcel papers print `"1\t"`) causes total content loss on the large majority of subjects tested. By Batches 4–5, **0 of 20 real Question Papers tested since Batch 2 produced any content at all**, and Batch 5 is the single worst batch of the entire campaign (0 of 5 documents, QP or MS, produced anything). Also surfaced a likely data-integrity problem independent of the pipeline: Law_9LW0 may not correspond to a real domestic Pearson qualification at all (Edexcel only offers Law as an International A-Level under a different code). | `REAL_PAPER_EDEXCEL_BATCH1` through `BATCH5_ADDENDUM.md` |

## 2. Defect patterns that recur across multiple boards

These are not board-specific quirks — the same shape of bug shows up independently in unrelated adapters, which suggests shared root causes in the pipeline rather than five unrelated one-off mistakes:

- **Question-numbering-format assumptions baked in from a single reference paper.** Edexcel's `_Q_START` regex and the Edexcel adapter in general were tuned against exactly one real PDF (`9FM0/3C`, a Mathematics paper). SAT's segment-naming hardcodes "PSAT" because it was tuned against PSAT fixtures. IB's adapter explicitly documents being built from "a mirror-sourced May 2024 AA HL Paper 1", and IB Batch 2 directly caught stale fixture metadata ("IB English A Paper 2 specimen... verified_on_real_pdf: false") leaking verbatim into a real, unrelated Economics paper's output. In every case, the adapter generalizes far worse than its own documentation implies, because "verified" described one lucky-fit paper, not the subject/format diversity a board actually contains.
- **Mark-scheme/answer-content orphaning and misclassification.** Edexcel mislabels unpaired mark schemes as standalone "packs" in early batches, and by Batches 4–5 mark schemes mostly just produce zero content outright. IB's combined specimen PDFs produce content labeled "QP" that is actually MS text, 6 times out of 10 in Batch 1; in Batch 2, a real mark scheme's correct content survived segmentation but was silently filed under a completely different, unrelated subject. SAT drops every Answer Explanations document as `UNKNOWN` and misfiles every Scoring Guide as `QP`. In every board, the net effect is the same: a user cannot trust that content under a "QP" or "MS" label is what it claims to be, or that it's even filed under the right subject.
- **Identification has no subject-level discrimination in several adapters.** IB Batch 2 proved this concretely: real documents are grouped into association keys of `board + paper-number + season + year` only, with no subject field, so two completely unrelated real subjects (Economics and Environmental Systems & Societies) were merged into one group purely by coincidence of paper number and date. Edexcel shows a milder version of the same thing — a QP and its own MS are frequently identified with different, inconsistent subject/date results in the same pipeline run.
- **Silent total content loss with no visible trace.** Edexcel's English Language 1EN0 fell through both subject-ID regexes into a generic UNKNOWN bucket; by Batch 5, entire documents (QP and MS alike) silently produce zero webp images with the render stage self-reporting "pass". IB's Physics and Geography specimens vanished with zero output despite clear "International Baccalaureate" branding on page 1. SAT's Answer Explanations are dropped the same way. None of these failures raise an error a user would see — the pipeline reports success (`render_pass`, `question_packs` counts, `contract_report: PASS`) while quietly not producing the content a human would expect.
- **Config claims of "verified" that don't hold up against the full pipeline.** `config/boards/sat.yaml`'s "independently VERIFIED on both real PSAT papers" claim, when re-tested through `run_universal_batch.py` in SAT Batch 2, reproduced the exact same defects found on three never-before-tested programs in Batch 1. This pattern — self-reported health metrics and "verified" claims not matching actual content survival — was reconfirmed in every single batch run for the rest of the campaign, across every board, with no exceptions. Any "VERIFIED" or "PASS" status anywhere in this codebase should be treated as unconfirmed until independently re-checked against real output, not just a contract-report status field.

## 3. What this means for prioritizing fixes

If choosing where to spend limited engineering time, the evidence in these addenda suggests, in order:

1. **SAT's module-render dropout is the single highest-leverage fix available.** It is narrow (identified precisely: `segments.json` is correct, only the render stage drops modules 2–4), reproducible at 100% across 5 real papers, and fixing it alone would roughly quadruple SAT's real content yield (from ~27.5% to potentially ~100% per paper, since the underlying crop logic is already proven correct on Module 1).
2. **IB's subject-blind association key is a concrete, well-evidenced, moderate-sized fix.** Unlike Batch 1's architectural diagnosis, Batch 2 pinpoints the exact mechanism (`association_manifest.json`'s grouping key has no subject dimension) with real documents as evidence. Adding a subject field to the key would likely fix a meaningful fraction of IB's pairing failures immediately — the segmentation/rendering layer is already proven capable of correct output (IB Batch 2 §1).
3. **Edexcel's `_Q_START` regex fix**, identified in Batch 1, remains a precisely root-caused, single-file fix — but its leverage has dropped over the course of the campaign. By Batches 4–5, even subjects that were correctly identified and filed still produced zero content on both QP and MS sides, suggesting there are now multiple compounding defects beyond the original regex, and a fix there alone would likely no longer be sufficient to restore Edexcel to AQA-level yield.
4. **AQA's Group-B (2024+) regressions deserve a root-cause pass** similar to what was done for Edexcel, since "substantially worse" with no stated cause is a weaker finding than Edexcel's precisely-located defect.
5. **IB's MS-segmentation failure (independent of the association-key bug) needs its own investigation.** Batch 2 showed that even a perfectly-grouped QP+MS pair (Psychology, no subject collision) still failed, because the MS document itself produced zero segments — a second, distinct defect from the pairing/grouping problem.
6. **CAIE needs no further real-paper work.** It is the one board where this campaign's method found nothing left to disclose.

## 4. Full index of addenda produced in this campaign (20 total)

| File | Board | Batch |
|---|---|---|
| `REAL_PAPER_ACCURACY_REPORT.md` | CAIE | 1 (pre-existing, referenced by later CAIE batches) |
| `REAL_PAPER_BATCH2_ADDENDUM.md` | CAIE | 2 |
| `REAL_PAPER_BATCH3_ADDENDUM.md` | CAIE | 3 |
| `REAL_PAPER_BATCH4_ADDENDUM.md` | CAIE | 4 |
| `REAL_PAPER_BATCH5_ADDENDUM.md` | CAIE | 5 |
| `REAL_PAPER_BATCH6_ADDENDUM.md` | CAIE | 6 |
| `REAL_PAPER_BATCH7_ADDENDUM.md` | CAIE | 7 (completes 81/81) |
| `REAL_PAPER_AQA_BATCH1_ADDENDUM.md` | AQA | 1 |
| `REAL_PAPER_AQA_BATCH2_ADDENDUM.md` | AQA | 2 |
| `REAL_PAPER_AQA_BATCH3_ADDENDUM.md` | AQA | 3 (completes 39/46; 7 excluded) |
| `REAL_PAPER_EDEXCEL_BATCH1_ADDENDUM.md` | Edexcel | 1 |
| `REAL_PAPER_EDEXCEL_BATCH2_ADDENDUM.md` | Edexcel | 2 (23/44 tested) |
| `REAL_PAPER_EDEXCEL_BATCH3_ADDENDUM.md` | Edexcel | 3 |
| `REAL_PAPER_EDEXCEL_BATCH4_ADDENDUM.md` | Edexcel | 4 (worst pack-count low to that point) |
| `REAL_PAPER_EDEXCEL_BATCH5_ADDENDUM.md` | Edexcel | 5 (final push; 31/44 tested total, 6 confirmed unsourceable, campaign-worst 0/5 content survival) |
| `REAL_PAPER_IB_BATCH1_ADDENDUM.md` | IB | 1 (10 subjects, specimens only) |
| `REAL_PAPER_IB_BATCH2_ADDENDUM.md` | IB | 2 (4 new subjects, genuine live 2025 papers; first real QP success in the campaign) |
| `REAL_PAPER_SAT_BATCH1_ADDENDUM.md` | SAT | 1 |
| `REAL_PAPER_SAT_BATCH2_ADDENDUM.md` | SAT | 2 (re-tests the adapter's own claimed validation baseline) |
| `REAL_PAPER_CROSS_BOARD_SUMMARY.md` | — | this document |

All 20 addenda, plus the rest of the repository, are bundled in `TopicalRunner_updated.zip`.

## 5. What remains untested or permanently out of scope

- AQA's 7 excluded Group-B subjects (documented reasons in `REAL_PAPER_AQA_BATCH3_ADDENDUM.md`).
- Edexcel's **A-level Law (9LW0)** and **A-level Sociology (9SC0)** — confirmed unsourceable from any free aggregator across two independent search passes; Law additionally appears not to exist as a genuine domestic Pearson GCE A-level at all (only as a differently-coded International A-Level, `YLA1`) — a likely data-integrity issue in the subject catalogue itself, separate from anything the pipeline does.
- Edexcel's **Spanish (1SP0)** — real June 2023 papers were confirmed to exist freely online but a direct, fetchable PDF URL was not captured before this campaign's sourcing effort concluded; this is a tooling/time gap, not a true dead end, and could be revisited.
- IB's remaining ~16 subjects beyond the 14 now tested (Mathematics-family beyond the Batch 1 specimens, Chemistry, Physics, Geography, History, Language A/B beyond what's tested, Computer Science, and all internally-assessed/portfolio subjects) — no freely, officially published real or specimen material was found for most; IBO's Questionbank and Programme Resource Centre remain login-gated, and exampaperspractice.co.uk's single-free-sample-per-subject model has been exhausted for the subjects it currently offers (its Computer Science category was seen but not checked, and could be a lead for any future work).
- SAT's remaining practice-test bundles (PSAT 10 Test 2, PSAT 8/9 Tests 2–3) and the separate SAT Practice Essay materials — not pursued further, since the render-dropout defect reproduced at 100% across all 5 forms tested and further testing is unlikely to surface new information until that defect is fixed.
- No code fixes were made to any adapter during this entire campaign, per the standing instruction to prioritize disclosure over silent repair. Every finding above is a documented, evidenced observation for a future maintainer to act on, not a change already made.
