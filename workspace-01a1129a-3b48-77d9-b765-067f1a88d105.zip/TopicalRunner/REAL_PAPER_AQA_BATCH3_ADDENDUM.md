# Real-Paper Validation Addendum — AQA Batch 3 (Group B: 2024+ subjects)

**Status: this batch produced substantially worse results than AQA Batch 1 and Batch 2. Disclosed here in full. No code fix was attempted this session (same decision as Batch 2). Read this before trusting any output from the 13 subjects below.**

## 0. Scope and why these subjects are a separate batch

AQA Batch 1 and Batch 2 (26 subjects total) covered every AQA subject whose repo config listed a `syllabus_years` range starting before 2024. The remaining 20 AQA subjects ("Group B") all have `syllabus_years` starting at `2024`. Before sourcing papers, those 20 were triaged:

- **Excluded (2 subjects)** — no conventional written exam exists at all: Art_and_Design A-level (7201) and Art_and_Design GCSE (8201) are 100% portfolio / Externally-Set-Assignment / practical, with no question-paper booklet to run through a PDF pipeline.
- **Deferred (5 subjects)** — audio-dependent components that can't be meaningfully audited from a PDF/text pipeline: Music A-level (7272), Music GCSE (8271) (the real written exam is an audio-based "Appraising Music" listening paper), French A-level (7652), French GCSE (8658), Spanish GCSE (8698) (this repo's "Paper 1" for these is AQA's real Listening paper).
- **Selected for Batch 3 (13 subjects, this document)**: Drama_and_Theatre_7262 (A-level), Drama_8261 (GCSE), Physical_Education_7582 (A-level), Physical_Education_8582 (GCSE), Design_and_Technology_8552 (GCSE), Government_and_Politics_7152 (A-level), Law_7162 (A-level), Media_Studies_7572 (A-level), Philosophy_7172 (A-level), Religious_Studies_7062 (A-level), Religious_Studies_8062 (GCSE), English_Language_7702 (A-level), Sociology_7192 (A-level).

All 13 use Paper 1 (or the sole written component, where the subject has only one), June 2024 session — the earliest year inside each subject's configured `syllabus_years` list.

## 1. Sourcing: AQA's own filestore gates the June 2024 session

Every direct `https://filestore.aqa.org.uk/sample-papers-and-mark-schemes/2024/june/AQA-<code>-<QP|MS>-JUN24.PDF` request for all 26 target files (13 subjects × QP+MS) returned **HTTP 302 → 404**, even though the identical URL pattern worked without issue for June 2023 and earlier in Batch 1/2. This looks like AQA embargoes public filestore access to its two most recent live sessions (June 2025, June 2024 at the time of this work) and only opens them up later — the pattern was uniform across all 13 very different subjects, which rules out a per-subject access restriction.

All 26 files were instead sourced from third-party revision-site mirrors that re-host the same official PDFs (confirmed by the authentic AQA page stamps inside the files, e.g. `IB/M/Jun24/7172/1`, `IB/G/Jun24/7192/1`):

| Subject | Code | QP+MS source |
|---|---|---|
| Sociology_7192 (A-level) | 71921 | `cdn.sanity.io` mirror linked from revisionworld.com |
| Religious_Studies_7062 (A-level) | 70621 | `cdn.sanity.io` mirror linked from revisionworld.com |
| Law_7162 (A-level) | 71621 | `cdn.sanity.io` mirror linked from revisionworld.com |
| Media_Studies_7572 (A-level) | 75721 | `cdn.sanity.io` mirror linked from revisionworld.com |
| Drama_and_Theatre_7262 (A-level) | 7262W | `cdn.sanity.io` mirror linked from revisionworld.com |
| Physical_Education_7582 (A-level) | 75821 | `cdn.sanity.io` mirror linked from revisionworld.com |
| Government_and_Politics_7152 (A-level) | 71521 | `cdn.sanity.io` mirror linked from revisionworld.com |
| Drama_8261 (GCSE) | 8261W | `cdn.sanity.io` mirror linked from revisionworld.com |
| Physical_Education_8582 (GCSE) | 85821 | `cdn.sanity.io` mirror linked from revisionworld.com |
| Design_and_Technology_8552 (GCSE) | 8552W | `cdn.sanity.io` mirror linked from revisionworld.com |
| Philosophy_7172 (A-level) | 71721 | `cdn.sanity.io` mirror linked from savemyexams.com |
| Religious_Studies_8062 (GCSE, Catholic Christianity option) | 806212 | `cdn.sanity.io` mirror linked from savemyexams.com |
| English_Language_7702 (A-level) | 77021 | PMT (physicsandmathstutor.com) direct mirror |

All 26 PDFs were verified to have valid `%PDF` headers before use. For Religious_Studies_8062 (GCSE), AQA offers 6 parallel religion options for Paper 1 (Buddhism, Catholic Christianity, Christianity, Hinduism, Islam, Judaism); **Catholic Christianity (8062/12)** was picked arbitrarily as the representative option, consistent with the precedent set for similarly multi-option subjects in earlier batches.

## 2. Infrastructure problems discovered and worked around this session

### 2a. New bug: non-numeric "W" component codes collide in a shared output directory

Three of the 13 subjects use AQA's bare `W` suffix as their paper identifier instead of a number: Drama_and_Theatre_7262 → `7262W`, Drama_8261 → `8261W`, Design_and_Technology_8552 → `8552W`. The pipeline's session-directory keying strips the subject-number prefix and keys purely on the trailing paper code, so when more than one `*W` subject is processed into the same shared output directory (the per-subject-loop method established in Batch 2 to work around sandbox OOM limits), **all of them collapse into one shared `AQA/W/<session>/` folder**, and the pack assembler refuses to run:

```json
{
  "detail": "one session dir must hold one question paper; run each paper separately",
  "documents": ["AQA-8261W-QP-JUN24", "AQA-8552W-QP-JUN24"],
  "reason": "MULTIPLE_QP_DOCUMENTS_IN_SESSION"
}
```

Worse, before that refusal triggers, QP/MS/review files from the colliding subjects get written into the *same* folder tree, so an uncorrected run would silently mix content from two unrelated subjects together. This was caught, the corrupted shared folder was deleted, and each of the three `*W` subjects was re-run into **its own separate output directory** (`output/batch10_7262W`, `output/batch10_8261W`, `output/batch10_8552W`). This is a real pipeline/identifier bug (the paper code needs to be the full subject+component string, not the bare trailing code) — it was **worked around, not fixed**, and will recur on any future batch mixing multiple bare-letter-coded subjects into a shared run.

### 2b. New OOM pattern: Design_and_Technology_8552 crashes when QP+MS run together

Even in its own isolated output directory with `--jobs 1`, running Design_and_Technology's QP and MS together in one `run_universal_batch.py` invocation was OOM-killed (exit 137) on this sandbox's 1.9 GiB RAM ceiling. Running the QP alone, then the MS alone, as two separate sequential invocations into the same output directory succeeded both times and merged correctly. The underlying cause wasn't fully diagnosed (the embedded raster images in the 28-page, 2.4 MB QP are not unusually large individually), but the workaround is recorded here for any future continuation.

## 3. Carried-over bug: the page-position (y0) segmentation failure (from Batch 2) — confirmed again, worse

Batch 2 found that the adapter's numbered-question fallback segmenter only recognises a question start if its printed number sits near the very top of the page (`y0 <= 120pt`); anything lower is silently dropped with no error. The same exact bug reproduces in Batch 3 and this time causes **total loss of question-paper content in 4 of 13 subjects** (not just partial loss):

| Subject | Real question markers found in the PDF (`y0`) | Pipeline QP output |
|---|---|---|
| Government_and_Politics_7152 (A-level) | 6 real questions, `y0` = 130.5, 197.5, 264.6, 713.0, 195.6, 262.5 — **all above 120** | `segments.json` = `[]`. **0 of 6 real questions rendered — 100% loss, both QP and MS sides empty.** |
| Religious_Studies_7062 (A-level) | 4 real questions, `y0` = 170.5, 237.8, 381.8, 461.7 — **all above 120** | `segments.json` = `[]` on the QP side. **0 of 4 real questions rendered.** The 4 "packs" that do exist in the delivered output are MS-only orphans (flagged `MISSING_QP`) — i.e. mark-scheme text with no matching question to go with it. |
| English_Language_7702 (A-level) | 5 real questions, `y0` = 285.7, 326.6, 367.6, 181.6, 93.4 — mostly above 120 | `segments.json` = `[]` on the QP side. **0 of 5 real questions rendered.** Again, the only output is MS-only orphans. |
| Physical_Education_8582 (GCSE) | ≥9 real top-level questions at mixed `y0` | Partial: 6 of the expected top-level question numbers (Q1, Q2, Q4, Q5, Q8, Q11) are missing entirely — same intermittent pattern as Batch 2's AS Computer Science / Economics GCSE (questions whose number happens to print low on the page vanish, others on the same paper survive). |

In short: **3 of 13 subjects (Government_and_Politics, Religious_Studies_7062, English_Language) have zero usable question content** — the delivered folders contain nothing but orphaned mark-scheme fragments — and a 4th (Physical_Education_8582) lost roughly 30% of its top-level questions to the same bug.

## 4. New bug: question-paper misclassified as an "Insert" document

Drama_and_Theatre_7262 (A-level)'s actual question-paper PDF (`AQA-7262W-QP-JUN24.PDF`) was identified by the pipeline's document-type classifier as an **Insert** (reference/stimulus material) rather than a **Question Paper**, and was routed to the `IN/` folder instead of `QP/`. The practical effect is identical to the y0 bug's total-loss case: `render_attempts: 0`, zero real question crops, and the only "packs" present are MS-only orphans (`MISSING_QP` on all 7). **This subject's Batch 3 output is entirely unusable** — a student would see 7 mark-scheme fragments with no questions attached, from an exam that in fact has 26 numbered sub-parts.

## 5. New bug: mark-scheme segmentation fails independently of the question paper

Several subjects have a perfectly fine question paper but a mark scheme that the pipeline could not segment at all, or almost not at all — a different failure mode than the y0 bug (confirmed: these MS files' own question-number markers use a different single-token layout, e.g. `"01"` as one merged span rather than the QP's two-span `"0"` + `"1"`, which appears to break the segmenter that expects the QP's exact layout):

| Subject | QP crops | MS crops | MS result |
|---|---|---|---|
| Law_7162 (A-level) | 23 (looks complete) | **0** | `segments.json` = `[]`. No mark scheme at all for any of the 9 real questions. |
| Physical_Education_7582 (A-level) | 43 (looks complete) | **0** | `segments.json` = `[]`. No mark scheme at all. |
| Religious_Studies_8062 (GCSE) | 4 (both real questions complete and correctly bundled) | **0** | `segments.json` = `[]`. No mark scheme at all. |
| Media_Studies_7572 (A-level) | 15 | **2** | Only 1 of 7 real questions has a matching mark-scheme segment. |
| Design_and_Technology_8552 (GCSE) | 30 | **2** | Mark scheme almost entirely missing (same MS-collapse symptom class found in Batch 2's Further Maths). |

## 6. New bug: pack labels (`Q1`, `Q2`, …) do not reliably match the real printed question number

This is a user-facing correctness problem distinct from the completeness problems above. Spot-checking the delivered crops against the source PDFs found that the folder named `Q1` sometimes contains a question whose real printed AQA number is **not** `01`:

- **Sociology_7192 (A-level)**: the delivered `Q1` folder's crop shows the printed header **`0 3`** ("Read Item A below... analyse two problems girls may experience...") — i.e. it is real Question 3, not Question 1. (Likely explanation: the paper's real Q01 sits at `y0 = 131`, just over the 120pt cutoff, and gets dropped by the Section 3 bug; the pipeline then appears to renumber the surviving segments positionally rather than preserving their true printed number.)
- **Drama_8261 (GCSE)**: the delivered `Q1` folder's crop is not a question at all — it is the printed *Crucible* play extract ("Read the following extract and answer Question 5 on page 7"), i.e. the stimulus material for real Question 5, mislabelled as `Q1`.

By contrast, several other subjects' `Q1` folders were spot-checked and found correct (Law_7162 `Q1` = real `01`, "Which one of the following statements about the offence of murder is true?"; Philosophy_7172 `Q1` = real `01`, "What is meant by (a) a necessary condition..."; Religious_Studies_8062 `Q1` = real `01`, correctly bundling all 5 sub-parts of the Catholic Christianity Beliefs question). **The labelling is therefore inconsistent — sometimes right, sometimes silently wrong — which is more dangerous than a uniform failure, because a user has no way to tell which `Qn` folders to trust without checking every one against the source paper.**

## 7. New bug: multi-question bundling plus cross-subject topic contamination

Design_and_Technology_8552 (GCSE)'s delivered `Q5` pack crop actually contains **three distinct MCQ questions printed on the page** (real `05`, `06`, `07` — composite materials, a volume calculation, and thermoforming polymers) bundled into one image under a single `Q5` label. That same pack was then tagged with the topic name **`bonding_structure_properties`** — a topic that does not exist in Design & Technology's own config; it is an **A-level Chemistry topic name**, evidently triggered by keyword overlap on the phrase "composite material." This is a concrete instance of the topic classifier matching keywords against the wrong subject's topic bank entirely, not just failing to classify.

## 8. New bug: phantom pack from a blank trailing page

Philosophy_7172 (A-level)'s delivered packs include a `Q10` folder, even though the real paper only has 9 questions (confirmed via the printed `01`–`09` markers). The `Q10` crop is the booklet's blank "Additional page, if required" answer sheet plus the AQA copyright-acknowledgement footer — not a question. This is the same class of defect as the GCSE Maths Q27 crop-bleed found in Batch 2 (trailing boilerplate pages mis-detected as a question), here producing a fully phantom extra pack rather than a partial crop overrun.

## 9. Systemic, batch-wide: topic classification is almost entirely non-functional for Group B subjects

Every one of the 13 subjects' `config.json` defines a real `paper_topics` list (e.g. Religious_Studies_7062: `Philosophy_of_Religion`, `Ethics_and_Religion`, …; Government_and_Politics_7152: `UK_Democracy_and_Participation`, …). Despite that, the topic classifier returned `UNKNOWN` (confidence 0.0, engine `nonib_fallback`, zero evidence) for almost every single question across almost every subject:

| Subject | Questions classified to a real topic | Questions left `UNKNOWN` |
|---|---|---|
| Religious_Studies_7062, Media_Studies_7572, English_Language_7702, Religious_Studies_8062, Drama_and_Theatre_7262, Drama_8261 | **0** | 100% |
| Law_7162 | 1 of 11 | 91% |
| Sociology_7192 | 1 of 6 | 83% |
| Philosophy_7172 | 2 of 10 | 80% |
| Physical_Education_8582 | 2 topics in use across 14 packs | mostly unclassified |
| Physical_Education_7582 | 3 topics in use across 21 packs | mostly unclassified |
| Design_and_Technology_8552 | 1 topic in use, and it is **wrong** (see §7) | effectively 100% |
| Government_and_Politics_7152 | n/a — 0 packs exist at all | n/a |

The topic bank *content* exists in config for every subject; what is missing is the keyword-evidence matching the classifier needs to connect question text to those topic names. This appears to be a gap specific to these newly-added Group B humanities/non-STEM subjects (the classifier evidently has working keyword rules for the STEM subjects tested in Batches 1–2, which fared much better on this axis), not a data-entry gap in the topic lists themselves.

## 10. Per-subject summary table

| # | Subject | Code | Real Q count | QP crops delivered | MS crops delivered | Verdict |
|---|---|---|---|---|---|---|
| 1 | Religious_Studies_7062 (A-level) | 70621 | 4 | **0** | 8 (orphaned, no matching QP) | **Unusable — total QP loss (§3)** |
| 2 | Government_and_Politics_7152 (A-level) | 71521 | 6 | **0** | 0 | **Unusable — total loss both sides (§3)** |
| 3 | Law_7162 (A-level) | 71621 | 9 | 23 (complete, spot-checked clean) | **0** | Questions usable; **no mark scheme at all (§5)**; topic UNKNOWN on 10/11 |
| 4 | Philosophy_7172 (A-level) | 71721 | 9 | 23 | 19 | Mostly usable; 1 phantom pack (§8); topic UNKNOWN on 8/10 |
| 5 | Sociology_7192 (A-level) | 71921 | 6 | 6 | 12 | **Pack-label mismatch confirmed — `Q1` is really `03` (§6)**; do not trust folder numbers without checking content; topic UNKNOWN on 5/6 |
| 6 | Media_Studies_7572 (A-level) | 75721 | 7 | 15 (looks complete) | **2 of 7** | Questions mostly usable; mark scheme almost entirely missing; topic UNKNOWN on 7/7 |
| 7 | Physical_Education_7582 (A-level) | 75821 | ~9 top-level (21 sub-items delivered) | 43 | **0** | Questions usable; **no mark scheme at all (§5)**; 3 real topics used, rest UNKNOWN |
| 8 | English_Language_7702 (A-level) | 77021 | 5 | **0** | 10 (orphaned) | **Unusable — total QP loss (§3)** |
| 9 | Religious_Studies_8062 (GCSE, Catholic Christianity) | 806212 | 2 | 4 (complete, spot-checked clean, correctly bundles all sub-parts) | **0** | Questions clean and complete; **no mark scheme at all (§5)**; topic UNKNOWN on 2/2 |
| 10 | Physical_Education_8582 (GCSE) | 85821 | ~9 top-level (14 delivered) | 18 | 12 | Partial QP loss — 6 top-level numbers missing (§3); 2 real topics used, rest UNKNOWN |
| 11 | Drama_and_Theatre_7262 (A-level) | 7262W | 26 sub-parts | **0** | 18 (orphaned) | **Unusable — QP misclassified as Insert (§4)** |
| 12 | Drama_8261 (GCSE) | 8261W | 16 | 18 (12 of 16 top-level numbers present) | 34 | Partial QP loss; **confirmed pack-label/content mismatch — `Q1` is really the Question-5 extract (§6)**; topic UNKNOWN on 12/12 |
| 13 | Design_and_Technology_8552 (GCSE) | 8552W | 9 | 30 (15 packs, but `Q5` bundles 3 real questions) | **2 of 15** | **Multi-question bundling + wrong cross-subject topic tag (§7)**; mark scheme almost entirely missing; required an OOM workaround (§2b) |

**Net: 4 of 13 subjects (Religious_Studies_7062, Government_and_Politics_7152, English_Language_7702, Drama_and_Theatre_7262) are completely unusable — zero real question content delivered. Of the remaining 9, every single one has at least one confirmed defect: 3 have no mark scheme at all, 2 have a confirmed wrong pack label, 1 has multi-question bundling plus a wrong topic tag, 1 has a phantom extra pack, 1 has partial question loss, and topic classification is close to entirely non-functional across the board. Zero of the 13 subjects in this batch are fully clean.**

## 11. What was not attempted

- **No code fix was made** for the y0<=120 page-position bug (carried over from Batch 2, unchanged), the "W"-component session-directory collision (§2a), the QP/Insert misclassification (§4), the MS-segmentation failures (§5), the pack-label/content mismatch (§6), the cross-subject topic contamination (§7), the phantom-pack bug (§8), or the topic-classifier evidence gap (§9). All are disclosed here, not repaired.
- The pack-label mismatch (§6) was confirmed in 2 of 13 subjects by direct spot-check; it was **not** exhaustively checked against every pack in every subject, because doing so requires manually cross-referencing every single delivered crop against the source PDF page by page. Any `Qn` folder in this batch's output should be treated as **unverified** until checked against the source paper.
- The root cause of the MS-segmentation failures in §5 was narrowed to a span-tokenization mismatch (QP uses a two-span `"0"` + digit layout the segmenter expects; at least one affected MS uses a single merged `"01"` token) but not fully traced through the segmenter code, and not fixed.
- The exact memory-blowup mechanism behind the Design_and_Technology OOM (§2b) was not diagnosed beyond confirming it only occurs when QP+MS are processed together in one invocation.
- No attempt was made to re-source the 4 totally-unusable subjects from a different mirror or a different (non-June-2024) session to see if the bug is specific to this PDF rendering or would reproduce on any paper for that subject — the evidence so far (the bug depends on where AQA happened to print the question number on the page, which varies paper-to-paper) suggests it probably would still occur on a different session's paper for the same subject, but this was not tested.
