"""Regression test for the IB adapter's examiner-report (subject report) identification.

Found 2026-10-06 while investigating a user report that "the script doesn't even
do examiner reports": adapters/ib/adapter.py's identify_document_type() had zero
wording for IB's own examiner-commentary document (officially called a "subject
report", e.g. a real in-circulation document's own running header reads
"SUBJECT REPORTS - MAY 2000 ... QUESTION ..."). Only QP/MS wording existed, so
every IB subject report fell through to document_type=UNKNOWN regardless of its
filename -- even though the board inherits HAS_EXAMINER_REPORTS=True from the
base class and the universal pipeline (tools/run_universal_batch.py) dispatches
purely on content-derived document_type. identify_examiner_report() was also
hardcoded to always return [], independent of content.

This is distinct from (and should not be confused with) AQA/Edexcel/CAIE, which
were all independently verified working for ER identification before this fix.
"""
from __future__ import annotations

from adapters.ib.adapter import Adapter
from adapters.base import DocumentContext


def _ctx(text: str, filename: str = "doc.pdf") -> DocumentContext:
    return DocumentContext(
        path=filename, filename=filename, stem=filename.rsplit(".", 1)[0], suffix=".pdf",
        first_page_text=text, full_text=text, layout={},
    )


def test_ib_subject_report_wording_identifies_as_er():
    """IB's own native document title ('subject report(s)') must be recognised."""
    text = (
        "International Baccalaureate Organization 2023\n\n"
        "SUBJECT REPORTS - MAY 2023\n\n"
        "Chemistry\nOverall grade boundaries\nStandard level\n\n"
        "Question 1\nCandidates generally performed well on this question.\n\n"
        "Question 2\nMany candidates struggled to identify the correct answer.\n"
    )
    ctx = _ctx(text, "chem_sl_subject_report_may23.pdf")
    adapter = Adapter()

    board_evidence = adapter.identify_document(ctx)
    assert any(e.value == "IB" for e in board_evidence), "IB board signature must still be recognised"

    type_evidence = adapter.identify_document_type(ctx)
    assert any(e.value == "ER" for e in type_evidence), "IB subject report text must identify as ER"

    er_evidence = adapter.identify_examiner_report(ctx)
    assert any(e.value == "ER" for e in er_evidence), "identify_examiner_report must no longer hardcode []"


def test_ib_informal_examiner_report_title_also_identifies_as_er():
    """Real-world re-publishers commonly title the same document 'Examiner Report'."""
    text = "Chemistry Examiner Report May 2017 Timezone 2\n\nQuestion 1\nMost candidates answered well.\n"
    ctx = _ctx(text, "random_filename_123.pdf")
    adapter = Adapter()
    type_evidence = adapter.identify_document_type(ctx)
    assert any(e.value == "ER" for e in type_evidence)


def test_ib_markscheme_and_question_paper_unaffected():
    """Regression guard: the new ER branch must not shadow existing MS/QP detection."""
    adapter = Adapter()

    ms_text = "International Baccalaureate\nMarkscheme\nMay 2023\nChemistry\nStandard level\nPaper 1"
    ms_evidence = adapter.identify_document_type(_ctx(ms_text))
    assert any(e.value == "MS" for e in ms_evidence)
    assert not any(e.value == "ER" for e in ms_evidence)

    qp_text = (
        "INTERNATIONAL BACCALAUREATE\nDIPLOMA PROGRAMME\n"
        "Instructions to candidates\nAnswer all questions.\n1. State the..."
    )
    qp_evidence = adapter.identify_document_type(_ctx(qp_text))
    assert any(e.value == "QP" for e in qp_evidence)
    assert not any(e.value == "ER" for e in qp_evidence)


def test_ib_supports_document_type_er_flag_matches_base_default():
    adapter = Adapter()
    assert adapter.supports_document_type("ER") is True
