# Real-Paper Accuracy Testing — AQA Batch 2 Addendum

Second batch of real AQA past-paper testing (13 more subjects, all June
2023). Sourcing went smoothly this time (12 of 13 subjects downloaded
directly from `filestore.aqa.org.uk` with no gate; only one QP needed the
PMT mirror fallback). The segmentation results did not go smoothly: this
batch found a **single root-cause bug that is more consequential than
anything found in Batch 1** — a hardcoded assumption that every top-level
question starts within the first ~120pt of a fresh page, which silently
drops any question that doesn't. It affects 5 of the 13 subjects here, with
severity ranging from partial loss to a complete, 100%, zero-questions-
extracted failure. Three further, unrelated defects were also found and
confirmed by hand. **No code fix was attempted this session** — the
clarifying question asking whether to fix it now versus just disclose it
went unanswered, so per this project's established practice (CAIE and
Batch 1 defects were disclosed, not silently patched), everything below is
disclosed as found, with the pipeline output left exactly as it was
rendered.

## 1. Scope

| # | Subject | Code | Level | Session | Component |
|---|---|---|---|---|---|
| 1 | Biology | 7402 | A-Level | June 2023 | Paper 1 |
| 2 | Chemistry | 7405 | A-Level | June 2023 | Paper 1 |
| 3 | Computer Science | 7517 | A-Level | June 2023 | Paper 1 |
| 4 | Further Mathematics | 7367 | A-Level | June 2023 | Paper 1 |
| 5 | Geography | 7037 | A-Level | June 2023 | Paper 1 (Physical Geography) |
| 6 | History | 7042 | A-Level | June 2023 | Component 1D ("Stuart Britain and the Crisis of Monarchy, 1603–1702") |
| 7 | Chemistry | 7404 | AS | June 2023 | Paper 1 |
| 8 | Computer Science | 7516 | AS | June 2023 | Paper 1 |
| 9 | Business | 8132 | GCSE | June 2023 | Paper 1 |
| 10 | Economics | 8136 | GCSE | June 2023 | Paper 1 |
| 11 | English Literature | 8702 | GCSE | June 2023 | Paper 1 ("Shakespeare and the 19th-century novel") |
| 12 | Mathematics | 8300 | GCSE | June 2023 | Paper 1 Higher |
| 13 | Physics | 8463 | GCSE | June 2023 | Paper 1 Higher |

Subject selection followed the same `syllabus_years` pre-check as Batch 1:
these 13 are the subset of the 33 subjects left untested after Batch 1
whose spec is confirmed to cover June 2023 (the other 20 are first-taught
2024+ and are deferred to a future batch that sources 2024/2025 papers —
see the project's running task notes).

**Component substitution on History 7042**: the originally-planned
component was 1A ("The Age of the Crusades"). `AQA-70421A-QP-JUN23.PDF`
302-redirected on `filestore.aqa.org.uk` (its MS loaded fine — the same
QP-gated/MS-open asymmetry documented in Batch 1 §2a). Rather than reach
for the PMT mirror for 1A specifically, component **1D** ("Stuart Britain")
was substituted instead, because both its QP and MS loaded directly from
AQA's own filestore with no mirror needed. 1D is one of the component
options already listed under this subject's own `paper_topics["1"]`
config entry, so this is a like-for-like swap within the same paper, not a
different paper.

## 2. Sourcing

Sourcing was largely uneventful this round:

- **12 of 13 subjects' QP+MS pairs loaded directly from
  `filestore.aqa.org.uk` with a clean HTTP 200** on the first attempt —
  a much better hit rate than Batch 1's 9 of 13.
- **1 subject needed the PMT mirror**: A-level Computer Science 7517's QP
  302-redirected on filestore (its MS loaded directly). The PMT mirror
  copy was fetched, confirmed to be the genuine 7517/1 June 2023 paper by
  its own printed header (`IB/G/Jun23/7517/1`), and used in place of the
  gated filestore copy — the same fallback pattern as Batch 1.
- **History's originally-planned component (1A) was swapped for 1D** for
  the reason given in §1 above, rather than invoking the PMT mirror for a
  third consecutive AQA subject in a row.

All 26 files (13 QP + 13 MS) were verified as genuine PDFs (`%PDF` header)
before being run through the pipeline.

## 3. Headline finding: a page-position assumption silently drops questions that start mid-page

### 3a. The bug, precisely

`adapters/aqa/adapter.py`'s generic fallback segmenter
(`_segment_numbered_boxed`, used whenever the subject-specific
literature/language/computer-science/A-level/maths paths all decline to
claim a document) looks for a question's "0 N" left-margin marker and
only accepts it as a new question's start if:

```python
if not (40 <= x0 <= 70 and 45 <= y0 <= 120):
    continue
```

The `x0` check (left-margin column) is sound. The `y0` check — the marker
must sit within the top 120pt of the page — is not: it silently assumes
every new top-level question starts on a fresh page, immediately below the
page header. That is true for the GCSE-science-style papers this fallback
was evidently tuned against (each question gets its own page), but it is
**not** true whenever a question's stem, data table, or source extract
ends partway down a page and the next question starts immediately
afterward on the same page — which is the normal layout for
case-study/data-response subjects like Geography, Business, Economics, and
essay subjects like History.

This was confirmed directly, not inferred: for five subjects below, the
exact `(x0, y0)` of every real "0 N" marker in the source PDF was measured
and compared one-for-one against which questions the pipeline actually
extracted. **In all five cases, exactly the markers with `y0 > 120`
were missing from the output, and exactly the markers with `y0` in range
survived** — a perfect match, not a coincidence.

### 3b. Severity by subject

| Subject | Real top-level questions | Extracted | Loss |
|---|---|---|---|
| Geography 7037/1 (A-level) | ~6 (measured: Q1–Q6, mixed-choice) | **0** | **100%** |
| Business 8132/1 (GCSE) | 3 (Q1 MCQ block, Q2, Q3) | **0** | **100%** |
| History 7042/1D (A-level) | 4 (Q1–Q4) | **0** | **100%** |
| Economics 8136/1 (GCSE) | 26 (Q1–Q26) | 11 (Q3,5,8,10,11,14,16,19,20,22,26 — every one at page-top y0≈66–69) | **58%** |
| Computer Science 7516/1 (AS) | ~15 (Q1–Q15, estimate from highest surviving marker) | 7 (Q2,5,9,10,13,14,15 — every one at page-top y0≈69) | **~53%** |

For the three 100%-loss subjects, `segments.json` for the question paper is
a literal empty list (`[]`) — not a crash, not a review flag, just zero
questions, with the document's own contract report still reporting
`"status": "PASS"` (an empty list trivially satisfies "nothing is
mis-cropped"). **A user looking only at `pack_index.json` or the contract
report for these three subjects would see no error of any kind** — the
only way to discover the loss is to notice the pack/topic counts are zero,
or open the source PDF and count questions by hand, which is what this
audit did.

For Business specifically, the mark scheme compounds the loss in a
different way: rather than also returning zero, the MS segmenter collapsed
its own "Question 1 / Question 2 / Question 3" headings into a single
segment labelled `Q1` that spans **the entire 19-page mark scheme** —
Section B and Section C's real headings were not recognised as separate
questions either, for reasons not fully diagnosed (most likely the same
family of bug, on the MS side's own heading-position heuristic).

### 3c. Compounding bug specific to History

History 7042/1D has a second, independent defect on top of §3a: AQA's PDF
text layer sometimes prints the two digits of a question number as **two
separate text-line objects** rather than one joined line — e.g. Q2, Q3 and
Q4's markers are `"0"` and `"2"` / `"3"` / `"4"` as two distinct lines at
the same y-coordinate, not a single `"0 2"` line. The fallback's regex
(`re.fullmatch(r"\d\s+\d", txt)`) only matches a single line's text, so
even if the y0 gate above were fixed, these three markers would still be
missed. (Q1's marker on this particular paper happens to be printed as one
joined line, so it is only excluded by the y0 gate, not this second bug.)

Despite the question paper losing 100% of its content, History's mark
scheme segmented correctly (`Q1`–`Q4`, each found via the heading text
"Question 1" / "Question 2" / etc., not the "0 N" marker) — but with no
matching QP to pair them against, all four end up stranded in
`review_required/UNKNOWN/` rather than a real topic pack, flagged both
`MISSING_QP` and `TOPIC_UNKNOWN`.

## 4. Three further, unrelated defects

### 4a. English Literature 8702/1 (GCSE): 13 real questions over-segmented into 22

The real paper has exactly 13 questions — confirmed from the official mark
scheme's own content, which runs "Question 1" through "Question 13" and
then ends ("The Tempest" … "The Sign of Four", 23 pages, no further
numbered question after 13). The question paper agrees: its own printed
text never goes past "Question 13" either.

The pipeline produced **22** question segments. The cause is the
`aqa_alt_extract_one_page` layout handler, whose own code comment states
its naming rule plainly: *"AQA contents-table alternatives mapped to
Q1..Qn by printed order"* — i.e. it assumes one page = one question, and
numbers its output segments sequentially by page order rather than reading
the paper's own printed question number. That assumption holds for the
first 13 pages of this paper (the earlier set-text options' extracts each
fit on a single page), but breaks for the later, longer 19th-century-novel
extracts (Dickens, Shelley, Austen, Conan Doyle), each of which spans an
extract page **and** a separate task page — two pages for one real
question. The handler counts each of those as a new question, so the back
half of the paper is stretched from 6 real questions (Q8–Q13) into 12
fake sequential ones (labelled Q11–Q22 in the output). This is the direct
cause of the pack index's 9 `MISSING_MS` flags for "Q14" through "Q22" —
those nine are not missing content from a real question; they are
duplicate halves of real questions 9–13 that the mark scheme (correctly)
never had separate entries for in the first place.

### 4b. AS Chemistry 7404/1: isotope superscripts misread as a phantom question, swallowing real Q3

AQA's mark scheme row-table parser (which groups "01.1".."01.6" etc. rows
under question headers) misread the isotope-abundance numbers inside real
question 2's calculation working — `⁸⁷Sr`, `⁸⁶Sr`, `87.73`, `87X` — as a
left-margin row header for a non-existent "Question 87". This was
confirmed visually: the crop written out for the phantom `Q87` is the
*second half* of real Q2.5's mark scheme row, duplicating content that
already correctly exists under the real `Q2` pack. Worse, a second
phantom bucket, `Q0`, absorbed what should have been real **Q3**'s own
mark-scheme rows (confirmed visually: `Q0`'s crop shows Q2.6's tail, then
Q3.1 and Q3.2 in full, then the start of a later question) — meaning real
Q3's mark scheme is not actually *missing*, it exists, just mislabelled
and sitting in `review_required/UNKNOWN/Q0` instead of the `Q3` pack a
user would look in. Both phantom buckets are correctly routed away from
real topic packs (they do not contaminate `Inorganic_chemistry` or
`Physical_chemistry`), but six real questions (Q3, Q4, Q5, Q13, Q16, Q21)
are flagged `MISSING_MS` as a knock-on effect of this single misparse, and
real Q1 is separately flagged `TOPIC_UNKNOWN` (classifier confidence 0,
cause not further diagnosed).

### 4c. Further Mathematics 7367/1 (A-level): mark-scheme segmentation collapses after Q2

The pipeline's own log for this document states the cause directly:
`[aqa-alevel-maths] mark-scheme rows are not a clean 1..N run; not an
A-level maths MS`. The dedicated A-level maths MS parser refused the whole
document on that basis, and the fallback it dropped to only found
questions 1 and 2 individually (both landed correctly in real topic packs:
`Hyperbolic_functions/Q1`, `Complex_numbers/Q2`) before giving up and
writing everything else — real questions 3 through 16, spanning 16 pages
of the mark scheme — into one single undifferentiated segment labelled
`Q0`, which was correctly routed to `review_required/UNKNOWN` rather than
mixed into a real pack. The question paper itself is intact (all 16
questions segmented and topic-classified correctly), so this is a
mark-scheme-only defect, but it means 14 of 16 questions (87.5%) in this
subject have no usable per-question mark scheme in the deliverable.

### 4d. GCSE Mathematics 8300/1H: trailing blank pages bundled into the last question's crop

Minor, cosmetic, non-content-loss: all 27 real questions segmented and
classified correctly (clean pass, 0 review items), but the very last
question (Q27) has no following question to bound it, so the
"ends at last content + 12pt, or the printed page floor" fallback used for
every other question's final page instead ran all the way through the
paper's trailing matter — the explicit "There are no questions printed on
this page" page, and three blank "Additional page, if required" lined
sheets — bundling all of it into Q27's crop (6 image pages total, most of
them blank). One of those trailing blank pages failed the automated
contract check (`"top 20 px verified white band is not blank"` —
apparently a stray hairline from a page-number/table rule sits just inside
the crop's top edge), which is why this is the one subject in this batch
whose contract report shows an explicit `FAIL` rather than a silent pass.
No real content is lost; the pack is simply far larger than it needs to be.

## 5. Subjects confirmed genuinely clean

Four of the 13 subjects were hand-checked (both metadata and representative
image crops opened and read) and found to have no defects: **Biology 7402/1**
(10/10 questions, 0 review items), **Chemistry 7405/1** (10/10, 0 review
items), **Computer Science 7517/1** (16/16, 0 review items — the one
subject sourced via the PMT mirror, confirmed to match the real paper by
its own printed header), and **Physics 8463/1H** (9/9, 0 review items).
Spot-checked crops (e.g. Biology Q1's three-part virus-structure question,
Physics Q3's five-part circuit/latent-heat question) show clean, complete,
correctly-bounded question content matching the source PDF exactly.

## 6. Summary table — all 13 subjects

| Subject | Real topic-classified questions | Routed to UNKNOWN/review | Verdict |
|---|---|---|---|
| Biology 7402/1 | 10 / 10 | 0 | **Clean** |
| Chemistry 7405/1 | 10 / 10 | 0 | **Clean** |
| Computer Science 7517/1 | 16 / 16 | 0 | **Clean** (PMT-sourced QP) |
| Physics 8463/1H | 9 / 9 | 0 | **Clean** |
| Mathematics 8300/1H | 27 / 27 | 0 | Clean content; cosmetic crop-bloat on last question (§4d) |
| Further Mathematics 7367/1 | 14 / 16 | 2 | QP clean; MS collapses after Q2 (§4c) |
| AS Chemistry 7404/1 | 10 / 13 | 3 (2 phantom + 1 real) | MS row-misparse cascade (§4b) |
| English Literature 8702/1 | 22 (should be 13) | 0 | QP over-segmented 13→22 (§4a) |
| AS Computer Science 7516/1 | 7 (should be ~15) | 0 | **~53% of QP lost** (§3b) |
| Economics 8136/1 | 11 (should be 26) | 0 | **58% of QP lost** (§3b) |
| History 7042/1D | 0 (should be 4) | 4 | **100% of QP lost** (§3b/3c) |
| Geography 7037/1 | 0 (should be ~6) | 0 | **100% of QP lost** (§3b) |
| Business 8132/1 | 0 (should be ≥3) | 0 | **100% of QP lost** (§3b) |

**4 of 13 fully clean, 1 with a cosmetic-only defect, 8 of 13 with
confirmed content-affecting defects** — a markedly worse hit rate than
Batch 1 (which had comparable headline issues in only 3 of 13 subjects).
This is attributable almost entirely to this batch's subject mix including
several data-response/case-study/essay subjects (Geography, Business,
Economics, History) whose layout the existing adapter was evidently never
tested against; Batch 1's worst subjects (Psychology, Combined Science
Physics strand) were comparatively narrow, single-paper bugs rather than
one systemic assumption touching five subjects at once.

## 7. What was not attempted

No code fix was made to `adapters/aqa/adapter.py` or any other adapter
file this session. The y0-position bug in §3 is the clearest, highest-value
fix candidate across both AQA batches so far — it is narrowly scoped (one
`if` condition), already has five known-good test cases in this batch's
own source PDFs to verify against, and a widened or removed y0 bound looks
safe in principle (the x0 column + exact-two-digit-fullmatch + same-baseline
dot-subpart-rejection gates already narrowly constrain what can match) —
but confirming that without introducing a regression would require
re-running it against every previously-passed AQA subject from Batch 1
(13 subjects) and this batch's own 4 clean + 1 cosmetic subjects, which
was out of scope for this pass. This is flagged as the top candidate for a
dedicated fix-and-regression-test session before any further AQA batches
are sourced, rather than fixed ad hoc here.
