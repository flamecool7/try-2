# Real-Paper Accuracy Addendum — Edexcel Batch 4

**Scope:** A fourth Edexcel batch, run immediately after Batch 3, covering 5 more previously-untested
subjects (10 files, QP+MS pairs), chosen specifically as a second, independent sample to check whether
Batch 3's headline finding — universal Question Paper segmentation failure — was a one-off artifact of
that particular set of subjects, or a reproducible property of the pipeline.

| # | Subject | Code | Level | Series |
|---|---|---|---|---|
| 1 | Computer Science (Paper 1) | 1CP2/01 | GCSE | June 2023 |
| 2 | Music (Component 3: Appraising) | 1MU0/03 | GCSE | June 2023 |
| 3 | Drama and Theatre (Component 3) | 9DR0/03 | A-level | June 2023 |
| 4 | Drama (Component 3A) | 1DR0/03A | GCSE | June 2023 |
| 5 | Design and Technology (Component 1A: Metals) | 1DT0/1A | GCSE | June 2023 |

All 10 files verified `%PDF` / HTTP 200, sourced from Physics & Maths Tutor and Revision World (unmodified
Pearson-published PDFs). Two subjects that are genuinely offered under the Edexcel directory structure
this project tracks — A-level Law (9LW0) and A-level Sociology (9SC0) — were searched for but **could not
be sourced**: every free past-paper aggregator checked (PMT, Revision World, SaveMyExams, TutorChase,
MathsGenie, Oxbridge Home Learning) only indexes AQA (7162/7192), OCR, WJEC, or Edexcel's separate
*International* A-Level (YLA1) for these subject names — none hosts free papers under the Pearson UK GCE
codes 9LW0/9SC0. These two remain unattempted and open, alongside French (1FR0), Spanish (1SP0), A-level
Design & Technology (9DT0), and GCSE Religious Studies (1RA0, which only publishes bundled zips rather
than individually-linked PDFs on the sites checked).

## Result: Batch 3's finding reproduces exactly — and gets worse

| Subject code | QP segments | QP webps | MS segments | MS webps |
|---|---|---|---|---|
| 1CP2/01 | 0 | 0 | 0 | 0 |
| 1MU0/03 | 0 | 0 | 0 | 0 |
| 9DR0/03 | 0 | 0 | 0 | 0 |
| 1DR0/03A | 0 | 0 | 0 | 0 |
| 1DT0/1A | 0 | 0 | 1 | 4 |

**All 5 of 5 Question Papers in this batch produced zero segments and zero rendered pages** — identical
to all 10 QPs in Batch 3. Combined across the two batches, **15 of 15 real Edexcel Question Papers tried
since Batch 2** have produced completely empty output, spanning 15 different subjects across GCSE,
IGCSE and A-level. `contract_report.json` again reports `"status": "PASS", "issues": []` for every one of
these empty folders — including the correctly-subject-and-date-bucketed ones (`1DT0_1A/June_2023/QP`,
`9DR0_03/June_2023/QP`), proving this is not solely a consequence of mis-identification; even QPs that
land in exactly the right folder arrive there with nothing inside.

On the Mark Scheme side, this batch is **worse** than Batch 3: only 1 of 5 subjects (GCSE Design &
Technology, 1DT0/1A) produced any content at all — 4 rendered pages, visually confirmed as genuine,
correct D&T mark-scheme content (softwood/corrugated-board/polyester materials questions, 3(a) through
4(c)). The other 4 subjects (Computer Science, Music, A-level Drama and Theatre, GCSE Drama) produced
**nothing whatsoever** — not one page, from either document, despite being equally valid, equally
text-native source PDFs.

Even the one partial success has its own defect: the 4 rendered pages are all filed as a single pack
labelled "Q3," but visually they contain the mark schemes for **questions 3(a) through 4(c)** — i.e. two
entire distinct top-level questions (3 and 4, each with multiple sub-parts) merged into one
mislabelled question slot. This is the inverse of the under-segmentation seen elsewhere in the campaign:
here the segmenter over-merged adjacent questions rather than failing to split at all.

## Pack assembly: zero packs produced, the first time this has happened in the entire campaign

`question_pack_manifest.json` for this run shows:

```json
{"packs": 0, "review_items": [], "session_summaries": [...all individual sessions also show "packs": 0...]}
```

This batch did not produce a single question pack of any kind — not even a misfiled or
`TOPIC_UNKNOWN`-flagged one, as Batch 3 at least did (14 packs, all defective). **This is the lowest
pack-assembly count recorded anywhere in the real-paper campaign.** Despite that, the batch's own summary
stats (`render_pass: 5, render_fail: 0`) read as fully successful, and every per-file `contract_report.json`
says `PASS` — reinforcing the central theme of this whole investigation: the pipeline's self-reported
health metrics are not a reliable proxy for whether any usable content reached the output tree.

## Subject identification: partial improvement over Batch 3, but irrelevant to content loss

Unlike Batch 3 (where only half of QPs resolved to a real subject code), 3 of 5 QPs in this batch landed
in correctly-named subject buckets (`1DR0_3A`, `1DT0_1A`, `9DR0_03`), and 2 of those 3 also got the right
date sub-folder (`1DT0_1A/June_2023`, `9DR0_03/June_2023`). Computer Science (1CP2) and Music (1MU0)
both fell into the generic `EDEXCEL/UNKNOWN` bucket for both QP and MS. This shows subject/program
identification is not uniformly broken — but, as in Batch 3, correct identification does not correlate
with correct content: the two QPs that landed in exactly the right subject-and-date folder
(`1DT0_1A/June_2023/QP`, `9DR0_03/June_2023/QP`) are just as empty as the ones that didn't.

## Conclusion

Two consecutive, independently-sourced batches (Batch 3: 10 subjects/20 files; Batch 4: 5 subjects/10
files) now agree that **Question Paper segmentation fails 100% of the time** on any Edexcel subject
outside the original Batch 1/2 test set — 15 for 15, across GCSE, IGCSE and A-level, across STEM,
humanities, languages-adjacent, and practical/creative subjects alike. Mark Scheme segmentation is only
marginally better (5 of 15 subjects across both batches produced any content, and one of those 5 had
content wrongly merged across two questions). Pack assembly, the final step that would make any of this
usable, produced either badly-collided output (Batch 3) or nothing at all (Batch 4). In no case across
either batch did the pipeline's own status reporting (`contract_report.json`, batch summary stats) flag
any of this — every empty or defective folder reports a clean `PASS`.

This closes out this round of Edexcel testing. Across all 4 Edexcel batches (13 + 10 + 10 + 5 = 38
subjects attempted), a consistent picture has emerged: subject/program identification is inconsistent but
improving in later batches, while actual question *content* survival is low everywhere and, on the
evidence of Batches 3–4, trends toward **zero** for any paper not already baked into the pipeline's
original tested set.
