# Real-Paper Validation Addendum — Edexcel Batch 2 (10 subjects)

**Status: every defect identified in `REAL_PAPER_EDEXCEL_BATCH1_ADDENDUM.md` reproduced exactly as predicted, on a completely different set of 10 subjects. Net result: 0 of 10 subjects (0%) produced usable question content — worse than Batch 1's already-poor 2/13 (15%). Read the Batch 1 addendum first; this document only covers what's new.**

## 0. Scope

Batch 2 = the remaining 10 "Group A" Edexcel subjects not covered in Batch 1, June 2023 session, Paper 1 (or the nearest Paper-1-equivalent component):

| Subject | Code | Source |
|---|---|---|
| Biology B, A-level | 9BI0/01 | PMT direct mirror |
| Business, A-level | 9BS0/01 | revisionworld.com direct mirror |
| Geography, A-level | 9GE0/01 | PMT direct mirror |
| Biology, GCSE (Higher tier) | 1BI0/1H | PMT direct mirror |
| Chemistry, GCSE (Higher tier) | 1CH0/1H | PMT direct mirror |
| Combined Science, GCSE (Biology 1, Higher tier) | 1SC0/1BH | PMT direct mirror |
| Geography, IGCSE | 4GE1/01 | PMT direct mirror |
| Mathematics A, IGCSE (Higher tier) | 4MA1/1H | PMT direct mirror |
| Mathematics B, IGCSE | 4MB1/01 | PMT direct mirror |
| Science (Double Award), IGCSE (Biology 1B) | 4SD0/1B | PMT direct mirror — **identical underlying PDF to IGCSE Biology 4BI1/1B**: Pearson dual-codes this exact paper "4BI1/1B 4SD0/1B" on every page, confirmed by inspecting the extracted text, so both subjects' Paper 1 content is literally the same document |

All 20 PDFs (10 QP + 10 MS) verified as valid `%PDF` files. The pipeline again ran cleanly, no crashes, no OOM: `render_pass: 10/10`, `companion_pass: 8/10`, `question_packs: 32` — again, a healthy-looking summary that hides the real outcome.

## 1. The dominant Batch-1 bug reproduced on every single subject

The `_Q_START` dot-only regex defect (Batch 1 §2) reproduced on **all 10** Batch 2 subjects. Checking the extracted text directly: Business, Geography (both A-level and IGCSE), GCSE Biology, GCSE Chemistry, Combined Science, IGCSE Maths A, and IGCSE Maths B all print question numbers as `"1\t ..."` (tab, no period) exactly like Batch 1's non-Mathematics subjects. Result: `segments.json` is `[]` for 9 of the 10 subjects.

## 2. A new, worse variant: one stray match swallows the entire paper into a single mislabeled "question"

Biology B (9BI0) didn't get zero segments — it got **exactly one**, and that one segment is a disaster: the regex happened to find a single `"N."`-shaped substring somewhere in the paper (most likely a numbered sub-list item inside a question's body text, not a real question heading), and because there was no second match to close the segment, **the entire remaining 25 pages of the 32-page paper (pages 7–31) were cropped into one single image stack and labelled "Q1."** This is worse than the clean zero-segment failures elsewhere in this batch: it produces a confident-looking, fully-rendered "pack" that is entirely wrong.

That one bogus pack was also given a topic tag of **`decision_discrete`** — a **Mathematics** topic (decision/discrete maths), applied to a **Biology** paper. The topic classifier didn't just fail to classify; it actively mis-tagged cross-subject. This pack is also flagged `MISSING_MS` internally (its real mark scheme was never matched to it, for the same underlying reason).

## 3. Subject-identification blind spot (Batch 1 §4) reproduced for both plain-"/01"-suffix IGCSE codes in this batch

Geography IGCSE (`4GE1/01`) and Mathematics B IGCSE (`4MB1/01`) both have a purely-numeric component suffix and a syllabus code that doesn't start with "9" — exactly the blind-spot profile identified in Batch 1 §4 (English Language GCSE). Both were never assigned a subject folder at all and landed entirely inside the board-level `EDEXCEL/UNKNOWN/` bucket, alongside unrelated orphaned mark schemes. This confirms the Batch 1 prediction that the bug is **not** specific to English Language — it will recur on any Edexcel GCSE/IGCSE subject whose Paper-1 code doesn't end in a tier letter and doesn't start with "9".

## 4. Session-misdating bug (Batch 1 §5) reproduced on the majority of this batch, not just A-level

Checked directly: GCSE Biology (1BI0) is dated "Tuesday 16 May 2023", A-level Business (9BS0) "Tuesday 23 May 2023", A-level Geography (9GE0) "Wednesday 17 May 2023" — all genuine June-2023-series papers dated in May, none containing the word "june" or "summer" anywhere on the cover. 7 of this batch's 10 subjects landed in a generic `UNKNOWN_2023` session folder rather than `June_2023` for this reason (only Biology B's QP happened to land in `June_2023`, because its actual printed date is in June). **This confirms the May-dating problem is the norm for Edexcel's Summer series, not an edge case** — it affected the majority of subjects in both batches combined.

## 5. Orphaned mark schemes (Batch 1 §3) reproduced

31 of this batch's 32 total delivered "packs" are MS-only orphans under the `EDEXCEL/UNKNOWN/June_2023/` bucket, flagged `MISSING_QP`, with no matching question content — the same pattern as Batch 1 §3, at an even higher rate (31/32 = 97%, versus Batch 1's 26/49 = 53%) because this batch has zero clean-segmentation subjects to anchor any packs at all.

## 6. Net result for Batch 2

**0 of 10 subjects (0%) produced any usable question content.** The one non-empty result (Biology B) is actively harmful rather than merely incomplete: a single mislabeled mega-pack spanning the whole paper, tagged with a topic from a different subject entirely, flagged as missing its mark scheme. Combined with Batch 1, **Edexcel's two real-paper batches so far have a combined content-yield rate of 2 of 23 subjects (~9%)** — both of those 2 being Mathematics-family papers that happen to share the one paper's numbering style the adapter was built against.

## 7. What was not attempted

- No code fix was made for any of the defects carried over from Batch 1 or newly characterized here (the mega-segment/single-stray-match failure mode in §2, in particular, was not previously known and is not fixed).
- The `decision_discrete` mistagging in §2 was not traced into the topic classifier's logic; it's recorded here as an observed symptom, not root-caused.
- No further Edexcel batches (the remaining 20 Group-B/2024+ subjects) should be attempted until the `_Q_START` regex defect is fixed. Both batches run so far show the defect is universal across every non-Mathematics Edexcel subject tested (21 of 23 subjects, 91%), so repeating this on Group B would almost certainly just document the identical failure another 20 times with no new information.
