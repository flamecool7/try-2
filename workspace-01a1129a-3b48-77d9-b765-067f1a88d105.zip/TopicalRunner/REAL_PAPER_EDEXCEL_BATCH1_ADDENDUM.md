# Real-Paper Validation Addendum — Edexcel Batch 1 (13 subjects)

**Status: this is Edexcel's first-ever real-paper test in this repository. Result: catastrophic — 11 of 13 subjects (85%) produced ZERO usable question content, due to a single root-caused regex defect, compounded by three further independent bugs. Read this before trusting ANY Edexcel output.**

## 0. Why this matters more than a normal batch

`config/boards/edexcel.yaml` states explicitly that the Edexcel adapter has been verified against exactly **one** real PDF in this repo's history: `P61181A_9FM0_3C.pdf` (Further Mathematics, Paper 3C), and that "No real Edexcel PDF exists in this repository → content signatures are SOURCE_NOT_FOUND for verification" for everything else. This batch is the first time the adapter has ever been pointed at real Edexcel papers outside that one anchor document, across 13 different subjects. The results below confirm the risk that single-paper validation implied: the adapter's core segmentation logic is effectively hardcoded to the formatting of that one Mathematics-family paper and fails on everything else.

## 1. Scope and sourcing

Batch 1 = 13 of Edexcel's 44 total subjects (the "Group A" subset with pre-2024 `syllabus_years`), June 2023 session, Paper 1 (or the sole Paper-1-equivalent component):

| Subject | Code | Source |
|---|---|---|
| Biology A (Salters-Nuffield), A-level | 9BN0/01 | PMT direct mirror |
| Chemistry, A-level | 9CH0/01 | PMT direct mirror |
| Physics, A-level | 9PH0/01 | PMT direct mirror |
| Mathematics, A-level (Pure 1) | 9MA0/01 | PMT direct mirror |
| Further Mathematics, A-level (Core Pure 1) | 9FM0/01 | PMT direct mirror |
| Economics A, A-level | 9EC0/01 | PMT direct mirror |
| Politics, A-level | 9PL0/01 | revisionworld.com direct mirror |
| Psychology, A-level | 9PS0/01 | PMT direct mirror |
| English Language, GCSE | 1EN0/01 | PMT direct mirror |
| Physics, GCSE (Higher tier) | 1PH0/1H | PMT direct mirror |
| Biology, IGCSE | 4BI1/1B | PMT direct mirror |
| Chemistry, IGCSE | 4CH1/1C | PMT direct mirror |
| Physics, IGCSE | 4PH1/1P | PMT direct mirror |

All 26 PDFs (13 QP + 13 MS) were verified to have valid `%PDF` headers before use. The pipeline itself ran cleanly with no crashes, no OOM, and no exceptions — `tools/run_universal_batch.py` reported a superficially healthy top-line summary: `render_pass: 13/13`, `companion_pass: 11/13`, `question_packs: 49`. **That summary is misleading; see §2.**

## 2. The dominant bug: question-numbering regex requires a literal "." that real Edexcel papers mostly don't print

`adapters/edexcel/adapter.py` segments questions using:

```python
_Q_START = re.compile(r"(?:^|\n)\s*(\d{1,2})\.\s+")
```

This requires the question number to be followed immediately by a period and whitespace — e.g. `"1. Find..."`. Inspecting the actual extracted text of the real papers:

- **Mathematics 9MA0 and Further Mathematics 9FM0** print `"1.\t Find..."` — number, period, tab. **Matches.**
- **Every other subject in this batch** prints `"1\t Homo sapiens..."`, `"1\t In your studies of social psychology..."` — number, tab, **no period at all.** Confirmed directly against the extracted PDF text for Biology A, Chemistry, Economics A, Psychology, Politics, Physics, English Language, GCSE Physics, and all three IGCSE subjects. **Does not match.**

Result: `segments.json` is an empty list `[]` for 11 of the 13 question papers. Zero questions were cropped. Only Mathematics (15/15 questions, Q1–Q15) and Further Mathematics (8/8 questions, Q1–Q8) produced real output — and those two are, not coincidentally, the only subjects in the batch that share the exact numbering convention of the one paper (`9FM0/3C`) the adapter was ever built and verified against.

**The pipeline does not flag this as a failure.** Every one of the 11 empty-segment QPs has a `contract_report.json` reading `{"status": "PASS", "issues": []}`. The batch-level summary's `render_pass: 13/13` only means the PDF pages rendered without crashing — it says nothing about whether any question was actually found. The real content-yield rate for this batch is **2 of 13 subjects (~15%)**, not the "13/13" and "11/13" numbers the run summary advertises.

## 3. Orphaned mark-scheme crops: a second, compounding defect

Mark-scheme segmentation uses different, more permissive logic than question-paper segmentation, so all 13 MS documents still produced webp crops (156 webps total across the batch) — including the 11 MS files whose sibling QP found no questions at all. Because there is no QP to attach them to, the pack assembler files these under `MISSING_QP` + `TOPIC_UNKNOWN`:

- 23 such orphan packs land in a board-level catch-all `EDEXCEL/UNKNOWN/June_2023/` folder (covering Biology A, Chemistry, Economics A, Physics, Politics, GCSE Physics, and all 3 IGCSE subjects' mark schemes).
- 3 more orphan packs land under `EDEXCEL/9PS0_01/June_2023/` (Psychology) — correctly bucketed by subject, still `MISSING_QP`.

**That is 26 of the batch's 49 total delivered "packs" (53%) that are a lone mark-scheme crop with no matching question text and no topic** — easy to mistake for real output if browsing the folder tree without checking `pack_index.json`.

Worse, spot-checking one orphan crop (`UNKNOWN/June_2023/MS/Edexcel-9BN0-01-MS-JUN23/..._Q4_MS_p1of2.webp`, Biology A) shows its **filename label (`Q4`) does not match its visible content** — the crop actually shows mark-scheme rows for a later question (visible heading `"7(b)(iii)"`). With no real QP boundaries to anchor against, the MS-only segmenter's page-slicing produces crops whose question-number label is simply wrong.

## 4. Subject-identification regex has its own, independent blind spot — and it swallowed English Language whole

`adapters/edexcel/adapter.py`'s component regex:

```python
_COMPONENT = re.compile(r"\b([0-9][A-Z]{2,3}[0-9])\s*/\s*([0-9][A-Z]{0,2})\b")
```

was tested directly against every code in this batch. It **matches** codes whose second half ends in a letter (`9PH0/1H` → `('1PH0','1H')`, `4BI1/1B`, `4CH1/1C`, `4PH1/1P` — the GCSE/IGCSE tiered papers), but **fails to match any code whose second half is purely numeric** (`9FM0/01`, `9MA0/01`, `9BN0/01`, `9CH0/01`, `9EC0/01`, `9PH0/01`, `9PL0/01`, `9PS0/01`, `1EN0/01` — every A-level paper in this batch, plus English Language GCSE). The cause is a trailing `\b` word-boundary assertion that can never be satisfied once the `{0,2}` letter-quantifier backtracks to zero letters against a second all-digit group — confirmed by isolated regex testing.

All the A-level subjects were rescued anyway by an entirely separate legacy fallback in `adapters/associations.py` (`_identify_edexcel`), whose own regex (`\b(9[A-Z0-9]{3}\s*/\s*[0-9A-Z]+\b`) happens to work for a different structural reason — but **only because it hardcodes a requirement that the syllabus code start with "9"**. GCSE/IGCSE codes starting with `1`/`4` get no such rescue.

**English Language GCSE (1EN0/01) falls into neither regex's coverage** — pure-numeric suffix (fails the adapter regex) and does not start with "9" (fails the associations fallback). Result: its QP was never assigned a subject at all, and landed entirely inside the generic board-level `EDEXCEL/UNKNOWN/` bucket, indistinguishable in the folder tree from the orphaned mark-scheme debris of unrelated subjects. This is a real, demonstrated gap that will recur for any future Edexcel GCSE/IGCSE subject whose paper code doesn't happen to end in a tier letter and doesn't start with "9" (e.g. likely candidates in later batches: `Biology_1BI0`, `Chemistry_1CH0`, `Mathematics_4MA1`/`4MB1` if their Paper-1 components use a plain `/01` suffix — not yet checked).

## 5. Session identification assumes "Summer 2023" papers are literally dated in June — several real ones are dated in May

`identify_session()` only assigns a "June" session if an alias token (`june`, `summer`, etc., min length 3) is found literally printed on the cover. But several real Pearson "Summer 2023" series papers are dated in **May**, and never print the word "summer" either — only an exact weekday + calendar date:

- Physics 9PH0/01 — "Wednesday 24 May 2023"
- Politics 9PL0/01 — "Tuesday 23 May 2023"
- Further Mathematics 9FM0/01 — "Thursday 25 May 2023"
- Economics A 9EC0/01 — "Thursday 18 May 2023"

None of these cover pages contain "june" or "summer" anywhere in the extracted text, so all four get bucketed into a generic `UNKNOWN_2023` session folder instead of `June_2023` — **even though they are the same real-world exam series as the June-dated Biology A, Chemistry, Mathematics, and Psychology papers in this same batch.** This fragments same-series documents across two different session directories (confirmed: `9PL0_01/June_2023/MS/` exists alongside a separate `9PL0_01/UNKNOWN_2023/QP/` for the same subject and series) and will misalign any pack assembly or reporting that assumes QP/MS/session alignment by folder name alone.

## 6. Topic classification fails on nearly half of the only real content produced

Even restricting to the 2 subjects where segmentation actually worked:

- **Further Mathematics (9FM0):** 8 packs total, 4 correctly topic-classified (`calculus`, `coordinate_geometry_vectors`, `pure_algebra_functions`), **4 routed to `TOPIC_UNKNOWN` (50%)**.
- **Mathematics (9MA0):** 15 packs total, 9 correctly classified, **6 routed to `TOPIC_UNKNOWN` (40%)**.

## 7. Cosmetic/provenance bug: hardcoded segment IDs

Every segment's `id` field in `segments.json` is literally `"3C_Summer_2019_Q{n}"` regardless of the real subject, component, or session — a leftover from the single anchor paper (`9FM0/3C`, Summer 2019) the adapter's `segment()` method was built against. It does not affect crop correctness, but it means the segment ID can never be trusted as provenance metadata — confirmed present in both working subjects (Mathematics and Further Mathematics output).

## 8. What did work, and was verified clean

The only two subjects with real output — Mathematics 9MA0/01 (15/15 questions, Q1–Q15, sequential with no gaps) and Further Mathematics 9FM0/01 (8/8 questions, Q1–Q8) — were spot-checked visually. Q1 of each (a Pure Mathematics integration question and a Further Pure cubic-roots-transformation question respectively) rendered as clean, correctly-cropped, legible question images with no AQA-style top-cut or margin-bleed defects. Where the Edexcel adapter's segmentation succeeds at all, crop geometry quality appears sound — the problem in this batch is almost entirely about whether a question boundary is *found* in the first place, not how it's cropped once found.

## 9. Per-subject summary table

| # | Subject | Code | QP segments found | MS crops | Verdict |
|---|---|---|---|---|---|
| 1 | Biology A, A-level | 9BN0/01 | **0** | 2 (orphaned, mislabeled — §3) | **Unusable — total QP loss (§2)** |
| 2 | Chemistry, A-level | 9CH0/01 | **0** | 5 (orphaned) | **Unusable — total QP loss (§2)** |
| 3 | Physics, A-level | 9PH0/01 | **0** | 7 (orphaned) | **Unusable — total QP loss (§2); also session-fragmented (§5)** |
| 4 | Mathematics, A-level | 9MA0/01 | **15/15** | 31 (complete) | Questions usable, visually clean (§8); 6/15 topic UNKNOWN (§6); hardcoded segment ID (§7) |
| 5 | Further Mathematics, A-level | 9FM0/01 | **8/8** | 17 (complete) | Questions usable, visually clean (§8); 4/8 topic UNKNOWN (§6); session-fragmented (§5); hardcoded segment ID (§7) |
| 6 | Economics A, A-level | 9EC0/01 | **0** | 4 (orphaned) | **Unusable — total QP loss (§2); also session-fragmented (§5)** |
| 7 | Politics, A-level | 9PL0/01 | **0** | 2 (orphaned) | **Unusable — total QP loss (§2); also session-fragmented (§5)** |
| 8 | Psychology, A-level | 9PS0/01 | **0** | 3 (orphaned, correctly bucketed by subject) | **Unusable — total QP loss (§2)** |
| 9 | English Language, GCSE | 1EN0/01 | **0** | 2 (orphaned, **subject never identified at all — §4**) | **Unusable — total loss, including subject identity (§4)** |
| 10 | Physics, GCSE (Higher) | 1PH0/1H | **0** | 7 (orphaned) | **Unusable — total QP loss (§2)** |
| 11 | Biology, IGCSE | 4BI1/1B | **0** | 6 (orphaned) | **Unusable — total QP loss (§2)** |
| 12 | Chemistry, IGCSE | 4CH1/1C | **0** | 5 (orphaned) | **Unusable — total QP loss (§2)** |
| 13 | Physics, IGCSE | 4PH1/1P | **0** | 6 (orphaned) | **Unusable — total QP loss (§2)** |

**Net: 11 of 13 subjects (85%) are completely unusable — zero real question content delivered, despite the pipeline reporting a "PASS" status and a healthy-looking top-line summary for all of them. Of the 2 subjects that did produce real output, both have a 40–50% topic-classification failure rate and a hardcoded/incorrect provenance field. Zero of the 13 subjects in this batch are fully clean. This is substantially worse than every AQA batch run in this repository, including AQA Batch 3 (which had a 4/13 total-loss rate against this batch's 11/13).**

## 10. What was not attempted

- **No code fix was made** for the `_Q_START` dot-only regex (§2), the MS-orphan mislabeling (§3), the `_COMPONENT` pure-numeric blind spot or its associations.py fallback gap (§4), the May-dated-session misbucketing (§5), the topic-classifier gap (§6), or the hardcoded segment-ID string (§7). All are disclosed here, not repaired.
- The MS-orphan mislabeling (§3) was confirmed by spot-checking exactly one crop (Biology A, `Q4_MS_p1of2`); it was not checked across all 26 orphan packs. Treat every orphan MS crop's question-number label as unverified.
- Whether the `_COMPONENT` regex blind spot (§4) affects other, not-yet-sourced Edexcel GCSE/IGCSE subjects whose Paper-1 code ends in a plain `/01` was not tested — only inferred from the regex's structure. This should be checked before running future Edexcel batches.
- No attempt was made to re-source the 11 failed subjects from a different session to see if a different year's paper happens to use dot-formatted numbering — the evidence (the regex is literally checking for a specific punctuation character that most of Pearson's own house style doesn't use) strongly suggests the failure is systemic to the adapter, not specific to the June 2023 printing, but this was not independently tested against another session.
- Batch 2 (the remaining 11 Group-A Edexcel subjects) and Batches for Group-B (2024+ syllabus) subjects were not started. Given the severity of the `_Q_START` defect found here (it will almost certainly reproduce identically on every non-Mathematics Edexcel subject, since the bug is in the adapter's core numbering regex, not anything subject-specific), further Edexcel batches should wait for this defect to be fixed/reported upstream rather than repeating the same failure 30+ more times across the remaining 31 subjects.
