# Real-Paper Validation Addendum — SAT / College Board Batch 1 (3 test forms)

**Status: this is the strongest result of any board tested so far (AQA, Edexcel, IB) — when the SAT adapter renders a question, the output is genuinely correct, well-cropped, single-question content. But a rendering-stage defect silently drops 3 of every 4 modules on every paper, so only ~27.5% of each test's actual questions (the first module only) ever reach the deliverable output, despite the question-identification stage correctly locating all of them. Separately, every Scoring Guide and Answer Explanations document in this batch was misclassified or dropped, so no paper in this batch ever got paired with real answer content.**

## 0. Sourcing

Unlike IB, College Board freely and officially publishes full practice tests, scoring guides, and answer explanations with no login or paywall, directly from `satsuite.collegeboard.org` — the cleanest sourcing situation of any board tested in this project. Three test bundles (9 PDFs total: question paper + scoring guide + answer explanations for each) were downloaded directly via `curl`, all HTTP 200, all `%PDF`-verified:

| Bundle | Program | Files |
|---|---|---|
| SAT Practice Test 4 (Digital) | SAT | QP, Scoring Guide, Answer Explanations |
| PSAT 10 Practice Test 1 | PSAT 10 | QP, Scoring Guide, Answer Explanations |
| PSAT 8/9 Practice Test 1 | PSAT 8/9 | QP, Scoring Guide, Answer Explanations |

`config/boards/sat.yaml` states the adapter was previously "independently VERIFIED on both real PSAT papers" — understood to mean PSAT/NMSQT, a fourth program not re-tested here. This batch deliberately covers three programs that configuration doesn't claim were already validated (SAT itself, PSAT 10, PSAT 8/9), to extend real-paper coverage rather than repeat it.

## 1. When it works, it really works: genuinely correct single-question crops

Spot-checking Question 1 from both correctly-identified question papers shows real, clean, single-question content:
- **PSAT 8/9 Practice Test 1, Q1**: a complete, correctly-cropped probability question about selecting buttons from a bag, with all four answer choices, a clear "1" badge, and no bleed from neighboring questions.
- **SAT Practice Test 4, Q1**: a complete, correctly-cropped line-graph data question about estimated chipmunk populations, again cleanly isolated with the question badge and no bleed.

This is a materially better baseline than anything found in the Edexcel or IB batches: the underlying crop-box geometry and question-boundary detection for SAT content, when it actually runs, produces exam-ready output. This matters for interpreting the defects below: they are not "the SAT adapter is broken the way the Edexcel one is" — they are specific, narrower pipeline-stage failures layered on top of a working core.

## 2. The big defect: only the first of four modules per paper ever gets rendered

Both the SAT and PSAT Suite tests are structured as two sections (Reading and Writing, Math), each delivered in two modules — four modules total, documented in the SAT adapter's own config as `RWM1 / RWM2 / MATHM1 / MATHM2`. Inspecting `segments.json` for SAT Practice Test 4 directly shows the **text-based segmentation stage works correctly across the whole paper**: all 120 questions are present, correctly numbered 1–33 / 1–33 / 1–27 / 1–27 within their four modules (`PSAT_RWM1_Practice_Q1` ... `PSAT_MATHM2_Practice_Q27`), each with a correct page reference.

But only **33 of those 120 segments** — exactly the Reading and Writing Module 1 questions — were ever rendered into an actual `.webp` image file. Reading and Writing Module 2 (33 questions), Math Module 1 (27 questions), and Math Module 2 (27 questions) are fully identified in `segments.json` but have **zero corresponding image files anywhere in the output**. The same pattern reproduces identically on PSAT 8/9 Practice Test 1 (33 of what should be a larger total rendered). This matches the batch-level stats exactly: `render_attempts: 6, render_fail: 3` — half of the rendering work silently failed across this batch, and in both cases, the failure consistently took out modules 2–4 while leaving module 1 intact. **Net effect: roughly 72.5% of each test's real question content is correctly located by the pipeline but never reaches the deliverable.**

## 3. Document-type identification is effectively non-functional beyond the board-level signature

Both files that are plainly **Scoring Guides** (`PSAT10_PracticeTest1_Scoring.pdf`, `PSAT89_PracticeTest1_Scoring.pdf`) were classified `document_type: QP` with confidence 0.9, evidence `["SAT:board_signature@0.90", "identified via SAT adapter"]` — the identical evidence a real question paper gets. They were filed inside `QP/` folders and partially segmented as if they were question papers. `config/boards/sat.yaml` explicitly defines a `SCORING_GUIDE` document type (tokens: `"scoring guide"`, `"scoring"`, `"score table"`, `"conversion table"`, marked `verified: true`) — this type is configured but evidently never checked by the identification code.

Separately, all three **Answer Explanations** PDFs — the real, official solution documents, confirmed by direct inspection to contain genuine per-question worked answers (e.g. "Choice B is the best answer because...") — were classified `document_type: UNKNOWN` and dropped entirely; none of the three appear anywhere in the final output. `config/boards/sat.yaml` also explicitly defines `SOLUTION_EXPLANATION` (tokens: `"answer explanations"`, `explanations`, `"answer explanation"`, marked `verified: true`) for exactly this document — again, configured but not implemented. Across this entire 9-file batch, `companion_attempts: 0`: not once did the pipeline even attempt to pair a question paper with any form of answer content, because no document was ever correctly recognized as carrying answers.

## 4. Program identification is unreliable, including a cross-program misfile

`PSAT10_PracticeTest1_QP.pdf` — plainly a PSAT 10 paper (filename, and the source URL itself: `.../psat-10-practice-test-1.pdf`) — was classified under component `PSAT_NMSQT_T1`, a different College Board program with its own distinct administration rules (PSAT 10 is given to 10th-graders in school; PSAT/NMSQT is the 11th-grade National Merit-qualifying exam). The questions that do render under this misfiled identity are real PSAT content, but a student or analyst would be told it's the wrong program.

A second, stranger misfile: the Scoring Guide for **SAT** Practice Test 4 (an SAT document, not a PSAT at all) was filed under component `PSAT_8_9_T4` — crossing both the program boundary (SAT vs. PSAT 8/9) and carrying through a `T4` test-number tag for a program (PSAT 8/9) that never had a "Test 4" sourced in this batch. This suggests the component-identification fallback logic, once it fails to find real brand/program evidence in a given file (as happens for anything that isn't a clean QP), defaults toward a generic "PSAT_8_9" guess rather than correctly reporting UNKNOWN.

## 5. A revealing cosmetic bug: every segment ID says "PSAT" even for real SAT documents

Every segment produced from `SAT_PracticeTest4_QP.pdf` — an actual full-length **SAT**, not a PSAT — is internally named with the literal prefix `PSAT_` (e.g. `PSAT_RWM1_Practice_Q1`). This is a strong signal that the segmenter's internal naming logic was built and tested exclusively against PSAT fixtures (consistent with `config/boards/sat.yaml`'s own claim of prior validation "on real PSAT papers") and never updated to branch on the actual program when the source is a plain SAT. It is cosmetic — it doesn't affect which pixels get cropped — but it is one more sign that this adapter's "verified" status describes PSAT specifically, not the SAT Suite as a whole.

## 6. Aggregate result for this batch

- Of 9 source files, only 2 (SAT Practice Test 4 QP, PSAT 8/9 Practice Test 1 QP) were both correctly typed as QP and correctly placed under a plausible program/identity, and even those two only surfaced 33 of ~120 and 33 of (a larger, unverified total) real questions respectively — the other modules are lost.
- 1 of 9 files (PSAT 10 QP) produced real, well-formed content but under the wrong program name.
- 2 of 9 files (the two Scoring Guides) were misclassified as question papers and partially, spuriously segmented.
- 3 of 9 files (all three Answer Explanations) were dropped entirely as `UNKNOWN`.
- `ms_segments: 0`, `companion_attempts: 0` for the whole batch — no paper in this batch was ever paired with real answer content.
- Where content did render, visual quality is genuinely good — better than any other board tested in this project to date.

## 7. What was not attempted

- No code fix for the module-2-4 render dropout (§2), the Scoring-Guide/QP confusion or Answer-Explanations UNKNOWN-drop (§3), the PSAT 10 / PSAT-NMSQT program confusion (§4), or the PSAT-prefix segment-naming bug (§5).
- The exact cause of the render dropout was not traced into the renderer code; it was confirmed only at the evidence level (`segments.json` has 120 correct entries, only 33 images exist, `render_fail: 3` of 6 attempts matches).
- PSAT/NMSQT itself (the program `config/boards/sat.yaml` claims was already used to validate this adapter) was not re-tested in this batch, to avoid duplicating prior validation; a useful next step would be re-running that specific program to check whether the module-render dropout found here (§2) also affects the paper the adapter was originally tuned on, or is specific to the three programs tested here.
- The SAT Practice Essay materials (a separate, optional document type) were not sourced or tested in this batch.
