# Real-Paper Accuracy — Batch 3 Addendum (13 New CAIE Subjects)

**Status: Batch 3 complete. This ADDS to, and does not replace, Phase 1
(`REAL_PAPER_ACCURACY_REPORT.md`, 80/80 questions, 5 subjects) or Phase 2
(`REAL_PAPER_BATCH2_ADDENDUM.md`, 104/104 questions, 8 subjects).**

## 0. Why this batch exists

The user asked for real-paper testing to be extended to the ~200 subject
configurations that had never been checked against a real PDF (only 8 CAIE
subjects had been hand-verified before this). Full hand-verification of all
200 to Phase 1/2 depth is a multi-day effort and was explicitly **not**
claimed to be finished in one sitting. This batch is the first concrete slice
of that larger effort: **13 brand-new CAIE subjects, chosen to maximize
diversity of taxonomy style** (pure-STEM numeric answers, structured business
case-studies, programming/pseudocode, multi-science, social-science essays).

| Level | Subjects added this batch |
|---|---|
| IGCSE | Mathematics 0580, Economics 0455, Accounting 0452, Business Studies 0450, Computer Science 0478, Additional Mathematics 0606, Combined Science 0653 |
| A-Level | Business 9609, Accounting 9706, Psychology 9990, Sociology 9699, Computer Science 9618, Geography 9696 |

All 26 source PDFs (QP+MS per subject) are genuine Winter 2023 (`w23`) past
papers downloaded from `pastpapers.papacambridge.com`, variant 22 (Combined
Science 0653 used variant 42), verified as real multi-page PDFs (4–38 pages,
255KB–2.4MB) before use.

The pipeline ran end-to-end (`python3 main.py --input input/batch3 --output
output/batch3_run`) and finished **ALL GREEN — 32 stages, 145 checks passed**,
extracting and classifying **105 real exam questions** across 13 papers / 13
subject-level contexts.

---

## 1. Result: manual domain review of all 105 questions

Every classification was manually checked against the real question text,
diagram evidence, and (where available) mark-scheme topic hits — the same
rigor as Phase 1/2, not a sampled spot-check.

| Outcome | Count | % |
|---|---:|---:|
| **Correct** (after fixes below) | 99 | 94.3% |
| **Disclosed near-tie** (genuinely multi-topic question — e.g. CAIE Economics/Business/Computer-Science data-response questions that legitimately span several syllabus areas in one structured question; the system's single "major" pick is defensible even though a human grader could reasonably favor a different one of the listed `detailed_topics`) | 4 | 3.8% |
| **Disclosed limitation** — forced full-auto default on content with no real keyword evidence (short/garbled extracted text, or content that doesn't map cleanly to any of the subject's official topic names) | 2 | 1.9% |

Three genuine, real bugs were found and fixed during this review (§2). After
the fixes, **99/105 (94.3%) are unambiguously correct**, 4/105 are disclosed
near-ties on legitimately mixed-topic questions, and 2/105 are a known,
pre-existing "full-auto never abstains" design tradeoff applied to two
particularly thin/garbled Additional Mathematics 0606 questions — not treated
as hidden failures.

---

## 2. Bugs found and fixed this batch

All three fixes were diagnosed by direct code/keyword inspection and a
reproduction script against the real extracted question text before editing,
and none was accepted without re-running the full golden set (2056 entries)
and pytest suite (105 tests) immediately after — both stayed at **2056/2056
(100%)** and **105/105** after every fix, confirming zero regressions.

1. **Unicode dash mismatch in the Mathematics routing engine
   (`core/math_reference.py`) — systemic, not subject-specific.**
   Cambridge PDF text extraction renders compound-word dashes as a Unicode
   **en dash** (`–`, U+2013), e.g. `"speed–time graph"`, while the
   hard-coded phrase-bonus lists for 0580/0606/9709/9231 Mathematics routing
   used the plain ASCII hyphen (`"speed-time graph"`). The two strings never
   matched, so questions correctly described by a dashed phrase lost that
   evidence entirely and fell through to a generic/default topic. Found via
   IGCSE Mathematics 0580 Q12 (a speed–time graph question, misrouted to
   `Number` instead of `Algebra_and_graphs`). **Fix:** added a
   `_normalize_dashes()` helper (collapses en dash/em dash/other Unicode dash
   variants to `-`) and applied it in the two shared matching primitives
   (`_score_text_against`, `_apply_phrase_bonuses`) used by every Mathematics
   routing function (9709, 0580, 0606, 9231) — a single, low-risk, systemic
   fix rather than a one-off patch for just the failing phrase.

2. **IGCSE Mathematics 0580 — basic calculus (differentiation) had zero
   keyword coverage.** Confirmed against the real 2023–2024 syllabus
   (Cambridge topic "Algebra and graphs", sub-strand E2.11) that introductory
   differentiation belongs under the `Algebra_and_graphs` bucket in this
   config's 9-topic structure, but no keyword list anywhere in
   `core/math_reference.py` contained `"derivative"`, `"differentiate"`, or
   related terms. Found via 0580 Q25 ("The derivative of ax² + 3/x^k is
   42x − 15/x⁶ ... find a and k"), misrouted to `Number`. **Fix:** added
   `derivative(s)`, `differentiate/differentiates/differentiated
   /differentiating/differentiation`, `dy/dx`, `rate of increase/decrease` to
   the `Algebra_and_graphs` phrase-bonus list.

3. **A-Level Geography 9696 — `Urban_trends_and_issues` keyword list only
   matched technical vocabulary ("squatter", "informal settlement"), not the
   plain descriptive language real exam questions actually use.** Found via
   9696 Q3, a photo-interpretation question about "a residential area in
   Manila" and "problems for people living in the area" with no technical
   settlement jargon at all — it was misrouted to `Core_Human_Population`
   (a flat, forced 0.25-confidence default) instead of
   `Core_Human_Settlement_dynamics`. **Fix:** added `"residential area"`,
   `"suburban"`, `"suburbs"`, `"housing problems"` to
   `subjects_caie/A-Level/Geography_9696/config.json`'s
   `Urban_trends_and_issues` keyword list — verified via
   `tools/classify_text.py` to raise this question from confidence 0.25
   (wrong topic) to confidence 1.0 (correct topic) without touching any other
   topic's keywords.

---

## 3. Disclosed near-ties (not bugs)

Consistent with the Phase 2 precedent, several CAIE structured/data-response
papers (Economics 0455, Business 9609, Computer Science 9618) contain single
questions with multiple lettered sub-parts that legitimately test 3–5
different syllabus topics in one question (this is normal CAIE exam design,
not a system weakness). In these cases the system's `detailed_topics` list
correctly captures the breadth, and the single "major" pick is a defensible
judgment call rather than a wrong answer; confidence on these sits in the
0.25–0.72 range by design (the system is correctly signalling ambiguity,
not confidently wrong).

## 4. Disclosed limitation (not fixed): forced full-auto default on
   no-evidence text

Two IGCSE Additional Mathematics 0606 questions (Q3: a cylinder-volume/surd
"find the exact value" question; Q6: a definite-integral question whose
integral sign extracted as a stray character) produced **zero real keyword
matches** against any of the 14 official 0606 topic names — Q3 tests a
foundational surds/indices skill that isn't tied to any one of the 14 named
topics, and Q6's key evidence (the integral sign, "dx") was lost to PDF
text-extraction noise. The classifier's full-auto mode is designed to *never*
return `REVIEW_REQUIRED` and instead fall back to a syllabus-order default
topic — both were flagged with the system's own `auto_forced` / flat
`major_scores` signal, which is honest about the fact that they are guesses.
This is a pre-existing architectural tradeoff (full automation vs.
occasionally abstaining), not a new bug introduced by this batch, and is
disclosed here rather than silently left in the "correct" count.

---

## 5. Cumulative real-paper evidence after Batches 1–3

| Phase | Subjects | Questions reviewed | Correct/defensible |
|---|---:|---:|---:|
| Phase 1 | 5 | 80 | 80/80 (100%) |
| Phase 2 | 8 | 104 | 102/104 (98.1%, 2 attributable to a disclosed MS-splitting pipeline defect in one paper) |
| Phase 3 (this batch) | 13 | 105 | 103/105 (98.1%, 2 disclosed full-auto forced-default edge cases) |
| **Total** | **21 unique CAIE subjects** (some reused across sessions) | **289** | **285/289 (98.6%)** |

**Still outstanding** (explicitly not claimed as tested): 65 more untested
CAIE subjects, and all of AQA (46), Edexcel (44), IB (30), and SAT (2) — 187
configs remain unverified against real papers. This is reported honestly as
incremental progress, not completion of "the other 200 subjects."
