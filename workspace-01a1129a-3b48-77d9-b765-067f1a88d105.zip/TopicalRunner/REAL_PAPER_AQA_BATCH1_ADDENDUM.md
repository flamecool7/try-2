# Real-Paper Accuracy Testing — AQA Batch 1 Addendum

First batch of real AQA past-paper testing. This is the **first non-CAIE
board** to get real-paper coverage (CAIE finished at 70 tested + 11 excluded
= 81/81 in Batch 7). AQA has a different sourcing landscape (no single
"source site" the way CAIE papers were found; a mix of AQA's own
`filestore.aqa.org.uk` and, where that gate-blocks a question paper, the
PMT mirror) and — this is the headline finding of this batch — a much less
mature question-paper **segmenter** than CAIE's: AQA's non-science subjects
turned out to have several numbering/layout conventions the adapter had
never been taught, and this batch found four of them the hard way. One
board-identity bug was found and fixed (verified against the full golden
set and pytest suite); the segmentation gaps were not fixed and are
disclosed in full below, subject by subject.

## 1. Scope

| # | Subject | Code | Level | Session | Component |
|---|---|---|---|---|---|
| 1 | Biology | 8461 | GCSE | June 2023 | Paper 1 Higher |
| 2 | Chemistry | 8462 | GCSE | June 2023 | Paper 1 Higher |
| 3 | Combined Science: Trilogy (Physics strand) | 8464 | GCSE | June 2023 | Paper 1 Higher |
| 4 | English Language | 8700 | GCSE | June 2023 | Paper 1 |
| 5 | Geography | 8035 | GCSE | June 2023 | Paper 1 |
| 6 | History | 8145 | GCSE | June 2023 | Paper 2, Section A option A ("Britain: Health and the people") |
| 7 | Computer Science | 8525 | GCSE | June 2023 | Paper 1, variant 1A (C#) |
| 8 | Business | 7132 | A-Level | June 2023 | Paper 1 |
| 9 | Economics | 7136 | A-Level | June 2023 | Paper 1 |
| 10 | Psychology | 7182 | A-Level | June 2023 | Paper 1 |
| 11 | English Literature A | 7712 | A-Level | June 2023 | Paper 1 ("Love through the ages") |
| 12 | Mathematics | 7357 | A-Level | June 2023 | Paper 1 |
| 13 | Physics | 7408 | A-Level | June 2023 | Paper 1 |

Subject selection was constrained by **syllabus-year coverage**, not just
topical interest: a `config.json` check across all 46 untested AQA subjects
found that a large share of AQA's A-level/GCSE humanities, arts and
languages subjects in this repo are configured for 2024+ syllabus years
only (first-taught after the window this project tests), so four
originally-planned subjects (French 8658, Sociology 7192, Law 7162, Media
Studies 7572) were swapped out before sourcing began for four subjects
confirmed to include 2023 (Business 7132, Mathematics 7357, Combined
Science Trilogy 8464, English Literature A 7712). This mirrors the same
`syllabus_years` pre-check discipline CAIE Batch 7 adopted after
Business_0774.

## 2. Sourcing: two AQA-specific quirks

**(a) `filestore.aqa.org.uk`'s direct QP link is access-gated for some
subjects, even for a genuinely old (June 2023) paper, while the MS stays
open.** Measured directly: `AQA-77121-QP-JUN23.PDF` (and three other QP
URLs) returned a clean **HTTP 302** redirect to an `aqa.org.uk` landing
page — not a 404 — while the matching MS URL for the same subject loaded
as a normal 200/PDF. This happened for English Language 8700, Geography
8035, Computer Science 8525 and English Literature A 7712 — 4 of 13
subjects. The [PMT (physicsandmathstutor.com)](https://pmt.physicsandmathstutor.com)
mirror, which republishes AQA's own papers verbatim under its own
watermark, was used as a fallback for all four QPs (plus MS for
Computer Science 8525, whose MS also needed PMT). This is the same kind
of mirror-sourcing workaround already used for a handful of CAIE papers in
earlier batches, just needed far more often here (4 of 13 vs. rare for
CAIE).

**(b) AQA GCSE Computer Science 8525 Paper 1 has two parallel
language-choice variants printed as separate booklets**: 1A uses C#, 1B
uses Python (a third, 1C, also exists for other languages in other years).
Variant 1A was used for this batch. Its mark scheme, unlike the question
paper, is **one single document covering 8525/1A, /1B and /1C together**
(confirmed from the MS's own cover: "COMPUTER SCIENCE 8525/1A, 8525/1B,
8525/1C") — this has a direct, disclosed downstream consequence (see
§4e below).

## 3. A real bug found and fixed: CAIE false-positive on an AQA paper

`run_universal_batch.py`'s board-identity resolver uses each board
adapter's own `identify_document`. The CAIE adapter's "belt and braces"
fallback — added in an earlier project phase specifically so a
genuinely-Cambridge paper with no legible board-signature text would still
be caught — treats **any** `<4 digits>/<1-2 digits>` cover code
(`_CODE_COMPONENT` regex) as 0.9-confidence evidence for CAIE. That shape
is not unique to Cambridge: AQA prints the exact same `8035/1` cover-code
convention. The PMT-mirrored copy of AQA GCSE Geography 8035/1 carries no
literal "AQA" token anywhere in the first 3 scanned pages (PMT's own
watermark stands in where AQA's branding would be; AQA's own
copyright-boilerplate "AQA will be happy to rectify..." text only appears
once, on page 44), so the only board evidence found for that file was
CAIE's 0.9 vs. AQA's own much weaker page-text heuristic at 0.65 — and
CAIE won. The paper was routed out of the AQA pipeline entirely with the
reason *"CAIE document — the Cambridge pipeline handles this paper"*,
silently dropping the whole subject from the batch.

**Root cause confirmed**: `8035` is not one of the ~70 syllabus codes this
repo actually has CAIE config for (`subjects_caie/`) — the collision was
coincidental, not a real ambiguity.

**Fix applied** (`adapters/caie/adapter.py`): the regex-matched 4-digit
code is now checked against the actual set of CAIE syllabus codes
configured in this repo before it is allowed to produce CAIE board
evidence; an unrecognised code (like AQA's `8035`) no longer outvotes
another board's real, if weaker, evidence. This preserves the original
"belt and braces" purpose (catching a real Cambridge paper whose signature
text is missing or garbled) while no longer firing on a numeric coincidence
with a different board's own code format.

**Verification**: full golden set re-run **2056/2056 (100%)** and
`pytest tests/` **105/105 passed**, both unchanged from before the fix.
Geography 8035/1's QP now correctly resolves to `AQA` and associates with
its MS (previously it associated as `MS`-only, `review_required=True`,
with the QP filed as a phantom CAIE "wrong door" item).

Fixing the board-identity bug did **not** fully unblock Geography — see
§4b: the GCSE Geography question paper still fails to segment into any
questions at all, for an entirely separate, unfixed reason.

## 4. Manual review: segmentation gaps are the real story of this batch

```
RUN COMPLETE — REVIEW REQUIRED   (exit code 2)
pdfs=26  render_pass=13  companion_pass=11  companion_review=2
question_packs=141  pack_review_items=74
```

| Subject | Qs on paper | Qs captured & classified correctly | Disclosed issue |
|---|---:|---:|---|
| Biology 8461 | 6 | 6 | none — clean |
| Chemistry 8462 | 10 | 10 | none — clean |
| English Language 8700 | 5 | 5 | none — clean |
| Mathematics 7357 | 16 | 16 | none — clean |
| Physics 7408 | 31 | 31 | none — clean |
| English Literature A 7712 | 7 | 7 | none — clean |
| Business 7132 | 23 (+1 stray) | 23 | 1 phantom "Q24" segment from the blank copyright page, safely caught by REVIEW_REQUIRED rather than filed as real content (§4a) |
| Computer Science 8525 (1A) | 16 printed (2 numbers by design omitted — on-screen-only tasks) | 14 topic-correct | mark scheme is one combined 1A/1B/1C document; **every** question correctly flagged `MISSING_MS` rather than silently paired wrong (§4e) |
| History 8145 | 4 | 3 topic-correct | **Q1 silently missing** — no record at all, not even review_required (§4c); MS also not split per-question for the 3 that were captured (§4e) |
| Combined Science Trilogy 8464 (Physics strand) | 6 | 3 topic-correct, 3 misclassified | cross-strand topic-vocabulary contamination: a Physics resistance question tagged "quantitative_chemistry" (§4d) |
| Psychology 7182 | 14 | 6 topic-correct | 5 explicitly flagged `MISSING_QP`, **3 silently missing** with no record at all (§4c) |
| Economics 7136 | ~14 (MS found 9 distinct markers) | 0 | **total QP segmentation failure** — vertically-stacked question-number glyphs not recognised (§4b) |
| Geography 8035 | 5 | 0 | **total QP+MS segmentation failure** — fused top-level/sub-part numbering not recognised (§4b) |

### (a) Business 7132 — a harmless phantom segment

The last "question" the segmenter found, Q24, is not a real question: it
is the blank "There are no questions printed on this page" /
copyright-information page at the end of the booklet, picked up as a
spurious 24th segment. It correctly failed closed — `TOPIC_UNKNOWN` +
`REVIEW_REQUIRED`, never filed into a real topic folder — so no incorrect
output resulted, but it is a stray-segment detection gap worth noting.
The 23 genuine questions (Q1–Q23) were all captured and, on inspection,
correctly classified (spot-checked across `Decision_making_to_improve_*`,
`What_is_business`, `Managing_strategic_change`, `Choosing_strategic_direction`).

### (b) Two subjects AQA-batch-wide segmentation could not handle at all

AQA's question-paper segmenter (`adapters/aqa/adapter.py::segment`) tries,
in order: a Literature choice-paper reader, a Language-paper reader, a
Computer-Science on-screen-task reader, an A-level science/humanities
reader (`_segment_alevel_questions`, gated to refuse anything containing
the word "GCSE"), an A-level/GCSE maths reader, and finally
`_segment_numbered_boxed` — the generic GCSE science reader, which looks
for a bare, horizontal `"0 1"` pair (two single-digit glyphs on the same
baseline) at the very top of a page (`y0` between 45 and 120 pt), with no
`.N` sub-part marker on the same line.

- **AQA GCSE Geography 8035/1** never prints that bare top-level marker at
  all: every question's number is fused directly onto its first sub-part
  (`"0"` then, immediately below it, `"1 . 1 ␉Which one of the
  following..."` as one continuous run with the question text) — measured
  directly from the PDF's own text layer. No segmenter in the chain claims
  this shape, so the result is **zero segments on both QP and MS** and an
  entirely empty output for the subject (no packs, no review-required
  entries either — there was nothing for the pack assembler to act on).
- **AQA A-level Economics 7136/1** uses a different, also-unrecognised
  convention: question numbers print as **two separate stacked lines**
  (`"0"` directly above `"9"`, not side-by-side on one baseline), inside a
  whole-paper "Answer EITHER Context 1 OR Context 2" / "Answer one essay
  from this section" choice structure analogous to the Literature paper's
  (which *is* handled) but for Economics (which is not). Result: **zero
  segments on the QP side**; the MS still found 9 distinct question
  markers, but with no QP segments to pair against, nothing could be
  classified or audited for this subject at all.

Both are new, previously-unseen AQA layout families in this project, not
edge cases of a working path. Fixing them would mean writing and
golden-set-validating two new segmenter branches — out of scope for this
testing pass, consistent with how the project has treated other
structural, non-trivial gaps (e.g. the CAIE Hindi/Urdu font-extraction
issues in Batch 7). Both subjects are kept in this batch's results,
disclosed as complete failures, rather than quietly swapped out.

### (c) Two subjects with *silent* gaps — worse than a disclosed one

**AQA GCSE History 8145/2A** ("Answer all four questions") only produced
3 segments (Q2, Q3, Q4); **Q1 is missing with no trace anywhere in the
output** — not packed, not in `review_required`. Direct inspection of the
source PDF confirms Q1 is real and printed ("Study Source A... How useful
is Source A to an historian studying the cholera epidemics of the 19th
century?") — its `"0 1"` marker is pushed down the page by the "Answer all
four questions. / Study Source A in the Sources Booklet." preamble above
it, past the generic segmenter's `y0 <= 120` ceiling.

**AQA A-level Psychology 7182/1** is worse in degree: of 14 printed
questions, only 6 (Q3, Q6, Q7, Q9, Q12, Q14) were captured and correctly
classified (spot-checked: Q12's "failure to function adequately" question
correctly tagged `Psychopathology`). Five more (Q1, Q2, Q4, Q5, Q8) were
at least caught by the companion-pairing stage and explicitly flagged
`MISSING_QP` under `review_required/TOPIC_UNKNOWN`. But **three (Q10, Q11,
Q13) are missing from the output with no record at all** — the same root
cause as History: each of these questions follows a stimulus paragraph or
a preceding question's own written-answer space, pushing its marker below
the geometric band the generic segmenter scans.

This is flagged as the single most important finding of this batch: a
*disclosed* gap (flagged `review_required`) is a known limitation a
consumer can act on; a *silent* gap is indistinguishable from "this paper
only had 11 questions" unless someone manually recounts against the real
paper, which is exactly what this testing pass is for. The common root
cause (a fixed top-of-page geometric window that assumes a question's
marker is always near the start of its own page) would need to be loosened
with real measurement against AQA's humanities-subject layouts before
being trusted — not attempted here given the risk of destabilising the
nine subjects in this same batch that currently work correctly through the
exact same function.

### (d) Combined Science Trilogy 8464 (Physics strand) — cross-strand topic contamination

All 6 questions segmented correctly (verified against the real PDF: Q2 is
a resistance/body-water-percentage data-handling question, unambiguously
Physics). Three were correctly classified; three (Q1, Q3, Q4) landed in
`TOPIC_UNKNOWN`; and the other three (Q2, Q5, Q6) were tagged
**`quantitative_chemistry`** — a Chemistry topic — purely because the word
"mass" appeared in the Physics question text and matched a generic,
apparently shared keyword vocabulary rather than a Physics-specific one.
Confirmed via the pack metadata: `engine: "nonib_fallback"`, a much weaker
classification path than the properly syllabus-referenced engine
(`aqa_alevel_reference`, 0.97 confidence with a spec citation) that
correctly classified every one of A-level Physics 7408's 31 questions.
This indicates AQA Combined Science Trilogy's three strands (Physics/
Biology/Chemistry, each printed and coded separately — `8464/P`, `/B`,
`/C`) do not yet have their own dedicated topic-reference configs in this
build, and fall back to a shared, strand-blind keyword list. Not fixed
here; disclosed as a classification-accuracy gap specific to Combined
Science Trilogy.

### (e) Mark-scheme-splitting gaps (topic correct, MS pairing missing — already anticipated)

Three subjects' question papers were captured and classified correctly but
their companion mark schemes did not split into individual per-question
segments, so every pack in the subject is correctly topic-tagged but
carries a `MISSING_MS` flag instead of a paired mark scheme image:

- **Computer Science 8525 (1A)** — all 14 questions. Root cause is the one
  disclosed in §2b: the MS is one combined document for all three language
  variants (1A/1B/1C), and the per-question splitter was not matched to
  that merged layout.
- **History 8145 (2A)** — the 3 questions that were captured. The MS
  produced only 1 raw segment for the entire paper rather than one per
  question — AQA's thematic-essay MS format (long, prose mark-scheme
  guidance per question rather than a compact marks table) was not
  recognised by the row-based MS splitter that works for the GCSE science
  subjects.

This is a distinct and milder failure mode than §4b/§4c: the question
content itself and its topic tag are both correct and auditable, only the
mark-scheme pairing is missing, and it fails safely (flagged, never
silently mispaired) in all cases.

## 5. Net result

- **9 of 13 subjects fully clean**: Biology 8461, Chemistry 8462, English
  Language 8700, Mathematics 7357, Physics 7408, English Literature A
  7712, Business 7132 (bar one harmless phantom segment), Computer Science
  8525 (topic-correct; MS-pairing disclosed separately), History 8145
  (3 of 4 topic-correct; 1 silently missing + MS-pairing disclosed).
- **1 subject with a real classification defect**: Combined Science
  Trilogy 8464 Physics strand (half its questions misrouted to a Chemistry
  topic via a shared, strand-blind fallback vocabulary).
- **1 subject badly degraded**: Psychology 7182 (well under half its
  questions reached a correct, auditable output; three genuinely silent).
- **2 subjects total failures**: Economics 7136 and Geography 8035 (zero
  usable output), both traced to specific, previously-unseen AQA
  question-numbering layouts outside current segmenter coverage.
- **1 real pipeline bug found and fixed**: the CAIE board-detection false
  positive described in §3, verified safe against the full golden set
  (2056/2056) and pytest suite (105/105).

Compared to CAIE's seven batches, this first AQA batch surfaced
meaningfully more structural gaps per subject tested — a direct
consequence of CAIE's adapter having had seven batches' worth of real-paper
hardening already, while this is AQA's first. Future AQA batches should
expect to keep finding new layout families in the subjects not yet tested,
particularly A-level humanities and essay/choice-structured papers, until
the segmenter has seen a wider sample of AQA's own format diversity.
