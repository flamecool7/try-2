# Real-Paper Validation Addendum — IB Diploma Programme Batch 2 (4 new subjects, genuine live papers)

## Status

Batch 1 (`REAL_PAPER_IB_BATCH1_ADDENDUM.md`) tested only specimen/sample materials
and concluded that IB's other subjects had no freely available real papers. This
batch found a new free source offering genuine **live May/November 2025 IB exam
papers** (not specimens) for 4 subjects Batch 1 could not source at all:
Environmental Systems and Societies (ESS), Economics, Business Management, and
Psychology. **For the first time in this entire real-paper campaign (since the
original Batch 1/2 baseline), real Question Paper content was correctly
segmented, cropped, and rendered — across all 4 new subjects.** However, 0 of
14 assembled packs ever achieved a correct QP+MS pairing, and the root cause is
now fully evidenced at the data level, not just inferred: **the IB adapter's
document-association logic groups papers by board + paper-number + season +
year only, with no subject-level discrimination at all** — so unrelated
subjects that happen to share a paper number, season, and year are merged into
the same association group, and subjects whose season/year extraction fails
end up unmatched with their own correct companion document.

## 0. Sourcing

All 9 files are genuine IBO-copyrighted documents (`© International
Baccalaureate Organization 2025`, confirmed via direct text extraction),
freely downloaded (HTTP 200, no login/paywall) from exampaperspractice.co.uk,
a commercial revision site that publishes exactly one real paper per subject
page as a free sample (everything else gated behind `/join`). This is
consistent with the "official free aggregator" sourcing standard used
throughout this campaign (e.g. revisionworld.com, savemyexams.com) — one free
genuine document per subject, not a bulk leak.

| Subject | Paper | Session (per document's own cover page) | Files |
|---|---|---|---|
| Environmental Systems and Societies | Paper 1, SL | November 2025 (QP) / May 2025 (MS) — see §2 | QP + Resource Booklet + MS |
| Economics | Paper 1, HL | May 2025 | QP + MS |
| Business Management | Paper 1, HL/SL | November 2025 (per MS cover; site listed it as "October 2025") | QP + MS |
| Psychology | Paper 3, HL | November 2025 | QP + MS |

All 9 PDFs were independently verified before the pipeline run: genuine `%PDF`
files with real, correct page counts and matching cover-page text (e.g. the
Economics MS reads "Markscheme | May 2025 | Economics | Higher level | Paper
1"). Source documents are not at fault for anything below.

## 1. The headline result: real QP content was correctly segmented for the first time since the campaign's original baseline

Visual inspection of rendered question images confirms **genuinely correct,
cleanly cropped content** for all 4 subjects' question papers:

- **Economics Q1**: "(a) Explain why the price elasticity of demand (PED) for
  primary commodities is generally lower than the PED for manufactured
  products. [10] (b) Using real-world examples, discuss the importance of PED
  for the decision-making of firms **and** government. [15]" — correct,
  complete, properly mark-annotated.
- **Economics Q3**: the matching exchange-rate question, equally clean.
- **Business Management Q1**: "State **two** purposes of a mission statement.
  [2]" — correct.
- **Environmental Systems and Societies Q1**: "Using **Figure 2**, identify
  the ecosystem of Mindo. [1]" with the real answer-line box reproduced
  faithfully.
- **Psychology Q1**: the real three-part research-methods question "(a)
  Identify the research method used… (b) Describe the sampling method used…
  (c) Suggest **one** alternative…" — correct, complete.

This is a genuine positive result and a marked improvement over every Edexcel
batch run since Batch 2, where 17 of 17 real Question Papers produced zero
content. It shows the underlying segmentation/rendering machinery **can**
work correctly on real exam papers when the document matches a layout
archetype the adapter already understands — the failures documented below are
entirely at the identification/pairing layer, not at the visual
segmentation/rendering layer.

### 1a. But the crop-plan metadata reveals the segmenter is pattern-matching, not understanding

Every correctly-segmented Economics question segment carries this verbatim
metadata note, copied from Batch 1's English A specimen handling:

```
"archetype": "ib_essay_prompt_list",
"notes": "IB English A Paper 2 specimen: four prompts; direct PDF binary
          remains access-blocked in this sandbox.",
"verified_on_real_pdf": false
```

This is leftover development/test-fixture text, hardcoded into the adapter
and now leaking verbatim into the metadata of an entirely unrelated real
Economics paper that has no connection to English A, four prompts, or any
sandbox access restriction. The `"verified_on_real_pdf": false` flag is
**still false even though this batch just ran it against a real PDF** — the
flag is static fixture metadata, not something the adapter updates based on
what it actually processed. This confirms the adapter was tuned against a
single specimen fixture and applies that fixture's generic "essay prompt
list" archetype as a default match to superficially similar real papers,
carrying its stale provenance notes along for the ride. A user inspecting
this metadata would be given false information about what was actually
verified.

## 2. Root cause of 0/14 correct pairings: association keys have no subject dimension

`association_manifest.json` groups every document by the key `board |
component | season | year` — e.g. `"IB|Paper 1|May|2025"`. This key contains
**no subject field at all**. The consequence, visible directly in this
batch's manifest:

| Association group | Documents merged into it |
|---|---|
| `IB\|Paper 1\|May\|2025` | Economics QP + Economics MS + **ESS MS** (3 unrelated-subject documents merged; flagged `"multiple MS documents in one association group"`) |
| `IB\|Paper 1\|November\|2025` | **Business Management MS** + ESS QP + ESS Resource Booklet (flagged `"multiple QP documents in one association group"`) |
| `IB\|Paper 1\|UNKNOWN\|2025` | Business Management QP, alone (its own season failed to parse, so it never reaches the group holding its own MS) |
| `IB\|Paper 3\|November\|2025` | Psychology QP + Psychology MS (the only group with no subject collision) |

Economics and ESS — two completely unrelated subjects — were merged into one
association group purely because both happen to be "Paper 1" sat in a "May
2025"-or-compatible session; the ESS **mark scheme**, correctly segmented into
2 real segments (confirmed by visual inspection: genuine ESS biocapacity
statistics, "The biocapacity in NZ has fallen more... than the world"), ends
up filed as if it belonged to Economics — a wrong-subject misattribution a
user would not detect without opening the file and reading it. Business
Management's QP and MS, meanwhile, never even reach the same group: the QP's
season/year extraction failed entirely (`UNKNOWN_2025`) while its own MS was
correctly dated `November_2025` — the same "QP and MS of the same real exam
get identified inconsistently with each other" pattern documented repeatedly
across Edexcel batches now reproduces on IB's own adapter too.

## 3. Even the one collision-free group failed to pair

Psychology is the only association group in this batch with no cross-subject
contamination (just its own QP + its own MS, correctly grouped). It should
represent the best-case scenario. It still produced **0 correctly paired
packs**: 3 packs were assembled, every single one flagged `MISSING_MS`,
because the Psychology MS document itself produced 0 segments (confirmed:
`final/IB/Paper_3/November_2025/MS/.../segments.json` is empty) despite being
a genuine, text-extractable, correctly-identified mark scheme document. This
demonstrates that **mark-scheme segmentation failure is a second, independent
defect from the association-key subject-blindness problem** — fixing the
association key alone (adding a subject dimension) would not have produced a
single correct pack in this batch, because 3 of the 4 real MS documents
(Business Management, Economics, Psychology) never produced any segments at
all. Only the ESS MS (misfiled under Economics, per §2) produced real
content.

## 4. Aggregate numbers for this run

```
pdfs: 9, identities: 9
render_pass: 5/5 attempted (all succeeded)
question_packs: 14 (across 4 session folders)
ms_segments: 2 (only the ESS MS; 3 of 4 real MS documents produced zero)
companion_attempts: 4, companion_pass: 1 (the ESS QP + Resource Booklet pairing — a non-MS companion type, not a QP+MS pack pairing)
review_required: 3 identities; pack_review_items: 27 (every single one of the 14 packs flagged both TOPIC_UNKNOWN and MISSING_MS)
```

**Net correctly-paired, correctly-labeled result across the whole batch: 0 of 14 packs — identical to Batch 1's net result of zero**, despite the clear improvement in raw QP segmentation quality documented in §1. Every `contract_report.json` for a QP again reports `"status": "PASS"` with no issues, regardless of whether that QP's content ever reaches a usable, MS-paired pack — the same self-reported-health blind spot documented in every batch across every board this campaign has tested.

## 5. What was not attempted

- No code fix for the subject-blind association key (§2), the 3-of-4 MS segmentation failures (§3), or the stale fixture metadata leaking into real output (§1a).
- The remaining IB subjects without a freely accessible real paper (confirmed again this session: Mathematics AA/AI, Chemistry, Physics, Geography, History, Language A/B at a scale beyond what Batch 1 already tested, and all of IB's internally-assessed/portfolio subjects) were not re-attempted; IBO's Questionbank and Programme Resource Centre remain login-gated, and exampaperspractice.co.uk's single-free-sample model has now been exhausted for the subjects it offers free samples for (ESS, Economics, Business Management, Psychology all used; its Computer Science and other listed categories were not checked and could be a lead for a future batch).

## 6. Conclusion

This batch is a genuine, measurable improvement on the raw segmentation
front — the first time in this entire campaign (since the original tested
baseline) that real Question Paper content was correctly extracted and
rendered, across 4 different real subjects, in one run. But it also newly
and concretely proves the root cause behind IB's persistent 0%
correctly-paired-pack rate: the adapter's document-association logic has no
subject awareness, grouping by board/paper-number/season/year alone, which
silently merges unrelated subjects when their metadata coincides and
silently orphans documents whose own season/year extraction fails — compounded
by a still-unresolved, independent defect causing most real mark schemes to
produce zero segments regardless of correct grouping. As with Edexcel, no
code fix was attempted; this document records findings only.
