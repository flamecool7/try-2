# Real-Paper Accuracy Testing — Batch 5 Addendum

Fifth batch of real CAIE past-paper testing, same method as Batches 1–4:
real October/November 2023 question papers and mark schemes for subjects
**never previously tested with real papers**, run through the full
production pipeline, every question manually checked.

## 1. Scope

| # | Subject | Code | Level | Variant used | Questions |
|---|---|---|---|---|---:|
| 1 | Physical Education | 0413 | IGCSE | w23 / **12** | 11 |
| 2 | Design and Technology | 0445 | IGCSE | w23 / **12** | 3 |
| 3 | Business Studies | 0450 | IGCSE | w23 / 22 | 4 |
| 4 | Global Perspectives | 0457 | IGCSE | w23 / **12** | 4 |
| 5 | Travel and Tourism | 0471 | IGCSE | w23 / 22 | 4 |
| 6 | Religious Studies | 0490 | IGCSE | w23 / 22 | 9 |
| 7 | English First Language | 0500 | IGCSE | w23 / 22 | 5 |
| 8 | French | 0520 | IGCSE | w23 / 22 | 6 |
| 9 | Food and Nutrition | 0648 | IGCSE | w23 / **12** | 15 |
| 10 | Global Perspectives | 9239 | A-Level | w23 / **12** | 3 |
| 11 | Travel and Tourism | 9395 | A-Level | w23 / **12** | 4 |
| 12 | Drama | 9482 | A-Level | w23 / **12** | 10 |
| 13 | Thinking Skills | 9694 | A-Level | w23 / 22 | 5 |
| **Total** | **13 subjects** | | | | **83** |

Marine Science 0697 (originally planned for this batch) was dropped and
replaced with English First Language 0500: 0697 is a tiny "Maldives only"
entry subject whose 2023 mark scheme is **not publicly hosted at all** on
the source site (only the question paper and a grade-thresholds document
exist) — confirmed before attempting a pipeline run, not after.

Seven of the thirteen subjects again needed variant 12 instead of 22 (the
same fake-HTML-404-at-200-status issue documented in Batch 4); all 26
downloaded files were verified genuine with `file -b` before the run.

## 2. Pipeline result

```
RUN COMPLETE — REVIEW REQUIRED   (exit code 2)
32 stages, 145 checks passed
83 questions saved
20 review-required directories
```

Same mechanism as Batch 4: two of the thirteen papers (Physical_Education_0413
and Global_Perspectives_9239) could not have their mark scheme structurally
segmented, so every question in those two papers was saved with
`outcome = review_required_no_markscheme` (QP-text-only classification,
flagged for human review) rather than silently guessing a pairing.

## 3. Manual review: 82/83 correct as generated, 1 found and fixed live

| Subject | Questions | Correct/defensible | Notes |
|---|---:|---:|---|
| Design_and_Technology_0445 | 3 | 3/3 | — |
| Drama_9482 | 10 | 10/10 | All `Performance_from_text` (set-text extract questions), conf 1.0 |
| Religious_Studies_0490 | 9 | 9/9 | Cleanly splits Christianity (Q1–3) / Islam (Q4–6) / Judaism (Q7–9) |
| English_First_Language_0500 | 5 | 5/5 | Directed/Descriptive/Narrative writing all correct |
| Food_and_Nutrition_0648 | 15 | 15/15 | A few defensible low-confidence near-ties between adjacent food topics |
| French_0520 | 6 | 6/6 | Listening/reading comprehension; several defensible near-ties (conf 0.46–0.70) across overlapping theme areas, consistent with prior batches |
| Business_Studies_0450 | 4 | 4/4 | Q1 is a 5-part question whose marks are mark-weighted toward Marketing even though its opening sub-part is about production/specialisation — correct per the system's proportional multi-part scoring, same pattern as Batch 4's Environmental Management |
| Global_Perspectives_0457 | 4 | 4/4 | — |
| Travel_and_Tourism_0471 | 4 | 4/4 | — |
| Travel_and_Tourism_9395 | 4 | 4/4 | — |
| Thinking_Skills_9694 | 5 | 5/5 | All correct; **mark scheme segmented successfully** for this paper (contrast with Global_Perspectives_9239 below — same question-paper genre, different outcome) |
| Global_Perspectives_9239 | 3 | 3/3 | Correct, but **flagged `review_required_no_markscheme`** — see §4 |
| Physical_Education_0413 | 11 | 10/11 as generated, **11/11 after a live fix** | **Q8 was a genuine miss, fixed this session** — see §5. All 11 also flagged `review_required_no_markscheme` — see §4 |
| **Total** | **83** | **83/83 after the fix** | |

## 4. `review_required_no_markscheme` recurs — now a confirmed pattern, not a one-off

Investigated the same way as Batch 4 (calling
`core/markscheme_split_gold.py::split_structured_mark_scheme` directly):

- **Physical_Education_0413** (`0413_w23_ms_12.pdf`): only 3 of 11 expected
  top-level question markers detected.
- **Global_Perspectives_9239** (`9239_w23_ms_12.pdf`): only 1 of 3 expected
  markers detected.

Both fail with the identical `_validate_expected` rejection message seen in
Batch 4 ("question paper reported trailing question number(s) not present
in the complete mark-scheme sequence... quarantining the unmatched QP
item"), and in both cases every question in the paper is still correctly
classified from QP text alone and safely flagged for review rather than
silently mis-paired.

This is now the **fourth and fifth real paper** (after ICT_0417 and
History_0470 in Batch 4) to trip this exact mark-scheme segmentation gap in
`core/markscheme_split_gold.py` — 2 of 13 papers in Batch 4, and 2 of 13
papers in Batch 5. That is too high a hit rate to keep calling incidental;
it is a genuine, recurring weak spot in the structured mark-scheme
segmenter worth prioritising in a future engineering pass, separate from
this task's `config.json`-only scope. (Notably, Thinking_Skills_9694 — the
same general "critical thinking / source-based" question genre as
Global_Perspectives_9239 — segmented its mark scheme perfectly, so the
failure tracks specific PDF table layouts, not subject genre.)

## 5. Defect found and fixed this batch: Physical_Education_0413 Q8

Q8 ("Being the host nation for a global sporting event has many advantages
... Explain the advantages for a nation of hosting a global sporting
event.") was classified with **zero keyword evidence against any of the
5 topics** (`Detailed scores: {}`, `fallback_tier: auto_forced`,
confidence 0.25 — the same forced-full-auto-default architecture already
disclosed in Batch 3 for Additional Mathematics 0606, not a new mechanism).
It defaulted to `Anatomy_and_physiology` (the first topic in syllabus
order) purely because no topic had any keyword hit — the real answer is
`Social_and_cultural_influences`, which in the 0413 syllabus already
covers Olympics/Paralympics/media/commercialisation but had no phrasing for
the generic "host nation" framing this question used instead of naming the
Olympics specifically.

**Fix applied and verified:** added `"host nation"`, `"hosting"`,
`"host the"`, `"global sporting event"`, `"major sporting event"`,
`"international sporting event"`, `"bidding to host"` to
`Social_and_cultural_influences` in
`subjects_caie/IGCSE/Physical_Education_0413/config.json`. Re-ran
`classify_text.py` on the exact question text — now resolves to
`Social_and_cultural_influences` at confidence 1.0 with real keyword
evidence. Re-ran the full golden set (2056/2056, 100%, including the 0413
subset at 5/5) and the full pytest suite (105/105) — zero regressions.

## 6. Cumulative real-paper evidence after Batches 1–5

| Phase | Subjects | Questions reviewed | Correct/defensible |
|---|---:|---:|---:|
| Phase 1 | 5 | 80 | 80/80 (100%) |
| Phase 2 | 8 | 104 | 102/104 (98.1%, 1 paper's disclosed MS-splitting defect) |
| Phase 3 | 13 | 105 | 103/105 (98.1%, 2 disclosed full-auto forced-default edge cases) |
| Phase 4 | 13 | 130 | 130/130 (100% topic-correct; 2 disclosed engine-level limitations affecting 2 subjects' MS availability + 1 QP content-merge defect, not topic correctness) |
| Phase 5 (this batch) | 13 | 83 | 83/83 (100% after 1 live keyword fix; same disclosed MS-segmentation limitation recurred in 2 more subjects) |
| **Total** | **47 unique CAIE subjects** | **502** | **498/502 (99.2%)** |

**Still outstanding:** 34 more untested CAIE subjects, and all of AQA (46),
Edexcel (44), IB (30), and SAT (2) — 156 configs remain unverified against
real papers.

**Fixes committed this batch:** 1 keyword addition
(`Physical_Education_0413`), verified against the golden set and pytest
with zero regressions.

**Recurring limitation flagged for a future engineering pass (not fixed,
outside config-keyword scope):** mark-scheme structural segmentation in
`core/markscheme_split_gold.py` has now failed on 4 of the last 26 real
mark schemes tested (ICT_0417, History_0470, Physical_Education_0413,
Global_Perspectives_9239) — roughly 1 in 6 — always causing that paper's
questions to be correctly flagged for manual review rather than
mis-classified, but worth a dedicated investigation into the segmenter's
table-rule detection robustness.
