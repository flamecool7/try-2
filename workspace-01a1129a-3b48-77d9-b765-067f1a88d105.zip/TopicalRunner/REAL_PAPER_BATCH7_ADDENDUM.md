# Real-Paper Accuracy Testing — Batch 7 Addendum

Seventh batch of real CAIE past-paper testing, same method as Batches 1–6.
**This batch sweeps up every remaining untested CAIE subject** (plus a
careful accounting of which ones genuinely cannot be tested and why) —
after this batch, every one of the 81 CAIE subject configs in the
repository has either been hand-verified against a real paper or formally
excluded with a documented reason. This batch also surfaced the two most
serious *new* findings of the whole project: a severe text-extraction
corruption on an Urdu (Nastaliq-script) paper, and a milder but
higher-than-usual text-extraction degradation on a Hindi paper.

## 1. Scope

| # | Subject | Code | Level | Session/Variant | Questions |
|---|---|---|---|---|---:|
| 1 | Hindi | 0549 | IGCSE | w23 / 01+02 | 42 |
| 2 | Marine Science | 0697 | IGCSE | **s23** / 01+02+03 | 17 |
| 3 | Drama | 0411 | IGCSE | w23 / 12 | 11 |
| 4 | Mandarin Chinese | 0547 | IGCSE | **s23** / 22 | 11 |
| 5 | Urdu | 9686 | A-Level | w23 / 02+03 | 10 |
| 6 | Design and Technology | 9705 | A-Level | w23 / 12 | 9 |
| 7 | Music | 9483 | A-Level | w23 / 12 | 8 |
| 8 | Arabic | 0544 | IGCSE | **s23** / 22 | 6 |
| 9 | Mandarin Chinese | 9715 | A-Level | w23 / 22 | 5 |
| 10 | Marine Science | 9693 | A-Level | w23 / 22 | 4 |
| **Total** | **10 subjects** | | | | **123** |

Three subjects (0697, 0547, 0544) had no w23 sitting on the source site;
May/June 2023 (`s23`) was used instead, same precedent as Media Studies
9607 in Batch 4. Hindi 0549 and Marine Science 0697 each have 2–3
components per the syllabus structure; Hindi's mark schemes again needed
the single-digit-vs-double-digit variant-naming workaround first seen with
Pakistan Studies 0448 in Batch 6 (`qp_01`/`qp_02` pairs with `ms_1`/`ms_2`).

## 2. Five subjects excluded before downloading — config check caught them early

Before touching the source site, this batch checked `syllabus_years` in
every remaining untested subject's `config.json` first (a direct lesson
from Batch 6's Business_0774 discovery). Four had **no 2023 entry at all**,
so no download was attempted:

| Subject | Code | Declared years | Why excluded |
|---|---|---|---|
| English Literature (UK 9-1) | 0477 | 2017–2019 | Retired syllabus — no longer examined in 2023 |
| English Literature | 9695 | 2026 only | New/future syllabus — first exams haven't happened yet |
| Arabic (alternate code) | 7180 | 2026–2028 | New/future syllabus |
| Arabic — First Language | 7184 | 2024–2026 | New/future syllabus |
| English as an Additional Language | 0772 | 2026–2028 | New/future syllabus (confirms Batch 6's inability to find it at w23 — it genuinely didn't exist yet) |

A sixth, **Applied ICT 9713**, declares 2023–2028 in its own config (so the
config check didn't catch it) but was not found anywhere on the source
site at w23 or s23 across the full variant grid. A direct check of the
site's own archive page confirmed why: **its most recent available session
is 2017 Nov** — Cambridge discontinued this qualification years before
2023, and the repo's config simply hasn't been pruned to reflect that. All
six are excluded from this and all future batches for documented reasons,
joining Business_0774 (no 2023 sitting), Urdu_0539 (confirmed unfindable
after an exhaustive two-session search in Batch 6), and the three
coursework/portfolio subjects (Art_and_Design_0400/9479,
Digital_Media_and_Design_9481, excluded in Batch 6) as the complete list of
CAIE subjects that will not be real-paper tested.

**With this batch, all 81 CAIE subject configs are now accounted for: 70
tested across Batches 1–7, 11 formally excluded with a documented reason.
CAIE real-paper testing is now complete.**

## 3. Pipeline result

```
RUN COMPLETE — REVIEW REQUIRED   (exit code 2)
30 stages, 147 checks passed
123 questions saved
17 review-required directories (10 individual questions across 2 papers)
```

## 4. Manual review: 87/123 cleanly correct, two newly-disclosed limitation types

| Subject | Questions | Correct | Notes |
|---|---:|---:|---|
| Drama_0411 | 11 | 11/11 | Scripted-performance extract (Rattigan-style text) + devised-theatre section, correctly split |
| Arabic_0544 | 6 | 6/6 | Reading/listening comprehension; defensible near-ties, same pattern as other language subjects |
| Mandarin_Chinese_0547 | 11 | 11/11 | Simple-sentence MCQ vocabulary items + reading comprehension, all correct by content (3 items were technically forced-default with no real keyword hit, but independently verified as the right topic by content: "bookstore is closed", "watermelon sold out" are genuinely `Everyday_activities`) |
| Marine_Science_0697 | 17 | 17/17 | Three components (01/02/03): marine biology, oceanography, and a practical/drawing paper — correctly split across Marine_organisms / Marine_ecosystems / The_ocean_environment / Human_influences |
| Marine_Science_9693 | 4 | 4/4 | A-Level equivalent; correct, reasonable near-ties (mangroves/crabs/fish/coral reef questions span Marine_ecosystems + Oceanography + Marine_organisms) |
| Design_and_Technology_9705 | 9 | 9/9 | Product-design case studies (chair, crate, pulley, shed, packaging, coffee machine, jewellery box, carrier bag, magnifier), all correct |
| Mandarin_Chinese_9715 | 5 | 5/5 | A-Level reading comprehension on politeness/formality, correctly tagged Society_and_culture throughout |
| Music_9483 | 8 | 5/8 | Q1–3 (listening extracts) and Q4–5 (named set works: Rimsky-Korsakov's *Scheherazade*, Debussy, Grieg) all correct. Q6–8 are generic high-level essay prompts ("Explain how contrast can be achieved in vocal music") with no distinguishing keyword content — forced full-auto default, **not counted as confidently correct** (see §5) |
| Hindi_0549 | 42 | 19/42 | See §5 — a new, more severe text-extraction finding |
| Urdu_9686 | 10 | **not scored** | See §6 — a new, severe text-extraction finding; topic assignments are not verifiable either way |
| **Total** | **123** | **87/123 cleanly verified correct** (remaining 36 are two distinct disclosed limitations, not classification bugs — see §5/§6) | |

## 5. New finding: Devanagari (Hindi) text extraction degrades keyword matching

23 of Hindi_0549's 42 questions (55%) came back as `fallback_tier:
auto_forced` — the per-paper keyword gate found zero real evidence and the
classifier fell back to the first topic in the subject's declared list
(`Everyday_activities`), exactly the documented "full-auto never abstains"
behavior from Batch 3. What's new here is the *rate*: no previous subject
has hit anywhere near 55%. Inspecting the raw extracted text explains why —
`कम्बोडिया` ("Cambodia") extracts as `कम््बबोडिया`, with a duplicated
consonant and a stray virama mark not present in the source. This is a
classic symptom of a non-Unicode "legacy" Devanagari font (e.g. Kruti Dev/
DevLys-style) embedded in the source PDF: the glyphs are visually correct
Devanagari when rendered, but the underlying character codes PyMuPDF reads
out do not correspond to standard Unicode Devanagari, so keyword lists
(written in normal Unicode) almost never match. Unlike Mandarin_0547's few
forced-defaults (which happened to land on the right topic anyway by
content coincidence), several of Hindi's forced-defaults clearly land on
the *wrong* topic by content (e.g. a question about Cambodia's population
distribution, or about industrialisation's effect on indigenous farmers,
both defaulted to `Everyday_activities` when `The_world_around_us` /
`The_world_of_work` would be the better real-content fit). These 23 items
are disclosed as a genuine limitation, not silently counted as correct.
**Recommended follow-up (not done in this session, out of scope for a
testing pass): add a font/encoding-remapping step for legacy Devanagari
fonts before keyword matching, or fall back to OCR for CAIE PDFs that
exhibit this corruption pattern.** Music_9483's 3 generic-essay forced
defaults (Q6–8) are unrelated to this — different root cause (genuinely
topic-neutral essay prompts), same "not confidently correct" treatment.

## 6. New finding (more severe): Nastaliq (Urdu) text extraction is unusable

Urdu_9686's two components are worse than Hindi's case — not "extracts
with artifacts" but **extracts as effectively unreadable scrambled text**.
Example (paper 03, Q1, raw extracted string): `اخدنان۔㸡  وچبں یک ےب راہ
روی ےک ذہم دار رصف وادلةی...` — individual letters are present but appear
reordered/reversed relative to correct reading order, mixed with stray
glyph-ID artifacts like `㸡`, `ᥖ`, `܉` that are not valid Urdu characters at
all. Paper 02's five questions are even more striking: the real
essay-prompt instructions appear to not be captured as text at all — only
the answer-line dots (`...`), mark allocations (`[1]`, `[3]`, `[20]`), and
a handful of scrambled option-label fragments came through. This strongly
suggests Cambridge typesets Nastaliq-script Urdu content (a cursive,
context-dependent script where CAIE's typesetting software commonly
renders text as embedded image/vector art rather than selectable Unicode
text) in a way that this pipeline's text-layer extraction cannot read at
all. Arabic (0544) did **not** show this problem — its extracted text was
legible standard Arabic — so this appears specific to Urdu's Nastaliq
calligraphic style rather than RTL scripts in general.

**Consequence:** all 10 of Urdu_9686's topic assignments are built on
essentially-unreadable input. They are not wrong in the sense of a
classifier bug — the classifier did the best it could with corrupted
input — but they cannot be confirmed correct either, so they are excluded
from the correctness count entirely rather than guessed at. This is the
most significant data-quality gap found in the project so far and is
flagged as a priority item: **CAIE Urdu papers should not be trusted by
this pipeline until a dedicated OCR-based fallback is built for
Nastaliq-typeset content; Arabic does not appear to need the same fix.**

## 7. Recurring `review_required_no_markscheme` pattern: now 8 papers across 4 batches

Music_9483 (questions 4–8, including the two correctly-classified named-
set-work questions) and Urdu_9686 paper 03 (all 5 questions — compounded
with the text-corruption issue above) both hit the same mark-scheme
structural-segmentation gap tracked since Batch 4. Running total: 8 real
papers across the last 4 batches (ICT_0417, History_0470,
Physical_Education_0413, Global_Perspectives_9239, Music_0410,
English_Language_9093, Music_9483, Urdu_9686) have hit this limitation —
always safely caught and disclosed, never silently mis-paired.

## 8. Cumulative real-paper evidence after Batches 1–7

**Correction to a prior count:** Business_Studies_0450 was independently
re-tested in both Batch 3 and Batch 5 (an oversight — Batch 5's "never
previously tested" framing was incorrect for this one subject; it scored
100% both times so the quality conclusions are unaffected, but it means
the subject-count arithmetic in earlier cumulative tables double-counted
it by one). The corrected unique-subject counts below fix this.

| Phase | Subjects (new, unique) | Questions reviewed | Correct/defensible |
|---|---:|---:|---:|
| Phase 1 | 5 | 80 | 80/80 (100%) |
| Phase 2 | 3 | 104 | 102/104 (98.1%, 1 disclosed MS-splitting defect) |
| Phase 3 | 13 | 105 | 103/105 (98.1%, 2 disclosed full-auto forced-default edge cases) |
| Phase 4 | 13 | 130 | 130/130 (100% topic-correct; 2 disclosed engine limitations + 1 QP content-merge defect) |
| Phase 5 | 13 | 83 | 83/83 (100% after 1 live keyword fix) |
| Phase 6 | 13 | 117 | 117/117 (100%, zero fixes needed) |
| Phase 7 (this batch) | 10 | 123 | 87/123 (70.7% cleanly verified; 26 disclosed Devanagari/essay-prompt forced-default limitation + 10 unverifiable due to severe Urdu/Nastaliq text corruption — see §5/§6) |
| **Total** | **70 unique CAIE subjects** (corrected for the 0450 double-count) | **742** | **702/742 (94.6%)** |

**CAIE coverage is now complete: 70 subjects tested, 11 formally excluded
with documented reasons (no 2023 sitting: Business_0774, English_Literature_0477,
English_Literature_9695, Arabic_7180, Arabic_First_Language_7184,
English_As_An_Additional_Language_0772; discontinued: Applied_ICT_9713;
confirmed unfindable after exhaustive search: Urdu_0539; coursework/
portfolio format unsuited to this methodology: Art_and_Design_0400,
Art_and_Design_9479, Digital_Media_and_Design_9481). 70 + 11 = 81, the full
CAIE subject count in this repository.**

**Still outstanding:** all of AQA (46), Edexcel (44), IB (30), and SAT (2)
— 122 configs across four other exam boards remain completely unverified
against real papers. This is a natural point to move to a different board.

**Fixes committed across all batches so far:** 4 config-level keyword/
normalization fixes (Batch 3 ×3, Batch 5 ×1), all verified against the
2056-question golden set and 105-test pytest suite with zero regressions
(reconfirmed again this batch: 2056/2056 golden set, 105/105 pytest).

**Two new disclosed limitation types from this batch, not yet fixed:**
(1) legacy/non-Unicode Devanagari font encoding degrading keyword matching
for Hindi papers (§5); (2) Nastaliq-script Urdu text extraction producing
effectively unusable scrambled text (§6). Both are text-extraction-layer
issues, not classifier-logic bugs, and both would need a dedicated
engineering effort (font remapping or OCR fallback) beyond the scope of a
testing pass to fix.
