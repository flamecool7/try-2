# Real-Paper Accuracy Testing — Batch 6 Addendum

Sixth batch of real CAIE past-paper testing, same method as Batches 1–5:
real 2023 question papers and mark schemes for subjects never previously
tested, run through the full production pipeline, every question manually
checked. **This is the first batch with zero new defects found** — all
117 questions were correctly classified as generated.

## 1. Scope

| # | Subject | Code | Level | Session/Variant | Questions |
|---|---|---|---|---|---:|
| 1 | Music | 0410 | IGCSE | w23 / 12 | 41 |
| 2 | English Second Language | 0510 | IGCSE | w23 / 22 | 15 |
| 3 | Pakistan Studies | 0448 | IGCSE | **s23** / 01+02 | 10 |
| 4 | Classical Studies | 9274 | A-Level | w23 / 22 | 9 |
| 5 | German | 0525 | IGCSE | w23 / 22 | 6 |
| 6 | Spanish | 0530 | IGCSE | w23 / 22 | 6 |
| 7 | Islamiyat | 0493 | IGCSE | w23 / 22 | 5 |
| 8 | French | 9716 | A-Level | w23 / 22 | 5 |
| 9 | German | 9717 | A-Level | w23 / 22 | 5 |
| 10 | Spanish | 9719 | A-Level | w23 / 22 | 5 |
| 11 | English Language | 9093 | A-Level | w23 / 22 | 4 |
| 12 | Physical Education | 9396 | A-Level | w23 / 12 | 3 |
| 13 | English General Paper | 8021 | A-Level | w23 / 22 | 2 |
| 14 | Literature in English | 0475 | IGCSE | w23 / 22 | 1 |
| **Total** | **14 subjects** | | | | **117** |

## 2. Four originally-planned subjects swapped out before the run

Four of the originally-selected 13 subjects were found to be unsuitable
for this methodology and swapped **before** running the pipeline:

- **Business_0774**: this syllabus code's own config declares
  `syllabus_years: ['2027','2028','2029']` — it genuinely has no 2023 exam
  sitting (it replaces 0450 starting with first exams in 2027). Confirmed
  via the config and corroborated by external search before attempting any
  download.
- **Art_and_Design_0400** and **Digital_Media_and_Design_9481**: both are
  coursework/portfolio subjects (open-ended project briefs, externally
  moderated) rather than conventional structured exam papers; their past
  papers use inconsistent/non-standard file-naming conventions on the
  source site and are a poor fit for this question-by-question topic
  classification methodology.
- **English_Literature_0477**: this specific "UK-only (9-1)" code does not
  appear to have a conventional November/June 2023 sitting under its own
  code (searches only surfaced 0475/0992 papers for that session).

These were replaced with Literature_in_English_0475, English_Second_
Language_0510, Urdu_0539 (itself later unavailable and replaced with
English General Paper 8021 and Spanish 9719), and French_9716 — all
confirmed genuine before the run. Pakistan_Studies_0448 also needed
non-standard filename handling (question papers use 2-digit variant
numbers `01`/`02` while its mark schemes use single-digit `1`/`2` — the
two conventions were matched up manually).

## 3. Pipeline result

```
RUN COMPLETE — REVIEW REQUIRED   (exit code 2)
35 stages, 163 checks passed
117 questions saved
52 review-required directories (45 individual questions across 2 papers)
```

## 4. Manual review: 117/117 correct — no fixes needed this batch

| Subject | Questions | Correct/defensible | Notes |
|---|---:|---:|---|
| Music_0410 | 41 | 41/41 | Listening paper; correctly split into skill-based `Listening`, period/set-work `Western_classical_music`, and `World_music` (Rajasthani folk music extract) sections. Flagged `review_required_no_markscheme` (whole paper) |
| English_Second_Language_0510 | 15 | 15/15 | Reading comprehension exercises + 2 writing tasks, all correct |
| Pakistan_Studies_0448 | 10 | 10/10 | Paper 1 (history/sources) correctly split Pakistan Movement vs Nationhood; Paper 2 (geography) correctly split Natural resources / Power / Agriculture / Industry / Population |
| Classical_Studies_9274 | 9 | 9/9 | Correctly splits Roman History (Augustus, the Aeneid) vs Classical Art and Architecture (Pompeii/Herculaneum houses, temples) |
| German_0525 | 6 | 6/6 | Reading/listening comprehension; several defensible near-ties across overlapping theme areas (same pattern as Batch 5's French/Spanish) |
| Spanish_0530 | 6 | 6/6 | Same pattern as German_0525 |
| Islamiyat_0493 | 5 | 5/5 | Hadiths, Rightly Guided Caliphs, Pillars of Islam, Articles of Faith — all correct |
| French_9716 | 5 | 5/5 | A-Level reading/writing; defensible near-ties across theme areas |
| German_9717 | 5 | 5/5 | Same pattern |
| Spanish_9719 | 5 | 5/5 | Same pattern |
| English_Language_9093 | 4 | 4/4 | 4 distinct writing-genre questions, each correctly matched to its named section. Flagged `review_required_no_markscheme` (whole paper) |
| Physical_Education_9396 | 3 | 3/3 | Correctly split by syllabus section (Applied anatomy and physiology / Skill acquisition / Sport and society) |
| English_General_Paper_8021 | 2 | 2/2 | Argument analysis + comprehension, correct |
| Literature_in_English_0475 | 1 | 1/1 | Twelfth Night extract (Orsino/Antonio), correctly tagged `Drama` with accurate detailed topics |
| **Total** | **117** | **117/117** | **Zero new defects — first batch with no fixes needed** |

## 5. `review_required_no_markscheme`: now confirmed across 6 papers in 3 batches

Two more papers (Music_0410, English_Language_9093 — 45 questions, both
100% of their paper) hit the same mark-scheme structural-segmentation gap
in `core/markscheme_split_gold.py` documented in Batches 4 and 5. That
makes **6 real papers across the last 3 batches** (ICT_0417, History_0470,
Physical_Education_0413, Global_Perspectives_9239, Music_0410,
English_Language_9093) — all correctly classified from QP text alone and
safely flagged for review, never silently mis-paired. This is now a firmly
established, recurring weak spot in the segmenter worth a dedicated
engineering pass; it has not been investigated further at the per-paper
root-cause level in this batch since Batch 4/5 already diagnosed the
general mechanism (expected-vs-found marker count mismatch) in detail.

## 6. Environment note: dependencies must be reinstalled before every run

Mid-batch, `python3 main.py` failed with `ModuleNotFoundError: No module
named 'fitz'` even though the same dependency had been reinstalled earlier
in the same working session (after being wiped between conversation turns,
as already noted in Batch 5). This confirms pip-installed packages in this
sandbox are not reliably durable even within a single long session, not
just across turns — `pip install -r requirements.txt` should be re-run
immediately before every pipeline invocation as a defensive habit, not just
once per conversation.

## 7. Cumulative real-paper evidence after Batches 1–6

| Phase | Subjects | Questions reviewed | Correct/defensible |
|---|---:|---:|---:|
| Phase 1 | 5 | 80 | 80/80 (100%) |
| Phase 2 | 8 | 104 | 102/104 (98.1%, 1 disclosed MS-splitting defect) |
| Phase 3 | 13 | 105 | 103/105 (98.1%, 2 disclosed full-auto forced-default edge cases) |
| Phase 4 | 13 | 130 | 130/130 (100% topic-correct; 2 disclosed engine limitations + 1 QP content-merge defect) |
| Phase 5 | 13 | 83 | 83/83 (100% after 1 live keyword fix) |
| Phase 6 (this batch) | 14 | 117 | 117/117 (100%, zero fixes needed) |
| **Total** | **61 unique CAIE subjects** | **619** | **615/619 (99.4%)** |

**Still outstanding:** 20 more untested CAIE subjects, and all of AQA (46),
Edexcel (44), IB (30), and SAT (2) — 142 configs remain unverified against
real papers.

**Fixes committed across all batches so far:** 4 config-level keyword/
normalization fixes (Batch 3 ×3, Batch 5 ×1), all verified against the
2056-question golden set and 105-test pytest suite with zero regressions.

**Recurring limitation tracked across batches (not fixed, outside
config-keyword scope):** mark-scheme structural segmentation failure in
`core/markscheme_split_gold.py`, now observed on 6 of the last 39 real
mark schemes tested (~15%) — always safely caught and disclosed via
`review_required_no_markscheme`, never causing a silent misclassification.
