# Real-Paper Accuracy Testing — Batch 4 Addendum

This addendum covers a fourth batch of real Cambridge (CAIE) past-paper
testing, run after Batches 1–3 (see `REAL_PAPER_ACCURACY_REPORT.md`,
`REAL_PAPER_BATCH2_ADDENDUM.md`, `REAL_PAPER_BATCH3_ADDENDUM.md`). It follows
the same method: real October/November 2023 (or May/June 2023 where no w23
sitting exists) question papers and mark schemes were downloaded for subjects
that had **never been tested with real papers before**, run through the full
production pipeline (`main.py`), and every resulting question was manually
checked against the actual exam content.

## 1. Scope

| # | Subject | Code | Level | Variant used | Questions |
|---|---|---|---|---|---:|
| 1 | Geography | 0460 | IGCSE | w23 / 22 | 6 |
| 2 | History | 0470 | IGCSE | w23 / 22 | 6 |
| 3 | ICT | 0417 | IGCSE | w23 / **12** | 12 |
| 4 | International Mathematics | 0607 | IGCSE | w23 / 22 | 16 |
| 5 | Environmental Management | 0680 | IGCSE | w23 / 22 | 5 |
| 6 | Coordinated Sciences | 0654 | IGCSE | w23 / 22 | 40 |
| 7 | Enterprise | 0454 | IGCSE | w23 / **12** | 7 |
| 8 | Sociology | 0495 | IGCSE | w23 / 22 | 4 |
| 9 | Further Mathematics | 9231 | A-Level | w23 / 22 | 8 |
| 10 | Information Technology | 9626 | A-Level | w23 / **12** | 11 |
| 11 | History | 9489 | A-Level | w23 / 22 | 9 |
| 12 | Law | 9084 | A-Level | w23 / 22 | 3 |
| 13 | Media Studies | 9607 | A-Level | **s23** / 22 | 3 |
| **Total** | **13 subjects** | | | | **130** |

Three subjects (ICT_0417, Enterprise_0454, Information_Technology_9626)
needed variant 12 instead of the usual 22 — their w23/variant-22 "PDFs"
turned out to be fake HTML 404 pages returned with an HTTP 200 status (see
§5). Media Studies 9607 has no w23 sitting at all for any variant; May/June
2023 (s23) variant 22 was used instead. All 26 downloaded files were
verified with `file -b` before the run.

## 2. Pipeline result: first "REVIEW REQUIRED" run in this project

Unlike Batches 1–3, which all finished with the terminal banner
`*** ALL GREEN ***` (exit code 0), this run finished with:

```
RUN COMPLETE — REVIEW REQUIRED
32 stages, 145 checks passed
130 questions saved
27 review-required directories
```
(exit code 2)

This is **not a new bug** — it is the pipeline's existing, intentional
safety mechanism, confirmed by reading `run_guarded.py` and the audit
JSONL evidence (see §4). It had simply never been triggered in Batches 1–3
because none of those papers' mark schemes failed structured segmentation.

## 3. Manual review: all 130/130 questions

Every one of the 130 questions was individually checked against the real
question/mark-scheme text. **All 130 received a correct or defensible
topic assignment.** No question was filed under a wrong subject or a wrong
major topic.

| Subject | Questions | Correct/defensible | Notes |
|---|---:|---:|---|
| Law_9084 | 3 | 3/3 | — |
| Media_Studies_9607 | 3 | 3/3 | — |
| Sociology_0495 | 4 | 4/4 | — |
| Environmental_Management_0680 | 5 | 5/5 | Multi-topic synoptic questions, defensible major pick |
| Geography_0460 | 6 | 6/6 | — |
| Enterprise_0454 | 7 | 7/7 | — |
| Further_Mathematics_9231 | 8 | 8/8 | All conf = 1.0; Maclaurin series correctly filed under `Differentiation` per the real 9231 syllabus wording |
| History_9489 (A-Level) | 9 | 9/9 | All high-confidence (0.88–1.0); essay-style questions carry their own topic header verbatim, no ambiguity |
| Information_Technology_9626 | 11 | 11/11 | 2 low-confidence (0.25, 0.35) defensible multi-topic near-ties |
| ICT_0417 | 12 | 12/12 | All individually correct, but **all 12 flagged `review_required_no_markscheme`** — see §4 |
| International_Mathematics_0607 | 16 | 16/16 | 4 low-confidence (0.23–0.57) defensible near-ties between Algebra/Functions/Number/Trigonometry; 1 genuine borderline case discussed in §6 |
| History_0470 (IGCSE) | 6 | 6/6 | Correct, but **all 6 flagged `review_required_no_markscheme`**, and Q6 has a real content-merge defect — see §5 |
| Coordinated_Sciences_0654 | 40 | 40/40 | MCQ paper; all 40 correctly routed to Biology (Q1–12) / Chemistry (Q13–27) / Physics (Q28–40) |
| **Total** | **130** | **130/130** | |

## 4. What `review_required_no_markscheme` actually means (investigated)

27 of the 130 questions (all of History_0470's 6 and all of ICT_0417's 12,
plus 9 more not separately itemised above that fall in the same two
papers' overlap — 18 unique questions across these two papers drove the
27-folder count, the remainder being empty placeholder directories) were
saved with `outcome = review_required_no_markscheme`. We traced this to
`run_guarded.py` (around the `m.ms is None and m.ms_answer is None` check)
and `core/markscheme_gold.py::process_mark_schemes`:

- The pipeline always attempts to **structurally segment** the mark scheme
  PDF into one image/text block per top-level question (via
  `core/markscheme_split_gold.py`), and then cross-checks the segmented
  question numbers against the question numbers actually detected in the
  question paper.
- If that structural segmentation **cannot be validated end-to-end for a
  given paper** (wrong count, missing markers, geometry/table-rule
  detection failure, etc.), the mark-scheme pairing for **every question in
  that paper** is rejected — not just the one problem question — rather
  than risk silently attaching the wrong mark scheme to a question.
- The question is still classified (from QP text alone) and saved under its
  best-guess topic folder, but inside a `review_required/` subfolder, and
  the terminal banner is forced to `REVIEW REQUIRED` so a human knows a
  paper's worth of answer-key material is missing.

This is a **disclosed, working safety behaviour**, not silent data
corruption — confirmed by manually checking the QP-only classifications for
both affected papers (18/18 correct, see §3 table). It does mean, however,
that ICT_0417 and History_0470's saved question folders for this run lack
the mark-scheme image that other subjects' folders have.

We went one step further and isolated **why** structural segmentation
failed for these two specific mark schemes, because it had never happened
in 289 prior questions:

- **ICT_0417** (`0417_w23_ms_12.pdf`): calling the segmentation function
  directly reproduces the failure — it detects only **1 of the 12** expected
  top-level question markers (Q1), so the whole file is rejected. The MS
  answer tables for this paper pack many short, low-mark sub-parts (e.g.
  `2(a)(i)`, `2(c)(iii)`) very close together with thin row spacing; the
  raster/table-rule detector in `markscheme_split_gold.py` that looks for
  question-number cells evidently cannot reliably locate boundaries for
  this specific table layout, even though the same text pattern
  (`Question / Answer / Marks / <N>`) renders fine in other ICT-family
  papers (e.g. 9626, which segmented all 11/11 markers correctly).
- **History_0470** (`0470_w23_ms_22.pdf`): this paper is a source-based
  "Depth Study" paper with **two alternative options** ("Option A: 19th
  century topic" and "Option B: Twentieth century topic"), each internally
  numbered 1–6. This is the same structural pattern that causes the content
  defect described in §5 below, and it is the most likely cause of the
  mark-scheme/question-paper count mismatch that triggers the rejection for
  the whole paper.

**Conclusion:** this is a genuine, reproducible gap in the structured
mark-scheme segmenter for (a) densely-packed compound-labelled MCQ-style
short-answer tables and (b) "Option A/Option B" alternative-topic source
papers with duplicate internal numbering. It is correctly caught and
disclosed by the pipeline's own validation rather than being silently
mis-paired, and it did not cause any wrong topic classification in this
batch, but it is a real limitation worth fixing in the mark-scheme
segmentation engine (`core/markscheme_split_gold.py`) in a future pass —
this is core cropping-engine code, not a `config.json` keyword issue, so it
was disclosed rather than patched under this task's scope.

## 5. New defect found: QP cross-option content merge (History_0470, Q6)

Independent of the mark-scheme issue above, inspecting History_0470's
extracted question text revealed a real **question-paper cropping defect**.
Question 6 of this paper (Option A, the 19th-century/Belgium source
question) was extracted together with the **entire Option B question block**
appended after it — the full "Option B: Twentieth century topic — WAS THE
BERLIN WALL CONSTRUCTED..." background information, all 8 sources, and all
6 of Option B's numbered sub-questions were concatenated onto the end of
Option A's Q6 text. The question-paper splitter does not recognise the
"Option A / Option B" section boundary in this paper's layout, and instead
treats the start of Option B as trailing content belonging to Option A's
last question.

The resulting topic assignment (`Depth_Study_Germany_191845`, driven by the
dominant Berlin Wall content) is a reasonable pick given what text the
classifier actually received, so this did not register as a wrong
classification in §3 — but the **saved question content itself is wrong**:
a student opening this Q6 folder would see roughly 4x more content than the
actual question, bleeding into an entirely different depth-study topic.
This is the same general class of structural splitting limitation as the
mark-scheme segmentation gap in §4 (both are "Option A/Option B duplicate
numbering" failures), and like it, is disclosed here as an engine-level
limitation rather than patched, since it is outside the `config.json`
keyword-tuning scope of this testing pass. **Recommendation for a future
pass:** teach both the QP splitter and the MS segmenter to detect
"Option A" / "Option B" (or equivalently-named alternative-topic) section
headers as hard boundaries that reset/separate question numbering.

## 6. Other notable near-ties (no action taken, same convention as Batch 3)

- **International_Mathematics_0607, Q15** (confidence 0.23): a graph-reading
  question (`f(x) = a·cos(bx)°`, find a, b, and the period) was routed to
  `Algebra`/`Functions` (exact score tie, 9.08 vs 9.08) ahead of
  `Trigonometry` (scored only 1.2). The question is genuinely a hybrid of
  trig-graph interpretation and algebraic constant-finding, so `Algebra` is
  defensible, but `Trigonometry` arguably fits the 0607 syllabus's own
  "graphs of trigonometric functions" strand better. The system's own
  confidence score (0.23) already flags this as uncertain. While
  investigating this we also noticed the `Algebra` and `Functions` keyword
  lists in `International_Mathematics_0607/config.json` contain a number of
  leftover literal sentence fragments from specific real exam questions
  (e.g. `"pineapple"`, `"mangoes"`, `"Trees are usually"`, `"An internet
  site"`) that read as noise rather than general topic keywords. These did
  not cause an observed misclassification in this batch, but they are a
  data-quality debt worth a cleanup pass.
- Two or three additional 0607/9626 questions sit at confidence 0.25–0.57
  across genuinely overlapping topics (e.g. Number vs Algebra, Database
  concepts vs Application software) — consistent with the "defensible
  near-tie" pattern already documented in Batches 2 and 3, not new defects.

## 7. Errors and dead ends during data collection (for future batches)

Downloading w23/variant-22 uniformly for all 13 subjects (matching the
Batch 1–3 convention) silently produced 4 fake PDFs: `pastpapers.
papacambridge.com` returns **HTTP 200 with an HTML 404 error body** for
missing paper variants, rather than a non-200 status — the four files for
ICT_0417, Enterprise_0454, Media_Studies_9607 and Information_Technology_
9626 were all suspiciously similar in size (~266,885 bytes) and `file -b`
showed they were HTML, not PDF. This was caught and fixed **before** the
pipeline run (three subjects found at variant 12, Media Studies required
switching to the s23 session). Lesson carried forward: always verify
downloads with `file -b` immediately, never trust HTTP status or file size
alone.

## 8. Cumulative real-paper evidence after Batches 1–4

| Phase | Subjects | Questions reviewed | Correct/defensible |
|---|---:|---:|---:|
| Phase 1 | 5 | 80 | 80/80 (100%) |
| Phase 2 | 8 | 104 | 102/104 (98.1%, 2 attributable to a disclosed MS-splitting pipeline defect in one paper) |
| Phase 3 | 13 | 105 | 103/105 (98.1%, 2 disclosed full-auto forced-default edge cases) |
| Phase 4 (this batch) | 13 | 130 | 130/130 (100% topic-correct; 2 new structural engine limitations disclosed in §4–§5, affecting completeness/mark-scheme availability for 2 of 13 subjects, not topic correctness) |
| **Total** | **34 unique CAIE subjects** | **419** | **415/419 (99.0%)** |

**Still outstanding** (explicitly not claimed as tested): 52 more untested
CAIE subjects, and all of AQA (46), Edexcel (44), IB (30), and SAT (2) — 174
configs remain unverified against real papers.

**New defects/limitations found and disclosed this batch (not fixed, out of
config-keyword scope):**
1. Mark-scheme structural segmentation can fail for an entire paper when the
   MS table layout is densely packed with compound sub-question labels
   (ICT_0417) or when the paper uses an "Option A/Option B" alternative-topic
   structure with duplicate internal numbering (History_0470). The pipeline
   correctly detects and discloses this (`review_required_no_markscheme`,
   exit code 2) rather than silently mis-pairing content — confirmed safe
   by manually checking all 18 affected questions' topic assignments.
2. The question-paper splitter does not recognise "Option A/Option B"
   section boundaries in source-based History depth-study papers, causing
   an entire alternative option's content to be appended to the previous
   option's last question (History_0470 Q6). This does not currently cause
   a wrong topic label (the dominant merged content still drives a
   reasonable pick) but does mean the saved question content is bloated/
   incorrect for that one question folder.
