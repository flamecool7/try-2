# Real-Paper Accuracy Addendum — Edexcel Batch 3

**Scope:** A third, independent batch of real Edexcel exam papers, deliberately chosen to extend coverage
into subjects and qualification levels not touched by Batch 1 (13 subjects) or Batch 2 (10 subjects),
and specifically to test whether a pattern observed in Batches 1–2 — "only Mathematics-family Edexcel
papers escape the `_Q_START` regex defect" — holds at GCSE tier as well as A-level/IGCSE.

10 subjects, 20 files (QP + MS pairs), all genuine, officially-sourced past papers downloaded from
Physics & Maths Tutor (`pmt.physicsandmathstutor.com`) and Revision World (`revisionworld.com`), both of
which host unmodified Pearson/Edexcel-published PDFs:

| # | Subject | Code | Level | Series |
|---|---|---|---|---|
| 1 | Mathematics (Higher, Paper 1) | 1MA1/1H | GCSE | June 2023 |
| 2 | English Literature (Paper 1) | 9ET0/01 | A-level | June 2023 |
| 3 | History (Paper 1, Option 1A) | 9HI0/1A | A-level | June 2023 |
| 4 | History (Paper 1, Option 10) | 1HI0 | GCSE | June 2023 |
| 5 | Geography A (Paper 1) | 1GA0/01 | GCSE | June 2023 |
| 6 | English Language (Paper 1) | 9EN0/01 | A-level | June 2023 |
| 7 | Computer Science (Paper 1) | 4CP0/01 | IGCSE | June 2023 |
| 8 | Business (Paper 1) | 1BS0/01 | GCSE | June 2023 |
| 9 | Religious Studies (Paper 1) | 9RS0/01 | A-level | November 2021 |
| 10 | Physical Education (Component 1) | 1PE0/01 | GCSE | June 2023 |

All 20 downloads verified `%PDF` header and HTTP 200 before the run; three QPs were spot-checked with
direct text extraction and confirmed to be clean, text-layer-native exam papers with normal question
numbering (e.g. `1 Work out 8.46 ÷ 0.15`, `1 Explore the ways in which Shakespeare uses...`) — ruling out
"bad/scanned source file" as an explanation for anything found below.

`tools/run_universal_batch.py --input input/batch_edexcel3 --output output/batch_edexcel3_run --jobs 1`
completed without crashing. Batch stats: `question_packs: 14, render_attempts: 10, render_pass: 10,
render_fail: 0, companion_attempts: 10, companion_pass: 4, companion_review: 6, ms_segments: 22`.
Taken at face value these numbers look like the healthiest run of the whole campaign. **Manual inspection
of every output folder shows the opposite: this is the worst-performing Edexcel batch yet, on a new axis
not fully exposed by Batches 1–2.**

## 1. Headline finding: 100% Question Paper content loss, across all 10 subjects, all 3 qualification levels

For **every one of the 10 QP files**, `segments.json` is a literal empty array `[]` and zero `.webp`
files were rendered:

| Subject code | QP segments | QP webps |
|---|---|---|
| 1MA1/1H | 0 | 0 |
| 9ET0/01 | 0 | 0 |
| 9HI0/1A | 0 | 0 |
| 1HI0 | 0 | 0 |
| 1GA0/01 | 0 | 0 |
| 9EN0/01 | 0 | 0 |
| 4CP0/01 | 0 | 0 |
| 1BS0/01 | 0 | 0 |
| 9RS0/01 | 0 | 0 |
| 1PE0/01 | 0 | 0 |

This is not confined to one subject family, one qualification level, or one source site — it spans
Maths, English Literature, English Language, History (×2, A-level and GCSE), Geography, Computer
Science, Business, Religious Studies and PE, across GCSE/IGCSE/A-level, sourced from two different
hosting sites. In every single case, `contract_report.json` for the QP folder reports:

```json
{"board": "EDEXCEL", "contract_version": 1, "issues": [], "status": "PASS"}
```

The pipeline marks a folder containing **zero extracted questions** as a clean `PASS` with **zero
issues**. There is no signal anywhere in the output tree that would tell a user browsing the final
output that the question papers — the primary deliverable — never rendered a single page. This is the
same "silent total content loss, no flag raised" pattern documented in the AQA, IB and SAT addenda, now
confirmed on the QP side specifically and at 100% incidence in this batch.

## 2. Mark Scheme side: partial recovery in 4/10 subjects, total failure in 6/10

| Subject code | MS segments | MS webps |
|---|---|---|
| 1MA1/1H | 5 | 5 |
| 1PE0/01 | 13 | 13 |
| 4CP0/01 | 2 | 4 |
| 9EN0/01 | 2 | 2 |
| 9ET0/01 | 0 | 0 |
| 9HI0/1A | 0 | 0 |
| 1HI0 | 0 | 0 |
| 1GA0/01 | 0 | 0 |
| 1BS0/01 | 0 | 0 |
| 9RS0/01 | 0 | 0 |

Net result across the whole 10-subject, 20-file batch: **6 of 10 subjects produced absolutely zero
usable content of any kind** (English Literature 9ET0, A-level History 9HI0, GCSE History 1HI0, GCSE
Geography 1GA0, GCSE Business 1BS0, A-level Religious Studies 9RS0) — both their QP and MS came back
completely empty, despite being verified, valid, text-layer PDFs of real, official exam papers. The
other 4 subjects got partial content, but only from the MS file, never the QP, and (see §3) that content
is not reliably attributable to the right subject on disk.

## 3. New defect: cross-subject question-number collision silently overwrites real content

Where subject identification fails (routed to the generic `EDEXCEL/UNKNOWN` program bucket, as happened
to all 10 MS files and 5 of the 10 QP files), the pack-assembler still tries to group pages into
question-numbered packs under `UNKNOWN/<date>/review_required/TOPIC_UNKNOWN/Q<n>/`. Because every exam
paper has a "Question 1", **packs from entirely different subjects collide on the same folder name**, and
the later one processed wins — overwriting the earlier one on disk with no warning.

Confirmed directly: `TOPIC_UNKNOWN/Q1/metadata.json` lists three claimed sources for its `Q1_MS.webp`:

```json
"ms": [
  ".../TOPIC_UNKNOWN/Q1/Q1_MS.webp",
  ".../TOPIC_UNKNOWN/Q1/Q1_MS.webp",
  ".../TOPIC_UNKNOWN/Q1/Q1_MS.webp"
]
```

— i.e. GCSE PE (1PE0), IGCSE Computer Science (4CP0), and A-level English Language (9EN0) each had a
rendered "Q1" mark-scheme page that the assembler tried to place in this same slot. Visually inspecting
the one surviving `Q1_MS.webp` file confirms it is **the English Language (9EN0) mark scheme** (Text
A/Text B phonology/lexis/semantics/discourse-analysis mark grid, with the AO1–AO4 marking grid at the
bottom — unmistakably 9EN0 Paper 1, "Variation over Time" paper). The real PE Q1 and Computer Science Q1
mark-scheme content that also mapped to this slot **no longer exists anywhere in the output** — not
quarantined, not logged as a conflict, just gone. `pack_index.json` for this bucket shows all 14 packs
flagged `TOPIC_UNKNOWN` and, simultaneously, `MISSING_QP` — a double-defect combination (wrong subject
*and* no question paper half) baked into every single pack this batch produced in that bucket.

This is a materially different and more serious failure mode than anything surfaced in Batches 1–2 of
this board: previously, mis-filing put a document in the *wrong* folder but it was still recoverable by
manually moving it. Here, two of three colliding documents are **destroyed outright**, with the surviving
metadata actively misleading a user into thinking all three are preserved under that path.

## 4. Subject/program identification: inconsistent and mostly wrong

- **QP subject ID**: 5 of 10 correctly resolved to their real subject-code bucket (1MA1_1H, 9EN0_01,
  9ET0_01, 9HI0_1A, 9RS0_01); the other 5 (1HI0, 1GA0, 1BS0, 1PE0, 4CP0) fell into the generic
  `EDEXCEL/UNKNOWN` bucket despite being just as clean, text-native, and clearly Edexcel-branded as the
  other five.
- **MS subject ID**: 9 of 10 fell into `EDEXCEL/UNKNOWN` regardless of whether their matching QP succeeded
  or failed. Only one MS (9HI0/1A) was correctly filed under its real subject bucket — and even that one
  correctly-filed MS pack contains zero rendered content (§2), so the one case of correct routing produced
  no actual benefit.
- **Date/series detection**: even where subject ID succeeded, the date sub-folder was usually wrong — 4 of
  the 5 correctly-subject-bucketed QPs were filed under a literal `UNKNOWN_2023`/`UNKNOWN_2021` date
  folder rather than `June_2023`/`November_2021`. Only 9HI0's MS got the date right.

No combination of (board, program, series, document-type) was fully correct and populated with content
for any one of the 10 subjects in this batch.

## 5. Correction to the Batch 1/2 "Mathematics escapes the regex bug" finding

Batches 1 and 2 observed that Mathematics-family Edexcel papers (A-level 9MA0/9FM0, IGCSE 4MA1/4MB1) were
the *only* subjects whose questions survived the `_Q_START` regex defect that silently destroyed ~91% of
content elsewhere. Batch 3 was deliberately designed to test whether that held at GCSE tier too
(1MA1/1H). **It does not, in this run**: GCSE Mathematics' QP produced zero segments, identically to every
non-Mathematics subject tested in this batch. Its MS produced a sparse 5-question subset (Q2, Q4, Q6,
Q13, and an anomalous "Q56" label that does not correspond to a real question number on a ~24-question
paper, suggesting a further number-parsing artifact on top of everything else).

**Revised conclusion**: the earlier "Mathematics survives" pattern was a property of the *specific* source
files and/or the *specific pipeline code path* exercised in Batches 1–2, not a general rule that
Mathematics-formatted content is immune to Edexcel's structural defects. In this batch, no subject —
Mathematics included — escaped the QP total-failure pattern described in §1.

## 6. Net yield of this batch

Of 10 subjects attempted, with real, valid, official papers for every one:

- **0 of 10** produced a correctly-filed, content-complete, QP+MS-paired output.
- **0 of 10** produced any usable Question Paper content at all.
- **4 of 10** (1MA1, 9EN0, 4CP0, 1PE0) produced *some* Mark Scheme content, but misfiled under the wrong
  program bucket and, in at least one confirmed case (1PE0's Q1), destroyed by the collision bug in §3
  before it ever reached a reviewer.
- **6 of 10** (9ET0, 9HI0, 1HI0, 1GA0, 1BS0, 9RS0) produced **nothing** — not one rendered page, from
  either the QP or the MS, despite clean source files.

This is the lowest success rate of any batch in the entire real-paper campaign (worse than Edexcel
Batches 1–2's already-poor ~50% subject-level pass rate, worse than AQA's degrading-but-partial results,
and comparable in severity only to IB's near-total failure).

## 7. Not attempted

This batch leaves 11 of the original 21 untested Edexcel subjects still unexplored: A-level
Design_and_Technology (9DT0), Drama_and_Theatre (9DR0), Law (9LW0), Sociology (9SC0); GCSE
Computer_Science (1CP2), Design_and_Technology (1DT0), Drama (1DR0), French (1FR0), Mathematics
(1MA1 — only Higher Paper 1 tested here; Foundation tier and Papers 2/3 untested), Music (1MU0),
Religious_Studies (1RA0), Spanish (1SP0).

## 8. Conclusion

Taken together with Batches 1–2, Edexcel's three real-paper batches show a board adapter whose behavior
is inconsistent not just across subjects but across *runs on the same subject family* — the same
Mathematics-code behavior that was rock-solid in Batches 1–2 did not reproduce in Batch 3. Combined with
the newly-discovered cross-subject collision/overwrite bug (§3), the practical implication is that Edexcel
output cannot currently be trusted even when the pipeline's own summary numbers (`render_pass: 10/10`,
`ms_segments: 22`) look healthy — the only way to know what actually reached a user is to open every pack
and check it against the source PDF by hand, which is what this batch did.
