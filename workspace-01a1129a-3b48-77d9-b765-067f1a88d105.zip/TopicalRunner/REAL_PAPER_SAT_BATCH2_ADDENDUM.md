# Real-Paper Validation Addendum — SAT / College Board Batch 2 (PSAT/NMSQT, the adapter's own claimed baseline)

**Status: `config/boards/sat.yaml` states the SAT adapter was "independently VERIFIED on both real PSAT papers (120 segments each ... zero id collisions)". This batch re-ran that exact program (PSAT/NMSQT Practice Tests 1 and 2) through the full `run_universal_batch.py` pipeline — the same pipeline used for every other board in this project — rather than whatever narrower check produced that YAML claim. Result: every defect found in `REAL_PAPER_SAT_BATCH1_ADDENDUM.md` reproduces identically on the adapter's own supposedly-verified paper. The "120 segments" claim is true only at the text-identification layer; through the real pipeline, 87 of those 120 segments (72.5%) never reach a rendered image on either test.**

## 0. Scope

Two bundles (6 PDFs: QP, Scoring Guide, Answer Explanations each) sourced the same way as Batch 1 — free, official, no-login `satsuite.collegeboard.org` PDFs, all HTTP 200 and `%PDF`-verified:

| Bundle | Program |
|---|---|
| PSAT/NMSQT Practice Test 1 | PSAT/NMSQT |
| PSAT/NMSQT Practice Test 2 | PSAT/NMSQT |

This is the specific program `config/boards/sat.yaml` names as the one used to validate the adapter before this project's audits began.

## 1. The module-render dropout reproduces exactly, on both tests

`segments.json` for both `PSATNMSQT_PracticeTest1_QP` and `PSATNMSQT_PracticeTest2_QP` correctly contains all **120 segments** each, spanning all four modules (RW Module 1: 33, RW Module 2: 33, Math Module 1: 27, Math Module 2: 27) — this matches the YAML's own claim precisely. But on both tests, only **33 of the 120 segments** (Reading and Writing Module 1 only) were ever rendered into an actual `.webp` image. The other 87 segments per test — all of RW Module 2, Math Module 1, and Math Module 2 — are correctly identified in the data but never produced as deliverable output. This is the identical failure mode documented in Batch 1 §2, now confirmed on the adapter's own reference program, not just on the three programs Batch 1 introduced.

This resolves the open question from Batch 1 §7: the config's "VERIFIED ... 120 segments each" claim describes what the segmentation/identification stage finds, not what a real end-to-end run through `run_universal_batch.py` delivers. Whatever check produced that YAML claim did not exercise the rendering stage, or exercised it in a way that didn't surface this dropout.

## 2. The Scoring Guide misfile reproduces, this time crossing in the opposite direction

Both `PSATNMSQT_PracticeTest1_Scoring.pdf` and `PSATNMSQT_PracticeTest2_Scoring.pdf` were again classified `document_type: QP` and filed inside a `QP/` folder (Batch 1 §3's exact pattern). This time the program misattribution runs the other way: both genuine **PSAT/NMSQT** scoring guides were filed under component **`PSAT_8_9_T1`** / **`PSAT_8_9_T2`** — a different program entirely. Combined with Batch 1's finding (an SAT scoring guide filed under `PSAT_8_9_T4`), every scoring guide tested across both SAT batches — three for three — has landed under a `PSAT_8_9_*` bucket regardless of its real source program. This is not random noise: it strongly suggests `PSAT_8_9` is a hardcoded fallback/default component value reached whenever the identifier fails to find clear program evidence in a document (which Scoring Guides, apparently, never carry in a form the identifier recognizes), rather than the identifier correctly reporting the program as UNKNOWN.

## 3. Answer Explanations are dropped entirely, again

Neither `PSATNMSQT_PracticeTest1_AnswerExplanations.pdf` nor `PSATNMSQT_PracticeTest2_AnswerExplanations.pdf` appears anywhere in the final output — the same `document_type: UNKNOWN` fate documented in Batch 1 §3. `companion_attempts: 0` for this batch confirms no pairing was ever attempted, same as Batch 1.

## 4. Net conclusion

Every finding in `REAL_PAPER_SAT_BATCH1_ADDENDUM.md` (§2 module dropout, §3 Scoring Guide/Answer Explanations misclassification, §4 program-identification unreliability) reproduces at a 100% rate on the two test forms the adapter's own documentation cites as its validation baseline. There is no real-paper evidence, across either SAT batch run in this project, of a test form that survived the full pipeline with all four modules intact and correctly paired with its own answer content. The `BOARD_DISPATCH_WIRED` / `"independently VERIFIED"` language in `config/boards/sat.yaml` should be read as describing a narrower, earlier check than the one this project's addenda perform, and should not be taken to mean the adapter produces complete, correctly-labeled output through the production pipeline.

## 5. What was not attempted

- No code fix for the render dropout or the Scoring-Guide default-component bug.
- The renderer was not traced to find exactly where in the pipeline modules 2–4 are discarded (e.g., a hardcoded page-range limit, a per-document render budget, or a crash that's caught and silently ignored per module).
- PSAT 10 Practice Test 2 and PSAT 8/9 Practice Tests 2–3 (additional bundles available from the same free source) were not sourced; given the 100% reproduction rate across five test forms now tested (3 in Batch 1, 2 here), further SAT-board batches are unlikely to surface new information until the render-dropout defect is fixed.
