#!/usr/bin/env python3
"""
tools/research/fetch_board_sources.py — download OFFICIAL board specification
documents into docs/research/<board>/ with a provenance manifest.

Why this exists (directive §21 REAL-PAPER RESEARCH RULE, spec §11.13):
    Taxonomies must be built from the official documents themselves. Typing topic
    lists from memory is exactly the SOURCE_NOT_FOUND shortcut the spec forbids.

Guarantees:
  * Every download is sha256-hashed and size-recorded.
  * Content is VALIDATED as a real PDF (%PDF magic) — an HTML error page saved
    with a .pdf extension is detected and rejected, never silently accepted.
  * Known sentinel: Pearson returns a generic 152,114-byte HTML page for a wrong
    path (recorded in TOPICS-FROM-OWN-CORPUS.txt Part 10). Any 152114-byte
    "pdf" is a miss, not a block.
  * Nothing is fabricated. A failure is recorded as SOURCE_NOT_FOUND or
    SOURCE_NOT_ACCESSIBLE and the build must proceed without it.
  * Polite: sequential requests with a delay, real User-Agent, no control bypass.

Usage:
    python tools/research/fetch_board_sources.py            # fetch all
    python tools/research/fetch_board_sources.py --board AQA
    python tools/research/fetch_board_sources.py --list
    python tools/research/fetch_board_sources.py --dry-run
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT))

RESEARCH_DIR = ROOT / "docs" / "research"
MANIFEST = RESEARCH_DIR / "sources_manifest.json"

PDF_MAGIC = b"%PDF"
MIN_PDF_BYTES = 20_000
REQUEST_DELAY_S = 2.0
TIMEOUT_S = 90
USER_AGENT = ("UniversalExamTopicalGenerator/2.0 "
              "(taxonomy research; respectful single-threaded fetch)")

# Pearson's generic 404 HTML page, observed at exactly this size.
PEARSON_404_SENTINEL_BYTES = 152_114


@dataclass
class Source:
    board: str
    subject: str
    code: str
    version: str                 # specification edition / issue / first-assessment
    url: str
    filename: str
    kind: str = "specification"  # specification | framework | subject_brief | technical_manual
    expected_sha256_prefix: str = ""   # from the corpus, when recorded
    expected_bytes: Optional[int] = None
    notes: str = ""


# ---------------------------------------------------------------------------
# SOURCE QUEUE
# Every entry is a URL recorded in TOPICS-FROM-OWN-CORPUS.txt / TOPICS-ADDITIONS.txt
# (fetched 2026-09-19 by the corpus author) or in the governing spec. Where the
# corpus recorded a sha256 prefix it is carried here so a re-fetch can be
# verified against the previously proven document.
# ---------------------------------------------------------------------------
SOURCES: List[Source] = [
    # ---- SAT / College Board (PROVEN URLs, corpus Part 3/6) ----------------
    Source("SAT", "SAT Suite", "digital", "assessment framework",
           "https://satsuite.collegeboard.org/media/pdf/assessment-framework-for-digital-sat-suite.pdf",
           "assessment-framework-for-digital-sat-suite.pdf", kind="framework",
           expected_bytes=2_700_000,
           notes="corpus Part 6: 2.7MB fetched 2026-09-19; tables 11-14 + 21-24, printed pp 58-116"),
    Source("SAT", "SAT Suite", "digital", "skills insight",
           "https://satsuite.collegeboard.org/media/pdf/skills-insight-digital-sat-suite.pdf",
           "skills-insight-digital-sat-suite.pdf", kind="framework",
           notes="corpus Part 3/6 program notes: PSAT 8/9 Geometry but NO trigonometry"),
    Source("SAT", "SAT Suite", "digital", "technical manual",
           "https://research.collegeboard.org/media/pdf/Digital%20SAT%20Suite%20of%20Assessments%20Technical%20Manual-FINAL.pdf",
           "digital-sat-suite-technical-manual.pdf", kind="technical_manual"),

    # ---- AQA (PROVEN pattern: filestore.aqa.org.uk AQA-<codes>-SP-<year>.PDF)
    Source("AQA", "Chemistry", "7404/7405", "SP-2015",
           "https://filestore.aqa.org.uk/resources/chemistry/specifications/AQA-7404-7405-SP-2015.PDF",
           "AQA-7404-7405-SP-2015.PDF",
           expected_sha256_prefix="405e292e9b005866",
           notes="corpus Part 12: 3 sections / 34 sub-topics"),
    Source("AQA", "Chemistry", "8462", "SP-2016",
           "https://filestore.aqa.org.uk/resources/chemistry/specifications/AQA-8462-SP-2016.PDF",
           "AQA-8462-SP-2016.PDF",
           expected_sha256_prefix="ecd869d1874091a0",
           notes="corpus Part 5b/12: GCSE Chemistry, 10 sections / 32 sub-topics"),
    Source("AQA", "Biology", "7402", "SP-2015",
           "https://filestore.aqa.org.uk/resources/biology/specifications/AQA-7401-7402-SP-2015.PDF",
           "AQA-7401-7402-SP-2015.PDF",
           expected_sha256_prefix="bffcfd57505b50e1",
           notes="corpus Part 12: A-level Biology, 8 sections / 39 sub-topics"),
    Source("AQA", "Biology", "8461", "SP-2016",
           "https://filestore.aqa.org.uk/resources/biology/specifications/AQA-8461-SP-2016.PDF",
           "AQA-8461-SP-2016.PDF",
           expected_sha256_prefix="effa4236b6250dd1",
           notes="corpus Part 12: GCSE Biology, 7 sections / 24 sub-topics"),
    Source("AQA", "Physics", "7408", "SP-2015",
           "https://filestore.aqa.org.uk/resources/physics/specifications/AQA-7407-7408-SP-2015.PDF",
           "AQA-7407-7408-SP-2015.PDF",
           expected_sha256_prefix="32a556da85fa0928",
           notes="corpus Part 12: A-level Physics, 13 sections / 38 sub-topics"),
    Source("AQA", "Physics", "8463", "SP-2016",
           "https://filestore.aqa.org.uk/resources/physics/specifications/AQA-8463-SP-2016.PDF",
           "AQA-8463-SP-2016.PDF",
           expected_sha256_prefix="b0ece1dba5a0f5d5",
           notes="corpus Part 12: GCSE Physics, 8 sections / 30 sub-topics"),

    # NOTE (resolved 2026-09-19): AQA publishes A-level specifications under the
# COMBINED AS+A-level code, not the A-level code alone. `AQA-7402-SP-2015.PDF`
# and `AQA-7408-SP-2015.PDF` are 404; `AQA-7401-7402-SP-2015.PDF` (Biology) and
# `AQA-7407-7408-SP-2015.PDF` (Physics) resolve, and their sha256 match the
# corpus record exactly (bffcfd57505b50e1 / 32a556da85fa0928). Chemistry's
# combined code AQA-7404-7405-SP-2015.PDF already worked.

    # ---- Pearson Edexcel (PROVEN DAM paths, corpus Parts 8/10/13) ----------
    Source("EDEXCEL", "Chemistry", "9CH0", "2017 spec, Issue 3 (Sept 2024)",
           "https://qualifications.pearson.com/content/dam/pdf/International%20GCSE/Chemistry/2017/specification-and-sample-assessments/international-gcse-chemistry-2017-specification.pdf",
           "international-gcse-chemistry-2017-specification.pdf",
           expected_sha256_prefix="36e2080d2e99f060", expected_bytes=1_720_000,
           notes="corpus Part 8: 1.72MB. 'C' suffix = beyond-Core tier marker, keep never drop"),
    Source("EDEXCEL", "Physics", "9PH0", "2017 spec",
           "https://qualifications.pearson.com/content/dam/pdf/International%20GCSE/Physics/2017/specification-and-sample-assessments/international-gcse-physics-2017-specification.pdf",
           "international-gcse-physics-2017-specification.pdf",
           expected_bytes=1_360_000,
           notes="corpus Part 10: 1.36MB; sub-letters need re-sweep of pp30-33"),
    Source("EDEXCEL", "Chemistry", "9CH0 (A Level)", "2015 spec, Issue 3 (Feb 2024)",
           "https://qualifications.pearson.com/content/dam/pdf/A%20Level/Chemistry/2015/Specification%20and%20sample%20assessments/a-level-chemistry-2015-specification.pdf",
           "a-level-chemistry-2015-specification.pdf",
           expected_bytes=2_110_597,
           notes="corpus Part 13: 2,110,597 B; Topics 1-19 (AS=1-10, A-level adds 11-19). Outcomes in 3-col tables -> extract table-aware (pdfplumber), not line regex"),

    # ---- IB (subject briefs; corpus Part 7/11 — curl bot-blocked, try anyway)
    Source("IB", "Chemistry", "DP Chemistry", "first assessment 2025",
           "https://www.ibo.org/globalassets/new-structure/recognition/pdfs/dp_sciences_chemistry_subject-brief_jan_2022_e.pdf",
           "dp_sciences_chemistry_subject-brief_jan_2022_e.pdf", kind="subject_brief",
           notes="corpus Part 7. ibo.org returns HTTP 403 to direct client fetches; the full brief IS retrievable via a page-fetcher and is stored as text at docs/research/ib/*.page-fetch.md"),
    Source("IB", "Biology", "DP Biology", "first assessment 2025",
           "https://www.ibo.org/globalassets/new-structure/recognition/pdfs/dp_sciences_biology_subject-brief_jan_2022_e.pdf",
           "dp_sciences_biology_subject-brief_jan_2022_e.pdf", kind="subject_brief",
           notes="corpus Part 11: 4 unifying themes, '*' = HL-only"),
    Source("IB", "Physics", "DP Physics", "first assessment 2025",
           "https://www.ibo.org/globalassets/new-structure/recognition/pdfs/dp_sciences_physics_subject-brief_jan_2022_e.pdf",
           "dp_sciences_physics_subject-brief_jan_2022_e.pdf", kind="subject_brief",
           notes="corpus Part 11"),

    # ---- OCR (optional board, spec §15.7) ----------------------------------
    Source("OCR", "Chemistry", "H432 (+AS H032)", "2015 accredited",
           "https://www.ocr.org.uk/Images/171720-specification-accredited-a-level-gce-chemistry-a-h432.pdf",
           "ocr-a-level-gce-chemistry-a-h432.pdf",
           expected_sha256_prefix="83d7a5c69b585fda", expected_bytes=21_400_000,
           notes="corpus Part 9: 21.4MB real PDF; asset IDs must come from the qualification page, guessed 308672/308673 were 404 HTML"),
]


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _classify_failure(status: int, data: bytes, content_type: str) -> str:
    """Map a bad response onto the §0.9.5 source-availability vocabulary."""
    if status in (401, 403, 429, 451):
        return "SOURCE_NOT_ACCESSIBLE"
    if status == 404:
        return "SOURCE_NOT_FOUND"
    if status >= 500:
        return "SOURCE_NOT_ACCESSIBLE"
    if not data.startswith(PDF_MAGIC):
        return "CORRUPTED_INPUT"          # HTML/JSON served under a .pdf name
    if len(data) == PEARSON_404_SENTINEL_BYTES:
        return "SOURCE_NOT_FOUND"         # Pearson generic 404 sentinel
    if len(data) < MIN_PDF_BYTES:
        return "CORRUPTED_INPUT"
    if content_type and "pdf" not in content_type.lower() and "octet" not in content_type.lower():
        return "CORRUPTED_INPUT"
    return "AVAILABLE"


def fetch_one(src: Source, dry_run: bool = False) -> Dict[str, Any]:
    dest_dir = RESEARCH_DIR / src.board.lower()
    dest = dest_dir / src.filename
    rec: Dict[str, Any] = {
        "board": src.board, "subject": src.subject, "code": src.code,
        "version": src.version, "kind": src.kind, "url": src.url,
        "path": str(dest.relative_to(ROOT)) if dest.exists() else None,
        "notes": src.notes,
    }

    if dest.exists() and dest.stat().st_size >= MIN_PDF_BYTES:
        data = dest.read_bytes()
        if data.startswith(PDF_MAGIC):
            rec.update(status="AVAILABLE", cached=True, bytes=len(data),
                       sha256=_sha256(data))
            if src.expected_sha256_prefix:
                rec["sha_matches_corpus"] = rec["sha256"].startswith(src.expected_sha256_prefix)
            return rec

    if dry_run:
        rec.update(status="NOT_FETCHED", cached=False, dry_run=True)
        return rec

    try:
        import requests
    except ImportError:
        rec.update(status="SOURCE_NOT_ACCESSIBLE", error="requests not installed")
        return rec

    try:
        r = requests.get(src.url, timeout=TIMEOUT_S,
                         headers={"User-Agent": USER_AGENT, "Accept": "application/pdf,*/*"},
                         allow_redirects=True)
        data = r.content or b""
        ctype = r.headers.get("Content-Type", "")
        status = _classify_failure(r.status_code, data, ctype)
        rec.update(http_status=r.status_code, content_type=ctype, bytes=len(data),
                   status=status)
        if status == "AVAILABLE":
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            rec["path"] = str(dest.relative_to(ROOT))
            rec["sha256"] = _sha256(data)
            rec["fetched_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
            if src.expected_sha256_prefix:
                rec["sha_matches_corpus"] = rec["sha256"].startswith(src.expected_sha256_prefix)
            if src.expected_bytes:
                rec["size_matches_corpus"] = abs(len(data) - src.expected_bytes) < 100_000
        else:
            # Keep the evidence of the miss (small HTML bodies only) for diagnosis.
            if data and len(data) < 400_000:
                dest_dir.mkdir(parents=True, exist_ok=True)
                (dest_dir / (src.filename + ".rejected")).write_bytes(data)
                rec["rejected_body"] = str((dest_dir / (src.filename + ".rejected")).relative_to(ROOT))
    except Exception as exc:
        rec.update(status="SOURCE_NOT_ACCESSIBLE", error=f"{type(exc).__name__}: {exc}"[:300])
    return rec


def load_manifest() -> Dict[str, Any]:
    if MANIFEST.exists():
        try:
            return json.loads(MANIFEST.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"schema_version": "1.0", "sources": []}


def save_manifest(m: Dict[str, Any]) -> None:
    RESEARCH_DIR.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(m, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--board", help="only this board (CAIE/AQA/EDEXCEL/IB/SAT/OCR)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--delay", type=float, default=REQUEST_DELAY_S)
    args = ap.parse_args(argv)

    if args.list:
        for s in SOURCES:
            print(f"  {s.board:8s} {s.subject:12s} {s.code:18s} {s.version:34s} {s.filename}")
        print(f"\n  {len(SOURCES)} sources queued.")
        return 0

    queue = [s for s in SOURCES if not args.board or s.board.upper() == args.board.upper()]
    print(f"=== BOARD SOURCE RESEARCH FETCH — {len(queue)} document(s) ===")
    print(f"target: {RESEARCH_DIR.relative_to(ROOT)}/   delay={args.delay}s   dry_run={args.dry_run}\n")

    manifest = load_manifest()
    by_key = {(r.get("board"), r.get("code"), r.get("filename", "")): r
              for r in manifest.get("sources", [])}
    results = []
    for i, src in enumerate(queue, 1):
        key = (src.board, src.code, src.filename)
        print(f"[{i}/{len(queue)}] {src.board} {src.subject} {src.code} -> {src.filename}")
        rec = fetch_one(src, dry_run=args.dry_run)
        rec["filename"] = src.filename
        extra = ""
        if rec.get("sha_matches_corpus") is True:
            extra = "  sha MATCHES corpus record"
        elif rec.get("sha_matches_corpus") is False:
            extra = "  sha DIFFERS from corpus record (new edition?)"
        print(f"        {rec['status']}  {rec.get('bytes','-')} B  http={rec.get('http_status','-')}{extra}")
        if rec.get("error"):
            print(f"        error: {rec['error']}")
        by_key[key] = rec
        results.append(rec)
        if not args.dry_run and i < len(queue):
            time.sleep(args.delay)

    manifest["sources"] = list(by_key.values())
    manifest["updated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    if not args.dry_run:
        save_manifest(manifest)

    ok = [r for r in results if r["status"] == "AVAILABLE"]
    print(f"\n=== SUMMARY ===")
    print(f"  AVAILABLE            : {len(ok)}")
    for st in ("SOURCE_NOT_FOUND", "SOURCE_NOT_ACCESSIBLE", "CORRUPTED_INPUT", "NOT_FETCHED"):
        n = len([r for r in results if r["status"] == st])
        if n:
            print(f"  {st:21s}: {n}")
    if ok:
        print("\n  Verified official documents now on disk:")
        for r in ok:
            print(f"    {r['board']:8s} {r['code']:18s} {r.get('sha256','')[:16]}…  {r['path']}")
    print("\n  No taxonomy will be built for a source that failed to fetch —")
    print("  it is recorded as SOURCE_NOT_FOUND / SOURCE_NOT_ACCESSIBLE instead.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
