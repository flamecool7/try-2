# HANDOFF BRIEF — Universal Examination Intelligence Engine

**Date:** 2026-09-20 · **For:** the next agent session · **Read this first, then the two docs below.**

## 1. What this repo is

A production-grade Universal Examination Intelligence Engine / Topical Question Bank
Generator. Five exam boards (CAIE, College Board/SAT, IB, AQA, Pearson Edexcel) as adapters
on ONE universal core. The original Cambridge generator is the reference implementation and
must never be duplicated or rewritten.

Primary build target: `/home/user/Universal_Exam_Topical_Generator/`
User source uploads (original zips, megaprompt, topic corpus): `/home/user/repo/` — **user data, never delete.**

## 2. Read these two documents before writing any code

1. **`docs/research/non-caie-real-paper-findings.md`** — real papers on disk with SHA-256 and
   source URLs, plus **measured** page structures for AQA, College Board and Edexcel, and the
   three measured MCQ defects. This is the complete groundwork for the next task.
2. **`docs/reports/milestone4-increment1-gold-path-proof.md`** — what was proven, including the
   RS-64 top-band fix and its validation table.

Also binding: `CROPPING_LOCK.md` (crop invariants + amendments), `ROUTING_STATE_LOCK.md` and
`EFFICIENCY_AUDIT.md` (lock ledger; **last doc wins per path** — append to EFFICIENCY_AUDIT.md).

## 3. Current state — verified, not assumed

- `424 passed, 58 skipped, 0 failed`, 85 subtests. Proof: `overall PASS`.
- 58 skips are **environmental**, not failures: 56 need the fixture corpus at
  `/home/user/test-crops/fixtures` (absent; `python tools/download_fixtures.py --download`),
  2 need `BATCH_HEAVY=1`.
- **RS-64 complete and validated:** every QP crop now has exactly 20 px of verified white
  above first ink. Measured **11/11** on real papers (was 15/16/82/93). Guarded by
  `tests/test_top_band_anchor.py` (16 tests) which measure the *written file*.

## 4. THE NEXT TASK

Build adapters for AQA, Edexcel and SAT, cropping **real papers** already on disk:

```
papers/real_noncaie/aqa/AQA-87021-SQP-V1.PDF            17p, A4 595x842
papers/real_noncaie/edexcel/P61181A_9FM0_3C.pdf         28p, 652x899  (third format!)
papers/real_noncaie/sat/psat-8-9-practice-test-1.pdf    56p, Letter 612x792
papers/real_noncaie/sat/psat-nmsqt-practice-test-2.pdf
```

**Build order:** AQA → Edexcel → SAT. IB is **blocked** — no real paper sourced (`ibo.org`
403s direct clients, full guides paywalled). Do not write an IB adapter blind.

**Architecture — do not build a second crop engine.** Split the locked mechanism into:
- *Reusable geometry* (board-agnostic, call these): `enforce_exact_width_2280`
  (`original_reference/cambridge_qb/multipage_optimizer.py:169`),
  `assemble_multipage_question` (`:188`), `_align_top_white_band_final`
  (`question_split.py:686`).
- *Board-specific boundary detection*: implement per board in the adapter.

Implement the existing hooks `segments_document()` / `segment(ctx)` at
`adapters/base.py:254,259`. `DocumentContext` already carries `path`, `full_text`,
`page_count`, `layout` — **never re-open or re-OCR the PDF in an adapter.**
Registry auto-discovers `adapters/<name>/adapter.py` exposing class `Adapter`.

**SAT specifically** — `core/mcq_support.py` is the inspiration but has three measured defects
(run it yourself against the real PSAT to reproduce: 65 hits vs 33 declared questions):
1. `MCQ_EXPECTED_COUNT = 40` (`mcq_support.py:45`) is a CAIE assumption; the PSAT module
   declares 33. Counts must come from board config or the paper's own declared count.
2. Duplicate question numbers across pages — `x0` margin thresholds
   (`left_margin_threshold=70.0`) are tuned for CAIE single-column A4, not Letter.
3. No module awareness, but **SAT numbering restarts per module**, so a flat list collides by
   design. This is likely the real cause of (2).

**Edexcel specifically:** `DO NOT WRITE IN THIS AREA` margin boxes are real ink in the gutters
and must be excluded **before** any ink-based boundary detection, or the 20 px band anchors
against margin ink. `*P61181A0228*` is a page-reference code, NOT a candidate barcode — give
it its own pattern; do not reuse gold's `_PAGE_BARCODE_RE`.

**AQA specifically:** p3 is a contents table whose numbers 1–8 will false-positive as question
starts; `"There are no questions printed on this page."` pages are fillers; questions are
`EITHER`/`OR` alternatives one per page, **not** sequentially numbered — decide canonical
naming for alternatives before generating files.

## 5. Hard constraints (user-mandated, do not violate)

- **Reuse before rewrite.** `original_reference/cambridge_qb` is byte-pristine. `core/question_split.py`
  is a LOCKED TRIPLET member — **cannot be modified**. Never build a second crop or naming engine.
- **No fabrication** of papers, questions, mark schemes, URLs or topics. Prefer
  `UNKNOWN` / `SOURCE_NOT_FOUND` / `REVIEW_REQUIRED`.
- Never trust filenames. Never assume P1–P6 / component codes mean the same across boards.
- No hardcoded year maximum; support 1900–9999.
- Crop invariants locked: 2280 px width, exactly 20 px verified white above first ink, LANCZOS,
  30 px multipage gap, no clipping, WEBP.
- Canonical naming `Variant_Season_Year_Qn[_MS/_IN/_ER].webp`; MCQ `.txt` sidecar is the exception.
- Final question folders must contain **no `proof.html`**.
- Do NOT spend build time on large synthetic test suites or fake benchmarks — the user tests with
  real papers. Always distinguish **IMPLEMENTED** from **FULLY VERIFIED**.
- Changing any file in the lock ledger requires re-pinning its SHA-256 in **both**
  `ROUTING_STATE_LOCK.md` and `EFFICIENCY_AUDIT.md` or 6 tests fail.

## 6. Environment gotchas (all cost real time last session)

- **Pip packages are stripped at session boundaries.** First pipeline run will fail with
  `ModuleNotFoundError: No module named 'fitz'`. Run `pip install -r requirements.txt`
  (restores exact pins `PyMuPDF==1.24.14`, `Pillow==11.0.0`).
- **`/tmp` is a 993 MB tmpfs — RAM-backed** — on a ~2 GB machine. Never write pipeline output
  there; it OOM-kills workers. Use a real-disk path inside the workspace.
- `_page_scratch_root()` prefers `/dev/shm` (also RAM) by design; budget for it.
- **A failed gold import silently sets `GOLD_AVAILABLE = False`** and only prints a line,
  disabling every locked invariant. After editing `core/cropping_engine.py` imports, always
  assert `GOLD_AVAILABLE is True`. Import gold symbols via guarded `getattr` on the module
  object, never by adding names to a `from x import (...)` list.
- `config/` is immutable and cached — override with
  `dataclasses.replace(load_config(), data=deepcopy(...))`.

## 7. Known open issues

1. **9686 Urdu crop failure** — image-only PDF; gold's text-based splitter finds 0 questions.
   `core/question_split.py` is locked, so the fix is a page-wrapper in `core/cropping_engine.py`
   returning OCR text only when the native text layer is empty. Design recorded, not implemented.
2. **Four board configs overstate status** — `aqa/edexcel/ib/sat.yaml` all declare
   `support_status: IMPLEMENTED_PENDING_VALIDATION` but **no adapter directory exists** for any
   of them. Correct these to a config-only value, or build the adapters.
3. **Stale comment at `core/cropping_engine.py:372`** claims gold's `crop_page_segments` applies
   the 20 px anchor. It does not (that function appears in the file only inside that comment).
   Reading it caused a wrong diagnosis last session. Fix the comment.
4. QP↔MS↔ER↔Insert association; MCQ `.txt` sidecar contract; remaining milestone items
   (downloader, search, set generation, booklets, analytics, QC doctor, launcher).

## 8. Suggested first actions

1. `pip install -r requirements.txt`
2. Read `docs/research/non-caie-real-paper-findings.md`
3. `python -m pytest tests/ -q` → expect 424 passed
4. `python tools/run_proof.py --output /tmp/p.html --no-suite --check` → expect `overall PASS`
5. Build the shared segment→gold-geometry bridge, then the AQA adapter, and crop
   `papers/real_noncaie/aqa/AQA-87021-SQP-V1.PDF` for real. Measure bands with the lock's
   criterion `(gray<250).sum(axis=1) >= 2`; expect exactly 20.
