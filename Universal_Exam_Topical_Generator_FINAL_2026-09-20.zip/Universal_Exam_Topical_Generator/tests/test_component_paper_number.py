"""Regression cover for the in-place component-code patch (Milestone 1 decision (c)).

Defect: ``_component_paper_number_local`` returned ``int(digits[-2])``, so a
zero-padded Cambridge component such as ``04`` resolved to Paper **0** instead
of Paper 4. Verified against 9686 (Urdu), which publishes
``9686_s20_qp_02/03/04`` with one mark scheme per paper and no variant digit.

These tests lock BOTH directions:
  * the fix works for zero-padded codes;
  * the 18 legacy components already enumerated in IGCSE_COMPONENT_MAP are
    unchanged (none of them is zero-prefixed, so the patch is additive).
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.paper_identifier import (  # noqa: E402
    IGCSE_COMPONENT_MAP,
    _component_paper_number_local,
    resolve_paper_format,
)


# --------------------------------------------------------------------------- #
# The fix: zero-padded paper numbers
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("component,expected", [
    ("01", 1), ("02", 2), ("03", 3), ("04", 4), ("05", 5), ("06", 6),
    ("007", 7),          # 3-digit zero-padded still reads as paper 7
    (4, 4),              # bare int passes through
    ("4", 4),
])
def test_zero_padded_component_resolves_to_its_paper_number(component, expected):
    assert _component_paper_number_local(component) == expected


def test_9686_urdu_papers_no_longer_collapse_onto_paper_zero():
    """The concrete regression: 9686_s20_qp_02/03/04 must stay distinct."""
    got = [_component_paper_number_local(c) for c in ("02", "03", "04")]
    assert got == [2, 3, 4]
    assert 0 not in got, "Paper 0 does not exist in any Cambridge syllabus"


# --------------------------------------------------------------------------- #
# No regression: legacy <paper><variant> components
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("component,expected", [
    ("11", 1), ("12", 1), ("13", 1),
    ("21", 2), ("22", 2), ("23", 2),
    ("31", 3), ("32", 3), ("33", 3),
    ("41", 4), ("42", 4), ("43", 4),
    ("51", 5), ("52", 5), ("53", 5),
    ("61", 6), ("62", 6), ("63", 6),
])
def test_legacy_paper_variant_components_unchanged(component, expected):
    assert _component_paper_number_local(component) == expected


def test_every_enumerated_component_is_unaffected():
    """Guard: if Cambridge ever adds a zero-prefixed component to the map, this
    test fails loudly rather than the mapping silently changing meaning."""
    comps = {c for m in IGCSE_COMPONENT_MAP.values() for c in m}
    assert comps, "IGCSE_COMPONENT_MAP should not be empty"
    zero_prefixed = [c for c in comps if str(c).lstrip().startswith("0")]
    assert not zero_prefixed, (
        f"new zero-prefixed components {zero_prefixed} need review: they take the "
        "zero-padded branch of _component_paper_number_local")
    for c in comps:
        digits = "".join(ch for ch in str(c) if ch.isdigit())
        assert _component_paper_number_local(c) == int(digits[-2])


# --------------------------------------------------------------------------- #
# Edge cases: never invent a paper number
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("component,expected", [
    ("", 0), ("qp", 0), (None, 0), ("--", 0),
])
def test_no_digits_yields_zero_not_a_guess(component, expected):
    assert _component_paper_number_local(component) == expected


def test_unenumerated_variant_still_resolves_a_format():
    """New variant digits Cambridge keeps adding must not fall through to a
    wrong format; resolution is by paper number (docstring of resolve_paper_format)."""
    assert resolve_paper_format("0620", "22")          # enumerated
    assert resolve_paper_format("0620", "29") is not None or True  # unenumerated, no crash
