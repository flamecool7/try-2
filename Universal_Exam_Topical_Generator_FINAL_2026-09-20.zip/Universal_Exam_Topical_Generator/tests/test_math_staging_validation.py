"""RS-63 regression: the validator must not contradict itself over `loading`.

`check_no_forbidden_paths` (Spec Fix 12) fails the audit when ANY output path
contains `loading`. `check_reference_staging_math_routing` used to *require* a
`paper-N/loading` directory and pre-created reference topic folders. Both run in
the same `validate()` pass, so a correct 9709/9231 bank could never pass:

    no loading folder -> "missing loading folder"
    loading folder    -> "Forbidden staging path contains 'loading'"

These tests pin the resolved contract: a real, correctly-produced math bank
validates clean, an invented topic still fails, and the two checks can never
demand and forbid the same path again.
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJ))

from core.validation import FinalValidator  # noqa: E402
from core.math_reference import reference_topics_for_subject_paper  # noqa: E402

SUBJECT = "Further_Mathematics_9231"
CODE = "9231"
PAPER = 1
VARIANT = "11"          # -> paper 1


def _write_question(root: Path, topic: str, qname: str) -> Path:
    folder = root / topic / qname
    folder.mkdir(parents=True, exist_ok=True)
    (folder / f"{qname}.webp").write_bytes(b"RIFF\x00\x00\x00\x00WEBP")
    (folder / "metadata.json").write_text(json.dumps({
        "subject": SUBJECT, "topic": [topic], "variant": VARIANT,
        "level": "A-Level", "syllabus_code": CODE,
    }, indent=4), encoding="utf-8")
    return folder


class TestMathReferenceStagingCheck(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="rs63_"))
        self.root = self.tmp / "A-Level" / SUBJECT / f"paper-{PAPER}"
        self.root.mkdir(parents=True, exist_ok=True)
        self.reference = set(reference_topics_for_subject_paper(CODE, PAPER))
        self.assertTrue(self.reference, "reference topic set should not be empty")

    def _validator(self) -> FinalValidator:
        return FinalValidator(self.tmp)

    def test_partial_reference_coverage_is_valid(self):
        """A fresh run only creates topics that questions actually classified into.
        That is correct — demanding every reference topic pre-exist was the bug."""
        used = sorted(self.reference)[:3]
        for i, topic in enumerate(used, 1):
            _write_question(self.root, topic, f"{VARIANT}_Winter_2025_Q{i}")
        v = self._validator()
        v.check_reference_staging_math_routing()
        self.assertEqual(v.errors, [], f"unexpected errors: {v.errors}")

    def test_no_loading_folder_is_not_an_error(self):
        """`loading` is forbidden elsewhere, so its absence must not be an error."""
        _write_question(self.root, sorted(self.reference)[0], f"{VARIANT}_Winter_2025_Q1")
        v = self._validator()
        v.check_reference_staging_math_routing()
        self.assertFalse(any("loading" in e for e in v.errors),
                         f"check still demands the retired loading folder: {v.errors}")

    def test_the_two_checks_are_no_longer_contradictory(self):
        """Guard against the unsatisfiable pair returning: a bank that satisfies
        the staging check must also satisfy the forbidden-paths check."""
        _write_question(self.root, sorted(self.reference)[0], f"{VARIANT}_Winter_2025_Q1")
        v = self._validator()
        v.check_reference_staging_math_routing()
        v.check_no_forbidden_paths()
        self.assertEqual(v.errors, [], f"contradiction reintroduced: {v.errors}")

    def test_invented_topic_still_fails_loudly(self):
        """The anti-fabrication invariant must survive the relaxation."""
        invented = "Topic_That_Is_Not_In_The_Reference"
        self.assertNotIn(invented, self.reference)
        _write_question(self.root, invented, f"{VARIANT}_Winter_2025_Q1")
        v = self._validator()
        v.check_reference_staging_math_routing()
        self.assertTrue(any(invented in e for e in v.errors),
                        f"invented topic was not rejected: {v.errors}")

    def test_loading_folder_is_still_forbidden(self):
        """Spec Fix 12 remains authoritative."""
        (self.root / "loading").mkdir()
        _write_question(self.root, sorted(self.reference)[0], f"{VARIANT}_Winter_2025_Q1")
        v = self._validator()
        v.check_no_forbidden_paths()
        self.assertTrue(any("loading" in e.lower() for e in v.errors),
                        "a loading directory must still fail the audit")

    def test_wrong_paper_assignment_still_detected(self):
        """Metadata whose variant maps to a different paper must still be caught."""
        topic = sorted(self.reference)[0]
        folder = self.root / topic / f"21_Winter_2025_Q1"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "metadata.json").write_text(json.dumps({
            "subject": SUBJECT, "topic": [topic], "variant": "21",   # -> paper 2
            "level": "A-Level", "syllabus_code": CODE,
        }, indent=4), encoding="utf-8")
        v = self._validator()
        v.check_reference_staging_math_routing()
        self.assertTrue(any("paper" in e.lower() for e in v.errors),
                        f"wrong-paper assignment not detected: {v.errors}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
