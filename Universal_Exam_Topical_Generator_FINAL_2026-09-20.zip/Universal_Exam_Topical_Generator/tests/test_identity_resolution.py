"""Milestone 3 acceptance tests: identity from content, conflicts never silent.

Directive §7: the system must identify what a document IS, not what its filename
CLAIMS. These tests use COPIES of the real staged papers (papers/raw is immutable)
renamed to destroy, falsify or contradict the filename evidence.

OCR is disabled for speed; these cases all have a readable text layer except the
Urdu paper, which is handled separately.
"""

from __future__ import annotations

import copy
import dataclasses
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJ))

from universal.config import load_config          # noqa: E402
from universal.identity import IdentityResolver    # noqa: E402

RAW = PROJ / "papers" / "raw"
QP = RAW / "9701_m26_qp_22.pdf"
MS = RAW / "0625_s24_ms_11.pdf"


def _resolver_no_ocr() -> IdentityResolver:
    """A resolver with OCR disabled.

    `Config` is immutable and `load_config` caches a module-level singleton, so
    the override is built with `dataclasses.replace` over a deep copy — mutating
    the shared instance would leak into every other test in the session.
    """
    base = load_config()
    data = copy.deepcopy(base.data)
    data.setdefault("ocr", {})["enabled"] = False
    return IdentityResolver(dataclasses.replace(base, data=data))


@unittest.skipUnless(QP.exists(), "real staged paper not present")
class TestIdentityFromContent(unittest.TestCase):
    """Filename evidence destroyed -> identity must still come from the document."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="identity_"))
        self.r = _resolver_no_ocr()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _copy_as(self, name: str) -> Path:
        dst = self.tmp / name
        shutil.copy2(QP, dst)
        return dst

    def test_meaningless_filename_still_resolves_from_content(self):
        """A scanner-style name carries zero identity. Content must supply it."""
        v = self.r.resolve(self._copy_as("scan0001.pdf"))
        self.assertEqual(v.identity.get("syllabus_code"), "9701")
        self.assertEqual(str(v.identity.get("year")), "2026")
        self.assertEqual(v.identity.get("board"), "CAIE")
        # The year must be corroborated by the document, not guessed from the name.
        year_sources = {s for c in v.fields["year"].candidates for s in c["sources"]}
        self.assertNotIn("filename", year_sources)
        self.assertTrue(year_sources & {"first_page_text", "qualification_code",
                                        "board_signature"},
                        f"year had no content-derived source: {year_sources}")

    def test_wrong_syllabus_in_filename_is_a_conflict_not_a_silent_pick(self):
        """Filename claims 0620; the document is 9701. Must never silently win."""
        v = self.r.resolve(self._copy_as("0620_s23_qp_11.pdf"))
        self.assertEqual(v.status, "REVIEW_REQUIRED")
        self.assertTrue(v.conflicts, "expected a recorded conflict")
        codes = {str(c["field"]) for c in v.conflicts}
        self.assertIn("syllabus_code", codes)
        conflict = next(c for c in v.conflicts if c["field"] == "syllabus_code")
        vals = {str(conflict["accepted"]["value"]), str(conflict["rejected"]["value"])}
        self.assertEqual(vals, {"0620", "9701"})
        self.assertEqual(conflict["policy"], "REVIEW_REQUIRED")

    def test_wrong_year_in_filename_is_surfaced(self):
        """Filename claims 2023; cover page says May/June 2026."""
        v = self.r.resolve(self._copy_as("9701_m23_qp_22.pdf"))
        self.assertEqual(v.status, "REVIEW_REQUIRED")
        self.assertTrue(any(c["field"] == "year" for c in v.conflicts),
                        f"no year conflict recorded: {v.conflicts}")

    def test_wrong_document_type_in_filename_is_surfaced(self):
        """A question paper named as a mark scheme must not pass as a mark scheme."""
        v = self.r.resolve(self._copy_as("9701_m26_ms_22.pdf"))
        self.assertEqual(v.status, "REVIEW_REQUIRED")
        types = {str(c["value"]) for cand in v.fields["document_type"].candidates
                 for c in [cand]}
        self.assertIn("qp", types)
        self.assertIn("ms", types)

    def test_rejected_value_is_preserved_in_the_record(self):
        """The losing side of a conflict must stay visible for a human reviewer."""
        v = self.r.resolve(self._copy_as("0620_s23_qp_11.pdf"))
        blob = v.to_dict()
        text = repr(blob)
        self.assertIn("0620", text)
        self.assertIn("9701", text)
        self.assertIn("conflicts", blob)

    def test_mark_scheme_is_not_confused_with_question_paper(self):
        """Regression: 'total mark' appears on QP covers too and must not create
        a phantom mark-scheme signal (this produced false conflicts on
        9701_m26_qp_22 and 9231_w25_qp_11)."""
        v = self.r.resolve(QP)
        self.assertEqual(v.status, "RESOLVED")
        self.assertEqual(v.identity.get("document_type"), "qp")
        ms_sources = {s for c in v.fields["document_type"].candidates
                      for s in c["sources"]}
        self.assertNotIn("mark_scheme_structure", ms_sources)

    def test_real_mark_scheme_still_identified(self):
        v = self.r.resolve(MS)
        self.assertEqual(v.identity.get("document_type"), "ms")
        self.assertEqual(v.identity.get("syllabus_code"), "0625")
        self.assertEqual(v.status, "RESOLVED")


@unittest.skipUnless(QP.exists(), "real staged paper not present")
class TestNoFabrication(unittest.TestCase):
    """Nothing may be invented when evidence is absent (§36)."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="identity_nf_"))
        self.r = _resolver_no_ocr()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_non_pdf_garbage_yields_insufficient_evidence(self):
        p = self.tmp / "notes.pdf"
        p.write_bytes(b"%PDF-1.4\nnot a real exam paper\n%%EOF\n")
        v = self.r.resolve(p)
        self.assertEqual(v.status, "INSUFFICIENT_EVIDENCE")
        self.assertTrue(v.needs_review)
        self.assertNotIn("year", v.identity)
        self.assertNotIn("syllabus_code", v.identity)

    def test_missing_file_is_reported_not_guessed(self):
        v = self.r.resolve(self.tmp / "does_not_exist.pdf")
        self.assertEqual(v.status, "INSUFFICIENT_EVIDENCE")
        self.assertTrue(any("FILE_NOT_FOUND" in r for r in v.reasons))

    def test_no_field_defaults_to_a_hardcoded_year(self):
        """The Milestone-1 defect: a real 2026 paper was dated 2024 once filename
        evidence was removed. No identity field may carry a baked-in default."""
        p = self.tmp / "paper.pdf"
        p.write_bytes(b"%PDF-1.4\nsome text without any year\n%%EOF\n")
        v = self.r.resolve(p)
        self.assertNotIn("year", v.identity)
        self.assertNotIn("2024", repr(v.identity))


if __name__ == "__main__":
    unittest.main(verbosity=2)
