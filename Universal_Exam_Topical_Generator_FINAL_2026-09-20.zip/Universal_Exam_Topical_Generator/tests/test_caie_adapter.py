"""CAIE adapter regression tests.

These pin the document-type reading rules against the REAL staged papers, because
every heuristic here was wrong at least once before it was right:

* matching cover tokens loosely made "Paper 1 Multiple Choice (Core)" on a MARK
  SCHEME cover match the QP token "paper" — every MS and ER read as `qp`;
* longest-phrase-wins then made the MS boilerplate
  "read in conjunction with the question paper and the principal examiner report
  for teachers" resolve to `er`;
* `\\bprincipal examiner\\b` matched MS covers ("prepared by the Principal
  Examiner"), producing a false `er`.

The rule that survives all three: a document's own type is declared by its
HEADING (a phrase on its own line), and a question paper is identified positively
by its candidate instruction block — never by a prose cross-reference.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJ))

from adapters.base import DocumentContext          # noqa: E402
from adapters.registry import (                    # noqa: E402
    discovery_errors, get_adapter, get_all_adapters)

RAW = PROJ / "papers" / "raw"

EXPECTED = {
    "9701_m26_qp_22.pdf": ("qp", "9701", "2026", "m", "22"),
    "9231_w25_qp_11.pdf": ("qp", "9231", "2025", "w", "11"),
    "9231_w25_ms_11.pdf": ("ms", "9231", "2025", "w", "11"),
    "0625_s24_ms_11.pdf": ("ms", "0625", "2024", "s", "11"),
    "0625_s24_ms_21.pdf": ("ms", "0625", "2024", "s", "21"),
    "0620_m25_er.pdf":    ("er", "0620", "2025", "m", "12"),
}


def _ctx(name: str) -> DocumentContext:
    import pymupdf
    p = RAW / name
    doc = pymupdf.open(str(p))
    pages = [doc[i].get_text("text") or "" for i in range(min(len(doc), 6))]
    doc.close()
    return DocumentContext(path=str(p), filename=p.name, stem=p.stem,
                           suffix=p.suffix, page_count=len(pages),
                           has_text_layer=bool(sum(map(len, pages))),
                           first_page_text=pages[0] if pages else "",
                           full_text="\n".join(pages))


@unittest.skipUnless(RAW.exists(), "staged papers absent")
class TestCaieAdapterDiscovery(unittest.TestCase):
    def test_adapter_is_discovered_without_errors(self):
        self.assertEqual(discovery_errors(), {})
        self.assertIn("CAIE", get_all_adapters())

    def test_adapter_declares_caie_identity(self):
        a = get_adapter("CAIE")
        self.assertEqual(a.BOARD_ID, "CAIE")
        self.assertTrue(a.HAS_EXAMINER_REPORTS)
        self.assertTrue(a.HAS_INSERTS)


@unittest.skipUnless(all((RAW / n).exists() for n in EXPECTED),
                     "not all staged papers present")
class TestCaieDocumentType(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a = get_adapter("CAIE")
        cls.ctx = {n: _ctx(n) for n in EXPECTED}

    def _types(self, name):
        ev = self.a.identify_document_type(self.ctx[name])
        return {e.value for e in ev if e.field == "document_type"}

    def test_each_real_paper_reads_its_own_type(self):
        for name, (want, *_rest) in EXPECTED.items():
            with self.subTest(paper=name):
                self.assertEqual(self._types(name), {want})

    def test_mark_schemes_are_not_question_papers(self):
        """Regression: the loose token "paper" matched MS/ER covers."""
        for name in ("9231_w25_ms_11.pdf", "0625_s24_ms_11.pdf", "0625_s24_ms_21.pdf"):
            with self.subTest(paper=name):
                self.assertNotIn("qp", self._types(name))

    def test_mark_schemes_are_not_examiner_reports(self):
        """Regression: MS boilerplate names the principal examiner report."""
        for name in ("9231_w25_ms_11.pdf", "0625_s24_ms_11.pdf", "0625_s24_ms_21.pdf"):
            with self.subTest(paper=name):
                self.assertNotIn("er", self._types(name))
                er = self.a.identify_examiner_report(self.ctx[name])
                self.assertFalse(any(e.field == "document_type" for e in er),
                                 f"false examiner-report signal on {name}")

    def test_question_paper_confidence_is_high_not_fallback(self):
        """A QP must be positively identified, not inferred from prose."""
        for name in ("9701_m26_qp_22.pdf", "9231_w25_qp_11.pdf"):
            with self.subTest(paper=name):
                ev = [e for e in self.a.identify_document_type(self.ctx[name])
                      if e.field == "document_type"]
                self.assertTrue(ev)
                self.assertGreaterEqual(max(e.confidence for e in ev), 0.9)


@unittest.skipUnless(all((RAW / n).exists() for n in EXPECTED),
                     "not all staged papers present")
class TestCaieIdentityFields(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a = get_adapter("CAIE")
        cls.ctx = {n: _ctx(n) for n in EXPECTED}

    def _one(self, name, method, field):
        vals = {e.value for e in getattr(self.a, method)(self.ctx[name])
                if e.field == field}
        return vals

    def test_board_signature_on_every_real_paper(self):
        for name in EXPECTED:
            with self.subTest(paper=name):
                self.assertIn("CAIE", self._one(name, "identify_document", "board"))

    def test_syllabus_code_and_session_from_cover(self):
        for name, (_t, code, year, season, comp) in EXPECTED.items():
            with self.subTest(paper=name):
                self.assertIn(code, self._one(name, "identify_subject", "syllabus_code"))
                self.assertIn(int(year), self._one(name, "identify_session", "year"))
                self.assertIn(season, self._one(name, "identify_session", "season"))
                self.assertIn(comp, self._one(name, "identify_component", "component"))

    def test_paper_number_derivation_delegates_to_core(self):
        """Paper number must come from core.paper_identifier, never re-derived."""
        got = self._one("9701_m26_qp_22.pdf", "identify_component", "paper_number")
        self.assertIn(2, got)
        detail = [e.detail for e in self.a.identify_component(self.ctx["9701_m26_qp_22.pdf"])
                  if e.field == "paper_number"]
        self.assertTrue(any("core.paper_identifier" in d for d in detail))

    def test_unmapped_month_is_not_guessed(self):
        """An unrecognised session word must yield NO season evidence at all.

        Inventing a season is the exact failure mode this project forbids, so the
        guarantee is stronger than "low confidence": the field is simply absent.
        A real month that maps in the regex but not in caie.yaml takes the
        zero-confidence path, asserted separately below.
        """
        ctx = DocumentContext(path="x.pdf", filename="x.pdf", stem="x", suffix=".pdf",
                              first_page_text="CHEMISTRY\n9701/22\nPaper 2\nFlorptober 2026\n")
        ev = [e for e in self.a.identify_session(ctx) if e.field == "season"]
        self.assertEqual(ev, [], f"a season was invented from an unknown month: {ev}")
        # the year is still readable, and only the year
        years = {e.value for e in self.a.identify_session(ctx) if e.field == "year"}
        self.assertEqual(years, {2026})

    def test_month_mapped_in_regex_but_absent_from_config_is_zero_confidence(self):
        """If caie.yaml lacks an alias for a real month, say so — never guess."""
        a = get_adapter("CAIE")
        original = a._session_aliases
        try:
            a._session_aliases = lambda: {}          # simulate a config gap
            ctx = DocumentContext(
                path="x.pdf", filename="x.pdf", stem="x", suffix=".pdf",
                first_page_text="CHEMISTRY\n9701/22\nPaper 2\nMay/June 2026\n")
            ev = [e for e in a.identify_session(ctx) if e.field == "season"]
            self.assertTrue(ev)
            self.assertEqual(ev[0].value, "")
            self.assertEqual(ev[0].confidence, 0.0)
            self.assertIn("not guessed", ev[0].detail)
        finally:
            a._session_aliases = original

    def test_no_text_yields_no_evidence(self):
        """A collector that finds nothing returns nothing — never a default."""
        ctx = DocumentContext(path="x.pdf", filename="x.pdf", stem="x", suffix=".pdf",
                              first_page_text="", full_text="")
        for m in ("identify_document", "identify_subject", "identify_session",
                  "identify_component", "identify_document_type",
                  "identify_question_structure", "identify_mark_scheme",
                  "identify_examiner_report"):
            with self.subTest(method=m):
                self.assertEqual(getattr(self.a, m)(ctx), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
