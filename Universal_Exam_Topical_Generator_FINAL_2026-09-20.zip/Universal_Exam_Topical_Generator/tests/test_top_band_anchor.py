"""RS-64 regression tests — the 20 px verified-white top band invariant.

CROPPING_LOCK.md Amendment 2 requires exactly 20 rows of verified white space above
the first ink in every QP crop, measured at final 2280 px width.

These tests exist because the invariant was silently violated in production output for
an unknown period. Gold's ``_align_top_white_band_final`` was called only from
``crop_page_segments`` (question_split.py:1480), which the active cropping engine never
invokes. Worse, two transforms inside ``OutputManager._save_image`` run *after* any
anchor applied earlier and undo it:

* ``scrub_barcode_bands`` paints barcode bands white, adding white above first ink
  (measured bands of 82 and 93 px on real papers);
* the exact-width LANCZOS resize scales the band by ``2280/w``, shrinking a 20 px
  pre-cut to 15/16 px.

The fix anchors at the save choke point, immediately before ``image.save()``, so the
invariant holds on the written artefact. These tests guard that placement directly: they
call ``_save_image`` and measure the file that lands on disk, so an anchor moved earlier
in the pipeline — or removed — fails here.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from core.output_manager import OutputManager  # noqa: E402

# The lock's own ink criterion: a row counts as ink when at least 2 pixels are < 250.
INK_THRESHOLD = 250
INK_MIN_PIXELS = 2
QUESTION_TOP_GUARD_PX = 20


def measure_band(path: Path) -> int:
    """Rows of white above the first ink row, per CROPPING_LOCK.md Amendment 2."""
    gray = np.asarray(Image.open(path).convert("L"))
    ink_rows = np.where((gray < INK_THRESHOLD).sum(axis=1) >= INK_MIN_PIXELS)[0]
    return int(ink_rows.min()) if ink_rows.size else -1


def make_page(width: int, height: int, first_ink_row: int) -> Image.Image:
    """White page with a solid ink block starting at ``first_ink_row``."""
    img = Image.new("RGB", (width, height), "white")
    block = Image.new("RGB", (width - 400, 300), "black")
    img.paste(block, (200, first_ink_row))
    return img


@pytest.fixture
def manager(tmp_path):
    return OutputManager(output_root=tmp_path, target_width=2280, quality=95)


class TestTopBandAnchor:
    """The written QP artefact must carry exactly 20 px of verified white."""

    @pytest.mark.parametrize(
        "starting_band",
        [
            pytest.param(93, id="band_too_large_93_real_9231_case"),
            pytest.param(82, id="band_too_large_82_real_9231_case"),
            pytest.param(40, id="band_too_large_40"),
            pytest.param(15, id="band_too_small_15_real_9701_case"),
            pytest.param(16, id="band_too_small_16_real_9701_case"),
            pytest.param(0, id="band_zero_ink_at_top_edge"),
            pytest.param(20, id="band_already_correct_20"),
        ],
    )
    def test_saved_qp_band_is_exactly_20(self, manager, tmp_path, starting_band):
        src = make_page(2280, 3000, starting_band)
        out = tmp_path / "22_Spring_2026_Q1.webp"

        manager._save_image(src, out)

        assert out.exists()
        assert measure_band(out) == QUESTION_TOP_GUARD_PX, (
            f"QP saved with band {measure_band(out)} px, expected exactly "
            f"{QUESTION_TOP_GUARD_PX} (input band was {starting_band})"
        )

    def test_width_invariant_preserved(self, manager, tmp_path):
        """Anchoring must not disturb the locked 2280 px width."""
        out = tmp_path / "22_Spring_2026_Q1.webp"
        manager._save_image(make_page(2280, 3000, 93), out)
        assert Image.open(out).size[0] == 2280

    def test_undersized_input_still_anchored_after_resize(self, manager, tmp_path):
        """A narrower input is resized to 2280 — the band must be anchored AFTER that.

        This is the exact ordering bug: resizing scales the band, so anchoring before
        the resize yields ~15/16 px instead of 20.
        """
        out = tmp_path / "22_Spring_2026_Q1.webp"
        manager._save_image(make_page(1800, 2400, 20), out)

        img = Image.open(out)
        assert img.size[0] == 2280, "width was not normalised to 2280"
        assert measure_band(out) == QUESTION_TOP_GUARD_PX, (
            "band drifted through the exact-width resize — anchor is running before "
            "the resize instead of after it"
        )

    def test_format_is_webp(self, manager, tmp_path):
        out = tmp_path / "22_Spring_2026_Q1.webp"
        manager._save_image(make_page(2280, 3000, 93), out)
        assert Image.open(out).format == "WEBP"

    def test_content_is_never_clipped(self, manager, tmp_path):
        """Trimming the oversized band must not remove any ink.

        Ink block height is 300 px; it must survive in full.
        """
        out = tmp_path / "22_Spring_2026_Q1.webp"
        manager._save_image(make_page(2280, 3000, 93), out)

        gray = np.asarray(Image.open(out).convert("L"))
        ink_rows = np.where((gray < INK_THRESHOLD).sum(axis=1) >= INK_MIN_PIXELS)[0]
        assert ink_rows.size >= 300, (
            f"ink block lost rows: {ink_rows.size} ink rows survived, expected >= 300"
        )

    @pytest.mark.parametrize("suffix", ["_MS", "_CI", "_IN"])
    def test_auxiliary_crops_are_not_anchored(self, manager, tmp_path, suffix):
        """MS/CI/IN come from the RULE-6 pristine engine — geometry must not change."""
        out = tmp_path / f"11_Winter_2025_Q1{suffix}.webp"
        manager._save_image(make_page(2280, 3000, 93), out)

        assert out.exists()
        assert measure_band(out) == 93, (
            f"{suffix} crop was modified by the QP band anchor; RULE-6 outputs must "
            f"pass through untouched"
        )

    def test_anchor_uses_gold_implementation(self):
        """The anchor must be gold's function, never a reimplementation.

        Guards against a second crop engine being built, which CROPPING_LOCK.md forbids.
        """
        import inspect

        from core import output_manager

        src = inspect.getsource(output_manager.OutputManager._save_image)
        assert "_align_top_white_band_final" in src, (
            "_save_image no longer calls gold's _align_top_white_band_final"
        )
        assert "from cambridge_qb import question_split" in src, (
            "anchor is no longer sourced from the gold cambridge_qb package"
        )

    def test_anchor_refusal_is_not_fatal(self, manager, tmp_path, monkeypatch):
        """If gold refuses to trim (would clip ink), the image must still be saved."""
        from cambridge_qb import question_split as gold_qs

        def _refuse(img):
            raise AssertionError("would clip ink")

        monkeypatch.setattr(
            gold_qs, "_align_top_white_band_final", _refuse, raising=False
        )
        out = tmp_path / "22_Spring_2026_Q1.webp"

        manager._save_image(make_page(2280, 3000, 93), out)

        assert out.exists(), "image was not saved after the anchor refused"
        assert measure_band(out) == 93, "refused anchor should leave geometry untouched"
