"""
adapters.registry — board adapter discovery and lookup.

Spec §15.1: "Adding a board = new adapter package + qualification registry
entries + research documents + corpus fixtures + tests. The core engine is never
modified for a new board."

This module is the ONLY place that knows which adapter classes exist. It
discovers them dynamically from `adapters/*/adapter.py`, so adding a board
requires no edit here.

Board *knowledge* (sessions, qualifications, document types, component grammar,
MCQ rules, downloader sources, naming) lives in `config/boards/<board>.yaml` and
is loaded as data. Adding a board's facts requires no Python change either.
"""
from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path
from typing import Any, Dict, List, Optional

from universal.config import PROJECT_ROOT, load_config

BOARDS_DIR = PROJECT_ROOT / "config" / "boards"
ADAPTERS_DIR = Path(__file__).resolve().parent

# Boards that are NOT first-class but are reserved by spec §0.11 / §15.7.
OPTIONAL_BOARDS = ("ocr", "wjec_eduqas")


def load_board_config(board_id: str) -> Dict[str, Any]:
    """Load config/boards/<board_id>.yaml as plain data. Returns {} if absent."""
    path = BOARDS_DIR / f"{board_id.lower()}.yaml"
    if not path.exists():
        return {}
    try:
        import yaml  # type: ignore
    except ImportError:  # pragma: no cover
        return {}
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def available_board_ids() -> List[str]:
    """Every board that has a config/boards/*.yaml file (data-driven)."""
    if not BOARDS_DIR.exists():
        return []
    return sorted(p.stem.upper() for p in BOARDS_DIR.glob("*.yaml"))


def load_all_board_configs() -> Dict[str, Dict[str, Any]]:
    return {b: load_board_config(b) for b in available_board_ids()}


# ---------------------------------------------------------------------------
# Adapter discovery
# ---------------------------------------------------------------------------
_ADAPTERS: Dict[str, Any] = {}
_DISCOVERED = False
_DISCOVERY_ERRORS: Dict[str, str] = {}


def _discover() -> None:
    """Import every adapters/<name>/adapter.py exposing a class named
    `Adapter` (or the first BoardAdapter subclass found)."""
    global _DISCOVERED
    if _DISCOVERED:
        return
    _DISCOVERED = True
    from adapters.base import BoardAdapter

    for mod_info in pkgutil.iter_modules([str(ADAPTERS_DIR)]):
        if not mod_info.ispkg:
            continue
        name = mod_info.name
        mod_path = ADAPTERS_DIR / name / "adapter.py"
        if not mod_path.exists():
            continue
        try:
            mod = importlib.import_module(f"adapters.{name}.adapter")
        except Exception as exc:  # isolate: one broken adapter must not kill all
            _DISCOVERY_ERRORS[name] = f"{type(exc).__name__}: {exc}"
            continue
        cls = getattr(mod, "Adapter", None)
        if cls is None:
            for attr in vars(mod).values():
                if (isinstance(attr, type) and issubclass(attr, BoardAdapter)
                        and attr is not BoardAdapter):
                    cls = attr
                    break
        if cls is None:
            _DISCOVERY_ERRORS[name] = "no Adapter class / BoardAdapter subclass found"
            continue
        board_id = (getattr(cls, "BOARD_ID", "") or name).upper()
        _ADAPTERS[board_id] = cls


def get_adapter(board_id: str) -> Optional[Any]:
    """Instantiate the adapter for a board, injecting its YAML config."""
    _discover()
    cls = _ADAPTERS.get(str(board_id).upper())
    if cls is None:
        return None
    cfg = load_board_config(board_id)
    try:
        return cls(config=cfg)
    except TypeError:
        return cls()


def get_all_adapters() -> Dict[str, Any]:
    """Instantiate every discovered adapter. Failures are recorded, not raised."""
    _discover()
    out: Dict[str, Any] = {}
    for board_id in list(_ADAPTERS):
        inst = get_adapter(board_id)
        if inst is not None:
            out[board_id] = inst
    return out


def discovery_errors() -> Dict[str, str]:
    _discover()
    return dict(_DISCOVERY_ERRORS)


def registry_report() -> Dict[str, Any]:
    """Descriptive snapshot used by analytics / the launcher. Never fabricates:
    a board with a YAML config but no adapter is reported as CONFIG_ONLY."""
    _discover()
    cfgs = load_all_board_configs()
    rows = []
    for board_id in sorted(set(cfgs) | set(_ADAPTERS)):
        cfg = cfgs.get(board_id, {})
        has_adapter = board_id in _ADAPTERS
        rows.append({
            "board_id": board_id,
            "display_name": cfg.get("display_name", board_id),
            "support_status": cfg.get("support_status", "NOT_STARTED"),
            "first_class": bool(cfg.get("first_class", False)),
            "config_file": f"config/boards/{board_id.lower()}.yaml" if board_id in cfgs else None,
            "adapter": f"adapters/{board_id.lower()}/adapter.py" if has_adapter else None,
            "sessions": len(cfg.get("sessions") or []),
            "qualifications": len(cfg.get("qualifications") or []),
            "document_types": len(cfg.get("document_types") or {}),
            "state": "READY" if (has_adapter and board_id in cfgs)
                     else ("CONFIG_ONLY" if board_id in cfgs else "ADAPTER_ONLY"),
            "optional": board_id.lower() in OPTIONAL_BOARDS,
        })
    return {
        "boards_configured": len(cfgs),
        "boards_with_adapter": len(_ADAPTERS),
        "discovery_errors": dict(_DISCOVERY_ERRORS),
        "boards": rows,
    }


__all__ = ["load_board_config", "available_board_ids", "load_all_board_configs",
           "get_adapter", "get_all_adapters", "discovery_errors",
           "registry_report", "BOARDS_DIR", "OPTIONAL_BOARDS"]
