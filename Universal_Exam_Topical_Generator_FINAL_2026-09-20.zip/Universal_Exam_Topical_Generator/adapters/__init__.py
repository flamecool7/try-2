"""adapters — one package per examination board.

Adding a board = new adapter package + qualification registry entries + research
documents + corpus fixtures. The core engine is never modified (spec §15.1).
"""
