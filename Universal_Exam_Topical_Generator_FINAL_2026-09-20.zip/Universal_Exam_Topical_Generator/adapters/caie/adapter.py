"""CAIE board adapter.

Thin, data-driven translation layer between the universal identity engine and the
existing gold CAIE pipeline. It owns no crop logic and no naming logic:

* cropping stays in `core/cropping_engine.py` wrapping the locked gold splitter;
* canonical naming stays in `core/output_manager.py::save_question_pair`;
* filename parsing stays in `core/paper_identifier.py` (reused, never duplicated).

What this adapter adds is CAIE-specific *reading* of a document into `Evidence`
records, driven by `config/boards/caie.yaml` rather than by constants in code.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from adapters.base import BoardAdapter, DocumentContext, Evidence

# Cambridge cover pages print "<syllabus>/<component>" and an explicit session.
_CODE_COMPONENT = re.compile(r"\b(\d{4})/(\d{1,2})\b")
_SESSION = re.compile(
    r"\b(may/june|february/march|october/november|june|may|march|february|"
    r"november|october|september)\s+(19|20)(\d{2})\b", re.I)
_YEAR4 = re.compile(r"\b(19\d{2}|20\d{2})\b")


class Adapter(BoardAdapter):
    BOARD_ID = "CAIE"
    BOARD_NAMES = ["CAIE", "CIE", "Cambridge", "Cambridge International",
                   "Cambridge Assessment International Education"]
    CONFIG_FILE = "caie.yaml"
    HAS_EXAMINER_REPORTS = True
    HAS_INSERTS = True

    # -- helpers -------------------------------------------------------------
    def _signatures(self) -> List[str]:
        sig = self.config.get("signatures") or {}
        if isinstance(sig, dict):
            out: List[str] = []
            for v in sig.values():
                if isinstance(v, list):
                    out.extend(str(x).lower() for x in v)
                elif v:
                    out.append(str(v).lower())
            return out
        return [str(x).lower() for x in sig]

    def _session_aliases(self) -> Dict[str, List[str]]:
        out: Dict[str, List[str]] = {}
        for s in self.config.get("sessions", []) or []:
            code = str(s.get("code", "")).lower()
            if not code:
                continue
            aliases = [str(a).lower() for a in (s.get("aliases") or [])]
            aliases += [str(t).lower() for t in (s.get("filename_tokens") or [])]
            aliases += [str(m).lower() for m in (s.get("months") or [])]
            out[code] = sorted(set(aliases))
        return out

    def _doc_type_tokens(self, content: bool = True) -> Dict[str, List[str]]:
        """Document-type tokens from caie.yaml, split by where they may be used.

        The config mixes two different kinds of token in one list: short filename
        codes ("qp", "ms", "er", "in") and real cover-text phrases ("question
        paper", "mark scheme"). They are NOT interchangeable.

        Verified failure when they were treated alike: Cambridge mark-scheme and
        examiner-report covers both print the word "Paper" ("Paper 1 Multiple
        Choice (Core)", "Paper 0620/12"), which matched the QP token "paper" and
        mislabelled every MS and ER as a question paper. Dict ordering then made
        QP win and `break` hid the rest.

        So for CONTENT matching only multi-word / long phrases are used, on word
        boundaries, and the most specific match wins. Short codes are used only
        against the filename.
        """
        out: Dict[str, List[str]] = {}
        dt = self.config.get("document_types") or {}
        items = dt.items() if isinstance(dt, dict) else [
            (str(d.get("code", "")), d) for d in dt]
        for code, spec in items:
            if not code:
                continue
            toks: List[str] = []
            if isinstance(spec, dict):
                for key in ("aliases", "tokens", "filename_tokens", "phrases"):
                    toks += [str(t).lower() for t in (spec.get(key) or [])]
            elif isinstance(spec, list):
                toks = [str(t).lower() for t in spec]
            toks = sorted(set(toks))
            if content:
                # A usable cover phrase has a space, or is long enough not to be a
                # bare code. "paper" alone is rejected: it appears on MS and ER too.
                toks = [t for t in toks if (" " in t or len(t) >= 6)
                        and t not in ("paper", "papers", "question", "document")]
            else:
                toks = [t for t in toks if " " not in t]
            if toks:
                out[str(code).lower()] = toks
        return out

    # -- the nine required identify_* methods --------------------------------
    def identify_document(self, ctx: DocumentContext) -> List[Evidence]:
        """Board-level evidence: is this a Cambridge document at all?"""
        out: List[Evidence] = []
        hay = f"{ctx.first_page_text}\n{ctx.ocr_text}".lower()
        if not hay.strip():
            return out
        for sig in self._signatures():
            if len(sig) > 3 and sig in hay:
                out.append(Evidence(kind="board_signature", field="board",
                                    value=self.BOARD_ID, confidence=1.0,
                                    detail=f"cover text contains {sig!r}",
                                    locator="page 1"))
                break
        # A Cambridge "<code>/<component>" pair on the cover is itself decisive.
        m = _CODE_COMPONENT.search(ctx.first_page_text or "")
        if m:
            out.append(Evidence(kind="qualification_code", field="board",
                                value=self.BOARD_ID, confidence=0.9,
                                detail=f"CAIE code/component pair {m.group(0)!r}",
                                locator="page 1"))
        return out

    def identify_subject(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        head = (ctx.first_page_text or "")[:1500]
        for q in self.qualifications:
            code = str(q.get("syllabus_code") or q.get("code") or "")
            subject = str(q.get("subject") or q.get("name") or "")
            if not code:
                continue
            if code in ctx.filename or code in head:
                out.append(Evidence(
                    kind="qualification_code", field="syllabus_code", value=code,
                    confidence=1.0 if code in head else 0.6,
                    detail=f"syllabus code {code} "
                           f"{'on cover page' if code in head else 'in filename only'}",
                    locator="page 1" if code in head else "filename"))
            if subject and subject.lower() in head.lower():
                out.append(Evidence(kind="first_page_text", field="subject",
                                    value=subject, confidence=0.8,
                                    detail=f"subject title {subject!r} on cover",
                                    locator="page 1"))
        m = _CODE_COMPONENT.search(ctx.first_page_text or "")
        if m and not any(e.field == "syllabus_code" for e in out):
            out.append(Evidence(kind="qualification_code", field="syllabus_code",
                                value=m.group(1), confidence=0.95,
                                detail=f"cover code/component pair {m.group(0)!r}",
                                locator="page 1"))
        return out

    def identify_qualification(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        low = (ctx.first_page_text or "").lower()
        for name, folder in (self.config.get("qualification_folder_names") or {}).items():
            if str(name).lower() in low:
                out.append(Evidence(kind="first_page_text", field="qualification",
                                    value=folder or name, confidence=0.9,
                                    detail=f"cover names the qualification {name!r}",
                                    locator="page 1"))
                break
        return out

    def identify_session(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        text = ctx.first_page_text or ctx.ocr_text or ""
        m = _SESSION.search(text)
        if m:
            word = m.group(1).lower()
            year = int(m.group(2) + m.group(3))
            code = ""
            for c, aliases in self._session_aliases().items():
                if word in aliases:
                    code = c
                    break
            out.append(Evidence(kind="first_page_text", field="year", value=year,
                                confidence=1.0, detail=f"session string {m.group(0)!r}",
                                locator="page 1"))
            if code:
                out.append(Evidence(kind="first_page_text", field="season", value=code,
                                    confidence=1.0,
                                    detail=f"{m.group(1)!r} maps to session {code!r}",
                                    locator="page 1"))
            else:
                out.append(Evidence(kind="first_page_text", field="season", value="",
                                    confidence=0.0,
                                    detail=f"month {m.group(1)!r} is not mapped to a "
                                           "session code in caie.yaml — not guessed",
                                    locator="page 1"))
        else:
            seen: List[int] = []
            for mm in _YEAR4.finditer(text[:2000]):
                y = int(mm.group(1))
                if y not in seen:
                    seen.append(y)
            for i, y in enumerate(seen[:3]):
                out.append(Evidence(kind="first_page_text", field="year", value=y,
                                    confidence=0.5 if i == 0 else 0.3,
                                    detail=f"bare year on cover "
                                           f"({len(seen)} distinct found)",
                                    locator="page 1"))
        return out

    def identify_component(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        m = _CODE_COMPONENT.search(ctx.first_page_text or "")
        if m:
            out.append(Evidence(
                kind="component_code", field="component", value=m.group(2),
                confidence=1.0, detail=f"cover pair {m.group(0)!r}", locator="page 1"))
            # Cambridge encodes <paper><variant> in the component. Reuse the
            # canonical parser rather than re-deriving the rule here.
            try:
                from core.paper_identifier import _component_paper_number_local
                out.append(Evidence(
                    kind="component_code", field="paper_number",
                    value=_component_paper_number_local(m.group(2)), confidence=1.0,
                    detail="via core.paper_identifier (single source of truth; "
                           "handles zero-padded codes per RS-61)", locator="page 1"))
            except Exception as exc:                      # pragma: no cover
                out.append(Evidence(kind="component_code", field="paper_number",
                                    value=None, confidence=0.0,
                                    detail=f"paper-number derivation unavailable: {exc}"))
        return out

    def identify_document_type(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        low_first = (ctx.first_page_text or "").lower()
        low_full = (ctx.full_text or ctx.first_page_text or "").lower()
        # A document's own type is declared by its HEADING, not by prose that
        # references other documents. This matters: Cambridge mark-scheme
        # boilerplate reads "Mark schemes should be read in conjunction with the
        # question paper and the principal examiner report for teachers", so an MS
        # cover page contains the phrases for all three types at once. Verified on
        # 0625_s24_ms_11: longest-match picked "er", first-match picked "qp"; the
        # heading ("MARK SCHEME" on its own line) is the only correct answer.
        #
        # Rank 1: phrase occupying its own line (a heading).
        # Rank 2: earliest phrase occurrence anywhere on the page.
        heading: Optional[tuple] = None
        for code, toks in self._doc_type_tokens(content=True).items():
            for t in toks:
                m = re.search(r"(?im)^\s*" + re.escape(t) + r"\s*$", low_first)
                if m and (heading is None or m.start() < heading[2]):
                    heading = (code, t, m.start())
        if heading:
            out.append(Evidence(kind="header_footer", field="document_type",
                                value=heading[0], confidence=0.97,
                                detail=f"cover heading {heading[1]!r} on its own line",
                                locator="page 1"))
        elif self._qp_instruction_signature(low_first):
            # Cambridge question papers never print "Question Paper" as a heading.
            # They print "Paper 2 AS Level Structured Questions", then an
            # INSTRUCTIONS block, a duration and "You must answer on the question
            # paper." Mark schemes and examiner reports have none of these, so the
            # combination is a positive identification rather than an inference
            # from a cross-reference. Verified on 9701_m26_qp_22 and 9231_w25_qp_11.
            out.append(Evidence(
                kind="question_structure", field="document_type", value="qp",
                confidence=0.93,
                detail="candidate-facing instruction block (Paper N heading + "
                       "duration + INSTRUCTIONS + 'answer on the question paper')",
                locator="page 1"))
        else:
            earliest: Optional[tuple] = None
            for code, toks in self._doc_type_tokens(content=True).items():
                for t in toks:
                    m = re.search(r"\b" + re.escape(t) + r"\b", low_first)
                    if m and (earliest is None or m.start() < earliest[2]):
                        earliest = (code, t, m.start())
            if earliest:
                out.append(Evidence(
                    kind="header_footer", field="document_type", value=earliest[0],
                    confidence=0.5,
                    detail=f"no standalone heading matched; earliest phrase "
                           f"{earliest[1]!r} at offset {earliest[2]} (low confidence — "
                           "may be a cross-reference, not self-identification)",
                    locator="page 1"))
        # Structural corroboration. Kept STRICT: "total ... mark" also appears on
        # question-paper covers, so it must not be used as a mark-scheme signal
        # (this produced false conflicts on real QPs — see Milestone 3 report §3.1).
        rows = re.findall(r"(?m)^\s*(\d{1,2})\s*\(\s?([a-f])\s?\)\s*[;=]?\s*$",
                          low_full[:30000])
        if len({(int(a), b) for a, b in rows}) >= 4 and "question paper" not in low_first:
            out.append(Evidence(kind="mark_scheme_structure", field="document_type",
                                value="ms", confidence=0.9,
                                detail=f"{len(set(rows))} mark-grid rows, no "
                                       "'Question Paper' header", locator="body"))
        qnums = re.findall(r"(?m)^\s*(\d{1,2})\s*[\.\)]\s", low_full[:20000])
        uniq = {int(n) for n in qnums if 1 <= int(n) <= 60}
        if len(uniq) >= 2:
            out.append(Evidence(kind="question_structure", field="document_type",
                                value="qp", confidence=0.8,
                                detail=f"{len(uniq)} distinct question numbers",
                                locator="body"))
        if re.search(r"\bspecimen\b", low_first):
            out.append(Evidence(kind="header_footer", field="document_type",
                                value="specimen", confidence=1.0,
                                detail="cover says specimen", locator="page 1"))
        return out

    def identify_question_structure(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        text = ctx.full_text or ctx.first_page_text or ""
        qnums = re.findall(r"(?m)^\s*(\d{1,2})\s*[\.\)]\s", text[:40000])
        uniq = sorted({int(n) for n in qnums if 1 <= int(n) <= 60})
        if uniq:
            out.append(Evidence(kind="question_structure", field="question_numbers",
                                value=uniq, confidence=0.9,
                                detail=f"{len(uniq)} anchors, max {max(uniq)}",
                                locator="body"))
        mcq = re.findall(r"(?m)^\s*(\d{1,2})\s*[\.\)]?\s*\n?\s*[ABCD]\s", text[:40000])
        if mcq:
            out.append(Evidence(kind="question_structure", field="mcq_option_layout",
                                value=len(mcq), confidence=0.6,
                                detail="A/B/C/D option layout detected", locator="body"))
        return out

    def identify_mark_scheme(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        text = ctx.full_text or ctx.first_page_text or ""
        rows = re.findall(r"(?m)^\s*(\d{1,2})\s*\(\s?([a-f])\s?\)\s*[;=]?(\s*\d+\s*)?$",
                          text[:40000])
        if rows:
            out.append(Evidence(kind="mark_scheme_structure", field="mark_grid_rows",
                                value=len(rows), confidence=0.85,
                                detail="question/part mark-grid rows", locator="body"))
        if re.search(r"(?m)^\s*\d+\s+\(\s?[a-f]\s?\)\s+[A-Za-z]", text[:40000]):
            out.append(Evidence(kind="mark_scheme_structure", field="has_answer_text",
                                value=True, confidence=0.7,
                                detail="mark rows carry answer wording", locator="body"))
        return out

    def identify_examiner_report(self, ctx: DocumentContext) -> List[Evidence]:
        out: List[Evidence] = []
        low = (ctx.first_page_text or "").lower()
        # Neither "principal examiner" nor "examiner report" may be matched in
        # running prose: mark-scheme covers contain BOTH ("prepared by the
        # Principal Examiner" and "read in conjunction with ... the principal
        # examiner report for teachers"), which produced a false `er` on real MS
        # documents. Require the phrase as a standalone heading line.
        if re.search(r"(?im)^\s*(principal\s+examiner\s+report(\s+for\s+teachers)?|"
                     r"examiners?\s+report|examiner\s+comments)\s*$", low):
            out.append(Evidence(kind="examiner_report_structure",
                                field="document_type", value="er", confidence=0.95,
                                detail="cover identifies an examiner report",
                                locator="page 1"))
        # ERs are series-level: no component. Record that absence explicitly so a
        # missing variant is never treated as incomplete (Milestone 3 §2).
        if any(e.value == "er" for e in out):
            out.append(Evidence(kind="examiner_report_structure", field="variant",
                                value="", confidence=1.0,
                                detail="Cambridge examiner reports are variantless "
                                       "by design", locator="n/a"))
        return out

    @staticmethod
    def _qp_instruction_signature(low_first: str) -> bool:
        """True when page 1 carries a Cambridge candidate instruction block."""
        if not low_first:
            return False
        signals = 0
        if re.search(r"(?m)^\s*paper\s+\d+\s+\S", low_first):
            signals += 1                      # "Paper 2 AS Level Structured Questions"
        if re.search(r"\byou must answer on the question paper\b", low_first):
            signals += 1
        if re.search(r"(?m)^\s*instructions\s*$", low_first):
            signals += 1
        if re.search(r"\b\d+\s+hours?\b|\b\d+\s+minutes\b", low_first):
            signals += 1                      # duration line
        if re.search(r"\bno additional materials are needed\b|"
                     r"\byou will need\b", low_first):
            signals += 1
        # Require several independent signals: any one alone could appear in an
        # examiner report quoting the paper.
        return signals >= 3

    # -- naming --------------------------------------------------------------
    def normalize_name(self, raw: str) -> str:
        """Trim/collapse only. Never re-case or re-order a Cambridge name."""
        return re.sub(r"\s+", " ", str(raw or "")).strip()
