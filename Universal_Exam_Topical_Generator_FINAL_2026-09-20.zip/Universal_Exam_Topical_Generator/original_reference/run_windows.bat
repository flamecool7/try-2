@echo off
REM ============================================================================
REM  Cambridge Topical Question-Bank Generator (Universal Windows Launcher)
REM ============================================================================
title Cambridge Topical Question-Bank Generator
cd /d "%~dp0"

cls
echo ============================================================================
echo   CAMBRIDGE TOPICAL QUESTION-BANK GENERATOR
echo   Multi-Topic Classification, Reference Removal, and Precision Cropping
echo ============================================================================
echo.

REM --- Step 1: Detect Python Command ---
set "PYTHON_EXE="

where python >nul 2>nul
if %errorlevel% equ 0 set "PYTHON_EXE=python"

if "%PYTHON_EXE%"=="" (
    where py >nul 2>nul
    if %errorlevel% equ 0 set "PYTHON_EXE=py -3"
)

if "%PYTHON_EXE%"=="" (
    where python3 >nul 2>nul
    if %errorlevel% equ 0 set "PYTHON_EXE=python3"
)

if "%PYTHON_EXE%"=="" (
    echo [ERROR] Python 3 was not found on your system.
    echo.
    echo To fix this:
    echo   1. Download Python 3.10+ from https://www.python.org/downloads/
    echo   2. During installation, CHECK the box: "Add Python to PATH"
    echo   3. Re-run this file.
    echo.
    pause
    exit /b 1
)

echo [OK] Python detected: %PYTHON_EXE%
echo.

REM --- Step 2: Ensure Directories Exist ---
if not exist "papers" mkdir "papers"
if not exist "Cambridge_Question_Bank" mkdir "Cambridge_Question_Bank"

REM --- Step 3: Install / Verify Dependencies ---
echo [1/3] Verifying Python packages...
%PYTHON_EXE% -m pip install -q -r requirements.txt >nul 2>nul
if %errorlevel% neq 0 (
    echo Installing required packages (PyMuPDF, Pillow, numpy, ImageHash)...
    %PYTHON_EXE% -m pip install PyMuPDF Pillow numpy imagehash reportlab requests PyWavelets
)
echo [OK] Dependencies verified.
echo.

REM --- Step 4: Count PDF Files ---
set "PDF_COUNT=0"
for %%F in (papers\*.pdf) do set /a PDF_COUNT+=1

echo [2/3] Checking input folder: %~dp0papers\
echo       Found %PDF_COUNT% PDF file(s) in "papers\"
echo.

if %PDF_COUNT% equ 0 (
    echo ============================================================================
    echo  NOTICE: The "papers" folder is currently empty.
    echo  Please place your Cambridge question paper and mark scheme PDFs into:
    echo    %~dp0papers\
    echo.
    echo  Example File Names:
    echo    Question papers: 9701_s24_qp_22.pdf
    echo    Mark schemes:    9701_s24_ms_22.pdf
    echo ============================================================================
    echo.
)

REM --- Step 5: Interactive Guide Menu ---
:MENU
echo ============================================================================
echo   MAIN MENU - SELECT AN ACTION
echo ============================================================================
echo   [1] Run Pipeline (Auto-Detect subjects from PDFs in papers\)
echo   [2] Chemistry (Syllabus 9701 / 0620 / 5070)
echo   [3] Physics (Syllabus 9702 / 0625 / 5054)
echo   [4] Biology (Syllabus 9700 / 0610 / 5090)
echo   [5] Mathematics (Syllabus 9709 / 0580 / 9231)
echo   [6] Computer Science (Syllabus 9618 / 9608 / 0478)
echo   [7] Economics (Syllabus 9708 / 0455)
echo   [8] Enter a Custom Syllabus Code
echo   [9] Open "papers" folder in Explorer to paste PDFs
echo   [O] Open "Cambridge_Question_Bank" output folder in Explorer
echo   [L] List all supported topics and syllabi
echo   [Q] Exit
echo ============================================================================
echo.

set "CHOICE=1"
set /p CHOICE="Enter choice (1-9, O, L, Q) [Default: 1]: "

if /i "%CHOICE%"=="Q" goto FINISH
if /i "%CHOICE%"=="9" goto OPEN_PAPERS
if /i "%CHOICE%"=="O" goto OPEN_OUTPUT
if /i "%CHOICE%"=="L" goto LIST_TOPICS
if "%CHOICE%"=="1" goto RUN_AUTO
if "%CHOICE%"=="2" goto RUN_CHEM
if "%CHOICE%"=="3" goto RUN_PHYS
if "%CHOICE%"=="4" goto RUN_BIO
if "%CHOICE%"=="5" goto RUN_MATH
if "%CHOICE%"=="6" goto RUN_CS
if "%CHOICE%"=="7" goto RUN_ECON
if "%CHOICE%"=="8" goto RUN_CUSTOM

REM Fallback default
goto RUN_AUTO

:OPEN_PAPERS
start explorer "%~dp0papers"
goto MENU

:OPEN_OUTPUT
start explorer "%~dp0Cambridge_Question_Bank"
goto MENU

:LIST_TOPICS
cls
%PYTHON_EXE% run_pipeline.py --list-topics
echo.
pause
cls
goto MENU

:RUN_AUTO
set "CODE_FLAG="
goto EXECUTE

:RUN_CHEM
set "CODE_FLAG=--code 9701"
goto EXECUTE

:RUN_PHYS
set "CODE_FLAG=--code 9702"
goto EXECUTE

:RUN_BIO
set "CODE_FLAG=--code 9700"
goto EXECUTE

:RUN_MATH
set "CODE_FLAG=--code 9709"
goto EXECUTE

:RUN_CS
set "CODE_FLAG=--code 9618"
goto EXECUTE

:RUN_ECON
set "CODE_FLAG=--code 9708"
goto EXECUTE

:RUN_CUSTOM
echo.
set "CUSTOM_CODE="
set /p CUSTOM_CODE="Enter 4-digit Cambridge Syllabus Code (e.g. 9701, 9706, 9609): "
if "%CUSTOM_CODE%"=="" (
    set "CODE_FLAG="
) else (
    set "CODE_FLAG=--code %CUSTOM_CODE%"
)
goto EXECUTE

:EXECUTE
echo.
echo ============================================================================
echo   STARTING TOPICAL QUESTION BANK GENERATION...
echo ============================================================================
echo   Input  : %~dp0papers\
echo   Output : %~dp0Cambridge_Question_Bank\
echo.

%PYTHON_EXE% run_pipeline.py --input ./papers --output ./Cambridge_Question_Bank %CODE_FLAG%

echo.
echo ============================================================================
echo   EXECUTION FINISHED
echo ============================================================================
echo.
echo Your generated questions are saved under:
echo   %~dp0Cambridge_Question_Bank\
echo.
set "OPEN_PROMPT=Y"
set /p OPEN_PROMPT="Open output folder in Windows Explorer now? (Y/N) [Default: Y]: "
if /i "%OPEN_PROMPT%"=="Y" start explorer "%~dp0Cambridge_Question_Bank"
if /i "%OPEN_PROMPT%"=="" start explorer "%~dp0Cambridge_Question_Bank"
echo.
pause
goto MENU

:FINISH
echo.
echo Thank you for using Cambridge Topical Question-Bank Generator!
pause
