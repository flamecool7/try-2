#!/usr/bin/env python3
"""
run_pipeline.py - CLI entry point for the Cambridge Topical Screenshot Organizer.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from cambridge_qb import pipeline
from cambridge_qb.config import Config
from cambridge_qb.reference import TOPICS_FILE_FOR_CODE, resolve_topics_file


def _list_available_topics() -> None:
    print("Bundled topic maps:\n")
    grouped = {"A-Level": [], "IGCSE": []}
    for code, rel in sorted(TOPICS_FILE_FOR_CODE.items()):
        level = rel.split("/")[0]
        grouped.setdefault(level, []).append((code, rel))
    for level, items in grouped.items():
        print(f"  {level}:")
        for code, rel in items:
            p = resolve_topics_file(code)
            status = "OK" if p and p.exists() else "MISSING"
            print(f"    {code}  ->  topics/{rel}   [{status}]")
        print()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", default="papers", help="folder of source PDFs")
    ap.add_argument("--output", default="Cambridge_Question_Bank")
    ap.add_argument("--config", default=None)
    ap.add_argument("--syllabus-pdf", "--syllabus", default=None, dest="syllabus")
    ap.add_argument("--topics", default=None)
    ap.add_argument("--subject", default=None)
    ap.add_argument("--level", default=None)
    ap.add_argument("--code", default=None)
    ap.add_argument("--paper-types", default=None,
                    help="comma-separated paper types to process: mcq,structured (default: all)")
    ap.add_argument("--api-key", default=None,
                    help="freeconvert.com API key for PDF-to-WebP conversion")
    ap.add_argument("--list-topics", action="store_true")
    ap.add_argument("--dpi", type=int, default=200)
    ap.add_argument("--quality", type=int, default=88)
    ap.add_argument("--dedup", type=int, default=8)
    args = ap.parse_args(argv)

    if args.list_topics:
        _list_available_topics()
        return 0

    if args.config:
        cfg = Config.load(args.config)
    else:
        cfg = Config()
    cfg.input_dir = args.input
    cfg.output_dir = args.output
    cfg.dpi = args.dpi
    cfg.webp_quality = args.quality
    cfg.dedup_hamming = args.dedup
    if args.syllabus:
        cfg.syllabus_pdf = args.syllabus
    if args.topics:
        cfg.topics_json = args.topics
    if args.subject:
        cfg.subject = args.subject
    if args.level:
        cfg.level = args.level
    if args.code:
        cfg.syllabus_code = args.code
    elif not cfg.syllabus_code:
        # Check if papers in input_dir allow auto-detection of syllabus code
        from cambridge_qb.paper_scan import scan_papers
        found_papers, _ = scan_papers(cfg.input_dir)
        if found_papers:
            cfg.syllabus_code = found_papers[0].syllabus
        else:
            prompt = ("No subject code given. Enter the subject code to run "
                      "(e.g. 9618, 9702, 9701, or press Enter to auto-detect): ")
            try:
                _code = input(prompt).strip()
            except (EOFError, KeyboardInterrupt):
                _code = ""
            if _code:
                cfg.syllabus_code = _code
    if args.paper_types:
        cfg.paper_types = [t.strip() for t in args.paper_types.split(",")]
    if args.api_key:
        cfg.freeconvert_api_key = args.api_key

    result = pipeline.run(cfg)

    print("\n================ PROCESSING SUMMARY ================")
    print(f"Subject            : {result['subject']} ({result['syllabus']})")
    print(f"Level              : {result['level']}")
    print(f"Questions found    : {result['questions']}")
    print(f"Unique (kept)      : {result['unique']}")
    print(f"Duplicates removed : {result['duplicates_removed']}")
    print(f"Topics created     : {', '.join(result['topics_created'])}")
    print(f"Output root        : {result['output_dir']}")
    print("====================================================")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
