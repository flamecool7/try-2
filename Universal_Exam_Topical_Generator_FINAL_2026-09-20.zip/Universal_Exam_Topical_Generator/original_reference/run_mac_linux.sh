#!/usr/bin/env bash
# ============================================================================
#  Cambridge Topical Question-Bank Generator (macOS & Linux Launcher)
# ============================================================================
set -e
cd "$(dirname "$0")"

echo "============================================================================"
echo "  CAMBRIDGE TOPICAL QUESTION-BANK GENERATOR"
echo "  Multi-Topic Classification, Reference Removal, and Precision Cropping"
echo "============================================================================"
echo ""

# --- Step 1: Check Python ---
if command -v python3 >/dev/null 2>&1; then
    PY_CMD="python3"
elif command -v python >/dev/null 2>&1; then
    PY_CMD="python"
else
    echo "[ERROR] Python 3 was not found. Please install Python 3.10+."
    exit 1
fi

echo "[OK] Python detected ($($PY_CMD --version))"
echo ""

# --- Step 2: Install dependencies ---
echo "[1/3] Ensuring required dependencies are installed..."
$PY_CMD -m pip install -q -r requirements.txt || true
echo "[OK] Dependencies ready."
echo ""

# --- Step 3: Check folders ---
mkdir -p papers Cambridge_Question_Bank

PDF_COUNT=$(find papers -maxdepth 1 -name "*.pdf" 2>/dev/null | wc -l || echo 0)
echo "[2/3] Checking input folder (papers/)..."
echo "      Found $PDF_COUNT PDF file(s) in 'papers/'"

if [ "$PDF_COUNT" -eq 0 ]; then
    echo ""
    echo "  ------------------------------------------------------------------------"
    echo "   NOTE: Your 'papers/' folder is currently empty!"
    echo "   Please place your Cambridge exam PDFs in: $(pwd)/papers/"
    echo ""
    echo "   Naming:"
    echo "     Question papers: *_qp_*.pdf  (e.g., 9701_s24_qp_22.pdf)"
    echo "     Mark schemes:    *_ms_*.pdf  (e.g., 9701_s24_ms_22.pdf)"
    echo "  ------------------------------------------------------------------------"
    echo ""
fi

# --- Step 4: Interactive Menu ---
echo "[3/3] Choose an action or subject to run:"
echo ""
echo "  [1] Auto-Detect & Run (Process all PDFs in papers/)"
echo "  [2] Chemistry          (Syllabus 9701 / 0620 / 5070)"
echo "  [3] Physics            (Syllabus 9702 / 0625 / 5054)"
echo "  [4] Biology            (Syllabus 9700 / 0610 / 5090)"
echo "  [5] Mathematics        (Syllabus 9709 / 0580 / 9231)"
echo "  [6] Computer Science   (Syllabus 9618 / 9608 / 0478)"
echo "  [7] Economics          (Syllabus 9708 / 0455)"
echo "  [8] Custom Syllabus Code"
echo "  [L] List all supported topics"
echo "  [Q] Exit"
echo ""
read -p "Select an option (1-8, L, Q) [Default: 1]: " CHOICE
CHOICE=${CHOICE:-1}

case "$CHOICE" in
    [Qq]) exit 0 ;;
    [Ll]) $PY_CMD run_pipeline.py --list-topics; exit 0 ;;
    1) CODE_ARG="" ;;
    2) CODE_ARG="--code 9701" ;;
    3) CODE_ARG="--code 9702" ;;
    4) CODE_ARG="--code 9700" ;;
    5) CODE_ARG="--code 9709" ;;
    6) CODE_ARG="--code 9618" ;;
    7) CODE_ARG="--code 9708" ;;
    8)
        read -p "Enter 4-digit Cambridge Syllabus Code (e.g. 9701, 9706): " CUSTOM_CODE
        CODE_ARG="--code $CUSTOM_CODE"
        ;;
    *) CODE_ARG="" ;;
esac

echo ""
echo "============================================================================"
echo "  STARTING PIPELINE EXECUTION..."
echo "============================================================================"
$PY_CMD run_pipeline.py --input ./papers --output ./Cambridge_Question_Bank $CODE_ARG

echo ""
echo "============================================================================"
echo "  PIPELINE COMPLETE!"
echo "  Output saved to: $(pwd)/Cambridge_Question_Bank/"
echo "============================================================================"
