# Cambridge Topical Question Bank Generator

An advanced, professional-grade system for converting Cambridge A-Level and IGCSE exam papers into topic-organized question banks with intelligent question extraction, automatic chemistry reference removal, context-aware cropping, and multi-topic classification.

---

## Key Features

- **Intelligent Question Detection**: Multi-pattern question detection (`1`, `1.`, `1 (a)`, `Question 1`), typography/margin analysis, and sequence gap healing across diverse paper formats and exam years.
- **Chemistry Reference Material Removal**: Automatically identifies and excludes non-question reference sheets:
  - Periodic Table of Elements
  - Data Booklets & Tables of Chemical Data
  - Qualitative Analysis Notes (Tests for anions, aqueous cations, gases, flame tests)
  - Standard Electrode Potentials ($E^\ominus$) series and half-equations
  - Spectroscopy reference tables ($^1H$ NMR, $^{13}C$ NMR, IR correlation frequencies)
  - Bond energies, ionisation energies, and physical constants
  - Mathematical formulae & statistical tables (MF19, MF9, MF20)
  - Candidate cover pages, lined continuation sheets, and copyright acknowledgements
- **Context-Aware Content Preservation**: Protects all diagrams, molecular structures, reaction mechanisms, curves, apparatus, graphs, tables, and mark allocations `[Total: X]`.
- **Dynamic Adaptive Cropping**: Computes precise per-page header and footer boundaries to prevent cutting off question prompts or question tails.
- **Safe Shared-Page Splitting**: Evaluates both PDF vector drawing bounds and high-resolution raster ink density profiles to cut exclusively inside verified whitespace bands.
- **Multi-Layer Quality Control**: Pre-save validation verifying question number validity, content sufficiency, diagram completeness, and absence of reference contamination with automatic review flagging.
- **Multi-Topic Classification**: Semantic understanding, command word detection, cross-topic patterns (e.g. redox titrations), and cross-folder organization.

---

## Requirements

- Python 3.10+
- PDF files from Cambridge International (A-Level, IGCSE, O-Level)

### Python Dependencies

```bash
pip install -r requirements.txt
```

Required packages:
- `pymupdf` (fitz) - PDF processing & vector drawing analysis
- `Pillow` - Image manipulation & rendering
- `numpy` - Vectorized array and profile processing
- `opencv-python` - Image processing
- `imagehash` - Perceptual hashing for deduplication
- `PyWavelets` - Image analysis

---

## Folder Structure

```
Topical_Generation/
├── cambridge_qb/                  # Core processing package
│   ├── __init__.py
│   ├── question_split.py          # Intelligent question splitting & cropping
│   ├── chemistry_reference.py     # Chemistry reference & back-matter detector
│   ├── quality_control.py         # Multi-layer QC validation engine
│   ├── chemical_concepts.py       # Chemistry semantic analysis
│   ├── topics_enhanced.py         # Multi-topic classifier
│   ├── correction_tracker.py      # Learning & manual correction system
│   ├── markscheme.py              # Mark scheme dispatcher
│   ├── markscheme_split.py        # Structured mark scheme segmentation
│   ├── ms_crop.py                 # Mark scheme tight border cropper
│   ├── config.py                  # Pipeline configuration
│   ├── converter.py               # PDF to WebP renderer
│   ├── dedup.py                   # Deduplication & perceptual hashing
│   ├── metadata.py                # Standardized metadata generation
│   ├── organize.py                # Cross-folder topic directory organizer
│   └── pdf_io.py                  # PyMuPDF rendering & watermark scrubbing
├── papers/                        # Place your PDF papers here (*_qp_*.pdf, *_ms_*.pdf)
├── topics/                        # Topic definition JSON files
│   └── A-Level/
│       └── Chemistry_9701_topics.json
├── syllabi/                       # Reference syllabi
├── foldernamestxt/                # Folder naming templates
├── run_pipeline.py                # Main CLI entrypoint
├── run_mac_linux.sh               # macOS/Linux runner
├── run_windows.bat                # Windows runner
└── requirements.txt
```

---

## How to Run

### Quick Start

1. **Place your PDF files** in the `papers/` folder:
   - Question papers: `9701_s24_qp_22.pdf`, `9701_w23_qp_42.pdf`, etc.
   - Mark schemes: `9701_s24_ms_22.pdf`, `9701_w23_ms_42.pdf`, etc.

2. **Run the pipeline**:
   ```bash
   python run_pipeline.py --input papers --output Cambridge_Question_Bank
   ```

3. **Check the output**:
   Your questions are organized by subject, paper type, and topic under `Cambridge_Question_Bank/`.

---

## Quality Control & Review System

Every extracted question undergoes comprehensive validation:
1. **Valid Question Number**: Confirms standard numbering sequence ($1 \le N \le 120$).
2. **Content Verification**: Checks for meaningful question text or diagrammatic elements.
3. **Reference Material Absence**: Ensures no reference page (e.g. Periodic Table) is misclassified as a question.
4. **Boundary & Dimension Sanity**: Ensures images are not cut off, excessively small ($< 80\text{px}$), or runaway merges.
5. **Shared Page Safety**: Verifies that horizontal cuts between questions occurred strictly in clear whitespace bands without slicing diagrams or text.

Any question with low confidence or anomalies is flagged with `needs_review=True` and detailed diagnostic codes in `Processing_Log.json` and `metadata.json`.

---

**Version**: 2.5 (Intelligent Context-Aware Cropping & Chemistry Reference Removal)
