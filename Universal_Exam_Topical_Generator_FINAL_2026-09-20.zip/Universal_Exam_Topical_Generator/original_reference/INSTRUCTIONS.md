# How to use this topical question-bank generator

You don't need to write or edit any code. Just follow these steps.

## What you need installed on your PC
* **Python 3** (version 3.9 or newer).
* Nothing else — the first run automatically installs the helper packages.

## Step 1 — Put your PDFs in the `papers` folder
Copy the Cambridge PDFs you want to process into the **`papers`** folder.
The filenames must follow the Cambridge pattern, for example:

```
9618_s22_qp_12.pdf     <- question paper
9618_s22_ms_12.pdf     <- mark scheme
9618_s22_qp_22.pdf
9618_s22_ms_22.pdf
```

(`qp` = question paper, `ms` = mark scheme, `s22` = summer 2022, `12` = paper 12)

## Step 2 — Run the generator

**On Windows:**
Double-click **`run_windows.bat`**.

**On macOS / Linux:**
Open a terminal in this folder and run:
```
bash run_mac_linux.sh
```

## Step 3 — Get your results
The topical question bank is written to the **`Cambridge_Question_Bank`** folder.
It is organised as:

```
Cambridge_Question_Bank/
  Computer_Science/
    P2_Problem_Solving_Programming/   (or another paper type folder)
      08_Databases/                   (topic folder)
        12_Summer_2022_Q1/            (one folder per question)
          metadata.json
          12_Summer_2022_Q1.webp        (the question image)
          12_Summer_2022_Q1_MS.webp     (the mark scheme image)
```

Each mark scheme is automatically cropped tightly to the black border of the
Cambridge marking box, with the excess white margins removed.

### Season naming (Spring, not March)
The February/March exam session is always named **Spring** — never `March`.
This applies to question folder names, the `.webp` and `_MS.webp` image
filenames, and the `season` field in every `metadata.json`. So you will see
`42_Spring_2026_Q2.webp`, not `42_March_2026_Q2.webp`.

### Multi-topic tagging
A question may genuinely cover more than one topic. The `metadata.json` records
all qualifying topics in the `topic` field:
- if only one topic qualifies, `topic` is a plain string
  (e.g. `"topic": "Security_privacy_and_data_integrity"`);
- if more than one qualifies, `topic` is an array with the strongest topic first
  (e.g. `"topic": ["Momentum", "Forces", "Energy"]`).

A secondary topic is added only if its score is **greater than 20** AND within
**±50** of the top topic's score. Regardless of how many topics are listed, the
question folder is always placed inside the folder of the **highest-scoring**
topic — the multi-topic list is just a metadata annotation, it never duplicates
the question.

### metadata.json format
Every `metadata.json` is written in a fixed 10-field format (in this exact order):
`id`, `level`, `subject`, `board`, `topic`, `paper`, `question_number`,
`variant`, `season`, `year`.

## Making it work for another subject
The system is fully data-driven. To switch to a different Cambridge subject you
just point it at that subject's topic JSON file instead (the Computer Science
one is used by default). For example, to run it for **Physics** you would pass
`--code 9702` (and add a `topics/A-Level/Physics_9702_topics.json` file in the
same format). The mark-scheme cropping and everything else work for any subject
automatically.

## Testing the installation (optional)
To run the built-in self-tests:
```
python -m pytest tests -q
```
All tests should pass.
