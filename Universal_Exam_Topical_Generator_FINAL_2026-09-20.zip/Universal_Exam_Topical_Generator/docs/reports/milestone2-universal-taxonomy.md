# Milestone 2 — Universal Taxonomy Architecture

**Date:** 2026-09-19
**Status:** IMPLEMENTED and cross-checked against source documents. Not yet exercised
against full real-paper runs (that is the user's separate testing phase).
**Scope:** data-driven topic taxonomy for all five boards, syllabus/version awareness,
cross-board concept identity, plus the approved in-place `paper_identifier.py` patch.

---

## 1. What was built

| Module | Lines | Role |
|---|---|---|
| `universal/taxonomy/registry.py` | 411 | `TopicNode` / `Taxonomy` / `TopicRegistry` data model, lazy load, exact + alias lookup, year→version resolution API |
| `universal/taxonomy/builder.py` | 768 | Builds `taxonomies/**/taxonomy.json` from real sources (CAIE legacy configs, official board PDFs, IB page-fetch text) |
| `universal/taxonomy/extract_official.py` | 336 | Corrected AQA + Pearson Edexcel specification extractors, and `extract_paper_facts()` |
| `universal/taxonomy/versions.py` | 431 | Version intelligence (`versions.json`) + cross-board concept identity (`concepts.json`) |
| `tests/test_component_paper_number.py` | — | 34-test regression lock for the component-code patch |

**Outputs:** 92 `taxonomy.json` files + `registry.json` + `versions.json` + `concepts.json`
under `taxonomies/` (2.2 MB).

No hardcoded topic lists exist in code. Every node is emitted only because a source
document or a repository-ingested config declared it.

---

## 2. Registry result

```
taxonomies: 92   boards: 5   total_nodes: 2168   load_errors: 0
```

| Board | Taxonomies | Topics | Sub-topics | Concepts | Source |
|---|---|---|---|---|---|
| CAIE | 78 | 670 | 719 | 0 | repository-ingested subject configs + detailed-topic JSONs |
| AQA | 6 | 49 | 196 | 0 | official AQA specification PDFs |
| EDEXCEL | 3 | 30 | 54 | 319 | official Pearson Edexcel specification PDFs |
| IB | 3 | 15 | 82 | 0 | official IBO subject briefs (page-fetch) |
| SAT | 2 | 8 | 26 | 0 | official College Board assessment framework PDF |

Every one of the 2,168 nodes carries `built_from` provenance naming a real document,
plus `sha256` and URL where the source is a downloaded PDF.

---

## 3. Verification against the corpus's own PROVEN counts

`TOPICS-FROM-OWN-CORPUS.txt` records counts that were previously extracted from these
same specifications. Those are used as an **independent cross-check**, and the outcome
is stored per taxonomy in `provenance.matches_corpus_counts` — including where it does
not match.

### AQA — 5 of 6 exact

| Spec | Subject | Extracted | Corpus-proven | Result |
|---|---|---|---|---|
| 8462 | Chemistry (GCSE) | 10 / 32 | 10 / 32 | **MATCH** |
| 8461 | Biology (GCSE) | 7 / 24 | 7 / 24 | **MATCH** |
| 8463 | Physics (GCSE) | 8 / 30 | 8 / 30 | **MATCH** |
| 7404/7405 | Chemistry (A-Level) | 3 / 34 | 3 / 34 | **MATCH** |
| 7408 | Physics (A-Level) | 13 / 38 | 13 / 38 | **MATCH** |
| 7402 | Biology (A-Level) | 8 / **38** | 8 / **39** | **OFF BY ONE** |

The 7402 shortfall is recorded honestly (`matches_corpus_counts: false`) rather than
padded. Most likely cause: one sub-topic heading wraps differently in that PDF's text
layer. It is a known gap, not a silent one.

### Pearson Edexcel

| Spec | Style | Result |
|---|---|---|
| IGCSE Chemistry 4CH1 | numbered sections + lettered sub-topics | **4 sections / 28 sub-topics / 182 outcomes** (52 beyond-Core) — matches the corpus listing exactly; outcomes land on the correct sub-topic (1.1–1.7 under 1(a), 1.8–1.13 under 1(b), …) |
| IGCSE Physics 4PH1 | same | **7 sections / 26 sub-topics / 137 outcomes** |
| A-Level Chemistry 9CH0 | `Topic N: Title` | **19 topics** — matches corpus exactly |

A-Level Edexcel sub-topics are deliberately **not emitted**: their learning outcomes
live inside 3-column tables that the text layer flattens. The node set records
`subtopic_extraction: TABLE_AWARE_REQUIRED` and `outcome_ids_seen_in_text_layer: 27`.
Emitting a line-regex guess here would fabricate structure, so nothing is emitted.

For IGCSE Physics, an 8th section anchor (`Astrophysics`) was found but has no numbered
heading; it is recorded under `skipped_anchors` rather than silently dropped or
invented as section 8.

### SAT — exact

Reading & Writing: 4 domains / 11 testing points. Math: 4 domains / 15 testing points.
All 26 sub-topics carry `verification: confirmed_in_source_pdf`.

An earlier build over-harvested 91 testing points by accepting any capitalised line in
the framework PDF. Candidates are now retained only when the printed name is confirmed
present in the source text; the dropped count is recorded per node.

### IB — exact

Biology 4 themes / 40 topics, Chemistry 6 strands / 18, Physics 5 themes / 24 — matching
the 2025 subject briefs. HL-only markers (`*`) and the `•/••/•••` SL/HL indicators are
preserved on the nodes.

---

## 4. Version intelligence

`taxonomies/versions.json` — 90 syllabuses across 5 boards.

Three evidence classes, each labelled by `basis` so a consumer can tell a declared fact
from an inference:

| basis | meaning | trusted as fact? |
|---|---|---|
| `config_syllabus_years` | years declared in a CAIE `config.json` | yes |
| `explicit_in_source` | year span inside the version string (e.g. `2023-2025`) | yes |
| `first_assessment_in_source` | board PDF states a first-assessment date; **no end year** | start only — forward inference is labelled |

### A real bug this caught

The first implementation resolved `9701` + year `2023` → version `2026`. That is wrong,
and the cause is instructive: CAIE `config.json` declares
`syllabus_years: ['2015','2024','2025','2026','2027']` — a **discrete published list**,
not a contiguous span. Treating `min(years)` as a "first assessment" year invented
coverage for every year from 2015 onward.

Two fixes:

1. A gapped list is flagged `discrete: true` and is **never interpolated** — a year
   absent from it is simply not covered.
2. Forward inference from a start year is restricted to
   `basis == first_assessment_in_source`, where the end year is genuinely unstated.
3. The config's own `historical_year_policy: "review_required"` is honoured verbatim.

Resolution behaviour now:

```
9701  2026 -> RESOLVED         2026            (in declared list)
9701  2025 -> RESOLVED         2026            (in declared list)
9701  2023 -> REVIEW_REQUIRED  None            (not in list; source policy says review)
9701  1999 -> REVIEW_REQUIRED  None
0620  2019 -> REVIEW_REQUIRED  None
9CH0  2019 -> RESOLVED         Issue 3         (source-declared first assessment)
9PH0  2020 -> RESOLVED         Issue 4
9708  2024 -> AMBIGUOUS        None            (two versions claim 2024 — never guess)
8462  2018 -> UNKNOWN          None            (no version metadata built yet)
```

No hardcoded year ceiling anywhere; 1900–9999 supported.

---

## 5. Cross-board concept identity

`taxonomies/concepts.json` — **status `NO_LINKS_YET`, 0 links, 2,168 nodes scanned.**

This is the intended result, not a stub. The policy is deliberately conservative: a link
is emitted only when two or more boards carry the **same explicit** `concept_ids` value.
Title similarity alone is never a link, because §31 forbids merging similar names and
§17 forbids assuming codes mean the same thing across boards. A wrong link is worse than
a missing one.

No adapter has populated `concept_ids` yet — that happens in Milestone 4 from
board-published mappings. Re-running the builder then grows the map without any code
change.

---

## 6. Component-code patch (Milestone-1 decision (c))

**Defect.** `_component_paper_number_local` returned `int(digits[-2])`. Correct for the
standard `<paper><variant>` encoding (`22` → Paper 2), but wrong for **zero-padded paper
numbers**: 9686 (Urdu) publishes `9686_s20_qp_02/03/04` — one mark scheme per paper, no
variant digit. `04` returned Paper **0**, collapsing 02/03/04 onto a paper that does not
exist.

**Fix, in place.** Branch on a leading zero: no Cambridge paper is numbered 0, so a
zero-prefixed component cannot be a paper+variant pair. Everything else is byte-identical.

**Regression risk: none, demonstrated.** All 18 components enumerated in
`IGCSE_COMPONENT_MAP` (11–63) are non-zero-prefixed. `test_every_enumerated_component_is_unaffected`
asserts this and fails loudly if a zero-prefixed component is ever added without review.

**Lock ledger.** The patch changed a locked core file, so the repo's own integrity check
(`lock ledger: latest rows == on-disk sha256`) correctly failed. Worth recording how that
check actually resolves: "latest row" is decided by **document order in `LOCK_DOCS`**, not
by date — `EFFICIENCY_AUDIT.md` is last, so a newer row in `ROUTING_STATE_LOCK.md` does
not win. The new sha256 was appended to both documents (RS-61 in
`ROUTING_STATE_LOCK.md`, matching section in `EFFICIENCY_AUDIT.md`).

---

## 6b. Two further bugs caught by querying the built data

Both were found by *using* the registry as a consumer would, not by reading the code.

**Edexcel outcomes all piled onto each section's last sub-topic.** Every IGCSE section
lists its sub-topics up front ("The following sub-topics are covered in this section.")
and then **repeats** each heading in the body, where its outcomes follow. The extractor
de-duplicated the repeated heading but left `current_sub` pointing at the contents-list
entry, so all 182 outcomes accumulated on `1(i)`, `2(h)`, `3(c)`, `4(h)`. Fixed by
re-pointing `current_sub` at the already-created node on a repeat. Distribution is now
monotonic and correct.

**`resolve_version` answered for years the source does not cover.** `9701` + 2023
returned version `2026` even though 2023 is absent from the declared list — the same
interpolation error described in §4, surviving in a second code path.
`TopicRegistry.resolve_version` now delegates coverage to `VersionIntelligence` and
returns `None` when the year is not covered; a sibling `resolve_version_status()` returns
`{taxonomy, status, reason, resolved_version}` so a caller can distinguish *no such
taxonomy* (`NOT_FOUND`) from *taxonomy exists but this year is not covered*
(`REVIEW_REQUIRED` / `AMBIGUOUS` / `UNKNOWN`).

```
CAIE  9701  2026 -> RESOLVED         taxonomy returned
CAIE  9701  2023 -> REVIEW_REQUIRED  None
CAIE  0620  2019 -> REVIEW_REQUIRED  None
EDEXCEL 9CH0 2019 -> RESOLVED        Issue 3 (source-declared first assessment)
AQA   8462  2018 -> UNKNOWN          None (no version metadata built)
CAIE  ZZZZ  2026 -> NOT_FOUND        None
```

## 7. Test status

```
full suite:  380 passed, 58 skipped, 51 subtests passed, 0 failed
new module:  tests/test_component_paper_number.py — 34 passed
```

Baseline before this milestone: 374 passed / 6 failed. The 6 failures were caused by my
own patch tripping the lock ledger, and were resolved by the ledger append above — not by
weakening any check.

---

## 8. Honest gaps carried forward

| Gap | State | Why not closed here |
|---|---|---|
| AQA 7402 sub-topics 38 vs 39 | recorded `matches_corpus_counts: false` | needs a targeted look at one wrapped heading in that PDF |
| Edexcel A-Level sub-topics (all 3 specs) | `TABLE_AWARE_REQUIRED`, 0 emitted | outcomes live in 3-column tables; requires `pdfplumber` table-aware extraction, not line regex |
| Edexcel IGCSE Physics "Astrophysics" anchor | recorded in `skipped_anchors` | present in the document without a numbered heading; not invented as section 8 |
| Cross-board concept links | `NO_LINKS_YET` | `concept_ids` are populated by adapters in Milestone 4 from board-published mappings |
| CAIE sub-topic depth | 670 topics / 719 sub-topics, 0 concepts | legacy configs publish major + detailed topics only; learning-outcome depth would require ingesting the official syllabus PDFs listed in each config's `official_source` |
| AQA version windows | `UNKNOWN` for year queries | AQA specs state a version label (`Version 1.1`) but no year span in the text layer |
| IB source PDFs | `SOURCE_NOT_ACCESSIBLE` (403) | taxonomy built from official subject-brief page text instead; full guides are paid |

None of these are hidden: each is written into the relevant `taxonomy.json` provenance or
into `concepts.json` / `versions.json`, so a downstream consumer sees the limitation next
to the data.

---

## 9. Next milestone

Milestone 3 — identity resolution: content/OCR evidence fusion, `IDENTITY_CONFLICT` →
`REVIEW_REQUIRED`, and the component-code semantics now fixed here feeding into
`paper_identifier.py`'s callers across all five boards.
