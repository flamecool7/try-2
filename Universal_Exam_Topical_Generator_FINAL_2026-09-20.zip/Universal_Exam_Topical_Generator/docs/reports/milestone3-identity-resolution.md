# Milestone 3 — Identity Resolution

**Date:** 2026-09-20
**Status:** IMPLEMENTED and verified against the 7 real staged papers plus adversarial
renames. Full suite green.
**Scope:** content/OCR evidence fusion, `IDENTITY_CONFLICT` → `REVIEW_REQUIRED`, and
removal of silent session fabrication from `core/paper_identifier.py`.

---

## 1. What was built

| Module | Role |
|---|---|
| `universal/identity/evidence.py` | Per-field evidence collectors: filename, PDF metadata, first-page text, full text, header/footer, board signature, qualification code, component code, question structure, mark-scheme structure, OCR |
| `universal/identity/resolver.py` | Fusion into per-field verdicts; conflict policy; `IdentityVerdict` |
| `universal/identity/__main__.py` | CLI: `python -m universal.identity <path> [--json OUT] [--evidence] [--strict]` |
| `tests/test_identity_resolution.py` | 10 acceptance tests using renamed copies of real papers |

Plus an in-place patch to `core/paper_identifier.py` (RS-62).

Nothing crops, names or writes output. This layer only produces a verdict.

---

## 2. Result on the real staged papers

```
0620_m25_er.pdf            RESOLVED  CAIE 0620 2025 m  er  comp=12  conf=1.00
0625_s24_ms_11.pdf         RESOLVED  CAIE 0625 2024 s  ms  comp=11  conf=1.00
0625_s24_ms_21.pdf         RESOLVED  CAIE 0625 2024 s  ms  comp=21  conf=1.00
9231_w25_ms_11.pdf         RESOLVED  CAIE 9231 2025 w  ms  comp=11  conf=1.00
9231_w25_qp_11.pdf         RESOLVED  CAIE 9231 2025 w  qp  comp=11  conf=1.00
9686 Urdu … Paper 04.pdf   RESOLVED  CAIE 9686 2026 s  qp  comp=04  conf=1.00
9701_m26_qp_22.pdf         RESOLVED  CAIE 9701 2026 m  qp  comp=22  conf=1.00
```

**7/7 RESOLVED, 0 conflicts.** Identity is corroborated by independent sources, not just
the filename — e.g. `9701_m26_qp_22` resolves `syllabus_code` from `filename` **and**
`qualification_code` (the `9701/22` printed on the cover), `year` from `filename` **and**
`first_page_text` ("May/June 2026"), `board` from `board_signature`.

The Urdu paper has **no text layer at all**. It resolves via OCR, and its component `04`
is consistent with the Milestone-2 zero-padded fix.

Two documents needed a rule rather than a guess:

- **ER is variantless by design** (`core/er_fetcher.py` builds `{code}_{season}{year}_er.pdf`),
  so a missing variant on an `er` document is *expected*, not incomplete. Without this,
  every examiner report reported `PARTIAL`.
- **CAIE component derivation**: the cover prints `9701/22`, which *is* the
  `<paper><variant>` pair from the filename. When the text layer is unreadable, the
  component is derived from the variant and marked `derived:variant`. This derivation is
  CAIE-only — §17 forbids assuming component codes mean the same thing on other boards.

---

## 3. Three real bugs found and fixed

### 3.1 My own mark-scheme heuristic invented conflicts

`\btotal\b.*\bmarks?\b` looks like a mark-scheme signal but **question paper covers print
"The total mark for this paper is 60"**. It produced a phantom `document_type` conflict on
`9701_m26_qp_22` and `9231_w25_qp_11` — two genuine question papers flagged
`REVIEW_REQUIRED`. A single `(a)`-style row also matches ordinary question sub-parts.

Now requires **≥4 distinct mark-grid rows AND no "Question Paper" header on page 1**.
`test_mark_scheme_is_not_confused_with_question_paper` locks this.

### 3.2 Conflict detection was gated on the wrong thing

The first implementation declared a conflict only when the top-2 **margin** was below
`review_gap`. That let a lying filename lose *quietly*: for a 9701 document named
`0620_s23_qp_11.pdf`, content out-weighed the name 3:1, the margin cleared the gap, and
the result was `RESOLVED` with no trace of the contradiction — precisely the "never
silently pick a side" failure the directive forbids.

**Conflict is about disagreement, not closeness.** Now: if any source supports *only* the
rejected value, that is `CONFLICT` regardless of margin. The stronger value is still
recorded as provisionally accepted, but the document routes to `REVIEW_REQUIRED` and the
rejected value stays in the record. Within-source ambiguity (a cover carrying two bare
years) remains `AMBIGUOUS` via the margin rule.

Both cases are covered by tests that rename a real paper to contradict its own contents.

### 3.3 `paper_identifier.py` silently fabricated the session (RS-62)

The loose-filename fallback did:

```python
season_letter = season_letter or c_season or "s"
year_short    = year_short    or c_year    or "24"
```

When neither filename nor cover text carried a session, an unidentifiable paper was dated
**Summer 2024**. This is the Milestone-1 observation ("invented year=2024 when filename
evidence removed"), now traced to source.

Also `_full_year_from_short` returned `2024` for non-numeric input, and one call site had
an `except` branch that **re-called the same function with the identical argument** — a
retry that could only repeat the failure, then fall through to the default.

Fixed:
- Defaults retained *only* so folder names and manifest keys stay well-formed; every
  invented field is recorded in `PaperInfo.fabricated_fields` and sets
  `identity_status="REVIEW_REQUIRED"`.
- `_full_year_from_short` raises `ValueError`; the two reachable call sites return `None`
  (unidentifiable) instead of dating inventively.
- Four additive fields on `PaperInfo` (`identity_status`, `identity_sources`,
  `identity_evidence`, `fabricated_fields`), all defaulted so every existing construction
  site — standard, long-format, year-first, ER — is unchanged. Surfaced in `to_dict()`.

`papers/raw` is immutable, so the adversarial tests operate on copies in a temp dir.

---

## 4. Acceptance tests

```
tests/test_identity_resolution.py — 10 passed
```

| Test | Asserts |
|---|---|
| `test_meaningless_filename_still_resolves_from_content` | `scan0001.pdf` → 9701 / 2026 / CAIE, and `year` has **no** `filename` source |
| `test_wrong_syllabus_in_filename_is_a_conflict_not_a_silent_pick` | named 0620, is 9701 → `REVIEW_REQUIRED`, conflict records both values |
| `test_wrong_year_in_filename_is_surfaced` | named `m23`, cover says May/June 2026 → conflict |
| `test_wrong_document_type_in_filename_is_surfaced` | QP named `_ms_` → both readings present |
| `test_rejected_value_is_preserved_in_the_record` | losing side survives into `to_dict()` |
| `test_mark_scheme_is_not_confused_with_question_paper` | regression for §3.1 |
| `test_real_mark_scheme_still_identified` | the stricter rule still detects real MS |
| `test_non_pdf_garbage_yields_insufficient_evidence` | `INSUFFICIENT_EVIDENCE`, no invented fields |
| `test_missing_file_is_reported_not_guessed` | `FILE_NOT_FOUND` recorded |
| `test_no_field_defaults_to_a_hardcoded_year` | `"2024"` appears nowhere in the identity |

---

## 5. Test status

```
full suite:  390 passed, 58 skipped, 51 subtests passed, 0 failed
proof check: overall PASS (gold core pristine, lock ledger verified)
```

`core/paper_identifier.py` changed, so the lock ledger was re-pinned as **RS-62** in both
`ROUTING_STATE_LOCK.md` and `EFFICIENCY_AUDIT.md` (the latter last, because
`verify_ledger()` resolves "latest" by document order — see ADR-0002).

---

## 6. Environment note

The sandbox loses pip-installed packages between sessions (workspace snapshots exclude
them). This run started with `pymupdf`, `imagehash`, `pdfplumber` and `rapidocr` **absent**,
which made every text-layer read fail and left only filename evidence — the resolver
correctly reported `INSUFFICIENT_EVIDENCE` / `OCR_UNAVAILABLE` rather than guessing.
After reinstalling, all 7 papers resolved. Worth knowing for real-paper testing: if
identity suddenly degrades to filename-only, check dependencies first.

---

## 7. Honest gaps carried forward

| Gap | State |
|---|---|
| Non-CAIE boards | `universal/identity` has board signatures and code patterns for AQA / Edexcel / IB / SAT / OCR, but **no real non-CAIE exam papers are staged**, so only CAIE is exercised end-to-end. The others are IMPLEMENTED, not FULLY VERIFIED. |
| Question-structure / layout weights | `question_structure` and `layout` are configured but `layout` is not yet collected (no visual feature extraction). |
| `corpus_match` weight | Declared in config, not yet wired — needs the question bank from later milestones. |
| QP↔MS↔ER↔Insert association | Not in this milestone; the verdicts here are the input to it. |
| Specimen papers | Detected and labelled, but not yet routed to a distinct output class. |

---

## 8. Next milestone

Milestone 4 — question extraction and board adapters: multi-page question preservation,
reuse of the OG crop mechanism (never a second crop engine), canonical naming
(`Variant_Season_Year_Qn[_MS/_IN/_ER].webp`, MCQ `.txt` exception), and QP/MS/ER/Insert
association built on these verdicts.
