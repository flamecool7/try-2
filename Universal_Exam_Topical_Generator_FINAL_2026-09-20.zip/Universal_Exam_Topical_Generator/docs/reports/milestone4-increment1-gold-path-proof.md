# Milestone 4 (increment 1) — End-to-End Proof of the Gold Path + Validator Repair

**Date:** 2026-09-20
**Status:** Gold path verified end-to-end on real papers. One blocking validator bug found
and fixed (RS-63). One environment-sensitive measurement discrepancy flagged for
verification. Image-only OCR remains an open gap with a safe design recorded.
**Scope of this increment:** prove the existing gold crop/extract/name path still works
after the Milestone 2–3 patches, and fix what blocks it.

Milestone 4 is deliberately being delivered in increments. This one is the foundation:
before building board adapters on top of the gold core, the gold core had to be shown
working through the real launcher.

---

## 1. End-to-end run over the real staged papers

`python run_pipeline.py --input papers/raw --output /tmp/qb_run2`

```
Total bundles:      3
Complete:           1        (9231_w25_11 — QP+MS pair)
Review required:    1        (9701_m26_22 — QP only, no MS staged)
Failed:             1        (9686_s26_04 — image-only, see §4)
Questions saved:    11
Batch complete in 1m 3s
[Validator] ✓ All checks passed!  /  [audit] final validation: PASSED (errors=0)
```

### Crop invariants verified on the produced artefacts

| Check | Result |
|---|---|
| Output width | **18/18 webp files exactly 2280 px** |
| Format | all `WEBP` |
| Canonical naming | 18/18 match `Variant_Season_Year_Qn[_MS/_IN/_ER].webp` |
| `proof.html` in question folders | **none** (definition-of-done requirement) |
| Stray file types in tree | only `.jsonl` worker logs under hidden `.staging/` |
| `.txt` sidecars | only `failure_report.txt` under `.staging/` — no non-MCQ `_MS.txt` |
| Multi-page preservation | `22_Spring_2026_Q4` = **2280×16006 single stitched image** (4-page question, not split) |

### Classification and routing behaved correctly

- **9231 Further Maths** → 7 QP+MS pairs classified into 6 real reference topics
  (`Vectors`, `Summation_of_series`, `Roots_of_polynomial_equations`,
  `Rational_functions_and_graphs`, `Proof_by_induction`, `Polar_coordinates`), each folder
  holding `11_Winter_2025_Qn.webp` + `_MS.webp`.
- **9701 Chemistry** → 4 structured questions with a genuine QP webp and canonical
  metadata, routed to `review_required_no_ms` because no mark scheme was staged. This is
  the designed behaviour, not a failure: the validator explicitly accepted the sentinel
  without renaming it.

---

## 2. RS-63 — an unsatisfiable validator check (blocking, now fixed)

`core/validation.py::check_reference_staging_math_routing` enforced the **retired** math
reference-staging scheme. It demanded that *every* configured reference topic folder be
pre-created under `paper-N/`, and that a `paper-N/loading` directory exist.

`check_no_forbidden_paths` (Spec Fix 12, 2026-08-12) fails the audit when **any** output
path contains `loading` — its own docstring names `paper-N/loading` and calls the scheme
retired. Both checks run in the same `validate()` pass (lines 205 and 219), so a correct
9709/9231 bank could never validate:

```
no loading folder  ->  "P1 missing loading folder"
loading folder     ->  "Forbidden staging path contains 'loading'"
```

**Observed on the first real run:** a correctly produced `Further_Mathematics_9231/paper-1`
bank — 7 canonically named QP+MS pairs in 6 valid reference topics — failed final
validation with *"P1 folders do not exactly match its reference"* + *"P1 missing loading
folder"*, and the bundle was marked **failed**. No test covered this check.

This would have hit the user's real-paper testing immediately for any Mathematics or
Further Mathematics paper.

**Fix.** The stale demands are removed; the genuinely useful invariants are kept:
- every topic folder that *does* exist must be in the configured reference set — an
  invented topic still fails loudly (this is the real anti-fabrication guarantee);
- metadata under each folder must agree on subject and paper number;
- metadata topic is still repaired to the literal folder name, never re-classified.

Efficiency impact is strictly positive: the check no longer walks a `loading` tree that
must not exist, and iterates `actual & expected` rather than the full reference set.

**Result:** the same run now reports `✓ All checks passed!` / `PASSED (errors=0)`, and the
9231 bundle is `complete`.

**Regression cover:** `tests/test_math_staging_validation.py` (6 tests) pins the resolved
contract, including `test_the_two_checks_are_no_longer_contradictory`, which runs both
checks over the same tree so the pair can never demand and forbid the same path again.

---

## 3. Measurement discrepancy requiring verification

Question heights from this run differ from the Milestone-1 measurement of the **same
PDF**:

| Question | Milestone 1 | This run |
|---|---|---|
| Q1 | 2280×5409 | 2280×5042 |
| Q2 | 2280×6299 | 2280×5233 |
| Q3 | 2280×7791 | 2280×6912 |
| Q4 | 2280×11240 | 2280×16006 |

Width (2280) and multi-page stitching are unchanged; only heights moved, and Q4 moved
*up* while Q1–Q3 moved *down*.

**Not attributed to the Milestone 2–3 patches.** Those touched component-code parsing,
identity provenance fields, year fabrication, and the validator — none of which is on the
crop geometry path. The locked triplet (`core/question_split.py` =
`cropping_engine_reference.py` = `original_reference`) still verifies identical, and
`run_proof.py` reports `overall PASS`.

### The dependency-version hypothesis was tested and REFUTED

`requirements.txt` pins `PyMuPDF==1.24.14` and `Pillow==11.0.0` under the heading
*"Gold-standard"*. The first run had used unpinned latest (PyMuPDF 1.28.2 / Pillow 12.3.0),
so version drift was the obvious suspect. The pinned versions were installed and the whole
pipeline re-run:

| Question | PyMuPDF 1.28.2 / Pillow 12.3.0 | **PyMuPDF 1.24.14 / Pillow 11.0.0** | Milestone 1 |
|---|---|---|---|
| Q1 | 2280×5042 | 2280×**5042** | 2280×5409 |
| Q2 | 2280×5233 | 2280×**5233** | 2280×6299 |
| Q3 | 2280×6912 | 2280×**6912** | 2280×7791 |
| Q4 | 2280×16006 | 2280×**15989** | 2280×11240 |

Identical to within 17 px on a 16,000 px image. **Dependency version is not the cause.**
(Q4's 17 px delta is the one real difference and is unexplained.)

### Second discrepancy: the 20 px top white band measures 15–16 px

Re-measuring the produced webp files directly, the first ink row is **15, 15, 15, 16** for
Q1–Q4. This is stable across every threshold tried (250/240/220/200/160), so it is real
content, not WEBP compression noise. Milestone 1 recorded `top_white_band=20px` for this
same paper. The gold engine's own constant is `WHITESPACE_THRESHOLD = 240`.

### Status: REQUIRES VERIFICATION — not resolved here

Neither discrepancy is attributed to the Milestone 2–4 changes: the locked triplet
(`core/question_split.py` = `cropping_engine_reference.py` = `original_reference`) still
verifies byte-identical, RULE-6 files are pristine, `run_proof.py` reports `overall PASS`,
and none of the patched code is on the geometry path.

The most likely remaining explanation is a **difference in measurement definition** —
Milestone 1 may have recorded the band in source page coordinates before the resize to
2280 px, or read the engine's own reported value rather than re-measuring the output
webp. This could not be settled in-sandbox: re-running `CroppingEngine.process_paper`
directly dies silently under memory pressure, so a controlled A/B was not possible.

**Action for real-paper testing.** Measure the band on the *output webp* with the recipe
above (`convert("L")`, `np.where((a<240).any(axis=1))[0][0]`, using the engine's own
`WHITESPACE_THRESHOLD`), and record it next to the PyMuPDF/Pillow versions. If the locked
invariant is "20 px in output space", then 15–16 px is a genuine pre-existing deviation
that predates this work and should be reconciled against `CROPPING_LOCK.md` before the
bank is regenerated at scale. Flagged, not fixed: changing crop geometry is exactly the
kind of edit that must not be made on an unverified hypothesis.

---

## 4. Open gap — image-only papers (the Urdu bundle)

`9686_s26_04` failed at `STAGE S2: QP crop (gold-standard splitter)`:

```
FAIL  QP 9686_s26_qp_04: at least 1 question: 0 questions
```

The paper has **no text layer at all** (it was OCR'd successfully in Milestone 1, and
`universal/identity` resolves its full identity through OCR — board, code, year, season,
type, component `04`). But the gold splitter locates question boundaries from the text
layer, so it finds nothing.

This is correct *loud* failure, not silent garbage — the bundle is marked failed with a
reason, and no partial output was written. But it means scanned papers cannot be
processed yet.

**Why this was not fixed in this increment.** The safe injection point is constrained:
- `core/question_split.py` is in the **locked triplet** and must stay byte-identical.
- `original_reference/cambridge_qb/` is byte-pristine by directive.
- `core/cropping_engine.py` is the wrapper, and it enforces the 2280 px / 20 px verified
  white-space / LANCZOS / 30 px multi-page-gap invariants.

**Recorded design (not yet implemented):** wrap the page object handed to the gold
splitter so that `get_text()` returns OCR-derived text *only* when the native text layer
is empty. That keeps a single crop engine, leaves all geometry and invariants untouched,
and cannot alter behaviour for any paper that already has a text layer. It must be gated
behind the existing `ocr.trigger` / `ocr.max_side_px` config (the 2400 px cap exists
because a 6287×4445 render OOM-killed the process in Milestone 1) and must be proven not
to shift boundaries on text-layer papers before it is allowed near the gold path.

---

## 5. Test status

```
full suite:  396 passed, 58 skipped, 51 subtests passed, 0 failed
new module:  tests/test_math_staging_validation.py — 6 passed
proof check: overall PASS (locked triplet identical, RULE-6 pristine, ledger verified)
```

`core/validation.py` changed, so the lock ledger was re-pinned as **RS-63** in both
`ROUTING_STATE_LOCK.md` and `EFFICIENCY_AUDIT.md` (latter last — `verify_ledger()`
resolves "latest" by document order, see ADR-0002).

---

## 6. Environment note (recurring, worth pinning)

The sandbox does **not** persist pip-installed packages between sessions. This session
started with `pymupdf`, `imagehash`, `pdfplumber` and `rapidocr-onnxruntime` absent, which
silently degraded identity resolution to filename-only and made OCR report
`OCR_UNAVAILABLE`. Behaviour was honest (no guessing), but results were wrong until the
packages were reinstalled.

Recommendation: a `requirements.txt` with pinned versions committed to the repo, and a
`--sys-check` gate that fails loudly when the PDF/OCR stack is missing rather than
producing degraded output. `run_pipeline.py --sys-check` already exists as a hook.

---

## 7. Next increment

Milestone 4 (increment 2) — board adapters on the verified gold path:
`adapters/caie.py` mapping `IdentityVerdict` → the existing pipeline inputs, then AQA /
Edexcel / IB / SAT adapters, QP↔MS↔ER↔Insert association, and the MCQ `.txt` sidecar
contract. The OCR page-wrapper above is a prerequisite for scanned-paper support and
should be landed with its own boundary-stability proof.

---

# Increment 2 — CAIE board adapter

`adapters/caie/adapter.py` (~340 lines) + `tests/test_caie_adapter.py` (12 tests).
Discovered automatically by `adapters/registry.py`; `discovery_errors()` is empty.

The adapter owns **no** crop logic and **no** naming logic. Cropping stays in
`core/cropping_engine.py` over the locked gold splitter, canonical naming stays in
`core/output_manager.py::save_question_pair`, filename parsing stays in
`core/paper_identifier.py`. Paper-number derivation *delegates* to
`core.paper_identifier._component_paper_number_local` so there is one source of truth
(and the RS-61 zero-padded fix applies automatically). Everything else is read from
`config/boards/caie.yaml`, not from constants in code.

## Result on the real staged papers — 6/6 correct

```
9701_m26_qp_22.pdf   qp  9701  2026  m  comp=22  paper_number=2
9231_w25_qp_11.pdf   qp  9231  2025  w  comp=11  paper_number=1
9231_w25_ms_11.pdf   ms  9231  2025  w  comp=11  paper_number=1
0625_s24_ms_11.pdf   ms  0625  2024  s  comp=11  paper_number=1
0625_s24_ms_21.pdf   ms  0625  2024  s  comp=21  paper_number=1
0620_m25_er.pdf      er  0620  2025  m  comp=12  paper_number=1
```

Board, syllabus code, year, season and component are all read from the **cover text**,
not the filename.

## Three false-positive bugs found and fixed

Every document-type heuristic here was wrong before it was right, and each failure was
found by running against real papers rather than by reading the code:

1. **Loose token matching.** `caie.yaml` lists `"paper"` as a QP token, but Cambridge
   mark-scheme and examiner-report covers both print it — `Paper 1 Multiple Choice (Core)`,
   `Paper 0620/12`. Every MS and ER read as `qp`. Dict ordering made QP win and `break`
   hid the rest. Fixed by using only multi-word/long phrases for content matching, on word
   boundaries; short codes are filename-only tokens.

2. **Longest-match picked the wrong type.** Cambridge MS boilerplate reads *"Mark schemes
   should be read in conjunction with the question paper and the principal examiner report
   for teachers"* — so an MS cover contains the phrases for **all three** types. Verified
   on `0625_s24_ms_11`: longest-match returned `er`, first-match returned `qp`. Fixed by
   matching the document's own **heading** (a phrase on its own line), which is the only
   correct signal. Confidence is now 0.97 for a heading match.

3. **`\bprincipal examiner\b` is not ER-specific.** MS covers say *"prepared by the
   Principal Examiner"*, producing a false `er`. Fixed by requiring the report phrase as a
   standalone heading.

A fourth finding is a genuine property of Cambridge papers, not a bug: **question papers
never print "Question Paper" as a heading.** They print `Paper 2 AS Level Structured
Questions` plus a candidate instruction block. Rather than fall back to prose matching at
0.5 confidence, QPs are now identified *positively* by that block (`Paper N` heading +
duration + `INSTRUCTIONS` + "you must answer on the question paper"), requiring ≥3
independent signals so a quotation inside an examiner report cannot trigger it. Confidence
0.93.

## Absence of evidence

`test_no_text_yields_no_evidence` asserts all nine `identify_*` methods return `[]` on an
empty document — a collector that finds nothing returns nothing, never a default.
`test_unmapped_month_is_not_guessed` asserts an unrecognised month produces **no** season
evidence at all (not even low-confidence), while the year is still read correctly. A real
month missing from `caie.yaml` takes an explicit zero-confidence path that says
"not guessed" in its detail.

## Test status after increment 2

```
full suite:  408 passed, 58 skipped, 85 subtests passed, 0 failed
new module:  tests/test_caie_adapter.py — 12 passed, 34 subtests
proof check: overall PASS
```

No locked file changed in increment 2, so no ledger re-pin was needed.

## Next

Remaining Milestone 4 work: AQA / Edexcel / IB / SAT adapters (all four are still
`CONFIG_ONLY`), QP↔MS↔ER↔Insert association, the MCQ `.txt` sidecar contract, and the
OCR page-wrapper for scanned papers (§4) with its boundary-stability proof.

---

# Addendum — the 20 px band question, investigated to a firm conclusion

I flagged in §3 that the locked 20 px top white band measured 15–16 px and that I could
not explain it. I have now traced it. **The invariant is not holding in pipeline output,
and the cause is architectural, not environmental.**

## What the lock specifies

`CROPPING_LOCK.md` Amendment 2 defines `_align_top_white_band_final()`, which "measures
the actual final 2280px image and trims/pads the top to exactly **20 rows of visible white
above the first ink**", with a defensive assertion that refuses to trim ink. Its ink
criterion is:

```python
ink_rows = np.where((gray < 250).sum(axis=1) >= 2)[0]
```

i.e. a row counts as ink only when **≥2 pixels** are below 250 — a single noisy pixel does
not count. `QUESTION_TOP_GUARD_PX = 20`.

My first measurement used `.any(axis=1)` (≥1 pixel), which was too sensitive. I re-measured
with the lock's own criterion. That was not the explanation.

## Measured with the lock's own criterion

| Crop | width | band | expected |
|---|---|---|---|
| `22_Spring_2026_Q1/Q2/Q3` | 2280 | **15, 15, 15** | 20 |
| `22_Spring_2026_Q4` | 2280 | **16** | 20 |
| `11_Winter_2025_Q7`, `Q1` | 2280 | **16, 16** | 20 |
| `11_Winter_2025_Q3/Q2/Q5` | 2280 | **93, 93, 93** | 20 |
| `11_Winter_2025_Q6`, `Q4` | 2280 | **82, 83** | 20 |
| all `_MS` crops | 2280 | 0 | (separate MS engine) |

Not one QP crop is at 20. The values fall into two distinct populations — slightly *under*
20 (15/16) and far *over* 20 (82/93) — which rules out a single systematic offset.

## Root cause

`_align_top_white_band_final` appears **4 times** in the gold splitter
`original_reference/cambridge_qb/question_split.py`, which the pipeline does use. But it
appears **0 times** in `core/cropping_engine.py`, the engine the pipeline actually
instantiates (`core/bundle_worker.py:488`, `run_guarded.py:1646`).

So `CroppingEngine` calls the gold `question_split` for **boundary detection**, then
performs its own cropping, assembly and resize. The raster-exact re-anchoring pass that
Amendment 2 added to guarantee the visible band is therefore never applied to the image
the engine finally writes. The 15/16 population is consistent with the segment-level 20 px
*pre-cut* being stretched or shrunk by the exact-2280 resize — precisely the drift
Amendment 2 was written to eliminate ("measured ~24px on 9700_w25_qp_22"). The 82/93
population is consistent with no top alignment at all on those sections.

This also explains the §3 height discrepancy without invoking PyMuPDF versions: the
Milestone-1 figures were measured from the gold engine path, the pipeline figures from
`CroppingEngine`'s own assembly.

## Status and recommendation

**Pre-existing, not caused by Milestone 2–4 work.** The locked triplet still verifies
byte-identical and `run_proof.py` reports `overall PASS` — because the proof checks file
*identity*, not the geometric invariant of freshly produced crops. No existing test
measures the band on pipeline output; that is the gap that let this pass unnoticed.

**Not fixed here.** Closing it means making `CroppingEngine` apply the gold anchoring pass
to its final assembled image — a change to crop geometry on the hot path, in the module
that enforces the locked invariants. That needs its own A/B proof (before/after bands on
every staged paper, plus confirmation that width, bottom edge, multi-page seams and the
no-clipping assertion are untouched) and maintainer sign-off, which is exactly what
`CROPPING_LOCK.md` line 117 asks for. Doing it at the end of a session, unverified, would
risk the one part of the system the directives say must not be rebuilt.

**Suggested next step:** add a band assertion to the pipeline's own QC so this cannot
regress silently again — measure each written QP webp with the lock's criterion and fail
the bundle if the band is not 20. That test will fail today, which is the point: it makes
the deviation visible and gives the geometry fix a target.

---

---

# RESOLVED — root cause confirmed (supersedes both earlier readings)

The addendum's conclusion was **correct**. An intermediate "CORRECTION" section that
retracted it was itself wrong and has been deleted: it trusted a stale code comment over
measurement. The confirmed evidence chain:

1. **Bands are never 20.** Measured on real output with the lock's own criterion
   (`(gray<250).sum(axis=1) >= 2`): `22_Spring_2026_Q1/Q2/Q3` = 15, 15, 15;
   `Q4` = 16; `11_Winter_2025_Q1` = 16; `Q4/Q6` = 83, 82; `Q2/Q3/Q5` = 93, 93, 93.
   Two distinct populations — slightly under 20, and far over it — so no single
   systematic offset.

2. **The band regions are 100% pure white.** `11_Winter_2025_Q3` rows 0–92:
   211,980 of 212,040 pixels exactly 255, minimum 251, only 60 pixels in 251–254.
   `11_Winter_2025_Q1` rows 0–15: 36,480/36,480 exactly 255. This **refutes** both
   lossy-WEBP ringing and `scrub_barcode_bands` residue as causes — the white is
   genuine, so the geometry really is unanchored.

3. **The anchor is unreachable from the pipeline.** `_align_top_white_band_final` is
   called exactly once in the gold package — `original_reference/cambridge_qb/question_split.py:1480`
   — inside `crop_page_segments`. In `core/cropping_engine.py` the string
   `crop_page_segments` occurs **once, inside a comment** (line 372). The engine calls
   `split_questions` (line 339) → `enforce_exact_width_2280` (366) →
   `assemble_multipage_question` (382); none of these anchor the top band.

So Amendment 2's raster-exact re-anchor never runs on pipeline output. The 15/16
population is the segment-level 20 px pre-cut shrunk by the exact-2280 resize — precisely
the drift Amendment 2 was written to eliminate. The 82/93 population is sections that
received no top alignment at all.

## The comment at line 371 is stale and actively misleading

> "Gold ALWAYS returns ONE fully-stitched image per question (its `crop_page_segments`
> assembles ALL page segments via `assemble_multipage_question` **+ the 20px raster
> re-anchor**) …"

The stitched-image claim is true, but the anchor clause is not: this engine never calls
`crop_page_segments`. Reading that comment is what caused the false retraction. It should
be corrected in the same change that lands the fix.

## Environment finding — /tmp is RAM

`/tmp` on this host is a **993 MB tmpfs**, i.e. RAM-backed, on a machine with ~2 GB total.
Writing pipeline output to `/tmp` consumes memory directly. Seven successive test-output
directories reached 340 MB and the 20-page `9231` worker began dying with
*"a process in the process pool was terminated abruptly"* — an OOM kill that persisted
after the code change was reverted, which is how it was identified as environmental rather
than a regression.

**Use a real-disk output path (e.g. `out_verify/` inside the workspace), never `/tmp`, for
pipeline runs here.** Note that `core/cropping_engine.py::_page_scratch_root()` deliberately
prefers `/dev/shm` for intermediate page renders, so scratch usage is RAM by design and
must be budgeted for.

## Fix status

A two-line fix was implemented and then reverted: import
`_align_top_white_band_final as gold_align_top_band` alongside the other gold imports, and
apply it to `assembled` immediately **after** `scrub_barcode_bands` (so any whitening the
scrub performed is accounted for). Ordering after assembly matters — the anchor must see
the final 2280 px image, which is the whole point of Amendment 2.

It was reverted because validation could not be completed under the memory pressure above,
**not** because the approach was wrong. `core/cropping_engine.py` is byte-identical to its
pre-patch state (verified: zero occurrences of the patch symbols), `408 passed`, proof
`overall PASS`.

Re-apply with output on real disk and measure bands before/after. The gold function only
crops or pads the top edge — width, bottom and multipage seams are untouched — and it
asserts that every removed row is white, so it cannot clip content. Where it would clip, it
raises `AssertionError`; that case must be caught and flagged for review rather than forced.

## RS-64 VALIDATED — 11/11 QP crops at exactly 20 px

Fix applied at the true choke point and measured on real papers. Bands before/after, using
the lock's own criterion (`(gray<250).sum(axis=1) >= 2`):

| Crop | Width x Height | Band before | Band after |
|---|---|---|---|
| `22_Spring_2026_Q1` | 2280x5047 | 15 | **20** |
| `22_Spring_2026_Q2` | 2280x5238 | 15 | **20** |
| `22_Spring_2026_Q3` | 2280x6917 | 15 | **20** |
| `22_Spring_2026_Q4` (multipage) | 2280x15993 | 16 | **20** |
| `11_Winter_2025_Q1` | 2280x5514 | 16 | **20** |
| `11_Winter_2025_Q2` | 2280x5240 | 93 | **20** |
| `11_Winter_2025_Q3` | 2280x5158 | 93 | **20** |
| `11_Winter_2025_Q4` | 2280x5257 | 83 | **20** |
| `11_Winter_2025_Q5` | 2280x5353 | 93 | **20** |
| `11_Winter_2025_Q6` | 2280x5375 | 82 | **20** |
| `11_Winter_2025_Q7` (multipage) | 2280x16355 | 16 | **20** |

**11/11 at exactly 20 px**, all at 2280 px width, all WEBP. Both deviant populations
corrected by the single change: the 15/16 px group (a 20 px pre-cut scaled down by the
exact-2280 LANCZOS resize) and the 82/93 px group (white added above first ink by
`scrub_barcode_bands`). Heights grew by the pad amount where the band was under 20
(e.g. Q1 5042 -> 5047) and shrank where it was over, which is the anchor trimming
verified-white rows only.

Multi-page questions retain stitching (Q4 15993 px, Q7 16355 px) with a correct 20 px top
band, confirming the anchor operates on the assembled image without disturbing the 30 px
seams.

MS crops were left untouched (band 0, their own native geometry) as designed — the RULE-6
MS engine is pristine and out of scope for the QP band invariant.

No `AssertionError` refusals occurred on this corpus, so no crop required clipping
protection here; the guard remains in place for papers where gold would refuse.

### Environment note (recurring)

Pip packages are stripped at session boundaries. This run initially failed with
`ModuleNotFoundError: No module named 'fitz'`; `pip install -r requirements.txt` restored
the exact pins (`PyMuPDF 1.24.14`, `Pillow 11.0.0`) from the local pip cache. Always
reinstall before pipeline work. Output was written to a real-disk path (`out_v/`), never
`/tmp`, which on this host is a 993 MB tmpfs.

The 9231 bundle completed in this run (11 questions total), so the earlier OOM failures
were memory-pressure artefacts of accumulated `/tmp` output directories, not a code
regression.
