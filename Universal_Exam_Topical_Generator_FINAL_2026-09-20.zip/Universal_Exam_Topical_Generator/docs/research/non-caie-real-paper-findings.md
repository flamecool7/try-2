# Non-CAIE board cropping — real-paper findings (2026-09-20)

Purpose: evidence gathered from **real** board papers to drive the AQA / Edexcel / IB / SAT
adapters. Nothing here is inferred from documentation alone; every structural claim below
was measured on a downloaded PDF.

## Papers obtained (real, on disk)

| Board | File | Pages | Page size | SHA-256 | Source |
|---|---|---|---|---|---|
| AQA | `papers/real_noncaie/aqa/AQA-87021-SQP-V1.PDF` | 17 | 595x842 (A4) | `c8a80894994a7e9fbaae6b56cd6e36b1a1e817b5c250f8d571e7b7536e12e81d` | `https://filestore.aqa.org.uk/resources/english/AQA-87021-SQP-V1.PDF` |
| College Board | `papers/real_noncaie/sat/psat-8-9-practice-test-1.pdf` | 56 | 612x792 (US Letter) | `98733d1016254b4f96226c6cd2dd76cb052dda0c29aaaf8bef8d6efc14ca4d06` | `https://satsuite.collegeboard.org/media/pdf/psat-8-9-practice-test-1.pdf` |
| College Board | `papers/real_noncaie/sat/psat-nmsqt-practice-test-2.pdf` | — | — | `7f5176bc6de992adcab7a40849803e4ffee340b695e33d7cff33739f5968c528` | `https://satsuite.collegeboard.org/media/pdf/psat-nmsqt-practice-test-2.pdf` |

AQA paper is 8702/1 GCSE English Literature Paper 1 (SPECIMEN MATERIAL).

**Not yet obtained:** Edexcel, IB. See "Sourcing notes" below for what was tried.

## Sourcing notes — what works and what does not

- **AQA**: `filestore.aqa.org.uk/sample-papers-and-mark-schemes/...` is **dead** — every
  path returns a ~123 KB `text/html` 404 sentinel. Only `resources/<subject>/...` still
  serves `application/pdf`. Of six probed candidates exactly one was live, so this path is
  usable but not enumerable by pattern; asset IDs must come from the qualification page.
- **College Board**: `satsuite.collegeboard.org/media/pdf/<name>.pdf` **works**. Earlier
  failures were wrong filenames (`digital-sat-practice-test-1.pdf`,
  `sat-linear-practice-test-1.pdf` both 404). Confirmed-good names came from an r/psat
  megathread. Linear (non-adaptive, paper-format) tests are the right artefacts for
  cropping — Bluebook adaptive tests are app-delivered and cannot be cropped as PDFs.
  Index of linear tests: `https://satsuite.collegeboard.org/sat/practice-preparation/practice-tests/linear`
- **Edexcel**: not attempted successfully; Pearson DAM requires exact paths and its
  generic-404 sentinel is exactly 152,114 bytes of HTML.
- **IB**: `ibo.org` returns HTTP 403 to direct clients; requires the page-fetcher. Full
  guides are paywalled (`SOURCE_NOT_ACCESSIBLE`).
- **Reddit is a good URL source** for College Board and AQA: threads in r/Sat, r/psat,
  r/GCSE, r/alevel, r/IBO aggregate official links. Prefer official-host PDFs surfaced via
  Reddit over third-party re-uploads, so provenance stays clean.

## AQA 8702/1 structure (measured)

Materially different from CAIE — a CAIE-tuned splitter will mis-segment this paper:

- p1 cover: `SPECIMEN MATERIAL / 8702/1 / GCSE / English Literature / Paper 1 ...`
- p2 filler: `There are no questions printed on this page.`
- p3 **contents table** listing `Question | Page` with numbers 1–8 for Section A and again
  for Section B. These numbers will **false-positive as question starts** unless the table
  is excluded.
- p4+: `SECTION A / Section A: Shakespeare / Answer one question from this section on your
  chosen text.` then `EITHER` … `OR` … `OR` — **one alternative per page**, each headed by a
  text title (`Macbeth`, `Romeo and Juliet`, `The Tempest`, …) and an extract.
- p10+: `Section B: The 19th-century novel`, same `EITHER`/`OR` pattern.
- `Turn over` appears as a page footer on odd pages.

Consequences for the adapter:
1. Questions are **not sequentially numbered** on the question pages — they are
   section + alternative (`Section A / EITHER`, `Section A / OR (Romeo and Juliet)`).
2. Canonical naming cannot reuse CAIE's `Q<n>` without deciding how to number alternatives.
3. The contents table and filler pages must be excluded explicitly.
4. Each question is exactly one page here, so multipage assembly is untested on this paper.

## College Board PSAT 8/9 structure (measured)

- p1 cover, then module sections: p4 `Module / 1 / Reading and Writing / 33 QUESTIONS /
  DIRECTIONS …`. Confirms `sat.yaml`'s section+module model (RW, MATH; two modules each).
- p5 is a near-blank separator page (dot rule only).
- p6+ questions: `The following text is adapted from …` stimulus, then numbered question
  with four options. Stimuli are **shared material** — matches `sat.yaml`'s
  `supporting_material_storage` and `content_ownership_map` requirements.

### Does the existing MCQ mechanism work on it? NO — measured

`core.mcq_support.detect_mcq_questions(doc)` was run against the real PSAT 8/9 paper:

```
detect_mcq_questions -> 65 hits
first 6: [(3, 324.11, 1), (3, 528.15, 2), (4, 115.10, 5), (4, 319.15, 6),
          (5, 115.10, 9), (6, 115.09, 11)]
validate_mcq_question_count(65) ->
  (False, 'FAIL: Expected 40, Detected 65 - Extra 25 questions,
           possible answer choices treated as questions')
```

Three concrete defects for College Board:

1. **Hardcoded count.** `MCQ_EXPECTED_COUNT = 40` (`core/mcq_support.py:45`) is a CAIE
   assumption. This module declares **33 QUESTIONS**. The validator therefore fails on a
   correct paper. Counts must come from the board config / the paper's own declared count,
   not a module constant.
2. **Duplicate question numbers across pages.** `(3, …, page 1)` and `(3, …, page 2)`; same
   for 4. Page indices here are 0-based body offsets, so question 3 is detected twice on
   different pages — either a two-column layout defeating the `x0` margin test in
   `_is_question_start(..., left_margin_threshold=70.0)`, or stimulus/option text matching
   `_MCQ_QUESTION_PATTERNS`. Either way, `x0` thresholds tuned for CAIE's single-column A4
   layout do not transfer to Letter-size College Board pages.
3. **No module awareness.** Detection returns a flat list with no section/module grouping,
   but SAT numbering **restarts per module**. Without module segmentation, question numbers
   collide by design — which is very likely the real cause of the duplicates in (2).

Also note the page-size consequence for the locked geometry: 2280 px at 300 dpi is 7.6 in.
Letter stock is 8.5 in wide and A4 is 8.27 in, so `enforce_exact_width_2280` **downscales**
SAT pages slightly more than CAIE/AQA ones. The invariant itself still holds (RS-64 anchors
the band after that resize), but effective raster resolution differs per board and should be
recorded per crop.

## Reusable pieces confirmed present

- Gold geometry primitives (board-agnostic): `enforce_exact_width_2280`
  (`original_reference/cambridge_qb/multipage_optimizer.py:169`),
  `assemble_multipage_question` (`:188`), `_align_top_white_band_final`
  (`question_split.py:686`).
- Adapter hooks: `segments_document()` / `segment(ctx)` at `adapters/base.py:254,259`;
  `DocumentContext` already carries `path`, `full_text`, `page_count`, `layout`, so an
  adapter never re-opens or re-OCRs the PDF.
- MCQ detection to adapt for SAT: `detect_mcq_questions`, `_is_option_line`,
  `_is_question_start`, `validate_mcq_crop_content` in `core/mcq_support.py`.

## Recommended implementation order

1. **AQA** — real paper in hand, structure fully mapped, closest to CAIE. Build the shared
   segment→gold-geometry bridge here and prove real crops.
2. **SAT** — real papers in hand, but needs the three MCQ defects above fixed first
   (config-driven counts, module segmentation, Letter/two-column `x0` thresholds). Do not
   reuse `MCQ_EXPECTED_COUNT`.
3. **Edexcel / IB** — blocked on sourcing real papers; do not implement unverifiable
   adapters (no-fabrication rule).

Note: `adapters/aqa/`, `adapters/edexcel/`, `adapters/ib/`, `adapters/sat/` **do not exist
yet**, although all four `config/boards/*.yaml` declare
`support_status: IMPLEMENTED_PENDING_VALIDATION`. That status overstates reality and should
be corrected to a config-only value until adapter code exists.

## Edexcel 9FM0/3C structure (measured, 2026-09-20)

Paper obtained via r/6thForm → `papers/real_noncaie/edexcel/P61181A_9FM0_3C.pdf`
(A-Level Further Mathematics 9FM0/3C, "Unused Original", 28 pages, 824 KB)
SHA-256 `59802dd8f927c2d52b675b85e919781fa317ad4d7bfd1978aa335b25b3aaf129`
Source `https://qualifications.pearson.com/content/dam/pdf/A-Level/Mathematics/2017/Exam-materials/P61181A_GCE_Fur_Maths_9FM0_3C_4C_Unused_Original.pdf`

**Page size 652x899 pt — a third format.** Neither A4 (595x842, AQA) nor US Letter
(612x792, College Board). At 300 dpi that is ~9.06 in wide, so `enforce_exact_width_2280`
downscales Edexcel more than any other board measured so far (2280 px = 7.6 in).

Per-page furniture, every page:
- `*P61181A0228*` — Edexcel **page-reference code**: `*` + paper code + zero-padded page
  number + total pages + `*`. Structurally analogous to CAIE's `* 6 0 0 6 8 8 7 8 1 6 *`
  candidate barcode, so gold's `_PAGE_BARCODE_RE = r"\*+\s*[\d\s]{5,}\*+"` will **partially**
  match it — but the semantics differ (page reference, not candidate ID) and it must be
  excluded from crops rather than scrubbed as a barcode.
- `DO NOT WRITE IN THIS AREA` repeated many times per page — these are **physical margin
  answer boxes** printed in the left/right gutters. They are real ink that must be cropped
  OUT of every question region. This is the single biggest Edexcel-specific cropping
  problem: an ink-based boundary detector will treat the margin boxes as question content
  and either widen the crop or mis-place the top band.
- `Turn over` on odd pages; p1 is a candidate-information cover with `Total Marks`,
  `Centre Number`, `Candidate surname`.

Consequences for the adapter:
1. Margin-box exclusion must run **before** any ink-based top/bottom boundary detection,
   otherwise the 20 px band anchor measures against margin ink instead of question ink.
2. The page-reference code needs its own pattern; do not reuse the CAIE barcode regex.
3. Effective raster resolution after the 2280 downscale is lowest of the four boards —
   record actual source width per crop so QC can flag resolution loss.

## Status of the four boards (real-paper evidence now in hand)

| Board | Real paper on disk | Structure mapped | Adapter code | Cropping validated |
|---|---|---|---|---|
| AQA | yes (8702/1, 17p) | yes | **none** | no |
| College Board / SAT | yes (PSAT 8/9 56p, PSAT/NMSQT) | yes + MCQ defects measured | **none** | no |
| Edexcel | yes (9FM0/3C, 28p) | yes | **none** | no |
| IB | **no** | no | **none** | no |

Three of four boards now have real papers and measured structures. IB remains unsourced
(`ibo.org` 403s direct clients; full guides paywalled). No adapter code has been written
yet for any non-CAIE board — `adapters/` still contains only `base.py`, `caie/`,
`registry.py`, `__init__.py`.
