# IB DP Physics — subject brief (first assessment 2025)

access_method: page-fetcher (text) — direct client download returns HTTP 403 at ibo.org
url: https://www.ibo.org/globalassets/new-structure/recognition/pdfs/dp_sciences_physics_subject-brief_jan_2022_e.pdf
retrieved: 2026-09-19
pdf_bytes: SOURCE_NOT_ACCESSIBLE (403)
corroborates: TOPICS-FROM-OWN-CORPUS.txt Part 11

## Syllabus content — SL 110 h / HL 180 h
Five themes A–E. Sub-topic markers are the brief's own:
`•` all students · `••` all students + additional HL content · `•••` HL only.

### A. Space, time and motion  (SL 27 / HL 42)
A.1 Kinematics • · A.2 Forces and momentum • · A.3 Work, energy and power • ·
A.4 Rigid body mechanics ••• · A.5 Galilean and special relativity •••

### B. The particulate nature of matter  (SL 24 / HL 32)
B.1 Thermal energy transfers • · B.2 Greenhouse effect • · B.3 Gas laws • ·
B.4 Thermodynamics ••• · B.5 Current and circuits •

### C. Wave behaviour  (SL 17 / HL 29)
C.1 Simple harmonic motion •• · C.2 Wave model • · C.3 Wave phenomena •• ·
C.4 Standing waves and resonance • · C.5 Doppler effect ••

### D. Fields  (SL 19 / HL 38)
D.1 Gravitational fields •• · D.2 Electric and magnetic fields •• ·
D.3 Motion in electromagnetic fields • · D.4 Induction •••

### E. Nuclear and quantum physics  (SL 23 / HL 39)
E.1 Structure of the atom •• · E.2 Quantum physics ••• · E.3 Radioactive decay •• ·
E.4 Fission • · E.5 Fusion and stars •

### Experimental programme  (SL 40 / HL 60)
Practical work (SL 20 / HL 40) · Collaborative sciences project (10/10) ·
Scientific investigation (10/10)
