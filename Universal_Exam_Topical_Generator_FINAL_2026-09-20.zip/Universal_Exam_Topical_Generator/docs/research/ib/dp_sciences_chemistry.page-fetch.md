# IB DP Chemistry — subject brief (first assessment 2025)

access_method: page-fetcher (text) — direct client download returns HTTP 403 at ibo.org
url: https://www.ibo.org/globalassets/new-structure/recognition/pdfs/dp_sciences_chemistry_subject-brief_jan_2022_e.pdf
retrieved: 2026-09-19
pdf_bytes: SOURCE_NOT_ACCESSIBLE (403)
corroborates: TOPICS-FROM-OWN-CORPUS.txt Part 7

## Syllabus content — SL 110 h / HL 180 h
Two top-level strands: **Structure** and **Reactivity**.

### Structure 1. Models of the particulate nature of matter  (SL 17 / HL 21)
1.1 Introduction to the particulate nature of matter · 1.2 The nuclear atom ·
1.3 Electron configurations · 1.4 Counting particles by mass: The mole · 1.5 Ideal gases

### Structure 2. Models of bonding and structure  (SL 20 / HL 30)
2.1 The ionic model · 2.2 The covalent model · 2.3 The metallic model ·
2.4 From models to materials

### Structure 3. Classification of matter  (SL 16 / HL 31)
3.1 The periodic table: Classification of elements ·
3.2 Functional groups: Classification of organic compounds

### Reactivity 1. What drives chemical reactions?  (SL 12 / HL 22)
1.1 Measuring enthalpy change · 1.2 Energy cycles in reactions · 1.3 Energy from fuels ·
1.4 Entropy and spontaneity (Additional higher level)

### Reactivity 2. How much, how fast and how far?  (SL 21 / HL 31)
2.1 How much? The amount of chemical change · 2.2 How fast? The rate of chemical change ·
2.3 How far? The extent of chemical change

### Reactivity 3. What are the mechanisms of chemical change?  (SL 24 / HL 45)
3.1 Proton transfer reactions · 3.2 Electron transfer reactions ·
3.3 Electron sharing reactions · 3.4 Electron-pair sharing reactions

### Experimental programme  (SL 40 / HL 60)
Practical work (SL 20 / HL 40) · Collaborative sciences project (10/10) ·
Scientific investigation (10/10)

## Tools & Inquiry process
Tools: Experimental techniques · Technology · Mathematics.
Inquiry process: Exploring and designing · Collecting and processing data ·
Concluding and evaluating.
