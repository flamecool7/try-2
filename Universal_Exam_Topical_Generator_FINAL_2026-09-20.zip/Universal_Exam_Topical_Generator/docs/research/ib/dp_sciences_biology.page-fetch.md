# IB DP Biology — subject brief (first assessment 2025)

access_method: page-fetcher (text) — direct client download returns HTTP 403 at ibo.org
url: https://www.ibo.org/globalassets/new-structure/recognition/pdfs/dp_sciences_biology_subject-brief_jan_2022_e.pdf
retrieved: 2026-09-19
pdf_bytes: SOURCE_NOT_ACCESSIBLE (403)
corroborates: TOPICS-FROM-OWN-CORPUS.txt Part 11 (4 unifying themes, '*' = HL-only)

## Syllabus content — 4 unifying themes
SL 110 h / HL 180 h total syllabus content; experimental programme SL 40 / HL 60.

### Unity and diversity  (SL 19 h / HL 33 h)
Water · Nucleic acids · Origins of cells * · Cell structure · Viruses * ·
Diversity of organisms · Classification and cladistics * · Evolution and speciation ·
Conservation of biodiversity

### Form and function  (SL 26 h / HL 39 h)
Carbohydrates and lipids · Proteins · Membranes and membrane transport ·
Organelles and compartmentalization · Cell specialization · Gas exchange · Transport ·
Muscle and motility * · Adaptation to environment · Ecological niches

### Interaction and interdependence  (SL 31 h / HL 48 h)
Enzymes and metabolism · Cell respiration · Photosynthesis · Chemical signalling * ·
Neural signalling · Integration of body systems · Defence against disease ·
Populations and communities · Transfer of energy and matter

### Continuity and change  (SL 34 h / HL 60 h)
DNA replication · Protein synthesis · Mutations and gene editing · Cell and nuclear
division · Gene expression * · Water potential · Reproduction · Inheritance ·
Homeostasis · Natural selection · Sustainability and change · Climate change

`*` = Topics with content that should only be taught to HL students (the brief's own marker).

## Skills in the study of biology
Tools / Inquiry process — see brief. Not topic-assignable syllabus content.
