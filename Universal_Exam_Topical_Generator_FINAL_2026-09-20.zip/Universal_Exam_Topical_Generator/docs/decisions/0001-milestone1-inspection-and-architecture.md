# ADR-0001 — Repository Inspection, Reuse Map & Universal Architecture

**Milestone:** 1
**Date:** 2026-09-19
**Status:** PROPOSED (awaiting approval)
**Decision owner:** primary software engineer (agent) + maintainer

---

## 1. What was inspected

Source of truth: `https://github.com/flamecool7/try-2` (cloned to `repo/`).

The repository root contains **no source tree** — it contains four canonical
text specifications and fifteen archives:

| Artifact | Role |
|---|---|
| `# UNIVERSAL EXAMINATION TOPICAL GEN.txt` (17,106 lines) | original multi-board spec |
| `UNIVERSAL-EXAM-TOPICAL-GEN-MEGAPROMPT-v2.txt` (5,262 lines) | **consolidated spec v2 — governing document** |
| `TOPICS-FROM-OWN-CORPUS.txt` (2,081 lines, 13 parts) | canonical topic corpus |
| `TOPICS-ADDITIONS.txt` (125 lines) | taxonomy additions (Edexcel/OCR/IB/AQA) |
| 15 × `.zip` | successive builds of the generator |

### 1.1 The five boards (spec §0, confirmed)

```text
1. Cambridge International / CAIE
2. SAT / College Board
3. International Baccalaureate / IB
4. AQA
5. Pearson Edexcel
```

Spec Part 0.11 additionally reserves `adapters/ocr/` and `adapters/wjec_eduqas/`;
these are registered as *optional* boards, not part of the five first-class ones.

### 1.2 Archive chronology — which build is the OG

Every bundle carries the same `original_reference/cambridge_qb/` gold core. The
bundles were compared by MD5 over all 388 distinct relative paths.

| Bundle | files | `cambridge_qb/question_split.py` | Verdict |
|---|---|---|---|
| `cambridge-topical-generator-final` | 194 | 892f0b84 (older) | early |
| `ExamVoid Topical Generator` | 220 | 892f0b84 (older) | early |
| `ExamVoid_FINAL_v7` | 241 | — | mid |
| `ExamVoid_FINAL_v9` | 322 | — | mid |
| `ExamVoid_FINAL_v33` | 334 | 1,518 lines | late |
| `ExamVoid_Production_Bundle (1)` | 346 | 1,686 lines | late |
| **`ExamVoid Topical Generator (1)`** | **374** | **1,686 lines + locked 20px anchor** | **NEWEST — chosen base** |

Decisive evidence: `CROPPING_LOCK.md` Amendment 2 (2026-08-10) locks the QP top
boundary to *"20 rows of visible white above the first ink"* via
`_align_top_white_band_final()`. Only the three latest bundles contain it; only
`ExamVoid Topical Generator (1)` also adds `core/classification_memory.py`,
`core/control_center.py`, `core/dedup.py`, `core/manifest.py`,
`core/mark_scheme_evidence.py` and `benchmarks/2026-08-29_*.json`.

**Two layers exist and both are canonical:**

```text
original_reference/cambridge_qb/   ← OG gold core (byte-pristine, "the reference implementation")
core/                              ← maintained evolved engine that WRAPS the gold core
```

`core/cropping_engine.py` literally does `from cambridge_qb.multipage_optimizer
import assemble_multipage_question as gold_assemble, enforce_exact_width_2280 as
gold_enforce_2280`. The evolved engine is a *facade over* the OG, not a rival.

### 1.3 Project root created

`ExamVoid Topical Generator (1)` was adopted as the base and installed at:

```text
Universal_Exam_Topical_Generator/     (6.1 MB, 376 files)
```

`benchmarks/`, `benchmark_results.json`, `profiling_baseline_report.json` and all
`__pycache__` were dropped (per directive §39 — no benchmark theatre in this phase).

---

## 2. Reusable OG mechanisms — verified, not assumed

Directive §2 requires identifying which mechanisms are *already reliable*. Each
row below was located in source and, where marked ✔RUN, exercised against a real
Cambridge PDF in this milestone.

| Capability | Module(s) | State |
|---|---|---|
| PDF render / watermark scrub | `cambridge_qb/pdf_io.py`, `cambridge_qb/converter.py`, `engine/renderer.py` | reliable (streams pages, RAM-safe) |
| Reference/back-matter removal | `cambridge_qb/chemistry_reference.py` (`identify_removable_pages`) | ✔RUN — removed cover, 2 blanks, data booklet, periodic table from 9701/22 |
| Question boundary detection | `cambridge_qb/question_split.py` (`_detect_markers`, `_analyse_page_top`, `find_question_bottom_pdf`) | ✔RUN — 4/4 questions, `confident=True` |
| Shared-page whitespace splitting | `question_split.adaptive_crop_page`, `webp_utils._bands_bottom_up` | reliable (vector + raster ink profiles) |
| **Multi-page assembly** | `cambridge_qb/multipage_optimizer.assemble_multipage_question` | ✔RUN — Q4 = 4 page sections → **one** 2280×11240 image |
| **Canonical crop invariants** | `multipage_optimizer.enforce_exact_width_2280`, `question_split._align_top_white_band_final`, `QUESTION_TOP_GUARD_PX=20` | ✔RUN — see §2.1 audit |
| WEBP output | `cambridge_qb/webp_utils.save_webp` (splits >16383px) | reliable |
| Barcode / imposition-mark scrub | `webp_utils.scrub_barcode_bands`, `_scrub_imposition_marks` | reliable |
| Mark-scheme split + crop | `cambridge_qb/markscheme_split.py`, `ms_crop.py`, `core/ms_cropping_engine.py`, `core/markscheme_split_gold.py` | reliable (LOCKed by `CROPPING_LOCK.md`) |
| MCQ answer-grid → `.txt` sidecar | `core/mcq_output.py` (`write_mcq_ms`, `VALID_ANSWERS`, `PLACEHOLDER_MS_CONTENT`), `core/mcq_registry.py` | reliable — matches directive §14 |
| Examiner-report parsing + Q attach | `core/examiner_report.py` (1,249 ln), `core/examiner_report_gold.py`, `core/er_question_crops.py`, `core/er_topic_boost.py` | reliable |
| Insert association | `core/insert_engine.py` (`InsertEngine`, `InsertSection`) | reliable |
| QP↔MS matching | `core/qp_ms_matcher.py` (`QPMSMatcher`, `MatchedQuestion`) | reliable |
| Document grouping | `engine/discoverer.py` (`Discoverer.discover_paths`) — order-independent QP/MS/ER/insert groups | reliable, **filename-driven only** |
| Canonical naming + folder tree | `core/output_manager.py` (`OutputManager.save_question_pair`) | reliable — see §2.2 |
| Duplicate detection | `cambridge_qb/dedup.py`, `core/dedup.py` (exact hash, imagehash hamming, number matching) | reliable |
| **Incremental processing** | `core/manifest.py` (`ProcessingManifest`, sha256, bundle states), `core/database.py` (`Database`, bundles/artifacts), `core/pipeline_state.py`, `core/bundle_cache.py` | reliable — resume-skip already wired into `main.py` |
| Classification | `core/classifier.py` (1,748 ln), `core/semantic_classifier.py`, `core/llm_classifier.py`, `core/hierarchical_consensus.py`, `core/classification_memory.py` | reliable **for CAIE only** |
| Subject/level detection from header | `core/subject_detector.py` (`extract_header_text`, `detect_subject_from_header`) | **partial — this is real content evidence, currently underused** |
| Identity parsing | `core/paper_identifier.py` (`parse_paper_filename`, `PaperInfo`) | **filename-first; no content fusion; CAIE-only patterns** |
| Output validation | `core/validation.py` (`FinalValidator`, 1,214 ln), `cambridge_qb/output_validator.py`, `cambridge_qb/quality_control.py` | reliable — reuse as QC backbone |
| Downloader | `core/qp_fetcher.py`, `core/ms_fetcher.py`, `core/er_fetcher.py` (verify → cache → fetch-log, `pastpapers.co` + `cambridgeinternational.org`, 2 s polite delay, 50 MB cap) | reliable **for CAIE only** |
| Subject configs (data-driven) | `subjects/<Level>/<Subject>_<code>/config.json` (78 configs), `+ /<year>/config.json` for syllabus versions | reliable — **already version-aware** |
| Topic JSON | `topics/<Level>/*_topics.json` (22), `original_reference/topics/A-Level/*` (10) | reliable |

### 2.1 Crop invariant audit — real paper, this milestone

`9701_m26_qp_22.pdf` (16 pp, real CAIE A-Level Chemistry, March 2026, Paper 2 AS
Structured) driven through `core.cropping_engine.CroppingEngine`:

```text
GOLD_AVAILABLE (canonical cambridge_qb crop core loaded): True
target_width: 2280
Kept 11 of 16 pages (removed 5 non-question pages)
Detected 4 question marker(s) (confident=True)

  Q1: 2280x5409   width_ok=True  top_white_band=20px  bottom_white=4px  left_white=66px  right_white=66px
  Q2: 2280x6299   width_ok=True  top_white_band=20px  bottom_white=6px  left_white=64px  right_white=66px
  Q3: 2280x7791   width_ok=True  top_white_band=20px  bottom_white=4px  left_white=65px  right_white=61px
  Q4: 2280x11240  width_ok=True  top_white_band=20px  bottom_white=4px  left_white=64px  right_white=66px
  (Q4 = 4 page sections assembled into ONE logical question)
```

**Conclusion: the OG crop mechanism is verified-correct and is adopted unchanged.**
No second crop engine will be written (directive §12, spec §0.13.9 HARD RULE).

### 2.2 Canonical output contract (already implemented — do not reinvent)

```text
output/<Level>/<Subject>_<code>/<PaperTypeFolder>/<WinningTopic>/<Variant>_<Season>_<Year>_<Qn>/
    ├── <Variant>_<Season>_<Year>_<Qn>.webp        # QP  (no suffix)
    ├── <Variant>_<Season>_<Year>_<Qn>_MS.webp     # mark scheme
    ├── <Variant>_<Season>_<Year>_<Qn>_MS.txt      # MCQ answer letters ONLY
    ├── <Variant>_<Season>_<Year>_<Qn>_IN.webp     # insert
    ├── <Variant>_<Season>_<Year>_<Qn>_ER.webp     # examiner report
    └── metadata.json
```

Enforced invariants already present: folder name == base filename; single-folder
per question (duplicate placement is *skipped*, not written); `topic[0]` exact
string is the physical folder name; season naming `Spring/Summer/Winter`
(never "March"); `review_required` questions are preserved, never discarded.

---

## 3. Gaps found (what Milestone 1 proves is genuinely missing)

### 3.1 Identity resolution is filename-first — proven wrong on a real document

`9686 Urdu - Pakistan only June 2026 Question Paper  04.pdf` is a **real** CAIE
A-Level Urdu question paper. Findings:

* It has **no text layer** (`producer: jsPDF 4.2.1`, 3 rendered pages of embedded
  1600×2263 PNG). It is image-only → **OCR is mandatory** for content evidence.
* High-res OCR of the header band returns:

```text
CAMBRIDGE / International Education
Cambridge International A Level
URDU
9686/04
Paper 4 Texts
May/June 2026
2 hours 30 minutes
The total mark for this paper is 75.  Each question is worth 25 marks.
This document has 8 pages.
© Cambridge University Press & Assessment 2026
```

* The existing parser returns `9686 / 2026 / Summer / variant='04' / STRUCTURED`.
  That is *accidentally* right **only because this filename happens to be
  descriptive**. When the same bytes were presented under a neutral filename the
  parser returned `year=2024, season=Summer, variant=None` — i.e. it silently
  invented an identity. **No conflict detection exists.**

* Component modelling is wrong: `variant='04'` treats `04` as a *variant*, but the
  document's own title says **"Paper 4 Texts"** and its printed component code is
  `9686/04`. The blind `code[0]=paper, code[1]=variant` rule does not hold for
  every subject. This is precisely directive §10 — *component intelligence must be
  derived, not assumed.*

**Decision:** build `universal/ingestion/identity.py` — an evidence-fusing
**Document Identity Resolver** that treats the existing parser as *one weak signal
among many*, adds PDF-content / header / OCR / layout / component-registry /
corpus evidence, emits a confidence, and raises `IDENTITY_CONFLICT` +
`REVIEW_REQUIRED` when filename and document disagree — never silently picking one.

### 3.2 OCR is absent from the installed environment

No `tesseract` binary and no root to `apt-get install` one. Verified working
alternative: **`rapidocr-onnxruntime`** (pure-pip, ONNX, offline after install) —
read the scanned Urdu page in 6.0 s.

Two engineering constraints discovered empirically:

* Rendering that page at 150 dpi yields **6287×4445** and the OCR call is
  **OOM-killed (exit 137)**. Downscaling to ≤1700×2400 works.
* ⇒ the OCR module must **downscale and/or tile**, and must expose a pluggable
  backend (`tesseract` → `rapidocr` → none) with a graceful `OCR_UNAVAILABLE`
  status instead of crashing the batch.

### 3.3 Genuinely missing subsystems

| Subsystem | Existing | Gap |
|---|---|---|
| Board adapters | none (CAIE hardcoded in `core/`) | AQA, Edexcel, IB, SAT + adapter contract |
| Universal taxonomy | 78 CAIE subject configs | no board/qualification/syllabus-version registry; corpus Parts 3–13 (SAT, IB, AQA, Edexcel, OCR) not ingested |
| Question DNA | `metadata.json` (canonical, must not change) | no DNA object; no `question_type`/`skills`/`structural_complexity`/`classification_confidence` |
| Search | `tools/query_bank.py` (54 lines, 3 filters) | universal multi-filter + NL query parsing |
| Question-set generator | none | all of it |
| Booklet generator | `engine/renderer.py` (53 lines, PDF→images), `tools/study_guide_generator.py` (HTML) | year-driven topical booklet flow, coverage preview, booklet naming/metadata/QA |
| Analytics | `core/database.get_progress()` | bank-wide descriptive analytics |
| Question Bank Doctor | `core/validation.py` (strong, reusable) | no unified diagnostic + safe auto-repair surface |
| Launcher menu | `main.py` = batch processor | the 7-item interactive menu |

---

## 4. Architecture decision

**Extend, do not rewrite.** The universal engine is built as a **new layer that
calls the existing one**, exactly as spec §0.13.4 requires:

```text
REAL EXAM SOURCES
      │
      ▼
universal/ingestion/     scanner → document_type → identity(evidence fusion) → relationships → manifest
      │                        └── reuses core/paper_identifier.py + core/subject_detector.py as SIGNALS
      ▼
adapters/<board>/        CAIE · AQA · EDEXCEL · IB · SAT  (+ OCR, WJEC optional)
      │                        └── CAIE adapter delegates to core/qp_ms_matcher.py, core/mcq_registry.py
      ▼
universal/extraction/    ── CALLS THE CANONICAL CROP PIPELINE, NEVER RE-CROPS ──
      │                  core.cropping_engine.CroppingEngine
      │                    → cambridge_qb.question_split / multipage_optimizer / webp_utils
      │                  core.ms_cropping_engine · core.insert_engine · core.examiner_report_gold
      ▼
universal/extraction/naming.py   single NamingEngine (canonical Variant_Season_Year_Qn[+_MS/_IN/_ER])
      ▼
universal/dna/           Question DNA + classification (wraps core/classifier.py) + confidence + states
      ▼
universal/bank/store.py  question bank index (extends core/database.py — additive tables only)
      ▼
   ┌──────────────┬──────────────────┬────────────────────┐
   ▼              ▼                  ▼                    ▼
bank/search.py  sets/generator.py  booklets/*         bank/analytics.py
                                                     bank/doctor.py
```

### 4.1 Non-negotiables carried into Milestones 2–10

1. `original_reference/cambridge_qb/` stays **byte-pristine**. No edits.
2. `core/` is extended **in place**; existing public functions keep their
   signatures and observable behaviour (spec §0.13.6, §0.13.9).
3. `metadata.json`'s existing fields are a **frozen contract** (spec §7.3).
   Question DNA is *additive* — new keys, plus a separate `dna.json` where the
   canonical file must not grow.
4. One crop engine. One naming engine. One asset, one lineage, many consumers.
5. No `if board == "CAIE"` in the universal core — board differences live in
   adapters and in data (`config/`, `taxonomies/`).
6. **No hardcoded year lists or topic lists in code.** Years come from scanning
   the bank; topics come from `taxonomies/*.json`.
7. `proof.html` and other diagnostic artefacts never land inside a question folder.

### 4.2 New package layout (added alongside, not replacing)

```text
universal/            # the new universal intelligence layer
  config.py  status.py  logging_utils.py  paths.py
  taxonomy/   registry.py loader.py builder.py versions.py concepts.py
  ingestion/  scanner.py document_type.py identity.py relationships.py manifest.py ocr.py
  extraction/ bridge.py questions.py naming.py mcq.py
  dna/        dna.py classifier.py confidence.py states.py
  families/   duplicates.py
  bank/       store.py search.py analytics.py doctor.py review.py
  sets/       generator.py
  booklets/   scanner.py selection.py controller.py renderer.py manifest.py naming.py validator.py
  downloader/ sources.py discover.py download.py verify.py pipeline.py
  pipeline/   runner.py state.py
  app/        launcher.py cli.py ui.py
adapters/       base.py registry.py caie/ aqa/ edexcel/ ib/ sat/ ocr/ wjec_eduqas/
taxonomies/     <BOARD>/<Qualification>/<Subject>_<code>/<version>/taxonomy.json
config/         config.yaml  boards/*.yaml
run.py          # integrated launcher entry point
```

Existing `core/`, `engine/`, `parsers/`, `profiles/`, `subjects/`, `topics/`,
`tools/`, `tests/`, `main.py`, `run_guarded.py`, `pipeline.py`, `run_pipeline.py`
are all **retained and still runnable**.

---

## 5. Sanity checks performed in Milestone 1

| Check | Result |
|---|---|
| Base bundle selected by content hash across 7 archives | `ExamVoid Topical Generator (1)` — newest |
| Dependencies | installed `pymupdf 1.28.2`, `imagehash`, `reportlab`, `pdfplumber`; `PIL 12.3`, `numpy 2.3.5`, `cv2 4.11`, `requests`, `yaml`, `bs4`, `sklearn`, `scipy` already present |
| Canonical gold core importable | `GOLD_AVAILABLE = True` |
| Real-paper crop end-to-end | 9701/22 → 4 questions, all invariants pass (§2.1) |
| Multi-page question integrity | Q4: 4 sections → 1 logical question ✔ |
| Reference-page removal | 5/5 non-question pages removed ✔ |
| Existing identity parser vs real files | 6/7 correct; **1 proven fragile** (§3.1) |
| OCR feasibility on a real scanned paper | `rapidocr` reads `9686/04 · Paper 4 Texts · May/June 2026` ✔ |
| OCR memory safety | 150 dpi full page → OOM kill; downscaled → 6.0 s OK (**constraint recorded**) |

**No synthetic papers were generated. Every check above used real Cambridge documents.**

Real documents staged for later real-paper testing (`papers/raw/`, immutable):

```text
9701_m26_qp_22.pdf                                        CAIE A-Level Chemistry  QP  (16 pp)
9231_w25_qp_11.pdf  +  9231_w25_ms_11.pdf                 CAIE A-Level Further Maths QP+MS
0625_s24_ms_11.pdf  +  0625_s24_ms_21.pdf                 CAIE IGCSE Physics MCQ MS ×2
0620_m25_er.pdf                                           CAIE IGCSE Chemistry Examiner Report (20 pp)
9686 Urdu - Pakistan only June 2026 Question Paper  04.pdf   real weird-filename, image-only QP
```

---

## 6. Known limitations at the end of Milestone 1

* The universal layer is **scaffolding only** — interfaces and config exist, the
  substantive logic lands in Milestones 2–10.
* Only CAIE has been exercised against real paper. AQA / Edexcel / IB / SAT have
  **no real documents in the repository yet**; their adapters will be built from
  the spec + the proven taxonomy extractions in `TOPICS-FROM-OWN-CORPUS.txt`
  Parts 3–13, and must be marked `IMPLEMENTED — NOT VERIFIED` until real papers
  are supplied.
* OCR backend is `rapidocr-onnxruntime` (pip). `tesseract` cannot be installed
  here (no root). Arabic-script accuracy on the Urdu paper was sufficient for
  header/identity fields but was not exhaustively validated.
* Nothing in this milestone claims the *system* is verified. Crop mechanism:
  verified. Everything else: implemented-or-planned, awaiting real-paper testing.

---

## 7. Addendum — component-code exception, corroborated

§3.1 flagged that `9686/04` + "Paper 4 Texts" breaks the `<paper><variant>`
grammar. Corroborated against the public 9686 corpus listing (searched
2026-09-19, not from memory):

```text
9686_s20_qp_02.pdf   9686_s20_qp_03.pdf   9686_w20_qp_04.pdf
9686_w20_ms_2.pdf    9686_w20_ms_3.pdf    9686_w20_ms_4.pdf
9686_w20_in_02.pdf   9686_w20_er.pdf      9686_w20_gt.pdf
```

One mark scheme **per paper** (`_ms_2/_ms_3/_ms_4`), no variant digit anywhere,
plus a `gt` (grade-threshold) document type. A third-party index labels
`9686_s24_qp_04` literally as *"Paper 0 Variant 4"* — i.e. the naive split is
known to produce nonsense in the wild.

**Consequence for the existing code (a real, reproducible defect):**
`core/paper_identifier.py::_component_paper_number_local` returns
`int(digits[-2])`, so `"04"` → **paper 0**. `parse_paper_filename` reported
`variant='04'`. Both are wrong for this syllabus.

**Decision (encoded in `config/boards/caie.yaml`):**

```yaml
component_grammar:
  default: paper_variant
  exceptions:
    zero_padded_paper_number:
      applies_when: "component code has a leading zero, or paper title is present"
      interpretation: paper_number_only
      verified: true
```

Resolution order in Milestone 3: **document's own printed paper title → per-syllabus
component table (from `core/mcq_registry.py` / `IGCSE_COMPONENT_MAP`) → default
grammar → `REVIEW_REQUIRED`**. `core/paper_identifier.py` is *not* patched in
Milestone 1; the resolver wraps it and overrides its component interpretation
with document evidence, preserving existing behaviour for every syllabus where
the default grammar is correct (spec §0.13.6 backward compatibility).

Also adopted from this evidence: `GRADE_BOUNDARIES` (`gt`) added to the CAIE
document-type table, and ER association must remain **component-scoped** — a real
ER file (`0620_m25_er.pdf`) covers several papers in one document, which
`core/er_question_crops.py::_component_scope` already handles.

## 8. Files added in Milestone 1

```text
docs/decisions/0001-milestone1-inspection-and-architecture.md   this ADR
docs/REUSE_MAP.json                     32 canonical mechanisms, 12 gaps (machine-readable)
config/config.yaml                      master config (spec §17.9), crop values locked
config/boards/caie.yaml                 SUPPORTED   — all facts evidence-backed
config/boards/aqa.yaml                  taxonomy proven, extraction NOT VERIFIED
config/boards/edexcel.yaml              taxonomy proven, extraction NOT VERIFIED
config/boards/ib.yaml                   taxonomy proven; timezone = SOURCE_NOT_FOUND
config/boards/sat.yaml                  taxonomy PROVEN from College Board PDFs
universal/__init__.py                   layer docstring + canonical crop entry point
universal/config.py                     PROJECT_ROOT, resolve(), Config, config_hash()
universal/paths.py                      path helpers
universal/status.py                     full §0.9 status/state taxonomy + §17.8 error codes
adapters/__init__.py
adapters/base.py                        BoardAdapter contract (§15.1), Evidence, DocumentIdentity
adapters/registry.py                    dynamic adapter discovery + registry_report()
papers/raw/*.pdf                        7 real Cambridge documents staged (immutable)
```

Nothing in `original_reference/`, `core/`, `subjects/`, `topics/`, `main.py`,
`run_guarded.py`, `pipeline.py` or `run_pipeline.py` was modified.

## 9. Addendum — the launcher already exists (directive §34)

`run_pipeline.py` with no arguments (or `--menu`) launches
`core/control_center.py::ControlMenu` — a working 14-item production launcher:

```text
PROCESS    1 Process New Files · 2 Resume/Pending · 3 Process Selected · 4 Reprocess Everything
ARCHIVE    5 Audit Archive · 6 Preview Changes · 7 Generate Proof · 8 Statistics
SYSTEM     9 Verify Installation · 10 Cleanup Temp · 11 Settings
DEVELOPER 12 Performance Benchmark · 13 Regression Tests · 14 Developer Tools
           0 Exit
```

It is backed by `SettingsManager` (`settings.ini`), `ExamVoidLock` (single-run
guard), `GracefulShutdown`, `ProcessingManifest` header stats and
`ArchiveAuditor`/`ArchiveStatistics`/`SystemVerifier`/`SafeCleaner`/
`NewFilesScanner`/`DryRunPreviewer`.

**Decision: EXTEND, do not replace.** The universal entry point `run.py`
(Milestone 10) will present the directive-§34 core menu and delegate PROCESS
items to this existing machinery:

```text
[1] Normal Topical Generation   → existing ControlMenu PROCESS path (run_guarded)
[2] Generate Booklet            → NEW universal/booklets
[3] Search Question Bank        → NEW universal/bank/search
[4] Question Set Generator      → NEW universal/sets
[5] Question Bank Analytics     → NEW universal/bank/analytics (+ ArchiveStatistics)
[6] Quality Control / Review    → NEW universal/bank/doctor  (+ FinalValidator, ArchiveAuditor)
[7] Maintenance / Downloader    → existing qp/ms/er fetchers, extended per board
[8] Advanced (classic ExamVoid menu) → existing ControlMenu, unchanged
[0] Exit
```

`DryRunPreviewer` is the precedent for the booklet **coverage preview**
(directive §26) and will be reused rather than reinvented.
