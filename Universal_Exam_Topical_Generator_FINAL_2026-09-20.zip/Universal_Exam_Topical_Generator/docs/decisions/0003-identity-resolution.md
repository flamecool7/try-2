# ADR-0003 — Identity resolution: disagreement is a finding, not an obstacle

**Date:** 2026-09-20
**Status:** Accepted
**Extends:** ADR-0001 (Milestone 1 inspection), ADR-0002 (universal taxonomy)

## Context

Directive §7 requires identifying what a document **is**, not what its filename
**claims**. Milestone-1 testing made the risk concrete: with filename evidence removed,
`core/paper_identifier.py` dated a real 2026 paper as **2024**. Traced to source, the
loose-filename fallback did:

```python
season_letter = season_letter or c_season or "s"
year_short    = year_short    or c_year    or "24"
```

and `_full_year_from_short` returned `2024` for any non-numeric input.

`config.yaml` already declared the intended model in Milestone 1: per-source weights with
`filename: 10` as the *weakest* signal against `first_page_text: 30`, plus
`min_confident: 0.75`, `review_gap: 0.10` and `conflict_policy: REVIEW_REQUIRED`. What
did not exist was anything that collected those sources or fused them.

## Decision

**A new `universal/identity/` package collects per-field evidence from independent
sources and fuses it; `core/paper_identifier.py` keeps its role as the filename reader
and gains provenance fields recording what it invented.**

1. **Per-field, not per-document.** Each of `board`, `syllabus_code`, `year`, `season`,
   `document_type`, `component`, `variant`, `subject` is resolved separately, because a
   document can have a trustworthy code and an untrustworthy year simultaneously.
2. **Reuse the existing filename parser.** `parse_paper_filename` is called, not
   reimplemented; its output is admitted as *filename*-weighted evidence (10), never as
   truth. No second filename engine.
3. **Collectors never return defaults.** A collector that finds nothing returns nothing.
   Defaults are how silent fabrication happens.
4. **Conflict = independent disagreement, regardless of margin.** If any source supports
   *only* the rejected value, the field is `CONFLICT` and the document routes to
   `REVIEW_REQUIRED`. The stronger value is recorded as provisionally accepted and the
   rejected value is preserved in the record.
5. **`review_gap` governs within-source ambiguity only** (e.g. a cover page carrying two
   different bare years), which is `AMBIGUOUS`, not `CONFLICT`.
6. **Derivation is allowed only where a board's own encoding makes it certain**, and is
   labelled (`derived:variant`). CAIE prints `9701/22`, which *is* the `<paper><variant>`
   pair — so a document with no readable text layer still has a knowable component. No
   cross-board inference: §17 forbids assuming component codes are equivalent.
7. **Expected absences are not gaps.** Cambridge examiner reports are series-level and
   carry no variant, so a missing variant on an `er` document is correct.
8. **OCR is a fallback with a hard size cap**, triggered per `ocr.trigger` and clamped to
   `ocr.max_side_px` — a 6287×4445 render OOM-killed the process in Milestone 1. An
   unavailable backend is a recorded status, never fatal.

## Consequences

**Positive.** 7/7 real staged papers resolve with corroboration from independent sources
and zero conflicts; an image-only Urdu paper resolves through OCR. Renaming a real paper
to contradict its contents now yields `REVIEW_REQUIRED` with both readings preserved,
instead of a silent pick. `390 passed, 0 failed`; proof check `PASS`.

**Negative — accepted.** Only CAIE is exercised end-to-end, because no real non-CAIE exam
papers are staged. AQA / Edexcel / IB / SAT signatures and code patterns are implemented
but **IMPLEMENTED, not FULLY VERIFIED**. `layout` and `corpus_match` weights are declared
in config but not yet collected.

## Rejected alternatives

**Gating conflicts on the top-2 margin.** The first implementation did this, and it failed
the central requirement: a 9701 document named `0620_s23_qp_11.pdf` resolved as
`RESOLVED` because content out-weighed the name 3:1 and the margin cleared `review_gap`.
The contradiction vanished without a trace. Weight should decide *which* value is
provisionally accepted; it must not decide *whether to report* the disagreement.

**Rewriting `parse_paper_filename` to do multi-source fusion.** It is correct for
well-formed names and is load-bearing for folder naming and manifest keys across the
working pipeline. Fusion belongs above it, so the gold path is untouched.

**Making the fabricated-session defaults disappear entirely.** `season_letter` and
`year_short` flow into `batch_manifest` keys, `bundle_worker` folder prefixes and
`er_fetcher` canonical names; emptying them would break well-formed output for a case that
is now loudly flagged instead. The value is retained, the invention is recorded, and
`identity_status="REVIEW_REQUIRED"` keeps it out of the bank unnoticed.

**Heuristic mark-scheme detection from "total … mark".** Rejected after it produced false
conflicts on two genuine question papers — QP covers print "The total mark for this paper
is 60". Replaced by ≥4 distinct mark-grid rows plus absence of a "Question Paper" header.

## Note for future changes

Any edit to `core/paper_identifier.py` re-trips `lock ledger: latest rows == on-disk
sha256`. "Latest" resolves by **document order in `LOCK_DOCS`**, not by date, so the new
row must be appended to the *last* doc mentioning the path (`EFFICIENCY_AUDIT.md`). The
check reports `141/141 files verified` while failing, which is misleading — read the
`bad` list, not the detail string.
