# ADR-0002 — Universal taxonomy: build from source documents, never from code

**Date:** 2026-09-19
**Status:** Accepted
**Supersedes:** nothing. Extends ADR-0001 (Milestone 1 inspection and architecture).

## Context

The master prompt requires a data-driven topic taxonomy covering five boards, with
syllabus/version awareness, and forbids hardcoded topic lists. The repository already
contained two usable CAIE data sources — `subjects/**/config.json` (18-key schema
including `major_topics`, `mapping`, `classification_keywords`, `syllabus_years`,
`historical_year_policy`) and `topics/**/*_topics.json` (keyword/formula/weight/
paper-affinity per topic). Nothing existed for AQA, Edexcel, IB or SAT.

Two ways to fill that gap: write topic lists into code from general knowledge, or extract
them from the boards' own published specifications.

## Decision

**Extract from source documents. Emit nothing that a source did not declare.**

1. **One registry, five builders.** `universal/taxonomy/registry.py` holds the data model;
   `builder.py` holds one builder per board. Board differences live in the builders, not
   in the model.
2. **CAIE from the repository.** The legacy configs are already source-derived and drive
   the working gold pipeline, so they are ingested as-is. `canonical_name` is preserved
   verbatim because `core/output_manager.py` writes it as the physical folder name — it
   must never be case-folded or "tidied".
3. **AQA / Edexcel / SAT from official PDFs**, downloaded by
   `tools/research/fetch_board_sources.py` with sha256 + `%PDF` validation.
4. **IB from official subject-brief page text.** `ibo.org` returns HTTP 403 to direct
   clients; the briefs were retrieved with a page-fetcher and saved under
   `docs/research/ib/*.page-fetch.md`. The full paid guides are recorded as
   `SOURCE_NOT_ACCESSIBLE` rather than approximated.
5. **Cross-check, then publish the disagreement.** Counts previously extracted from these
   same specifications (`TOPICS-FROM-OWN-CORPUS.txt`) are used as an independent check and
   the result is written into `provenance.matches_corpus_counts` — including `false`.
6. **Absence of evidence emits nothing.** Where a document's structure cannot be parsed
   reliably, a diagnostic marker is written instead of a guess
   (`TABLE_AWARE_REQUIRED`, `skipped_anchors`).
7. **Cross-board links require an explicit shared id.** Title similarity is never a link.

## Consequences

**Positive.** 92 taxonomies / 2,168 nodes, all five boards, zero hardcoded topic lists,
every node traceable to a document with a sha256. AQA matches the independently-recorded
counts on 5 of 6 specs; SAT and IB match exactly; Edexcel IGCSE Chemistry matches at
4 sections / 28 sub-topics / 182 outcomes.

**Negative — accepted.** Coverage is incomplete where sources are hard to parse:
Edexcel A-Level has 19 topics but zero sub-topics, and AQA 7402 is one sub-topic short.
Both are recorded in provenance. Filling them needs `pdfplumber` table-aware extraction,
which is deliberately not rushed here: a fabricated sub-topic would poison classification
silently, whereas a missing one is visible and recoverable.

## Notable sub-decisions

**Discrete year lists are not spans.** CAIE `syllabus_years` for 9701 is
`['2015','2024','2025','2026','2027']`. An early implementation read `min(years)` as a
first-assessment year and resolved 2023 → version 2026, inventing coverage. A gapped list
is now flagged `discrete: true` and never interpolated; forward inference is restricted to
windows whose `basis` is `first_assessment_in_source`; and a config's own
`historical_year_policy: "review_required"` is honoured verbatim.

**The lock ledger is ordered by document, not by date.** Patching
`core/paper_identifier.py` (approved in ADR-0001 decision (c)) correctly tripped
`lock ledger: latest rows == on-disk sha256`. `verify_ledger()` walks `LOCK_DOCS` in list
order and the last row seen per path wins, so a new row in `ROUTING_STATE_LOCK.md` is
overridden by an older row in `EFFICIENCY_AUDIT.md`. New rows must be appended to the
**last** lock doc that mentions the path. Recorded here because it is not discoverable
from the check's output, which reports `141/141 files verified` while still failing.

**Component codes have two encodings.** `<paper><variant>` (`22` → Paper 2) and
zero-padded paper numbers (`04` → Paper 4, as used by 9686 Urdu). A leading zero is a
safe discriminator because no Cambridge paper is numbered 0.
