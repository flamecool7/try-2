"""
webp_utils.py
=============
Lossy .webp conversion, vertical image merging, imposition barcode scrubbing,
trailing answer-space trimming, and whitespace trimming.

From the reference implementation with all the working cropping logic.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import numpy as np
from PIL import Image


_WEBP_MAX_DIM = 16383


# ---------------------------------------------------------------------------
# Full-image barcode-band scrubber (user requirement 2026-08-14: no barcodes
# in any question crop). The seam/edge scrubber above only scans the top,
# bottom and page-join windows, so a barcode printed mid-page (e.g. the large
# registration barcode on 0625_w25_qp_13 page 1, between part (a) and part
# (b)) sails straight through into the assembled question image. This pass
# scans the ENTIRE image for horizontal bands of uniform vertical bars.
#
# The discriminator is the bar pattern itself: a real barcode is a solid
# stripe comb whose dark/light column positions are IDENTICAL on every row of
# the band. Text, tables, grids and halftones all vary row-to-row, so they
# fail the consistency test; a barcode also sits isolated (white rows above
# and below) and its bars span the full band height. When in doubt, KEEP
# content — erasing real content is the worst possible failure.
# ---------------------------------------------------------------------------

def scrub_barcode_bands(img: Image.Image) -> Image.Image:
    """Remove any horizontal barcode stripe band anywhere in the image.

    Scans the full canvas (not just seams/edges), whitens verified barcode
    bands, returns the (possibly modified) image. Pure content is never
    touched: a band must pass ALL of (bar consistency across rows, bars
    spanning the band height, isolation above/below) before it is painted.
    """
    arr = np.array(img.convert("L"))
    h, w = arr.shape
    if h < 24 or w < 60:
        return img

    dark = arr < 128
    # Per-row dark runs (vertical-bar candidates).
    row_runs = []          # list of (n_runs, span0, span1, fill) per row
    band_rows = np.zeros(h, dtype=bool)
    padded = np.pad(dark, ((0, 0), (1, 1)), constant_values=False)
    diff = np.diff(padded.astype(np.int8), axis=1)
    starts = diff == 1
    ends = diff == -1
    for y in range(h):
        xs = np.where(starts[y])[0] - 1
        xe = np.where(ends[y])[0] - 1
        if xs.size == 0 or xs.size != xe.size:
            continue
        # count of runs, span, fill
        span0 = int(xs[0]); span1 = int(xe[-1])
        bw = span1 - span0 + 1
        if bw < 60 or xs.size < 10:
            continue
        fill = float(dark[y, span0:span1 + 1].mean())
        if fill < 0.15 or fill > 0.85:
            continue
        row_runs.append((y, xs, xe, span0, span1, fill))
        band_rows[y] = True

    if not row_runs:
        return img

    # Cluster consecutive candidate rows (allow a 2-row gap).
    bands = []
    cur = [row_runs[0]]
    last_y = row_runs[0][0]
    for item in row_runs[1:]:
        if item[0] - last_y <= 3:
            cur.append(item)
        else:
            bands.append(cur)
            cur = [item]
        last_y = item[0]
    bands.append(cur)

    def _row_is_barcode(ys_ref: np.ndarray, ye_ref: np.ndarray,
                        ys: np.ndarray, ye: np.ndarray) -> bool:
        """Starts/ends agree within 2px on >= 85% of the shared bars."""
        if ys.size == 0 or ys_ref.size == 0:
            return False
        ref = set(zip(ys_ref.tolist(), ye_ref.tolist()))
        if not ref:
            return False
        hits = 0
        for a, b in zip(ys.tolist(), ye.tolist()):
            for (ra, rb) in ref:
                if abs(a - ra) <= 2 and abs(b - rb) <= 2:
                    hits += 1
                    break
        return hits / max(1, len(ref)) >= 0.85

    painted = 0
    for band in bands:
        y0 = band[0][0]
        y1 = band[-1][0] + 1
        bh = y1 - y0
        if bh < 20:
            continue
        x0 = min(b[3] for b in band)
        x1 = max(b[4] for b in band)
        # (1) pattern consistency across sampled rows
        step = max(1, len(band) // 8)
        ref = band[0]
        ok = True
        for idx in range(step, len(band), step):
            b = band[idx]
            if not _row_is_barcode(ref[1], ref[2], b[1], b[2]):
                ok = False
                break
        if not ok:
            continue
        # (2) bars span the full band height
        sub = dark[y0:y1, x0:x1 + 1]
        col_has = sub.any(axis=0)
        if int(col_has.sum()) < 12:
            continue
        span_touch = 0
        total = 0
        for x in np.where(col_has)[0][:400]:
            ys_c = np.where(sub[:, x])[0]
            if ys_c.size == 0:
                continue
            total += 1
            if ys_c[0] <= 2 and ys_c[-1] >= bh - 3:
                span_touch += 1
        if total and span_touch / total < 0.60:
            continue
        # (3) isolation: rows above/below are mostly white
        isolated = True
        for (wa, wb) in ((y0 - 8, y0), (y1, y1 + 8)):
            wa = max(0, wa)
            wb = min(h, wb)
            if wb > wa:
                win = dark[wa:wb, max(0, x0 - 4):x1 + 5]
                row_has = win.any(axis=1)
                if float(row_has.sum()) / (wb - wa) > 0.30:
                    isolated = False
                    break
        if not isolated:
            continue
        # verified barcode band -> paint white (small pad, clipped)
        py0 = max(0, y0 - 4)
        py1 = min(h, y1 + 4)
        px0 = max(0, x0 - 6)
        px1 = min(w, x1 + 7)
        arr[py0:py1, px0:px1] = 255
        painted += 1

    if not painted:
        return img
    out = Image.fromarray(arr).convert(img.mode if img.mode == "L" else "RGB")
    return out


def save_webp(img: Image.Image, path: str | Path, quality: int = 92) -> List[Path]:
    """Save ``img`` as WebP, tiling vertically if it exceeds the WebP size limit."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    w, h = img.size
    stride = _WEBP_MAX_DIM - 16

    if w <= _WEBP_MAX_DIM and h <= _WEBP_MAX_DIM:
        img.save(str(path), format="WEBP", quality=quality, method=4)
        return [path]

    parts: List[Path] = []
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    idx = 1
    y = 0
    while y < h:
        y1 = min(h, y + stride)
        tile = img.crop((0, y, w, y1))
        if idx == 1:
            out = path
        else:
            out = parent / f"{stem}_part{idx}{suffix}"
        if tile.width > _WEBP_MAX_DIM or tile.height > _WEBP_MAX_DIM:
            out = out.with_suffix(".jpg")
            tile.save(str(out), format="JPEG", quality=max(70, quality),
                      optimize=True)
        else:
            tile.save(str(out), format="WEBP", quality=quality, method=4)
        parts.append(out)
        idx += 1
        y = y1
    return parts


# ---------------------------------------------------------------------------
# Imposition-barcode scrubber
# ---------------------------------------------------------------------------

def _scrub_imposition_marks(img: Image.Image, scan_full_page: bool = False,
                            page_seams: Optional[List[int]] = None,
                            ) -> Image.Image:
    """Remove printer-imposition registration barcodes (raster stripe bands)."""
    import numpy as _np
    arr = _np.array(img.convert("L")).copy()
    h, w = arr.shape

    LEFT_SAFE = 70
    DARK_T = 50
    MIN_BW = 150
    MAX_BW = int(w * 0.98)
    MIN_T_PER_100 = 18
    MIN_TRANS = 30
    MIN_FILL = 0.05
    MAX_FILL = 0.65
    MAX_BAND_H = 80
    MIN_BAND_H = 6
    ROW_GAP = 2
    PAINT_PAD = 3
    MAX_WHITE_GAP = 12

    # ── Amendment 4 (2026-08-10): content guards ──────────────────────────
    # The band/blob heuristics below were designed for printer-imposition
    # registration barcodes: SOLID, PERIODIC, ISOLATED stripe combs. Verified
    # on real Cambridge MS papers (9700 m25/w25 MS), the old heuristics also
    # "matched" marking-table rows and margin labels (22k-58k content pixels
    # silently whited per paper — the "1(a) disappearing" defect). A real
    # barcode comb passes all three of these independent tests; text and
    # table structure each fail at least one. When in doubt, KEEP content:
    # erasing real content is the worst possible failure.
    def _band_is_barcode(by0: int, by1: int, bx0: int, bx1: int) -> bool:
        bh = by1 - by0
        if bh < 4 or bx1 - bx0 < 40:
            return False
        band = arr[by0:by1, bx0:bx1] < DARK_T
        col_has = band.any(axis=0)
        ncols = int(col_has.sum())
        if ncols < 12:
            return False
        # (1) stripe bars span the FULL height of the band (~all dark
        # columns touch both ends); text strokes and glyph fragments do not.
        col_idx = _np.where(col_has)[0]
        probe = col_idx[:400]  # combs are uniform; sampling is enough
        touch = 0
        for x in probe:
            ys = _np.where(band[:, x])[0]
            if ys[0] <= 1 and ys[-1] >= bh - 2:
                touch += 1
        if touch / probe.size < 0.60:
            return False
        # (2) stripe cadence: white-gap widths between consecutive dark runs
        # on the busiest row are near-constant for a comb, erratic for text.
        row_counts = band.sum(axis=1)
        row = band[int(row_counts.argmax())]
        xs = _np.where(row)[0]
        if xs.size < 24:
            return False
        splits = _np.where(_np.diff(xs) > 1)[0]
        starts = _np.concatenate(([xs[0]], xs[splits + 1]))
        ends = _np.concatenate((xs[splits], [xs[-1]]))
        gaps = (starts[1:] - ends[:-1]).astype(_np.float64)
        if gaps.size < 10 or gaps.mean() <= 0:
            return False
        if float(gaps.std() / gaps.mean()) > 0.25:
            return False
        # (3) isolation: a registration comb stands alone — rows directly
        # above and below are white. Table content rows always continue
        # (vertical borders, adjacent text rows).
        ISOL = 8
        for (wa, wb) in ((by0 - ISOL, by0), (by1, by1 + ISOL)):
            wa = max(0, wa)
            wb = min(h, wb)
            if wb > wa:
                win = arr[wa:wb, bx0:bx1] < DARK_T
                if float((win.any(axis=1)).sum()) / (wb - wa) > 0.15:
                    return False
        return True

    def _row_candidate_bands(row: _np.ndarray):
        dark_mask = row < DARK_T
        runs = []
        i = 0
        n = len(row)
        while i < n:
            if dark_mask[i]:
                j = i
                while j < n and dark_mask[j]:
                    j += 1
                runs.append((i, j))
                i = j
            else:
                i += 1
        if len(runs) < 8:
            return []
        MERGE_GAP = MAX_WHITE_GAP
        merged = []
        cs, ce = runs[0]
        for s, e in runs[1:]:
            if s - ce <= MERGE_GAP:
                ce = e
            else:
                merged.append((cs, ce))
                cs, ce = s, e
        merged.append((cs, ce))
        out = []
        for s, e in merged:
            bw = e - s
            if bw < MIN_BW or bw > MAX_BW:
                continue
            if e < LEFT_SAFE + 20:
                continue
            sub = dark_mask[s:e]
            fill = float(sub.mean())
            if fill < MIN_FILL or fill > MAX_FILL:
                continue
            trans = int(_np.abs(_np.diff(sub.astype(_np.int8))).sum())
            t100 = trans / (bw / 100.0)
            if trans < MIN_TRANS or t100 < MIN_T_PER_100:
                continue
            out.append((max(int(s), LEFT_SAFE), int(e)))
        return out

    def _vertical_coherent_hits(y_start: int, y_end: int):
        hits_by_y: dict = {}
        for y in range(max(0, y_start), min(h, y_end)):
            bands = _row_candidate_bands(arr[y])
            if bands:
                hits_by_y[y] = bands
        if not hits_by_y:
            return []
        ys = sorted(hits_by_y.keys())
        visited = set()
        rects = []
        for i, y in enumerate(ys):
            if y in visited:
                continue
            cluster_ys = [y]
            cur_bands = list(hits_by_y[y])
            for ny in range(y + 1, min(y + MAX_BAND_H + 5, min(h, y_end))):
                if ny not in hits_by_y:
                    if ny - cluster_ys[-1] > ROW_GAP:
                        break
                    continue
                nb = hits_by_y[ny]
                overlap = False
                for (cx0, cx1) in cur_bands:
                    for (nx0, nx1) in nb:
                        if nx0 < cx1 - 20 and nx1 > cx0 + 20:
                            overlap = True
                            break
                    if overlap:
                        break
                if overlap or ny - cluster_ys[-1] <= ROW_GAP:
                    cluster_ys.append(ny)
                    cur_bands = nb
                else:
                    break
            cluster_h = cluster_ys[-1] - cluster_ys[0] + 1
            if cluster_h < MIN_BAND_H:
                continue
            bx0 = min(b[0] for yy in cluster_ys for b in hits_by_y[yy])
            bx1 = max(b[1] for yy in cluster_ys for b in hits_by_y[yy])
            for yy in cluster_ys:
                visited.add(yy)
            by0, by1 = cluster_ys[0], cluster_ys[-1] + 1
            sub = arr[by0:by1, bx0:bx1] < DARK_T
            cluster_h = by1 - by0
            col_tall_dark = 0
            mid_y = cluster_h // 2
            for x in range(sub.shape[1]):
                col = sub[:, x]
                if col.any():
                    max_run = 0; run = 0
                    for v in col:
                        if v:
                            run += 1
                            if run > max_run: max_run = run
                        else:
                            run = 0
                    if max_run >= cluster_h * 0.40:
                        col_tall_dark += 1
            mid_dark = arr[by0 + mid_y, bx0:bx1] < DARK_T
            mid_row_trans = int(np.abs(np.diff(mid_dark.astype(np.int8))).sum())
            density = col_tall_dark / max(1, (bx1 - bx0))
            EDGE_PROX = 200 if scan_full_page else 130
            touches_left_edge = bx0 < EDGE_PROX
            touches_right_edge = bx1 > w - EDGE_PROX
            is_dense_tall = (col_tall_dark >= 25 and density >= 0.10)
            is_super_stripey = (mid_row_trans >= 180 and cluster_h >= 6)
            if not (is_dense_tall or is_super_stripey):
                continue
            if not (touches_left_edge or touches_right_edge):
                continue
            if touches_left_edge and touches_right_edge and (bx1 - bx0) > 0.92 * w and cluster_h <= 5:
                continue
            rects.append((by0, by1, bx0, bx1))
        return rects

    def _scrub_region(y_start: int, y_end: int) -> int:
        rects = _vertical_coherent_hits(y_start, y_end)
        kept = 0
        for (by0, by1, bx0, bx1) in rects:
            if not _band_is_barcode(by0, by1, bx0, bx1):
                continue  # Amendment 4: content, not a registration comb
            kept += 1
            x0 = max(LEFT_SAFE, bx0 - PAINT_PAD)
            x1 = min(w, bx1 + PAINT_PAD)
            y0 = max(0, by0 - PAINT_PAD)
            y1 = min(h, by1 + PAINT_PAD)
            if y1 - y0 > MAX_BAND_H + 10:
                y1 = y0 + MAX_BAND_H + 10
            arr[y0:y1, x0:x1] = 255
            for yy in range(max(0, y0 - 4), min(h, y1 + 4)):
                seg = arr[yy, x0:x1]
                dark_seg = seg < 100
                if 0 < dark_seg.sum() < (x1 - x0) * 0.15:
                    arr[yy, x0:x1] = _np.where(dark_seg, 255, seg)
        return kept  # Amendment 4: only barcode-verified rects were painted

    if scan_full_page:
        SEAM_WINDOW = 80
        regions: List[Tuple[int, int]] = []
        regions.append((0, min(h, SEAM_WINDOW)))
        regions.append((max(0, h - SEAM_WINDOW), h))
        if page_seams:
            for sy in page_seams:
                y0 = max(0, sy - SEAM_WINDOW)
                y1 = min(h, sy + SEAM_WINDOW)
                regions.append((y0, y1))
        regions.sort()
        merged: List[Tuple[int, int]] = []
        for y0, y1 in regions:
            if merged and y0 <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], y1))
            else:
                merged.append((y0, y1))
        for y0, y1 in merged:
            _scrub_region(y0, y1)
    else:
        edge = int(h * 0.12)
        _scrub_region(0, edge)
        _scrub_region(h - edge, h)

    if not scan_full_page:
        EDGE_STRIP = 110
        def _in_edge(x: int) -> bool:
            return x < EDGE_STRIP or x >= w - EDGE_STRIP
        import collections as _collections
        dark_edge = arr < 180
        visited = _np.zeros_like(dark_edge, dtype=bool)
        edge_blobs = []
        seed_xs = (list(range(0, EDGE_STRIP))
                   + list(range(max(EDGE_STRIP, w - EDGE_STRIP), w)))
        for sx in seed_xs:
            if sx < 0 or sx >= w:
                continue
            for sy in range(h):
                if visited[sy, sx] or not dark_edge[sy, sx]:
                    continue
                q = _collections.deque()
                q.append((sy, sx))
                visited[sy, sx] = True
                blob: list = []
                touches_interior = False
                min_x = max_x = sx
                min_y = max_y = sy
                while q:
                    cy, cx = q.popleft()
                    blob.append((cy, cx))
                    if cx < min_x: min_x = cx
                    if cx > max_x: max_x = cx
                    if cy < min_y: min_y = cy
                    if cy > max_y: max_y = cy
                    if not _in_edge(cx):
                        touches_interior = True
                    for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        ny, nx = cy + dy, cx + dx
                        if (0 <= ny < h and 0 <= nx < w
                                and not visited[ny, nx]
                                and dark_edge[ny, nx]):
                            visited[ny, nx] = True
                            q.append((ny, nx))
                if touches_interior:
                    continue
                bh = max_y - min_y + 1
                bw = max_x - min_x + 1
                area = len(blob)
                # Amendment 4: long rules/borders are never combs; everything
                # else is collected and the comb-group test below decides.
                # (The old "quiet zone" early-exit left a coverage hole where
                # comb bars at x<70 survived; uniform collection fixes it.)
                if bh > 150 and area > 200:
                    continue
                if area < 2500 and bh < 200 and bw < 200:
                    edge_blobs.append((min_y, max_y, min_x, max_x, blob))

        # Amendment 4 (2026-08-10): erase edge-strip blobs ONLY when they form
        # a verified registration comb — ≥8 equally spaced tall bars with
        # strongly overlapping y-intervals. Everything else (MS margin labels,
        # marks-column digits, cover bullets, punctuation, specks) is kept.
        # Verified against real Cambridge MS papers: glyph/speck blobs are
        # image-indistinguishable from printer marks, so comb-structure is
        # the only safe discriminator; content always wins.
        for want_left in (True, False):
            cand = [b for b in edge_blobs
                    if (b[2] < w // 2) == want_left
                    and (b[1] - b[0] + 1) >= 30    # bars are tall; glyphs are not
                    and (b[3] - b[2] + 1) <= 40    # bars are narrow
                    and len(b[4]) >= 60]           # bars are solid
            cand.sort(key=lambda b: b[2])
            n = len(cand)
            i = 0
            while i < n:
                j = i + 1
                gap0 = None
                while j < n:
                    prev, cur = cand[j - 1], cand[j]
                    gap = cur[2] - prev[3] - 1
                    bw_prev = prev[3] - prev[2] + 1
                    minh = min(prev[1] - prev[0], cur[1] - cur[0]) + 1
                    ov = min(prev[1], cur[1]) - max(prev[0], cur[0]) + 1
                    if gap0 is None:
                        if gap < 1 or gap > max(24, 4 * bw_prev):
                            break
                        gap0 = gap
                    elif gap < 1 or abs(gap - gap0) > 2:
                        break
                    if ov < 0.6 * minh:
                        break
                    j += 1
                if j - i >= 8:  # a real comb; erase its bars
                    for b in cand[i:j]:
                        for (cy, cx) in b[4]:
                            arr[cy, cx] = 255
                i = max(j, i + 1)

    if scan_full_page:
        edge_trim = 18
        if h > 2 * edge_trim + 50 and w > 2 * edge_trim + 50:
            arr = arr[edge_trim:h - edge_trim, edge_trim:w - edge_trim]

    return Image.fromarray(arr, mode="L").convert("RGB")


# ---------------------------------------------------------------------------
# Trailing answer-space trimming
# ---------------------------------------------------------------------------

def _row_fill(arr: np.ndarray) -> np.ndarray:
    return (arr < 230).sum(axis=1) / arr.shape[1]


def _is_barcode_row(rf: np.ndarray, y: int, h: int) -> bool:
    return 0 <= y < h and float(rf[y]) > 0.60


def _is_dotted_rule_row(rf: np.ndarray, y: int, h: int) -> bool:
    return 0 <= y < h and 0.25 <= float(rf[y]) <= 0.60


def _bands_bottom_up(arr: np.ndarray):
    h, w = arr.shape
    dark = arr < 230
    rf = _row_fill(arr)
    y = h - 1
    while y >= 0 and float(rf[y]) < 0.003:
        y -= 1
    if y < 0:
        return
    while y >= 0:
        while y >= 0 and float(rf[y]) < 0.003:
            y -= 1
        if y < 0:
            break
        y1 = y + 1
        kinds: set = set()
        while y >= 0 and float(rf[y]) >= 0.003:
            if _is_barcode_row(rf, y, h):
                kinds.add("barcode")
            elif _is_dotted_rule_row(rf, y, h):
                kinds.add("dotted")
            else:
                kinds.add("text")
            y -= 1
        y0 = y + 1
        sub = dark[y0:y1]
        cols = sub.any(axis=0)
        if cols.any():
            cx0 = int(np.argmax(cols))
            cx1 = w - int(np.argmax(cols[::-1]))
            bw = int(cx1 - cx0)
        else:
            bw = 0
        yield y0, y1, y1 - y0, bw, float(sub.mean()), kinds


def _band_rightmost_text_is_total_marker(arr: np.ndarray, y0: int, y1: int,
                                          w: int) -> bool:
    import numpy as _np
    band = arr[y0:y1, :]
    dark = band < 80
    if not dark.any():
        return False
    if (y1 - y0) > 50:
        return False
    all_cols = _np.where(dark.any(axis=0))[0]
    if len(all_cols) == 0:
        return False
    leftmost = int(all_cols[0])
    rightmost = int(all_cols[-1])
    content_width = rightmost - leftmost + 1

    if leftmost >= int(w * 0.60) and int(w * 0.08) <= content_width <= int(w * 0.30):
        dark_pixels = int(dark.sum())
        if dark_pixels >= (y1 - y0) * content_width * 0.10:
            return True

    band_h = y1 - y0
    if content_width > int(w * 0.70) and 12 <= band_h <= 50:
        right_start = int(w * 0.75)
        right_region = dark[:, right_start:]
        max_tall_run = 0
        for c in range(right_region.shape[1]):
            col = right_region[:, c]
            run = 0
            for v in col:
                if v:
                    run += 1
                    if run > max_tall_run:
                        max_tall_run = run
                else:
                    run = 0
        if max_tall_run >= max(10, band_h * 0.40):
            return True

    return False


def _find_trailing_answer_cut(arr: np.ndarray, floor_frac: float = 0.15):
    h, w = arr.shape
    bands = list(_bands_bottom_up(arr))

    def is_text_kind(kinds):
        return "text" in kinds
    def is_dotted_kind(kinds):
        return "dotted" in kinds

    content_cut_y = h
    total_band = None
    found_total = False
    for idx, (y0, y1, bh, bw, mean_f, kinds) in enumerate(bands):
        is_ws = (bw == 0)
        is_barcode = "barcode" in kinds
        is_dotted = "dotted" in kinds
        is_text = "text" in kinds
        is_total = _band_rightmost_text_is_total_marker(arr, y0, y1, w)
        is_mark = (bh <= 30 and bw < int(w * 0.22) and not is_total)

        if is_total and not found_total:
            total_band = (y0, y1)
            found_total = True
            content_cut_y = y0
            continue
        if not found_total:
            if is_ws or is_barcode or is_mark:
                content_cut_y = y0
                continue
            content_cut_y = y1
            break
        if is_ws or is_barcode or is_mark:
            content_cut_y = y0
            continue
        if is_dotted:
            content_cut_y = y0
            continue
        if bh < 15:
            content_cut_y = y0
            continue
        if is_text and not is_dotted and bh > 15 and bw > int(w * 0.25):
            content_cut_y = y1
            break
        content_cut_y = y1
        break

    content_cut_y = max(content_cut_y, int(h * floor_frac))
    content_cut_y = min(content_cut_y, h)
    if h - content_cut_y < 60:
        return None
    return content_cut_y, total_band


def _trim_working_space(img: Image.Image) -> Image.Image:
    """Trim trailing answer-space from the BOTTOM of a fully-merged question image."""
    import numpy as _np
    arr = _np.array(img.convert("L"))
    h, w = arr.shape
    if h < 200:
        return img
    result = _find_trailing_answer_cut(arr, floor_frac=0.20)
    if result is None:
        return img
    cut, total_band = result
    cut = max(int(h * 0.20), cut)
    cut = min(h - 80, cut)
    if h - cut < 60:
        return img

    cropped = img.crop((0, 0, img.width, cut))

    if total_band is None:
        return cropped

    t_y0, t_y1 = total_band
    t_band_h = t_y1 - t_y0
    gap = t_y0 - cut
    if gap < 0 or gap < 200:
        return cropped

    margin = 40
    new_h = cut + margin + t_band_h + 20
    canvas = Image.new("RGB", (img.width, new_h), "white")
    canvas.paste(cropped, (0, 0))
    band_img = img.crop((0, max(0, t_y0 - 2), img.width, min(h, t_y1 + 2)))
    canvas.paste(band_img, (0, cut + margin))
    return canvas


def trim_whitespace(img: Image.Image, dark_thresh: int = 252,
                    pad: int = 14,
                    trim_tail_answer_space: bool = True,
                    vertical_only: bool = False,
                    h_only_white_border: bool = False) -> Image.Image:
    """Crop excess white borders and vertical separator strips."""
    if img is None:
        return img
    from .pdf_io import trim_margin_warnings
    if not vertical_only and not h_only_white_border:
        img = trim_margin_warnings(img)
    arr = np.array(img.convert("L"))
    content = arr < dark_thresh
    if not content.any():
        return img
    rows = np.any(content, axis=1)
    r0, r1 = int(np.argmax(rows)), len(rows) - int(np.argmax(rows[::-1]))
    r0 = max(0, r0 - pad)
    r1 = min(img.height, r1 + pad)
    if vertical_only:
        c0, c1 = 0, img.width
    else:
        cols = np.any(content, axis=0)
        c0, c1 = int(np.argmax(cols)), len(cols) - int(np.argmax(cols[::-1]))
        c0 = max(0, c0 - pad)
        c1 = min(img.width, c1 + pad)
    if r1 - r0 < 17 or c1 - c0 < 17:
        return img
    cropped = img.crop((c0, r0, c1, r1))
    if trim_tail_answer_space:
        return _trim_working_space(cropped)
    return cropped


def merge_vertical(images: List[Image.Image],
                   trim_tail: bool = True) -> Image.Image:
    """Stack images vertically on a white canvas with barcode scrubbing."""
    real = [im for im in images if im.height >= 17]
    if not real:
        real = images
    if len(real) == 1:
        return trim_whitespace(real[0], h_only_white_border=True,
                               trim_tail_answer_space=trim_tail)
    w = max(im.width for im in real)
    h = sum(im.height for im in real)
    canvas = Image.new("RGB", (w, h), "white")
    y = 0
    seams: List[int] = []
    for im in real:
        canvas.paste(im, (0, y))
        y += im.height
        seams.append(y)
    canvas = _scrub_imposition_marks(canvas, scan_full_page=True,
                                     page_seams=seams)
    return trim_whitespace(canvas, h_only_white_border=True,
                           trim_tail_answer_space=trim_tail)
