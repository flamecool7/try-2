"""Identity fusion: turn contradictory evidence into an explicit verdict.

Rules come from `config.yaml`, not from code:

    detection.min_confident: 0.75          # below this -> not accepted
    detection.review_gap:    0.10          # top-2 margin below this -> REVIEW_REQUIRED
    detection.conflict_policy: REVIEW_REQUIRED   # never silently pick a side

The central rule of this module: **a disagreement between sources is a finding, not
an obstacle.** When two independent sources disagree on a material field the result is
`IDENTITY_CONFLICT` and the document is routed to `REVIEW_REQUIRED`. The losing value is
never discarded quietly — it stays in the record so a human can see what was rejected
and why.

Nothing here writes files, crops images or names folders. It only produces a verdict.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from universal.config import load_config
from universal.identity.evidence import FIELDS, Evidence, EvidenceBundle, EvidenceCollector

# Material fields: identity is unusable if any of these is unresolved.
MATERIAL = ("board", "syllabus_code", "year", "document_type")
# Secondary fields: missing is reported as PARTIAL, not as a failure.
SECONDARY = ("season", "component", "variant", "subject")


@dataclass
class FieldVerdict:
    """Resolution outcome for one identity field."""

    field: str
    value: Any = None
    confidence: float = 0.0
    status: str = "NO_EVIDENCE"     # RESOLVED | AMBIGUOUS | CONFLICT | NO_EVIDENCE
    material: bool = False
    candidates: List[Dict[str, Any]] = field(default_factory=list)
    conflicts: List[Dict[str, Any]] = field(default_factory=list)
    reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"field": self.field, "value": self.value,
                "confidence": round(self.confidence, 4), "status": self.status,
                "material": self.material, "reason": self.reason,
                "candidates": self.candidates, "conflicts": self.conflicts}


@dataclass
class IdentityVerdict:
    """The whole-document verdict."""

    path: Path
    status: str = "UNKNOWN"   # RESOLVED | PARTIAL | REVIEW_REQUIRED | INSUFFICIENT_EVIDENCE
    identity: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    fields: Dict[str, FieldVerdict] = field(default_factory=dict)
    reasons: List[str] = field(default_factory=list)
    conflicts: List[Dict[str, Any]] = field(default_factory=list)
    bundle: Optional[EvidenceBundle] = None

    @property
    def needs_review(self) -> bool:
        return self.status in ("REVIEW_REQUIRED", "INSUFFICIENT_EVIDENCE")

    def to_dict(self, include_evidence: bool = True) -> Dict[str, Any]:
        d = {
            "path": str(self.path),
            "status": self.status,
            "identity": self.identity,
            "confidence": round(self.confidence, 4),
            "reasons": self.reasons,
            "conflicts": self.conflicts,
            "fields": {k: v.to_dict() for k, v in self.fields.items()},
        }
        if include_evidence and self.bundle is not None:
            d["evidence"] = self.bundle.to_dict()
        return d


class IdentityResolver:
    """Fuses an `EvidenceBundle` into an `IdentityVerdict`."""

    def __init__(self, config=None):
        self.cfg = config or load_config()
        self.min_confident = float(self.cfg.get("detection.min_confident", 0.75))
        self.review_gap = float(self.cfg.get("detection.review_gap", 0.10))
        self.conflict_policy = str(self.cfg.get("detection.conflict_policy",
                                               "REVIEW_REQUIRED"))
        self.collector = EvidenceCollector(self.cfg)

    # -- per-field fusion ----------------------------------------------------
    def fuse_field(self, bundle: EvidenceBundle, name: str) -> FieldVerdict:
        evs = bundle.for_field(name)
        v = FieldVerdict(field=name, material=name in MATERIAL)
        if not evs:
            v.status = "NO_EVIDENCE"
            v.reason = "no source produced this field"
            return v

        # group by comparable value, summing weight per distinct source
        groups: Dict[str, Dict[str, Any]] = {}
        for e in evs:
            if e.norm_value == "":
                continue
            g = groups.setdefault(e.norm_value, {"value": e.value, "weight": 0.0,
                                                 "sources": set(), "evidence": []})
            g["weight"] += float(e.weight or 0.0)
            g["sources"].add(e.source)
            g["evidence"].append(e)
        if not groups:
            v.status = "NO_EVIDENCE"
            v.reason = "all collected values were empty"
            return v

        total = sum(g["weight"] for g in groups.values()) or 1.0
        ranked = sorted(groups.items(), key=lambda kv: kv[1]["weight"], reverse=True)
        v.candidates = [
            {"value": g["value"], "weight": round(g["weight"], 3),
             "confidence": round(g["weight"] / total, 4),
             "sources": sorted(g["sources"]),
             "snippets": [e.snippet for e in g["evidence"][:3]]}
            for _, g in ranked
        ]

        top_key, top = ranked[0]
        v.confidence = top["weight"] / total
        v.value = top["value"]

        # Independent sources agreeing is strong. The same source repeating itself
        # is not, so count distinct sources rather than raw hits.
        distinct_sources = len(top["sources"])

        if len(ranked) > 1:
            second_key, second = ranked[1]
            margin = v.confidence - (second["weight"] / total)
            # A CONFLICT is when two different sources disagree, not merely when a
            # weaker duplicate reading exists.
            # Which sources support ONLY the rejected value? If any exist, two
            # genuinely independent sources disagree — that is a CONFLICT no matter
            # how lopsided the weights are. `conflict_policy: REVIEW_REQUIRED`
            # means never silently pick a side: the stronger value is recorded as
            # provisionally accepted, and the disagreement is still surfaced.
            #
            # Gating on the top-2 margin instead (the first implementation) let a
            # lying filename lose quietly: 9701 content out-weighed a "0620" name
            # 3:1, the margin cleared review_gap, and the document was accepted as
            # RESOLVED with no trace of the contradiction.
            exclusive_second = second["sources"] - top["sources"]
            v.conflicts = [{
                "field": name,
                "accepted": {"value": top["value"], "sources": sorted(top["sources"]),
                             "weight": round(top["weight"], 3),
                             "confidence": round(v.confidence, 4)},
                "rejected": {"value": second["value"],
                             "sources": sorted(second["sources"]),
                             "exclusive_sources": sorted(exclusive_second),
                             "weight": round(second["weight"], 3)},
                "margin": round(margin, 4),
                "independent_disagreement": bool(exclusive_second),
                "material": v.material,
                "policy": self.conflict_policy,
            }]
            if exclusive_second:
                v.status = "CONFLICT"
                v.reason = (f"{sorted(exclusive_second)} report {second['value']!r} "
                            f"while {sorted(top['sources'])} report {top['value']!r}; "
                            f"independent sources disagree (margin {margin:.3f} is "
                            "irrelevant — policy is REVIEW_REQUIRED)")
                return v
            if margin < self.review_gap:
                # Same source(s) on both sides: within-source ambiguity, e.g. a
                # cover page carrying two different bare years.
                v.status = "AMBIGUOUS"
                v.reason = (f"top-2 margin {margin:.3f} below review_gap "
                            f"{self.review_gap} ({top['value']!r} vs {second['value']!r}); "
                            f"same sources both sides: {sorted(top['sources'])}")
                return v

        if v.confidence < self.min_confident and distinct_sources < 2:
            v.status = "AMBIGUOUS"
            v.reason = (f"confidence {v.confidence:.3f} < min_confident "
                        f"{self.min_confident} from {distinct_sources} source(s)")
            return v

        v.status = "RESOLVED"
        v.reason = (f"confidence {v.confidence:.3f} from {distinct_sources} "
                    f"source(s): {sorted(top['sources'])}")
        return v

    # -- derivation ----------------------------------------------------------
    def _derive_fields(self, bundle: EvidenceBundle,
                       verdict: "IdentityVerdict") -> None:
        """Fill a field from an already-resolved field, marked as derived.

        Derivation is only allowed where the board's own encoding makes it a
        certainty. For CAIE the two-digit component code printed on the cover
        (`9701/22`) IS the `<paper><variant>` pair carried in the filename, so a
        document with no readable text layer (OCR-only, e.g. the 9686 Urdu paper)
        still has a knowable component. No cross-board inference is made: §17
        forbids assuming component codes mean the same thing on other boards.
        """
        board = verdict.identity.get("board")
        comp = verdict.fields.get("component")
        var = verdict.fields.get("variant")
        if (board == "CAIE" and comp is not None
                and comp.status != "RESOLVED"
                and var is not None and var.status == "RESOLVED"
                and str(var.value).isdigit()):
            comp.value = str(var.value)
            comp.status = "RESOLVED"
            comp.confidence = var.confidence
            comp.reason = ("derived from variant: CAIE prints the component code as "
                           "the <paper><variant> pair (no cross-board inference)")
            comp.candidates = [{"value": comp.value, "sources": ["derived:variant"],
                                "confidence": round(comp.confidence, 4),
                                "weight": 0.0, "snippets": []}]
            verdict.identity["component"] = comp.value

    # -- whole document ------------------------------------------------------
    def resolve(self, path: str | Path,
                bundle: Optional[EvidenceBundle] = None) -> IdentityVerdict:
        path = Path(path)
        bundle = bundle or self.collector.collect(path)
        verdict = IdentityVerdict(path=path, bundle=bundle)

        for name in FIELDS:
            fv = self.fuse_field(bundle, name)
            verdict.fields[name] = fv
            if fv.status == "RESOLVED":
                verdict.identity[name] = fv.value

        self._derive_fields(bundle, verdict)

        material_unresolved = [n for n in MATERIAL
                               if verdict.fields[n].status != "RESOLVED"]
        conflicts = [c for fv in verdict.fields.values() for c in fv.conflicts
                     if fv.status == "CONFLICT"]
        verdict.conflicts = conflicts

        resolved_mat = [n for n in MATERIAL if verdict.fields[n].status == "RESOLVED"]
        if resolved_mat:
            verdict.confidence = sum(verdict.fields[n].confidence
                                     for n in resolved_mat) / len(MATERIAL)

        if not any(verdict.fields[n].status == "RESOLVED" for n in FIELDS):
            verdict.status = "INSUFFICIENT_EVIDENCE"
            verdict.reasons.append("no identity field could be resolved from any source")
        elif conflicts:
            verdict.status = "REVIEW_REQUIRED"
            for c in conflicts:
                verdict.reasons.append(
                    f"IDENTITY_CONFLICT on {c['field']}: {c['accepted']['value']!r} "
                    f"({','.join(c['accepted']['sources'])}) vs "
                    f"{c['rejected']['value']!r} ({','.join(c['rejected']['sources'])})")
        elif material_unresolved:
            verdict.status = "REVIEW_REQUIRED"
            for n in material_unresolved:
                fv = verdict.fields[n]
                verdict.reasons.append(
                    f"material field '{n}' is {fv.status}: {fv.reason}")
        else:
            # Some absences are correct rather than incomplete. Cambridge examiner
            # reports are series-level and carry NO variant (core/er_fetcher.py
            # builds `{code}_{season}{year}_er.pdf`), so a missing variant on an
            # `er` document is expected, not a gap.
            dtype = verdict.identity.get("document_type")
            expected_absent = set()
            if dtype == "er":
                expected_absent.add("variant")
            secondary_missing = [n for n in SECONDARY
                                 if verdict.fields[n].status != "RESOLVED"
                                 and n not in expected_absent]
            if secondary_missing:
                verdict.status = "PARTIAL"
                verdict.reasons.append(
                    "identity accepted; secondary fields unresolved: "
                    + ", ".join(secondary_missing))
            else:
                verdict.status = "RESOLVED"

        if bundle.ocr_used:
            verdict.reasons.append("OCR contributed evidence (no usable text layer)")
        if bundle.ocr_status.startswith("OCR_UNAVAILABLE"):
            verdict.reasons.append(f"OCR unavailable: {bundle.ocr_status}")
        for note in bundle.collection_notes:
            verdict.reasons.append(f"note: {note}")
        return verdict

    # -- batch ---------------------------------------------------------------
    def resolve_dir(self, directory: str | Path,
                    patterns: tuple = ("*.pdf",)) -> List[IdentityVerdict]:
        d = Path(directory)
        out = []
        if not d.exists():
            return out
        files = sorted({p for pat in patterns for p in d.rglob(pat) if p.is_file()})
        for p in files:
            try:
                out.append(self.resolve(p))
            except Exception as exc:
                v = IdentityVerdict(path=p, status="REVIEW_REQUIRED")
                v.reasons.append(f"resolver error: {type(exc).__name__}: {exc}")
                out.append(v)
        return out
