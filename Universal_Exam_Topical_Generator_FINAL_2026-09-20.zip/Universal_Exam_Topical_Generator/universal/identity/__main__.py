"""CLI: report document identity for a file or directory.

    python -m universal.identity <path> [--json OUT] [--evidence] [--strict]

Exit code is non-zero when any document needs review under --strict, so this can
gate a batch run.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from universal.identity.resolver import IdentityResolver  # noqa: E402

_ORDER = {"RESOLVED": 0, "PARTIAL": 1, "REVIEW_REQUIRED": 2,
          "INSUFFICIENT_EVIDENCE": 3, "UNKNOWN": 4}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="universal.identity")
    ap.add_argument("path", help="PDF file or directory to inspect")
    ap.add_argument("--json", help="write the full report as JSON here")
    ap.add_argument("--evidence", action="store_true",
                    help="include per-field evidence snippets in JSON output")
    ap.add_argument("--strict", action="store_true",
                    help="exit 1 if any document is REVIEW_REQUIRED / INSUFFICIENT")
    args = ap.parse_args(argv)

    target = Path(args.path)
    resolver = IdentityResolver()
    verdicts = ([resolver.resolve(target)] if target.is_file()
                else resolver.resolve_dir(target))

    if not verdicts:
        print(f"[identity] no PDFs found under {target}")
        return 2

    verdicts.sort(key=lambda v: (-_ORDER.get(v.status, 9), str(v.path)))
    width = max(len(v.path.name) for v in verdicts)
    counts: dict = {}
    for v in verdicts:
        counts[v.status] = counts.get(v.status, 0) + 1
        ident = v.identity
        print(f"{v.path.name:<{width}}  {v.status:<22} "
              f"{str(ident.get('board') or '-'):8s} "
              f"{str(ident.get('syllabus_code') or '-'):8s} "
              f"{str(ident.get('year') or '-'):6s} "
              f"{str(ident.get('season') or '-'):3s} "
              f"{str(ident.get('document_type') or '-'):9s} "
              f"comp={str(ident.get('component') or '-'):4s} "
              f"conf={v.confidence:.2f}")
        for c in v.conflicts:
            print(f"    IDENTITY_CONFLICT {c['field']}: "
                  f"{c['accepted']['value']!r} ({','.join(c['accepted']['sources'])}) vs "
                  f"{c['rejected']['value']!r} "
                  f"({','.join(c['rejected'].get('exclusive_sources') or c['rejected']['sources'])})")
        if v.status in ("REVIEW_REQUIRED", "INSUFFICIENT_EVIDENCE"):
            for r in v.reasons[:3]:
                print(f"    - {r[:150]}")

    print(f"\n[identity] {len(verdicts)} document(s): "
          + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    review = counts.get("REVIEW_REQUIRED", 0) + counts.get("INSUFFICIENT_EVIDENCE", 0)
    if review:
        print(f"[identity] {review} need review — identity was NOT assumed")

    if args.json:
        out = Path(args.json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps({
            "schema_version": "1.0",
            "summary": counts,
            "documents": [v.to_dict(include_evidence=args.evidence) for v in verdicts],
        }, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[identity] wrote {out}")

    if args.strict and review:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
