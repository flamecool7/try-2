"""Universal document identity resolution.

Directive §7: identify what a document IS, not what its filename CLAIMS.
`evidence.py` collects per-field evidence from independent sources; `resolver.py`
fuses it into a verdict where any material disagreement becomes
IDENTITY_CONFLICT -> REVIEW_REQUIRED rather than a silent pick.
"""

from universal.identity.evidence import (  # noqa: F401
    FIELDS, Evidence, EvidenceBundle, EvidenceCollector)
from universal.identity.resolver import (  # noqa: F401
    MATERIAL, SECONDARY, FieldVerdict, IdentityResolver, IdentityVerdict)

__all__ = ["FIELDS", "Evidence", "EvidenceBundle", "EvidenceCollector",
           "MATERIAL", "SECONDARY", "FieldVerdict", "IdentityResolver",
           "IdentityVerdict"]
