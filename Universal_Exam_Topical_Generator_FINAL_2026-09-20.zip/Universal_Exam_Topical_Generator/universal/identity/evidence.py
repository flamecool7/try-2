"""Evidence collection for document identity resolution.

Directive §7: identify what a document **IS**, not what its filename **CLAIMS**.
The filename is deliberately the weakest signal (config `detection.weights.filename: 10`
vs `first_page_text: 30`). Milestone-1 evidence for that ordering: the existing
filename parser invented `year=2024` for a real 2026 paper once the filename evidence
was removed.

Every collector returns `Evidence` records that name their source and quote the raw
snippet they were derived from. A collector that cannot find something returns nothing
— it never returns a default. Defaults are how silent fabrication happens.

OCR is a fallback, not a first resort: it runs only when the trigger condition in
`config.yaml` (`ocr.trigger`) is met, and renders are capped at `ocr.max_side_px`
because a 6287×4445 render OOM-killed the process during Milestone 1 (exit 137).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from universal.config import load_config

# Material identity fields. Each is resolved independently, because a document can
# have a trustworthy syllabus code and an untrustworthy year at the same time.
FIELDS = ("board", "syllabus_code", "year", "season", "document_type",
          "component", "variant", "subject")


@dataclass
class Evidence:
    """One observed fact about one identity field, from one source."""

    field: str
    value: Any
    source: str                       # key into config detection.weights
    weight: float = 0.0
    snippet: str = ""                 # raw text the value was read from
    page: Optional[int] = None
    note: str = ""

    @property
    def norm_value(self) -> str:
        """Comparable form. Values are compared as strings so that `2026` from a
        filename and `"2026"` from a cover page are recognisably the same fact."""
        return str(self.value).strip().lower()

    def to_dict(self) -> Dict[str, Any]:
        return {"field": self.field, "value": self.value, "source": self.source,
                "weight": self.weight, "snippet": self.snippet[:200],
                "page": self.page, "note": self.note}


@dataclass
class EvidenceBundle:
    """All evidence gathered for one document."""

    path: Path
    evidence: List[Evidence] = field(default_factory=list)
    text_pages: List[str] = field(default_factory=list)
    text_layer_chars: int = 0
    ocr_used: bool = False
    ocr_status: str = "not_required"   # not_required | ok | OCR_UNAVAILABLE | disabled
    collection_notes: List[str] = field(default_factory=list)

    def add(self, ev: Optional[Evidence]) -> None:
        if ev is not None:
            self.evidence.append(ev)

    def extend(self, evs: List[Evidence]) -> None:
        self.evidence.extend(evs)

    def for_field(self, name: str) -> List[Evidence]:
        return [e for e in self.evidence if e.field == name]

    def to_dict(self) -> Dict[str, Any]:
        return {"path": str(self.path), "text_layer_chars": self.text_layer_chars,
                "ocr_used": self.ocr_used, "ocr_status": self.ocr_status,
                "collection_notes": self.collection_notes,
                "evidence": [e.to_dict() for e in self.evidence]}


# --------------------------------------------------------------------------- #
# Board signatures — printed by the board on its own papers. This is how the
# system knows WHICH board's component-code semantics apply, which matters
# because §17 forbids assuming P1-P6 mean the same thing across boards.
# --------------------------------------------------------------------------- #
BOARD_SIGNATURES: Dict[str, Tuple[str, ...]] = {
    "CAIE": ("cambridge international", "university of cambridge international",
             "cambridge igcse", "international general certificate",
             "cambridge international as", "cambridge international a level",
             "c|e|se? cambridge", "internationa"),   # last: deliberate typo tolerance
    "AQA": ("aqa", "assessment and qualifications alliance"),
    "EDEXCEL": ("pearson edexcel", "edexcel", "pearson education limited"),
    "IB": ("international baccalaureate", "ib diploma programme",
           "m17/4/", "m18/4/", "m19/4/", "m20/4/", "m21/4/", "m22/4/",
           "m23/4/", "m24/4/", "m25/4/", "m26/4/"),
    "SAT": ("college board", "digital sat", "sat suite", "satsuite"),
    "OCR": ("ocr oxford cambridge", "oxford cambridge and rsa", "ocr 2026",
            "ocr gce", "ocr gcse"),
}

# IB paper codes look like M26/4/CHEMI/HP1/ENG — a strong board signal on their own.
_IB_CODE = re.compile(r"\b([MNX])(\d{2})/(\d{1,2})/([A-Z]{2,5}[A-Z0-9]*)/")
# CAIE cover pages print e.g. "9701/22" and "May/June 2026"
_CAIE_COMPONENT = re.compile(r"\b(\d{4})/(\d{1,2})\b")
_CAIE_SESSION = re.compile(
    r"\b(may/june|june|may|february|march|october|november|february/march|"
    r"october/november|september)\s+(19|20)(\d{2})\b", re.I)
# AQA prints "AQA-8462/1-SP-2016" style references and "GCSE CHEMISTRY"
_AQA_CODE = re.compile(r"\bAQA[- ]?(\d{4})\b", re.I)
# Edexcel IGCSE prints paper codes like "4CH1/1C"
_EDEXCEL_PAPER = re.compile(r"\b(\d[A-Z0-9]{3})/(\d{1,2}[A-Z]?)\b")
_YEAR4 = re.compile(r"\b(19\d{2}|20\d{2})\b")

_SEASON_BY_WORD = {
    "february": "m", "march": "m", "february/march": "m",
    "may": "s", "june": "s", "july": "s", "august": "s", "september": "s",
    "may/june": "s",
    "october": "w", "november": "w", "october/november": "w", "december": "w",
}


class EvidenceCollector:
    """Gathers identity evidence from one document."""

    def __init__(self, config=None):
        self.cfg = config or load_config()
        self.weights: Dict[str, float] = dict(self.cfg.get("detection.weights", {}) or {})
        self.ocr_cfg: Dict[str, Any] = dict(self.cfg.get("ocr", {}) or {})
        self.year_min = int(self.cfg.get("detection.year.min", 1900))
        self.year_max = int(self.cfg.get("detection.year.max", 9999))

    def w(self, source: str) -> float:
        return float(self.weights.get(source, 0.0))

    # -- text layer ----------------------------------------------------------
    def read_text(self, path: Path, max_pages: int = 6) -> Tuple[List[str], int]:
        """First `max_pages` pages of the text layer. Returns ([], 0) on failure."""
        try:
            import pymupdf as fitz          # modern name; `fitz` alias is deprecated
        except ImportError:
            try:
                import fitz
            except ImportError:
                return [], 0
        try:
            doc = fitz.open(str(path))
        except Exception:
            return [], 0
        pages = []
        try:
            for i in range(min(len(doc), max_pages)):
                try:
                    pages.append(doc[i].get_text("text") or "")
                except Exception:
                    pages.append("")
        finally:
            doc.close()
        return pages, sum(len(p) for p in pages)

    def read_metadata(self, path: Path) -> Dict[str, Any]:
        try:
            import pymupdf as fitz
        except ImportError:
            try:
                import fitz
            except ImportError:
                return {}
        try:
            doc = fitz.open(str(path))
            md = dict(doc.metadata or {})
            doc.close()
            return md
        except Exception:
            return {}

    # -- OCR fallback --------------------------------------------------------
    def maybe_ocr(self, path: Path, bundle: EvidenceBundle) -> Optional[str]:
        """Run OCR only if the configured trigger condition is met.

        Returns OCR text, or None. Never raises: an unavailable OCR backend is a
        recorded status (`OCR_UNAVAILABLE`), not a fatal error.
        """
        if not self.ocr_cfg.get("enabled", True):
            bundle.ocr_status = "disabled"
            return None
        trigger = str(self.ocr_cfg.get("trigger", "no_text_layer"))
        density = float(self.ocr_cfg.get("text_density_threshold", 20))
        n_pages = max(1, len(bundle.text_pages))
        chars_per_page = bundle.text_layer_chars / n_pages

        needed = False
        if trigger == "always":
            needed = True
        elif trigger == "never":
            needed = False
        elif trigger == "no_text_layer":
            needed = bundle.text_layer_chars == 0
        elif trigger == "low_text_density":
            needed = chars_per_page < density
        if not needed:
            bundle.ocr_status = "not_required"
            return None

        try:
            text = self._run_ocr(path)
        except Exception as exc:
            bundle.ocr_status = f"OCR_UNAVAILABLE ({type(exc).__name__})"
            bundle.collection_notes.append(f"OCR failed: {type(exc).__name__}: {exc}")
            return None
        if text is None:
            bundle.ocr_status = str(self.ocr_cfg.get("unavailable_status",
                                                     "OCR_UNAVAILABLE"))
            return None
        bundle.ocr_used = True
        bundle.ocr_status = "ok"
        return text

    def _run_ocr(self, path: Path, max_pages: int = 3) -> Optional[str]:
        """Render + OCR with the hard size cap that prevents the Milestone-1 OOM."""
        try:
            from rapidocr_onnxruntime import RapidOCR
        except ImportError:
            return None
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        try:
            from PIL import Image
        except ImportError:
            Image = None

        cap = int(self.ocr_cfg.get("max_side_px", 2400))
        engine = RapidOCR()
        out: List[str] = []
        doc = fitz.open(str(path))
        try:
            for i in range(min(len(doc), max_pages)):
                page = doc[i]
                rect = page.rect
                longest = max(rect.width, rect.height) or 1.0
                # target ~150 dpi, then clamp so the longest side never exceeds cap
                zoom = min(150.0 / 72.0, cap / longest)
                zoom = max(0.2, min(zoom, cap / longest))
                pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
                img_bytes = pix.tobytes("png")
                if Image is not None:
                    import io
                    im = Image.open(io.BytesIO(img_bytes))
                    if max(im.size) > cap:
                        im = im.resize((max(1, int(im.width * cap / max(im.size))),
                                        max(1, int(im.height * cap / max(im.size)))),
                                       Image.LANCZOS)
                        import io as _io
                        buf = _io.BytesIO()
                        im.save(buf, format="PNG")
                        img_bytes = buf.getvalue()
                res, _ = engine(img_bytes)
                if res:
                    for row in res:
                        try:
                            out.append(str(row[1]))
                        except Exception:
                            continue
        finally:
            doc.close()
        return "\n".join(out) if out else ""

    # -- collectors ----------------------------------------------------------
    def from_filename(self, path: Path, bundle: EvidenceBundle) -> None:
        """Reuse the existing parser — do NOT build a second filename engine.

        `core.paper_identifier.parse_paper_filename` is the canonical filename
        reader and is already correct for well-formed Cambridge names. Its output
        is admitted here as *filename* evidence (weight 10), not as truth.
        """
        try:
            from core.paper_identifier import parse_paper_filename
        except Exception as exc:
            bundle.collection_notes.append(f"filename parser unavailable: {exc}")
            return
        try:
            info = parse_paper_filename(path)
        except Exception as exc:
            bundle.collection_notes.append(f"filename parse error: {type(exc).__name__}: {exc}")
            return
        if info is None:
            bundle.collection_notes.append("filename parser returned None (no recognised pattern)")
            return
        w = self.w("filename")
        stem = path.stem
        for fld, val in (("syllabus_code", info.syllabus_code),
                         ("year", info.year),
                         ("season", info.season_letter),
                         ("document_type", info.paper_type),
                         ("variant", info.variant),
                         ("subject", info.subject_guess)):
            if val in (None, ""):
                continue
            bundle.add(Evidence(field=fld, value=val, source="filename", weight=w,
                                snippet=stem,
                                note="claimed by filename; weakest signal"))
        # A PaperInfo that itself reports REVIEW_REQUIRED must propagate.
        status = getattr(info, "identity_status", None)
        if status and status != "FILENAME_RESOLVED":
            bundle.collection_notes.append(
                f"parser reported identity_status={status}; "
                f"fabricated={getattr(info, 'fabricated_fields', [])}")

    def from_pdf_metadata(self, path: Path, bundle: EvidenceBundle) -> None:
        md = self.read_metadata(path)
        if not md:
            return
        w = self.w("pdf_metadata")
        blob = " ".join(str(v) for v in md.values() if v)
        for m in _YEAR4.finditer(blob):
            y = int(m.group(1))
            if self.year_min <= y <= self.year_max:
                bundle.add(Evidence(field="year", value=y, source="pdf_metadata",
                                    weight=w, snippet=blob[:120],
                                    note="from XMP/DocInfo"))
                break
        low = blob.lower()
        for board, sigs in BOARD_SIGNATURES.items():
            if any(s in low for s in sigs):
                bundle.add(Evidence(field="board", value=board, source="pdf_metadata",
                                    weight=w, snippet=blob[:120]))
                break

    def from_text(self, path: Path, bundle: EvidenceBundle,
                  ocr_text: Optional[str] = None) -> None:
        pages = list(bundle.text_pages)
        if ocr_text:
            pages = pages + [ocr_text]
        if not pages:
            return
        first = pages[0] or ""
        full = "\n".join(pages)
        low_first, low_full = first.lower(), full.lower()

        # --- board signature -------------------------------------------------
        wb = self.w("board_signature")
        hits: Dict[str, int] = {}
        for board, sigs in BOARD_SIGNATURES.items():
            n = sum(low_first.count(s) for s in sigs if len(s) > 3)
            if n:
                hits[board] = n
        if hits:
            best = max(hits, key=lambda k: hits[k])
            sig = next(s for s in BOARD_SIGNATURES[best] if s in low_first)
            i = low_first.index(sig)
            bundle.add(Evidence(field="board", value=best, source="board_signature",
                                weight=wb,
                                snippet=first[max(0, i - 40):i + 60].replace("\n", " "),
                                page=1, note=f"signature counts {hits}"))

        # --- year ------------------------------------------------------------
        wy = self.w("first_page_text")
        sess = _CAIE_SESSION.search(first)
        if sess:
            y = int(sess.group(2) + sess.group(3))
            if self.year_min <= y <= self.year_max:
                bundle.add(Evidence(field="year", value=y, source="first_page_text",
                                    weight=wy, snippet=sess.group(0), page=1,
                                    note="explicit session string"))
                bundle.add(Evidence(
                    field="season", value=_SEASON_BY_WORD.get(sess.group(1).lower(), ""),
                    source="first_page_text", weight=wy, snippet=sess.group(0),
                    page=1, note="explicit session string"))
        else:
            # No session string: collect every plausible 4-digit year on page 1.
            # Multiple different years is itself evidence of ambiguity, so all of
            # them are recorded and the resolver decides.
            seen = []
            for m in _YEAR4.finditer(first):
                y = int(m.group(1))
                if self.year_min <= y <= self.year_max and y not in seen:
                    seen.append(y)
            for y in seen[:4]:
                i = first.index(str(y))
                bundle.add(Evidence(field="year", value=y, source="first_page_text",
                                    weight=wy * (1.0 if y == seen[0] else 0.6),
                                    snippet=first[max(0, i - 40):i + 20].replace("\n", " "),
                                    page=1,
                                    note=f"bare year on cover ({len(seen)} distinct found)"))

        # --- syllabus / component codes, per board ---------------------------
        wq = self.w("qualification_code")
        wc = self.w("component_code")

        m = _IB_CODE.search(first) or _IB_CODE.search(full)
        if m:
            bundle.add(Evidence(field="board", value="IB", source="board_signature",
                                weight=wb, snippet=m.group(0),
                                note="IB paper code shape M##/#/SUBJ/"))
            bundle.add(Evidence(field="season",
                                value={"M": "s", "N": "w", "X": "x"}.get(m.group(1), ""),
                                source="qualification_code", weight=wq,
                                snippet=m.group(0), note="IB session letter"))
            bundle.add(Evidence(field="year", value=int("20" + m.group(2)),
                                source="qualification_code", weight=wq,
                                snippet=m.group(0), note="IB session year"))
            bundle.add(Evidence(field="component", value=m.group(3),
                                source="component_code", weight=wc,
                                snippet=m.group(0),
                                note="IB paper number — NOT comparable to CAIE variants"))

        for m in _CAIE_COMPONENT.finditer(first):
            code, comp = m.group(1), m.group(2)
            if 1 <= len(code) == 4 and code.isdigit():
                bundle.add(Evidence(field="syllabus_code", value=code,
                                    source="qualification_code", weight=wq,
                                    snippet=m.group(0), page=1,
                                    note="CAIE <code>/<component> on cover"))
                bundle.add(Evidence(field="component", value=comp,
                                    source="component_code", weight=wc,
                                    snippet=m.group(0), page=1,
                                    note="CAIE component; second digit is variant"))
            break

        m = _AQA_CODE.search(first) or _AQA_CODE.search(full)
        if m:
            bundle.add(Evidence(field="syllabus_code", value=m.group(1),
                                source="qualification_code", weight=wq,
                                snippet=m.group(0), note="AQA specification code"))
            m2 = re.search(r"\bAQA[- ]?\d{4}[-/](\w+)[- ]SP[- ](19|20)(\d{2})", full, re.I)
            if m2:
                bundle.add(Evidence(field="year", value=int(m2.group(2) + m2.group(3)),
                                    source="qualification_code", weight=wq,
                                    snippet=m2.group(0), note="AQA spec year"))

        for m in _EDEXCEL_PAPER.finditer(first):
            bundle.add(Evidence(field="syllabus_code", value=m.group(1),
                                source="qualification_code", weight=wq,
                                snippet=m.group(0), note="Pearson qualification code"))
            bundle.add(Evidence(field="component", value=m.group(2),
                                source="component_code", weight=wc,
                                snippet=m.group(0),
                                note="Edexcel paper/tier code; a trailing letter is a "
                                     "tier marker (e.g. 1C, 2P), NOT a CAIE variant"))
            break

        # --- document type ---------------------------------------------------
        wt = self.w("header_footer")
        dtype = None
        if re.search(r"\bmark scheme\b|\bmarkscheme\b", low_first):
            dtype = "ms"
        elif re.search(r"\bexaminer report\b|\bexaminers? report\b", low_first):
            dtype = "er"
        elif re.search(r"\binsert\b|\binserted material\b", low_first) and \
                re.search(r"\bquestion paper\b", low_first) is None:
            dtype = "insert"
        elif re.search(r"\bquestion paper\b|\bfinal paper\b|\bpaper \d\b", low_first):
            dtype = "qp"
        if re.search(r"\bspecimen\b", low_first):
            bundle.add(Evidence(field="document_type", value="specimen",
                                source="header_footer", weight=wt,
                                snippet="specimen", page=1,
                                note="specimen paper — not a dated session"))
        elif dtype:
            bundle.add(Evidence(field="document_type", value=dtype,
                                source="header_footer", weight=wt,
                                snippet=first[:160].replace("\n", " "), page=1))

        # --- question-structure signal (is this really a QP?) ----------------
        wq2 = self.w("question_structure")
        qnums = re.findall(r"(?m)^\s*(\d{1,2})\s*[\.\)]\s", full[:20000])
        if qnums:
            uniq = sorted({int(n) for n in qnums if 1 <= int(n) <= 60})
            if len(uniq) >= 2:
                bundle.add(Evidence(field="document_type", value="qp",
                                    source="question_structure", weight=wq2,
                                    snippet=f"numbered anchors {uniq[:12]}",
                                    note=f"{len(uniq)} distinct question numbers"))
        # Mark-scheme structure. Deliberately STRICT.
        #
        # Two heuristics that look reasonable are actively wrong here, and both
        # were verified against the real staged papers:
        #   * "total ... mark" appears on QUESTION PAPER covers too ("The total
        #     mark for this paper is 60"), so it cannot separate MS from QP. It
        #     produced a false IDENTITY_CONFLICT on 9701_m26_qp_22 and
        #     9231_w25_qp_11.
        #   * a single "(a)"-style row appears in ordinary question sub-parts.
        # So: require several mark-grid rows AND no explicit question-paper header.
        wms = self.w("mark_scheme_structure")
        grid_rows = re.findall(r"(?m)^\s*(\d{1,2})\s*\(\s?([a-f])\s?\)\s*[;=]?\s*$",
                               full[:30000])
        explicit_qp_header = bool(re.search(r"\bquestion paper\b", low_first))
        distinct_rows = {(int(n), l) for n, l in grid_rows}
        if len(distinct_rows) >= 4 and not explicit_qp_header:
            bundle.add(Evidence(field="document_type", value="ms",
                                source="mark_scheme_structure", weight=wms,
                                snippet=f"mark-grid rows {sorted(distinct_rows)[:6]}",
                                note=f"{len(distinct_rows)} distinct mark-grid rows and "
                                     "no 'Question Paper' header on page 1"))

    # -- orchestration -------------------------------------------------------
    def collect(self, path: Path) -> EvidenceBundle:
        path = Path(path)
        bundle = EvidenceBundle(path=path)
        if not path.exists():
            bundle.collection_notes.append("FILE_NOT_FOUND")
            return bundle

        self.from_filename(path, bundle)
        self.from_pdf_metadata(path, bundle)
        bundle.text_pages, bundle.text_layer_chars = self.read_text(path)
        if bundle.text_layer_chars == 0 and path.suffix.lower() == ".pdf":
            bundle.collection_notes.append("no text layer — OCR trigger eligible")

        ocr_text = self.maybe_ocr(path, bundle)
        self.from_text(path, bundle, ocr_text=ocr_text)
        if ocr_text:
            # OCR-derived facts are recorded at the OCR weight, separately from the
            # text layer, so a conflict between them stays visible.
            w = self.w("ocr")
            for m in _YEAR4.finditer(ocr_text[:4000]):
                y = int(m.group(1))
                if self.year_min <= y <= self.year_max:
                    bundle.add(Evidence(field="year", value=y, source="ocr",
                                        weight=w, snippet=m.group(0),
                                        note="OCR-derived"))
                    break
            low = ocr_text.lower()
            for board, sigs in BOARD_SIGNATURES.items():
                if any(s in low for s in sigs):
                    bundle.add(Evidence(field="board", value=board, source="ocr",
                                        weight=w, snippet="ocr board signature",
                                        note="OCR-derived"))
                    break
        return bundle
