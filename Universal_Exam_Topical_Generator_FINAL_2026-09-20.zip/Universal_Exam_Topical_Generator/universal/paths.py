"""universal.paths — re-export of project-root path helpers (see universal.config)."""
from universal.config import PROJECT_ROOT, resolve, ensure_dirs

__all__ = ["PROJECT_ROOT", "resolve", "ensure_dirs"]
