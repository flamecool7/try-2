"""universal.taxonomy — data-driven topic registry, builder and version intelligence."""
from universal.taxonomy.registry import (TopicNode, Taxonomy, TopicRegistry,
                                         default_registry, SCHEMA_VERSION)
__all__ = ["TopicNode", "Taxonomy", "TopicRegistry", "default_registry", "SCHEMA_VERSION"]
