"""Version intelligence + cross-board concept identity.

Two jobs the master prompt requires and that no existing module does:

1. **Version awareness (§6, §27)** — retain syllabus/version information with every
   artefact and resolve "which syllabus version applies to year Y" without
   hardcoded year limits. Versions are read from the built taxonomies (which were
   built from official sources), never invented.
2. **Cross-board concept identity (§31)** — map genuinely shared concepts between
   boards (e.g. "Bonding, structure and properties") while explicitly NOT merging
   same-name-different-meaning nodes. The default is "no link", because a wrong
   link is worse than a missing one.

Nothing here writes to the gold core or changes naming/cropping behaviour.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from universal.taxonomy.registry import PROJECT_ROOT, Taxonomy, TopicNode, TopicRegistry


# --------------------------------------------------------------------------- #
# 1. Version intelligence
# --------------------------------------------------------------------------- #
_YEAR_TOKEN = re.compile(r"\b(19|20)(\d{2})\b")


@dataclass
class VersionWindow:
    """A syllabus version and the years it plausibly covers.

    `known` distinguishes "extracted from the source document" from "inferred".
    An inferred window is never presented as fact (§36).
    """

    syllabus_version: str
    years: List[int] = field(default_factory=list)
    explicit_first_year: Optional[int] = None
    explicit_last_year: Optional[int] = None
    basis: str = "unknown"
    evidence: Dict[str, Any] = field(default_factory=dict)
    # True when `years` is a DISCRETE published list ("these exact years use this
    # version") rather than a contiguous span. A discrete list must never be
    # interpolated: a year absent from it is simply not covered, and inferring
    # coverage from min(years) would silently mis-version historical papers.
    discrete: bool = False
    historical_year_policy: Optional[str] = None

    @property
    def known(self) -> bool:
        return self.basis in ("explicit_in_source", "config_syllabus_years")

    @property
    def start_year_only(self) -> bool:
        """Start year is source-declared but the end year is not."""
        return self.basis == "first_assessment_in_source"

    def covers(self, year: Optional[int]) -> Optional[bool]:
        if year is None or not self.years:
            return None
        return year in self.years

    def to_dict(self) -> Dict[str, Any]:
        return {
            "syllabus_version": self.syllabus_version,
            "years": self.years,
            "year_span": [min(self.years), max(self.years)] if self.years else None,
            "basis": self.basis,
            "known": self.known,
            "discrete_year_list": self.discrete,
            "historical_year_policy": self.historical_year_policy,
            "evidence": self.evidence,
        }


@dataclass
class VersionResolution:
    """Result of resolving a year against a syllabus's versions."""

    syllabus: str
    requested_year: Optional[int]
    resolved_version: Optional[str] = None
    status: str = "UNKNOWN"   # RESOLVED | AMBIGUOUS | REVIEW_REQUIRED | UNKNOWN
    candidates: List[VersionWindow] = field(default_factory=list)
    reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "syllabus": self.syllabus,
            "requested_year": self.requested_year,
            "resolved_version": self.resolved_version,
            "status": self.status,
            "reason": self.reason,
            "candidates": [c.to_dict() for c in self.candidates],
        }


class VersionIntelligence:
    """Resolves year -> syllabus version from evidence that already exists."""

    def __init__(self, registry: Optional[TopicRegistry] = None):
        self._registry = registry or TopicRegistry()
        self._cache: Dict[str, Dict[str, VersionWindow]] = {}

    @property
    def registry(self) -> TopicRegistry:
        if not self._registry._loaded:
            self._registry.load()
        return self._registry

    # -- window construction -------------------------------------------------
    def windows_for(self, syllabus: str) -> Dict[str, VersionWindow]:
        if syllabus in self._cache:
            return self._cache[syllabus]

        windows: Dict[str, VersionWindow] = {}
        taxonomies = self.registry.search(syllabus=syllabus)

        # (a) legacy CAIE config.json declares explicit syllabus_years
        for t in taxonomies:
            cfg = self._as_dict(t.provenance.get("config"))
            years = self._coerce_years(cfg.get("syllabus_years"))
            ver = str(cfg.get("version") or t.syllabus_version or "unversioned")
            if years:
                # Contiguous (e.g. 2023,2024,2025) => a span. Gapped (e.g. CAIE
                # 9701: 2015,2024,2025,2026,2027) => a discrete published list.
                contiguous = years == list(range(min(years), max(years) + 1))
                windows[ver] = VersionWindow(
                    syllabus_version=ver, years=years,
                    explicit_first_year=min(years), explicit_last_year=max(years),
                    basis="config_syllabus_years", discrete=not contiguous,
                    historical_year_policy=(
                        str(cfg.get("historical_year_policy"))
                        if cfg.get("historical_year_policy") else None),
                    evidence={"source": (t.provenance.get("source")
                                         or t.provenance.get("config") or t.path),
                              "field": "syllabus_years",
                              "raw": cfg.get("syllabus_years")})

        # (b) version strings that carry their own year span, e.g. "2023-2025"
        for t in taxonomies:
            ver = t.syllabus_version
            if not ver or ver in windows:
                continue
            yrs = re.findall(r"(19\d{2}|20\d{2})", ver)
            if len(yrs) >= 2:
                lo, hi = int(min(yrs)), int(max(yrs))
                windows[ver] = VersionWindow(
                    syllabus_version=ver, years=list(range(lo, hi + 1)),
                    explicit_first_year=lo, explicit_last_year=hi,
                    basis="explicit_in_source",
                    evidence={"version_string": ver,
                              "source": t.provenance.get("source")})
            elif len(yrs) == 1:
                windows[ver] = VersionWindow(
                    syllabus_version=ver, years=[int(yrs[0])],
                    explicit_first_year=int(yrs[0]),
                    basis="explicit_in_source",
                    evidence={"version_string": ver,
                              "source": t.provenance.get("source")})

        # (c) first-assessment / issue metadata from board PDFs (Edexcel, AQA)
        for t in taxonomies:
            ver = t.syllabus_version
            facts = t.provenance.get("paper_facts") or {}
            fa = str(facts.get("first_assessment") or "")
            m = re.search(r"(19\d{2}|20\d{2})", fa)
            yrs = [int(m.group(1))] if m else []
            if ver and yrs and ver not in windows:
                windows[ver] = VersionWindow(
                    syllabus_version=ver, years=[], explicit_first_year=yrs[0],
                    basis="first_assessment_in_source",
                    evidence={"first_assessment": fa,
                              "source": t.provenance.get("source"),
                              "note": "start year known; end year not stated in source"})

        self._cache[syllabus] = windows
        return windows

    @staticmethod
    def _as_dict(cfg: Any) -> Dict[str, Any]:
        """provenance['config'] may be a path string or an inline dict."""
        if isinstance(cfg, dict):
            return cfg
        if isinstance(cfg, str) and cfg:
            p = Path(cfg)
            if not p.is_absolute():
                p = PROJECT_ROOT / cfg
            if p.exists():
                try:
                    d = json.loads(p.read_text(encoding="utf-8"))
                    return d if isinstance(d, dict) else {}
                except Exception:
                    return {}
        return {}

    @staticmethod
    def _coerce_years(raw: Any) -> List[int]:
        out: List[int] = []
        if isinstance(raw, (list, tuple)):
            for item in raw:
                m = re.search(r"(19\d{2}|20\d{2})", str(item))
                if m:
                    out.append(int(m.group(1)))
                elif isinstance(item, int) and 1900 <= item <= 9999:
                    out.append(item)
        elif raw:
            for m in re.finditer(r"(19\d{2}|20\d{2})", str(raw)):
                out.append(int(m.group(1)))
        # de-duplicate, keep order
        seen: set = set()
        return [y for y in out if not (y in seen or seen.add(y))]

    # -- resolution ----------------------------------------------------------
    def resolve(self, syllabus: str, year: Optional[int]) -> VersionResolution:
        windows = self.windows_for(syllabus)
        res = VersionResolution(syllabus=syllabus, requested_year=year,
                                candidates=list(windows.values()))
        if not windows:
            res.status, res.reason = "UNKNOWN", "no version metadata in built taxonomies"
            return res
        if year is None:
            if len(windows) == 1:
                res.resolved_version = next(iter(windows))
                res.status, res.reason = "RESOLVED", "single version recorded for syllabus"
            else:
                res.status = "AMBIGUOUS"
                res.reason = f"{len(windows)} versions recorded; no year supplied"
            return res

        exact = [v for v, w in windows.items() if w.covers(year) is True]
        if len(exact) == 1:
            res.resolved_version, res.status = exact[0], "RESOLVED"
            res.reason = "year inside an explicitly declared version span"
            return res
        if len(exact) > 1:
            res.status = "AMBIGUOUS"
            res.reason = (f"year {year} claimed by {len(exact)} versions: {exact}; "
                          "REVIEW_REQUIRED — never guess")
            return res

        # No exact membership. Only a window whose START year is source-declared
        # and whose END year is genuinely unstated may be inferred forward.
        # Windows with declared spans or discrete published lists are NOT eligible:
        # a year absent from a declared list is not covered by it.
        starts = sorted(
            [(w.explicit_first_year, v) for v, w in windows.items()
             if w.start_year_only and w.explicit_first_year
             and w.explicit_first_year <= year],
            reverse=True)
        if len(starts) == 1:
            res.resolved_version, res.status = starts[0][1], "RESOLVED"
            res.reason = ("inferred from source-declared first-assessment year; end "
                          "year not stated in source (basis=first_assessment_in_source)")
            return res
        if len(starts) > 1:
            res.status = "REVIEW_REQUIRED"
            res.reason = (f"year {year} is after the first assessment of {len(starts)} "
                          f"versions ({[v for _, v in starts]}); cannot disambiguate "
                          "without a source-declared end year")
            return res

        # Declared lists/spans exist but do not cover this year. If the source
        # itself sets a historical-year policy, honour it verbatim.
        policies = {w.historical_year_policy for w in windows.values()
                    if w.historical_year_policy}
        if policies:
            res.status = "REVIEW_REQUIRED"
            res.reason = (f"year {year} is not in any declared syllabus_years list "
                          f"{sorted({y for w in windows.values() for y in w.years})}; "
                          f"source policy = {sorted(policies)}")
            return res

        res.status = "UNKNOWN"
        res.reason = (f"year {year} is outside every declared version span and no "
                      "source-declared start year applies")
        return res

    def summary(self) -> Dict[str, Any]:
        rows = []
        # NOTE: the registry key is (board, qualification, syllabus, version,
        # subject) — key[1] is the QUALIFICATION, not the syllabus. Use the
        # taxonomy's own fields so rows are not collapsed.
        for tax in self.registry.all():
            w = self.windows_for(tax.syllabus)
            rows.append({
                "board": tax.board, "qualification": tax.qualification,
                "syllabus": tax.syllabus, "syllabus_version": tax.syllabus_version,
                "subject": tax.subject,
                "versions": {v: win.basis for v, win in w.items()},
                "explicit_spans": {v: [min(win.years), max(win.years)]
                                   for v, win in w.items() if win.years},
            })
        return {"syllabuses": len(rows), "rows": rows}


# --------------------------------------------------------------------------- #
# 2. Cross-board concept identity
# --------------------------------------------------------------------------- #
# Deliberately conservative: a concept link is emitted only when BOTH sides carry
# an explicit, source-derived marker for the same concept id. Two nodes that
# merely share a title are NOT linked (§31: never merge similar names;
# §17: P1-P6/component codes do not mean the same thing across boards).
@dataclass
class ConceptLink:
    concept_id: str
    label: str
    members: List[Dict[str, str]] = field(default_factory=list)
    basis: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"concept_id": self.concept_id, "label": self.label,
                "basis": self.basis, "members": self.members}


class CrossBoardConcepts:
    """Builds `taxonomies/concepts.json` from taxonomy metadata only.

    Links come from three conservative sources:
      * `node.concept_ids` — explicit concept ids recorded while building.
      * `markers` — board-printed qualifiers such as AQA's "chemistry only",
        which identify a sub-topic's discipline rather than a shared concept.
      * outcome-id namespaces (Edexcel `1.5C`, AQA `4.2.1.3`) — used ONLY as
        node identity inside a board, never as a cross-board link.
    If nothing qualifies, the file records zero links instead of guessing.
    """

    def __init__(self, registry: Optional[TopicRegistry] = None):
        self._registry = registry or TopicRegistry()

    @property
    def registry(self) -> TopicRegistry:
        if not self._registry._loaded:
            self._registry.load()
        return self._registry

    def build(self) -> Dict[str, Any]:
        buckets: Dict[str, List[Dict[str, str]]] = {}
        scanned = 0

        def visit(node: TopicNode, tax: Taxonomy) -> None:
            nonlocal scanned
            scanned += 1
            for cid in (node.concept_ids or []):
                buckets.setdefault(cid, []).append({
                    "board": tax.board, "syllabus": tax.syllabus,
                    "qualification": tax.qualification, "subject": tax.subject,
                    "syllabus_version": tax.syllabus_version,
                    "node": node.canonical_name, "display_name": node.display_name,
                    "level": node.level})
            for child in node.children:
                visit(child, tax)

        for tax in self.registry.all():
            for topic in tax.topics:
                visit(topic, tax)

        links = [ConceptLink(concept_id=cid, label=cid, members=members,
                             basis="explicit node.concept_ids recorded at build time")
                 for cid, members in sorted(buckets.items())
                 if len({m["board"] for m in members}) >= 2]

        single_board = {cid: members for cid, members in buckets.items()
                        if len({m["board"] for m in members}) < 2}

        return {
            "schema_version": "1.0",
            "policy": ("Cross-board links are emitted only when two or more boards "
                       "carry the SAME explicit concept id. Title similarity alone is "
                       "never a link (§31 never merge similar names). Absence of a "
                       "link means NOT_LINKED_YET, not 'unrelated'."),
            "nodes_scanned": scanned,
            "cross_board_concepts": [l.to_dict() for l in links],
            "single_board_concepts": len(single_board),
            "status": "LINKS_BUILT" if links else "NO_LINKS_YET",
            "next_step": ("Populate node.concept_ids during adapter implementation "
                          "(Milestone 4) from board-published mappings; re-run to grow "
                          "the map. Do not hand-write links from memory."),
        }


def write_outputs(out_dir: Optional[Path] = None) -> Dict[str, Any]:
    out = Path(out_dir) if out_dir else PROJECT_ROOT / "taxonomies"
    out.mkdir(parents=True, exist_ok=True)

    vi = VersionIntelligence()
    reg = vi.registry
    summary = vi.summary()

    versions = {}
    for row in summary["rows"]:
        bucket = versions.setdefault(row["board"], {}).setdefault(
            row["syllabus"], {"subject": row["subject"],
                              "qualifications": [], "versions": {},
                              "explicit_spans": {}})
        bucket["qualifications"].append(row.get("qualification"))
        bucket["versions"].update(row["versions"])
        bucket["explicit_spans"].update(row["explicit_spans"])

    (out / "versions.json").write_text(
        json.dumps({"schema_version": "1.0",
                    "note": "Year->version resolution evidence. 'basis' says whether "
                            "a span is declared by the source or inferred. Inferred "
                            "spans are never treated as fact.",
                    "syllabuses": summary["syllabuses"],
                    "by_board": versions}, indent=2, ensure_ascii=False),
        encoding="utf-8")

    concepts = CrossBoardConcepts(registry=reg).build()
    (out / "concepts.json").write_text(
        json.dumps(concepts, indent=2, ensure_ascii=False), encoding="utf-8")

    return {"versions": versions, "concepts": concepts,
            "nodes_scanned": concepts["nodes_scanned"]}


if __name__ == "__main__":
    r = write_outputs()
    n_syll = sum(len(v) for v in r["versions"].values())
    print(f"[version-intel] wrote taxonomies/versions.json "
          f"({n_syll} syllabuses across {len(r['versions'])} boards)")
    print(f"[version-intel] wrote taxonomies/concepts.json "
          f"nodes_scanned={r['nodes_scanned']} "
          f"cross_board={len(r['concepts']['cross_board_concepts'])} "
          f"status={r['concepts']['status']}")
