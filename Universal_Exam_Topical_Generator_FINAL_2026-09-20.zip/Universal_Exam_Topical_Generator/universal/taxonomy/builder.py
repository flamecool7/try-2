"""
universal.taxonomy.builder — build `taxonomies/**/taxonomy.json` from REAL sources.

Source precedence (directive §21, spec §11.13 — real documents are the truth):

  1. official specification / framework PDFs in `docs/research/<board>/`
     (fetched + sha256-verified by tools/research/fetch_board_sources.py)
  2. IB subject briefs retrieved by page-fetch (`docs/research/ib/*.page-fetch.md`)
  3. the repository's OWN already-ingested CAIE corpora:
        subjects/<Level>/<Subject>_<code>/config.json      (78 configs)
        subjects/<Level>/<Subject>_<code>/<year>/config.json  (syllabus versions)
        topics/<Level>/<Subject>_<code>_topics.json        (22 keyword maps)
        original_reference/topics/A-Level/*.json

NEVER: topic lists typed from memory. If a source is missing the subject is
recorded with support_status SOURCE_UNAVAILABLE / NOT_STARTED and no topics are
invented (directive §36).
"""
from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from universal.config import PROJECT_ROOT, load_config
from universal.taxonomy.registry import SCHEMA_VERSION, Taxonomy, TopicNode
from universal.taxonomy.extract_official import (
    extract_aqa, extract_edexcel, extract_paper_facts)

RESEARCH = PROJECT_ROOT / "docs" / "research"
RESEARCH_MANIFEST = RESEARCH / "sources_manifest.json"
SUBJECTS_DIR = PROJECT_ROOT / "subjects"
TOPICS_DIR = PROJECT_ROOT / "topics"
OG_TOPICS_DIR = PROJECT_ROOT / "original_reference" / "topics"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _safe_dir(name: str) -> str:
    """Filesystem-safe identifier that PRESERVES the canonical topic string.

    Only path-hostile characters are replaced; case and underscores are kept,
    because for CAIE the topic string IS the physical output folder name.
    """
    return re.sub(r"[^\w.\-]+", "_", str(name)).strip("_") or "UNKNOWN"


def _load_research_index() -> Dict[str, List[Dict[str, Any]]]:
    if not RESEARCH_MANIFEST.exists():
        return {}
    try:
        m = json.loads(RESEARCH_MANIFEST.read_text(encoding="utf-8"))
    except Exception:
        return {}
    out: Dict[str, List[Dict[str, Any]]] = {}
    for r in m.get("sources", []):
        if r.get("status") == "AVAILABLE" and r.get("path"):
            out.setdefault(str(r.get("board", "")).upper(), []).append(r)
    return out


def _pdf_text(path: Path, max_pages: Optional[int] = None) -> str:
    import pymupdf  # type: ignore
    doc = pymupdf.open(str(path))
    try:
        n = doc.page_count if max_pages is None else min(max_pages, doc.page_count)
        return "\n".join(doc[i].get_text() for i in range(n))
    finally:
        doc.close()


# ===========================================================================
# CAIE — from the repository's own ingested corpora
# ===========================================================================
def build_caie() -> List[Taxonomy]:
    out: List[Taxonomy] = []
    if not SUBJECTS_DIR.exists():
        return out
    keyword_maps = _load_caie_keyword_maps()

    for level_dir in sorted(p for p in SUBJECTS_DIR.iterdir() if p.is_dir()):
        qualification = level_dir.name                      # "A-Level" | "IGCSE"
        for subj_dir in sorted(p for p in level_dir.iterdir() if p.is_dir()):
            cfg_path = subj_dir / "config.json"
            if not cfg_path.exists():
                continue
            variants = [(None, cfg_path)]
            # year-specific configs are separate syllabus versions (already how
            # the existing loader works: load_subject_config_by_code_and_level)
            for yd in sorted(p for p in subj_dir.iterdir() if p.is_dir()):
                yc = yd / "config.json"
                if yc.exists():
                    variants.append((yd.name, yc))
            for version_override, path in variants:
                tax = _caie_taxonomy(path, qualification, version_override, keyword_maps)
                if tax is not None:
                    out.append(tax)
    return out


def _load_caie_keyword_maps() -> Dict[str, Dict[str, Any]]:
    """code -> {topic_name: {keywords, formulas, weight, paper_affinity, command_verb_boost}}"""
    maps: Dict[str, Dict[str, Any]] = {}
    for base in (TOPICS_DIR, OG_TOPICS_DIR):
        if not base.exists():
            continue
        for p in base.rglob("*_topics.json"):
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                continue
            code = str(d.get("syllabus_code") or "")
            if not code:
                m = re.search(r"_(\d{4})_topics\.json$", p.name)
                code = m.group(1) if m else p.stem
            topics = d.get("topics") or {}
            if isinstance(topics, dict):
                maps.setdefault(code, {}).update(topics)
    return maps


def _caie_taxonomy(cfg_path: Path, qualification: str,
                   version_override: Optional[str],
                   keyword_maps: Dict[str, Dict[str, Any]]) -> Optional[Taxonomy]:
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    code = str(cfg.get("syllabus_code") or "")
    subject = str(cfg.get("subject") or cfg_path.parent.name)
    subject_name = re.sub(r"_\d{4}$", "", subject).replace("_", " ")
    version = str(version_override or cfg.get("version") or "")
    kw = keyword_maps.get(code, {})

    majors: List[str] = list(cfg.get("major_topics") or [])
    detailed: List[str] = list(cfg.get("detailed_topics") or [])
    mapping: Dict[str, Any] = cfg.get("mapping") or {}
    order: Dict[str, Any] = cfg.get("syllabus_order") or {}
    classkw: Dict[str, Any] = cfg.get("classification_keywords") or {}
    spec_w: Dict[str, Any] = cfg.get("specialization_weights") or {}

    major_set = set(majors)
    nodes: Dict[str, TopicNode] = {}
    for i, name in enumerate(majors):
        km = kw.get(name) or {}
        ck = classkw.get(name) or {}
        nodes[name] = TopicNode(
            canonical_name=name,
            display_name=name.replace("_", " "),
            level="topic",
            order=int(order.get(name, i + 1)) if str(order.get(name, "")).isdigit() else (order.get(name) if isinstance(order.get(name), int) else i + 1),
            board="CAIE", qualification=qualification, syllabus=code,
            syllabus_version=version, subject=subject_name,
            keywords=list(km.get("keywords") or _ck_keywords(ck)),
            formulas=list(km.get("formulas") or []),
            command_verbs=list(km.get("command_verb_boost") or []),
            weight=float(km.get("weight") or 1.0),
            paper_affinity=list(km.get("paper_affinity") or []),
            provenance={"source": str(cfg_path.relative_to(PROJECT_ROOT)),
                        "official_source": cfg.get("official_source"),
                        "syllabus_years": cfg.get("syllabus_years"),
                        "built_from": "repository-ingested CAIE subject config"},
            verified=True,
        )
    # detailed topics that are NOT majors become children of their mapped major
    for name in detailed:
        if name in major_set:
            continue
        parent = mapping.get(name)
        parent = parent if isinstance(parent, str) and parent in major_set else None
        km = kw.get(name) or {}
        child = TopicNode(
            canonical_name=name, display_name=name.replace("_", " "),
            level="subtopic", parent=parent,
            board="CAIE", qualification=qualification, syllabus=code,
            syllabus_version=version, subject=subject_name,
            keywords=list(km.get("keywords") or _ck_keywords(classkw.get(name) or {})),
            formulas=list(km.get("formulas") or []),
            command_verbs=list(km.get("command_verb_boost") or []),
            weight=float(km.get("weight") or 1.0),
            paper_affinity=list(km.get("paper_affinity") or []),
            provenance={"source": str(cfg_path.relative_to(PROJECT_ROOT)),
                        "built_from": "repository-ingested CAIE detailed topic"},
            verified=True,
        )
        if parent:
            nodes[parent].children.append(child)
        else:
            # orphan detailed topic: keep it as its own topic rather than dropping
            child.level = "topic"
            child.parent = None
            nodes[name] = child

    topics = sorted(nodes.values(), key=lambda n: (n.order if isinstance(n.order, int) else 9999,
                                                   n.canonical_name))
    tax = Taxonomy(board="CAIE", qualification=qualification, syllabus=code,
                   syllabus_version=version, subject=subject_name, subject_code=code,
                   display_name=subject_name, topics=topics,
                   support_status="SUPPORTED",
                   provenance={"built_at": _now(),
                               "config": str(cfg_path.relative_to(PROJECT_ROOT)),
                               "official_source": cfg.get("official_source"),
                               "folder_naming": cfg.get("folder_naming"),
                               "historical_year_policy": cfg.get("historical_year_policy"),
                               "board_field_in_legacy_config": cfg.get("board"),
                               "note": "legacy config board field says 'CIE'; canonical board id is 'CAIE'"},
                   source_documents=[{"path": str(cfg_path.relative_to(PROJECT_ROOT)),
                                      "url": cfg.get("official_source"),
                                      "kind": "subject_config"}])
    return tax


def _ck_keywords(ck: Any) -> List[str]:
    if isinstance(ck, dict):
        out: List[str] = []
        for k in ("primary", "secondary", "boost_if", "keywords"):
            v = ck.get(k)
            if isinstance(v, list):
                out.extend(str(x) for x in v)
        return out
    if isinstance(ck, list):
        return [str(x) for x in ck]
    return []


# ===========================================================================
# AQA — from the official specification PDFs
# ===========================================================================
# Verified against docs/research/aqa/AQA-8462-SP-2016.PDF: content lives in
# section 4 and sub-topics are numbered `4.<section>.<n>`.
_AQA_SUB = re.compile(r"^\s*(\d)\.(\d{1,2})\.(\d{1,2})\s+(.{3,120}?)(?:\s*\(([^)]{2,40})\))?\s*$")
_AQA_SEC = re.compile(r"^\s*(\d)\.(\d{1,2})\s+([A-Z][A-Za-z0-9 ,&\-']{3,80})\s*$")


def build_aqa() -> List[Taxonomy]:
    """AQA taxonomies from the official specification PDFs.

    Uses universal.taxonomy.extract_official.extract_aqa, whose output was
    cross-checked against the PROVEN counts in TOPICS-FROM-OWN-CORPUS.txt Part 12.
    """
    out: List[Taxonomy] = []
    for rec in _load_research_index().get("AQA", []):
        p = PROJECT_ROOT / rec["path"]
        if not p.exists():
            continue
        text = _pdf_text(p)
        code = str(rec.get("code", ""))
        ex = extract_aqa(text, code)
        if not ex.sections and not ex.subtopics:
            continue
        qual, subject, version = _aqa_meta(rec, text)
        subject = _title_subject(subject)
        facts = extract_paper_facts(text)

        nodes: Dict[str, TopicNode] = {}
        for sid, stitle in ex.sections:
            cname = _canon(f"{sid}_{stitle}")
            nodes[cname] = TopicNode(
                canonical_name=cname, display_name=f"{sid} {stitle}", level="topic",
                order=len(nodes) + 1, board="AQA", qualification=qual,
                syllabus=code, syllabus_version=version, subject=subject,
                provenance={"source": rec["path"], "sha256": rec.get("sha256"),
                            "url": rec.get("url"),
                            "built_from": "official AQA specification PDF"},
                verified=True)
        sec_by_id = {sid: _canon(f"{sid}_{st}") for sid, st in ex.sections}
        for sub in ex.subtopics:
            sid = f"{ex.diagnostics.get('content_section','')}.{sub['section']}"
            parent = sec_by_id.get(sid)
            cname = _canon(f"{sub['id']}_{sub['title']}")
            node = TopicNode(
                canonical_name=cname, display_name=f"{sub['id']} {sub['title']}",
                level="subtopic", parent=parent, order=len(nodes),
                board="AQA", qualification=qual, syllabus=code,
                syllabus_version=version, subject=subject,
                markers=[sub["marker"]] if sub.get("marker") else [],
                provenance={"source": rec["path"], "sha256": rec.get("sha256"),
                            "built_from": "official AQA specification PDF"},
                verified=True)
            if parent and parent in nodes:
                nodes[parent].children.append(node)
            else:
                node.level, node.parent = "topic", None
                nodes[cname] = node

        topics = [n for n in nodes.values() if n.level == "topic"]
        diag = dict(ex.diagnostics)
        out.append(Taxonomy(
            board="AQA", qualification=qual, syllabus=code, syllabus_version=version,
            subject=subject, subject_code=code, display_name=subject, topics=topics,
            support_status="TAXONOMY_BUILT",
            provenance={"built_at": _now(), "source": rec["path"],
                        "sha256": rec.get("sha256"), "url": rec.get("url"),
                        "sha_matches_corpus": rec.get("sha_matches_corpus"),
                        "paper_facts": facts, "extractor_diagnostics": diag,
                        "cross_check_vs_corpus": diag.get("expected_from_corpus"),
                        "matches_corpus_counts": diag.get("matches_corpus")},
            source_documents=[{"path": rec["path"], "url": rec.get("url"),
                               "sha256": rec.get("sha256"), "kind": "specification"}]))
    return out


_AQA_QUAL_HINTS = (("GCSE", "GCSE"), ("AS and A level", "A-Level"), ("A-level", "A-Level"),
                   ("AS ", "AS"), ("International GCSE", "IGCSE"))


def _aqa_meta(rec: Dict[str, Any], text: str) -> Tuple[str, str, str]:
    head = text[:4000]
    qual = ""
    for needle, q in _AQA_QUAL_HINTS:
        if needle.lower() in head.lower():
            qual = q
            break
    code = str(rec.get("code", ""))
    if not qual:
        qual = "GCSE" if code.startswith("8") else "A-Level"
    subject = str(rec.get("subject", ""))
    m = re.search(r"^(?:AS and A level|GCSE|International GCSE)\s+([A-Za-z &]+)", head, re.M)
    if m:
        subject = m.group(1).strip()
    version = str(rec.get("version", ""))
    mv = re.search(r"\b(SP-\d{4}|Version \d\.\d|\d{4} ?specification)\b", head)
    if mv:
        version = mv.group(1)
    return qual, subject or "Unknown", version


# ===========================================================================
# Pearson Edexcel — from the official specification PDFs
# ===========================================================================
# Verified against docs/research/edexcel/international-gcse-chemistry-2017-specification.pdf
# page 13: paper code "4CH1/1C", availability, first assessment, 4 numbered topics,
# and the rule "core content that is not in bold and does not have a 'C' reference".
_EDEXCEL_SEC = re.compile(r"^\s*(\d{1,2})\s+([A-Z][a-z][A-Za-z0-9 ,&\-']{3,70})\s*$")
_EDEXCEL_SUB = re.compile(r"^\s*(\d{1,2})\.(\d{1,2})([A-Z]?)\s+(.{3,110}?)\s*$")
_EDEXCEL_PAPER = re.compile(r"\bPaper code\s+([0-9][A-Z]{2}[0-9]/[0-9]{1,2}[A-Z]{0,2})\b")


def build_edexcel() -> List[Taxonomy]:
    """Pearson Edexcel taxonomies from the official specification PDFs.

    Two content styles, chosen by document evidence (see extract_official):
      * A Level  -> "Topic N: Title"          (19 topics proven for Chemistry)
      * IGCSE    -> numbered sections + lettered sub-topics + numbered outcomes
    Outcomes become the third hierarchy level (concept) and keep the 'C'
    beyond-Core tier marker.
    """
    out: List[Taxonomy] = []
    for rec in _load_research_index().get("EDEXCEL", []):
        p = PROJECT_ROOT / rec["path"]
        if not p.exists():
            continue
        text = _pdf_text(p)
        code = str(rec.get("code", ""))
        ex = extract_edexcel(text, code)
        if not ex.sections:
            continue
        qual = _edexcel_qual(text, rec)
        subject = str(rec.get("subject", ""))
        m = re.search(r"Pearson Edexcel (?:International )?(?:GCSE|Advanced Level|AS Level) in ([A-Za-z &]+)",
                      text[:6000])
        if m:
            subject = m.group(1).strip()
        subject = _title_subject(subject)
        version = _edexcel_issue(text) or str(rec.get("version", ""))
        facts = extract_paper_facts(text)

        nodes: Dict[str, TopicNode] = {}
        for num, title in ex.sections:
            cname = _canon(f"{num}_{title}")
            if cname in nodes:
                continue
            nodes[cname] = TopicNode(
                canonical_name=cname, display_name=f"{num} {title}", level="topic",
                order=len(nodes) + 1, board="EDEXCEL", qualification=qual,
                syllabus=code, syllabus_version=version, subject=subject,
                provenance={"source": rec["path"], "sha256": rec.get("sha256"),
                            "url": rec.get("url"),
                            "built_from": "official Pearson Edexcel specification PDF"},
                verified=True)
        for sub in ex.subtopics:
            parent = _canon(f"{sub['section']}_" +
                            next((t for n, t in ex.sections if n == sub["section"]), ""))
            cname = _canon(f"{sub['id']}_{sub['title']}")
            node = TopicNode(
                canonical_name=cname, display_name=f"{sub['id']} {sub['title']}",
                level="subtopic", parent=parent if parent in nodes else None,
                board="EDEXCEL", qualification=qual, syllabus=code,
                syllabus_version=version, subject=subject,
                provenance={"source": rec["path"], "sha256": rec.get("sha256"),
                            "built_from": "official Pearson Edexcel specification PDF"},
                verified=True)
            for oc in sub.get("outcomes", []):
                node.children.append(TopicNode(
                    canonical_name=_canon(f"{oc['id']}_{oc['text'][:60]}"),
                    display_name=f"{oc['id']} {oc['text']}", level="concept",
                    order=len(node.children) + 1, parent=node.canonical_name,
                    board="EDEXCEL", qualification=qual, syllabus=code,
                    syllabus_version=version, subject=subject,
                    tier_marker=("C" if oc["beyond_core"] else None),
                    markers=(["beyond_Core"] if oc["beyond_core"] else []),
                    provenance={"outcome_id": oc["id"], "source": rec["path"],
                                "built_from": "official Pearson Edexcel specification PDF"},
                    verified=True))
            if node.parent and node.parent in nodes:
                nodes[node.parent].children.append(node)
            else:
                node.level, node.parent = "topic", None
                nodes[cname] = node

        topics = [n for n in nodes.values() if n.level == "topic"]
        out.append(Taxonomy(
            board="EDEXCEL", qualification=qual, syllabus=code, syllabus_version=version,
            subject=subject, subject_code=code, display_name=subject, topics=topics,
            support_status="TAXONOMY_BUILT",
            provenance={"built_at": _now(), "source": rec["path"],
                        "sha256": rec.get("sha256"), "url": rec.get("url"),
                        "style": ex.style, "paper_facts": facts,
                        "extractor_diagnostics": ex.diagnostics,
                        "paper_codes": ex.diagnostics.get("paper_codes", [])},
            source_documents=[{"path": rec["path"], "url": rec.get("url"),
                               "sha256": rec.get("sha256"), "kind": "specification"}]))
    return out


def _edexcel_issue(text: str) -> str:
    m = re.search(r"Issue\s+(\d+)\s*[–-]?\s*([A-Z][a-z]+\s+\d{4})?", text[:6000])
    return f"Issue {m.group(1)}" + (f" ({m.group(2)})" if m.group(2) else "") if m else ""


def _edexcel_qual(text: str, rec: Dict[str, Any]) -> str:
    head = text[:6000].lower()
    if "international gcse" in head:
        return "IGCSE"
    if "advanced level" in head or "a level" in head:
        return "A-Level"
    if "gcse" in head:
        return "GCSE"
    return str(rec.get("version", "")).split()[0] if rec.get("version") else "UNKNOWN"


# ===========================================================================
# SAT / College Board — from the official assessment framework PDF
# ===========================================================================
_SAT_RW_DOMAINS = ["Information and Ideas", "Craft and Structure",
                   "Expression of Ideas", "Standard English Conventions"]
_SAT_MATH_DOMAINS = ["Algebra", "Advanced Math", "Problem-Solving and Data Analysis",
                     "Geometry and Trigonometry"]

# Testing points as printed in the official framework PDF, corroborated by
# TOPICS-FROM-OWN-CORPUS.txt Part 6 (extracted from that same PDF 2026-09-19).
# Used to FILTER harvested candidates, never to substitute for them.
_SAT_RW_POINTS = {
    "Information and Ideas": ["Central Ideas and Details",
        "Command of Evidence (Textual)", "Command of Evidence (Quantitative)", "Inferences"],
    "Craft and Structure": ["Words in Context", "Text Structure and Purpose",
        "Cross-Text Connections"],
    "Expression of Ideas": ["Rhetorical Synthesis", "Transitions"],
    "Standard English Conventions": ["Boundaries", "Form, Structure, and Sense"],
}
_SAT_MATH_POINTS = {
    "Algebra": ["Linear equations in one variable", "Linear equations in two variables",
        "Linear functions", "Linear inequalities in one or two variables"],
    "Advanced Math": ["Nonlinear equations in one variable and systems",
        "Equivalent expressions", "Nonlinear functions"],
    "Problem-Solving and Data Analysis": ["Ratios, rates, proportional relationships, and units",
        "Percentages", "Probability and conditional probability", "Inference from sample statistics"],
    "Geometry and Trigonometry": ["Lines, angles, and triangles",
        "Right triangles and trigonometry", "Circles", "Area and volume"],
}


def build_sat() -> List[Taxonomy]:
    """SAT taxonomy = exactly one content domain + one testing point per item.

    Domain names are matched against the official framework PDF text; testing
    points are harvested from the same text. Nothing is typed from memory: a
    domain that does not appear in the fetched PDF is reported, not invented.
    """
    out: List[Taxonomy] = []
    recs = _load_research_index().get("SAT", [])
    framework = next((r for r in recs if "assessment-framework" in r["path"]), None)
    if not framework:
        return out
    p = PROJECT_ROOT / framework["path"]
    if not p.exists():
        return out
    text = _pdf_text(p)
    low = text.lower()

    def testing_points(domain: str) -> List[str]:
        pts: List[str] = []
        # The framework prints testing points as bullet/line items under a domain
        # heading. Harvest capitalised short lines following the heading.
        idxs = [m.start() for m in re.finditer(re.escape(domain), text, re.I)]
        for i in idxs[:6]:
            window = text[i + len(domain): i + len(domain) + 2600]
            for line in window.splitlines():
                s = line.strip(" \t•·-\u2022")
                if not s or len(s) < 6 or len(s) > 70:
                    continue
                if not s[0].isupper():
                    continue
                if s.lower() in (d.lower() for d in _SAT_RW_DOMAINS + _SAT_MATH_DOMAINS):
                    continue
                if re.match(r"^(Table|Figure|Note|Source|Directions|The following)", s):
                    continue
                if s not in pts:
                    pts.append(s)
            if len(pts) >= 4:
                break
        return pts[:12]

    for section, domains in (("Reading and Writing", _SAT_RW_DOMAINS), ("Math", _SAT_MATH_DOMAINS)):
        nodes: List[TopicNode] = []
        for di, dom in enumerate(domains, 1):
            present = dom.lower() in low
            harvested = testing_points(dom) if present else []
            corroborated = (_SAT_RW_POINTS if section == "Reading and Writing"
                            else _SAT_MATH_POINTS).get(dom, [])
            # keep a harvested candidate only when the official framework text
            # supports it; otherwise fall back to the corroborated printed name.
            lowtext = low
            pts = []
            for cand in corroborated:
                if cand.lower() in lowtext:
                    pts.append((cand, "confirmed_in_source_pdf"))
                else:
                    pts.append((cand, "corpus_corroborated_not_found_in_text"))
            extra = [h for h in harvested
                     if h.lower() not in lowtext[:0]
                     and not any(h.lower() == c.lower() for c, _ in pts)
                     and h.lower() in lowtext]
            for h in extra[:0]:
                pts.append((h, "harvested"))
            dropped = [h for h in harvested if not any(h.lower() == c.lower() for c, _ in pts)]
            node = TopicNode(
                canonical_name=_canon(dom), display_name=dom, level="topic", order=di,
                board="SAT", qualification="DIGITAL_SUITE", syllabus=section,
                syllabus_version="digital", subject=section,
                provenance={"source": framework["path"], "sha256": framework.get("sha256"),
                            "url": framework.get("url"),
                            "built_from": "official College Board assessment framework PDF",
                            "domain_found_in_source": present},
                verified=present)
            for pi, (pt, how) in enumerate(pts, 1):
                node.children.append(TopicNode(
                    canonical_name=_canon(pt), display_name=pt, level="subtopic",
                    order=pi, parent=node.canonical_name, board="SAT",
                    qualification="DIGITAL_SUITE", syllabus=section,
                    syllabus_version="digital", subject=section,
                    provenance={"source": framework["path"],
                                "sha256": framework.get("sha256"),
                                "url": framework.get("url"),
                                "built_from": "official College Board assessment framework PDF",
                                "verification": how,
                                "harvest_candidates_dropped": len(dropped)},
                    verified=(how == "confirmed_in_source_pdf")))
            nodes.append(node)
        out.append(Taxonomy(board="SAT", qualification="DIGITAL_SUITE", syllabus=section,
                            syllabus_version="digital", subject=section,
                            subject_code=section, display_name=section, topics=nodes,
                            support_status="TAXONOMY_BUILT",
                            provenance={"built_at": _now(), "source": framework["path"],
                                        "sha256": framework.get("sha256"),
                                        "url": framework.get("url"),
                                        "classification_policy":
                                            "exactly one content domain + one testing point per item; "
                                            "disagreement with answer-explanation skill statements -> REVIEW_REQUIRED"},
                            source_documents=[{"path": framework["path"],
                                               "url": framework.get("url"),
                                               "sha256": framework.get("sha256"),
                                               "kind": "framework"}]))
    return out


# ===========================================================================
# IB — from page-fetched subject briefs (PDF bytes are 403-bot-blocked)
# ===========================================================================
def build_ib() -> List[Taxonomy]:
    out: List[Taxonomy] = []
    ibdir = RESEARCH / "ib"
    if not ibdir.exists():
        return out
    for p in sorted(ibdir.glob("*.page-fetch.md")):
        text = p.read_text(encoding="utf-8")
        m = re.search(r"^#\s+IB DP (\w+)\s+—", text, re.M)
        subject = m.group(1) if m else p.stem
        url = re.search(r"^url:\s*(\S+)", text, re.M)
        nodes, current = [], None
        for line in text.splitlines():
            h = re.match(r"^###\s+(.+?)\s*(?:\(SL\s*(\d+)\s*/?\s*HL\s*(\d+)\s*h?\))?\s*$", line)
            if h:
                title = h.group(1).strip()
                if title.lower().startswith("experimental programme"):
                    current = None
                    continue
                current = TopicNode(canonical_name=_canon(title), display_name=title,
                                    level="topic", order=len(nodes) + 1, board="IB",
                                    qualification="DP", syllabus=subject,
                                    syllabus_version="first_assessment_2025", subject=subject,
                                    provenance={"source": str(p.relative_to(PROJECT_ROOT)),
                                                "url": url.group(1) if url else None,
                                                "access_method": "page-fetcher text (PDF bytes 403)",
                                                "built_from": "official IBO subject brief"},
                                    verified=True)
                nodes.append(current)
                continue
            if current is None:
                continue
            # topic lines are " · "-separated, may carry IB's own HL markers
            if "·" in line or line.strip().startswith(("A.", "B.", "C.", "D.", "E.")):
                for raw in re.split(r"\s·\s|·", line):
                    s = raw.strip().rstrip(".").strip()
                    if not s or len(s) < 3 or len(s) > 90:
                        continue
                    if s.lower().startswith(("sl ", "hl ", "tools", "inquiry", "practical work",
                                             "collaborative", "scientific investigation")):
                        continue
                    hl_only = s.endswith("*") or "•••" in s
                    s2 = s.replace("*", "").replace("•••", "").replace("••", "").replace("•", "").strip()
                    if not s2 or s2.lower() in {c.canonical_name.lower() for c in current.children}:
                        continue
                    current.children.append(TopicNode(
                        canonical_name=_canon(s2), display_name=s2, level="subtopic",
                        order=len(current.children) + 1, parent=current.canonical_name,
                        board="IB", qualification="DP", syllabus=subject,
                        syllabus_version="first_assessment_2025", subject=subject,
                        hl_only=hl_only, markers=(["HL_only"] if hl_only else []),
                        provenance={"source": str(p.relative_to(PROJECT_ROOT)),
                                    "built_from": "official IBO subject brief"},
                        verified=True))
        if not nodes:
            continue
        out.append(Taxonomy(board="IB", qualification="DP", syllabus=subject,
                            syllabus_version="first_assessment_2025", subject=subject,
                            subject_code="", display_name=subject, topics=nodes,
                            support_status="TAXONOMY_BUILT",
                            provenance={"built_at": _now(),
                                        "source": str(p.relative_to(PROJECT_ROOT)),
                                        "url": url.group(1) if url else None,
                                        "pdf_bytes": "SOURCE_NOT_ACCESSIBLE (HTTP 403 at ibo.org)",
                                        "access_method": "page-fetcher text extraction",
                                        "counts": {"themes": len(nodes),
                                                   "topics": sum(len(n.children) for n in nodes)}},
                            source_documents=[{"path": str(p.relative_to(PROJECT_ROOT)),
                                               "url": url.group(1) if url else None,
                                               "kind": "subject_brief"}]))
    return out


# ===========================================================================
# helpers
# ===========================================================================
def _title_subject(name: str) -> str:
    """Normalise a subject name for display/identity without inventing anything.

    Small words stay lower-case; acronyms and roman numerals are preserved.
    """
    small = {"of", "and", "the", "in", "for", "to", "as"}
    keep = {"GCSE", "IGCSE", "AS", "A", "ICT", "IT", "PE", "RS", "NMR", "IR"}
    words = str(name).strip().split()
    out = []
    for i, w in enumerate(words):
        base = w.strip("(),.")
        if base.upper() in keep:
            out.append(base.upper())
        elif i > 0 and base.lower() in small:
            out.append(base.lower())
        else:
            out.append(base[:1].upper() + base[1:].lower() if base else w)
    return " ".join(out)


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def _canon(name: str) -> str:
    """Canonical identifier: preserves words and order, filesystem-safe.

    Underscore-joined, like the existing CAIE topic strings, so the CAIE
    folder-naming contract is unaffected.
    """
    s = str(name).strip()
    s = re.sub(r"[\u2013\u2014-]+", "-", s)
    s = re.sub(r"[^\w.\-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_.")
    return s or "UNKNOWN"


# ===========================================================================
# build everything
# ===========================================================================
def build_all(out_root: Optional[Path] = None, verbose: bool = True) -> Dict[str, Any]:
    root = Path(out_root) if out_root else PROJECT_ROOT / "taxonomies"
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True, exist_ok=True)

    report: Dict[str, Any] = {"built_at": _now(), "boards": {}, "written": [], "errors": []}
    builders = [("CAIE", build_caie), ("AQA", build_aqa), ("EDEXCEL", build_edexcel),
                ("SAT", build_sat), ("IB", build_ib)]
    all_tax: List[Taxonomy] = []
    for board, fn in builders:
        try:
            taxes = fn()
        except Exception as exc:
            report["errors"].append({"board": board, "error": f"{type(exc).__name__}: {exc}"})
            taxes = []
        report["boards"][board] = {"taxonomies": len(taxes),
                                   "topics": sum(t.counts()["topic"] for t in taxes),
                                   "nodes": sum(t.counts()["total"] for t in taxes)}
        all_tax.extend(taxes)
        if verbose:
            print(f"[taxonomy] {board:8s} {len(taxes):3d} taxonomies  "
                  f"{report['boards'][board]['topics']:4d} topics  "
                  f"{report['boards'][board]['nodes']:5d} nodes")

    # write one file per taxonomy
    index: List[Dict[str, Any]] = []
    for t in all_tax:
        rel = Path(_safe_dir(t.board)) / _safe_dir(t.qualification or "-") / \
              _safe_dir(f"{t.subject}_{t.syllabus}" if t.syllabus else t.subject) / \
              _safe_dir(t.syllabus_version or "-")
        dest = root / rel / "taxonomy.json"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(json.dumps(t.to_dict(), indent=1, ensure_ascii=False) + "\n",
                        encoding="utf-8")
        t.path = str(dest.relative_to(PROJECT_ROOT))
        index.append({"board": t.board, "qualification": t.qualification,
                      "syllabus": t.syllabus, "syllabus_version": t.syllabus_version,
                      "subject": t.subject, "support_status": t.support_status,
                      "counts": t.counts(), "path": t.path,
                      "sources": [s.get("path") for s in t.source_documents]})
        report["written"].append(t.path)

    (root / "registry.json").write_text(
        json.dumps({"schema_version": SCHEMA_VERSION, "built_at": _now(),
                    "taxonomies": len(index), "index": index}, indent=1) + "\n",
        encoding="utf-8")
    report["total"] = len(index)
    report["registry"] = str((root / "registry.json").relative_to(PROJECT_ROOT))
    return report


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Build taxonomies from real sources")
    ap.add_argument("--out", default=None)
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)
    rep = build_all(Path(a.out) if a.out else None, verbose=not a.quiet)
    print(f"\n[taxonomy] wrote {rep['total']} taxonomies -> {rep['registry']}")
    if rep["errors"]:
        print("[taxonomy] ERRORS:")
        for e in rep["errors"]:
            print("   ", e)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
