"""
universal.taxonomy.registry — the data-driven universal topic registry.

Hierarchy (directive §4, spec §6.12):

    Board → Qualification → Syllabus → Syllabus Version → Subject
          → Topic → Subtopic → Concept

HARD RULES enforced here:
  * No topic list is hardcoded in Python. Everything comes from
    `taxonomies/**/*.json`, built by `universal/taxonomy/builder.py` from the
    official documents in `docs/research/` and the repository's own
    `subjects/` + `topics/` corpora.
  * Topics are NEVER merged because their names look similar
    (`never_merge_similar_names`).
  * Historical topics are NEVER renamed (`never_rename_historical`).
  * One subject's concepts never leak into another subject.
  * A syllabus version is part of a topic's identity.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from universal.config import PROJECT_ROOT, load_config

SCHEMA_VERSION = "1.0"

LEVELS = ("topic", "subtopic", "concept")


# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------
@dataclass
class TopicNode:
    """One node in the topic hierarchy.

    `canonical_name` is the stable identifier and — for CAIE — the exact string
    that names the physical output folder (core/output_manager.py writes
    metadata `topic[0]` verbatim as the folder name). It must never be
    normalised, case-folded or "tidied".
    """
    canonical_name: str
    display_name: str = ""
    level: str = "topic"                    # topic | subtopic | concept
    aliases: List[str] = field(default_factory=list)
    legacy_names: List[str] = field(default_factory=list)
    order: Optional[int] = None
    board: str = ""
    qualification: str = ""
    syllabus: str = ""
    syllabus_version: str = ""
    subject: str = ""
    parent: Optional[str] = None            # canonical_name of parent
    children: List["TopicNode"] = field(default_factory=list)
    # classification aids carried over from the legacy corpora
    keywords: List[str] = field(default_factory=list)
    formulas: List[str] = field(default_factory=list)
    command_verbs: List[str] = field(default_factory=list)
    weight: float = 1.0
    paper_affinity: List[Any] = field(default_factory=list)
    # level/tier markers that must be preserved (IB '*' HL-only, Edexcel 'C'
    # beyond-Core, AQA "(chemistry only)")
    markers: List[str] = field(default_factory=list)
    hl_only: bool = False
    tier_marker: Optional[str] = None
    # cross-board concept linkage (spec §6.13)
    concept_ids: List[str] = field(default_factory=list)
    provenance: Dict[str, Any] = field(default_factory=dict)
    verified: bool = False

    # -- identity ------------------------------------------------------------
    @property
    def uid(self) -> str:
        return "::".join([self.board, self.qualification, self.syllabus,
                          self.syllabus_version, self.subject, self.canonical_name])

    def names(self) -> List[str]:
        """Every name this node answers to, canonical first. Used for matching."""
        out = [self.canonical_name]
        if self.display_name and self.display_name not in out:
            out.append(self.display_name)
        out.extend(a for a in self.aliases if a not in out)
        out.extend(l for l in self.legacy_names if l not in out)
        return out

    def walk(self) -> Iterable["TopicNode"]:
        yield self
        for c in self.children:
            yield from c.walk()

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "canonical_name": self.canonical_name,
            "display_name": self.display_name or self.canonical_name,
            "level": self.level,
            "order": self.order,
            "aliases": self.aliases,
            "legacy_names": self.legacy_names,
            "markers": self.markers,
            "hl_only": self.hl_only,
            "tier_marker": self.tier_marker,
            "concept_ids": self.concept_ids,
            "keywords": self.keywords,
            "formulas": self.formulas,
            "command_verbs": self.command_verbs,
            "weight": self.weight,
            "paper_affinity": self.paper_affinity,
            "verified": self.verified,
            "provenance": self.provenance,
        }
        if self.children:
            d["children"] = [c.to_dict() for c in self.children]
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any], ctx: Optional[Dict[str, str]] = None,
                  parent: Optional[str] = None, level: str = "topic") -> "TopicNode":
        ctx = ctx or {}
        node = cls(
            canonical_name=d["canonical_name"],
            display_name=d.get("display_name") or d["canonical_name"],
            level=d.get("level", level),
            aliases=list(d.get("aliases") or []),
            legacy_names=list(d.get("legacy_names") or []),
            order=d.get("order"),
            board=ctx.get("board", ""), qualification=ctx.get("qualification", ""),
            syllabus=ctx.get("syllabus", ""), syllabus_version=ctx.get("syllabus_version", ""),
            subject=ctx.get("subject", ""),
            parent=parent,
            keywords=list(d.get("keywords") or []),
            formulas=list(d.get("formulas") or []),
            command_verbs=list(d.get("command_verbs") or []),
            weight=float(d.get("weight", 1.0) or 1.0),
            paper_affinity=list(d.get("paper_affinity") or []),
            markers=list(d.get("markers") or []),
            hl_only=bool(d.get("hl_only", False)),
            tier_marker=d.get("tier_marker"),
            concept_ids=list(d.get("concept_ids") or []),
            provenance=dict(d.get("provenance") or {}),
            verified=bool(d.get("verified", False)),
        )
        for ch in d.get("children") or []:
            child_level = "subtopic" if node.level == "topic" else "concept"
            node.children.append(cls.from_dict(ch, ctx, parent=node.canonical_name,
                                               level=ch.get("level", child_level)))
        return node


# ---------------------------------------------------------------------------
# Taxonomy — one board/qualification/syllabus/version/subject tuple
# ---------------------------------------------------------------------------
@dataclass
class Taxonomy:
    board: str
    qualification: str
    syllabus: str
    syllabus_version: str
    subject: str
    subject_code: str = ""
    display_name: str = ""
    topics: List[TopicNode] = field(default_factory=list)
    provenance: Dict[str, Any] = field(default_factory=dict)
    support_status: str = "NOT_STARTED"
    source_documents: List[Dict[str, Any]] = field(default_factory=list)
    path: Optional[str] = None
    schema_version: str = SCHEMA_VERSION

    @property
    def key(self) -> Tuple[str, str, str, str, str]:
        return (self.board, self.qualification, self.syllabus,
                self.syllabus_version, self.subject)

    def ctx(self) -> Dict[str, str]:
        return {"board": self.board, "qualification": self.qualification,
                "syllabus": self.syllabus, "syllabus_version": self.syllabus_version,
                "subject": self.subject}

    def all_nodes(self) -> List[TopicNode]:
        out: List[TopicNode] = []
        for t in self.topics:
            out.extend(t.walk())
        return out

    def find(self, name: str) -> Optional[TopicNode]:
        """Exact canonical-name lookup, then alias/legacy lookup.

        Deliberately does NOT fuzzy-match: directive §5 forbids merging topics
        merely because names look similar.
        """
        want = str(name).strip()
        for n in self.all_nodes():
            if n.canonical_name == want:
                return n
        low = want.lower()
        for n in self.all_nodes():
            if any(x.lower() == low for x in n.names()):
                return n
        return None

    def counts(self) -> Dict[str, int]:
        c = {"topic": 0, "subtopic": 0, "concept": 0}
        for n in self.all_nodes():
            c[n.level] = c.get(n.level, 0) + 1
        c["total"] = sum(c.values())
        return c

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "board": self.board, "qualification": self.qualification,
            "syllabus": self.syllabus, "syllabus_version": self.syllabus_version,
            "subject": self.subject, "subject_code": self.subject_code,
            "display_name": self.display_name or self.subject,
            "support_status": self.support_status,
            "provenance": self.provenance,
            "source_documents": self.source_documents,
            "counts": self.counts(),
            "topics": [t.to_dict() for t in self.topics],
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any], path: Optional[str] = None) -> "Taxonomy":
        tax = cls(board=d["board"], qualification=d.get("qualification", ""),
                  syllabus=str(d.get("syllabus", "")),
                  syllabus_version=str(d.get("syllabus_version", "")),
                  subject=d.get("subject", ""), subject_code=str(d.get("subject_code", "")),
                  display_name=d.get("display_name", ""),
                  provenance=dict(d.get("provenance") or {}),
                  support_status=d.get("support_status", "NOT_STARTED"),
                  source_documents=list(d.get("source_documents") or []),
                  path=path, schema_version=d.get("schema_version", SCHEMA_VERSION))
        ctx = tax.ctx()
        for i, t in enumerate(d.get("topics") or []):
            t.setdefault("order", i + 1)
            tax.topics.append(TopicNode.from_dict(t, ctx, parent=None, level="topic"))
        return tax


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------
class TopicRegistry:
    """Loads and queries every taxonomy under `taxonomies/`.

    Lazy: nothing is read until first use, so importing this module is free.
    """

    def __init__(self, root: Optional[Path] = None, config=None) -> None:
        self.cfg = config or load_config()
        self.root = Path(root) if root else PROJECT_ROOT / self.cfg.get("taxonomy.dir", "taxonomies")
        self._taxonomies: Dict[Tuple[str, str, str, str, str], Taxonomy] = {}
        self._loaded = False
        self._load_errors: Dict[str, str] = {}

    # -- loading -------------------------------------------------------------
    def load(self, force: bool = False) -> "TopicRegistry":
        if self._loaded and not force:
            return self
        self._loaded = True
        self._taxonomies.clear()
        self._load_errors.clear()
        if not self.root.exists():
            return self
        for p in sorted(self.root.rglob("taxonomy.json")):
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                tax = Taxonomy.from_dict(d, path=str(p.relative_to(PROJECT_ROOT)))
                self._taxonomies[tax.key] = tax
            except Exception as exc:
                self._load_errors[str(p)] = f"{type(exc).__name__}: {exc}"
        return self

    @property
    def load_errors(self) -> Dict[str, str]:
        self.load()
        return dict(self._load_errors)

    # -- queries -------------------------------------------------------------
    def all(self) -> List[Taxonomy]:
        self.load()
        return list(self._taxonomies.values())

    def get(self, board: str, qualification: str = "", syllabus: str = "",
            syllabus_version: str = "", subject: str = "") -> Optional[Taxonomy]:
        """Exact key lookup. Empty components act as wildcards only via `search`."""
        self.load()
        return self._taxonomies.get((board, qualification, str(syllabus),
                                     str(syllabus_version), subject))

    def search(self, board: str = "", qualification: str = "", syllabus: str = "",
               subject: str = "", syllabus_version: str = "") -> List[Taxonomy]:
        self.load()
        out = []
        for tax in self._taxonomies.values():
            if board and tax.board.upper() != board.upper():
                continue
            if qualification and tax.qualification.lower() != qualification.lower():
                continue
            if syllabus and str(tax.syllabus) != str(syllabus) and tax.subject_code != str(syllabus):
                continue
            if subject and subject.lower() not in tax.subject.lower():
                continue
            if syllabus_version and str(tax.syllabus_version) != str(syllabus_version):
                continue
            out.append(tax)
        return sorted(out, key=lambda t: t.key)

    def boards(self) -> List[str]:
        self.load()
        return sorted({t.board for t in self._taxonomies.values()})

    def subjects(self, board: str = "") -> List[Dict[str, str]]:
        self.load()
        seen = {}
        for t in self._taxonomies.values():
            if board and t.board.upper() != board.upper():
                continue
            seen[(t.board, t.qualification, t.subject, t.syllabus)] = {
                "board": t.board, "qualification": t.qualification,
                "subject": t.subject, "syllabus": t.syllabus,
                "versions": sorted({str(x.syllabus_version) for x in self._taxonomies.values()
                                    if (x.board, x.qualification, x.subject, x.syllabus)
                                    == (t.board, t.qualification, t.subject, t.syllabus)}),
            }
        return [seen[k] for k in sorted(seen)]

    def versions_for(self, board: str, subject: str, syllabus: str = "") -> List[str]:
        self.load()
        return sorted({str(t.syllabus_version) for t in self._taxonomies.values()
                       if t.board.upper() == board.upper()
                       and t.subject.lower() == subject.lower()
                       and (not syllabus or str(t.syllabus) == str(syllabus))})

    def resolve_version(self, board: str, subject: str, year: Optional[int],
                        syllabus: str = "") -> Optional[Taxonomy]:
        """Pick the taxonomy whose version covers `year`.

        Version strings are data: '2025-2027', '2026', 'Issue 3 (September 2024)',
        'first assessment 2025', 'SP-2016'. Years are parsed out of them; no year
        list is hardcoded (directive §8).
        """
        cands = self.search(board=board, subject=subject, syllabus=syllabus)
        if not cands:
            return None
        if year is None:
            # newest by parsed year span, else lexicographic
            return sorted(cands, key=lambda t: (_span(t.syllabus_version), t.syllabus_version))[-1]
        scored = []
        for t in cands:
            lo, hi = _span(t.syllabus_version)
            if lo is None:
                scored.append((-1, t))
            elif lo <= int(year) <= (hi if hi is not None else lo + 99):
                scored.append((2, t))
            elif int(year) >= lo:
                scored.append((1, t))
            else:
                scored.append((0, t))
        scored.sort(key=lambda x: (x[0], _span(x[1].syllabus_version), x[1].syllabus_version))
        best = scored[-1][1] if scored else None
        if best is None:
            return None
        # Coverage honesty: a declared DISCRETE year list (e.g. CAIE 9701
        # syllabus_years = 2015,2024,2025,2026,2027) must not be interpolated.
        # VersionIntelligence is the authority on whether `year` is really
        # covered; imported lazily because versions.py imports this module.
        from universal.taxonomy.versions import VersionIntelligence
        res = VersionIntelligence(registry=self).resolve(best.syllabus, year)
        if res.status == "RESOLVED":
            return best
        # Not covered -> return None rather than a plausible-looking guess.
        # Callers needing the reason should use resolve_version_status().
        return None

    def resolve_version_status(self, board: str, subject: str, year: Optional[int],
                               syllabus: str = "") -> Dict[str, Any]:
        """`resolve_version` plus the reason, so a caller can distinguish
        "no such taxonomy" from "taxonomy exists but this year is not covered".

        Returns dict(taxonomy, status, reason, resolved_version). Status is one of
        RESOLVED | AMBIGUOUS | REVIEW_REQUIRED | UNKNOWN | NOT_FOUND.
        """
        from universal.taxonomy.versions import VersionIntelligence
        cands = self.search(board=board, subject=subject, syllabus=syllabus)
        if not cands:
            return {"taxonomy": None, "status": "NOT_FOUND",
                    "reason": f"no taxonomy for board={board} subject={subject} "
                              f"syllabus={syllabus}", "resolved_version": None}
        tax = self.resolve_version(board, subject, year, syllabus)
        res = VersionIntelligence(registry=self).resolve(cands[0].syllabus, year)
        return {"taxonomy": tax, "status": res.status, "reason": res.reason,
                "resolved_version": res.resolved_version}

    def topic_names(self, board: str, qualification: str = "", syllabus: str = "",
                    subject: str = "", syllabus_version: str = "",
                    level: str = "") -> List[str]:
        out: List[str] = []
        for t in self.search(board, qualification, syllabus, subject, syllabus_version):
            for n in t.all_nodes():
                if level and n.level != level:
                    continue
                if n.canonical_name not in out:
                    out.append(n.canonical_name)
        return out

    def stats(self) -> Dict[str, Any]:
        self.load()
        by_board: Dict[str, int] = {}
        nodes = 0
        for t in self._taxonomies.values():
            by_board[t.board] = by_board.get(t.board, 0) + 1
            nodes += len(t.all_nodes())
        return {
            "taxonomies": len(self._taxonomies),
            "boards": sorted(by_board),
            "taxonomies_per_board": dict(sorted(by_board.items())),
            "total_nodes": nodes,
            "load_errors": len(self._load_errors),
        }


_YEAR_RE = re.compile(r"(19|20)\d{2}")


def _span(version: str) -> Tuple[Optional[int], Optional[int]]:
    """Parse a year span out of an arbitrary version string. Never fabricates."""
    years = [int(m.group(0)) for m in _YEAR_RE.finditer(str(version))]
    if not years:
        return (None, None)
    return (min(years), max(years))


def default_registry() -> TopicRegistry:
    return TopicRegistry().load()


__all__ = ["TopicNode", "Taxonomy", "TopicRegistry", "default_registry",
           "SCHEMA_VERSION", "LEVELS"]
