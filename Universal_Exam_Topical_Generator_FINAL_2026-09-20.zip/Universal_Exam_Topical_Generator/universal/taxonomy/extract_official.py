"""
universal.taxonomy.extract_official — extract topic structure from OFFICIAL board
specification PDFs.

Every rule here was derived by reading the actual fetched document, and each
function records what it found so a wrong extraction is visible rather than
silent. Counts are cross-checkable against the PROVEN counts recorded in
TOPICS-FROM-OWN-CORPUS.txt Parts 5/5b/8/10/12/13.

Verified structural facts:
  AQA GCSE Chemistry 8462 (AQA-8462-SP-2016.PDF, sha ecd869d1874091a0…)
      subject content is top-level section 4; sections 4.1…4.10;
      sub-topics numbered 4.<sec>.<n>.  Corpus expects 10 sections / 32 sub-topics.
  AQA A-level specs are published under the COMBINED AS+A-level code
      (AQA-7401-7402-SP-2015.PDF, AQA-7404-7405-SP-2015.PDF,
       AQA-7407-7408-SP-2015.PDF).
  Pearson Edexcel International GCSE Chemistry (spec Issue 3, Sept 2024)
      paper codes 4CH1/1C and 4CH1/2C (also 4SD0/1C for combined science);
      Availability: November and June; First assessment: June 2019;
      Paper 1 = 110 marks, 61.1%; Paper 2 = 38.9%;
      content = numbered sections (1 Principles of chemistry … 4 Organic chemistry)
      with lettered sub-topics "(a) States of matter";
      Paper 1 "assesses core content that is not in bold and does not have a
      'C' reference", Paper 2 "assesses all the content, including content that
      is in bold and has a 'C' reference"  ->  'C' = beyond-Core tier marker.
  Pearson Edexcel A Level Chemistry (2015 spec)
      content is "Topic 1: …" … "Topic 19: …"; outcomes live in 3-column tables
      (corpus Part 13: re-extract table-aware, not line regex).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ExtractResult:
    board: str
    style: str                                  # aqa_numbered | edexcel_lettered | edexcel_topic_colon
    sections: List[Tuple[str, str]] = field(default_factory=list)   # (id, title)
    subtopics: List[Dict[str, Any]] = field(default_factory=list)
    diagnostics: Dict[str, Any] = field(default_factory=dict)

    @property
    def counts(self) -> Dict[str, int]:
        return {"sections": len(self.sections), "subtopics": len(self.subtopics)}


# ---------------------------------------------------------------------------
# AQA
# ---------------------------------------------------------------------------
_AQA_SUB_LINE = re.compile(r"^\s*(\d{1,2})\.(\d{1,2})\.(\d{1,2})\s+([A-Z][^\n]{3,110}?)\s*$", re.M)
_AQA_SEC_LINE = re.compile(r"^\s*(\d{1,2})\.(\d{1,2})\s+([A-Z][^\n]{3,90}?)\s*$", re.M)
_TRAILING_MARKER = re.compile(r"^(.*?)\s*\(([^)]{2,45})\)\s*$")

# Corpus-recorded expectations, used only as a cross-check report — never to
# synthesise missing topics.
AQA_EXPECTED = {
    "7404/7405": (3, 34), "8462": (10, 32), "7402": (8, 39),
    "8461": (7, 24), "7408": (13, 38), "8463": (8, 30),
}


def extract_aqa(text: str, code: str = "") -> ExtractResult:
    """Find AQA's subject-content section automatically, then its sub-topics.

    The content section is the top-level number that owns the most distinct
    `<sec>.<sub>` pairs — so this works for GCSE (section 4) and for A-level
    specs whose content sits under a different top-level number, without
    hardcoding either.
    """
    res = ExtractResult(board="AQA", style="aqa_numbered")

    owners: Dict[str, set] = {}
    for m in _AQA_SUB_LINE.finditer(text):
        owners.setdefault(m.group(1), set()).add((m.group(2), m.group(3)))
    if not owners:
        res.diagnostics["error"] = "no <top>.<sec>.<sub> lines found"
        return res
    top = max(owners, key=lambda k: (len(owners[k]), -int(k)))
    res.diagnostics["content_section"] = top
    res.diagnostics["candidate_top_level_sections"] = {k: len(v) for k, v in sorted(owners.items())}

    seen = set()
    for m in _AQA_SUB_LINE.finditer(text):
        if m.group(1) != top:
            continue
        sec, sub = m.group(2), m.group(3)
        if (sec, sub) in seen:
            continue
        seen.add((sec, sub))
        title = m.group(4).strip()
        marker = ""
        mm = _TRAILING_MARKER.match(title)
        if mm:
            title, marker = mm.group(1).strip(), mm.group(2).strip()
        title = re.sub(r"\s+", " ", title)
        if len(title) < 3:
            continue
        res.subtopics.append({"section": sec, "sub": sub, "title": title,
                              "marker": marker, "id": f"{top}.{sec}.{sub}"})

    # section titles, in document order of first appearance
    wanted = sorted({s["section"] for s in res.subtopics}, key=int)
    titles: Dict[str, str] = {}
    for m in _AQA_SEC_LINE.finditer(text):
        if m.group(1) != top:
            continue
        sec = m.group(2)
        if sec in wanted and sec not in titles:
            t = re.sub(r"\s+", " ", m.group(3).strip())
            # reject lines that are themselves sub-topic headings or page furniture
            if 3 < len(t) <= 90 and not re.match(r"^\d", t):
                titles[sec] = t
    for sec in wanted:
        res.sections.append((f"{top}.{sec}", titles.get(sec, f"Section {top}.{sec}")))

    exp = AQA_EXPECTED.get(code)
    if exp:
        res.diagnostics["expected_from_corpus"] = {"sections": exp[0], "subtopics": exp[1]}
        res.diagnostics["matches_corpus"] = (len(res.sections) == exp[0]
                                             and len(res.subtopics) == exp[1])
    return res


# ---------------------------------------------------------------------------
# Pearson Edexcel
# ---------------------------------------------------------------------------
_EDEXCEL_TOPIC_COLON = re.compile(r"^\s*Topic\s+(\d{1,2}):\s*([A-Z][^\n]{3,80}?)\s*$", re.M)
_EDEXCEL_LETTERED = re.compile(r"^\s*\(([a-z])\)\s*([A-Z][^\n]{3,80}?)\s*$", re.M)
_EDEXCEL_NUMBERED_TITLE = re.compile(r"^\s*(\d{1,2})\s+([A-Z][a-z][A-Za-z ,&\-']{3,60}?)\s*$", re.M)
EDEXCEL_PAPER_CODE = re.compile(r"\*?Paper code\s+([0-9][A-Z]{2}[0-9]/[0-9]{1,2}[A-Z]{0,2})")
EDEXCEL_OUTCOME = re.compile(r"^\s*(\d{1,2}\.\d{1,2})([A-Z]?)\b", re.M)


def extract_edexcel(text: str, code: str = "") -> ExtractResult:
    """Handle both Edexcel content styles, choosing by evidence in the document."""
    # --- Style A: A-Level "Topic N: Title" ---------------------------------
    topic_colon: List[Tuple[str, str]] = []
    seen = set()
    for m in _EDEXCEL_TOPIC_COLON.finditer(text):
        n = m.group(1)
        if n in seen:
            continue
        seen.add(n)
        topic_colon.append((n, re.sub(r"\s+", " ", m.group(2).strip())))
    if len(topic_colon) >= 3:
        res = ExtractResult(board="EDEXCEL", style="edexcel_topic_colon",
                            sections=topic_colon)
        # Outcomes live in 3-column tables. Line regex under-extracts them, so
        # this is reported rather than silently emitting a wrong sub-topic list.
        outcome_ids = sorted({m.group(1) + m.group(2)
                              for m in EDEXCEL_OUTCOME.finditer(text)})
        res.diagnostics.update({
            "subtopic_extraction": "TABLE_AWARE_REQUIRED",
            "note": ("corpus Part 13: 'Outcomes <topic>.<n> live in 3-col tables — "
                     "re-extract table-aware (pdfplumber), not line regex.' "
                     "Topics are proven; sub-topics are NOT emitted rather than "
                     "emitted wrong (directive §36 no fabrication)."),
            "outcome_ids_seen_in_text_layer": len(outcome_ids),
            "sample_outcome_ids": outcome_ids[:12],
        })
        return res

    # --- Style B: International GCSE numbered sections + lettered sub-topics --
    # VERIFIED LAYOUT (international-gcse-chemistry-2017-specification.pdf p17):
    #   "1 \nPrinciples of chemistry \nThe following sub-topics are covered in
    #    this section. \n(a) \nStates of matter \n(b) \nElements, compounds and
    #    mixtures ..."
    # Number and title are on SEPARATE lines; so are letter and sub-topic title.
    # Outcomes are "1.1", "1.5C", "1.6C" — 'C' = beyond-Core tier marker, kept.
    #
    # The contents pages also contain "1 \nAbout this specification" style pairs,
    # so sections are anchored ONLY on the body marker
    # "The following sub-topics are covered in this section." which precedes every
    # real content section. This is what makes the walk immune to contents noise.
    res = ExtractResult(board="EDEXCEL", style="edexcel_lettered")
    lines = [l.strip() for l in text.splitlines()]
    MARKER = "the following sub-topics are covered in this section"

    anchors = [i for i, l in enumerate(lines) if MARKER in l.lower()]
    res.diagnostics["section_anchors_found"] = len(anchors)
    if not anchors:
        res.diagnostics["error"] = "no body section marker found"
        return res

    for ai, anchor in enumerate(anchors):
        # Section heading sits immediately above the marker in one of two shapes
        # (both verified): split "1\nPrinciples of chemistry" (Chemistry spec) or
        # same-line "1 Forces and motion" (Physics spec). Try same-line FIRST so a
        # preceding page number cannot be mistaken for the section number.
        num, title = "", ""
        prev = lines[anchor - 1] if anchor >= 1 else ""
        m_same = re.match(r"^(\d{1,2})\s+([A-Z][^\n]{3,70})$", prev)
        if m_same and _looks_like_section_title(m_same.group(2)):
            num, title = m_same.group(1), m_same.group(2)
        else:
            for back in range(1, 5):
                j = anchor - back - 1
                if j >= 0 and re.fullmatch(r"\d{1,2}", lines[j]) and int(lines[j]) <= 12:
                    cand = lines[j + 1]
                    if _looks_like_section_title(cand):
                        num, title = lines[j], cand
                        break
        if not num or int(num) > 12:
            res.diagnostics.setdefault("skipped_anchors", []).append(
                {"anchor_line": anchor, "above": prev[:70]})
            continue
        if any(s0 == num for s0, _ in res.sections):
            continue
        limit = anchors[ai + 1] if ai + 1 < len(anchors) else len(lines)
        res.sections.append((num, re.sub(r"\s+", " ", title)))
        current_sub = None
        seen_sub = set()
        i = anchor + 1
        while i < limit:
            raw = lines[i]
            m2 = re.fullmatch(r"\(([a-z])\)", raw)
            m3 = _EDEXCEL_LETTERED.match(raw)
            letter = None; sub_title = None
            if m2 and i + 1 < limit and _looks_like_subtopic_title(lines[i + 1]):
                letter, sub_title = m2.group(1), lines[i + 1]
                i += 2
            elif m3 and _looks_like_subtopic_title(m3.group(2)):
                letter, sub_title = m3.group(1), m3.group(2)
                i += 1
            if letter:
                key = (num, letter)
                if key not in seen_sub:
                    seen_sub.add(key)
                    current_sub = {"section": num, "sub": letter,
                                   "title": re.sub(r"\s+", " ", sub_title),
                                   "marker": "", "id": f"{num}({letter})", "outcomes": []}
                    res.subtopics.append(current_sub)
                else:
                    # Each section lists its sub-topics up front ("The following
                    # sub-topics are covered in this section.") and then REPEATS each
                    # heading in the body, where its outcomes follow. Re-point
                    # current_sub at the already-created node; otherwise every outcome
                    # in the section accumulates on the last sub-topic of the
                    # contents list. (Verified bug: 1(i)=60, 2(h)=50, 4(h)=50.)
                    current_sub = next((x for x in res.subtopics
                                        if (x["section"], x["sub"]) == key), current_sub)
                continue
            # outcome, same-line form: "1.5C know what is meant by the term..."
            m4 = re.match(r"^(\d{1,2}\.\d{1,2})(C?)\s+(.{5,170})$", raw)
            # outcome, split form (verified in the Chemistry spec): the id sits on
            # its own line and the wording starts on the next line.
            m5 = re.fullmatch(r"(\d{1,2}\.\d{1,2})(C?)", raw)
            if m4 and current_sub and m4.group(1).startswith(num + "."):
                current_sub["outcomes"].append({
                    "id": m4.group(1) + m4.group(2),
                    "text": re.sub(r"\s+", " ", m4.group(3)),
                    "beyond_core": bool(m4.group(2))})
            elif m5 and current_sub and m5.group(1).startswith(num + ".") and i + 1 < limit:
                wording = lines[i + 1]
                if wording and wording[0].islower() and len(wording) > 8:
                    current_sub["outcomes"].append({
                        "id": m5.group(1) + m5.group(2),
                        "text": re.sub(r"\s+", " ", wording),
                        "beyond_core": bool(m5.group(2))})
                    i += 2
                    continue
            i += 1

    papers = sorted(set(EDEXCEL_PAPER_CODE.findall(text)))
    res.diagnostics["paper_codes"] = papers
    res.diagnostics["outcomes_extracted"] = sum(len(s.get("outcomes", [])) for s in res.subtopics)
    res.diagnostics["beyond_core_outcomes"] = sum(
        1 for s in res.subtopics for o in s.get("outcomes", []) if o["beyond_core"])
    res.diagnostics["beyond_core_marker"] = (
        "'C' suffix on outcomes = beyond-Core (9-1 tier marker); Paper 2 assesses "
        "content 'in bold and has a C reference'. Preserve, never drop.")
    return res


_SECTION_TITLE_WORDS = re.compile(
    r"\b(principles|inorganic|physical|organic|chemistry|physics|biology|forces|"
    r"electricity|waves|energy|matter|magnetism|radioactivity|particles|"
    r"solids|liquids|gases|resources|transfers|motion)\b", re.I)


def _looks_like_section_title(t: str) -> bool:
    t = (t or "").strip()
    if not (4 < len(t) <= 70) or not t[0].isupper():
        return False
    if t.endswith((".", ",", ":")):
        return False
    if re.match(r"^(Specification|Pearson|Contents|The following|Students should)", t):
        return False
    return bool(_SECTION_TITLE_WORDS.search(t))


def _looks_like_subtopic_title(t: str) -> bool:
    t = (t or "").strip()
    if not (3 < len(t) <= 80) or not t[0].isupper():
        return False
    if t.endswith((",", ":")):
        return False
    if re.match(r"^(Specification|Pearson|Contents|The following|Students should|"
                r"Assessment|Overview|Appendix)", t):
        return False
    return True


# ---------------------------------------------------------------------------
# Shared paper-metadata helpers (component intelligence, directive §10)
# ---------------------------------------------------------------------------
def extract_paper_facts(text: str) -> Dict[str, Any]:
    """Pull board-printed assessment facts out of a specification.

    These become component intelligence for the board adapter — derived from the
    document, never assumed.
    """
    facts: Dict[str, Any] = {}
    head = text[:20000]

    m = re.search(r"Availability:\s*([A-Za-z ,]+)", head)
    if m:
        facts["availability"] = m.group(1).strip()
    m = re.search(r"First assessment:\s*([A-Za-z ]*\d{4})", head)
    if m:
        facts["first_assessment"] = m.group(1).strip()
    m = re.search(r"total number of marks is\s+(\d{1,3})", head)
    if m:
        facts["total_marks"] = int(m.group(1))
    m = re.search(r"(\d{1,2}(?:\.\d)?)% of the total", head)
    if m:
        facts["weighting_pct"] = m.group(1)
    m = re.search(r"(\d)\s*hour(?:s)?\s*(\d{1,2})?\s*(?:minutes)?\s*written examination", head)
    if m:
        facts["duration"] = f"{m.group(1)}h" + (f" {m.group(2)}m" if m.group(2) else "")
    codes = sorted(set(EDEXCEL_PAPER_CODE.findall(head)))
    if codes:
        facts["paper_codes"] = codes
    if re.search(r"multiple-choice", head, re.I):
        facts["contains_multiple_choice"] = True
    if re.search(r"A calculator may be used", head, re.I):
        facts["calculator_allowed"] = True
    return facts


__all__ = ["ExtractResult", "extract_aqa", "extract_edexcel", "extract_paper_facts",
           "AQA_EXPECTED", "EDEXCEL_PAPER_CODE"]
