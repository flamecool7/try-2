"""
universal — the Universal Examination Intelligence Engine layer.

This package sits ON TOP of the existing, proven pipeline. It never replaces it.

    REAL EXAM SOURCES
      -> universal.ingestion   (scan, detect type, resolve identity, relate, manifest)
      -> adapters.<board>      (CAIE / AQA / EDEXCEL / IB / SAT)
      -> universal.extraction  (CALLS the canonical crop engine; never re-crops)
      -> universal.dna         (Question DNA + classification confidence + states)
      -> universal.bank        (index, search, analytics, doctor)
      -> universal.sets / universal.booklets
      -> universal.app         (launcher + CLI)

Canonical crop mechanism (MUST be used, MUST NOT be duplicated):
    core.cropping_engine.CroppingEngine.process_paper
      -> original_reference/cambridge_qb/question_split.py
      -> original_reference/cambridge_qb/multipage_optimizer.py
      -> original_reference/cambridge_qb/webp_utils.py

See docs/decisions/0001-milestone1-inspection-and-architecture.md and
docs/REUSE_MAP.json.
"""
from universal.config import PROJECT_ROOT, Config, load_config, resolve, ensure_dirs

__version__ = "2.0.0"

__all__ = ["PROJECT_ROOT", "Config", "load_config", "resolve", "ensure_dirs", "__version__"]
