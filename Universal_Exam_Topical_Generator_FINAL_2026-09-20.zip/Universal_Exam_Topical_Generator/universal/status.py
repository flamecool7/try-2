"""
universal.status — MASTER STATUS & STATE TAXONOMY

Single source of truth for every status, state and error code used anywhere in
the engine. Spec: UNIVERSAL-EXAM-TOPICAL-GEN-MEGAPROMPT-v2.txt §0.9 and §17.8;
directive §37.

Design rules enforced here:
  * No subsystem may invent its own status vocabulary.
  * A status is never silently downgraded to success.
  * UNKNOWN / SOURCE_NOT_FOUND / REVIEW_REQUIRED are always preferred over
    fabricating an answer (directive §36).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# §0.9.1 Detection / classification status (all subsystems)
# ---------------------------------------------------------------------------
class DetectionStatus(str, Enum):
    CONFIDENT = "CONFIDENT"                  # evidence sufficient; may proceed
    REVIEW_REQUIRED = "REVIEW_REQUIRED"      # insufficient/conflicting evidence
    UNKNOWN = "UNKNOWN"                      # cannot even form candidates
    REJECTED = "REJECTED"                    # hard-rejection condition met
    QUARANTINED = "QUARANTINED"              # held with reason + evidence


# ---------------------------------------------------------------------------
# §0.9.2 Question pipeline state machine (forward transitions only)
# ---------------------------------------------------------------------------
class QuestionState(str, Enum):
    INGESTED = "INGESTED"
    IDENTIFIED = "IDENTIFIED"
    DETECTED = "DETECTED"
    BOUNDARIED = "BOUNDARIED"
    CROPPED = "CROPPED"
    RASTER_VALIDATED = "RASTER_VALIDATED"
    REVERSE_VALIDATED = "REVERSE_VALIDATED"
    CLASSIFIED = "CLASSIFIED"
    DEDUPLICATED = "DE-DUPLICATED"
    COMMITTED = "COMMITTED"
    GOLDEN_APPROVED = "GOLDEN_APPROVED"      # immutable; never auto-overwritten
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    QUARANTINED = "QUARANTINED"
    REJECTED = "REJECTED"


_FORWARD_ORDER: List[QuestionState] = [
    QuestionState.INGESTED,
    QuestionState.IDENTIFIED,
    QuestionState.DETECTED,
    QuestionState.BOUNDARIED,
    QuestionState.CROPPED,
    QuestionState.RASTER_VALIDATED,
    QuestionState.REVERSE_VALIDATED,
    QuestionState.CLASSIFIED,
    QuestionState.DEDUPLICATED,
    QuestionState.COMMITTED,
    QuestionState.GOLDEN_APPROVED,
]
_SIDE_STATES = {
    QuestionState.REVIEW_REQUIRED,
    QuestionState.QUARANTINED,
    QuestionState.REJECTED,
}


def can_transition(src: QuestionState, dst: QuestionState) -> bool:
    """Forward-only transitions; any stage may divert to a side state.

    A question may NOT skip RASTER_VALIDATED or REVERSE_VALIDATED (§0.9.2).
    """
    if dst in _SIDE_STATES:
        return True
    if src in _SIDE_STATES:
        # Recovery out of a side state re-enters the pipeline, it does not jump
        # ahead of the gate it failed.
        return dst in (QuestionState.INGESTED, QuestionState.IDENTIFIED)
    if src not in _FORWARD_ORDER or dst not in _FORWARD_ORDER:
        return False
    if dst == src:
        return True
    i, j = _FORWARD_ORDER.index(src), _FORWARD_ORDER.index(dst)
    if j < i:
        return False
    # No skipping the two mandatory validation gates.
    for gate in (QuestionState.RASTER_VALIDATED, QuestionState.REVERSE_VALIDATED):
        if i < _FORWARD_ORDER.index(gate) <= j and src != gate:
            # allowed only if the caller passes through the gate explicitly
            if j > _FORWARD_ORDER.index(gate):
                return False
    return True


# ---------------------------------------------------------------------------
# §0.9.3 Classification status  (directive §16)
# ---------------------------------------------------------------------------
class ClassificationState(str, Enum):
    AUTO_CLASSIFIED = "AUTO_CLASSIFIED"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    HUMAN_VERIFIED = "HUMAN_VERIFIED"
    HUMAN_CORRECTED = "HUMAN_CORRECTED"


# §0.9.4 Subject support status — never claim SUPPORTED without evidence
class SubjectSupport(str, Enum):
    NOT_STARTED = "NOT_STARTED"
    RESEARCHED = "RESEARCHED"
    TAXONOMY_BUILT = "TAXONOMY_BUILT"
    IMPLEMENTED_PENDING_VALIDATION = "IMPLEMENTED_PENDING_VALIDATION"
    VALIDATION_FAILED = "VALIDATION_FAILED"
    CLASSIFIER_PENDING = "CLASSIFIER_PENDING"
    SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"
    SUPPORTED = "SUPPORTED"


# ---------------------------------------------------------------------------
# §0.9.5 Source availability — never converted into fabricated evidence
# ---------------------------------------------------------------------------
class SourceAvailability(str, Enum):
    AVAILABLE = "AVAILABLE"
    UNAVAILABLE = "UNAVAILABLE"
    SOURCE_NOT_FOUND = "SOURCE_NOT_FOUND"
    SOURCE_NOT_ACCESSIBLE = "SOURCE_NOT_ACCESSIBLE"


# ---------------------------------------------------------------------------
# §0.9.6 Supporting-material status (per question, per material type)
# ---------------------------------------------------------------------------
class MaterialStatus(str, Enum):
    ATTACHED = "ATTACHED"
    VERIFIED_UNAVAILABLE = "VERIFIED_UNAVAILABLE"
    UNMATCHED = "UNMATCHED"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"


# ---------------------------------------------------------------------------
# Directive §37 — run/batch outcome statuses
# ---------------------------------------------------------------------------
class RunStatus(str, Enum):
    SUCCESS = "SUCCESS"
    WARNING = "WARNING"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    IDENTITY_CONFLICT = "IDENTITY_CONFLICT"
    SOURCE_NOT_FOUND = "SOURCE_NOT_FOUND"
    SOURCE_NOT_ACCESSIBLE = "SOURCE_NOT_ACCESSIBLE"
    PROCESSING_ERROR = "PROCESSING_ERROR"
    CORRUPTED_INPUT = "CORRUPTED_INPUT"
    OCR_UNAVAILABLE = "OCR_UNAVAILABLE"


# ---------------------------------------------------------------------------
# §15 Question types
# ---------------------------------------------------------------------------
QUESTION_TYPES: List[str] = [
    "MCQ", "CALCULATION", "SHORT_ANSWER", "STRUCTURED", "ESSAY", "EXPLANATION",
    "DATA_ANALYSIS", "GRAPH", "DIAGRAM", "PROOF", "DERIVATION", "EXPERIMENTAL",
    "PRACTICAL", "PLANNING", "MIXED", "OTHER",
]

DIFFICULTY_LEVELS: List[str] = ["easy", "medium", "hard"]

# Document types (§3 / directive §18)
DOCUMENT_TYPES: List[str] = ["QP", "MS", "ER", "INSERT", "SYLLABUS", "UNKNOWN"]


# ---------------------------------------------------------------------------
# §17.8 Structured error codes: E-<STAGE>-<NNN>
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ErrorCode:
    code: str
    stage: str
    severity: str          # fatal | error | warning | info
    action: str            # what the engine/user does next
    message: str

    def as_dict(self) -> Dict[str, str]:
        return {"code": self.code, "stage": self.stage, "severity": self.severity,
                "action": self.action, "message": self.message}


ERROR_CODES: Dict[str, ErrorCode] = {}


def _reg(code: str, severity: str, action: str, message: str) -> ErrorCode:
    stage = code.split("-")[1]
    ec = ErrorCode(code=code, stage=stage, severity=severity, action=action, message=message)
    ERROR_CODES[code] = ec
    return ec


# -- INGEST ------------------------------------------------------------------
_reg("E-INGEST-001", "error",   "quarantine, preserve, report",        "corrupt PDF")
_reg("E-INGEST-002", "error",   "quarantine, report (user may supply key)", "encrypted PDF")
_reg("E-INGEST-003", "warning", "REVIEW_REQUIRED",                     "detection conflict (board)")
_reg("E-INGEST-004", "warning", "REVIEW_REQUIRED",                     "detection conflict (document type)")
_reg("E-INGEST-005", "warning", "REVIEW_REQUIRED",                     "detection conflict (year/session/component)")
_reg("E-INGEST-006", "warning", "OCR fallback then REVIEW_REQUIRED",   "no text layer (image-only document)")
_reg("E-INGEST-007", "warning", "degrade gracefully, continue",        "OCR backend unavailable")
_reg("E-INGEST-008", "info",    "record SOURCE_NOT_FOUND",             "source document not found")
# -- PAGE --------------------------------------------------------------------
_reg("E-PAGE-001",   "warning", "review",                              "page classification low confidence")
_reg("E-PAGE-002",   "error",   "retry, then review",                  "barcode removal failed")
# -- QUESTION ----------------------------------------------------------------
_reg("E-Q-001",      "warning", "investigate + log",                   "numbering gap")
_reg("E-Q-002",      "warning", "investigate + log",                   "numbering duplicate")
_reg("E-Q-003",      "warning", "keep as ONE logical question",        "multi-page question detected")
# -- CROP --------------------------------------------------------------------
_reg("E-CROP-001",   "error",   "recalculate (auto, <=3-5 retries)",   "top clipping detected")
_reg("E-CROP-002",   "error",   "reject -> diagnose -> retry -> review","hard-rejection condition")
_reg("E-CROP-003",   "warning", "REVIEW_REQUIRED",                     "detector disagreement")
_reg("E-CROP-004",   "error",   "REVIEW_REQUIRED (invariant breach)",  "final width != 2280")
# -- CLASSIFICATION ----------------------------------------------------------
_reg("E-CLASS-001",  "warning", "REVIEW_REQUIRED",                     "classifier disagreement")
_reg("E-CLASS-002",  "error",   "REJECT classification",               "topic not in active taxonomy")
_reg("E-CLASS-003",  "warning", "REVIEW_REQUIRED",                     "confidence below min_confident")
# -- MATCHING ----------------------------------------------------------------
_reg("E-MATCH-001",  "warning", "unmatched_mark_schemes/",             "mark scheme confidence low")
_reg("E-MATCH-002",  "warning", "REVIEW_REQUIRED",                     "examiner report association weak")
# -- OUTPUT / DB -------------------------------------------------------------
_reg("E-OUT-001",    "error",   "quarantine + full log",               "atomic commit failed")
_reg("E-OUT-002",    "error",   "block write",                         "forbidden artefact in question folder")
_reg("E-DB-001",     "error",   "integrity check + repair report",     "index/file inconsistency")
# -- DOWNLOADER --------------------------------------------------------------
_reg("E-DL-001",     "info",    "record SOURCE_NOT_FOUND",             "no source URL resolved")
_reg("E-DL-002",     "warning", "record SOURCE_NOT_ACCESSIBLE",        "source unreachable / blocked")
_reg("E-DL-003",     "error",   "reject download, quarantine",         "downloaded file is not what it claimed")


# ---------------------------------------------------------------------------
# Finding — the unit every subsystem reports in
# ---------------------------------------------------------------------------
@dataclass
class Finding:
    """A single structured diagnostic. Never raise bare strings."""
    code: str
    status: RunStatus = RunStatus.WARNING
    detail: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    confidence: Optional[float] = None

    def __post_init__(self) -> None:
        if self.code not in ERROR_CODES:
            # Unregistered codes are allowed but flagged: they indicate a
            # subsystem inventing vocabulary, which §17.8 forbids.
            self.context.setdefault("_unregistered_code", True)

    @property
    def severity(self) -> str:
        ec = ERROR_CODES.get(self.code)
        return ec.severity if ec else "warning"

    @property
    def action(self) -> str:
        ec = ERROR_CODES.get(self.code)
        return ec.action if ec else "review"

    def as_dict(self) -> Dict[str, Any]:
        return {"code": self.code, "status": self.status.value,
                "severity": self.severity, "action": self.action,
                "detail": self.detail, "confidence": self.confidence,
                "context": self.context}


__all__ = [
    "DetectionStatus", "QuestionState", "ClassificationState", "SubjectSupport",
    "SourceAvailability", "MaterialStatus", "RunStatus", "ErrorCode",
    "ERROR_CODES", "Finding", "can_transition",
    "QUESTION_TYPES", "DIFFICULTY_LEVELS", "DOCUMENT_TYPES",
]
