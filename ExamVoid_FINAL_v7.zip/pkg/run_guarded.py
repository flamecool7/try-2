#!/usr/bin/env python3
"""run_guarded.py — self-checking orchestration runner (2026-08-10, user-approved:
"check itself every step" mode, wrapper architecture).

Runs the locked pipeline stage-by-stage with hard gates BETWEEN every stage.
Any failed check inside a stage aborts the run ON THE SPOT with a loud banner
naming the stage + every failed check + a failure_report.txt — downstream
stages never execute, and nothing half-built is treated as output.

    python3 run_guarded.py --input papers --output output [--clean] [--low-ram]

Exit codes: 0 = every stage green and no review-required output. 1 = a stage gate failed (see banner/report). 2 = the run completed safely but one or more question folders require human review.
This file changes NO locked source: it only calls the same public functions
main.py calls.

Architecture notes
------------------
* Each QP+MS paper bundle runs in its own subprocess ("paper worker"). Peak
  heap stays around ~950MB inside one worker and dies with it, instead of
  accumulating across papers (glibc retains freed heap: one 16+ page paper
  leaves ~935MB RSS that a second paper then kills against — exit 137 in this
  ~2GB sandbox). A worker crash (incl. SIGKILL/137) is surfaced by the parent
  as a loud failed gate naming the paper, not a silent empty log.
* QP paths (loudly reported at start):
    default   : CroppingEngine.process_paper.
    --low-ram : bundled vector-first QP cropping. PDF text/vector geometry is
                analyzed first and final question clips are spooled one at a
                time; QP/MS pairing is by exact question number.
* Width contract: engines may return content-width rasters (MS 1501px); the
  locked OutputManager scales to exactly 2280 at save. The hard 2280 gate
  lives in S5 on the saved files — where production actually guarantees it.
"""
import argparse
import gc
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))
logging.basicConfig(level=logging.WARNING)

import numpy as np

MIN_HEIGHT_PX = 80
TARGET_WIDTH = 2280
INK_MIN_FRAC = 0.0005


def qp_min_height_px(qp_info) -> int:
    """Per-paper sanity floor for QP crop height.

    Keep the default 80px floor everywhere unless we have specific evidence.
    IGCSE Mathematics 0580 Paper 2 can contain legitimate very short structured
    one-liners whose clean crops land in the high-60s / 70s px range at the
    final 2280px width; those should not fail the whole paper when they still
    contain ink and extracted text. This is a guard-only change, not a crop
    algorithm change.
    """
    code = str(getattr(qp_info, "syllabus_code", "") or "")
    if code == "0580":
        return 60
    return MIN_HEIGHT_PX

ALL_STAGES = [
    ("S0", "environment + config validation"),
    ("S1", "paper identification + subject separation"),
    ("S2", "QP crop (gold-standard splitter)"),
    ("S3", "MS crop (LOCKED exact splitter)"),
    ("S4", "QP/MS grouping + pairing"),
    ("S5", "classify + save question pairs"),
    ("S6", "examiner-report text attachment"),
    ("S7", "examiner-report per-question crops"),
    ("S8", "final validation + output audit"),
]

WORKER_OK = re.compile(r"WORKER-RESULT saved=(\d+) base=(\S+)")


class StageAbort(Exception):
    pass


def _rss_mb() -> int:
    try:
        with open("/proc/self/statm") as fh:
            pages = int(fh.read().split()[1])
        return pages * 4096 // (1024 * 1024)
    except Exception:
        return -1


class _NullState:
    """State API no-op for child workers spawned by pipeline.py (U1).

    In parallel mode the PARENT owns .pipeline_state.json; children must never
    read-modify-write it concurrently (corruption risk). should_skip() is
    always False because the parent pre-filters before spawning.
    """

    def __init__(self, real_state=None):
        self._real = real_state

    def register_paper(self, *a, **k):
        return None

    def should_skip(self, paper_code) -> bool:
        return False

    def mark_processing(self, paper_code):
        return None

    def mark_complete(self, paper_code, questions_found, questions_saved):
        return None

    def mark_failed(self, paper_code, error):
        return None

    def save(self, output_dir):
        return None

    def print_summary(self):
        return None


class Gate:
    """Collects checks for one stage; abort() ends the run loudly on any fail."""

    def __init__(self, output_root: Path):
        self.output_root = Path(output_root)
        self.stage_results = []

    def run_stage(self, sid: str, name: str, fn, *, abort_on_fail: bool = True):
        checks = []

        def check(nm, ok, detail=""):
            checks.append((nm, bool(ok), str(detail)))
            print(f"    [{'PASS' if ok else 'FAIL'}] {nm}: {detail}")

        print(f"\n=== STAGE {sid} — {name} ===")
        try:
            result = fn(check)
            print(f"  [mem] current RSS after {sid}: {_rss_mb()} MB")
        except StageAbort:
            raise
        except Exception as exc:  # crash containment: exception becomes a failed gate, not a traceback
            import traceback
            tb = traceback.format_exc(limit=3)
            check(f"stage crashed: {type(exc).__name__}", False, f"{exc} | {tb.splitlines()[-1] if tb else ''}")
            result = None

        fails = [(n, d) for n, ok, d in checks if not ok]
        if fails and abort_on_fail:
            self._abort(sid, name, checks, fails)
        self.stage_results.append((sid, name, checks))
        if fails:
            print(f"  -> STAGE {sid} SOFT-FAIL captured ({len(fails)} failed checks; continuing)")
        else:
            print(f"  -> STAGE {sid} OK ({len(checks)} checks)")
        return result

    def _abort(self, sid, name, checks, fails):
        print()
        print("!" * 64)
        print(f"  XXX RUN FAILED XXX — stopped at STAGE {sid}: {name}")
        print("!" * 64)
        print("  Failed checks:")
        for i, (n, d) in enumerate(fails, 1):
            print(f"    {i}. {n}" + (f"   ->  {d}" if d else ""))
        print()
        print("  Downstream stages did NOT run. Nothing half-built is treated as output.")
        self.output_root.mkdir(parents=True, exist_ok=True)
        rp = self.output_root / "failure_report.txt"
        lines = [
            f"failure_report  —  {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"run_guarded stopped at STAGE {sid}: {name}",
            f"failed {len(fails)}/{len(checks)} checks in this stage",
            "",
        ] + [f"FAIL  {n}: {d}" for n, d in fails]
        rp.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"  report written: {rp}")
        print("!" * 64)
        sys.exit(1)

    def finish_all(self, title="", worker=False, paper_failures=None):
        """Finish only after distinguishing clean output from safe review output.

        A review-required question is not a stage failure: its crop is kept and
        the run is internally consistent. It is also not an all-green run.
        Exit code 2 makes that distinction machine-readable for batch scripts.

        `paper_failures` is an optional list of per-bundle hard failures that
        were recorded but tolerated so the rest of the batch could continue.
        When present, the run ends with exit 1 AFTER all remaining bundles and
        post-processing stages have finished, and the user gets a specific
        failed-papers report instead of a first-error abort.
        """
        total = sum(len(c) for _, _, c in self.stage_results)
        review_roots = {"review_required", "review_required_no_ms"}
        review_dirs = [
            path for path in self.output_root.rglob("*")
            if path.is_dir() and any(part in review_roots for part in path.parts)
        ]
        # A historical-year review can legitimately keep its question folders
        # in normal topic directories.  Read the guarded state file as a
        # second review signal so direct run_guarded mode cannot print ALL
        # GREEN merely because no sentinel folder was needed.
        state_review = False
        state_file = self.output_root / ".pipeline_state.json"
        if state_file.exists():
            try:
                payload = json.loads(state_file.read_text(encoding="utf-8"))
                state_review = any(
                    "review" in str(record.get("status", "")).lower()
                    for record in payload.get("papers", {}).values()
                )
            except Exception:
                state_review = False
        paper_failures = list(paper_failures or [])
        stale = self.output_root / "failure_report.txt"
        if stale.exists() and not paper_failures:
            stale.unlink()
            print("  (cleared stale failure_report.txt from an earlier failed run)")

        print()
        print("=" * 64)
        if paper_failures:
            print(f"  *** RUN COMPLETE — SOME PAPERS FAILED ***  "
                  f"{len(self.stage_results)} stages, {total} checks executed")
            print(f"  failed paper bundles: {len(paper_failures)}")
            if review_dirs or state_review:
                print(f"  review-required directories: {len(review_dirs)}"
                      + (" (plus a review-required state record)" if state_review else ""))
            if title:
                print(f"  —  {title}")
            print("  Successful papers were kept. Failed papers are listed in failed_papers_report.txt.")
            print("=" * 64)
            raise SystemExit(1)

        if review_dirs or state_review:
            print(f"  *** RUN COMPLETE — REVIEW REQUIRED ***  "
                  f"{len(self.stage_results)} stages, {total} checks passed")
            print(f"  review-required directories: {len(review_dirs)}"
                  + (" (plus a review-required state record)" if state_review else ""))
            if title:
                print(f"  —  {title}")
            print("  Crops were preserved safely; do not treat this batch as complete.")
            print("=" * 64)
            # A child worker communicates its safe-but-review verdict through
            # the committed output and WORKER-RESULT marker.  It must exit 0
            # so the parent can finish ER/audit stages and return the batch
            # contract's exit code 2.  Only the top-level runner exits 2.
            if worker:
                return 0
            raise SystemExit(2)

        print(f"  *** ALL GREEN ***  {len(self.stage_results)} stages, {total} checks passed" +
              (f"  —  {title}" if title else ""))
        print("=" * 64)
        raise SystemExit(0)


def ink_frac(img) -> float:
    a = np.asarray(img.convert("L"))
    return float((a < 200).mean())


def question_image(cq):
    return getattr(cq, "assembled_image", None) or cq.images[0]


MS_MIN_HEIGHT_PX = 40  # RS-16: real one-line MS rows measure 50-78px @150dpi (0580 evidence)

# Cambridge occasionally retracts a question mid-paper and prints a one-line
# notice instead ("Due to an issue with question 14, the question has been
# removed from the question paper." — real 0625_s24_qp_21 Q14). Such a crop
# is legitimately tiny: the height floor must not fail it, or the whole paper
# bundle dies with exit code 1 for a normal paper.
_REMOVED_QUESTION_RE = re.compile(
    r"\bquestion\b[^.\n]{0,80}?\bremoved\b|\bremoved\b[^.\n]{0,80}?\bquestion\b",
    re.IGNORECASE,
)


def _is_removed_question(crop) -> bool:
    text = getattr(crop, "text", "") or ""
    return bool(_REMOVED_QUESTION_RE.search(text))


def check_crop_list(check, label, crops, *, list_level=True, pixel=True,
                    min_height=MIN_HEIGHT_PX):
    if list_level:
        check(f"{label}: at least 1 question", len(crops) >= 1, f"{len(crops)} questions")
        nums = [c.number_int for c in crops]
        check(f"{label}: question numbers unique", len(set(nums)) == len(nums),
              f"{sorted(nums)}")
    if not pixel:
        return
    # NOTE: engines may return content-width rasters (e.g. MS 1501px); the
    # locked OutputManager scales to exactly 2280 at save — the hard width
    # gate lives in S5 on the saved files. Here: sane-raster checks only.
    for c in crops:
        img = question_image(c)
        check(f"{label} {c.question_number}: sane raster", img.width >= 1000,
              f"{img.size} (scaled to 2280 at save)")
        _removed = _is_removed_question(c)
        check(f"{label} {c.question_number}: height >= {min_height}",
              img.height >= min_height or _removed,
              f"{img.size}{' (Cambridge removal notice — legitimately short)' if _removed else ''}")
        frac = ink_frac(img)
        check(f"{label} {c.question_number}: has ink", frac > INK_MIN_FRAC, f"dark={frac:.5f}")


def qp_crops_low_ram(qp_info, spool=None) -> list:
    """Built-in RAM-safe vector-first QP cropper.

    The old implementation imported a developer-only module that was absent
    from normal checkouts. The production worker now uses the bundled
    vector-first cropper, which renders direct question clips and leaves each
    WebP on disk until S5 needs that individual question.
    """
    from core.vector_first_cropper import CambridgeCropper

    spool_root = Path(spool or _spool_dir())
    crop_root = spool_root / "vector_qp"
    crop_root.mkdir(parents=True, exist_ok=True)
    analysis, results = CambridgeCropper(crop_root, quality=95).crop_qp(Path(qp_info.file_path))
    out = []
    for result in results:
        paths = [str(Path(path)) for path in result.image_paths]
        if not paths:
            continue
        text = result.text or ""
        marks = sum(int(mm) for mm in re.findall(r"\[(\d+)\]", text))
        out.append(SimpleNamespace(
            question_number=f"Q{result.number}", number_int=result.number,
            paper_code=qp_info.full_code,
            images=[], assembled_image=None,
            text=text, marks=marks, pages=result.pages,
            needs_review=(result.status != "PASS"),
            qc_reasons=list(result.warnings),
            _spool_png=paths[0], _spool_paths=paths,
        ))
    print(f"    [low-ram] vector-first extracted {len(out)} questions "
          f"from {qp_info.file_path.name}; analysis={analysis.elapsed_ms:.1f}ms")
    return out


def low_ram_qp_with_fallback(qp_info, subject: str, cropping_engine, spool=None) -> list:
    """Use vector-first first, but rescue known 0580 weak layouts by retrying
    the locked production cropper before failing the paper.

    This does NOT change any crop algorithm: it only chooses between two
    existing, already-shipped crop paths when the low-ram metadata pass for
    IGCSE Mathematics 0580 returns an implausibly small set.
    """
    qp_cropped = qp_crops_low_ram(qp_info, spool=spool)
    if str(getattr(qp_info, "syllabus_code", "")) != "0580":
        return qp_cropped
    if len(qp_cropped) >= 5:
        return qp_cropped
    print(f"    [low-ram] 0580 fallback: vector-first yielded {len(qp_cropped)} question(s); retrying locked CroppingEngine")
    try:
        fallback = cropping_engine.process_paper(qp_info.file_path)
    except Exception as exc:
        print(f"    [low-ram] 0580 fallback failed closed: {exc}")
        return qp_cropped
    if fallback:
        print(f"    [low-ram] 0580 fallback recovered {len(fallback)} question(s) via locked CroppingEngine")
        return fallback
    print("    [low-ram] 0580 fallback produced 0 questions; keeping vector-first result")
    return qp_cropped

def pair_low_ram(qp_list, ms_list, qp_info, ms_info, subject):
    """Question-number pairing producing match_questions-compatible objects."""
    ms_by_q = {m.number_int: m for m in ms_list}
    out = []
    for q in sorted(qp_list, key=lambda c: c.number_int):
        mo = ms_by_q.get(q.number_int)
        if mo is None:
            continue
        out.append(SimpleNamespace(
            question_number=q.question_number, number_int=q.number_int,
            qp=q, ms=mo,
            paper_code=f"{qp_info.syllabus_code}_{qp_info.season_letter}{qp_info.year_short}",
            full_qp_code=qp_info.full_code, full_ms_code=ms_info.full_code,
            year=qp_info.year, season=qp_info.season, variant=qp_info.variant,
            subject=subject.split("_")[0],
        ))
    return out


def _spool_dir():
    import tempfile
    return Path(tempfile.mkdtemp(prefix="qb_spool_"))


def _spool_crops(crops, spool, tag):
    """RS-16 low-ram: park assembled pixel payloads as lossless PNGs so S2/S3
    peaks stay flat on multi-page structured papers (assembled question
    images can reach 2280x10000+). PNG is pixel-exact -> the webp bytes saved
    at S5 are unchanged. Verified byte-identical on the 0620 MCQ oracle."""
    n = 0
    for i, c in enumerate(crops or []):
        img = getattr(c, "assembled_image", None)
        if img is None and getattr(c, "images", None):
            img = c.images[0]
        if img is None:
            continue
        p = spool / f"{tag}_{i:03d}.png"
        img.save(p, format="PNG")
        c._spool_png = str(p)
        c.assembled_image = None
        if getattr(c, "images", None):
            c.images = []
        n += 1
    if n:
        print(f"    [low-ram] spooled {n} {tag} crop payload(s) -> {spool.name}/ (PNG pixel-exact)")
    gc.collect()


def _unspool(crop):
    p = getattr(crop, "_spool_png", None) if crop is not None else None
    if p and getattr(crop, "assembled_image", None) is None:
        from PIL import Image as _Img
        with _Img.open(p) as im:
            img = im.convert("RGB")
        crop.assembled_image = img
        if not getattr(crop, "images", None):
            crop.images = [img]


def _heap_trim():
    """RS-16/17: return freed glibc arena pages to the OS so a question's
    released pixels actually drop RSS instead of lingering as reusable arena.
    Best-effort no-op off glibc."""
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


def _release(crop):
    if crop is not None and getattr(crop, "_spool_png", None):
        crop.assembled_image = None


def run_paper_stages(gate, args, base_key, qp_info, ms_info, subject, config, state,
                     cropping_engine, ms_cropping_engine, matcher, output_mgr):
    """S2 -> S3 -> S4-pair -> S5 for ONE paper bundle. Returns saved count."""
    from core.classifier import TopicClassifier

    state.register_paper(base_key, qp_path=str(qp_info.file_path),
                         ms_path=str(ms_info.file_path) if ms_info else None, er_path=None)
    # ROT-1 (rotation-handling round): sideways-display normalization.
    # Only pages whose DISPLAYED text runs vertically (/Rotate set on
    # upright-authored content) are re-baked to upright rotation=0 copies
    # under <output>/.rotcache/; Cambridge-style rotated files and all
    # rotation=0 inputs pass through UNTOUCHED (proven: detector votes
    # 142:16 sideways on the case-A probe, 0:39..7:130 on real ms_42).
    # Provenance above deliberately keeps the ORIGINAL paths.
    from core.page_rotation import ensure_upright
    _rotcache = Path(args.output) / ".rotcache"
    qp_info.file_path, _ = ensure_upright(qp_info.file_path, _rotcache)
    if ms_info is not None:
        ms_info.file_path, _ = ensure_upright(ms_info.file_path, _rotcache)
    if state.should_skip(base_key):
        print(f"    [guarded] RESUME-SKIP {base_key}")
        return -1
    state.mark_processing(base_key)

    # ---------- S2 QP crop ----------
    _spool = None

    def s2(check):
        if args.low_ram:
            nonlocal _spool
            _spool = _spool_dir()
            qp_cropped = low_ram_qp_with_fallback(qp_info, subject, cropping_engine, spool=_spool)
            _min_h = qp_min_height_px(qp_info)
            # list-level gates on metadata; pixel gates reload ONE crop at a
            # time from the pixel-exact spool (flat RAM, same texts/semantics)
            check_crop_list(check, f"QP {qp_info.full_code}", qp_cropped, pixel=False,
                            min_height=_min_h)
            for _c in qp_cropped:
                _unspool(_c)
                check_crop_list(check, f"QP {qp_info.full_code}", [_c], list_level=False,
                                min_height=_min_h)
                _release(_c)
            gc.collect()
        else:
            qp_cropped = cropping_engine.process_paper(qp_info.file_path)
            check_crop_list(check, f"QP {qp_info.full_code}", qp_cropped,
                            min_height=qp_min_height_px(qp_info))
        for c in qp_cropped:
            check(f"QP {qp_info.full_code} {c.question_number}: text extracted",
                  bool((c.text or "").strip()), f"{len(c.text or '')} chars")
        return qp_cropped

    qp_cropped = gate.run_stage("S2", f"{ALL_STAGES[2][1]} [{qp_info.full_code}]", s2)
    gc.collect()

    # ---------- S3 MS crop ----------
    # Mega-spec Fix 4 (2026-08-12): the MS/QP branch decision comes from the
    # strategy registry (profile + component), not an inline format string
    # check. Practical/essay components surface REVIEW_REQUIRED here instead of
    # being fed to the structured parser.
    from core.strategies import (StrategyUnsupported, select_ms_strategy,
                                 strategy_plan_for_paper)
    try:
        _ms_strategy = select_ms_strategy(qp_info, ms_info)
        _plan = strategy_plan_for_paper(qp_info)
        print(f"    [strategy] {base_key}: {_plan.name} — {_plan.reason}")
    except StrategyUnsupported as _exc:
        print(f"    [strategy] {base_key}: {_exc.review_reason}")
        state.mark_review_required(base_key, _exc.review_reason)
        state.save(Path(args.output))
        gate._abort("S3", f"strategy selection [{base_key}]",
                    [], [("supported strategy exists", _exc.review_reason)])
    _is_mcq = _ms_strategy is not None and _ms_strategy.name == "mcq_ms_grid"
    _mcq_answers = None
    if ms_info is None:
        # Overseer RULE 2: no MS paper at all - QP-only mode
        print(f"    [guarded] {base_key}: no MS supplied - QP-only mode")
        ms_cropped = []
    elif _is_mcq:
        # IGCSE paper-format round (user decision mcq_ms=letters): MCQ mark
        # schemes carry a bare answer grid — extract letters, crop nothing.
        def s3(check):
            answers = ms_cropping_engine.extract_mcq_answers(ms_info.file_path)
            check("MCQ answer grid extracted (fail-closed on empty)", len(answers) > 0,
                  f"{len(answers)} answers")
            exp = getattr(qp_info, "expected_question_count", None)
            if exp is not None:
                # counts=advisory (user decision): measured, never a gate
                print(f"    [advisory] {base_key}: expected {exp} MCQ grid answers, parsed {len(answers)}")
            return answers

        _mcq_answers = gate.run_stage("S3", f"MCQ answer grid [{ms_info.full_code}]", s3)
        ms_cropped = []
    else:
        def s3(check):
            # Give the structured splitter the already-proven QP top-level
            # question numbers.  A missing trailing mark-scheme question is
            # then diagnosed explicitly instead of disappearing silently.
            _expected_ms_questions = [c.number_int for c in qp_cropped]
            ms_cropped = ms_cropping_engine.process_paper(
                ms_info.file_path,
                expected_questions=_expected_ms_questions,
            )
            _expected = [c.number_int for c in qp_cropped]
            _found = {c.number_int for c in ms_cropped}
            if _found != set(_expected):
                # Gold remains first.  If it returns a partial set (the older
                # 0580 portrait table has one header page and continuation
                # pages without headers), do not accept the partial MS: try a
                # QP-proven portrait-column splitter that must recover the
                # complete number set.
                from core.legacy_ms_split import (
                    split_portrait_column_ms,
                    split_legacy_portrait_ms,
                )
                from core.ms_cropping_engine import MSCroppedQuestion

                print(f"    [MS-legacy] gold coverage {sorted(_found)} != "
                      f"QP coverage {_expected} — trying portrait-column fallback")
                _pieces, _diag = split_portrait_column_ms(
                    ms_info.file_path, dpi=ms_cropping_engine.dpi,
                    expected_top_numbers=_expected)
                if not _pieces:
                    # RS-16 A-Level portrait grammar fallback.  This remains
                    # strict 1..N + exact QP identity and therefore cannot turn
                    # a random number column into a mark scheme.
                    _pieces, _diag = split_legacy_portrait_ms(
                        ms_info.file_path, dpi=ms_cropping_engine.dpi,
                        expected_top_numbers=_expected)
                if _pieces:
                    ms_cropped = [MSCroppedQuestion(
                        question_number=f"Q{q}", number_int=q,
                        paper_code=ms_info.file_path.stem,
                        images=[img], assembled_image=img,
                        text=f"Mark scheme for question {q}",
                        marks=0, pages=[])
                        for q, img in sorted(_pieces.items())]
                    print(f"    [MS-legacy] portrait fallback produced {len(ms_cropped)} crops "
                          f"(QP-validated exact set; sig: "
                          f"{_diag.split_notes[0] if _diag.split_notes else '?'})")
                else:
                    print(f"    [MS-legacy] portrait fallbacks refuse "
                          f"{_diag.warnings[-1][:120] if _diag.warnings else ''} — fail-closed stands")
            check_crop_list(check, f"MS {ms_info.full_code}", ms_cropped,
                            min_height=MS_MIN_HEIGHT_PX)
            return ms_cropped

        if args.low_ram:
            print(f"    [mem] S3 entry RSS {_rss_mb()} MB")  # RS-16 trace
        ms_cropped = gate.run_stage("S3", f"{ALL_STAGES[3][1]} [{ms_info.full_code}]", s3)

    # In low-RAM mode question pixels stay spooled. S4 validates identity and
    # question-number coverage from metadata; S5 reloads one crop at a time.
    # Do not unspool the whole paper just to run pair validation.

    # ---------- S4 pair coverage ----------
    def s4b(check):
        if _is_mcq:
            # IGCSE paper-format round: pair each crop with its grid letter
            # (ms=None + ms_answer=letter — the letter IS the mark scheme).
            stubs = [SimpleNamespace(question_number=c.question_number, number_int=c.number_int,
                                     qp=c, ms=None, ms_answer=_mcq_answers.get(c.number_int),
                                     paper_code=base_key,
                                     full_qp_code=qp_info.full_code, full_ms_code=ms_info.full_code,
                                     year=qp_info.year, season=qp_info.season,
                                     variant=qp_info.variant, subject=subject.split("_")[0])
                     for c in qp_cropped]
            valid = [s for s in stubs if s.ms_answer is not None]
            answered = {s.number_int for s in valid}
            unmatched_qp = [c for c in qp_cropped if c.number_int not in answered]
            check("MCQ: every cropped QP question paired with a grid letter or review_required-bound",
                  len(valid) + len(unmatched_qp) == len(qp_cropped),
                  f"answered {len(valid)} + unanswered {len(unmatched_qp)} = {len(qp_cropped)}")
            qn = [m.question_number for m in valid]
            check("MCQ: no question paired twice", len(set(qn)) == len(qn), qn)
            if unmatched_qp:
                print(f"    [info] {base_key}: {len(unmatched_qp)} MCQ question(s) without grid letter -> review_required/no_markscheme")
            return valid, unmatched_qp
        if ms_info is None:
            from types import SimpleNamespace as _SN0
            stubs = [_SN0(question_number=c.question_number, number_int=c.number_int,
                          qp=c, ms=None, paper_code=base_key,
                          full_qp_code=qp_info.full_code, full_ms_code=None,
                          year=qp_info.year, season=qp_info.season,
                          variant=qp_info.variant, subject=subject.split("_")[0])
                     for c in qp_cropped]
            check("QP-only mode: every QP question staged for review_required", True,
                  f"{len(stubs)} questions")
            return stubs, []
        if args.low_ram:
            matched = pair_low_ram(qp_cropped, ms_cropped, qp_info, ms_info, subject)
            # Pairing is by exact bundle identity + question number. Pixel
            # validation is intentionally deferred to S5, where one spooled
            # crop is loaded at a time.
            valid = [m for m in matched
                     if m.qp is not None and m.ms is not None
                     and m.qp.number_int == m.ms.number_int]
            errors = [] if len(valid) == len(matched) else ["metadata pair mismatch"]
        else:
            matched = matcher.match_questions(qp_cropped, ms_cropped, qp_info, ms_info, subject)
            valid, errors = matcher.validate_pairs(matched)
        check("no pair-validation errors", len(errors) == 0,
              str(errors) if errors else "clean")
        paired_ints = {m.number_int for m in valid}
        unmatched_qp = [c for c in qp_cropped if c.number_int not in paired_ints]
        check("every cropped QP question accounted (paired or review_required-bound)",
              len(valid) + len(unmatched_qp) == len(qp_cropped),
              f"paired {len(valid)} + unmatched {len(unmatched_qp)} = {len(qp_cropped)}")
        if unmatched_qp:
            print(f"    [info] {base_key}: {len(unmatched_qp)} QP question(s) without MS twin -> review_required/no_markscheme")
        qn = [m.question_number for m in valid]
        check("no question paired twice", len(set(qn)) == len(qn), qn)
        return valid, unmatched_qp

    _paired, _unmatched_qp = gate.run_stage("S4", f"pair coverage [{base_key}]", s4b)
    from types import SimpleNamespace as _SNQ
    valid_matched = list(_paired) + [
        _SNQ(question_number=_c.question_number, number_int=_c.number_int,
             qp=_c, ms=None, paper_code=base_key,
             full_qp_code=qp_info.full_code,
             full_ms_code=ms_info.full_code if ms_info else None,
             year=qp_info.year, season=qp_info.season,
             variant=qp_info.variant, subject=subject.split("_")[0])
        for _c in _unmatched_qp
    ]
    # F4/F6 capture: collapse the QC verdict + crop count to scalars BEFORE
    # freeing the image lists (RAM hygiene), so the completion gate can read
    # them afterwards.
    _qp_crop_count = len(qp_cropped)
    _qc_flagged_qs = [c.question_number for c in qp_cropped
                      if getattr(c, "needs_review", False)]
    if _spool is not None:
        # S4 needed the real pixels (validate_pairs); park them again so S5
        # saves one question at a time instead of holding all payloads.
        _spool_crops([m.qp for m in valid_matched if getattr(m, "qp", None) is not None],
                     _spool, "qp2")
        _spool_crops([m.ms for m in valid_matched if getattr(m, "ms", None) is not None],
                     _spool, "ms2")
    del qp_cropped, ms_cropped
    gc.collect()
    _heap_trim()  # RS-16: give S4's validation-peak pages back before S5 builds on them

    # ---------- S5 classify + save ----------
    classifier = TopicClassifier(config)
    unc_counts = {"no_markscheme": 0, "classification_failed": 0}
    _full_auto_eff = bool(getattr(args, "full_auto", True)) and not bool(getattr(args, "no_full_auto", False))

    # Buff 2026-08-13: paper-coherence prior. Pass 1 collects tentative
    # winners (cheap; no saving, no image loads in low-ram spool mode) so
    # ambiguous questions can be nudged toward topics that already won
    # elsewhere in the SAME paper. Pass 2 does the real classify+save with
    # the prior. Confident winners are never affected (prior only applies
    # to the pre-prior ambiguous state).
    from collections import Counter as _Counter
    _coherence = _Counter()
    try:
        for _m0 in valid_matched:
            _c0 = classifier.classify_question(
                _m0, force_winner=_full_auto_eff)
            if getattr(_c0, "winning_major", ""):
                _coherence[_c0.winning_major] += 1
    except Exception:
        _coherence = _Counter()
    _coherence_prior = dict(_coherence) if _coherence else None

    def s5(check):
        topic_union = set(getattr(config, "major_topics", [])) | set(getattr(config, "detailed_topics", []))
        saved_here = 0
        _prev_m = None
        for m in valid_matched:
            if _spool is not None:
                # flat-peak discipline: park the previous question's pixels
                # before loading this one (release lags exactly one iteration);
                # malloc_trim so the freed pages lower RSS, not just arena.
                if _prev_m is not None:
                    _release(getattr(_prev_m, "qp", None)); _release(getattr(_prev_m, "ms", None))
                    _heap_trim()
                _unspool(getattr(m, "qp", None)); _unspool(getattr(m, "ms", None))
            _prev_m = m
            if args.low_ram:
                print(f"    [mem] s5 in {m.question_number}: RSS {_rss_mb()} MB")  # RS-16 trace
            # Missing structured MS no longer forces review_required by itself.
            # We save the classified question with an _MS.txt placeholder unless
            # this is an MCQ item with no extracted answer letter.
            if getattr(m, "ms", None) is None and getattr(m, "ms_answer", None) is None:
                print(f"    [guarded] {base_key} {m.question_number}: proceeding without MS crop (placeholder _MS.txt will be written)")
            c = classifier.classify_question(m, coherence_prior=_coherence_prior,
                                           force_winner=_full_auto_eff)
            if getattr(c, "fallback_tier", "scored") in ("paper_hint", "alphabetical_first", "review_required"):
                # 2026-08-14 (user requirement, boss checklist): with full-auto
                # ON (the default), REVIEW is NOT ALLOWED — re-classify with
                # force_winner=True (guaranteed guess) and save normally.
                # --no-full-auto restores the fail-closed behavior below.
                if _full_auto_eff:
                    print(f"    [guarded] {base_key} {m.question_number}: {c.fallback_tier} "
                          f"-> re-classifying with force (full-auto)")
                    c = classifier.classify_question(m, coherence_prior=_coherence_prior,
                                                     force_winner=True)
                else:
                    # Overseer RULE 1 (decision: desperate_only): desperate tiers only
                    # RS-17: spec absolute rule — insufficient evidence routes to
                    # REVIEW_REQUIRED (never an alphabetical/first-topic rescue).
                    _unc_reason = "review_required" if getattr(c, "fallback_tier", "") == "review_required" else "classification_failed"
                    output_mgr.save_review_required_question(m, _unc_reason, config)
                    unc_counts["classification_failed"] += 1
                    saved_here += 1
                    print(f"    [guarded] {base_key} {m.question_number}: {c.fallback_tier} -> review_required")
                    if _spool is not None:
                        _release(getattr(m, "qp", None)); _release(getattr(m, "ms", None)); _heap_trim()
                    continue
            check(f"{base_key} {m.question_number}: winner set", bool(c.winning_major), c.winning_major)
            if topic_union:
                check(f"{base_key} {m.question_number}: winner in taxonomy",
                      c.winning_major in topic_union, c.winning_major)
            check(f"{base_key} {m.question_number}: <=4 detailed topics",
                  len(c.detailed_topics) <= 4, str(c.detailed_topics[:4]))
            saved = output_mgr.save_question_pair(m, c, config)
            qfolder = Path(saved["question_folder"])
            _mcq_save = getattr(m, "ms_answer", None) is not None
            _missing_ms_placeholder = (getattr(m, "ms", None) is None and not _mcq_save)
            if saved.get("skipped_duplicate"):
                qp_f = qfolder / f"{qfolder.name}.webp"
                ms_f = None if (_mcq_save or _missing_ms_placeholder) else qfolder / f"{qfolder.name}_MS.webp"
                js_f = qfolder / "metadata.json"
            else:
                qp_f, js_f = Path(saved["qp"]), Path(saved["json"])
                ms_f = None if (_mcq_save or _missing_ms_placeholder) else Path(saved["ms"])

            def on_disk(p: Path) -> bool:
                return p.exists() or any(p.parent.glob(p.stem + "_part*" + p.suffix))
            check(f"{base_key} {m.question_number}: QP file on disk", on_disk(qp_f), qp_f.name)
            if ms_f is not None:
                check(f"{base_key} {m.question_number}: MS file on disk", on_disk(ms_f), ms_f.name)
            else:
                _js0 = json.loads(js_f.read_text(encoding="utf-8"))
                _txt_files = list(qfolder.glob("*_MS.txt"))
                # User requirement (2026-08-14): metadata.json carries ONLY the
                # canonical 11 fields; MCQ letters / missing-MS status live in
                # sidecar files. The canonical-key invariant is asserted on
                # every question the guarded runner saves.
                from core.json_generator import CANONICAL_METADATA_FIELDS as _CANON
                check(f"{base_key} {m.question_number}: metadata = canonical 11 fields only",
                      set(_js0.keys()) == set(_CANON),
                      str(sorted(_js0.keys())))
                if _mcq_save:
                    # MCQ (mcq_ms=letters): no MS webp by design; the grid
                    # letter lives in the _MS.txt sidecar.
                    check(f"{base_key} {m.question_number}: MCQ _MS.txt on disk (unified-MCQ)",
                          len(_txt_files) == 1, f"{len(_txt_files)} found")
                    if _txt_files:
                        _tl = _txt_files[0].read_text(encoding="utf-8").strip()
                        check(f"{base_key} {m.question_number}: _MS.txt valid letter",
                              _tl in ("A", "B", "C", "D"), _tl or "(empty)")
                else:
                    check(f"{base_key} {m.question_number}: missing-MS placeholder txt on disk",
                          len(_txt_files) == 1, f"{len(_txt_files)} found")
            check(f"{base_key} {m.question_number}: metadata.json on disk", js_f.exists(), js_f.name)
            webps = sorted(qfolder.glob("*.webp"))
            check(f"{base_key} {m.question_number}: webp {'QP-only (MCQ)' if ms_f is None else 'pair'} written",
                  len(webps) >= (1 if ms_f is None else 2), f"{len(webps)} webps")
            from PIL import Image
            for w in webps:
                with Image.open(w) as im:
                    check(f"{base_key} {m.question_number}: {w.name} width 2280",
                          im.width == TARGET_WIDTH, f"{im.size}")
            json.loads(js_f.read_text(encoding="utf-8"))
            check(f"{base_key} {m.question_number}: metadata.json parses",
                  True, f"{js_f.stat().st_size} bytes")
            saved_here += 1
        check(f"{base_key}: all paired questions saved", saved_here == len(valid_matched),
              f"{saved_here}/{len(valid_matched)}")
        return saved_here

    saved_n = gate.run_stage("S5", f"{ALL_STAGES[5][1]} [{base_key}]", s5)
    print(f"    [guarded] review_required (no MS): {unc_counts['no_markscheme']} / (classify failed): {unc_counts['classification_failed']}")
    if ms_info is None:
        # Trust-self mode: classify and save even when the MS is unavailable;
        # the question folder receives a placeholder _MS.txt instead of being
        # forced to review_required.
        state.mark_complete(base_key, len(valid_matched), saved_n)
    elif _qp_crop_count == 0:
        # defect 6: never mark an empty/hollow paper complete
        state.mark_failed(base_key, "CROP_EMPTY (0 QP crops — fail-closed, never fabricated)")
        print(f"    [guarded] ❌ {base_key}: 0 QP crops — NOT marked complete")
    elif _qc_flagged_qs:
        # defect 4 gate: QC needs_review blocks completion (crops stay saved)
        state.mark_failed(base_key, f"QC needs_review: {_qc_flagged_qs}")
        print(f"    [guarded] ⚠️ {base_key}: QC needs_review {_qc_flagged_qs} — NOT marked complete (crops saved for review)")
    elif getattr(config, "year_review_required", False):
        # Historical/future paper year has no verified edition profile yet.
        # Preserve the real crops and classifications, but never advertise a
        # clean syllabus-level completion.
        reason = (
            f"SYLLABUS_YEAR_UNVERIFIED: {getattr(config, 'requested_year', '?')} "
            f"not in {getattr(config, 'syllabus_years', [])}"
        )
        state.mark_review_required(base_key, reason)
        print(f"    [guarded] ⚠️ {base_key}: {reason} — crops preserved; bundle REVIEW_REQUIRED")
    else:
        state.mark_complete(base_key, len(valid_matched), saved_n)
    state.save(output_root_safe(output_mgr))
    del valid_matched
    if _spool is not None:
        shutil.rmtree(_spool, ignore_errors=True)
    gc.collect()
    return saved_n


def output_root_safe(output_mgr) -> Path:
    return Path(getattr(output_mgr, "output_root", "output"))


def load_inputs(args):
    """S0+S1 shared by parent and workers. Returns (gate, configs, papers, sep)."""
    input_dir, output_dir = Path(args.input), Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    gate = Gate(output_dir)

    if args.clean and output_dir.exists():
        for item in output_dir.iterdir():
            if item.name == ".gitkeep":
                continue
            shutil.rmtree(item) if item.is_dir() else item.unlink()
        print(f"[guarded] cleaned {output_dir}")

    from core.config_loader import (load_all_subject_configs,
                                    load_subject_config_by_code_and_level,
                                    validate_all_configs)

    def s0(check):
        ok, errors_by_subject = validate_all_configs()
        check("all subject configs validate", ok, f"errors={errors_by_subject if not ok else 'none'}")
        configs = load_all_subject_configs()
        check("configs loaded", len(configs) > 0, f"{len(configs)} entries")
        return configs

    configs = gate.run_stage("S0", ALL_STAGES[0][1], s0)

    from core.paper_identifier import identify_papers_in_dir
    from core.subject_detector import separate_papers_by_subject

    def s1(check):
        from core.batch_manifest import identify_via_manifest_or_live
        # RS-9: one-pass manifest (derived cache). Parent builds/refreshes it;
        # workers consume-or-fallback and NEVER build — kills the O(N^2)
        # per-worker whole-directory re-identification at 300+ files.
        papers, ident_src = identify_via_manifest_or_live(
            input_dir,
            manifest_path=getattr(args, "manifest", None),
            build_if_missing=not bool(getattr(args, "worker", None)),
            no_manifest=bool(getattr(args, "no_manifest", False)),
            full_check=bool(getattr(args, "manifest_full_check", False)),
        )
        check("at least one paper identified", len(papers) > 0,
              f"{len(papers)} papers in {input_dir} [identity:{ident_src}]")
        for p in papers:
            check(f"{p.original_name or p.file_path.name}: parsed",
                  p.paper_type in {"qp", "ms", "er", "gt", "in"} and bool(p.syllabus_code),
                  f"type={p.paper_type} code={p.syllabus_code} {p.season_letter}{p.year_short} v{p.variant}")
        sep = separate_papers_by_subject(papers)
        check("no identity conflicts", len(sep["conflicts"]) == 0,
              f"{len(sep['conflicts'])} conflicts" if sep["conflicts"] else "clean")
        check("no papers needing review", len(sep["review"]) == 0,
              f"{len(sep['review'])} for review" if sep["review"] else "clean")
        check("papers sorted into subject contexts", len(sep["by_level_subject"]) > 0,
              str({lvl: list(d) for lvl, d in sep["by_level_subject"].items()}))
        # Every four-digit paper year is processable.  Declared syllabus
        # editions are clean; an undeclared historical/future year is loudly
        # bound to REVIEW_REQUIRED rather than aborting S1 and discarding the
        # entire paper before cropping begins.
        _cfg_by_code = {}
        for _cfg in configs.values():
            _cfg_by_code[(str(_cfg.syllabus_code), _cfg.level)] = _cfg
            # Alias codes (0983 -> 0478, 0971 -> 0620, 9608 -> 9618, ...)
            # must resolve to the canonical config in the S1 profile gate too,
            # or alias-code papers fail "profile exists for year" with
            # years=None even though their subject is fully configured.
            try:
                from core.config_loader import CODE_ALIASES
                for _alias, _canon in CODE_ALIASES.items():
                    if _canon == str(_cfg.syllabus_code):
                        _cfg_by_code[(_alias, _cfg.level)] = _cfg
            except Exception:
                pass
        for p in papers:
            if p.paper_type not in {"qp", "ms", "er", "in"}:
                continue
            _full_year = f"20{p.year_short}" if len(str(p.year_short)) == 2 else str(p.year_short)
            _cfg_hit = _cfg_by_code.get((str(p.syllabus_code), p.level))
            _year_known = _cfg_hit is not None and _full_year in [
                str(y) for y in _cfg_hit.syllabus_years
            ]
            if _cfg_hit is not None and not _year_known:
                print(
                    f"    [info] {p.original_name or p.file_path.name}: year "
                    f"{_full_year} is not in the verified editions "
                    f"{_cfg_hit.syllabus_years}; crop allowed, bundle forced "
                    "REVIEW_REQUIRED"
                )
            check(
                f"{p.original_name or p.file_path.name}: profile exists for year {_full_year}",
                _cfg_hit is not None,
                f"{p.syllabus_code} {p.level} declared_year={_year_known} "
                f"years={getattr(_cfg_hit, 'syllabus_years', None)} paper={_full_year}"
            )
        return papers, sep

    papers, sep = gate.run_stage("S1", ALL_STAGES[1][1], s1)
    return gate, configs, papers, sep


def find_bundle(base_key, configs, sep):
    """Locate (level, subject, config, qp_info, ms_info) for a bundle key."""
    from core.config_loader import load_subject_config_by_code_and_level
    for level in ["IGCSE", "A-Level"]:
        for subject, paper_list in sep["by_level_subject"].get(level, {}).items():
            from collections import defaultdict
            by_year = defaultdict(list)
            for p in paper_list:
                by_year[p.year].append(p)
            for year, year_papers in by_year.items():
                from core.qp_ms_matcher import QPMSMatcher
                matcher = QPMSMatcher()
                groups = matcher.group_papers(year_papers)
                if base_key in groups:
                    td = groups[base_key]
                    config = load_subject_config_by_code_and_level(
                        year_papers[0].syllabus_code, level, year)
                    if config is None:
                        # Spec Fix 10 (2026-08-12): NEVER substitute a default/
                        # nearest-profile config silently. Identity that resolves
                        # to no declared profile aborts the bundle loudly instead.
                        raise SystemExit(
                            f"[guarded] FATAL: no declared subject profile for "
                            f"{year_papers[0].syllabus_code} {level} (bundle {base_key}) — "
                            f"refusing to fall back to a default configuration")
                    return level, subject, config, td.get("qp"), td.get("ms")
    return None, None, None, None, None


def worker_main(args):
    gate, configs, papers, sep = load_inputs(args)
    level, subject, config, qp_info, ms_info = find_bundle(args.worker, configs, sep)
    from core.cropping_engine import CroppingEngine
    from core.ms_cropping_engine import MSCroppingEngine
    from core.qp_ms_matcher import QPMSMatcher
    from core.output_manager import OutputManager
    from core.pipeline_state import PipelineState

    if not qp_info:
        gate._abort("S4", f"worker bundle {args.worker}", [],
                    [("bundle resolvable", f"qp={qp_info} ms={ms_info}")])
    cropping_engine = CroppingEngine(target_width=2280, quality=95, dpi=75)
    ms_engine = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
    output_mgr = OutputManager(output_root=args.output, target_width=2280, quality=95)
    state = PipelineState.load_or_create(Path(args.output), subject=subject,
                                         syllabus_code=qp_info.syllabus_code, level=level)
    if os.environ.get("GUARDED_CHILD_NO_STATE") == "1":
        # U1: spawned by pipeline.py parallel orchestrator - parent owns state file.
        print("    [guarded] child state I/O disabled (GUARDED_CHILD_NO_STATE=1)")
        state = _NullState(state)
    saved_n = run_paper_stages(gate, args, args.worker, qp_info, ms_info, subject,
                               config, state, cropping_engine, ms_engine, QPMSMatcher(),
                               output_mgr)
    gc.collect()  # U6: full sweep before the worker reports out
    print(f"  [mem] current RSS at worker end: {_rss_mb()} MB")
    print(f"WORKER-RESULT saved={saved_n} base={args.worker}")
    gate.finish_all(f"paper worker {args.worker}", worker=True)


# ---------------------------------------------------------------------------
# RAM survival (2026-08): /tmp on this box is tmpfs (every MB pinned in RAM),
# and one S4/S5 worker peaks ~510-790MB. dmesg caught the kernel killing a
# 738MB worker at MemAvailable=3.8MB while /tmp debris from crashed runs
# held ~830MB. Two defences, both loud: a pre-spawn headroom gate (fail hard
# after a timeout instead of gambling on the OOM killer) and an orphan sweep
# for /tmp/er_tiles_* dirs a crashed worker leaves behind (its tmpfs pages
# are real RAM: 830MB of debris + a 790MB worker exceeded the 2GB box).
# ---------------------------------------------------------------------------
_WORKER_PEAK_MB = 820       # measured worst worker anon RSS 790MB + margin
_MIN_HEADROOM_MB = _WORKER_PEAK_MB + 260   # parent + platform + tmpfs slack
_HEADROOM_TIMEOUT_S = 60.0


def _mem_available_mb() -> int | None:
    try:
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except OSError:
        return None
    return None


def _purge_er_tile_orphans() -> int:
    """Remove orphaned er-tile temp dirs left by crashed workers."""
    import shutil, tempfile
    tmp = Path(tempfile.gettempdir())
    n = 0
    for d in tmp.glob("er_tiles_*"):
        try:
            shutil.rmtree(d, ignore_errors=True); n += 1
        except OSError:
            pass
    return n


def _wait_for_memory_headroom(base_key: str, output_root: Path | None = None, low_ram: bool = False) -> None:
    """Block until a worker's worst-case peak can actually be satisfied.

    A RAM timeout is a real failed gate, so leave the same failure_report.txt
    artifact as every other guarded abort before exiting.
    """
    import time
    avail = _mem_available_mb()
    if avail is None:
        print(f"  [mem] /proc/meminfo unreadable; spawning {base_key} ungated")
        return
    required_mb = 650 if low_ram else _MIN_HEADROOM_MB
    t0 = time.time()
    waited = False
    while avail < required_mb:
        if time.time() - t0 > _HEADROOM_TIMEOUT_S:
            message = (
                f"[guarded] FATAL: insufficient memory to spawn worker for "
                f"{base_key}: MemAvailable={avail}MB < required="
                f"{required_mb}MB after {_HEADROOM_TIMEOUT_S}s - "
                f"free RAM or reduce concurrent load (never gambling on OOM)"
            )
            if output_root is not None:
                try:
                    output_root.mkdir(parents=True, exist_ok=True)
                    (output_root / "failure_report.txt").write_text(
                        "failure_report\n" + message + "\n", encoding="utf-8"
                    )
                except Exception:
                    pass
            raise SystemExit(message)
        if not waited:
            print(f"  [mem] headroom {avail}MB < {required_mb}MB - "
                  f"waiting before spawning {base_key} ...")
            waited = True
        time.sleep(1.0)
        gc.collect()
        avail = _mem_available_mb()
        if avail is None:
            return
    if waited:
        print(f"  [mem] headroom OK ({avail}MB) - spawning {base_key}")


def _extract_worker_failure_reason(text: str, rc: int) -> str:
    """Best-effort single-line reason for a failed paper worker."""
    for line in text.splitlines():
        if line.startswith("FAIL  "):
            return line[6:].strip()
    for line in text.splitlines():
        if "RUN FAILED" in line or "FATAL:" in line:
            return line.strip()
    for line in reversed(text.splitlines()):
        line = line.strip()
        if line:
            return line
    return f"worker exited with code {rc}"


def _record_paper_failure(output_root: Path, base_key: str, rc: int, log_text: str) -> dict:
    """Persist a failed paper's log/report without stopping the rest of the batch."""
    fail_root = output_root / "paper_failures" / base_key
    fail_root.mkdir(parents=True, exist_ok=True)
    log_path = fail_root / "worker_log.txt"
    log_path.write_text(log_text, encoding="utf-8")

    reason = _extract_worker_failure_reason(log_text, rc)
    root_report = output_root / "failure_report.txt"
    report_text = ""
    if root_report.exists():
        try:
            report_text = root_report.read_text(encoding="utf-8")
        except Exception:
            report_text = ""
        try:
            root_report.unlink()
        except Exception:
            pass
    if not report_text:
        report_text = (
            f"failure_report\n"
            f"paper bundle: {base_key}\n"
            f"worker exit: {rc}\n"
            f"reason: {reason}\n"
        )
    report_path = fail_root / "failure_report.txt"
    report_path.write_text(report_text, encoding="utf-8")
    meta = {
        "paper": base_key,
        "worker_exit_code": rc,
        "reason": reason,
        "failure_report": str(report_path.relative_to(output_root)),
        "worker_log": str(log_path.relative_to(output_root)),
    }
    (fail_root / "summary.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def _write_failed_papers_report(output_root: Path, paper_failures: list[dict]) -> tuple[Path, Path]:
    """Aggregate all tolerated paper-worker failures into user-facing reports."""
    txt_path = output_root / "failed_papers_report.txt"
    json_path = output_root / "failed_papers_report.json"
    root_failure = output_root / "failure_report.txt"
    lines = [
        f"failed_papers_report  —  {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"failed bundles: {len(paper_failures)}",
        "",
    ]
    for i, item in enumerate(paper_failures, 1):
        lines.extend([
            f"{i}. {item.get('paper', '')}",
            f"   exit code : {item.get('worker_exit_code', '')}",
            f"   reason    : {item.get('reason', '')}",
            f"   report    : {item.get('failure_report', '')}",
            f"   worker log: {item.get('worker_log', '')}",
            "",
        ])
    text = "\n".join(lines)
    txt_path.write_text(text, encoding="utf-8")
    root_failure.write_text(text, encoding="utf-8")
    json_path.write_text(json.dumps({"failed_papers": paper_failures}, indent=2), encoding="utf-8")
    return txt_path, json_path


def spawn_paper_worker(args, base_key) -> tuple:
    """Run one bundle in an isolated subprocess; stream its output. Returns (rc, saved, log_text)."""
    cmd = [sys.executable, "-u", str(Path(__file__).resolve()),
           "--input", str(args.input), "--output", str(args.output),
           "--_worker", base_key]
    if args.low_ram:
        cmd.append("--low-ram")
    if getattr(args, "full_auto", True) and not getattr(args, "no_full_auto", False):
        cmd.append("--full-auto")
    if getattr(args, "manifest", None):
        cmd += ["--manifest", str(args.manifest)]
    if getattr(args, "no_manifest", False):
        cmd.append("--no-manifest")
    if getattr(args, "manifest_full_check", False):
        cmd.append("--manifest-full-check")
    _orphans = _purge_er_tile_orphans()
    if _orphans:
        print(f"  [mem] purged {_orphans} orphaned er_tiles_* dir(s) from crashed workers")
    _wait_for_memory_headroom(base_key, Path(args.output), low_ram=bool(args.low_ram))
    print(f"\n[guarded] paper {base_key}: isolated process …")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1)
    buf = []
    for line in proc.stdout:
        sys.stdout.write(line)
        buf.append(line)
    rc = proc.wait()
    _purge_er_tile_orphans()
    gc.collect()
    log_text = "".join(buf)
    m = WORKER_OK.search(log_text)
    saved = int(m.group(1)) if m else (-9 if rc == 0 else -8)
    return rc, saved, log_text


def main():
    ap = argparse.ArgumentParser(description="Self-checking guarded runner (locked pipeline, gate between every stage)")
    ap.add_argument("--input", "-i", default="input")
    ap.add_argument("--output", "-o", default="output")
    ap.add_argument("--clean", action="store_true")
    ap.add_argument("--low-ram", action="store_true",
                    help="QP: RAM-safe streaming harness (production-identical segmentation)")
    ap.add_argument("--manifest", default=None,
                    help="batch manifest path (default <input>/.batch_manifest.json; env GUARDED_MANIFEST_JSON honoured)")
    ap.add_argument("--no-manifest", action="store_true",
                    help="disable the manifest cache; force live per-worker identification (pre-RS-9 behaviour)")
    ap.add_argument("--manifest-full-check", action="store_true",
                    help="hash-verify every file against the manifest (slow, max paranoia)")
    # Mega-spec Fix 1 flags (2026-08-12)
    ap.add_argument("--workers", type=int, default=2,
                    help="bounded parallel bundle workers (default 2). Honest "
                         "note: per-paper process isolation is sequential on "
                         "this box by design — the flag is accepted, recorded "
                         "and clamped so RAM-safe ordering is never violated.")
    ap.add_argument("--resume", action="store_true",
                    help="skip bundles already COMPLETE in pipeline state "
                         "(this is also the default; the flag documents intent)")
    ap.add_argument("--retry-failed", action="store_true",
                    help="reset FAILED bundles to PENDING before the run")
    ap.add_argument("--dry-run", action="store_true",
                    help="identify, group, and print the per-bundle plan "
                         "(strategies, missing MS, review items) without "
                         "processing anything")
    ap.add_argument("--fetch-missing-ms", action="store_true",
                    help="OPT-IN: for QP-only bundles, attempt mark-scheme fetch "
                         "via the allowed source order (official Cambridge -> "
                         "pastpapers.co -> approved). Off by default; failures "
                         "record REVIEW_REQUIRED, never a guessed pairing.")
    ap.add_argument("--fetch-missing-qp", action="store_true",
                    help="OPT-IN: for MS/ER files whose question paper is "
                         "missing, attempt QP fetch via the allowed source "
                         "order (official Cambridge -> pastpapers.co). "
                         "Verified downloads land in the input folder before "
                         "identification; unverifiable results are never used "
                         "and existing files are never overwritten.")
    ap.add_argument("--full-auto", action="store_true", default=True,
                    help="DEFAULT ON (2026-08-14): never route to review_required "
                         "— crop + categorize + sort everything; auto-guesses "
                         "marked in metadata. Pass --no-full-auto to restore "
                         "fail-closed routing.")
    ap.add_argument("--no-full-auto", action="store_true", default=False,
                    help="Restore fail-closed review routing.")
    ap.add_argument("--fetch-missing-er", action="store_true",
                    help="OPT-IN: for every QP/MS in the input folder whose "
                         "examiner-report twin is missing, attempt ER fetch "
                         "via official Cambridge -> pastpapers.co -> "
                         "papacambridge -> xtrapapers -> papersdaddy; Scribd "
                         "results are reported as manual-download links in "
                         "er_fetch_report.txt. Verified only.")
    ap.add_argument("--validate", action="store_true",
                    help="run ONLY the final output audit (S8) on --output and exit")
    ap.add_argument("--_worker", dest="worker", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()

    if args.worker:
        worker_main(args)
        return

    if args.validate:
        # Mega-spec required command: main/run_guarded --validate = audit-only.
        from core.validation import FinalValidator
        result = FinalValidator(output_root=args.output).validate_all()
        review_roots = {"review_required", "review_required_no_ms"}
        review_present = any(
            path.is_dir() and any(part in review_roots for part in path.parts)
            for path in Path(args.output).rglob("*")
        ) if Path(args.output).exists() else False
        _state_file = Path(args.output) / ".pipeline_state.json"
        if _state_file.exists():
            try:
                _payload = json.loads(_state_file.read_text(encoding="utf-8"))
                review_present = review_present or any(
                    "review" in str(record.get("status", "")).lower()
                    for record in _payload.get("papers", {}).values()
                )
            except Exception:
                pass
        status = "PASS — REVIEW REQUIRED" if result["passed"] and review_present else (
            "PASS" if result["passed"] else "FAIL"
        )
        print(f"[validate] {status}: "
              f"errors={result.get('total_errors', 0)} output={args.output}")
        for e in result.get("errors", [])[:20]:
            print(f"  [validate] ERROR: {e}")
        if not result["passed"]:
            raise SystemExit(1)
        raise SystemExit(2 if review_present else 0)

    if args.workers != 2:
        print(f"[guarded] --workers={args.workers}: recorded; per-paper isolation "
              f"stays sequential for RAM safety (worker dies with its peak heap)")
    if args.resume:
        print("[guarded] --resume: completed bundles are skipped (default behavior; flag recorded)")

    print(f"[guarded] QP path: {'RAM-SAFE streaming (locked triplet, low-ram)' if args.low_ram else 'production CroppingEngine (main.py-exact)'}")
    print(f"[guarded] per-paper process isolation: ON (worker dies with its peak heap)")

    # QP fetch pre-flight (2026-08-13, OPT-IN only — mirror of the MS-fetch
    # policy). Runs BEFORE load_inputs so a verified downloaded QP lands in
    # the input folder and the S1 identification pass picks up the complete
    # QP/MS pair on this same run. Unverifiable downloads are quarantined as
    # *.unverified.pdf and never enter the pipeline; user files are never
    # overwritten. A stale manifest is dropped so S1 re-identifies fresh.
    if getattr(args, "fetch_missing_er", False):
        print("[guarded] --fetch-missing-er: scanning for missing examiner "
              "reports before identification...")
        try:
            from core.er_fetcher import fetch_missing_ers_in_dir as _fetch_ers
            _er_stats = _fetch_ers(Path(args.input), output_root=Path(args.output),
                                   dry_run=bool(args.dry_run))
            print(f"[fetch-er] summary: {_er_stats}")
        except Exception as _e:
            print(f"[fetch-er] pre-flight error (continuing): {_e}")

    if getattr(args, "fetch_missing_qp", False):
        print("[guarded] --fetch-missing-qp: scanning for QP-less MS/ER files "
              "before identification...")
        try:
            from core.qp_fetcher import fetch_missing_qps_in_dir
            _qp_stats = fetch_missing_qps_in_dir(
                input_dir=Path(args.input),
                output_root=Path(args.output),
                dry_run=bool(args.dry_run),
            )
            if _qp_stats.get("resolved", 0) > 0:
                _mf = Path(args.input) / ".batch_manifest.json"
                if _mf.exists():
                    _mf.unlink(missing_ok=True)
                    print(f"[fetch-qp] removed stale manifest {_mf.name} so S1 "
                          f"re-identifies with the downloaded question papers")
        except Exception as _e:  # fetch problems never abort the run
            print(f"[fetch-qp] pre-flight error (continuing without fetch): {_e}")

    gate, configs, papers, sep = load_inputs(args)
    output_root = Path(args.output)

    from core.qp_ms_matcher import QPMSMatcher
    from core.pipeline_state import PipelineState

    if args.retry_failed:
        _st = PipelineState.load_or_create(output_root, subject="_run", syllabus_code="", level="")
        _n = _st.reset_failed()
        _st.save(output_root)
        print(f"[guarded] --retry-failed: {_n} failed bundle(s) returned to PENDING")

    if args.dry_run:
        # Mega-spec Fix 1: one-pass plan only. Nothing is processed, nothing
        # is written to the output tree beyond the manifest S1 already wrote.
        from core.strategies import strategy_plan_for_paper
        print("\n[guarded] DRY RUN plan (no processing):")
        _matcher = QPMSMatcher()
        _groups = _matcher.group_papers(papers)
        for _bk, _td in sorted(_groups.items()):
            _qp = _td.get("qp")
            _plan = strategy_plan_for_paper(_qp) if _qp is not None else None
            print(f"  - {_bk}: qp={'Y' if 'qp' in _td else '-'} ms={'Y' if 'ms' in _td else '-'} "
                  f"er={'Y' if 'er' in _td else '-'}"
                  + (f" | strategy {_plan.name} ({_plan.reason})" if _plan else " | ER/insert-only"))
            if "qp" in _td and "ms" not in _td:
                print(f"      REVIEW: no mark scheme supplied — fetch with --fetch-missing-ms "
                      f"or the bundle runs QP-only (review_required_no_ms)")
        if _matcher.grouping_errors:
            print(f"  duplicate/conflict grouping errors: {_matcher.grouping_errors}")
        print("[guarded] DRY RUN complete — 0 papers processed")
        return

    total_saved = 0
    paper_failures = []
    for level in ["IGCSE", "A-Level"]:
        if level not in sep["by_level_subject"]:
            continue
        from collections import defaultdict
        for subject, paper_list in sep["by_level_subject"][level].items():
            print(f"\n[guarded] subject context {level}/{subject}: {len(paper_list)} papers")
            by_year = defaultdict(list)
            for p in paper_list:
                by_year[p.year].append(p)

            for year, year_papers in by_year.items():
                matcher = QPMSMatcher()
                groups = matcher.group_papers(year_papers)

                # RS-13 (S4-fix round): an ER/insert-ONLY context has nothing to
                # pair by definition — skip it loudly instead of aborting the
                # whole run (pre-existing defect: one orphan-ER subject killed
                # an otherwise-clean batch at this gate). Duplicate-input
                # grouping errors remain a hard gate even here.
                _bundles_n = sum(1 for _v in groups.values() if ("qp" in _v or "ms" in _v))
                if _bundles_n == 0 and not matcher.grouping_errors:
                    print(f"    [guarded] SKIP {subject} {year}: no QP/MS bundles — "
                          f"ER/insert-only context ({len(groups)} group(s)); orphan ER "
                          f"output handled at S6/S7 and listed at run end")
                    continue

                if getattr(args, "fetch_missing_ms", False):
                    # Mega-spec Fix 6 (OPT-IN ONLY): resolve QP-only bundles via
                    # the allowed source order. Wired to the real resolver
                    # (core/ms_fetcher.MissingMSResolver — the same one
                    # run_pipeline uses); it needs a pipeline sqlite of bundles,
                    # so when none exists the hook reports loudly and marks the
                    # QP-only bundles REVIEW_REQUIRED rather than guessing.
                    _qp_only = [_bk for _bk, _td in groups.items()
                                if "qp" in _td and "ms" not in _td]
                    if _qp_only:
                        _db = output_root / "pipeline.sqlite"
                        if _db.exists():
                            from core.ms_fetcher import MissingMSResolver
                            _resolver = MissingMSResolver(
                                db_path=_db,
                                cache_dir=output_root / ".ms_cache",
                                dry_run=False,
                            )
                            _fetch_stats = _resolver.resolve_all()
                            print(f"    [fetch-ms] resolver finished: {_fetch_stats}")
                        else:
                            for _bk in _qp_only:
                                print(f"    [fetch-ms] {_bk}: REVIEW_REQUIRED — no pipeline "
                                      f"sqlite at {_db.name}; run "
                                      f"'python run_pipeline.py --input {args.input} "
                                      f"--output {args.output} --dry-run' first, then re-run "
                                      f"with --fetch-missing-ms (spec Fix 6: opt-in only, "
                                      f"allowed-source order enforced by the resolver)")

                # ---------- S4 grouping gates (structure only) ----------
                def s4(check, groups=groups, year=year):
                    check("no duplicate-input grouping errors", len(matcher.grouping_errors) == 0,
                          str(matcher.grouping_errors) if matcher.grouping_errors else "clean")
                    bundles = {k: v for k, v in groups.items() if ("qp" in v or "ms" in v)}
                    loners = [k for k, v in groups.items() if ("qp" not in v and "ms" not in v)]
                    check("at least one QP/MS group", len(bundles) > 0,
                          f"{len(bundles)} bundles, {len(loners)} er/insert-only groups")
                    for k in loners:
                        print(f"    [info] {k}: no QP/MS — handled in ER stages S6/S7")
                    for base_key, td in bundles.items():
                        check(f"{base_key}: has QP", "qp" in td, ",".join(td.keys()))
                        if "ms" not in td:
                            # Overseer RULE 2: no MS -> QP preserved to review_required
                            print(f"    [info] {base_key}: no MS - QP-only run, questions -> review_required/no_markscheme")
                            continue
                        if "qp" in td and "ms" in td:
                            check(f"{base_key}: QP/MS level agree", td["qp"].level == td["ms"].level,
                                  f"{td['qp'].level} vs {td['ms'].level}")
                    return None

                gate.run_stage("S4", f"{ALL_STAGES[4][1]} [{subject} {year}]", s4)

                for base_key, td in groups.items():
                    if "qp" not in td:
                        if getattr(args, "fetch_missing_qp", False):
                            print(f"    [fetch-qp] {base_key}: QP still missing "
                                  f"after fetch attempt — see the fetch summary above")
                        else:
                            print(f"    [info] {base_key}: no QP — supply it or "
                                  f"re-run with --fetch-missing-qp to auto-download")
                        continue  # QP-less groups never produce output; ER handled post-loop
                    rc, saved_n, worker_log = spawn_paper_worker(args, base_key)

                    def wp(check, bk=base_key, rc=rc, sn=saved_n, failures=paper_failures):
                        _ok = (rc == 0 and sn >= 0)
                        _detail = f"exit={rc}, saved={sn}"
                        if not _ok:
                            _reason = _extract_worker_failure_reason(worker_log, rc)
                            _detail += f" | {_reason}"
                        check(f"{bk}: worker process exited cleanly", _ok, _detail)
                        check(f"{bk}: worker reported saved count", sn >= 0, f"saved={sn}")
                        return max(sn, 0)

                    saved_n = gate.run_stage("S5", f"paper worker result [{base_key}]", wp,
                                             abort_on_fail=False)
                    if rc == 0 and saved_n >= 0:
                        total_saved += saved_n
                    else:
                        failure = _record_paper_failure(output_root, base_key, rc, worker_log)
                        paper_failures.append(failure)
                        print(f"    [guarded] continuing after failed paper {base_key}: {failure['reason']}")
                    gc.collect()

    # ---------- S6 ER text ----------
    er_papers = [p for p in papers if p.paper_type == "er"]

    # RS-13: orphan ERs = examiner reports whose paper context produced no
    # question folders this run (their subject was skipped at S4 by design).
    # They parse and report fine, but there is nothing to attach to.
    _QDIR_RE = re.compile(r"_Q\d+$")
    orphan_ers = []
    for _p in er_papers:
        _level_root = Path(args.output) / _p.level
        _attachable = (
            any(qd.is_dir() and _QDIR_RE.search(qd.name)
                for sd in _level_root.glob(f"*_{_p.syllabus_code}")
                for qd in sd.rglob("*"))
            if _level_root.exists() else False
        )
        if not _attachable:
            orphan_ers.append(_p)
    if orphan_ers:
        print(f"[guarded] orphan examiner reports (no question output to attach to): "
              + ", ".join(Path(p.file_path).name for p in orphan_ers))

    def s6(check):
        if not er_papers:
            check("no ER papers supplied — stage skipped by design", True, "")
            return None
        from core.examiner_report import attach_examiner_reports_to_output
        stats = attach_examiner_reports_to_output(er_papers, output_root)
        check("ER: no processing errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        check("ER: every detected report parsed", stats["reports_parsed"] == stats["reports_detected"],
              f"{stats['reports_parsed']}/{stats['reports_detected']}")
        check("ER: commentary attached to questions",
              stats["questions_attached"] > 0 or (er_papers and len(orphan_ers) == len(er_papers)),
              f"{stats['questions_attached']} attached"
              + (f" ({len(orphan_ers)}/{len(er_papers)} ERs orphan — nothing to attach to)"
                 if orphan_ers else ""))
        return stats

    gate.run_stage("S6", ALL_STAGES[6][1], s6)
    try:
        from core.examiner_report import clear_er_tile_cache
        clear_er_tile_cache()  # RS-18: /tmp tile caches drop here, not at exit
    except Exception:
        pass

    # ---------- S7 ER crops ----------
    def s7(check):
        if not er_papers:
            check("no ER papers supplied — stage skipped by design", True, "")
            return None
        from core.er_question_crops import attach_question_er_crops
        stats = attach_question_er_crops(er_papers, output_root)
        check("ER crops: no errors", len(stats["errors"]) == 0,
              str(stats["errors"][:3]) if stats["errors"] else "clean")
        check("ER crops: all written crops text-verified", stats["crops_written"] == stats["verified"],
              f"{stats['crops_written']}/{stats['verified']}")
        from PIL import Image
        tiles = [p for p in output_root.rglob("*_ER.webp")]
        check("ER crops: at least one crop on disk",
              len(tiles) > 0 or (er_papers and len(orphan_ers) == len(er_papers)),
              f"{len(tiles)} tiles"
              + (f" ({len(orphan_ers)}/{len(er_papers)} ERs orphan)" if orphan_ers else ""))
        for t in tiles:
            with Image.open(t) as im:
                check(f"ER crop {t.parent.name}/{t.name}: width 2280", im.width == TARGET_WIDTH,
                      f"{im.size}")
        return stats

    gate.run_stage("S7", ALL_STAGES[7][1], s7)

    # ---------- S8 final validation ----------
    from core.validation import FinalValidator
    from core.output_manager import OutputManager
    output_mgr = OutputManager(output_root=args.output, target_width=2280, quality=95)

    def s8(check):
        removed = output_mgr.cleanup_empty_and_invalid_folders()
        check("cleanup ran", True, f"removed {len(removed)} invalid folders" if removed else "nothing invalid")
        dup_errors, _ = output_mgr.ensure_no_duplicate_distribution()
        check("no duplicate distribution", len(dup_errors) == 0,
              str(dup_errors[:3]) if dup_errors else "clean")
        qpms_errors = output_mgr.validate_qp_ms_pairs()
        check("QP/MS pairs valid on disk", len(qpms_errors) == 0,
              str(qpms_errors[:3]) if qpms_errors else "clean")
        result = FinalValidator(output_root=output_root).validate_all()
        check("final audit passes", result["passed"], f"errors={result.get('total_errors', 0)}")
        folders = [p for p in output_root.rglob("*_Q*")
                   if p.is_dir() and re.search(r"_Q\d+$", p.name)]
        check("question folders on disk == saved this run", len(folders) == total_saved,
              f"{len(folders)} folders vs {total_saved} saved")
        # RS-13: state-mirror parity (phase-1 posture: advisory, never fatal).
        # JSON remains authoritative; drift is reported loudly, not gated.
        _state_file = Path(args.output) / ".pipeline_state.json"
        if _state_file.exists():
            try:
                from core.pipeline_state import PipelineState as _PS
                from core.state_mirror import verify_parity as _vp
                _st = _PS.load_or_create(Path(args.output), "", "", "")
                _ok, _drift = _vp(_st, Path(args.output))
                if _ok:
                    check("state-mirror parity (advisory)", True,
                          f"MIRRORED OK ({len(_st.papers)} papers)")
                else:
                    print(f"  [state-mirror] PARITY DRIFT (advisory): {_drift[:3]}")
                    check("state-mirror parity (advisory)", True,
                          f"DRIFT x{len(_drift)}: {_drift[:2]}")
            except Exception as _exc:
                print(f"  [state-mirror] parity check skipped ({_exc})")
                check("state-mirror parity (advisory)", True, f"skipped: {_exc}")
        return result

    gate.run_stage("S8", ALL_STAGES[8][1], s8)

    print(f"\n[guarded] questions saved: {total_saved}")
    if paper_failures:
        txt_report, json_report = _write_failed_papers_report(output_root, paper_failures)
        print(f"[guarded] failed paper bundles recorded: {len(paper_failures)}")
        print(f"[guarded] failed-papers reports: {txt_report} and {json_report}")
    if orphan_ers:
        print(f"[guarded] orphan ERs unused this run (supply their QP/MS to use them): "
              + ", ".join(Path(p.file_path).name for p in orphan_ers))
    gate.finish_all("full guarded run", paper_failures=paper_failures)


if __name__ == "__main__":
    main()
