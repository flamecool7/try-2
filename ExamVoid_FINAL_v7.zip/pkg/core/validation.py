"""
Validation - Universal component + Final audit supporting IGCSE + A-Level
CRITICAL FIX: JSON must be inside question folder per new requirement

New required structure (F10: real writer naming — OutputManager writes
{variant}_{Season}_{Year}_Q{n}.webp / {...}_MS.webp / {...}_ER.webp):
P2_AS_Structured/
├── Equilibria/
│   ├── 22_Spring_2025_Q3/
│   │   ├── 22_Spring_2025_Q3.webp
│   │   ├── 22_Spring_2025_Q3_MS.webp
│   │   └── metadata.json
│   └── 22_Spring_2025_Q8/
│       ├── 22_Spring_2025_Q8.webp
│       ├── 22_Spring_2025_Q8_MS.webp
│       └── metadata.json
└── Electrochemistry/
    └── 22_Spring_2025_Q7/
        ├── 22_Spring_2025_Q7.webp
        ├── 22_Spring_2025_Q7_MS.webp
        └── metadata.json

Every question is self-contained: QP + MS + metadata.json inside question folder
No orphan JSON, no empty question folders
"""

from pathlib import Path
import json
from PIL import Image
from collections import defaultdict
import shutil
from .output_manager import _is_paper_type_dir_name

class FinalValidator:
    def __init__(self, output_root: str | Path = "output", subjects_root: str | Path | None = None):
        # 2026-08-10 (approved, guarded-runner finding V3): the old default
        # "subjects" was CWD-relative — any caller running outside the project
        # root silently got known_subjects=[] and every real subject folder was
        # flagged "Unknown subject folder". Default is now package-relative;
        # a missing explicit path falls back package-relatively, loudly.
        self.output_root = Path(output_root)
        if subjects_root is None:
            subjects_root = Path(__file__).resolve().parent.parent / "subjects"
        self.subjects_root = Path(subjects_root)
        if not self.subjects_root.exists():
            alt = Path(__file__).resolve().parent.parent / "subjects"
            if alt.exists() and alt != self.subjects_root:
                print(f"[Validator] subjects_root {self.subjects_root} not found; using {alt}")
                self.subjects_root = alt
            else:
                print(f"[Validator] WARNING: subjects_root {self.subjects_root} not found — subject detection will flag all folders")
        self.errors = []
        self.fixes = []

    def validate_subject_context(self, level: str, subject: str) -> dict:
        """Validate one isolated subject output context without inspecting others."""
        subject_root = self.output_root / level / subject
        errors = []
        if not subject_root.exists():
            return {"level": level, "subject": subject, "questions": 0, "errors": ["Subject output directory missing"], "passed": False}
        for json_file in subject_root.rglob("metadata.json"):
            try:
                with json_file.open("r", encoding="utf-8") as fh:
                    data = json.load(fh)
                if data.get("level") != level or data.get("subject") != subject:
                    errors.append(f"Cross-subject metadata in {json_file}")
                    continue
                topics = data.get("topic")
                if not isinstance(topics, list) or not topics or not isinstance(topics[0], str):
                    errors.append(f"Invalid topic metadata: {json_file}")
                    continue
                q_folder = json_file.parent
                topic_folder = q_folder.parent
                expected_base = f"{data.get('variant')}_{data.get('season')}_{data.get('year')}_{data.get('question_number')}"
                if topic_folder.name == "review_required":
                    # RS-5/RS-17: sentinel accepted; naming + QP + (sentinel-dependent) MS enforced
                    if topics[0] not in ("review_required", "review_required_no_ms", "review_required"):
                        errors.append(f"review_required folder with non-sentinel topic {topics[0]!r}: {json_file}")
                    if q_folder.name != expected_base:
                        errors.append(f"Question-folder naming mismatch: {q_folder}")
                    if not (q_folder / f"{expected_base}.webp").exists():
                        errors.append(f"Missing QP file: {q_folder}")
                    if topics[0] in ("review_required", "review_required") \
                            and not (q_folder / f"{expected_base}_MS.webp").exists() \
                            and not any(q_folder.glob("*_MS.txt")):
                        errors.append(f"Missing MS file (classification_failed/review keeps MS): {q_folder}")
                    continue
                if topic_folder.name != topics[0]:
                    errors.append(f"JSON topic/folder mismatch: {json_file}")
                if q_folder.name != expected_base:
                    errors.append(f"Question-folder naming mismatch: {q_folder}")
                if not (q_folder / f"{expected_base}.webp").exists():
                    errors.append(f"Missing QP file: {q_folder}")
                # IGCSE paper-format round (mcq_ms=letters): grid letter rides
                # in the `*_MS.txt` sidecar instead of an MS webp. User
                # requirement (2026-08-14): metadata.json is canonical-only.
                from .mcq_output import valid_ms_sidecar as _valid_sidecar
                ms_txts = sorted(q_folder.glob("*_MS.txt"))
                if ms_txts and _valid_sidecar(ms_txts[0].read_text(encoding="utf-8")):
                    pass  # MCQ letter or QP-only placeholder = legal MS-less home
                elif not (q_folder / f"{expected_base}_MS.webp").exists():
                    errors.append(f"Missing MS file: {q_folder}")
            except Exception as exc:
                errors.append(f"Invalid metadata {json_file}: {exc}")
        questions = len(list(subject_root.rglob("metadata.json")))
        return {"level": level, "subject": subject, "questions": questions, "errors": errors, "passed": not errors}

    def validate_all(self) -> dict:
        print("[Validator] Starting full end-to-end audit (IGCSE + A-Level) - NEW STRUCTURE: Topic/Q/ QP,MS,metadata.json")
        self.errors = []
        self.fixes = []

        self.check_no_forbidden_paths()
        self.check_level_detection()
        self.check_subject_detection()
        self.check_question_extraction()
        self.check_cropping()
        self.check_folder_requirements_new()  # NEW: checks Topic/Q/ structure
        self.check_question_folders()  # NEW: validates Q folder has QP,MS,metadata.json
        self.check_no_orphan_json()  # NEW: no JSON outside Q folders
        self.check_qp_ms_pairing_new()  # NEW: checks inside Q folders
        # This pass reads metadata.json and makes its topic[0] the sole folder
        # identifier.  It runs before topic/reference checks so repaired paths are
        # audited as their final locations.
        self.check_json_folder_topic_consistency(auto_fix=True)
        self.check_topic_classification()
        self.check_reference_staging_math_routing()
        self.check_major_mapping()
        self.check_single_folder_distribution()
        self.check_json_structure()
        self.check_json_files_consistency_new()  # NEW: both directions with new structure
        self.check_no_cross_contamination()
        self.check_webp_validity()
        self.check_image_dimensions()
        self.check_level_separation()

        # Generic Topic/Q validation predates the deliberate Pn/loading staging
        # layout. Its staging paths are validated by the dedicated reference
        # validator above, so suppress only those duplicate generic assumptions.
        staging_markers = ("/Mathematics_9709/P", "/Further_Mathematics_9231/P", "\\Mathematics_9709\\P", "\\Further_Mathematics_9231\\P")
        self.errors = [err for err in self.errors if not any(marker in err for marker in staging_markers)]

        result = {
            "errors": self.errors,
            "fixes": self.fixes,
            "passed": len(self.errors) == 0,
            "total_errors": len(self.errors)
        }

        if result["passed"]:
            print("[Validator] ✓ All checks passed! (IGCSE + A-Level) - NEW STRUCTURE VALID")
        else:
            print(f"[Validator] ✗ Found {len(self.errors)} error(s)")
            for err in self.errors[:30]:
                print(f"  - {err}")

        return result

    def check_no_forbidden_paths(self):
        """Spec Fix 12 (2026-08-12): 'loading' (any case, incl. 'loading..' and
        'paper-N/loading') must NEVER appear in the output tree. These were
        staging artifacts of the retired math reference-staging scheme; any
        occurrence fails the audit loudly instead of being silently ignored."""
        for node in self.output_root.rglob("*"):
            if "loading" in node.name.lower():
                self.errors.append(f"Forbidden staging path contains 'loading': {node}")

    def check_level_detection(self):
        if not self.output_root.exists():
            self.errors.append("Output root does not exist")
            return
        valid_levels = ["IGCSE", "A-Level"]
        for item in self.output_root.iterdir():
            if not item.is_dir() or item.name.startswith('.'):
                continue
            if item.name in valid_levels:
                continue
            if '_' in item.name:
                print(f"[Validator] Note: flat subject folder {item.name} found, expected under level folder (IGCSE/A-Level)")

    def check_subject_detection(self):
        known_subjects = []
        if self.subjects_root.exists():
            for cfg_path in self.subjects_root.rglob("config.json"):
                try:
                    with open(cfg_path, 'r') as f:
                        data = json.load(f)
                    known_subjects.append(data.get("subject"))
                except Exception as e:
                    continue

        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.'):
                continue
            if level_dir.name in ["IGCSE", "A-Level"]:
                for subject_dir in level_dir.iterdir():
                    if not subject_dir.is_dir():
                        continue
                    if subject_dir.name not in known_subjects:
                        self.errors.append(f"Unknown subject folder: {level_dir.name}/{subject_dir.name} not in known subjects")

    def check_question_extraction(self):
        webp_count = len(list(self.output_root.rglob("*.webp")))
        if webp_count == 0:
            print("[Validator] No webp files found in output - may be empty run")
        else:
            print(f"[Validator] Found {webp_count} webp files (IGCSE + A-Level)")

    def check_cropping(self):
        for webp in self.output_root.rglob("*.webp"):
            if "json" in str(webp):
                continue
            try:
                with Image.open(webp) as im:
                    if im.size[1] < 50:
                        self.errors.append(f"Image too small (possible cutoff): {webp} size {im.size}")
            except Exception as e:
                self.errors.append(f"Cannot open image for cropping check {webp}: {e}")

    def check_folder_requirements_new(self):
        """
        NEW: Folder must be Topic/Q/ with QP,MS,metadata.json
        With paper type separation: Level/Subject/PaperType/Major/Q/
        Major folder may ONLY exist if it contains at least one valid question folder
        Question folder may ONLY exist if it contains valid QP + MS + metadata.json
        """
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.'):
                continue

            subject_dirs = []
            if level_dir.name in ["IGCSE", "A-Level"]:
                subject_dirs = [d for d in level_dir.iterdir() if d.is_dir()]
            else:
                subject_dirs = [level_dir]

            for subject_dir in subject_dirs:
                if not subject_dir.is_dir():
                    continue

                # Subject may contain paper type folders (P2_AS_Structured) or major folders directly
                for item in subject_dir.iterdir():
                    if not item.is_dir():
                        continue
                    if item.name == "json":
                        self.errors.append(f"Found old json folder {item} - JSON must be inside question folders per new requirement")
                        try:
                            shutil.rmtree(item)
                            self.fixes.append(f"Deleted old json folder {item}")
                        except Exception as e:
                            self.errors.append(f"Failed to delete old json folder {item}: {e}")
                        continue

                    # Check if item is paper type folder
                    is_paper_type = _is_paper_type_dir_name(item.name)

                    if is_paper_type:
                        # Paper type folder contains major folders
                        paper_type_dir = item
                        for major_dir in paper_type_dir.iterdir():
                            if not major_dir.is_dir():
                                continue
                            if major_dir.name == "json":
                                self.errors.append(f"Found old json folder {major_dir}")
                                try:
                                    shutil.rmtree(major_dir)
                                    self.fixes.append(f"Deleted old json folder {major_dir}")
                                except Exception as e:
                                    self.errors.append(f"Failed to delete {major_dir}: {e}")
                                continue

                            direct_webp = list(major_dir.glob("*.webp"))
                            if direct_webp:
                                self.errors.append(f"Found {len(direct_webp)} webp files directly in major folder {major_dir} - must be inside question subfolders (Topic/Q/ structure)")
                                try:
                                    shutil.rmtree(major_dir)
                                    self.fixes.append(f"Deleted major folder with old structure {major_dir}")
                                except Exception as e:
                                    self.errors.append(f"Failed to delete {major_dir}: {e}")
                                continue

                            question_folders = [d for d in major_dir.iterdir() if d.is_dir()]
                            if not question_folders:
                                self.errors.append(f"Invalid major folder without question subfolders: {major_dir}")
                                try:
                                    shutil.rmtree(major_dir)
                                    self.fixes.append(f"Deleted empty major folder {major_dir}")
                                except Exception as e:
                                    self.errors.append(f"Failed to delete {major_dir}: {e}")
                                continue
                    else:
                        # Item is major folder directly under subject (old structure without paper type)
                        major_dir = item
                        if major_dir.name == "json":
                            continue

                        direct_webp = list(major_dir.glob("*.webp"))
                        if direct_webp:
                            self.errors.append(f"Found {len(direct_webp)} webp directly in major folder {major_dir} - must be inside question subfolders")
                            try:
                                shutil.rmtree(major_dir)
                                self.fixes.append(f"Deleted major folder with old structure {major_dir}")
                            except Exception as e:
                                self.errors.append(f"Failed to delete {major_dir}: {e}")
                            continue

                        question_folders = [d for d in major_dir.iterdir() if d.is_dir()]
                        if not question_folders:
                            self.errors.append(f"Invalid major folder without question subfolders: {major_dir}")
                            try:
                                shutil.rmtree(major_dir)
                                self.fixes.append(f"Deleted empty major folder {major_dir}")
                            except Exception as e:
                                self.errors.append(f"Failed to delete {major_dir}: {e}")
                            continue

    def _check_review_required_folder(self, q_folder: Path):
        """RS-5 (Overseer review_required directive, 2026-08-10): review_required
        folders are EXEMPT from topic-folder-name and single-folder checks, but
        NOT exempt from: QP present, metadata.json present+valid, REASON.txt
        present, and 2280px width / webp validity (enforced globally elsewhere).
        MS presence is required unless the no_markscheme sentinel is set."""
        qp_files = [f for f in q_folder.glob("*.webp") if "_MS" not in f.name and "_ER" not in f.name]
        ms_files = list(q_folder.glob("*_MS.webp")) + list(q_folder.glob("*_MS.txt"))
        json_files = list(q_folder.glob("metadata.json"))
        reason_files = list(q_folder.glob("REASON.txt"))
        if len(qp_files) != 1:
            self.errors.append(f"review_required {q_folder}: must have exactly 1 QP webp, found {len(qp_files)}")
        if len(json_files) != 1:
            self.errors.append(f"review_required {q_folder}: must have exactly 1 metadata.json, found {len(json_files)}")
        if len(reason_files) != 1:
            self.errors.append(f"review_required {q_folder}: must have REASON.txt, found {len(reason_files)}")
        sentinel = None
        if len(json_files) == 1:
            try:
                with open(json_files[0], "r") as f:
                    data = json.load(f)
                t = data.get("topic")
                sentinel = t[0] if isinstance(t, list) and t else None
                if sentinel not in ("review_required", "review_required_no_ms", "review_required"):
                    self.errors.append(f"review_required {q_folder}: non-sentinel topic {sentinel!r}")
                qnum = data.get("question_number")
                if qnum and qnum not in q_folder.name:
                    self.errors.append(f"review_required {q_folder}: question_number {qnum} not in folder name")
            except Exception as e:
                self.errors.append(f"review_required {q_folder}: invalid metadata.json: {e}")
        if sentinel == "review_required_no_ms":
            # Unified-MCQ round: an MCQ no_markscheme UNC keeps exactly one
            # _MS.txt (possibly EMPTY per Rule 3) — never an MS webp. User
            # requirement (2026-08-14): metadata is canonical-only; MCQ-ness
            # is decided by the sidecar.
            _txtnm = [f for f in ms_files if f.name.endswith("_MS.txt")]
            if _txtnm:
                _webpnm = [f for f in ms_files if f.name.endswith("_MS.webp")]
                if _webpnm or len(_txtnm) > 1:
                    self.errors.append(f"review_required {q_folder}: MCQ no_markscheme sentinel with contradictory MS files ({[f.name for f in ms_files]})")
            elif ms_files:
                self.errors.append(f"review_required {q_folder}: no_markscheme sentinel but {len(ms_files)} MS file(s) present - contradictory")
        else:
            # IGCSE paper-format round (mcq_ms=letters): an MCQ question in
            # classification_failed has no MS file BY DESIGN — its grid letter
            # lives in the `*_MS.txt` sidecar.
            _txtu = [f for f in ms_files if f.name.endswith("_MS.txt")]
            if _txtu:
                _tu = _txtu[0].read_text(encoding="utf-8").strip()
                if _tu and _tu not in ("A", "B", "C", "D"):
                    self.errors.append(f"review_required {q_folder}: _MS.txt invalid content {_tu!r}")
            elif len(ms_files) != 1:
                self.errors.append(f"review_required {q_folder}: classification_failed must keep the MS file, found {len(ms_files)}")

    # Compatibility alias for existing callers. The path semantics are now
    # review_required; no Uncategorized directory is created.
    _check_uncategorized_folder = _check_review_required_folder

    def check_question_folders(self):
        """
        NEW: Every question folder must contain exactly QP, MS, metadata.json
        Validates per requirement 7,9,10
        Handles both structures:
        - Old: Level/Subject/Major/Q/
        - New with paper type: Level/Subject/PaperType/Major/Q/ (e.g., P2_AS_Structured)
        """
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.'):
                continue

            subject_dirs = []
            if level_dir.name in ["IGCSE", "A-Level"]:
                subject_dirs = [d for d in level_dir.iterdir() if d.is_dir()]
            else:
                subject_dirs = [level_dir]

            for subject_dir in subject_dirs:
                # Subject may contain paper type folders or major folders
                # First, collect all major dirs regardless of whether they are under paper type or directly under subject
                major_dirs = []
                for item in subject_dir.iterdir():
                    if not item.is_dir():
                        continue
                    is_paper_type = _is_paper_type_dir_name(item.name)
                    if is_paper_type:
                        # Paper type folder contains majors
                        for major_sub in item.iterdir():
                            if major_sub.is_dir() and major_sub.name != "json":
                                major_dirs.append(major_sub)
                    else:
                        if item.name != "json":
                            major_dirs.append(item)

                for major_dir in major_dirs:
                    if not major_dir.is_dir() or major_dir.name == "json":
                        continue

                    for q_folder in major_dir.iterdir():
                        if not q_folder.is_dir():
                            continue

                        if major_dir.name == "review_required":
                            self._check_review_required_folder(q_folder)
                            continue

                        # Question folder should be like Q3 or 41_Winter_2025_Q2 per new requirement
                        # NEW NAMING: Variant_Season_Year_Q e.g., 41_Winter_2025_Q2
                        # Files: 41_Winter_2025_Q2.webp (QP) + 41_Winter_2025_Q2_MS.webp (MS) + metadata.json
                        all_webp = list(q_folder.glob("*.webp"))
                        all_txt = list(q_folder.glob("*.txt"))
                        # QP is webp without _MS and without _ER.
                        # 2026-08-10 (approved, guarded-runner finding V1): the
                        # locked OutputManager.validate_qp_ms_pairs already
                        # excludes "_ER" — full-report tiles and per-question
                        # ER crops legitimately live inside question folders.
                        # This filter was "_MS"-only, so every folder with ER
                        # content failed R9 ("exactly 1 QP webp, found 6") and
                        # the final production audit could never pass with ER
                        # attached. Mirrors output_manager.py filter exactly.
                        qp_files = [f for f in all_webp if "_MS" not in f.name and "_ER" not in f.name]
                        # MS can be webp with _MS or txt with _MS (for MCQ)
                        ms_files = list(q_folder.glob("*_MS.webp")) + list(q_folder.glob("*_MS.txt"))
                        json_files = list(q_folder.glob("metadata.json"))

                        # Requirement: must have exactly QP, MS, metadata.json (MS can be webp or txt for MCQ per R10)
                        # IGCSE paper-format round (mcq_ms=letters): an MCQ
                        # folder is QP webp + `*_MS.txt` letter sidecar; NO MS
                        # webp by design. User requirement (2026-08-14):
                        # metadata.json carries no paper_format/ms_answer —
                        # MCQ-ness is decided by the sidecar alone.
                        _ms_txts = sorted(q_folder.glob("*_MS.txt"))
                        _mcq_txt = _ms_txts[0] if _ms_txts else None
                        if len(qp_files) != 1:
                            self.errors.append(f"Question folder {q_folder} must have exactly 1 QP webp, found {len(qp_files)} ({qp_files}) - invalid per R9")
                        if _mcq_txt is not None:
                            from .mcq_output import valid_ms_sidecar as _valid_sidecar
                            _tl = _mcq_txt.read_text(encoding="utf-8").strip()
                            if not _valid_sidecar(_tl):
                                self.errors.append(f"Question folder {q_folder}: _MS.txt invalid content ({_tl!r}) - expected A-D letter or MS_UNAVAILABLE placeholder")
                        elif len(ms_files) != 1:
                            self.errors.append(f"Question folder {q_folder} must have exactly 1 MS file (webp or txt for MCQ), found {len(ms_files)} ({ms_files}) - invalid per R9")
                        if len(json_files) != 1:
                            self.errors.append(f"Question folder {q_folder} must have exactly 1 metadata.json, found {len(json_files)} - invalid per R9")

                        if len(qp_files) != 1 or len(ms_files) != 1 or len(json_files) != 1:
                            if len(qp_files) == 0 and len(ms_files) == 0 and len(json_files) == 1:
                                self.errors.append(f"Question folder {q_folder} has only metadata.json, no QP/MS - invalid per R9")
                                try:
                                    shutil.rmtree(q_folder)
                                    self.fixes.append(f"Deleted invalid question folder (only metadata) {q_folder}")
                                except Exception as e:
                                    self.errors.append(f"Failed to delete {q_folder}: {e}")
                            continue

                        # Validate JSON inside question folder
                        json_path = q_folder / "metadata.json"
                        try:
                            with open(json_path, 'r') as f:
                                data = json.load(f)

                            # Check question_number matches folder name per R7 - for new naming Variant_Season_Year_Q, folder contains Q
                            # Requirement: folder = Variant_Season_Year_Q e.g., 41_Winter_2025_Q2, qnum = Q2, so check qnum in folder name
                            qnum = data.get("question_number")
                            if qnum:
                                # For new naming, folder is like 41_Winter_2025_Q2, should contain Q2
                                if qnum not in q_folder.name:
                                    self.errors.append(f"JSON question_number {qnum} not in folder name {q_folder.name} in {json_path} - must match per R7 (folder should contain question number or be exact)")

                            # Check topic matches classification (exact string equality)
                            topics = data.get("topic", [])
                            if not topics or not isinstance(topics, list):
                                self.errors.append(f"JSON {json_path} missing valid topic array")

                            # Check folder name is exact topic? Actually topic folder is major, question folder is Q number
                            # But per R8: json_topic == folder.name for major? No, for question folder, question_number matches
                            # For major folder, need to check major topic exact?

                        except Exception as e:
                            self.errors.append(f"Invalid JSON {json_path}: {e}")

    def check_no_orphan_json(self):
        """No JSON outside question folders per R8"""
        for json_file in self.output_root.rglob("*.json"):
            # 2026-08-10 (approved, guarded-runner finding V2): dotfiles are
            # state/tooling, not question artifacts. rglob("*.json") matches
            # dotfiles, so the auto-heal below was silently DELETING
            # .pipeline_state.json on every audited run — killing the RS-1
            # crash-resume file right after PipelineState wrote it. Skip
            # dotfiles entirely (loudly), never flag or delete them.
            if json_file.name.startswith("."):
                print(f"[Validator] kept dotfile state JSON (not an orphan): {json_file.name}")
                continue
            # Must be named metadata.json and inside question folder that is inside major folder
            if json_file.name != "metadata.json":
                self.errors.append(f"Orphan JSON file not named metadata.json: {json_file} - must be metadata.json inside question folder per R8")
                # Auto-fix: if it's Q3.json in major folder, move to Q3/metadata.json?
                # Try to fix: if parent is major folder and file is like Q3.json, create Q3 folder and move
                parent = json_file.parent
                # If parent is major folder (contains no question subfolders with same name?), check
                # For now, just delete orphan old json
                if parent.name != "json" and json_file.name.endswith(".json") and json_file.name != "metadata.json":
                    # This is old structure JSON like Q3.json in major folder or in json/ folder
                    try:
                        json_file.unlink()
                        self.fixes.append(f"Deleted orphan JSON {json_file} - must be inside question folder")
                    except Exception as e:
                        self.errors.append(f"Failed to delete orphan JSON {json_file}: {e}")
                continue

            # Check parent is question folder, grandparent is major folder
            question_folder = json_file.parent
            major_folder = question_folder.parent

            if not question_folder.is_dir() or not major_folder.is_dir():
                self.errors.append(f"JSON {json_file} not inside valid Topic/Q/ structure")
                continue

            # Question folder should not be json folder
            if question_folder.name == "json":
                self.errors.append(f"JSON {json_file} inside json folder - must be inside question folder per new requirement")
                continue

    def check_qp_ms_pairing_new(self):
        """Check QP/MS inside question folders per new structure with paper type separation"""
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.'):
                continue

            subject_dirs = []
            if level_dir.name in ["IGCSE", "A-Level"]:
                subject_dirs = [d for d in level_dir.iterdir() if d.is_dir()]
            else:
                subject_dirs = [level_dir]

            for subject_dir in subject_dirs:
                # Subject may contain paper type folders or major folders
                major_dirs = []
                for item in subject_dir.iterdir():
                    if not item.is_dir():
                        continue
                    is_paper_type = _is_paper_type_dir_name(item.name)
                    if is_paper_type:
                        for major_sub in item.iterdir():
                            if major_sub.is_dir() and major_sub.name != "json":
                                major_dirs.append(major_sub)
                    else:
                        if item.name != "json":
                            major_dirs.append(item)

                for major_dir in major_dirs:
                    if not major_dir.is_dir() or major_dir.name == "json":
                        continue

                    for q_folder in major_dir.iterdir():
                        if not q_folder.is_dir():
                            continue

                        all_webp = list(q_folder.glob("*.webp"))
                        all_txt = list(q_folder.glob("*.txt"))
                        # QP is webp without _MS, MS can be webp or txt (MCQ)
                        qp_files = [f for f in all_webp if "_MS" not in f.name]
                        ms_files = list(q_folder.glob("*_MS.webp")) + list(q_folder.glob("*_MS.txt"))

                        if len(qp_files) == 0:
                            self.errors.append(f"Missing QP in question folder {q_folder} - must have QP webp like 41_Winter_2025_Q2.webp per R5")
                        if len(ms_files) == 0:
                            _unc_no_ms = False
                            if q_folder.parent.name == "review_required":
                                try:
                                    with open(q_folder / "metadata.json", "r") as _f:
                                        _t = json.load(_f).get("topic")
                                    _unc_no_ms = isinstance(_t, list) and _t and _t[0] == "review_required_no_ms"
                                except Exception:
                                    _unc_no_ms = False
                            if not _unc_no_ms:
                                # IGCSE paper-format round (mcq_ms=letters):
                                # MCQ folders carry the grid letter in a
                                # `*_MS.txt` sidecar, not an MS webp (user
                                # requirement 2026-08-14: metadata is
                                # canonical-only).
                                _unc_no_ms = bool(list(q_folder.glob("*_MS.txt")))
                            if not _unc_no_ms:
                                self.errors.append(f"Missing MS in question folder {q_folder} - must have MS file like 41_Winter_2025_Q2_MS.webp or _MS.txt per R5,R10")

                        for wf in qp_files + ms_files:
                            # Unified-MCQ round: ms_files may include _MS.txt
                            # (letter file) — image verification applies to
                            # webps only.
                            if wf.suffix.lower() != ".webp":
                                continue
                            try:
                                with Image.open(wf) as im:
                                    im.verify()
                                if wf.suffix.lower() != ".webp":
                                    self.errors.append(f"Not webp: {wf}")
                                with Image.open(wf) as im:
                                    if im.size[0] != 2280:
                                        self.errors.append(f"Width not 2280 for {wf}: {im.size[0]}")
                            except Exception as e:
                                self.errors.append(f"Invalid webp {wf}: {e}")

    def check_json_folder_topic_consistency(self, auto_fix: bool = True):
        """Enforce the canonical JSON-topic-to-folder invariant.

        For every question, the physical topic folder is the parent of its
        question folder.  Its name must equal ``metadata.json["topic"][0]``
        character-for-character.  The comparison intentionally does not apply
        any case, whitespace, underscore, punctuation, or spelling conversion.
        A stale folder is renamed to the exact JSON string when it is safe to do
        so; this keeps JSON as the source of truth rather than creating a second
        folder-naming system.
        """
        for json_file in list(self.output_root.rglob("metadata.json")):
            try:
                with json_file.open("r", encoding="utf-8") as fh:
                    data = json.load(fh)
                topics = data.get("topic")
                if not isinstance(topics, list):
                    self.errors.append(f"Cannot validate JSON-folder topic consistency; invalid topic array: {json_file}")
                    continue
                if not topics and data.get("subject") in {"Mathematics_9709", "Further_Mathematics_9231"} and json_file.parent.parent.name == "loading":
                    continue
                if not topics or not isinstance(topics[0], str) or not topics[0]:
                    self.errors.append(f"Cannot validate JSON-folder topic consistency; invalid topic array: {json_file}")
                    continue

                assigned_topic = topics[0]
                question_folder = json_file.parent
                actual_topic_folder = question_folder.parent
                if actual_topic_folder.name == "review_required" and assigned_topic in ("review_required", "review_required_no_ms", "review_required"):
                    # RS-5: sentinel folder is deliberate; never auto-rename it
                    print(f"[Validator] review_required sentinel accepted (no rename): {question_folder.name} topic={assigned_topic}")
                    continue
                # This is a direct string equality check: no normalization.
                if actual_topic_folder.name == assigned_topic:
                    continue

                mismatch = (
                    f"JSON-folder topic mismatch: JSON topic[0]={assigned_topic!r}, "
                    f"folder={actual_topic_folder.name!r} for {json_file}"
                )
                expected_topic_folder = actual_topic_folder.parent / assigned_topic
                target_question_folder = expected_topic_folder / question_folder.name

                if not auto_fix:
                    self.errors.append(mismatch)
                    continue

                expected_topic_folder.mkdir(parents=True, exist_ok=True)
                if target_question_folder.exists():
                    # Same question in both folders is a stale duplicate. Keep the
                    # canonical location and remove the non-canonical placement.
                    target_metadata = target_question_folder / "metadata.json"
                    same_question = False
                    if target_metadata.exists():
                        try:
                            with target_metadata.open("r", encoding="utf-8") as fh:
                                target_data = json.load(fh)
                            same_question = (
                                target_data.get("paper") == data.get("paper")
                                and target_data.get("question_number") == data.get("question_number")
                                and target_data.get("topic", [None])[0] == assigned_topic
                            )
                        except (OSError, json.JSONDecodeError, IndexError, TypeError):
                            pass
                    if not same_question:
                        self.errors.append(mismatch + "; automatic repair blocked by a conflicting question folder")
                        continue
                    shutil.rmtree(question_folder)
                    self.fixes.append(f"Removed duplicate non-canonical question folder {question_folder}; retained {target_question_folder}")
                else:
                    question_folder.rename(target_question_folder)
                    self.fixes.append(f"Renamed topic folder placement to exact JSON topic {assigned_topic!r}: {target_question_folder}")

                # Do not leave empty, obsolete topic folders behind.
                if actual_topic_folder.exists() and not any(actual_topic_folder.iterdir()):
                    actual_topic_folder.rmdir()
            except (OSError, json.JSONDecodeError, IndexError, TypeError) as exc:
                self.errors.append(f"Could not validate JSON-folder topic consistency for {json_file}: {exc}")

    def check_topic_classification(self):
        from .config_loader import load_all_subject_configs
        configs = load_all_subject_configs()

        for json_file in self.output_root.rglob("metadata.json"):
            try:
                with open(json_file, 'r') as f:
                    data = json.load(f)
                if "topic" not in data:
                    self.errors.append(f"JSON missing 'topic' field: {json_file}")
                elif not isinstance(data["topic"], list) or (len(data["topic"]) == 0 and data.get("subject") not in {"Mathematics_9709", "Further_Mathematics_9231"}):
                    self.errors.append(f"JSON topic empty or not list: {json_file}")

                if "level" not in data:
                    self.errors.append(f"JSON missing 'level' field: {json_file}")
                elif data["level"] not in ["IGCSE", "A-Level"]:
                    self.errors.append(f"JSON invalid level {data['level']} in {json_file}")

                subject = data.get("subject")
                level = data.get("level")
                if subject and level:
                    cfg_key = f"{level}/{subject}"
                    cfg = configs.get(cfg_key) or configs.get(subject) or configs.get(data.get("paper", "")[:4])
                    if cfg and hasattr(cfg, 'detailed_topics'):
                        # JSON topic[0] is the distribution winner (a major
                        # reference identifier); additional values may be detailed
                        # multi-topic classifications.  Both originate unchanged
                        # from the configured reference taxonomy.
                        allowed = set(cfg.major_topics) | set(cfg.detailed_topics)
                        if str(getattr(cfg, "syllabus_code", "")) == "9709":
                            from .math_reference import load_9709_reference
                            allowed |= {topic for topics in load_9709_reference().values() for topic in topics}
                        for t in data.get("topic", []):
                            if t in ("review_required", "review_required_no_ms", "review_required"):
                                continue  # RS-5/RS-17 sentinels (Overseer + spec REVIEW_REQUIRED)
                            if t not in allowed:
                                self.errors.append(f"Topic {t} not in configured reference topics for {level}/{subject} in {json_file}")

            except Exception as e:
                self.errors.append(f"Invalid JSON {json_file}: {e}")

    def check_reference_staging_math_routing(self):
        """Synchronize manual Pn topic-folder moves with metadata exactly."""
        from .math_category import get_paper_number_from_variant
        from .math_reference import reference_topics_for_subject_paper
        for subject, code in (("Mathematics_9709", "9709"), ("Further_Mathematics_9231", "9231")):
            root = self.output_root / "A-Level" / subject
            if not root.exists():
                continue
            for paper_root in [p for p in root.iterdir() if p.is_dir() and p.name.startswith("paper-")]:
                try:
                    paper_number = int(paper_root.name.split("-", 1)[1])
                    expected = set(reference_topics_for_subject_paper(code, paper_number))
                except Exception as exc:
                    self.errors.append(f"Invalid {subject} reference container {paper_root}: {exc}")
                    continue
                actual = {p.name for p in paper_root.iterdir() if p.is_dir() and p.name != "loading"}
                if actual != expected:
                    self.errors.append(f"{subject} P{paper_number} folders do not exactly match its reference")
                loading = paper_root / "loading"
                if not loading.is_dir():
                    self.errors.append(f"{subject} P{paper_number} missing loading folder")
                    continue
                # Unassigned bundles remain explicitly topic-empty in loading.
                for jf in loading.rglob("metadata.json"):
                    try:
                        with jf.open(encoding="utf-8") as fh: data=json.load(fh)
                        if data.get("subject") != subject or data.get("topic") != []:
                            self.errors.append(f"Invalid review_required staging metadata: {jf}")
                        if get_paper_number_from_variant(str(data.get("variant", ""))) != paper_number:
                            self.errors.append(f"Wrong paper staging location: {jf}")
                    except Exception as exc:
                        self.errors.append(f"Invalid staging metadata {jf}: {exc}")
                # A manual move from loading/ into an exact reference folder is
                # the assignment event. Repair metadata to that literal folder
                # name—never classify or transform the name.
                for topic in expected:
                    topic_dir = paper_root / topic
                    for jf in topic_dir.rglob("metadata.json"):
                        try:
                            with jf.open(encoding="utf-8") as fh: data=json.load(fh)
                            if data.get("subject") != subject:
                                self.errors.append(f"Cross-subject metadata in {topic_dir}: {jf}")
                                continue
                            if get_paper_number_from_variant(str(data.get("variant", ""))) != paper_number:
                                self.errors.append(f"Wrong paper assignment folder: {jf}")
                                continue
                            if data.get("topic") != [topic]:
                                data["topic"] = [topic]
                                with jf.open("w", encoding="utf-8") as fh:
                                    json.dump(data, fh, indent=4)
                                self.fixes.append(f"Updated manual {subject} assignment metadata to exact topic {topic!r}: {jf}")
                        except Exception as exc:
                            self.errors.append(f"Invalid assigned-topic metadata {jf}: {exc}")

    def check_major_mapping(self):
        from .config_loader import load_all_subject_configs
        configs = load_all_subject_configs()

        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name.startswith('.'):
                continue

            if level_dir.name in ["IGCSE", "A-Level"]:
                level_name = level_dir.name
                for subject_dir in level_dir.iterdir():
                    if not subject_dir.is_dir():
                        continue
                    subject_name = subject_dir.name
                    cfg_key = f"{level_name}/{subject_name}"
                    cfg = configs.get(cfg_key) or configs.get(subject_name)
                    if not cfg:
                        continue
                    if str(getattr(cfg, "syllabus_code", "")) in {"9709", "9231"}:
                        # Reference staging uses Pn containers, not major folders.
                        continue
                    allowed_majors = set(cfg.major_topics)
                    if str(getattr(cfg, "syllabus_code", "")) == "9709":
                        from .math_reference import load_9709_reference
                        allowed_majors = {topic for topics in load_9709_reference().values() for topic in topics}

                    for item in subject_dir.iterdir():
                        if not item.is_dir():
                            continue
                        # Check if item is paper type folder
                        is_paper_type = _is_paper_type_dir_name(item.name)
                        if is_paper_type:
                            # Paper type folder contains major folders
                            for major_dir in item.iterdir():
                                if not major_dir.is_dir():
                                    continue
                                if major_dir.name not in allowed_majors:
                                    self.errors.append(f"Major topic {major_dir.name} not in allowed list for {level_name}/{subject_name}: {allowed_majors}")
                        else:
                            # Direct major folder (old structure without paper type, or paper type omitted)
                            major_dir = item
                            if major_dir.name in ("review_required", "review_required"):
                                continue  # RS-5/RS-17: deliberate containers next to paper-type folders
                            if major_dir.name not in allowed_majors:
                                # Allow paper type folders themselves to not be in allowed list - they are not major topics
                                # Only check if it's not a paper type folder
                                if not (major_dir.name.startswith("P") and ("_Structured" in major_dir.name or "MCQ" in major_dir.name or "Practical" in major_dir.name or "_ATP" in major_dir.name or "_Essay" in major_dir.name or "Plan_Analysis" in major_dir.name or "Alt_to_Practical" in major_dir.name)):
                                    self.errors.append(f"Major topic {major_dir.name} not in allowed list for {level_name}/{subject_name}: {allowed_majors}")

    def check_single_folder_distribution(self):
        question_to_folders = defaultdict(set)
        question_to_files = defaultdict(list)

        for qp_file in self.output_root.rglob("*.webp"):
            # F10 (Overseer defect 10): the writer's real convention is
            # {variant}_{Season}_{Year}_Q{n}.webp (OutputManager:216);
            # *_MS.webp / *_ER.webp are the twin/report artifacts. The old
            # "*_QP.webp" glob matched ZERO production files — this check was
            # silently vacuous (always passed checking nothing).
            if "_MS" in qp_file.name or "_ER" in qp_file.name:
                continue
            # QP file is inside question folder: .../Major/Q/Q.webp
            question_folder = qp_file.parent
            major_folder = question_folder.parent

            # Base id from JSON if available
            json_path = question_folder / "metadata.json"
            base = None
            if json_path.exists():
                try:
                    with open(json_path, 'r') as f:
                        data = json.load(f)
                        paper = data.get("paper", "unknown")
                        qnum = data.get("question_number", qp_file.stem)
                        base = f"{paper}_{qnum}"
                except Exception as e:
                    base = str(question_folder)

            if not base:
                base = str(question_folder)

            question_to_folders[base].add(str(major_folder))
            question_to_files[base].append(str(question_folder))

        for base_q, majors in question_to_folders.items():
            if len(majors) == 0:
                self.errors.append(f"0 folders for {base_q} - fix needed")
            elif len(majors) > 1:
                self.errors.append(f"Question {base_q} exists in {len(majors)} majors: {majors} - must be exactly ONE (R6)")

    def check_json_structure(self):
        required_fields = ["id", "level", "subject", "board", "topic", "paper", "question_number", "variant", "season", "year"]
        forbidden_fields = ["topic_details", "primary", "secondary", "needs_review", "topic_scores", "primary_topic", "secondary_topics"]

        for json_file in self.output_root.rglob("metadata.json"):
            try:
                with open(json_file, 'r') as fj:
                    data = json.load(fj)
                for field in required_fields:
                    if field not in data:
                        self.errors.append(f"JSON {json_file} missing required field {field}")
                for field in forbidden_fields:
                    if field in data:
                        self.errors.append(f"JSON {json_file} contains forbidden field {field}")

                if "topic" in data and not isinstance(data["topic"], list):
                    self.errors.append(f"JSON {json_file} topic not list")
                if "id" in data and len(str(data["id"])) < 10:
                    self.errors.append(f"JSON {json_file} id suspicious: {data['id']}")
                if "level" in data and data["level"] not in ["IGCSE", "A-Level"]:
                    self.errors.append(f"JSON {json_file} invalid level {data['level']}")

            except Exception as e:
                self.errors.append(f"Invalid JSON structure {json_file}: {e}")

    def check_json_files_consistency_new(self):
        """NEW: Both directions with new structure Topic/Q/"""
        json_bases = set()
        json_to_qfolder = {}

        for jf in self.output_root.rglob("metadata.json"):
            try:
                with open(jf, 'r') as f:
                    data = json.load(f)
                paper = data.get("paper")
                qnum = data.get("question_number")
                if paper and qnum:
                    base = f"{paper}_{qnum}"
                    json_bases.add(base)
                    json_to_qfolder[base] = jf.parent
            except Exception as e:
                continue

        webp_bases = set()
        webp_to_qfolder = {}

        # NEW STRUCTURE: QP is *.webp without _MS, e.g., 41_Winter_2025_Q2.webp
        # Old structure: Q3_QP.webp
        # Handle both: look for all webp that are NOT _MS.webp as QP
        for wf in self.output_root.rglob("*.webp"):
            if "_MS" in wf.name:
                continue  # Skip MS files, only count QP for base
            q_folder = wf.parent
            json_path = q_folder / "metadata.json"
            if not json_path.exists():
                self.errors.append(f"QP {wf} has no metadata.json in same question folder {q_folder} - must have QP,MS,metadata.json together per R5")
                continue

            try:
                with open(json_path, 'r') as f:
                    data = json.load(f)
                paper = data.get("paper")
                qnum = data.get("question_number")
                if paper and qnum:
                    base = f"{paper}_{qnum}"
                    webp_bases.add(base)
                    webp_to_qfolder[base] = q_folder
                else:
                    webp_bases.add(str(q_folder))
            except Exception as e:
                # Fallback to folder name
                webp_bases.add(str(q_folder))

        # Check both directions
        for wb in webp_bases:
            if wb not in json_bases:
                self.errors.append(f"Webp question {wb} has no matching metadata.json")

        for jb in json_bases:
            if jb not in webp_bases:
                self.errors.append(f"JSON {jb} has no matching webp files")

        # Check for orphan JSON outside question folders already done in check_no_orphan_json

    def check_no_cross_contamination(self):
        from .config_loader import load_all_subject_configs
        configs = load_all_subject_configs()

        for json_file in self.output_root.rglob("metadata.json"):
            try:
                with open(json_file, 'r') as f:
                    data = json.load(f)
                subject_in_json = data.get("subject")
                level_in_json = data.get("level")

                parts = json_file.parts
                try:
                    idx = parts.index(self.output_root.name)
                    maybe_level = parts[idx+1] if len(parts) > idx+1 else None
                    maybe_subject = None
                    if maybe_level in ["IGCSE", "A-Level"]:
                        maybe_subject = parts[idx+2] if len(parts) > idx+2 else None
                        if level_in_json != maybe_level:
                            self.errors.append(f"Cross-level contamination: JSON level {level_in_json} in folder {maybe_level} file {json_file}")
                    else:
                        maybe_subject = maybe_level

                    if maybe_subject and subject_in_json != maybe_subject:
                        # For new structure, subject folder is at idx+2 if level present, else idx+1
                        # Check if subject matches
                        if maybe_subject != subject_in_json and maybe_subject not in ["json", "metadata.json"]:
                            # Only flag if maybe_subject looks like subject (contains _)
                            if "_" in maybe_subject:
                                self.errors.append(f"Cross-contamination: JSON subject {subject_in_json} in folder {maybe_subject} file {json_file}")

                except Exception as e:
                    print(f"[Validator] Warning: non-critical error {e} - logged")

                if subject_in_json and level_in_json:
                    cfg_key = f"{level_in_json}/{subject_in_json}"
                    cfg = configs.get(cfg_key) or configs.get(subject_in_json)
                    if cfg:
                        if cfg.level != level_in_json:
                            self.errors.append(f"Level mismatch in config: JSON says {level_in_json} but config for {subject_in_json} says {cfg.level} in {json_file}")

                        allowed_reference_topics = set(cfg.major_topics) | set(cfg.detailed_topics)
                        if str(getattr(cfg, "syllabus_code", "")) == "9709":
                            from .math_reference import load_9709_reference
                            allowed_reference_topics |= {topic for topics in load_9709_reference().values() for topic in topics}
                        for t in data.get("topic", []):
                            if t in ("review_required", "review_required_no_ms", "review_required"):
                                continue  # RS-5/RS-17 sentinels (Overseer + spec REVIEW_REQUIRED)
                            if t not in allowed_reference_topics:
                                self.errors.append(f"Topic {t} not in configured reference topics for {level_in_json}/{subject_in_json} in {json_file}")

            except Exception as e:
                continue

    def check_level_separation(self):
        for level_dir in self.output_root.iterdir():
            if not level_dir.is_dir() or level_dir.name not in ["IGCSE", "A-Level"]:
                continue

            level = level_dir.name
            for webp in level_dir.rglob("*.webp"):
                name = webp.name
                import re
                m = re.search(r'^(\d{4})_', name)
                if not m:
                    # Try to get code from JSON in same question folder
                    json_path = webp.parent / "metadata.json"
                    if json_path.exists():
                        try:
                            with open(json_path, 'r') as f:
                                data = json.load(f)
                                paper = data.get("paper", "")
                                m2 = re.search(r'^(\d{4})_', paper)
                                if m2:
                                    code = m2.group(1)
                                    from .config_loader import infer_level_from_code
                                    inferred = infer_level_from_code(code)
                                    if inferred != level:
                                        self.errors.append(f"Level separation violation: file {webp} with code {code} inferred as {inferred} but located in {level} folder")
                                    continue
                        except Exception as e:
                            print(f"[Validator] Warning: level separation check failed for {webp}: {e}")
                            continue
                code = m.group(1)
                from .config_loader import infer_level_from_code
                inferred = infer_level_from_code(code)
                if inferred != level:
                    self.errors.append(f"Level separation violation: file {webp} with code {code} inferred as {inferred} but located in {level} folder")

    def check_webp_validity(self):
        for webp in self.output_root.rglob("*.webp"):
            try:
                with Image.open(webp) as im:
                    im.verify()
                with Image.open(webp) as im:
                    if im.format != "WEBP":
                        self.errors.append(f"File {webp} not valid WEBP format, got {im.format}")
            except Exception as e:
                self.errors.append(f"Invalid WEBP {webp}: {e}")

    def check_image_dimensions(self):
        for webp in self.output_root.rglob("*.webp"):
            try:
                with Image.open(webp) as im:
                    if im.size[0] != 2280:
                        self.errors.append(f"Image {webp} width not 2280, got {im.size[0]}")
                    if im.size[1] < 50:
                        self.errors.append(f"Image {webp} height too small {im.size[1]}, possible cutoff - No cutoff allowed per gold-standard")
            except Exception as e:
                print(f"[Validator] Warning: image dimension check failed: {e}")
                self.errors.append(f"Image dimension check failed: {e}")
