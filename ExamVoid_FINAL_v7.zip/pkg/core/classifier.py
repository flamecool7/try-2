"""
Subject-Specific Classifier - Handles detailed topic classification

Flow:
Paper
↓
Identify subject
↓
Load subject configuration
↓
Load correct syllabus
↓
Extract question
↓
Classify detailed topics
↓
Map detailed topics → major topics
↓
Calculate major-topic scores
↓
Select winning major topic
↓
Place QP/MS there

CRITICAL RULES:
- Chemistry must ONLY use Chemistry mappings
- Physics must ONLY use Physics mappings
- Mathematics must ONLY use Mathematics mappings
- Never mix mappings between subjects
- JSON contains detailed topics
- Folders contain ONLY major topics
- Point-based classification
- Single-folder distribution

Point allocation considered:
- Marks allocated
- Number of subquestions
- Central purpose
- Required knowledge
- Calculations
- Reasoning
- Mark-scheme dependency
- Specialized knowledge
- Number of syllabus objectives
Do NOT award points merely because keyword appears.

Tie-breaking:
1. Topic responsible for most marks
2. Central purpose
3. Most specialized knowledge
4. Strongest mark-scheme dependency
5. Official syllabus hierarchy/order
"""

import re
from functools import lru_cache
from typing import List, Dict, Tuple, Optional, Sequence
from dataclasses import dataclass
from .config_loader import SubjectConfig
from .cropping_engine import CroppedQuestion
from .qp_ms_matcher import MatchedQuestion


@lru_cache(maxsize=None)
def _keyword_pattern(kw: str):
    """U3: compile each keyword regex ONCE per process.

    The scoring loop (topic x subpart x keyword) previously re-invoked
    re.compile for every cell of that product; identical regex string,
    identical semantics, now held by strong reference.
    """
    return re.compile(r'\b' + re.escape(kw) + r'\b', re.IGNORECASE)

# =============================================================================
# MERGED SPEC v1.0 SCORING FACTORS  (overseer-approved merge into the point
# system: mark-weighted sub-part scoring, chemical-formula bonus, command-verb
# boost, paper-affinity multiplier, generic-term collision dampening, 4-topic
# cap, forced fallback). Routing contract, Major->detailed mapping, winner
# selection, tie-breaking and ClassificationResult are unchanged.
# Corpus decision (overseer): QUESTION PAPER TEXT ONLY - mark schemes and
# examiner reports no longer feed the topic scorer.
# =============================================================================

# Point-system invariants (spec core rules: never more than 4 topics)
MAX_TOPICS = 4
FORMULA_BONUS = 3.0            # per unique chemical formula exact match
COMMAND_MULTIPLIER = 1.5       # sub-part score multiplier when command verb found
PAPER_AFFINITY_MUL = 1.2       # when paper number is in the topic's affinity list
COLLISION_THRESHOLD = 0.40     # terms in >40% of detailed topics are "generic"
COLLISION_DAMPEN = 0.5         # per-hit dampening factor for generic terms
# Buff 2026-08-13: MCQ option down-weighting. Cambridge MCQ options are
# distractor-rich (the wrong topics' vocabulary lives in the options), so
# keyword hits in the option block score at 0.4x. The stem carries the true
# signal. Only fires when the text has the standalone A/B/C/D option layout.
MCQ_OPTION_WEIGHT = 0.4

_OPTION_LINE_RE = re.compile(r"(?m)^\s*([a-d])\s*$")


def _split_subpart_options(sp_text: str) -> "tuple[str, str]":
    """Split an MCQ subpart into (stem, options). The first standalone
    single-letter line A-D marks the start of the option block; everything
    before it is the stem. The MCQ signature is >= 2 such lines (options come
    in 3-4); a lone stray letter (table cell, axis label) never triggers the
    split. Structured (non-MCQ) text returns (sp_text, "")."""
    m = _OPTION_LINE_RE.search(sp_text)
    if not m:
        return sp_text, ""
    if len(_OPTION_LINE_RE.findall(sp_text[m.end():])) < 1:
        return sp_text, ""
    return sp_text[:m.start()], sp_text[m.start():]

# Unicode subscript/superscript digits -> ASCII (formula normalisation)
_SUBSCRIPT_MAP = {
    "\u2080": "0", "\u2081": "1", "\u2082": "2", "\u2083": "3", "\u2084": "4",
    "\u2085": "5", "\u2086": "6", "\u2087": "7", "\u2088": "8", "\u2089": "9",
    "\u2070": "0", "\u00b9": "1", "\u00b2": "2", "\u00b3": "3", "\u2074": "4",
    "\u2075": "5", "\u2076": "6", "\u2077": "7", "\u2078": "8", "\u2079": "9",
}

# Unicode chemistry symbols -> ASCII.
# NOTE (spec fix): U+2212 MINUS SIGN added - the spec's own Problem 5 requires
# "[Fe(CN)6]3-" -> "[Fe(CN)6]3-" but its symbol table omitted this character.
_CHEM_SYMBOL_MAP = {
    "\u2192": "->", "\u21cc": "<=>", "\u21d2": "=>", "\u2261": "===",
    "\u00b1": "+/-", "\u00b0": " degrees ", "\u2206": "delta", "\u0394": "delta",
    "\u03b1": "alpha", "\u03b2": "beta", "\u03b3": "gamma", "\u03bb": "lambda",
    "\u03bc": "mu", "\u03c3": "sigma", "\u03c0": "pi", "\u2212": "-",
}

_LIGATURE_MAP = {
    "\ufb01": "fi", "\ufb02": "fl", "\ufb00": "ff",
    "\ufb03": "ffi", "\ufb04": "ffl",
}

# Cambridge command verbs (spec full list)
COMMAND_VERBS = {
    "calculate", "state", "explain", "describe", "determine", "draw", "sketch",
    "deduce", "suggest", "predict", "identify", "write", "show", "define",
    "compare", "outline", "discuss", "justify", "estimate", "derive",
    "construct", "plot", "complete", "balance", "name", "give", "list",
    "comment",
}

# Sub-part header: (a), (b)(i), "1(a)" etc., line anchored
_SUBPART_PATTERN = re.compile(
    r"^\s*(?:\d+\s*)?\(([a-z]+)\)(?:\s*\([ivxlc]+\))?\s*",
    re.IGNORECASE | re.MULTILINE,
)
# Mark allocation: [1], [2], [3 marks]  —  [Total: n] is matched SEPARATELY and
# must never inflate a single sub-part's weight (spec mark-extraction fix).
_MARK_PATTERN = re.compile(r"\[(\d+)(?:\s*marks?)?\]", re.IGNORECASE)
_TOTAL_PATTERN = re.compile(r"\[Total\s*:\s*(\d+)\]", re.IGNORECASE)

# Chemical formula extraction (H2SO4, Fe2O3, [Cu(NH3)4]2+, CH3COOH, ...)
_FORMULA_EXTRACT_PATTERN = re.compile(
    r"\b[A-Z][a-z]?(?:\d+)?(?:[A-Z][a-z]?(?:\d+)?)+(?:[0-9]+[+\-])?\b"
    r"|\[[A-Z][^\]]+\][0-9]*[+\-]?"
)

# Paper-number heuristic hints for the forced fallback (spec FallbackClassifier)
# Amendment (final-upgrade Issue 2, 2026-08-10, approved): hints are now keyed
# PER SUBJECT — a Chemistry-shaped hint can never leak into another subject's
# fallback chain. Subjects not listed simply have no paper hints (the keyword
# and alphabetical-first fallbacks below still apply, exactly as before).
_FALLBACK_PAPER_HINTS: Dict[str, Dict[int, List[str]]] = {
    "Chemistry_9701": {
        1: ["Multiple_choice"],
        2: ["Atomic_structure", "Bonding", "Periodicity"],
        3: ["Practical_skills", "Planning", "Analysis_conclusions"],
        4: ["Reaction_kinetics", "Equilibria", "Electrochemistry"],
        5: ["Planning", "Analysis_conclusions_and_evaluation"],
    },
    "Biology_9700": {
        1: ["Multiple_choice"],
        2: ["Cell_structure", "Biological_molecules"],
        4: ["Genetics", "Ecology"],
    },
    "Physics_9702": {
        1: ["Multiple_choice"],
        2: ["Kinematics", "Forces"],
        4: ["Waves", "Electricity"],
    },
}


def _resolve_hint_topic(hint: str, detailed_topics) -> Optional[str]:
    """Resolve a fallback hint onto a CONFIGURED detailed topic.

    Never invents a topic: exact match, then case/space-insensitive match,
    then a unique normalised prefix/containment match; otherwise None, so the
    caller keeps walking its chain. This replaces the previous plain
    ``hint in detailed_topics`` membership test (same guard, more tolerant
    spelling forms like "Cell_structure" vs "Cell Structure").
    """
    if not hint:
        return None
    topics = list(detailed_topics or [])
    if hint in topics:
        return hint
    hn = hint.lower().replace(" ", "_").replace("-", "_")
    normed = {t.lower().replace(" ", "_").replace("-", "_"): t for t in topics}
    if hn in normed:
        return normed[hn]
    near = [t for t, n in normed.items() if n.startswith(hn) or hn in n]
    if len(near) == 1:
        return near[0]
    return None


def _normalize_text(raw: str) -> Tuple[str, str]:
    """Normalise raw PDF text for classification. Returns (lowercase, cased)."""
    text = raw
    for u, a in _SUBSCRIPT_MAP.items():
        text = text.replace(u, a)
    for u, a in _CHEM_SYMBOL_MAP.items():
        text = text.replace(u, a)
    text = re.sub(r"([A-Z][a-z]?)\s+(\d)", r"\1\2", text)  # "H2SO 4" -> "H2SO4"
    for lig, rep in _LIGATURE_MAP.items():
        text = text.replace(lig, rep)
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)            # "identi-\nfied"
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.lower(), text


def _extract_formulas(cased_text: str) -> set:
    """Chemical formulas from CASE-preserved text; returned lowercased so
    matching against keyword lists is case-insensitive (checklist item)."""
    return {m.lower() for m in _FORMULA_EXTRACT_PATTERN.findall(cased_text)}


def _extract_marks(block: str) -> int:
    """Highest single-part mark allocation in a block; [Total: n] ignored."""
    marks = [int(m.group(1)) for m in _MARK_PATTERN.finditer(block)]
    return max(marks) if marks else 0


def _parse_subparts(norm_lower: str, norm_cased: str, qp_marks: int) -> List[dict]:
    """Split normalised question text into scored units with mark weights."""
    boundaries = list(_SUBPART_PATTERN.finditer(norm_lower))

    def _has_command(text: str) -> bool:
        return any(re.search(r"\b" + v + r"\b", text, re.IGNORECASE) for v in COMMAND_VERBS)

    if not boundaries:
        return [{
            "label": "whole", "text": norm_lower,
            "marks": qp_marks if qp_marks > 0 else 1,
            "has_command": _has_command(norm_lower),
        }]

    subparts = []
    for i, b in enumerate(boundaries):
        start = b.end()
        end = boundaries[i + 1].start() if i + 1 < len(boundaries) else len(norm_lower)
        block = norm_lower[start:end]
        marks = _extract_marks(norm_cased[start:end] if end <= len(norm_cased) else block)
        subparts.append({
            "label": b.group(1), "text": block,
            "marks": marks if marks > 0 else 1,
            "has_command": _has_command(block),
        })
    return subparts


def _paper_number_from_variant(variant) -> int:
    try:
        return int(str(variant).strip()[0])
    except Exception:
        return 0


# High-signal phrases for the currently supported real-world target subjects.
# These are stronger than generic keyword overlap and exist to break common
# collisions without touching crop/ER logic.
PHRASE_BONUS_WEIGHT = 2.4
SCIENCE_AMBIGUITY_SUBJECTS = {
    "Chemistry_9701", "Physics_9702", "Biology_9700",
    "Chemistry_0620", "Physics_0625", "Biology_0610",
}
_SUBJECT_PHRASE_BONUSES: Dict[str, Dict[str, Sequence[str]]] = {
    "Chemistry_9701": {
        "Chemical_bonding": ("bond angle", "lone pair", "dative covalent", "sigma bond", "pi bond"),
        "Chemical_energetics": ("hess's law", "hess cycle", "bond enthalpy", "enthalpy change", "calorimeter"),
        "Electrochemistry": ("standard electrode potential", "electrode potential", "electrochemical cell", "salt bridge", "half-cell"),
        "Equilibria": ("equilibrium constant", "le chatelier", "buffer solution", "kc", "kp"),
        "Reaction_kinetics": ("rate equation", "order of reaction", "initial rate", "activation energy", "arrhenius"),
        "Group_2": ("thermal stability", "solubility of hydroxides", "solubility of sulfates"),
        "Group_17": ("halogen displacement", "chlorine water", "disproportionation"),
        "Hydroxy_compounds": ("alcohol oxidation", "iodoform test", "secondary alcohol"),
        "Carbonyl_compounds": ("2,4-dnph", "tollens", "fehling", "cyanohydrin"),
        "Carboxylic_acids_and_derivatives": ("acyl chloride", "acid anhydride", "esterification"),
        "Nitrogen_compounds": ("amine", "amide", "ammonium salt", "nitrile"),
        "Organic_synthesis": ("reagents and conditions", "convert compound", "synthesis route"),
        "Analytical_techniques": ("mass spectrum", "infrared spectrum", "nmr spectrum", "retention factor", "chromatography"),
        "Chemistry_of_transition_elements": ("ligand", "complex ion", "coordination number", "coloured ion"),
        "An_introduction_to_A_Level_organic_chemistry": ("optical isomerism", "stereoisomer", "e/z", "chiral carbon", "enantiomer"),
    },
    "Physics_9702": {
        "Physical_quantities_and_units": ("percentage uncertainty", "systematic error", "base unit"),
        "Kinematics": ("displacement-time graph", "velocity-time graph", "uniform acceleration", "suvat"),
        "Dynamics": ("newton's second law", "conservation of momentum", "impulse"),
        "Forces_density_and_pressure": ("stokes law", "upthrust", "centre of gravity", "moment of a force"),
        "Work_energy_and_power": ("kinetic energy", "gravitational potential energy", "power output"),
        "Deformation_of_solids": ("young modulus", "stress-strain", "hooke's law"),
        "Waves": ("diffraction grating", "polarisation", "doppler effect"),
        "Superposition": ("double slit", "path difference", "stationary wave"),
        "Electricity": ("drift velocity", "charge carrier", "coulomb"),
        "D_C_circuits": ("internal resistance", "potential divider", "kirchhoff", "potentiometer"),
        "Particle_physics": ("quark", "lepton", "antiparticle"),
        "Motion_in_a_circle": ("centripetal force", "angular velocity"),
        "Gravitational_fields": ("gravitational potential", "escape velocity", "geostationary"),
        "Temperature": ("specific latent heat", "specific heat capacity", "kelvin scale"),
        "Ideal_gases": ("pv=nrt", "root mean square", "kinetic theory"),
        "Thermodynamics": ("first law of thermodynamics", "internal energy", "adiabatic"),
        "Oscillations": ("simple harmonic motion", "resonance", "damping"),
        "Electric_fields": ("coulomb's law", "electric potential", "parallel plates"),
        "Capacitance": ("time constant", "discharge of capacitor", "dielectric"),
        "Magnetic_fields": ("magnetic flux density", "lenz's law", "fleming"),
        "Alternating_currents": ("root mean square", "rectification", "transformer"),
        "Quantum_physics": ("photoelectric effect", "work function", "de broglie"),
        "Nuclear_physics": ("half-life", "binding energy", "mass defect"),
        "Medical_physics": ("ultrasound", "acoustic impedance", "pet scan", "ct scan"),
        "Astronomy_and_cosmology": ("hubble law", "redshift", "wien's law", "stefan"),
    },
    "Biology_9700": {
        "Cell_structure": ("rough endoplasmic reticulum", "golgi body", "secretory vesicle", "electron microscope"),
        "Biological_molecules": ("biuret test", "benedict's test", "glycosidic bond", "peptide bond", "phosphodiester"),
        "Enzymes": ("induced fit", "competitive inhibitor", "non-competitive inhibitor", "enzyme-substrate complex"),
        "Cell_membranes_and_transport": ("facilitated diffusion", "sodium-potassium pump", "water potential", "fluid mosaic"),
        "The_mitotic_cell_cycle": ("interphase", "metaphase", "anaphase", "telophase", "homologous chromosomes"),
        "Nucleic_acids_and_protein_synthesis": ("mrna", "trna", "codon", "anticodon", "semi-conservative"),
        "Transport_in_plants": ("transpiration stream", "cohesion-tension", "sieve tube element"),
        "Transport_in_mammals": ("haemoglobin dissociation curve", "tissue fluid", "cardiac cycle"),
        "Gas_exchange": ("partial pressure", "tracheole", "ventilation rate"),
        "Infectious_diseases": ("pathogen transmission", "cholera", "hiv", "tuberculosis"),
        "Immunity": ("clonal selection", "memory cell", "monoclonal antibody"),
        "Energy_and_respiration": ("glycolysis", "krebs cycle", "oxidative phosphorylation"),
        "Photosynthesis": ("light-dependent", "calvin cycle", "rubisco", "photophosphorylation"),
        "Homeostasis": ("negative feedback", "osmoregulation", "thermoregulation", "blood glucose"),
        "Control_and_coordination": ("action potential", "synaptic cleft", "pacinian corpuscle", "photoreceptor"),
        "Inheritance": ("test cross", "codominant", "linkage", "crossing over"),
        "Selection_and_evolution": ("selection pressure", "allele frequency", "stabilising selection"),
        "Classification_biodiversity_and_conservation": ("biodiversity index", "binomial name", "conservation"),
        "Genetic_technology": ("gel electrophoresis", "polymerase chain reaction", "genetic engineering"),
    },
    "Chemistry_0620": {
        "States_of_matter": ("particle theory", "brownian motion", "intermolecular forces"),
        "Atoms_elements_and_compounds": ("atomic number", "mass number", "electronic configuration"),
        "Stoichiometry": ("empirical formula", "limiting reagent", "molar volume"),
        "Electrochemistry": ("electrolysis", "selective discharge", "electroplating"),
        "Chemical_energetics": ("exothermic", "endothermic", "hess's law", "calorimetry"),
        "Chemical_reactions": ("rate of reaction", "collision theory", "le chatelier", "equilibrium"),
        "Acids_bases_and_salts": ("titration", "neutralisation", "preparation of salt"),
        "The_Periodic_Table": ("transition metal", "reactivity trend", "group 7", "group 0"),
        "Metals": ("blast furnace", "rusting", "alloy", "reactivity series"),
        "Chemistry_of_the_environment": ("greenhouse effect", "acid rain", "water treatment", "global warming"),
        "Organic_chemistry": ("homologous series", "esterification", "addition polymerisation", "bromine water"),
        "Experimental_techniques_and_chemical_analysis": ("chromatography", "flame test", "anion test", "gas test", "distillation"),
    },
    "Physics_0625": {
        "Motion_forces_and_energy": ("distance-time graph", "velocity-time graph", "moment of a force", "hooke's law"),
        "Thermal_physics": ("specific heat capacity", "latent heat", "conduction", "convection"),
        "Waves": ("total internal reflection", "electromagnetic spectrum", "diffraction"),
        "Electricity_and_magnetism": ("potential difference", "electromagnetic induction", "logic gate", "transformer", "fuse"),
        "Nuclear_physics": ("half-life", "background radiation", "fission", "fusion"),
        "Space_physics": ("solar system", "big bang", "redshift", "orbit of earth"),
    },
    "Biology_0610": {
        "Organisation_of_the_organism": ("cell membrane", "palisade mesophyll", "xylem vessel", "magnification"),
        "Movement_into_and_out_of_cells": ("partially permeable", "active transport", "water potential", "osmosis"),
        "Biological_molecules": ("biuret", "benedict", "iodine test", "emulsion test"),
        "Enzymes": ("active site", "lock and key", "optimum temperature"),
        "Plant_nutrition": ("photosynthesis", "limiting factor", "chlorophyll"),
        "Human_nutrition": ("alimentary canal", "villus", "bile", "amylase"),
        "Transport_in_plants": ("transpiration stream", "root hair", "xylem", "phloem"),
        "Transport_in_animals": ("double circulation", "red blood cell", "plasma"),
        "Diseases_and_immunity": ("antibody", "vaccination", "pathogen"),
        "Gas_exchange_in_humans": ("alveoli", "ventilation", "breathing rate"),
        "Respiration": ("aerobic", "anaerobic", "fermentation"),
        "Excretion_in_humans": ("ultrafiltration", "dialysis", "nephron"),
        "Coordination_and_response": ("reflex arc", "synapse", "hormone", "homeostasis"),
        "Reproduction": ("menstrual cycle", "fertilisation", "pollination", "germination"),
        "Inheritance": ("dominant", "recessive", "genotype", "phenotype"),
        "Variation_and_selection": ("natural selection", "adaptation", "mutation"),
        "Organisms_and_their_environment": ("food web", "trophic level", "nitrogen cycle"),
        "Human_influences_on_ecosystems": ("eutrophication", "deforestation", "conservation"),
        "Biotechnology_and_genetic_modification": ("fermenter", "plasmid", "genetic modification"),
    },
}


def _apply_subject_phrase_bonus(subject: str, topic: str, text_lower: str) -> tuple[float, int]:
    phrases = _SUBJECT_PHRASE_BONUSES.get(subject, {}).get(topic, ())
    if not phrases:
        return 0.0, 0
    # Buff 2026-08-13: per-glyph PDF extraction inserts newlines between words
    # ("reagents\nand\nconditions"), so multi-word phrases silently missed.
    # Collapse whitespace once so every phrase bonus actually matches.
    text_lower = re.sub(r"\s+", " ", text_lower)
    hits = sum(text_lower.count(p.lower()) for p in phrases)
    return (hits * PHRASE_BONUS_WEIGHT, hits)


def _science_ambiguity_reason(subject: str, major_scores: Dict[str, float]) -> Optional[str]:
    if subject not in SCIENCE_AMBIGUITY_SUBJECTS or not major_scores:
        return None
    ranked = sorted(major_scores.items(), key=lambda kv: kv[1], reverse=True)
    if len(ranked) == 1:
        top = ranked[0][1]
        if top < 3.0:
            return f"weak sole major score {top:.2f}"
        return None
    top_name, top_score = ranked[0]
    second_name, second_score = ranked[1]
    gap = top_score - second_score
    if top_score < 3.0 and second_score > 0:
        return f"weak evidence top={top_name}:{top_score:.2f} second={second_name}:{second_score:.2f}"
    if gap <= 0.40:
        return f"near-tie top={top_name}:{top_score:.2f} second={second_name}:{second_score:.2f}"
    if second_score > 0 and gap <= 1.0 and (second_score / max(top_score, 1e-9)) >= 0.87:
        return f"ambiguous top={top_name}:{top_score:.2f} second={second_name}:{second_score:.2f}"
    return None


@dataclass
class ClassificationResult:
    detailed_topics: List[str]  # For JSON
    major_topic_scores: Dict[str, float]  # major -> score
    winning_major: str
    topic_marks_breakdown: Dict[str, int]  # detailed -> marks estimate
    reasoning: str
    # CLS-4 (2026-08-10, Overseer review_required): which fallback tier produced
    # the winner: "scored" (>=1.5 threshold), "weak_keyword", "paper_hint", or
    # "alphabetical_first". The last two are the DESPERATE tiers that route a
    # question to review_required/classification_failed. Default keeps the math
    # specially-routed early returns byte-compatible.
    # RS-17: "review_required" = deterministic evidence was insufficient
    # (spec: ambiguous input -> REVIEW_REQUIRED; never an alphabetical pick).
    fallback_tier: str = "scored"
    # RS-17 (Fix 8): deterministic diagram signals harvested from the QP crop
    # (counts of angle arcs, triangles, arrows, axes+curves, greek labels, ...).
    # None when no raster was available.
    diagram_evidence: dict | None = None

class TopicClassifier:
    def __init__(self, subject_config: SubjectConfig):
        self.config = subject_config
        # Preprocess keywords to lower
        self.keywords_lower = {}
        for detailed, kws in self.config.classification_keywords.items():
            self.keywords_lower[detailed] = [kw.lower() for kw in kws]
        # Generic-term collision index (built ONCE at load): fraction of
        # detailed topics containing each keyword. Terms in >40% of topics are
        # dampened per hit so shared vocabulary cannot dominate scoring.
        self._collision_index: Dict[str, float] = {}
        total = len(self.config.detailed_topics) or 1
        counts: Dict[str, int] = {}
        for detailed in self.config.detailed_topics:
            for kw in set(self.keywords_lower.get(detailed, [])):
                kw_n = kw.strip()
                counts[kw_n] = counts.get(kw_n, 0) + 1
        self._collision_index = {t: c / total for t, c in counts.items()}

    _diagram_cache: dict = {}

    def _harvest_diagram_evidence(self, matched_question: MatchedQuestion) -> dict | None:
        """RS-17 (Fix 8): deterministic diagram signals from the QP crop raster.
        Never raises — no raster / harvest failure degrades to None (text-only).

        Amendment 10: memoized per question_number. The paper-coherence
        two-pass calls classify_question twice per question; harvesting
        HoughLinesP+findContours on 2280px crops twice was 2.24s/paper
        (measured). Question numbers are unique within a paper, so the key
        is safe."""
        try:
            _key = f"q{getattr(matched_question, 'question_number', '')}"
            if _key in self._diagram_cache:
                return self._diagram_cache[_key]
            qp = getattr(matched_question, "qp", None)
            if qp is None:
                return None
            image = getattr(qp, "assembled_image", None)
            if image is None and getattr(qp, "images", None):
                image = qp.images[0]
            if image is None:
                image = getattr(qp, "image", None)
            if image is None:
                return None
            import numpy as np
            arr = np.asarray(image)
            if arr.size == 0:
                return None
            text = getattr(qp, "text", "") or ""
            from .diagram_evidence import harvest_diagram_evidence
            _res = harvest_diagram_evidence(arr, text=text)
            self._diagram_cache[_key] = _res
            return _res
        except Exception:
            self._diagram_cache[_key] = None
            return None

    def classify_question(self, matched_question: MatchedQuestion,
                          coherence_prior: "Optional[dict] | None" = None,
                          force_winner: bool = False) -> ClassificationResult:
        """coherence_prior (Buff 2026-08-13): {topic: win_count} accumulated over
        the rest of the same paper. Used ONLY to resolve an otherwise-ambiguous
        near-tie: topics with >= 2 wins elsewhere in the paper get a small bonus
        (0.5 * wins, capped +1.5) BEFORE the ambiguity gate. Confident winners
        are never touched; the bonus only ever applies when the pre-prior state
        was ambiguous.``"""
        """
        Classify a matched QP/MS question into detailed topics and major topic winner
        For Mathematics/Further Mathematics: Uses paper/component based categorization, NOT detailed question-level
        For other subjects: Uses detailed topic classification as before
        """
        # SPECIAL HANDLING FOR MATHEMATICS-RELATED SUBJECTS (Part 1)
        # Per requirement: For Mathematics and Further Mathematics, do NOT attempt detailed question-level classification
        # Category determined by paper/component identity
        try:
            from .math_category import is_mathematics_subject, get_canonical_math_category, is_paper_7, verify_paper7_mapping, get_paper_number_from_variant
            import os

            # Check if this is Mathematics-related subject
            is_math = is_mathematics_subject(self.config.subject, self.config.syllabus_code)

            if is_math:
                # Get paper number from variant
                variant = matched_question.variant
                paper_number = get_paper_number_from_variant(variant)
                year = matched_question.year
                season = matched_question.season
                subject = self.config.subject
                syllabus_code = self.config.syllabus_code

                # Mathematics 9709 only: the filename selects P1–P6 and the
                # uploaded reference file limits question classification to that
                # paper's exact subtopic strings. Other Mathematics syllabuses
                # retain their existing component-category behavior below.
                if str(syllabus_code) == "9709" and paper_number in range(1, 7):
                    from .math_reference import classify_9709_question
                    diagram = self._harvest_diagram_evidence(matched_question)
                    reference_topic = classify_9709_question(
                        matched_question.qp.text or "",
                        paper_number,
                        diagram=diagram,
                        force=force_winner,
                    )
                    if reference_topic is None:
                        return ClassificationResult(
                            detailed_topics=[],
                            major_topic_scores={},
                            winning_major="",
                            topic_marks_breakdown={},
                            reasoning=(
                                f"Mathematics 9709 P{paper_number}: no deterministic text/formula/"
                                f"diagram evidence for any official topic -> REVIEW_REQUIRED"
                            ),
                            fallback_tier="review_required",
                            diagram_evidence=diagram,
                        )
                    return ClassificationResult(
                        detailed_topics=[reference_topic],
                        major_topic_scores={reference_topic: 10.0},
                        winning_major=reference_topic,
                        topic_marks_breakdown={reference_topic: matched_question.qp.marks or 5},
                        reasoning=(
                            f"Mathematics 9709 filename component {variant}: P{paper_number}; "
                            f"classified only within that paper's reference topics -> {reference_topic}"
                            + (f" | diagram evidence: {diagram}" if diagram else "")
                        ),
                        diagram_evidence=diagram,
                    )

                # Further Mathematics 9231: reference-file vocabulary, question-level.
                if str(syllabus_code) == "9231" and paper_number in range(1, 5):
                    from .math_reference import classify_9231_question
                    diagram = self._harvest_diagram_evidence(matched_question)
                    reference_topic = classify_9231_question(
                        matched_question.qp.text or "",
                        paper_number,
                        diagram=diagram,
                        force=force_winner,
                    )
                    if reference_topic is None:
                        return ClassificationResult(
                            detailed_topics=[],
                            major_topic_scores={},
                            winning_major="",
                            topic_marks_breakdown={},
                            reasoning=(
                                f"Further Mathematics 9231 P{paper_number}: no deterministic "
                                f"evidence for any official topic -> REVIEW_REQUIRED"
                            ),
                            fallback_tier="review_required",
                            diagram_evidence=diagram,
                        )
                    return ClassificationResult(
                        detailed_topics=[reference_topic],
                        major_topic_scores={reference_topic: 10.0},
                        winning_major=reference_topic,
                        topic_marks_breakdown={reference_topic: matched_question.qp.marks or 5},
                        reasoning=(
                            f"Further Mathematics 9231 filename component {variant}: P{paper_number}; "
                            f"classified within that paper's reference topics -> {reference_topic}"
                            + (f" | diagram evidence: {diagram}" if diagram else "")
                        ),
                        diagram_evidence=diagram,
                    )

                # IGCSE Mathematics 0580: question-level routing into the 9
                # official topic areas (spec Fix 8; replaces component-name
                # 'classification' which put every question in a paper bucket).
                if str(syllabus_code) == "0580":
                    from .math_reference import classify_0580_question
                    diagram = self._harvest_diagram_evidence(matched_question)
                    topic = classify_0580_question(
                        matched_question.qp.text or "",
                        diagram=diagram,
                        force=force_winner,
                    )
                    if topic is None:
                        return ClassificationResult(
                            detailed_topics=[],
                            major_topic_scores={},
                            winning_major="",
                            topic_marks_breakdown={},
                            reasoning=(
                                "Mathematics 0580: no deterministic text/formula/diagram "
                                "evidence for any of the 9 official topic areas -> REVIEW_REQUIRED"
                            ),
                            fallback_tier="review_required",
                            diagram_evidence=diagram,
                        )
                    return ClassificationResult(
                        detailed_topics=[topic],
                        major_topic_scores={topic: 10.0},
                        winning_major=topic,
                        topic_marks_breakdown={topic: matched_question.qp.marks or 5},
                        reasoning=(
                            f"Mathematics 0580 question-level routing -> {topic}"
                            + (f" | diagram evidence: {diagram}" if diagram else "")
                        ),
                        diagram_evidence=diagram,
                    )

                # IGCSE Additional Mathematics 0606 uses the official
                # question-level topic names, not a paper-number pseudo-topic.
                if str(syllabus_code) == "0606":
                    from .math_reference import classify_0606_question
                    diagram = self._harvest_diagram_evidence(matched_question)
                    topic = classify_0606_question(
                        matched_question.qp.text or "",
                        diagram=diagram,
                        force=force_winner,
                    )
                    if topic is None:
                        return ClassificationResult(
                            detailed_topics=[],
                            major_topic_scores={},
                            winning_major="",
                            topic_marks_breakdown={},
                            reasoning=(
                                "Mathematics 0606: no deterministic text/formula/diagram "
                                "evidence for any of the 14 official topic areas -> REVIEW_REQUIRED"
                            ),
                            fallback_tier="review_required",
                            diagram_evidence=diagram,
                        )
                    return ClassificationResult(
                        detailed_topics=[topic],
                        major_topic_scores={topic: 10.0},
                        winning_major=topic,
                        topic_marks_breakdown={topic: matched_question.qp.marks or 5},
                        reasoning=(
                            f"Additional Mathematics 0606 question-level routing -> {topic}"
                            + (f" | diagram evidence: {diagram}" if diagram else "")
                        ),
                        diagram_evidence=diagram,
                    )

                # Check for Paper 7 special handling
                if is_paper_7(variant, paper_number):
                    print(f"[MathCategory] Paper 7 detected: variant {variant}, paper {paper_number} for {self.config.subject} {self.config.syllabus_code}")

                    # Online verification should trigger ONLY for Paper 7 per requirement 7
                    # Extract metadata for verification
                    year = matched_question.year
                    season = matched_question.season
                    subject = self.config.subject
                    syllabus_code = self.config.syllabus_code

                    # Try to get cached mapping first
                    from .math_category import get_cached_paper7_mapping
                    cached = get_cached_paper7_mapping(syllabus_code, year, season, subject, paper_number, variant)

                    if cached:
                        canonical = cached["verified_mapping"]
                        print(f"[MathCategory] Using cached Paper 7 mapping: {canonical}")
                    else:
                        # Perform verification - for Mathematics, variant like 17,27,37,47 are actually Paper 1,2,3,4 variant 7
                        # So Paper 7 detection for variant 17,27,37,47 should map to existing component
                        verified_mapping, source, is_verified = verify_paper7_mapping(
                            syllabus_code, year, season, subject, paper_number, variant,
                            pdf_path=str(matched_question.qp.paper_code) if hasattr(matched_question.qp, 'paper_code') else ""
                        )

                        if is_verified:
                            canonical = verified_mapping
                            print(f"[MathCategory] Paper 7 verified: {canonical} from {source}")
                        else:
                            # If not verified, try to determine if it's actually variant 7 of existing paper
                            # For Mathematics, 17 = Paper 1 variant 7, 27 = Paper 2 variant 7, etc.
                            try:
                                v_str = str(variant).lstrip("0")
                                if len(v_str) == 2 and v_str[1] == "7":
                                    actual_paper = int(v_str[0])
                                    canonical = get_canonical_math_category(syllabus_code, actual_paper, variant)
                                    print(f"[MathCategory] Paper 7 variant {variant} -> Paper {actual_paper} variant 7 -> {canonical} (fallback)")
                                    # Cache it
                                    from .math_category import cache_paper7_mapping
                                    cache_paper7_mapping(syllabus_code, year, season, subject, paper_number, variant, canonical, source)
                                else:
                                    # Independent Paper 7
                                    canonical = f"P7_Paper_7_Variant_{variant}"
                                    print(f"[MathCategory] Paper 7 independent: {canonical} (needs online verification)")
                            except Exception as e:
                                canonical = get_canonical_math_category(syllabus_code, paper_number, variant)
                                print(f"[MathCategory] Paper 7 fallback to direct: {canonical} due to {e}")

                    # For Mathematics, category is determined by paper, NOT question content
                    # Return canonical category as both detailed and winning major
                    # No duplication, one category only per requirement 5

                    # Ensure canonical category is in config major_topics, if not, add to detailed?
                    # For Mathematics, major_topics are like P1_Pure_Mathematics_1 etc., which should include canonical

                    # If canonical not in major_topics, we need to check if it's close to existing
                    # For now, use canonical as winning major, and detailed as [canonical]

                    # For JSON, topic should be [canonical] per Part 7 example
                    return ClassificationResult(
                        detailed_topics=[canonical],
                        major_topic_scores={canonical: 10.0},
                        winning_major=canonical,
                        topic_marks_breakdown={canonical: matched_question.qp.marks or 5},
                        reasoning=f"Mathematics paper-based categorization: Paper {paper_number} Variant {variant} -> {canonical} (paper/component identity, not question content per requirement)"
                    )

                # Normal Mathematics papers 1-6 - no online verification needed
                else:
                    canonical = get_canonical_math_category(syllabus_code, paper_number, variant)
                    print(f"[MathCategory] Mathematics paper-based: Paper {paper_number} Variant {variant} -> {canonical}")

                    return ClassificationResult(
                        detailed_topics=[canonical],
                        major_topic_scores={canonical: 10.0},
                        winning_major=canonical,
                        topic_marks_breakdown={canonical: matched_question.qp.marks or 5},
                        reasoning=f"Mathematics paper-based categorization: Paper {paper_number} -> {canonical} (official component, not question content)"
                    )

        except Exception as e:
            # If math_category handling fails, fall back to normal classification
            # Do not break existing non-Mathematics classification
            print(f"[Classifier] Mathematics categorization failed for {self.config.subject}, falling back to detailed classification: {e}")
            import traceback
            traceback.print_exc()

        # For non-Mathematics subjects: merged spec v1.0 scorer on the existing
        # point system. CORPUS DECISION (overseer): QUESTION PAPER TEXT ONLY -
        # mark-scheme/examiner text no longer feeds topic scoring. The old
        # "MS dependency bonus" (ms_hits x 0.8) is retired with the MS corpus.
        qp_text = matched_question.qp.text or ""
        qp_marks = int(matched_question.qp.marks or 0)

        # 2026-08-13: corpus-derived science diagram evidence — harvested
        # ONCE for the question and used only as a SMALL supplement to text
        # evidence below (diagram-only input stays fail-closed REVIEW).
        diagram = self._harvest_diagram_evidence(matched_question)

        # Normalisation: sub/superscripts, unicode chemistry symbols (incl.
        # U+2212 minus), formula spacing, ligatures, hyphen rejoins.
        norm_lower, norm_cased = _normalize_text(qp_text)
        combined_text = norm_lower  # variable name kept for downstream code
        formulas = _extract_formulas(norm_cased)

        # Sub-part structure with per-part mark weights ([Total: n] excluded)
        subparts = _parse_subparts(norm_lower, norm_cased, qp_marks)
        total_est_marks = max(1, sum(sp["marks"] for sp in subparts))
        # Spec intent: "a sub-part worth [8] marks counts more than [1]". Applied
        # as a RELATIVE weight (part marks / mean part marks) so an 8-mark part
        # boosts and a 1-mark part damps, while the overall score scale — and
        # therefore the calibrated 1.5/1.0 thresholds — is preserved.
        mean_part_marks = total_est_marks / len(subparts)
        paper_number = _paper_number_from_variant(getattr(matched_question, "variant", 0))
        affinity_map = self.config.data.get("paper_affinity", {}) if hasattr(self.config, "data") else {}

        # Step 1: Identify every genuine detailed topic
        detailed_scores: Dict[str, float] = {}  # detailed -> raw score
        detailed_marks: Dict[str, int] = {}  # estimate marks per detailed
        subquestion_count: Dict[str, int] = {}
        formula_hits_map: Dict[str, List[str]] = {}
        # RS-23 (2026-08-14, real-paper accuracy finding 9701_w25_qp_11):
        # under full-auto the zero-evidence fallback blindly picked
        # detailed_topics[0] (Atomic_structure for 9701) — every calculation /
        # application MCQ with generic wording was dumped into that one topic
        # (~9 of 40 questions), a dominant share of the measured ~54.8%
        # accuracy loss. Track the best BELOW-threshold candidate so the
        # forced fallback picks the least-weak topic instead of index 0.
        near_miss_score: float = 0.0
        near_miss_topic: str = ""
        phrase_bonus_hits: Dict[str, int] = {}
        command_boost_count = 0
        dampened_terms: List[str] = []

        first_part = combined_text[:500]

        for detailed in self.config.detailed_topics:
            keywords = self.keywords_lower.get(detailed, [])
            if not keywords:
                continue

            topic_score = 0.0
            hit_count = 0
            specialized_weight = self.config.specialization_weights.get(detailed, 1.0)

            # --- Sub-part scoring: keyword hits x mark weight of containing
            #     sub-part, with per-hit diminishing returns (anti keyword
            #     stuffing), generic-term collision dampening, and command-verb
            #     boost applied ONLY when the sub-part scored > 0 ---
            for sp in subparts:
                sp_text = sp["text"]
                sp_stem, sp_opts = _split_subpart_options(sp_text)  # Buff: MCQ stem vs options
                sp_score = 0.0
                for kw in keywords:
                    pattern = _keyword_pattern(kw)  # U3: cached; pattern string unchanged
                    stem_matches = pattern.findall(sp_stem)
                    opt_matches = pattern.findall(sp_opts) if sp_opts else []
                    matches = stem_matches + opt_matches
                    if matches:
                        hit_count += len(matches)
                        prevalence = self._collision_index.get(kw.strip(), 0.0)
                        collision_factor = COLLISION_DAMPEN if prevalence > COLLISION_THRESHOLD else 1.0
                        if collision_factor != 1.0 and kw.strip() not in dampened_terms:
                            dampened_terms.append(kw.strip())
                        def _add_hits(n, weight):
                            nonlocal sp_score
                            for idx in range(n):
                                if idx == 0:
                                    sp_score += 2 * weight * specialized_weight * collision_factor
                                elif idx == 1:
                                    sp_score += 1 * weight * specialized_weight * collision_factor
                                else:
                                    sp_score += 0.5 * weight * specialized_weight * collision_factor
                        _add_hits(len(stem_matches), 1.0)
                        if opt_matches:
                            _add_hits(len(opt_matches), MCQ_OPTION_WEIGHT)
                if sp_score > 0 and sp["has_command"]:
                    sp_score *= COMMAND_MULTIPLIER
                    command_boost_count += 1
                topic_score += sp_score * (sp["marks"] / mean_part_marks)

            # - Central purpose (legacy factor, retained): keyword near the start
            central_hits = sum(1 for kw in keywords if kw in first_part)
            if central_hits > 0:
                topic_score += central_hits * 1.2

            # - Chemical formula exact-match bonus (case-insensitive; one bonus
            #   per unique formula string, not per occurrence)
            f_hits = sorted(formulas.intersection(keywords))
            if f_hits:
                topic_score += FORMULA_BONUS * len(f_hits)
                formula_hits_map[detailed] = f_hits

            # - Distinctive phrase bonuses for the target science subjects.
            phrase_bonus, phrase_hits = _apply_subject_phrase_bonus(self.config.subject, detailed, combined_text)
            if phrase_bonus:
                topic_score += phrase_bonus
                phrase_bonus_hits[detailed] = phrase_hits

            # - Paper affinity multiplier (config-driven; absent = no-op)
            topic_affinity = affinity_map.get(detailed, [])
            if paper_number and paper_number in topic_affinity:
                topic_score *= PAPER_AFFINITY_MUL

            # Threshold: need at least 1.5 points to be considered genuine (not just keyword appearance)
            if topic_score >= 1.5:
                detailed_scores[detailed] = topic_score
                subquestion_count[detailed] = hit_count
            elif topic_score > near_miss_score:
                # RS-23: remember the best near-miss (any evidence, below
                # threshold) for the full-auto forced fallback.
                near_miss_score = topic_score
                near_miss_topic = detailed

        # Fail closed when no configured topic reaches the evidence threshold.
        # Never force a weak keyword, paper hint, or alphabetical topic into the
        # production bank. The caller routes this result to review_required.
        fallback_tier = "scored"
        if not detailed_scores:
            if not force_winner:
                return ClassificationResult(
                    detailed_topics=[],
                    major_topic_scores={},
                    winning_major="",
                    topic_marks_breakdown={},
                    reasoning=(
                        f"No deterministic topic evidence passed the threshold for "
                        f"{self.config.subject} -> REVIEW_REQUIRED"
                    ),
                    fallback_tier="review_required",
                    diagram_evidence=diagram,
                )
            # RS-23: prefer the best near-miss (weakest-evidence topic) over
            # the config's index-0 topic; only fall back to index 0 when the
            # question carried literally no keyword evidence at all.
            _forced = near_miss_topic or (
                self.config.detailed_topics[0] if self.config.detailed_topics else "")
            _maj = self.config.mapping.get(_forced, "") if _forced else ""
            if not _maj and self.config.major_topics:
                _maj = self.config.major_topics[0]
                _forced = next((d for d in self.config.detailed_topics
                                if self.config.mapping.get(d) == _maj), _forced)
            winning_major = _maj
            fallback_tier = "auto_forced" if winning_major else "review_required"
            _auto = _forced
            _auto_reason = (f"Auto-assigned (--full-auto): no deterministic evidence -> {_maj}"
                            + (f" (near-miss {near_miss_topic} score={near_miss_score:.2f})"
                               if near_miss_topic else ""))

        # Step 2: Map to major topics and calculate major scores
        major_scores: Dict[str, float] = {}
        major_marks: Dict[str, int] = {}
        major_specialization: Dict[str, float] = {}

        for detailed, score in detailed_scores.items():
            major = self.config.mapping.get(detailed)
            if not major:
                continue
            if major not in major_scores:
                major_scores[major] = 0
                major_marks[major] = 0
                major_specialization[major] = 0

            # Point allocation based on:
            # - marks (we have qp.marks)
            # - subquestion count
            # - specialized knowledge
            # - reasoning etc approximated via score

            # Base: detailed score
            major_scores[major] += score

            # Specialization bonus
            spec_w = self.config.specialization_weights.get(detailed, 1.0)
            major_specialization[major] = max(major_specialization[major], spec_w)

            # Marks: distribute total marks proportionally to detailed scores
            # We'll calculate after loop

        # Distribute marks for point calculation
        total_marks = matched_question.qp.marks or 5  # default
        total_detailed_score = sum(detailed_scores.values()) or 1
        for detailed, score in detailed_scores.items():
            major = self.config.mapping.get(detailed)
            if not major:
                continue
            proportion = score / total_detailed_score
            estimated_marks = int(round(proportion * total_marks))
            detailed_marks[detailed] = estimated_marks
            major_marks[major] += estimated_marks

        # Enhance major scores with marks factor
        for major in major_scores:
            # Marks allocated is major factor
            major_scores[major] += major_marks.get(major, 0) * 0.5
            # Specialized knowledge
            major_scores[major] += major_specialization.get(major, 0) * 0.3

        # 2026-08-13: science diagram boosts (corpus-derived, conservative).
        # Applied ONLY here — after the empty-detailed_scores fail-closed gate
        # — so diagram signals break near-ties / rescue a text-evidenced
        # topic but can never route a diagram-only question. Weights are 1-3
        # points; text evidence still dominates.
        if diagram:
            try:
                from .science_diagram_signals import science_diagram_boosts
                _d_boosts = science_diagram_boosts(
                    str(self.config.syllabus_code), diagram)
                for _topic, _boost in _d_boosts.items():
                    if _topic in major_scores:
                        major_scores[_topic] += _boost
            except Exception:
                pass  # diagram boosts are strictly supplementary; never break

        # Buff 2026-08-13: paper-coherence prior. If the CURRENT scores are
        # ambiguous, topics that already won >= 2 questions elsewhere in the
        # same paper receive a small bonus (0.5 * wins, capped +1.5). This
        # only ever rescues an ambiguous question; confident winners are
        # never modified (the bonus is applied strictly before the gate and
        # only when the pre-prior state was ambiguous).
        _prior_used = {}
        _pre_ambig = _science_ambiguity_reason(self.config.subject, major_scores)
        if _pre_ambig and coherence_prior:
            for _t, _n in coherence_prior.items():
                if _n >= 2 and _t in major_scores:
                    _bonus = min(1.5, 0.5 * _n)
                    major_scores[_t] += _bonus
                    _prior_used[_t] = _n

        # Boss requirement #1 (2026-08-14): per-paper topic gating.
        _paper_gated = False
        _allowed = set()
        _paper_topics = self.config.data.get("paper_topics") if hasattr(self.config, "data") else None
        if _paper_topics and paper_number:
            _allowed = set(_paper_topics.get(str(paper_number), []))
            if _allowed:
                for _m in [m for m in major_scores if m not in _allowed]:
                    major_scores.pop(_m, None)
                _paper_gated = True

        ambiguity_reason = _science_ambiguity_reason(self.config.subject, major_scores)
        if ambiguity_reason:
            if not force_winner:
                return ClassificationResult(
                    detailed_topics=[],
                    major_topic_scores=major_scores,
                    winning_major="",
                    topic_marks_breakdown=detailed_marks,
                    reasoning=(
                        f"Ambiguous classification for {self.config.subject} -> REVIEW_REQUIRED | "
                        f"{ambiguity_reason} | detailed_scores={detailed_scores}"
                    ),
                    fallback_tier="review_required",
                    diagram_evidence=diagram,
                )
            _top = max(major_scores, key=major_scores.get)
            winning_major = _top
            fallback_tier = "auto_forced"
            _auto = _top
            _auto_reason = (f"Auto-assigned (--full-auto) after ambiguous classification | "
                            f"{ambiguity_reason}")

        # Step 3: Select winning major topic (single-folder requirement)
        winning_major = self._select_winner(major_scores, major_marks, major_specialization)
        if _paper_gated and not major_scores:
            if force_winner:
                _forced_major = None
                if _allowed:
                    _cand = [(d, s) for d, s in detailed_scores.items()
                             if self.config.mapping.get(d) in _allowed]
                    if _cand:
                        _forced_major = self.config.mapping.get(max(_cand, key=lambda kv: kv[1])[0])
                    else:
                        _forced_major = sorted(_allowed)[0]
                elif self.config.major_topics:
                    _forced_major = self.config.major_topics[0]
                winning_major = _forced_major or ""
                fallback_tier = "auto_forced" if winning_major else "review_required"
                _auto = winning_major
                _auto_reason = (f"Auto-assigned (--full-auto) after per-paper gate removed "
                                f"all candidates -> {winning_major}")
            else:
                winning_major = ""
                fallback_tier = "review_required"

        # Step 4: Detailed topics list for JSON (all genuine detailed topics, not just winner's)
        # Spec invariant: score-descending, de-duplicated, NEVER more than 4.
        genuine_detailed = [d for d, s in detailed_scores.items() if s >= 1.0]
        if not genuine_detailed:
            genuine_detailed = list(detailed_scores.keys())

        # Ensure at least 1 detailed topic
        if not genuine_detailed and self.config.detailed_topics:
            genuine_detailed = [sorted(self.config.detailed_topics)[0]]

        # Sort by score descending, then cap at MAX_TOPICS (spec hard limit)
        genuine_detailed.sort(key=lambda d: detailed_scores.get(d, 0), reverse=True)
        if len(genuine_detailed) > MAX_TOPICS:
            print(f"  [classifier] topic cap: keeping top {MAX_TOPICS} of {len(genuine_detailed)} genuine topics")
            genuine_detailed = genuine_detailed[:MAX_TOPICS]

        _auto = None
        _auto_reason = ""
        _prior_note = (f", paper_coherence_prior={_prior_used}" if _prior_used else "")
        reasoning = (
            f"Detailed scores: {detailed_scores}, Major scores: {major_scores}, "
            f"Marks: {major_marks}, Winner: {winning_major} by point system | "
            f"corpus=qp-only, subparts={len(subparts)} (marks_total={total_est_marks}), "
            f"command_boosts={command_boost_count}, formula_hits={formula_hits_map}, "
            f"phrase_bonus_hits={phrase_bonus_hits}, collision_dampened_terms={dampened_terms}"
            f"{_prior_note}"
        )

        _result = ClassificationResult(
            detailed_topics=genuine_detailed,
            major_topic_scores=major_scores,
            winning_major=winning_major,
            topic_marks_breakdown=detailed_marks,
            reasoning=reasoning,
            fallback_tier=fallback_tier,
            diagram_evidence=diagram,
        )
        if fallback_tier == "auto_forced":
            _result.auto_assigned = True
            _result.auto_reason = _auto_reason
            if winning_major and winning_major not in _result.detailed_topics:
                _result.detailed_topics.insert(0, winning_major)
                _result.detailed_topics = _result.detailed_topics[:4]
        return _result

    def _select_winner(self, major_scores: Dict[str, float], major_marks: Dict[str, int], major_spec: Dict[str, float]) -> str:
        """
        Select winning major topic with tie-breaking
        Never duplicate question because of tie - always ONE winner
        Tie-breaking order:
        1. Topic responsible for most marks
        2. Central purpose (already in scores)
        3. Most specialized knowledge
        4. Strongest mark-scheme dependency (already in scores)
        5. Official syllabus hierarchy/order
        """
        if not major_scores:
            # Fallback: first major topic
            return self.config.major_topics[0] if self.config.major_topics else "General"

        # Sort by score descending
        sorted_majors = sorted(major_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Check tie
        max_score = sorted_majors[0][1]
        tied = [m for m, s in sorted_majors if abs(s - max_score) < 0.01]

        if len(tied) == 1:
            return tied[0]

        # Tie-breaking 1: Most marks
        tied_marks = [(m, major_marks.get(m, 0)) for m in tied]
        tied_marks_sorted = sorted(tied_marks, key=lambda x: x[1], reverse=True)
        max_marks = tied_marks_sorted[0][1]
        tied_after_marks = [m for m, mk in tied_marks_sorted if mk == max_marks]
        if len(tied_after_marks) == 1:
            return tied_after_marks[0]

        # Tie-breaking 2: Central purpose already considered, but we try specialized knowledge
        tied_spec = [(m, major_spec.get(m, 0)) for m in tied_after_marks]
        tied_spec_sorted = sorted(tied_spec, key=lambda x: x[1], reverse=True)
        max_spec = tied_spec_sorted[0][1]
        tied_after_spec = [m for m, sp in tied_spec_sorted if sp == max_spec]
        if len(tied_after_spec) == 1:
            return tied_after_spec[0]

        # Tie-breaking 5: Official syllabus hierarchy/order
        # Lower order number wins (earlier in syllabus is often foundational)
        order = self.config.syllabus_order
        if order:
            tied_ordered = sorted(tied_after_spec, key=lambda m: order.get(m, 999))
            return tied_ordered[0]

        # Final fallback: alphabetical or first in major_topics list order
        # Use order in major_topics list as official hierarchy
        if self.config.major_topics:
            for major in self.config.major_topics:
                if major in tied_after_spec:
                    return major

        return tied_after_spec[0]
