#!/usr/bin/env python3
from pathlib import Path
"""
UNIVERSAL CAMBRIDGE EXAM TOPICAL GENERATOR - IGCSE + A-LEVEL
Official Syllabus Integration for 22 Subjects

Supports per prompt:
IGCSE: Chemistry 0620, Physics 0625, Biology 0610, Mathematics 0580,
       Computer Science 0478, Economics 0455, Business Studies 0450,
       Literature in English 0475, History 0470, ICT 0417, Geography 0460

A-Level: Chemistry 9701, Physics 9702, Mathematics 9709, Further Mathematics 9231,
         Computer Science 9618, Economics 9708, Business 9609,
         English Literature 9695, History 9489, Information Technology 9626,
         Geography 9696, Biology 9700 (extra)

Architecture:
Level → Subject → Syllabus Code → Syllabus Year → Official Topic Hierarchy
→ Question Classification → Detailed Topics → JSON → Major Topic → Point System → One Winning Folder → QP+MS WEBP → Validation

- Official Cambridge syllabus documents are source of truth
- Major topics = high-level official structure
- Detailed = sub-topics
- JSON topic[0] is the point-system routing winner; its exact unmodified string names the folder
- Point-based winner, single-folder, no duplication
- Syllabus-year awareness
- Universal cropping engine preserved
"""

import argparse
import shutil
from collections import Counter

from core.paper_identifier import identify_papers_in_dir, infer_level_from_code
from core.subject_detector import separate_papers_by_subject
from core.config_loader import load_all_subject_configs, load_subject_config_by_code_and_level, validate_all_configs, KNOWN_CODE_MAP
from core.cropping_engine import CroppingEngine
from core.ms_cropping_engine import MSCroppingEngine
from core.qp_ms_matcher import QPMSMatcher
from core.classifier import TopicClassifier
from core.json_generator import JSONGenerator
from core.output_manager import OutputManager
from core.validation import FinalValidator
from core.pipeline_state import PipelineState

def print_banner():
    print("""
=================================================================
    UNIVERSAL CAMBRIDGE TOPICAL GENERATOR - OFFICIAL SYLLABUS
    IGCSE: 0620 Chem, 0625 Phys, 0610 Bio, 0580 Math, 0478 CS,
           0455 Econ, 0450 Business, 0475 Lit, 0470 Hist, 0417 ICT, 0460 Geog
    A-LEVEL: 9701 Chem (Ref), 9702 Phys, 9709 Math, 9231 Further Math,
             9618 CS, 9708 Econ, 9609 Business, 9695 Lit, 9489 Hist,
             9626 IT, 9696 Geog, 9700 Bio
=================================================================
    Official syllabus is source of truth - Major → Sub-topic hierarchy preserved
    Level → Code → Year → Config → Point Winner → JSON topic[0] → Exact Same Folder
=================================================================
""")

def process_subject_papers(level: str, subject: str, papers, output_root: Path,
                           cropping_engine: CroppingEngine, ms_cropping_engine: MSCroppingEngine, matcher: QPMSMatcher,
                           json_gen: JSONGenerator, output_mgr: OutputManager,
                           configs: dict, failures: list | None = None):
    print(f"\n[Main] Processing {level} - {subject} with {len(papers)} papers")
    failures = failures if failures is not None else []

    # Audit fix-group 8 C4/C5: stateful resume — persisted after every paper.
    state = PipelineState.load_or_create(
        output_root,
        subject=subject,
        syllabus_code=(papers[0].syllabus_code if papers else ""),
        level=level,
    )

    # Group by year as well for syllabus-year awareness
    from collections import defaultdict
    by_year = defaultdict(list)
    for p in papers:
        by_year[p.year].append(p)

    all_matched = []
    all_classifications = []

    for year, year_papers in by_year.items():
        # Find config for this year - syllabus-year awareness
        config = None
        # Try year-specific config
        sample_code = year_papers[0].syllabus_code if year_papers else None
        if sample_code:
            config = load_subject_config_by_code_and_level(sample_code, level, year)
        # Do not fall back to an unrelated/default config when a year-specific
        # lookup failed. A missing edition is a hard validation failure.
        if not config and not sample_code:
            level_subject_key = f"{level}/{subject}"
            if level_subject_key in configs:
                config = configs[level_subject_key]
            elif subject in configs and configs[subject].level == level:
                config = configs[subject]

        if not config:
            print(f"[Main] ERROR: No config for {level}/{subject} year {year} - STOP")
            failures.append({"status": "FAILED_VALIDATION", "reason": "MISSING_CONFIG", "subject": subject, "year": year})
            continue

        # Validation
        valid, errs = config.validate()
        if not valid:
            print(f"[Main] CONFIG VALIDATION FAILED for {level}/{subject} {year}: {errs} - Do not process")
            failures.append({"status": "FAILED_VALIDATION", "reason": "INVALID_CONFIG", "subject": subject, "year": year, "details": errs})
            continue

        if config.level != level:
            print(f"[Main] LEVEL VALIDATION FAILED: Expected {level} got {config.level} - STOP")
            failures.append({"status": "FAILED_VALIDATION", "reason": "CONFIG_LEVEL_MISMATCH", "subject": subject, "year": year})
            continue

        print(f"[Main] Verified config: Level={config.level}, Subject={config.subject}, Code={config.syllabus_code}, Years={config.syllabus_years}, Majors={len(config.major_topics)}, Detailed={len(config.detailed_topics)}, Using year {year}")

        # For this year group, group QP/MS
        groups = matcher.group_papers(year_papers)
        if matcher.grouping_errors:
            for grouping_error in matcher.grouping_errors:
                print(f"[Main] FAILED_VALIDATION {grouping_error}")
                failures.append({"status": "FAILED_VALIDATION", "reason": "DUPLICATE_INPUT_PAPER", "details": grouping_error})
        print(f"[Main] Found {len(groups)} paper groups for {level}/{subject}/{year}")
        review_required_counts = {"no_markscheme": 0, "classification_failed": 0}  # Overseer RS-5

        for base_key, type_dict in groups.items():
            qp_info = type_dict.get('qp')
            ms_info = type_dict.get('ms')

            # Production rule: never substitute a QP as a missing or failed MS.
            # A bundle without its exact matching MS is recorded as failed and
            # produces no misleading QP/MS pair.
            if not qp_info:
                print(f"[Main] FAILED_VALIDATION {base_key}: missing QP "
                      f"(hint: re-run with --fetch-missing-qp to auto-download)")
                failures.append({"status": "FAILED_VALIDATION", "reason": "MISSING_QP", "paper": base_key})
                continue
            if not ms_info:
                # Overseer RULE 2 (decision: adopt_keep_crop): the locked
                # never-substitute rule stands (no fake _MS is ever written),
                # but the QP crops are PRESERVED under review_required/no_markscheme
                # instead of discarding the paper. Still recorded MISSING_MS and
                # still marked failed so re-running with the MS present reprocesses
                # fully (promotion retires the review_required twins).
                print(f"[Main] MISSING_MS {base_key}: no mark scheme - preserving QP crops to review_required (never discard a crop)")
                failures.append({"status": "MISSING_MS", "paper": base_key, "qp": qp_info.full_code})
                try:
                    from types import SimpleNamespace as _SN
                    _qp_only = cropping_engine.process_paper(qp_info.file_path)
                    for _qc in _qp_only:
                        _m = _SN(question_number=_qc.question_number, number_int=_qc.number_int,
                                 qp=_qc, ms=None, paper_code=base_key,
                                 full_qp_code=qp_info.full_code, full_ms_code=None,
                                 year=qp_info.year, season=qp_info.season,
                                 variant=qp_info.variant, subject=subject)
                        output_mgr.save_review_required_question(_m, "no_markscheme", config)
                        review_required_counts["no_markscheme"] += 1
                except Exception as e:
                    print(f"[Main] QP-only preservation failed for {base_key}: {e}")
                    failures.append({"status": "FAILED_VALIDATION", "reason": "REVIEW_REQUIRED_SAVE_FAILED",
                                     "paper": base_key, "details": str(e)})
                state.mark_failed(base_key, "MISSING_MS (QP crops preserved to review_required)")
                continue

            if qp_info.level != ms_info.level:
                print(f"[Main] LEVEL CONFLICT {base_key}: QP {qp_info.level} vs MS {ms_info.level} - STOP")
                failures.append({"status": "FAILED_VALIDATION", "reason": "QP_MS_LEVEL_CONFLICT", "paper": base_key})
                continue
            if qp_info.level != level:
                print(f"[Main] LEVEL MISMATCH {base_key}: {qp_info.level} vs {level} - STOP")
                failures.append({"status": "FAILED_VALIDATION", "reason": "QP_GROUP_LEVEL_MISMATCH", "paper": base_key})
                continue

            # Year-aware
            if year not in config.syllabus_years:
                better = load_subject_config_by_code_and_level(qp_info.syllabus_code, level, year)
                if better and year in better.syllabus_years:
                    config = better
                    print(f"[Main] Switched to year-specific config for {year}: {config.syllabus_years}")

            print(f"[Main] Processing {qp_info.full_code} + {ms_info.full_code} [{level} Year {year}]")

            # Audit fix-group 8: register + resume-gate + processing mark.
            paper_code = base_key
            state.register_paper(paper_code, qp_path=str(qp_info.file_path),
                                 ms_path=str(ms_info.file_path), er_path=None)
            if state.should_skip(paper_code):
                print(f"[Main] RESUME-SKIP {paper_code}: already complete in a previous run")
                continue
            state.mark_processing(paper_code)

            try:
                # QP uses existing approved QP cropper (gold-standard question_split)
                qp_cropped = cropping_engine.process_paper(qp_info.file_path)
            except Exception as e:
                print(f"[Main] QP cropping failed for {base_key}: {e}")
                import traceback, gc
                traceback.print_exc()
                gc.collect()
                failures.append({"status": "FAILED_VALIDATION", "reason": "QP_CROP_FAILED", "paper": base_key, "details": str(e)})
                state.mark_failed(paper_code, f"QP_CROP_FAILED: {e}")
                continue

            # IGCSE paper-format round (user decision mcq_ms=letters): MCQ
            # papers skip the structured MS cropper entirely — the mark scheme
            # is a bare answer grid; extract letters via the LOCKED gold parser.
            _is_mcq = (ms_info is not None
                       and getattr(qp_info, "paper_format", None) == "MCQ")
            _mcq_answers = None
            if _is_mcq:
                try:
                    import gc
                    gc.collect()
                    _mcq_answers = ms_cropping_engine.extract_mcq_answers(ms_info.file_path)
                    gc.collect()
                except Exception as e:
                    print(f"[Main] FAILED_VALIDATION {base_key}: MCQ answer extraction failed: {e}")
                    import traceback, gc
                    traceback.print_exc()
                    gc.collect()
                    failures.append({"status": "FAILED_VALIDATION", "reason": "MCQ_ANSWERS_FAILED", "paper": base_key, "details": str(e)})
                    state.mark_failed(paper_code, f"MCQ_ANSWERS_FAILED: {e}")
                    continue
                if not _mcq_answers:
                    # FAIL-CLOSED: never mark an MCQ paper complete on 0 letters
                    failures.append({"status": "FAILED_VALIDATION", "reason": "MCQ_GRID_EMPTY", "paper": base_key})
                    state.mark_failed(paper_code, "MCQ_GRID_EMPTY (0 grid answers parsed — fail-closed, never fabricated)")
                    print(f"[Main] ❌ {base_key}: 0 MCQ grid answers parsed — NOT marked complete")
                    continue
                _expected_mcq = getattr(qp_info, "expected_question_count", None)
                if _expected_mcq is not None:
                    # counts=advisory (user decision): measured, never a gate
                    print(f"[Main] advisory: {base_key} expected {_expected_mcq} MCQ grid answers, parsed {len(_mcq_answers)}")
                ms_cropped = []
            else:
                try:
                    # MS uses EXACT GitHub MS cropper - LOCKED, no enhancements
                    # Per critical requirement: COPY AND USE MS CROPPING MECHANISM EXACTLY AS GITHUB
                    # QP and MS croppers must remain separate, do not apply QP improvements to MS
                    import gc
                    gc.collect()
                    ms_cropped = ms_cropping_engine.process_paper(
                        ms_info.file_path,
                        expected_questions=[c.number_int for c in qp_cropped],
                    )
                    gc.collect()
                except Exception as e:
                    print(f"[Main] FAILED_VALIDATION {base_key}: MS cropping failed: {e}")
                    import traceback, gc
                    traceback.print_exc()
                    gc.collect()
                    failures.append({"status": "FAILED_VALIDATION", "reason": "MS_CROP_FAILED", "paper": base_key, "details": str(e)})
                    state.mark_failed(paper_code, f"MS_CROP_FAILED: {e}")
                    continue

            if _is_mcq:
                # Pair each crop with its grid letter: metadata-only MS
                # (ms=None + ms_answer=letter — the letter IS the mark
                # scheme). Questions with no grid letter keep their crops via
                # the existing unmatched-QP -> review_required/no_markscheme
                # machinery below (their number_int is absent from valid).
                from types import SimpleNamespace as _SNM
                matched_questions = [
                    _SNM(question_number=c.question_number, number_int=c.number_int,
                         qp=c, ms=None, ms_answer=_mcq_answers.get(c.number_int),
                         paper_code=base_key,
                         full_qp_code=qp_info.full_code, full_ms_code=ms_info.full_code,
                         year=qp_info.year, season=qp_info.season,
                         variant=qp_info.variant, subject=subject)
                    for c in qp_cropped
                ]
                # RS-13 (mandated letterless variant): a missing grid letter is a
                # MARKSCHEME completeness signal, not a classification one — keep
                # letterless questions in normal CLS-4 topic routing instead of
                # exiling them to review_required. Every loud surface below stays:
                # empty _MS.txt, absent ms_answer, OutputManager flag, the RS-7
                # negative validator gate (final audit error -> paper NOT marked
                # complete), and the batch staging rule.
                _letterless = [m for m in matched_questions if m.ms_answer is None]
                valid_matched = list(matched_questions)
                errors = []
                print(f"[Main] MCQ {base_key}: {len(_mcq_answers)} grid answers -> "
                      f"{len(matched_questions) - len(_letterless)}/{len(qp_cropped)} questions with letters")
                if _letterless:
                    print(f"[Main] MCQ {base_key}: {len(_letterless)} LETTERLESS question(s) "
                          f"kept in topic routing (empty _MS.txt + validator/QC flag): "
                          + ", ".join(m.question_number for m in _letterless))
            else:
                matched_questions = matcher.match_questions(qp_cropped, ms_cropped, qp_info, ms_info, subject)
                valid_matched, errors = matcher.validate_pairs(matched_questions)
            if errors:
                print(f"[Main] FAILED_VALIDATION {base_key}: pair errors: {errors}")
                failures.append({"status": "FAILED_VALIDATION", "reason": "QUESTION_PAIR_MISMATCH", "paper": base_key, "details": errors})
            if not valid_matched:
                failures.append({"status": "FAILED_VALIDATION", "reason": "NO_MATCHED_QUESTIONS", "paper": base_key})
                state.mark_failed(paper_code, "NO_MATCHED_QUESTIONS")
                continue
            print(f"[Main] Matched {len(valid_matched)} Qs for {base_key}")

            classifier = TopicClassifier(config)
            saved_this_paper = 0

            for matched in valid_matched:
                classification = classifier.classify_question(matched)
                # Overseer RULE 1 (decision: desperate_only): only paper-hint /
                # alphabetical-first DESPERATE tiers route to review_required;
                # weak-keyword matches stay classified normally.
                if getattr(classification, "fallback_tier", "scored") in ("paper_hint", "alphabetical_first"):
                    output_mgr.save_review_required_question(matched, "classification_failed", config)
                    review_required_counts["classification_failed"] += 1
                    saved_this_paper += 1
                    print(f"[Main] {matched.full_qp_code} {matched.question_number}: fallback tier {classification.fallback_tier} -> review_required (classification_failed)")
                    continue
                # For QP-only, save_question_pair will save same image as QP and MS - still valid WebP pair for testing
                try:
                    saved = output_mgr.save_question_pair(matched, classification, config)
                except Exception as exc:
                    failures.append({"status": "FAILED_VALIDATION", "reason": "OUTPUT_WRITE_FAILED", "paper": matched.full_qp_code, "question": matched.question_number, "details": str(exc)})
                    print(f"[Main] FAILED_VALIDATION output write {matched.full_qp_code} {matched.question_number}: {exc}")
                    continue
                # JSON is now saved INSIDE question folder per critical fix
                # output_manager.save_question_pair already saves metadata.json inside question folder
                # No separate json/ folder - that was old structure, now fixed to be inside question folder

                all_matched.append(matched)
                all_classifications.append(classification)

                print(f"[Main] {matched.full_qp_code} {matched.question_number}: {classification.detailed_topics[:2]} -> WINNER {classification.winning_major} [{level}] ")
                saved_this_paper += 1

            # Overseer RULE 2 (question-level): a QP question with no matching
            # MS question keeps its crop under review_required/no_markscheme.
            from types import SimpleNamespace as _SN
            _matched_ints = {m.number_int for m in valid_matched}
            for _qc in qp_cropped:
                if _qc.number_int in _matched_ints:
                    continue
                _m = _SN(question_number=_qc.question_number, number_int=_qc.number_int,
                         qp=_qc, ms=None, paper_code=base_key,
                         full_qp_code=qp_info.full_code, full_ms_code=ms_info.full_code,
                         year=qp_info.year, season=qp_info.season,
                         variant=qp_info.variant, subject=subject)
                output_mgr.save_review_required_question(_m, "no_markscheme", config)
                review_required_counts["no_markscheme"] += 1
                saved_this_paper += 1
                print(f"[Main] {qp_info.full_code} {_qc.question_number}: no MS twin -> review_required (no_markscheme)")

            # Audit fix-group 8 C4: per-paper state commit = crash-recovery point
            # Overseer confidence-gate spec (defect 6): completeness gate FIRST —
            # a paper is complete only when every detected question was saved,
            # no write failed, crops exist, and no QC flag stands unresolved.
            _matched_ints_done = {m.number_int for m in valid_matched}
            _qc_flagged = [m.question_number for m in valid_matched
                           if getattr(m.qp, "needs_review", False)]
            _qc_flagged += [f"{_qc.question_number}(unmatched)" for _qc in qp_cropped
                            if getattr(_qc, "needs_review", False)
                            and _qc.number_int not in _matched_ints_done]
            _write_failures = [f for f in failures
                               if f.get("paper") == qp_info.full_code]
            _expected = len(qp_cropped)
            if not qp_cropped:
                state.mark_failed(paper_code, "CROP_EMPTY (0 QP crops — fail-closed, never fabricated)")
                print(f"[Main] ❌ {paper_code}: 0 QP crops — NOT marked complete")
            elif _write_failures:
                state.mark_failed(paper_code, f"OUTPUT_WRITE_FAILED x{len(_write_failures)}")
                print(f"[Main] ❌ {paper_code}: {len(_write_failures)} write failure(s) — NOT marked complete")
            elif saved_this_paper < _expected:
                state.mark_failed(paper_code, f"INCOMPLETE saved {saved_this_paper}/{_expected}")
                print(f"[Main] ❌ {paper_code}: saved {saved_this_paper}/{_expected} — NOT marked complete")
            elif _qc_flagged:
                state.mark_failed(paper_code, f"QC needs_review: {_qc_flagged}")
                print(f"[Main] ⚠️ {paper_code}: QC needs_review {_qc_flagged} — NOT marked complete (crops saved for review)")
            elif getattr(config, "year_review_required", False):
                reason = (
                    f"SYLLABUS_YEAR_UNVERIFIED: {getattr(config, 'requested_year', year)} "
                    f"not in {getattr(config, 'syllabus_years', [])}"
                )
                state.mark_review_required(paper_code, reason)
                print(f"[Main] ⚠️ {paper_code}: {reason} — crops preserved; REVIEW_REQUIRED")
            else:
                state.mark_complete(paper_code, len(valid_matched), saved_this_paper)
            state.save(output_root)

    # Audit fix-group 8 C5: final summary
    state.print_summary()
    print(f"[Main] review_required (no MS):           {review_required_counts['no_markscheme']}")
    print(f"[Main] review_required (classify failed): {review_required_counts['classification_failed']}")
    return all_matched, all_classifications

def main():
    parser = argparse.ArgumentParser(description="ExamVoid Topical Generator - Official Syllabus")
    parser.add_argument("--input", "-i", default="input")
    parser.add_argument("--output", "-o", default="output")
    parser.add_argument("--validate", action="store_true")
    parser.add_argument("--clean", action="store_true")
    parser.add_argument("--demo", action="store_true", help="Generate demo for all required subjects (IGCSE+A-Level)")
    parser.add_argument("--demo-all", action="store_true", help="Generate demo for all configured Cambridge subjects")
    parser.add_argument("--legacy", action="store_true",
                        help="run the legacy in-process pipeline body below "
                             "(kept pinned by tests; NOT the production path)")
    parser.add_argument("--dry-run", action="store_true", help="plan only (delegated)")
    parser.add_argument("--resume", action="store_true", help="skip completed bundles (delegated)")
    parser.add_argument("--retry-failed", action="store_true", help="retry FAILED bundles (delegated)")
    parser.add_argument("--workers", type=int, default=2, help="bounded workers (delegated)")
    parser.add_argument("--full-ram", action="store_true",
                        help="use full in-memory crop path; default is bundled low-RAM streaming")
    parser.add_argument("--fetch-missing-ms", action="store_true",
                        help="OPT-IN mark-scheme fetch via allowed sources (delegated)")
    parser.add_argument("--fetch-missing-qp", action="store_true",
                        help="OPT-IN question-paper fetch via allowed sources "
                             "(official Cambridge -> pastpapers.co) when a QP is "
                             "missing (delegated; also wired into the legacy body)")
    parser.add_argument("--fetch-missing-er", action="store_true",
                        help="OPT-IN examiner-report fetch when a QP/MS lacks "
                             "its ER twin (delegated; also wired into the "
                             "legacy body)")
    parser.add_argument("--full-auto", action="store_true", default=True,
                        help="DEFAULT ON: never route to review_required — crop + "
                             "categorize + sort everything")
    parser.add_argument("--no-full-auto", action="store_true", default=False,
                        help="Restore fail-closed review routing")
    parser.add_argument("--classification-memory", default=None,
                        help="SQLite indexed classification-memory path for the guarded production path")
    parser.add_argument("--write-high-confidence-memory", action="store_true", default=False,
                        help="OPT-IN buffered high-confidence memory writes after a paper completes")
    parser.add_argument("--memory-high-confidence-threshold", type=float, default=0.95,
                        help="minimum confidence for OPT-IN high-confidence memory writes")
    args = parser.parse_args()
    if not 0.0 <= float(args.memory_high_confidence_threshold) <= 1.0:
        parser.error("--memory-high-confidence-threshold must be between 0 and 1")

    if not args.legacy and not args.demo and not args.demo_all:
        # Mega-spec (2026-08-12): the guarded runner IS the production path.
        # This entry point delegates instead of keeping a divergent in-process
        # pipeline; the legacy body below stays available via --legacy (pinned
        # by tests and history), never silently selecting itself.
        print_banner()
        print("[Main] delegating to the guarded production path (run_guarded); "
              "pass --legacy for the pinned in-process body")
        import run_guarded as _rg
        import sys as _sys
        argv = ["run_guarded.py", "--input", args.input, "--output", args.output]
        if args.clean:
            argv.append("--clean")
        # --validate here means "process AND validate": the guarded run stages
        # S0-S8 include final validation on every execution, so the flag is
        # intentionally not forwarded as audit-only (that would audit an empty
        # tree before processing). Audit-only usage: run_guarded --output O --validate.
        if args.validate:
            print("[Main] --validate: validation is built into every guarded run "
                  "(stage S8); for audit-only use run_guarded --output O --validate")
        if args.dry_run:
            argv.append("--dry-run")
        if args.resume:
            argv.append("--resume")
        if args.retry_failed:
            argv.append("--retry-failed")
        if args.fetch_missing_ms:
            argv.append("--fetch-missing-ms")
        if args.fetch_missing_qp:
            argv.append("--fetch-missing-qp")
        if args.fetch_missing_er:
            argv.append("--fetch-missing-er")
        if getattr(args, "full_auto", True):
            argv.append("--full-auto")
        if getattr(args, "no_full_auto", False):
            argv.append("--no-full-auto")
        if args.classification_memory:
            argv += ["--classification-memory", str(args.classification_memory)]
        if args.write_high_confidence_memory:
            argv.append("--write-high-confidence-memory")
        argv += ["--memory-high-confidence-threshold", str(args.memory_high_confidence_threshold)]
        if not args.full_ram:
            argv.append("--low-ram")
        argv += ["--workers", str(args.workers)]
        _sys.argv = argv
        _rg.main()
        return

    print_banner()

    input_dir = Path(args.input)
    output_root = Path(args.output)
    processing_failures = []
    output_root.mkdir(parents=True, exist_ok=True)

    if args.clean:
        print(f"[Main] Cleaning output {output_root}")
        for item in output_root.iterdir():
            if item.is_dir():
                shutil.rmtree(item)
            else:
                if item.name != ".gitkeep":
                    item.unlink()

    input_dir.mkdir(parents=True, exist_ok=True)

    # Validate all configs before processing (Requirement 11)
    print("[Main] Validating all subject configurations against official syllabus structure...")
    overall_valid, errors_by_subject = validate_all_configs()
    if not overall_valid:
        print(f"[Main] CONFIG VALIDATION FAILED for: {errors_by_subject}")
        print("[Main] Do not process papers using invalid configurations per requirement")
        processing_failures.append({"status": "FAILED_VALIDATION", "reason": "INVALID_SUBJECT_CONFIGS", "details": errors_by_subject})
    else:
        print(f"[Main] All configs validated OK - {len([k for k,v in load_all_subject_configs().items() if '_' in k and '/' not in k and len(k)==4 or '_' in k])} subject configs")

    configs = load_all_subject_configs()
    level_count = Counter()
    seen = set()
    for v in configs.values():
        if hasattr(v, 'subject') and hasattr(v, 'level'):
            if v.subject not in seen:
                level_count[v.level] += 1
                seen.add(v.subject)
    print(f"[Main] By level: {dict(level_count)} - Total unique subjects: {len(seen)}")

    if (args.demo or args.demo_all) and not list(input_dir.rglob("*.pdf")):
        print("[Main] Demo mode: generating official-syllabus-based demo PDFs for all required subjects")
        generate_demo_pdfs(input_dir, all_subjects=args.demo_all)

    # RS-9: one-pass manifest (derived cache, core/batch_manifest.py);
    # main.py is a top-level parent entry so it may build/refresh it.
    from core.batch_manifest import identify_via_manifest_or_live

    # QP fetch pre-flight (2026-08-13, OPT-IN via --fetch-missing-qp):
    # download+verify missing question papers INTO the input dir BEFORE
    # identification so the pair is processed on this same run. Unverifiable
    # downloads are quarantined (*.unverified.pdf) and never used; existing
    # files are never overwritten.
    if args.fetch_missing_er:
        print("[Main] --fetch-missing-er: scanning for missing examiner reports before identification...")
        try:
            from core.er_fetcher import fetch_missing_ers_in_dir
            _er_stats = fetch_missing_ers_in_dir(input_dir, output_root=output_root, dry_run=False)
            print(f"[Main] ER fetch summary: {_er_stats}")
        except Exception as e:
            print(f"[Main] ER fetch pre-flight failed (continuing): {e}")

    if args.fetch_missing_qp:
        print("[Main] --fetch-missing-qp: scanning for QP-less MS/ER files before identification...")
        try:
            from core.qp_fetcher import fetch_missing_qps_in_dir
            qp_fetch_stats = fetch_missing_qps_in_dir(input_dir, output_root=output_root, dry_run=False)
            if qp_fetch_stats.get("resolved", 0) > 0:
                _mf = input_dir / ".batch_manifest.json"
                if _mf.exists():
                    _mf.unlink(missing_ok=True)
                    print(f"[Main] removed stale manifest {_mf.name} so identification re-scans with downloaded QPs")
        except Exception as e:
            print(f"[Main] QP fetch pre-flight failed (continuing without fetch): {e}")

    papers, ident_src = identify_via_manifest_or_live(input_dir, build_if_missing=True)
    print(f"[Main] identity source: {ident_src}")
    print(f"\n[Main] Identified {len(papers)} papers")

    if not papers:
        print("[Main] No papers. Place PDFs like 0478_m26_qp_12.pdf, 0620_m26_qp_42.pdf, 9701_m26_qp_22.pdf, 9618_m26_qp_12.pdf in input/")
        if args.validate:
            FinalValidator(output_root=output_root).validate_all()
        return

    separation = separate_papers_by_subject(papers)
    by_level_subject = separation["by_level_subject"]
    conflicts = separation["conflicts"]
    review = separation["review"]

    print("\n[Main] Level + Subject separation:")
    total = 0
    for lvl, subj_dict in by_level_subject.items():
        for subj, plist in subj_dict.items():
            print(f"  {lvl}/{subj}: {len(plist)} papers (codes: {set(p.syllabus_code for p in plist)})")
            total += len(plist)
    print(f"  Total valid: {total}")
    if conflicts:
        print(f"  CONFLICTS: {len(conflicts)} STOPPED")
        for c in conflicts:
            print(f"    - {c.file_path.name} Level {c.level} Code {c.syllabus_code}")
            processing_failures.append({"status": "FAILED_VALIDATION", "reason": "PAPER_IDENTITY_CONFLICT", "paper": c.file_path.name})
    if review:
        print(f"  NEEDS REVIEW: {len(review)}")
        for r in review:
            print(f"    - {r.file_path.name}")
            processing_failures.append({"status": "FAILED_VALIDATION", "reason": "PAPER_IDENTITY_REVIEW", "paper": r.file_path.name})

    if not by_level_subject:
        print("[Main] No valid subjects")
        return

    # QP and MS croppers MUST remain separate per critical requirement
    # QP -> existing approved QP cropper (gold-standard question_split)
    # MS -> exact GitHub MS cropper (LOCKED, no enhancements)
    # QP and MS croppers MUST remain separate per critical requirement
    # QP -> existing approved QP cropper (gold-standard question_split)
    # MS -> exact GitHub MS cropper (LOCKED, no enhancements)
    cropping_engine = CroppingEngine(target_width=2280, quality=95, dpi=75)
    # 2026-08-10 (approved): MS render dpi 75 -> 150. The gold splitter is
    # designed for ~200 dpi; 75 forced a x2.6 upscale that left margin labels
    # ("1(a)") and marks digits soft/faint. 150 is the engine's own clamp
    # ceiling (self.dpi = min(dpi, 150)) -> upscale only x1.3. Splitting
    # identical: m25 + w25 MS both still extract exactly 6/6 questions, zero
    # warnings. Engine internals untouched — constructor argument only.
    ms_cropping_engine = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
    matcher = QPMSMatcher()
    json_gen = JSONGenerator()
    output_mgr = OutputManager(output_root=output_root, target_width=2280, quality=95)

    # NEW: Examiner Report handling - exact copy from final product (3).zip gold-standard
    # This is legitimate new feature, not modifying protected systems
    try:
        from core.examiner_report import ExaminerReportParser, ExaminerReportMatcher
        ER_AVAILABLE = True
        print("[Main] Examiner Report module available (gold-standard from final product)")
    except Exception as e:
        ER_AVAILABLE = False
        print(f"[Main] Examiner Report module not available: {e}")

    total_questions = 0
    subject_batch_results = []
    for level in ["IGCSE", "A-Level"]:
        if level not in by_level_subject:
            continue
        for subject, paper_list in by_level_subject[level].items():
            matched, _ = process_subject_papers(level, subject, paper_list, output_root,
                                                cropping_engine, ms_cropping_engine, matcher, json_gen, output_mgr, configs, processing_failures)
            total_questions += len(matched)
            subject_batch_results.append({"level": level, "subject": subject, "papers": len(paper_list), "questions": len(matched)})

    # Validate each subject context independently before the global audit.
    per_subject_audits = []
    for context in subject_batch_results:
        audit = FinalValidator(output_root=output_root).validate_subject_context(context["level"], context["subject"])
        per_subject_audits.append(audit)
        if not audit["passed"]:
            processing_failures.extend({"status": "FAILED_VALIDATION", "reason": "SUBJECT_CONTEXT_INVALID", "subject": context["subject"], "details": err} for err in audit["errors"])
            print(f"[Main] FAILED_VALIDATION subject context {context['level']}/{context['subject']}: {audit['errors']}")
        else:
            print(f"[Main] ✓ Subject context validated: {context['level']}/{context['subject']} ({audit['questions']} questions)")

    print(f"\n[Main] Total questions processed: {total_questions}")

    # Examiner Report integration: files parsed as *_er are strictly matched
    # against existing question metadata before examiner_report.txt is written.
    er_stats = {"reports_detected": 0, "reports_parsed": 0, "questions_attached": 0, "errors": [], "skipped": []}
    print("\n[Main] Integrating Examiner Reports (if any)...")
    try:
        from core.examiner_report import attach_examiner_reports_to_output
        er_papers = [p for p in papers if p.paper_type == "er"]
        er_stats = attach_examiner_reports_to_output(er_papers, output_root)
        print(
            "[Main] Examiner Reports: "
            f"detected={er_stats['reports_detected']}, "
            f"parsed={er_stats['reports_parsed']}, "
            f"attached={er_stats['questions_attached']}"
        )
        # 2026-08-10 (approved): add per-question boundary ER page crops
        # ({variant}_{Season}_{Year}_Qn_ER.webp) — additive; the locked
        # examiner_report.py, its txt writer and the full-report tiles are
        # untouched. Nothing is written for questions without a verified
        # boundary (locked no-placeholder policy).
        try:
            from core.er_question_crops import attach_question_er_crops
            er_crop_stats = attach_question_er_crops(er_papers, output_root)
            print(
                "[Main] ER question crops: "
                f"written={er_crop_stats['crops_written']}, "
                f"text-verified={er_crop_stats['verified']}, "
                f"errors={len(er_crop_stats['errors'])}"
            )
            for issue in er_crop_stats["errors"]:
                print(f"[ER-CROPS] ERROR: {issue}")
        except Exception as crop_exc:
            print(f"[ER-CROPS] question crops skipped: {crop_exc}")
        for issue in er_stats["errors"]:
            processing_failures.append({"status": "FAILED_VALIDATION", "reason": "ER_PROCESSING_FAILED", "details": issue})
            print(f"[ER] ERROR: {issue}")
        for skipped in er_stats["skipped"][:10]:
            print(f"[ER] SKIPPED: {skipped}")
    except Exception as e:
        print(f"[Main] Examiner Report integration failed: {e}")
        import traceback
        traceback.print_exc()

    print("\n[Main] Cleanup invalid folders (must have QP+MS pair)...")
    removed = output_mgr.cleanup_empty_and_invalid_folders()
    if removed:
        print(f"Removed {len(removed)} invalid")

    print("\n[Main] Validating single-folder distribution...")
    dup_errors, _ = output_mgr.ensure_no_duplicate_distribution()
    if dup_errors:
        print(f"Distribution errors: {dup_errors[:5]}")
        processing_failures.extend({"status": "FAILED_VALIDATION", "reason": "DUPLICATE_DISTRIBUTION", "details": err} for err in dup_errors)
    else:
        print("✓ Single-folder validated")

    qpms_errors = output_mgr.validate_qp_ms_pairs()
    if qpms_errors:
        print(f"QP/MS errors: {qpms_errors[:5]}")
        processing_failures.extend({"status": "FAILED_VALIDATION", "reason": "QP_MS_OUTPUT_INVALID", "details": err} for err in qpms_errors)
    else:
        print("✓ QP/MS pairs validated")

    print("\n[Main] FINAL AUDIT...")
    validator = FinalValidator(output_root=output_root)
    result = validator.validate_all()
    if not result["passed"]:
        print("Attempting auto-fix...")
        result2 = validator.validate_all()
        if result2["passed"]:
            print("✓ Fixed")
        else:
            print(f"Still {result2['total_errors']} errors")

    final_result = result2 if (not result["passed"] and "result2" in locals()) else result
    if not final_result["passed"]:
        processing_failures.extend({"status": "FAILED_VALIDATION", "reason": "FINAL_AUDIT", "details": err} for err in final_result["errors"])

    # Production completion report: the pipeline must not claim success when
    # any paper/question was skipped or failed validation.
    qp_count = len([p for p in papers if p.paper_type == "qp"])
    ms_count = len([p for p in papers if p.paper_type == "ms"])
    report_status = "PASS" if not processing_failures and final_result["passed"] else "FAILED"
    report_lines = [
        "=" * 40,
        "TOPICAL GENERATOR VALIDATION",
        "=" * 40,
        f"Papers identified:       {len(papers)}",
        f"QP files identified:     {qp_count}",
        f"MS files identified:     {ms_count}",
        f"Questions processed:     {total_questions}",
        f"Examiner Reports parsed: {er_stats['reports_parsed']}",
        f"Reports attached:        {er_stats['questions_attached']}",
        f"Subjects processed:       {len(subject_batch_results)}",
        f"Subjects validated:       {sum(1 for audit in per_subject_audits if audit['passed'])}",
        f"Failures:                {len(processing_failures)}",
        "=" * 40,
        f"STATUS: {report_status}",
        "=" * 40,
    ]
    if processing_failures:
        report_lines.extend(" - " + str(failure) for failure in processing_failures)
    (output_root / "processing_validation_report.txt").write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    print("\n" + "\n".join(report_lines))

    print("\n[Main] Output structure:")
    for level_dir in sorted(output_root.iterdir()):
        if not level_dir.is_dir() or level_dir.name.startswith('.'):
            continue
        if level_dir.name in ["IGCSE", "A-Level"]:
            print(f"  {level_dir.name}/ ({len(list(level_dir.rglob('*.webp')))} webp total)")
            for subject_dir in sorted(level_dir.iterdir()):
                if not subject_dir.is_dir():
                    continue
                majors = [d for d in subject_dir.iterdir() if d.is_dir() and d.name != "json"]
                print(f"    {subject_dir.name}/ - {len(majors)} majors - {sum(len(list(m.glob('**/metadata.json'))) for m in [subject_dir])} metadata.json")

    return 0 if report_status == "PASS" else 1


def generate_demo_pdfs(input_dir: Path, all_subjects=False):
    """
    Generate demo PDFs for every configured syllabus profile.  The generated
    papers are deterministic smoke fixtures, not fabricated production
    evidence; real-paper processing remains the validation path.
    """
    try:
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import A4
    except ImportError:
        print("[Demo] reportlab missing")
        return

    # Base demos (always)
    demos = [
        # IGCSE Core + New
        ("0620_m26_qp_42.pdf", "Chemistry", "0620", "IGCSE", [
            ("1", "Particulate nature matter experimental techniques atoms elements compounds stoichiometry chemical reactions", 5),
            ("2", "Acids bases salts periodic table metals reactivity air water organic chemistry", 6),
        ]),
        ("0620_m26_ms_42.pdf", "Chemistry", "0620", "IGCSE", [
            ("1", "Mark scheme particulate experimental atoms", 5),
            ("2", "Mark scheme acids periodic metals organic", 6),
        ]),
        ("0478_m26_qp_12.pdf", "Computer Science", "0478", "IGCSE", [
            ("1", "Data representation number systems text sound images data storage compression binary hexadecimal", 6),
            ("2", "Data transmission error detection encryption hardware software internet cyber security automated systems", 8),
            ("3", "Algorithm design programming databases boolean logic", 10),
        ]),
        ("0478_m26_ms_12.pdf", "Computer Science", "0478", "IGCSE", [
            ("1", "Mark scheme data representation binary", 6),
            ("2", "Mark scheme data transmission hardware software", 8),
            ("3", "Mark scheme algorithm programming databases boolean", 10),
        ]),
        ("0580_m26_qp_42.pdf", "Mathematics", "0580", "IGCSE", [
            ("1", "Number algebra graphs coordinate geometry geometry mensuration trigonometry transformations vectors probability statistics", 6),
            ("2", "Algebra graphs equations inequalities sequences", 8),
        ]),
        ("0580_m26_ms_42.pdf", "Mathematics", "0580", "IGCSE", [
            ("1", "Mark scheme number algebra geometry", 6),
            ("2", "Mark scheme algebra equations", 8),
        ]),
        ("0455_m26_qp_12.pdf", "Economics", "0455", "IGCSE", [
            ("1", "Basic economic problem factors production opportunity cost PPC demand supply price elasticity market failure", 6),
            ("2", "Microeconomic decision makers money banking households workers firms market structure government macroeconomy fiscal monetary", 8),
        ]),
        ("0455_m26_ms_12.pdf", "Economics", "0455", "IGCSE", [
            ("1", "Mark scheme basic economic problem demand supply", 6),
            ("2", "Mark scheme microeconomic government macro", 8),
        ]),
        ("0450_m26_qp_12.pdf", "Business Studies", "0450", "IGCSE", [
            ("1", "Understanding business activity classification enterprise business growth types organisation business objectives stakeholder", 5),
            ("2", "People in business motivating organisation management recruitment marketing operations financial external influences", 7),
        ]),
        ("0450_m26_ms_12.pdf", "Business Studies", "0450", "IGCSE", [
            ("1", "Mark scheme business activity enterprise", 5),
            ("2", "Mark scheme people marketing operations financial", 7),
        ]),
        ("0475_m26_qp_12.pdf", "Literature in English", "0475", "IGCSE", [
            ("1", "Poetry analysis poetic devices themes characterisation structure language form context unseen poetry", 8),
            ("2", "Prose analysis prose drama literary techniques themes characterisation personal response comparison", 8),
        ]),
        ("0475_m26_ms_12.pdf", "Literature in English", "0475", "IGCSE", [
            ("1", "Mark scheme poetry analysis literary techniques", 8),
            ("2", "Mark scheme prose drama themes characterisation", 8),
        ]),
        ("0470_m26_qp_12.pdf", "History", "0470", "IGCSE", [
            ("1", "Core History 19th century Italy unified Germany unified civil war US European expansion First World War", 6),
            ("2", "Core 20th century Versailles fair League Nations success Hitler foreign policy Cold War USA contain communism depth study Germany Russia", 8),
        ]),
        ("0470_m26_ms_12.pdf", "History", "0470", "IGCSE", [
            ("1", "Mark scheme 19th century unification", 6),
            ("2", "Mark scheme Versailles League Hitler Cold War", 8),
        ]),
        ("0417_m26_qp_12.pdf", "ICT", "0417", "IGCSE", [
            ("1", "Types components computer systems input output storage networks effects IT ICT applications systems life cycle safety security", 6),
            ("2", "Document production databases presentations spreadsheets website authoring file management images layout", 8),
        ]),
        ("0417_m26_ms_12.pdf", "ICT", "0417", "IGCSE", [
            ("1", "Mark scheme types components input output", 6),
            ("2", "Mark scheme document production databases", 8),
        ]),
        ("0460_m26_qp_12.pdf", "Geography", "0460", "IGCSE", [
            ("1", "Changing river environments coastal ecosystems tectonic hazards climate change physical geography", 6),
            ("2", "Changing populations towns cities development economies resource provision human geography", 8),
        ]),
        ("0460_m26_ms_12.pdf", "Geography", "0460", "IGCSE", [
            ("1", "Mark scheme river coastal ecosystems tectonic climate", 6),
            ("2", "Mark scheme populations towns development economies resource", 8),
        ]),
        ("0606_m26_qp_12.pdf", "Additional Mathematics", "0606", "IGCSE", [
            ("1", "Functions quadratic functions equations inequalities graphs logarithmic exponential functions", 8),
            ("2", "Coordinate geometry circle circular measure trigonometry vectors calculus differentiation integration", 10),
        ]),
        ("0606_m26_ms_12.pdf", "Additional Mathematics", "0606", "IGCSE", [
            ("1", "Mark scheme functions quadratics equations logarithms", 8),
            ("2", "Mark scheme coordinate geometry circular measure trigonometry vectors calculus", 10),
        ]),
        ("0610_m26_qp_42.pdf", "Biology", "0610", "IGCSE", [
            ("1", "Cell structure biological molecules enzymes membranes transport mitotic cell cycle nucleic acids", 6),
            ("2", "Transport plants mammals gas exchange infectious diseases immunity inheritance ecology", 8),
        ]),
        ("0610_m26_ms_42.pdf", "Biology", "0610", "IGCSE", [
            ("1", "Mark scheme cell structure molecules enzymes membranes", 6),
            ("2", "Mark scheme transport gas exchange diseases immunity inheritance", 8),
        ]),
        ("0625_m26_qp_42.pdf", "Physics", "0625", "IGCSE", [
            ("1", "Motion forces energy thermal physics waves electricity magnetism nuclear physics space physics", 6),
            ("2", "Motion forces energy circuits electromagnetic induction radioactivity space", 8),
        ]),
        ("0625_m26_ms_42.pdf", "Physics", "0625", "IGCSE", [
            ("1", "Mark scheme motion forces energy thermal waves electricity", 6),
            ("2", "Mark scheme circuits magnetism nuclear space physics", 8),
        ]),
        # A-Level
        ("9618_m26_qp_12.pdf", "Computer Science", "9618", "A-Level", [
            ("1", "Information representation communication hardware processor fundamentals system software security ethics databases algorithm", 8),
            ("2", "Data types structures programming software development data representation advanced artificial intelligence further programming", 10),
        ]),
        ("9618_m26_ms_12.pdf", "Computer Science", "9618", "A-Level", [
            ("1", "Mark scheme information representation communication hardware processor", 8),
            ("2", "Mark scheme data types programming databases AI", 10),
        ]),
        ("9700_m26_qp_22.pdf", "Biology", "9700", "A-Level", [
            ("1", "Cell structure biological molecules enzymes membranes transport nucleic acids protein synthesis", 6),
            ("2", "Transport plants mammals gas exchange immunity energy respiration photosynthesis homeostasis inheritance", 8),
        ]),
        ("9700_m26_ms_22.pdf", "Biology", "9700", "A-Level", [
            ("1", "Mark scheme cell structure molecules enzymes membranes transport", 6),
            ("2", "Mark scheme respiration photosynthesis homeostasis inheritance", 8),
        ]),
        ("9701_m26_qp_22.pdf", "Chemistry", "9701", "A-Level", [
            ("1", "Atomic structure chemical bonding periodicity energetics electrochemistry equilibria kinetics", 6),
            ("2", "Organic chemistry hydrocarbons halogen hydroxy carbonyl carboxylic acids analytical techniques", 8),
        ]),
        ("9701_m26_ms_22.pdf", "Chemistry", "9701", "A-Level", [
            ("1", "Mark scheme atomic structure bonding periodicity energetics kinetics", 6),
            ("2", "Mark scheme organic hydrocarbons halogen hydroxy carbonyl carboxylic", 8),
        ]),
        ("9702_m26_qp_22.pdf", "Physics", "9702", "A-Level", [
            ("1", "Physical quantities units kinematics dynamics forces density pressure work energy power deformation waves", 6),
            ("2", "Electricity circuits particle physics gravitational fields temperature gases thermodynamics oscillations quantum nuclear", 8),
        ]),
        ("9702_m26_ms_22.pdf", "Physics", "9702", "A-Level", [
            ("1", "Mark scheme quantities kinematics dynamics forces energy waves", 6),
            ("2", "Mark scheme electricity circuits particles fields thermodynamics quantum nuclear", 8),
        ]),
        ("9709_m26_qp_12.pdf", "Mathematics", "9709", "A-Level", [
            ("1", "Pure Mathematics 1 quadratics functions coordinate geometry circular measure trigonometry series differentiation integration", 6),
            ("2", "Mechanics forces equilibrium kinematics momentum Newtons laws energy work power probability statistics", 8),
        ]),
        ("9709_m26_ms_12.pdf", "Mathematics", "9709", "A-Level", [
            ("1", "Mark scheme pure mathematics quadratics functions", 6),
            ("2", "Mark scheme mechanics forces probability statistics", 8),
        ]),
        ("9231_m26_qp_12.pdf", "Further Mathematics", "9231", "A-Level", [
            ("1", "Further Pure Mathematics roots polynomial rational functions graphs summation matrices polar coordinates vectors proof induction", 8),
            ("2", "Further Mechanics projectile equilibrium rigid body circular motion Hookes law momentum further probability statistics", 10),
        ]),
        ("9231_m26_ms_12.pdf", "Further Mathematics", "9231", "A-Level", [
            ("1", "Mark scheme pure mathematics roots rational", 8),
            ("2", "Mark scheme mechanics projectile probability", 10),
        ]),
        ("9708_m26_qp_12.pdf", "Economics", "9708", "A-Level", [
            ("1", "Basic economic ideas resource allocation price system microeconomy government micro intervention macroeconomy international trade", 6),
            ("2", "Utility indifference curves efficiency market failure private social costs market structures labour market growth sustainability money banking exchange rates globalisation", 8),
        ]),
        ("9708_m26_ms_12.pdf", "Economics", "9708", "A-Level", [
            ("1", "Mark scheme basic economic ideas price system", 6),
            ("2", "Mark scheme utility efficiency market structures macro", 8),
        ]),
        ("9609_m26_qp_12.pdf", "Business", "9609", "A-Level", [
            ("1", "Business environment enterprise business structure size objectives stakeholders people organisations management leadership", 6),
            ("2", "Marketing nature market research marketing mix operations project management finance accounting strategic management external influences", 8),
        ]),
        ("9609_m26_ms_12.pdf", "Business", "9609", "A-Level", [
            ("1", "Mark scheme business environment enterprise", 6),
            ("2", "Mark scheme marketing operations finance strategy", 8),
        ]),
        ("9695_m26_qp_12.pdf", "English Literature", "9695", "A-Level", [
            ("1", "Poetry analysis poetic techniques prose drama Shakespeare unseen texts literary techniques A Level context interpretation", 8),
            ("2", "Themes characterisation structure language form personal response comparison A Level drama", 8),
        ]),
        ("9695_m26_ms_12.pdf", "English Literature", "9695", "A-Level", [
            ("1", "Mark scheme poetry prose drama Shakespeare", 8),
            ("2", "Mark scheme themes literary techniques context", 8),
        ]),
        ("9489_m26_qp_12.pdf", "History", "9489", "A-Level", [
            ("1", "Modern Europe 1750-1921 France Revolution industrial revolution Germany Russian Revolution USA Civil War international history Empire League Nations", 6),
            ("2", "Origins First World War Holocaust Cold War depth study European interwar Mussolini Stalin Hitler Britain USA 1944-92", 8),
        ]),
        ("9489_m26_ms_12.pdf", "History", "9489", "A-Level", [
            ("1", "Mark scheme modern Europe France industrial", 6),
            ("2", "Mark scheme origins WWI Holocaust Cold War depth", 8),
        ]),
        ("9626_m26_qp_12.pdf", "Information Technology", "9626", "A-Level", [
            ("1", "Data processing hardware software monitoring control algorithms eSecurity digital divide expert systems spreadsheets modelling database file concepts", 6),
            ("2", "IT in society new emerging technologies communications project management system life cycle data analysis mail merge graphics animation programming web", 8),
        ]),
        ("9626_m26_ms_12.pdf", "Information Technology", "9626", "A-Level", [
            ("1", "Mark scheme data processing hardware software", 6),
            ("2", "Mark scheme IT society new technologies project management", 8),
        ]),
        ("9696_m26_qp_12.pdf", "Geography", "9696", "A-Level", [
            ("1", "Core Physical hydrology fluvial geomorphology atmosphere weather rocks weathering core human population migration settlement dynamics", 6),
            ("2", "Advanced Physical tropical coastal hazardous hot arid advanced human production environmental management global interdependence economic transition", 8),
        ]),
        ("9696_m26_ms_12.pdf", "Geography", "9696", "A-Level", [
            ("1", "Mark scheme core physical hydrology atmosphere population", 6),
            ("2", "Mark scheme advanced physical tropical coastal human production", 8),
        ]),
    ]

    # If not all_subjects, limit to required per prompt testing list (already all required are in list)
    # The above list includes all required 17+ existing

    input_dir.mkdir(parents=True, exist_ok=True)
    for filename, subject_name, code, level, questions in demos:
        path = input_dir / filename
        c = canvas.Canvas(str(path), pagesize=A4)
        w, h = A4
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, h-50, f"CAMBRIDGE INTERNATIONAL EXAMINATIONS")
        c.drawString(50, h-70, f"{level} {subject_name} {code} - Official Syllabus {code}")
        c.drawString(50, h-90, f"Paper: {filename} - Year 2026")
        c.setFont("Helvetica", 9)
        c.drawString(50, h-105, f"Barcode: |||||| Level:{level} Code:{code} Year:2026")
        c.drawString(50, h-115, f"Official Source: https://www.cambridgeinternational.org/Images/{code}-syllabus.pdf")

        y = h - 140
        for q_num, q_text, marks in questions:
            if y < 150:
                c.showPage()
                y = h - 100
            c.setFont("Helvetica-Bold", 10)
            c.drawString(50, y, f"{q_num} {q_text[:110]}")
            c.setFont("Helvetica", 8)
            c.drawString(50, y-15, f"Additional official syllabus content for {level} {subject_name} {code} - detailed topics classified via point system")
            c.drawString(50, y-30, f"Tests {', '.join(q_text.split()[:7])}")
            c.drawString(w-80, y-15, f"[{marks}]")
            y -= 70

        if code in ["0620", "0478"] and "qp" in filename:
            c.showPage()
            c.setFont("Helvetica-Bold", 10)
            c.drawString(50, h-50, "DATA SHEET / Reference - should be excluded by cropping engine")
            c.drawString(50, h-70, "Periodic Table, Data Representation tables - excluded")

        c.setFont("Helvetica", 7)
        c.drawString(50, 30, f"© UCLES 2026 - {level} {code} - Footer excluded")
        c.save()
        print(f"[Demo] Generated {path} [{level} {code}] Official Syllabus Based")

if __name__ == "__main__":
    raise SystemExit(main() or 0)
