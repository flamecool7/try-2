#!/usr/bin/env python3
"""profile_pipeline.py — Comprehensive pipeline profiler & scalability benchmark.

Measures:
  - Input scanning & file discovery
  - PDF loading & rendering
  - Question extraction & cropping
  - Classification
  - Mark Scheme processing
  - Examiner Report processing
  - Insert processing
  - Duplicate detection & single-folder checks
  - Metadata generation & disk writes
  - Memory usage (RSS) & CPU time
  - Archive growth impact: compares batches 1-100, 400-500, 900-1000
"""
from __future__ import annotations

import gc
import json
import os
import resource
import shutil
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier
from core.config_loader import load_subject_config_by_code_and_level
from core.output_manager import OutputManager
from core.paper_identifier import parse_paper_filename


def get_rss_mb() -> float:
    usage = resource.getrusage(resource.RUSAGE_SELF)
    # On Linux, maxrss is in kilobytes
    return usage.ru_maxrss / 1024.0


def benchmark_archive_scaling(target_counts=(100, 500, 1000), iterations_per_point=20):
    """Measures how OutputManager saving and duplicate checking behave as the archive grows."""
    print("=" * 70)
    print("ARCHIVE SCALING BENCHMARK (Simulating 1 to 1000 archive growth)")
    print("=" * 70)

    cfg = load_subject_config_by_code_and_level("9706", "A-Level")
    assert cfg is not None
    classifier = TopicClassifier(cfg)

    results = []

    with tempfile.TemporaryDirectory() as tmpdir:
        out_root = Path(tmpdir) / "output"
        out_root.mkdir(parents=True, exist_ok=True)
        om = OutputManager(output_root=out_root, target_width=2280, quality=95)

        total_questions = 0

        for target in target_counts:
            # Populate archive up to target count
            to_add = target - total_questions
            if to_add > 0:
                print(f"--> Populating archive from {total_questions} to {target} questions...")
                t_pop_start = time.perf_counter()
                for i in range(total_questions, target):
                    # Simulate existing question folder in output tree
                    # e.g. A-Level/Accounting_9706/paper-3/Financial_statements/32_Summer_2023_Q{i}
                    topic = "Financial_statements" if i % 2 == 0 else "Cost_and_management_accounting"
                    qf = out_root / "A-Level" / "Accounting_9706" / "paper-3" / topic / f"32_Summer_{2000 + (i % 25)}_Q{i}"
                    qf.mkdir(parents=True, exist_ok=True)
                    (qf / f"32_Summer_{2000 + (i % 25)}_Q{i}.webp").write_bytes(b"RIFF\x00\x00\x00\x00WEBPVP8 ")
                    (qf / f"32_Summer_{2000 + (i % 25)}_Q{i}_MS.webp").write_bytes(b"RIFF\x00\x00\x00\x00WEBPVP8 ")
                    meta = {
                        "id": f"q-uuid-{i}",
                        "level": "A-Level",
                        "subject": "Accounting_9706",
                        "board": "CIE",
                        "topic": [topic],
                        "paper": f"9706_s{20 + (i % 5)}_qp_32",
                        "question_number": f"Q{i}",
                        "variant": "32",
                        "season": "Summer",
                        "year": f"20{20 + (i % 5)}"
                    }
                    (qf / "metadata.json").write_text(json.dumps(meta), encoding="utf-8")
                total_questions = target
                print(f"    Populated in {time.perf_counter() - t_pop_start:.2f}s")

            # Now benchmark saving a NEW question against this archive
            print(f"--> Benchmarking new question processing with archive size = {target} questions...")

            rglob_times = []
            stale_scan_times = []
            audit_times = []

            for k in range(iterations_per_point):
                test_qname = f"32_Summer_2024_TestQ{k}"

                # 1. OutputManager single-folder duplicate check (the rglob call)
                t0 = time.perf_counter()
                dupes = [
                    d for d in (out_root / "A-Level" / "Accounting_9706").rglob(test_qname)
                    if d.is_dir()
                ]
                t1 = time.perf_counter()
                rglob_times.append((t1 - t0) * 1000.0)  # ms

                # 2. _remove_stale_bundle_question_folders style scan (rglob metadata.json + json.loads)
                t0 = time.perf_counter()
                stale_count = 0
                for metadata in list(out_root.rglob("metadata.json")):
                    try:
                        data = json.loads(metadata.read_text(encoding="utf-8"))
                        if data.get("paper") == "9706_s24_qp_32":
                            stale_count += 1
                    except Exception:
                        pass
                t1 = time.perf_counter()
                stale_scan_times.append((t1 - t0) * 1000.0)  # ms

            # 3. ensure_no_duplicate_distribution audit
            t0 = time.perf_counter()
            dup_errors, _ = om.ensure_no_duplicate_distribution()
            t1 = time.perf_counter()
            audit_time_ms = (t1 - t0) * 1000.0

            avg_rglob = sum(rglob_times) / len(rglob_times)
            avg_stale = sum(stale_scan_times) / len(stale_scan_times)
            rss = get_rss_mb()

            results.append({
                "archive_size": target,
                "avg_rglob_ms": avg_rglob,
                "avg_stale_scan_ms": avg_stale,
                "audit_ms": audit_time_ms,
                "rss_mb": rss,
            })

            print(f"    Results for archive size {target}:")
            print(f"      - Question folder rglob check: {avg_rglob:.2f} ms/question")
            print(f"      - Stale folder metadata scan : {avg_stale:.2f} ms/bundle")
            print(f"      - Global duplicate audit     : {audit_time_ms:.2f} ms/run")
            print(f"      - Process RSS memory         : {rss:.1f} MB")

    return results


def benchmark_pipeline_components():
    """Measures CPU and execution time of individual pipeline stages on actual Cambridge paper."""
    print("\n" + "=" * 70)
    print("PIPELINE COMPONENT BREAKDOWN (Actual Cambridge 9706 Paper)")
    print("=" * 70)

    from PIL import Image
    from core.cropping_engine import CroppingEngine
    from core.ms_cropping_engine import MSCroppingEngine
    from core.insert_engine import InsertEngine
    from core.classifier import TopicClassifier
    from core.paper_identifier import parse_paper_filename, identify_papers_in_dir
    import fitz

    qp_path = PROJ / "fixtures" / "actual_accounting_9706" / "9706_s23_qp_32.pdf"
    ms_path = PROJ / "fixtures" / "actual_accounting_9706" / "9706_s23_ms_32.pdf"
    in_path = PROJ / "fixtures" / "actual_accounting_9706" / "9706_s23_in_32.pdf"
    er_path = PROJ / "fixtures" / "actual_accounting_9706" / "9706_s23_er.pdf"

    times = {}

    # 1. File discovery & identification
    t0 = time.perf_counter()
    papers = identify_papers_in_dir(qp_path.parent)
    times["file_discovery_ms"] = (time.perf_counter() - t0) * 1000.0

    # 2. PDF loading
    t0 = time.perf_counter()
    doc_qp = fitz.open(qp_path)
    page_count = len(doc_qp)
    doc_qp.close()
    times["pdf_loading_ms"] = (time.perf_counter() - t0) * 1000.0

    # 3. Question extraction & QP cropping
    t0 = time.perf_counter()
    ce = CroppingEngine(target_width=2280, quality=95, dpi=150)
    qp_crops = ce.process_paper(qp_path)
    times["qp_cropping_ms"] = (time.perf_counter() - t0) * 1000.0

    # 4. Mark Scheme processing & cropping
    t0 = time.perf_counter()
    ms_ce = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
    ms_crops = ms_ce.process_paper(ms_path)
    times["ms_cropping_ms"] = (time.perf_counter() - t0) * 1000.0

    # 5. Insert processing & bottom whitespace trimming
    t0 = time.perf_counter()
    ie = InsertEngine(target_width=2280, quality=95)
    in_res = ie.process_insert(in_path)
    times["insert_processing_ms"] = (time.perf_counter() - t0) * 1000.0

    # 6. Classification
    cfg = load_subject_config_by_code_and_level("9706", "A-Level")
    classifier = TopicClassifier(cfg)
    t0 = time.perf_counter()
    for q in qp_crops:
        matched = SimpleNamespace(
            question_number=f"Q{q.question_number}",
            number_int=q.number_int,
            qp=q, ms=None, ms_answer=None,
            paper_code="9706_s23_32",
            full_qp_code="9706_s23_qp_32",
            full_ms_code="9706_s23_ms_32",
            year="2023", season="Summer", variant="32",
            subject="Accounting_9706",
            paper_format="STRUCTURED",
        )
        classifier.classify_question(matched)
    times["classification_ms"] = (time.perf_counter() - t0) * 1000.0

    print("Component Execution Times:")
    for k, v in times.items():
        print(f"  - {k:25}: {v:.2f} ms")

    return times


if __name__ == "__main__":
    comp_times = benchmark_pipeline_components()
    scale_results = benchmark_archive_scaling(target_counts=(100, 500, 1000), iterations_per_point=10)

    report_path = PROJ / "profiling_baseline_report.json"
    report_path.write_text(json.dumps({
        "component_times": comp_times,
        "archive_scaling": scale_results
    }, indent=2), encoding="utf-8")
    print(f"\n[profile] Baseline profiling written to {report_path}")
