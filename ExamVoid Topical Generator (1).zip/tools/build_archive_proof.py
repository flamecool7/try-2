#!/usr/bin/env python3
"""Build a self-contained visual proof from *existing* ExamVoid output.

This is intentionally a read-only reporting tool.  It never invokes a cropper,
never manufactures a source document or crop, and only embeds WebP files and
metadata.json files that are already present in the selected archive scope.

The default visual cap keeps a full-archive report practical for large archives:
the report inventories every matching question but embeds the first 50 visual
cards.  Pass ``--max-questions 0`` to embed every matching question when the
scope is small enough for a reviewable HTML file.
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import re
import sqlite3
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

CANONICAL_METADATA_KEYS = {
    "id", "level", "subject", "board", "topic", "paper",
    "question_number", "variant", "season", "year",
}


@dataclass(frozen=True)
class QuestionProofItem:
    """A question folder selected from the archive's real output state."""

    folder: Path
    rel_folder: str
    bundle_key: str
    subject: str
    variant: str
    season: str
    year: str
    metadata: dict[str, Any]


def _esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def _normalise_year(value: str | None) -> str | None:
    if value is None or not str(value).strip():
        return None
    text = str(value).strip()
    if re.fullmatch(r"\d{2}", text):
        return "20" + text
    return text


def _normalise_session(value: str | None) -> tuple[str | None, str | None]:
    """Match the friendly batch-runner session syntax without importing state."""
    text = str(value or "").strip().casefold()
    if not text:
        return None, None
    text = re.sub(r"[ _/]", "-", text)
    aliases = {
        "summer": "summer", "may-june": "summer", "may-june-summer": "summer", "s": "summer",
        "spring": "spring", "february-march": "spring", "m": "spring",
        "winter": "winter", "october-november": "winter", "w": "winter",
        "specimen": "specimen", "spec": "specimen", "sp": "specimen",
    }
    if text in aliases:
        return aliases[text], None
    match = re.fullmatch(r"(sp|spec|specimen|mj|on|fm|f|m|s|j|w|n)-?(20\d{2}|\d{2})", text)
    if match:
        season_code, year = match.groups()
        season = {
            "s": "summer", "j": "summer", "mj": "summer",
            "m": "spring", "f": "spring", "fm": "spring",
            "w": "winter", "n": "winter", "on": "winter",
            "sp": "specimen", "spec": "specimen",
        }.get(season_code, season_code)
        return season, _normalise_year(year)
    if re.fullmatch(r"20\d{2}", text):
        return None, text
    return text, None


def _bundle_key_from_metadata(metadata: dict[str, Any]) -> str:
    """Derive the DB/manifest logical key from canonical metadata where needed."""
    paper = str(metadata.get("paper", ""))
    # Canonical paper is normally e.g. 9706_s24_qp_31.
    return paper.replace("_qp_", "_") if "_qp_" in paper else paper


def _load_manifest_latest_bundle_keys(output_root: Path) -> set[str]:
    """Return terminal bundles from the latest recorded processing window.

    A manifest has no user-maintained baseline marker.  "New items" therefore
    means the most recently completed/reviewed/failed timestamp window, which
    is the useful visual-review meaning after a batch has finished.  If no
    usable terminal record exists, the caller deliberately returns no items
    rather than guessing.
    """
    manifest_path = output_root / ".processing_manifest.json"
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return set()
    records = data.get("bundles", {})
    terminal = [
        (str(key), str(value.get("last_processed") or ""))
        for key, value in records.items()
        if str(value.get("status", "")).casefold() in {"complete", "review_required", "failed"}
        and value.get("last_processed")
    ]
    if not terminal:
        return set()
    latest = max(timestamp for _key, timestamp in terminal)
    return {key for key, timestamp in terminal if timestamp == latest}


def _metadata_from_folder(folder: Path) -> dict[str, Any] | None:
    try:
        data = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None
    return data if isinstance(data, dict) else None


def _iter_database_items(output_root: Path) -> Iterable[QuestionProofItem]:
    """Use indexed SQLite state where available, with no archive-wide DB scan."""
    db_path = output_root / "pipeline.sqlite"
    if not db_path.is_file():
        return []
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """
            SELECT q.folder_path, b.bundle_key, b.subject, b.component,
                   b.season, b.year
            FROM questions q
            JOIN bundles b ON b.id=q.bundle_id
            ORDER BY b.subject, b.year, b.season, b.component, q.question_num, q.id
            """
        ).fetchall()
        conn.close()
    except sqlite3.Error:
        return []

    items: list[QuestionProofItem] = []
    for row in rows:
        raw = Path(str(row["folder_path"]))
        folder = raw if raw.is_absolute() else output_root / raw
        metadata = _metadata_from_folder(folder)
        if metadata is None:
            # A proof must showcase only genuine canonical question folders.
            continue
        try:
            rel = str(folder.resolve().relative_to(output_root.resolve()))
        except ValueError:
            continue
        items.append(QuestionProofItem(
            folder=folder,
            rel_folder=rel,
            bundle_key=str(row["bundle_key"]),
            subject=str(metadata.get("subject") or row["subject"] or ""),
            variant=str(metadata.get("variant") or row["component"] or ""),
            season=str(metadata.get("season") or row["season"] or ""),
            year=str(metadata.get("year") or row["year"] or ""),
            metadata=metadata,
        ))
    return items


def _iter_fallback_items(output_root: Path) -> Iterable[QuestionProofItem]:
    """Fallback for an imported archive that predates its SQLite index."""
    if not output_root.is_dir():
        return []
    items: list[QuestionProofItem] = []
    for metadata_path in output_root.rglob("metadata.json"):
        folder = metadata_path.parent
        # Insert manifests are intentionally not question metadata.
        if "_insert" in folder.parts:
            continue
        metadata = _metadata_from_folder(folder)
        if metadata is None:
            continue
        try:
            rel = str(folder.resolve().relative_to(output_root.resolve()))
        except ValueError:
            continue
        items.append(QuestionProofItem(
            folder=folder,
            rel_folder=rel,
            bundle_key=_bundle_key_from_metadata(metadata),
            subject=str(metadata.get("subject", "")),
            variant=str(metadata.get("variant", "")),
            season=str(metadata.get("season", "")),
            year=str(metadata.get("year", "")),
            metadata=metadata,
        ))
    return items


def _matches_scope(
    item: QuestionProofItem,
    *,
    subject: str | None,
    variant: str | None,
    year: str | None,
    session: str | None,
    latest_bundle_keys: set[str] | None,
) -> bool:
    if subject and str(subject).casefold() not in item.subject.casefold():
        return False
    if variant and item.variant != str(variant):
        return False
    wanted_year = _normalise_year(year)
    if wanted_year and item.year != wanted_year:
        return False
    wanted_season, session_year = _normalise_session(session)
    if wanted_season and item.season.casefold() != wanted_season:
        return False
    if session_year and item.year != session_year:
        return False
    if latest_bundle_keys is not None and item.bundle_key not in latest_bundle_keys:
        return False
    return True


def select_questions(
    output_root: str | Path,
    *,
    subject: str | None = None,
    variant: str | None = None,
    year: str | None = None,
    session: str | None = None,
    new_only: bool = False,
) -> list[QuestionProofItem]:
    """Select real question folders for a proof without modifying the archive."""
    root = Path(output_root).resolve()
    indexed = list(_iter_database_items(root))
    items = indexed or list(_iter_fallback_items(root))
    latest = _load_manifest_latest_bundle_keys(root) if new_only else None
    return [item for item in items if _matches_scope(
        item, subject=subject, variant=variant, year=year, session=session,
        latest_bundle_keys=latest,
    )]


def _webp_data_uri(path: Path) -> str:
    return "data:image/webp;base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def _asset_groups(folder: Path, question_number: str) -> list[tuple[str, list[Path]]]:
    """Group true on-disk assets without mistaking ER/Insert files for QP."""
    all_webp = sorted(folder.glob("*.webp"))
    qp = [p for p in all_webp if "_MS" not in p.name and "_IN" not in p.name and "_ER" not in p.name]
    ms = [p for p in all_webp if "_MS" in p.name]
    insert = [p for p in all_webp if "_IN" in p.name]
    er = [p for p in all_webp if "_ER" in p.name]
    return [("Question Paper", qp), ("Mark Scheme", ms), ("Insert", insert), ("Examiner Report", er)]


def _scope_label(
    subject: str | None, variant: str | None, year: str | None,
    session: str | None, new_only: bool,
) -> str:
    labels = []
    if subject:
        labels.append(f"subject={subject}")
    if variant:
        labels.append(f"variant={variant}")
    if year:
        labels.append(f"year={year}")
    if session:
        labels.append(f"session={session}")
    if new_only:
        labels.append("latest processed manifest window")
    return ", ".join(labels) if labels else "full archive"


def build_archive_proof(
    output_root: str | Path,
    proof_path: str | Path | None = None,
    *,
    subject: str | None = None,
    variant: str | None = None,
    year: str | None = None,
    session: str | None = None,
    new_only: bool = False,
    max_questions: int = 50,
) -> Path:
    """Write a portable HTML visual proof and return its absolute path.

    ``max_questions`` limits embedded visual cards, not selection/inventory.
    Use zero to embed every selected question.  A negative value is invalid.
    """
    if max_questions < 0:
        raise ValueError("max_questions must be zero or a positive integer")
    root = Path(output_root).resolve()
    selected = select_questions(
        root, subject=subject, variant=variant, year=year,
        session=session, new_only=new_only,
    )
    scope = _scope_label(subject, variant, year, session, new_only)
    visible = selected if max_questions == 0 else selected[:max_questions]
    if proof_path is None:
        safe_scope = re.sub(r"[^a-z0-9]+", "_", scope.casefold()).strip("_")[:80] or "full_archive"
        proof_path = root / f"proof_{safe_scope}.html"
    destination = Path(proof_path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)

    invalid_metadata = [
        item for item in selected
        if set(item.metadata) != CANONICAL_METADATA_KEYS
        or not isinstance(item.metadata.get("topic"), list)
        or len(item.metadata.get("topic", [])) > 4
    ]
    html_parts = [
        "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'>",
        "<meta name='viewport' content='width=device-width,initial-scale=1'>",
        "<title>ExamVoid Archive Visual Proof</title>",
        "<style>"
        "body{margin:0;background:#f5f7fb;color:#172033;font:14px/1.5 -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif}"
        "header{background:#10233f;color:#fff;padding:28px max(20px,calc((100vw - 1180px)/2))}"
        "h1{margin:0 0 5px;font-size:25px}.sub{color:#c9d7e8}.wrap{max-width:1180px;margin:auto;padding:22px}"
        ".card{background:#fff;border:1px solid #dce4ee;border-radius:10px;padding:18px;margin:15px 0;box-shadow:0 1px 2px #10233f0d}"
        ".ok{display:inline-block;border-radius:999px;background:#087443;color:#fff;font-size:12px;font-weight:700;padding:3px 9px}"
        ".warn{display:inline-block;border-radius:999px;background:#a95d00;color:#fff;font-size:12px;font-weight:700;padding:3px 9px}"
        "table{width:100%;border-collapse:collapse;margin-top:8px}th,td{text-align:left;padding:8px;border-bottom:1px solid #e5eaf1;vertical-align:top}th{color:#475569;background:#f6f8fb}"
        "code,pre{font:12px/1.45 ui-monospace,SFMono-Regular,Consolas,monospace;background:#eef3f8;border-radius:5px}code{padding:2px 5px}pre{padding:12px;overflow:auto;white-space:pre-wrap}"
        ".assets{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:14px;margin-top:14px}.asset{border:1px solid #dde6ef;border-radius:8px;padding:10px}"
        ".asset img{max-width:100%;height:auto;display:block;border:1px solid #cad5e2;margin-top:8px}.small{font-size:12px;color:#526174}"
        "details{margin-top:12px}summary{cursor:pointer;font-weight:650}.none{color:#667085;font-style:italic}"
        "</style></head><body>",
        "<header><h1>ExamVoid — Archive Visual Proof</h1>",
        "<div class='sub'>Read-only report built from existing WebP artifacts and canonical metadata.json files. No cropper or source-document generator ran.</div></header>",
        "<main class='wrap'>",
        "<section class='card'><h2 style='margin-top:0'>Scope and evidence</h2>",
        f"<p><strong>Output root:</strong> <code>{_esc(root)}</code><br><strong>Scope:</strong> <code>{_esc(scope)}</code><br>"
        f"<strong>Matching question folders:</strong> {len(selected):,}<br><strong>Embedded visual cards:</strong> {len(visible):,}</p>",
        ("<p><span class='ok'>CANONICAL METADATA CHECK PASS</span> Every selected metadata file has exactly the ten canonical keys and at most four topics.</p>"
         if not invalid_metadata else
         f"<p><span class='warn'>METADATA REVIEW NEEDED</span> {len(invalid_metadata):,} selected folder(s) have a schema/topic-cap issue; they remain shown without concealment.</p>"),
        "</section>",
        "<section class='card'><h2 style='margin-top:0'>Complete selected inventory</h2>",
        "<table><thead><tr><th>#</th><th>Question</th><th>Subject / session</th><th>Variant</th><th>Topic folder</th></tr></thead><tbody>",
    ]
    for index, item in enumerate(selected, start=1):
        qnum = item.metadata.get("question_number", "?")
        topic = item.metadata.get("topic", [""])
        html_parts.append(
            "<tr>"
            f"<td>{index}</td><td>{_esc(qnum)}</td><td>{_esc(item.subject)} / {_esc(item.season)} {_esc(item.year)}</td>"
            f"<td>{_esc(item.variant)}</td><td><code>{_esc(item.rel_folder)}</code><br><span class='small'>{_esc(', '.join(map(str, topic)))}</span></td>"
            "</tr>"
        )
    if not selected:
        html_parts.append("<tr><td colspan='5' class='none'>No canonical question folders matched this scope. The archive was not modified.</td></tr>")
    html_parts.extend(["</tbody></table></section>"])

    if len(visible) < len(selected):
        html_parts.append(
            f"<section class='card'><span class='warn'>VISUAL CAP</span> The report inventories all {len(selected):,} matching folders but embeds the first {len(visible):,} to keep a large archive proof usable. Re-run with <code>--max-questions 0</code> for every image.</section>"
        )

    html_parts.append("<h2>Visual artifact and metadata review</h2>")
    for index, item in enumerate(visible, start=1):
        metadata = item.metadata
        qnum = str(metadata.get("question_number", "?"))
        html_parts.append(
            "<section class='card'>"
            f"<h3 style='margin-top:0'>#{index} — {_esc(qnum)} <span class='small'>({ _esc(item.subject) }, {_esc(item.season) } {_esc(item.year) }, variant {_esc(item.variant) })</span></h3>"
            f"<p><strong>Physical topic folder:</strong> <code>{_esc(item.rel_folder)}</code></p>"
            "<div class='assets'>"
        )
        has_assets = False
        for label, paths in _asset_groups(item.folder, qnum):
            # A paper can have many ER/Insert parts. One representative,
            # genuinely generated WebP per artifact type keeps a full-archive
            # proof reviewable instead of accidentally embedding gigabytes.
            # The folder inventory and metadata remain complete above.
            for asset in paths[:1]:
                try:
                    uri = _webp_data_uri(asset)
                except OSError:
                    continue
                has_assets = True
                extra = (f"<div class='small'>{len(paths) - 1} additional {label.lower()} WebP artifact(s) remain in this folder.</div>"
                         if len(paths) > 1 else "")
                html_parts.append(
                    "<div class='asset'>"
                    f"<strong>{_esc(label)}</strong><br><code>{_esc(asset.name)}</code>"
                    f"<img src='{uri}' alt='{_esc(label + ' for ' + qnum)}'>{extra}"
                    "</div>"
                )
        if not has_assets:
            html_parts.append("<p class='none'>No WebP artifact exists in this registered question folder.</p>")
        html_parts.extend([
            "</div><details><summary>Canonical metadata.json</summary>",
            f"<pre>{_esc(json.dumps(metadata, ensure_ascii=False, indent=2, sort_keys=True))}</pre>",
            "</details></section>",
        ])

    html_parts.extend([
        "<section class='card'><h2 style='margin-top:0'>Interpretation</h2>",
        "<p>This proof is an inspection artifact, not a processing result. It does not claim that a source PDF, crop, examiner report, or outcome exists unless that item was already found in the selected archive folder.</p>",
        "</section></main></body></html>",
    ])
    destination.write_text("\n".join(html_parts), encoding="utf-8")
    return destination


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a read-only visual proof from existing ExamVoid output")
    parser.add_argument("--output-root", default="output", help="Existing archive output directory")
    parser.add_argument("--proof", default=None, help="Destination HTML path (default: inside output root)")
    parser.add_argument("--subject", default=None, help="Subject substring scope")
    parser.add_argument("--variant", default=None, help="Exact paper variant scope")
    parser.add_argument("--year", default=None, help="Exam year scope, e.g. 2024")
    parser.add_argument("--session", default=None, help="Session scope, e.g. s24 or summer")
    parser.add_argument("--new-only", action="store_true", help="Use the latest terminal manifest processing window")
    parser.add_argument("--max-questions", type=int, default=50,
                        help="Maximum embedded visual cards; 0 means all (default: 50)")
    args = parser.parse_args()
    path = build_archive_proof(
        args.output_root, args.proof, subject=args.subject, variant=args.variant,
        year=args.year, session=args.session, new_only=args.new_only,
        max_questions=args.max_questions,
    )
    print(f"[proof] Wrote read-only visual proof: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
