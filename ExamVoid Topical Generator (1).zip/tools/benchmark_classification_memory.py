#!/usr/bin/env python3
"""Measure indexed classification-memory retrieval without touching outputs.

The corpus is synthetic by design: it measures SQLite/index behavior, not
classification accuracy.  It creates a standalone database and reports build
and bounded-query timings.  No cropper, archive question folder, or
``metadata.json`` is read or written.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.classification_memory import ClassificationMemory


def run_benchmark(db_path: Path, *, records: int = 10_000, queries: int = 50) -> dict:
    if db_path.exists():
        db_path.unlink()
    started = time.perf_counter()
    with ClassificationMemory(db_path, create=True) as memory:
        for i in range(records):
            # Each record has a unique term plus ordinary terms. A target term
            # occurs only in a small sparse subset, exercising the inverted
            # subject+token index rather than a corpus scan.
            target = "target_jit_inventory" if i % 997 == 0 else f"concept_{i}"
            memory.record_verified(
                subject="Benchmark_9609",
                topics=["Inventory_management"],
                question_text=(
                    f"Analyse {target} inventory control and contribution calculation "
                    f"for business scenario {i}."
                ),
                evidence=["Synthetic performance fixture; not a classification label."],
                record_key=f"benchmark:{i}",
            )
        build_seconds = time.perf_counter() - started
        query_started = time.perf_counter()
        retrieved_counts = []
        for _ in range(queries):
            context = memory.retrieve(
                subject="Benchmark_9609",
                question_text="Evaluate target JIT inventory control and contribution.",
                allowed_detailed_topics=["Inventory_management"],
                allowed_major_topics=["Operations"],
                limit=8,
            )
            retrieved_counts.append(len(context.matches))
        query_seconds = time.perf_counter() - query_started
        indexes = [row[1] for row in memory._conn.execute("PRAGMA index_list(memory_tokens)")]  # noqa: SLF001
        stats = memory.stats()
    return {
        "schema": "classification-memory-benchmark/1",
        "records": records,
        "queries": queries,
        "build_seconds": round(build_seconds, 4),
        "queries_seconds": round(query_seconds, 4),
        "mean_query_ms": round((query_seconds / max(1, queries)) * 1000, 3),
        "maximum_retrieved_matches": max(retrieved_counts, default=0),
        "retrieval_limit": 8,
        "indexed_subject_token_lookup": "idx_memory_tokens_subject_token" in indexes,
        "stats": stats,
        "database_bytes": db_path.stat().st_size if db_path.exists() else 0,
        "note": (
            "Synthetic performance evidence only. It demonstrates bounded, subject-scoped "
            "inverted-index retrieval; it does not measure topic-classification accuracy."
        ),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="validation_evidence/classification_memory_benchmark.sqlite3")
    parser.add_argument("--records", type=int, default=10_000)
    parser.add_argument("--queries", type=int, default=50)
    parser.add_argument("--report", default=None)
    args = parser.parse_args(argv)
    if args.records < 1 or args.queries < 1:
        parser.error("--records and --queries must be positive")
    result = run_benchmark(Path(args.db), records=args.records, queries=args.queries)
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.report).write_text(text + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
