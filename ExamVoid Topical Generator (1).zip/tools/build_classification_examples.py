#!/usr/bin/env python3
"""Import reviewed classification labels into indexed SQLite memory.

This supersedes the old eager ``classification_examples.jsonl`` retrieval path.
The classifier no longer reads that JSONL file at runtime.  Instead, this tool
joins filled human labels to the external classification audit and writes
subject-scoped, indexed ``verified`` records to ``classification_memory.sqlite3``.
It never changes question folders, crop code, or ``metadata.json``.

Examples
--------

Import human-verified labels:
    python tools/build_classification_examples.py \
      --output-root output \
      --labels topic_accuracy_labels_filled.csv \
      --memory-db memory/classification_memory.sqlite3

One-time migration of an old JSONL file (the legacy file remains untouched):
    python tools/build_classification_examples.py \
      --migrate-legacy subjects/A-Level/Business_9609/classification_examples.jsonl \
      --legacy-subject Business_9609 --legacy-level A-Level \
      --memory-db memory/classification_memory.sqlite3
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.classification_memory import ClassificationMemory, default_memory_path
from core.config_loader import SubjectConfig
from core.classifier import CLASSIFIER_VERSION

SENTINELS = {"", "review_required", "review_required_no_ms", "review_required_no_qp"}


def _key(value: str) -> str:
    return str(value or "").strip()


def _paper_aliases(value: str) -> set[str]:
    paper = _key(value)
    if not paper:
        return set()
    aliases = {paper}
    for marker in ("_qp_", "_ms_"):
        if marker in paper:
            aliases.add(paper.replace(marker, "_"))
    return aliases


def load_audit(output_root: Path) -> dict[tuple[str, str], dict]:
    """Index only audit lines by paper/question; never scan question archives."""
    index: dict[tuple[str, str], dict] = {}
    audit_root = output_root / ".classification_audit"
    if not audit_root.exists():
        return index
    for path in sorted(audit_root.glob("*.jsonl")):
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                row = json.loads(raw)
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            question = _key(row.get("question_number"))
            if not question:
                continue
            for paper in _paper_aliases(row.get("paper_full_code")) | _paper_aliases(row.get("paper")):
                index[(paper, question)] = row
    return index


def _config_for(subjects_root: Path, level: str, subject: str) -> SubjectConfig | None:
    path = subjects_root / level / subject / "config.json"
    if not path.is_file():
        return None
    try:
        return SubjectConfig(json.loads(path.read_text(encoding="utf-8")), config_path=path)
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _topic_columns(expected: str, config: SubjectConfig) -> tuple[list[str], list[str]]:
    """Respect exact existing identifiers; never invent a taxonomy label."""
    if expected in config.detailed_topics:
        return [expected], []
    if expected in config.major_topics:
        return [], [expected]
    return [], []


def build_examples(output_root: Path, labels_path: Path, subjects_root: Path,
                   memory_db: Path | None = None) -> tuple[int, int, list[str]]:
    """Import filled human labels as verified indexed records.

    The historical function name is retained for script/API compatibility, but
    no ``classification_examples.jsonl`` file is written or used.
    """
    audit = load_audit(output_root)
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    missing: list[str] = []
    with labels_path.open(newline="", encoding="utf-8-sig") as fh:
        for label in csv.DictReader(fh):
            expected = _key(label.get("expected_topic"))
            if expected in SENTINELS:
                continue
            subject = _key(label.get("subject"))
            level = _key(label.get("level"))
            paper = _key(label.get("paper"))
            question = _key(label.get("question_number"))
            candidate = next(
                (audit.get((alias, question)) for alias in _paper_aliases(paper)
                 if audit.get((alias, question))),
                None,
            )
            if not candidate or not _key(candidate.get("question_text")):
                missing.append(f"{paper}/{question}")
                continue
            grouped[(level, subject)].append({
                "paper": paper,
                "variant": _key(label.get("variant") or candidate.get("variant")),
                "question_number": question,
                "expected_topic": expected,
                "question_text": candidate["question_text"],
            })

    written = 0
    subjects_used = 0
    target = Path(memory_db) if memory_db is not None else default_memory_path()
    with ClassificationMemory(target, create=True) as memory:
        for (level, subject), rows in sorted(grouped.items()):
            config = _config_for(subjects_root, level, subject)
            if config is None:
                missing.extend(f"{row['paper']}/{row['question_number']} (missing config {level}/{subject})" for row in rows)
                continue
            # Keep deterministic idempotence per reviewed paper/question/topic.
            unique = {
                (row["paper"], row["question_number"], row["expected_topic"]): row
                for row in rows
            }
            accepted = 0
            for (_, _, expected), row in sorted(unique.items()):
                detailed, majors = _topic_columns(expected, config)
                if not detailed and not majors:
                    missing.append(
                        f"{row['paper']}/{row['question_number']} (unknown taxonomy topic {expected})"
                    )
                    continue
                memory.record_verified(
                    subject=config.subject,
                    level=config.level,
                    paper=row["paper"], variant=row["variant"],
                    question_number=row["question_number"],
                    topics=detailed,
                    major_topics=majors,
                    evidence=["Human-verified topic label imported from filled accuracy label CSV."],
                    question_text=row["question_text"],
                    classifier_version=CLASSIFIER_VERSION,
                    taxonomy_version=config.version,
                    syllabus_version=str(config.data.get("syllabus_source_sha256", "") or ",".join(config.syllabus_years)),
                    source="filled_topic_accuracy_label",
                    record_key=(
                        f"human-label:{config.subject}:{row['paper']}:"
                        f"{row['question_number']}:{expected}"
                    ),
                )
                accepted += 1
            if accepted:
                written += accepted
                subjects_used += 1
                print(
                    f"[memory] {level}/{subject}: {accepted} verified labels -> {target}"
                )
    return written, subjects_used, missing


def migrate_legacy(path: Path, *, subject: str, level: str, subjects_root: Path,
                   memory_db: Path | None = None) -> int:
    config = _config_for(subjects_root, level, subject)
    if config is None:
        raise ValueError(f"no config found for {level}/{subject}")
    target = Path(memory_db) if memory_db is not None else default_memory_path()
    with ClassificationMemory(target, create=True) as memory:
        count = memory.import_legacy_examples(
            path,
            subject=config.subject,
            detailed_topics=config.detailed_topics,
            major_topics=config.major_topics,
            taxonomy_version=config.version,
            syllabus_version=str(config.data.get("syllabus_source_sha256", "") or ",".join(config.syllabus_years)),
            classifier_version=CLASSIFIER_VERSION,
        )
    print(f"[memory] migrated {count} legacy JSONL record(s) from {path} -> {target}")
    return count


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-root", help="output root containing .classification_audit")
    ap.add_argument("--labels", help="filled human verification CSV")
    ap.add_argument("--subjects-root", default="subjects")
    ap.add_argument("--memory-db", default=None,
                    help="SQLite classification-memory store (default memory/classification_memory.sqlite3)")
    ap.add_argument("--migrate-legacy", default=None,
                    help="one old classification_examples.jsonl to import explicitly")
    ap.add_argument("--legacy-subject", default=None)
    ap.add_argument("--legacy-level", default=None, choices=("IGCSE", "A-Level"))
    args = ap.parse_args(argv)

    subjects_root = Path(args.subjects_root)
    memory_db = Path(args.memory_db) if args.memory_db else None
    if args.migrate_legacy:
        if not args.legacy_subject or not args.legacy_level:
            ap.error("--migrate-legacy requires --legacy-subject and --legacy-level")
        migrate_legacy(
            Path(args.migrate_legacy), subject=args.legacy_subject,
            level=args.legacy_level, subjects_root=subjects_root, memory_db=memory_db,
        )
        return 0
    if not args.output_root or not args.labels:
        ap.error("--output-root and --labels are required unless --migrate-legacy is used")
    written, subjects, missing = build_examples(
        Path(args.output_root), Path(args.labels), subjects_root, memory_db
    )
    print(f"[memory] wrote/updated {written} verified records across {subjects} subjects")
    if missing:
        print(f"[memory] skipped {len(missing)} labels without usable audit text or taxonomy")
        for item in missing[:10]:
            print(f"  - {item}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
