#!/usr/bin/env python3
"""Run a child command while streaming and saving the same output with process tree cleanup.

The Windows launcher uses this instead of redirecting the whole generator run
until exit. It keeps the live progress visible, writes a UTF-8 log, preserves
the child's exit code, handles signals (SIGINT/SIGTERM/KeyboardInterrupt) to
cleanly terminate process trees without leaving stale locks, and prints a heartbeat
if a PDF operation is quiet for a while.
"""
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import threading
import time
from queue import Empty, Queue
from pathlib import Path


def _emit(line: str, log_fh) -> None:
    log_fh.write(line)
    log_fh.flush()
    try:
        sys.stdout.write(line)
        sys.stdout.flush()
    except UnicodeEncodeError:
        data = line.encode(getattr(sys.stdout, "encoding", None) or "utf-8", errors="replace")
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


def _terminate_process_tree(proc: subprocess.Popen) -> None:
    """Terminate the process and all spawned child processes cleanly."""
    if proc.poll() is not None:
        return
    pid = proc.pid
    try:
        if sys.platform == "win32":
            # Windows: use taskkill with /T to kill entire process tree
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
        else:
            # POSIX: terminate process group
            try:
                pgid = os.getpgid(pid)
                os.killpg(pgid, signal.SIGTERM)
                time.sleep(0.5)
                if proc.poll() is None:
                    os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
    except Exception:
        pass
    try:
        proc.terminate()
        proc.wait(timeout=2.0)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--log", required=True, help="UTF-8 log file")
    ap.add_argument("--pid-file", default=None, help="File to store child PID for liveness detection")
    ap.add_argument("--lock-dir", default=None, help="Lock directory to manage/release on exit")
    ap.add_argument("command", nargs=argparse.REMAINDER,
                    help="child command after --")
    args = ap.parse_args(argv)
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        print("ERROR: no child command was supplied", file=sys.stderr)
        return 2

    log_path = Path(args.log).resolve()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    print("[launcher] live output enabled; log: " + str(log_path))

    pid_path = Path(args.pid_file).resolve() if args.pid_file else None
    lock_dir = Path(args.lock_dir).resolve() if args.lock_dir else None

    # Preexec on POSIX to establish a new process group for clean signal handling
    preexec = os.setsid if sys.platform != "win32" else None

    try:
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            preexec_fn=preexec,
        )
    except Exception as exc:
        print(f"[launcher] could not start child: {exc}", file=sys.stderr)
        return 1

    # Write PID for liveness checks
    if pid_path:
        try:
            pid_path.parent.mkdir(parents=True, exist_ok=True)
            pid_path.write_text(str(proc.pid), encoding="utf-8")
        except OSError:
            pass
    if lock_dir and lock_dir.is_dir():
        try:
            (lock_dir / "pid.txt").write_text(str(proc.pid), encoding="utf-8")
        except OSError:
            pass

    # Signal handlers to ensure clean shutdown
    def _sig_handler(signum, frame):
        _terminate_process_tree(proc)
        sys.exit(130)

    signal.signal(signal.SIGINT, _sig_handler)
    signal.signal(signal.SIGTERM, _sig_handler)

    queue: Queue[object] = Queue()

    def reader() -> None:
        assert proc.stdout is not None
        try:
            for line in iter(proc.stdout.readline, ""):
                queue.put(line)
        finally:
            queue.put(None)

    reader_thread = threading.Thread(target=reader, daemon=True)
    reader_thread.start()

    eof = False
    last_output = time.monotonic()
    heartbeat_after = 30.0
    exit_code = 1

    try:
        with log_path.open("a", encoding="utf-8", errors="replace") as log_fh:
            while not eof or proc.poll() is None:
                try:
                    item = queue.get(timeout=2.0)
                except Empty:
                    if time.monotonic() - last_output >= heartbeat_after:
                        elapsed = int(time.monotonic() - started)
                        _emit(f"[launcher] still running ({elapsed}s since last output)...\n", log_fh)
                        last_output = time.monotonic()
                    continue
                if item is None:
                    eof = True
                    continue
                _emit(str(item), log_fh)
                last_output = time.monotonic()

            # Drain any final lines after the process exits
            while True:
                try:
                    item = queue.get_nowait()
                except Empty:
                    break
                if item is not None:
                    _emit(str(item), log_fh)

            exit_code = int(proc.wait())

    except KeyboardInterrupt:
        print("\n[launcher] interrupted by user (Ctrl+C). Terminating processes...", file=sys.stderr)
        _terminate_process_tree(proc)
        exit_code = 130
    except Exception as exc:
        print(f"\n[launcher] unexpected error: {exc}", file=sys.stderr)
        _terminate_process_tree(proc)
        exit_code = 1
    finally:
        _terminate_process_tree(proc)
        if pid_path and pid_path.is_file():
            try:
                pid_path.unlink()
            except OSError:
                pass

    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
