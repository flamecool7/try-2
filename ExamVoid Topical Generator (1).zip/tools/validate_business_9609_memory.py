#!/usr/bin/env python3
"""Source-grounded functional validation for Business 9609/22 M/J 2024.

This is intentionally *not* an accuracy benchmark: Cambridge does not publish
per-question taxonomy labels and this repository has no independent human
adjudication file for the paper.  It uses the authentic QP/MS pair to prove
that frozen QP/MS matching, read-only raw-MS extraction, the 2024 official
syllabus profile, and bounded indexed-memory support work together.

No output archive, crop coordinate, or metadata.json is modified. The memory
database created by this tool is an isolated non-production validation fixture.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.classification_memory import ClassificationMemory
from core.classifier import CLASSIFIER_VERSION, TopicClassifier
from core.config_loader import load_subject_config_by_code_and_level
from core.cropping_engine import CroppingEngine
from core.mark_scheme_evidence import MarkSchemeEvidenceIndex
from core.ms_cropping_engine import MSCroppingEngine
from core.paper_identifier import parse_paper_filename
from core.qp_ms_matcher import QPMSMatcher


EVIDENCE_ROOT = ROOT / "validation_evidence/business_9609_s24_22_memory"
QP = EVIDENCE_ROOT / "runtime_input/9609_s24_qp_22.pdf"
MS = EVIDENCE_ROOT / "runtime_input/9609_s24_ms_22.pdf"
DEMO_DB = EVIDENCE_ROOT / "business_2024_source_grounded_memory_demo.sqlite3"
REPORT = EVIDENCE_ROOT / "authentic_business_2024_memory_validation.json"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _result_summary(result) -> dict:
    evidence = getattr(result, "evidence_summary", {}) or {}
    return {
        "winning_major": result.winning_major,
        "detailed_topics": list(result.detailed_topics),
        "confidence": result.confidence,
        "fallback_tier": result.fallback_tier,
        "major_scores": {key: round(value, 4) for key, value in result.major_topic_scores.items()},
        "mark_scheme": evidence.get("mark_scheme", {}),
        "memory": evidence.get("memory", {}),
        "memory_topic_effects": evidence.get("memory_topic_effects", {}),
        "memory_major_effects": evidence.get("memory_major_effects", {}),
    }


def run() -> dict:
    if not QP.is_file() or not MS.is_file():
        raise FileNotFoundError("authentic Business QP/MS validation fixture is unavailable")
    config = load_subject_config_by_code_and_level("9609", "A-Level", "2024")
    if config is None or not config.year_verified:
        raise RuntimeError("verified historical Business 2024 syllabus profile is unavailable")
    syllabus_version = str(config.data.get("syllabus_source_sha256", "") or ",".join(config.syllabus_years))

    # Frozen crop/match code is invoked read-only; this script does not write a
    # topical bundle. The MS text comes from the separate raw-PDF reader.
    qp_info, ms_info = parse_paper_filename(QP), parse_paper_filename(MS)
    qp_crops = CroppingEngine(target_width=2280, quality=95, dpi=150).process_paper(QP)
    ms_crops = MSCroppingEngine(target_width=2280, quality=95, dpi=150).process_paper(
        MS, expected_questions=[crop.number_int for crop in qp_crops]
    )
    matched = QPMSMatcher().match_questions(qp_crops, ms_crops, qp_info, ms_info, config.subject)
    index = MarkSchemeEvidenceIndex.from_pdf(MS)
    if [item.number_int for item in matched] != [1, 2] or index.question_numbers != (1, 2):
        raise AssertionError("authentic QP/MS question identity did not remain 1, 2")

    baseline_classifier = TopicClassifier(config)
    baseline = {
        str(item.number_int): baseline_classifier.classify_question(
            item, mark_scheme_text=index.text_for_question(item.number_int)
        )
        for item in matched
    }

    if DEMO_DB.exists():
        DEMO_DB.unlink()
    with ClassificationMemory(DEMO_DB, create=True) as memory:
        # These are deliberately high-confidence *source-grounded fixtures*,
        # not records claimed to be independently human verified. They use
        # concise factual evidence from the published MS/syllabus and nearby
        # paraphrases so the current paper cannot be treated as a duplicate.
        q1_record = memory.record_high_confidence(
            subject=config.subject, level=config.level, paper="fixture", variant="22", question_number="Q1",
            topics=["The_marketing_mix", "Budgets", "Human_resource_management", "The_nature_of_operations"],
            question_text=(
                "Evaluate packaging; analyse selection with an assessment centre; explain incremental "
                "budgeting and sustainability of operations."
            ),
            mark_scheme_text=(
                "Packaging, assessment centre, incremental budgeting and sustainability are assessed "
                "Business concepts."
            ),
            evidence=[
                "Official 2023–2025 syllabus includes the role of packaging in promotion.",
                "Published 9609/22 Q1 mark scheme assesses incremental budgeting and an assessment centre.",
            ],
            confidence=0.94, classifier_version=CLASSIFIER_VERSION,
            taxonomy_version=config.version, syllabus_version=syllabus_version,
            source="source_grounded_validation_fixture_not_human_gold",
        )
        q2_record = memory.record_high_confidence(
            subject=config.subject, level=config.level, paper="fixture", variant="22", question_number="Q2",
            topics=["Inventory_management", "Costs", "Size_of_business", "The_nature_of_marketing"],
            question_text=(
                "Analyse Just in Time inventory management, contribution and break-even analysis, "
                "mass marketing and the importance of a small business."
            ),
            mark_scheme_text=(
                "JIT inventory, contribution, break-even, mass market and small business are assessed."
            ),
            evidence=[
                "Official syllabus 4.2.2 names Just in Time inventory management.",
                "Official syllabus 5.4.4 names break-even analysis and contribution.",
                "Published 9609/22 Q2 mark scheme contains JIT, break-even and small-business evidence.",
            ],
            confidence=0.95, classifier_version=CLASSIFIER_VERSION,
            taxonomy_version=config.version, syllabus_version=syllabus_version,
            source="source_grounded_validation_fixture_not_human_gold",
        )
        correction_record = memory.record_correction(
            subject=config.subject, level=config.level, paper="fixture", variant="22", question_number="Q2",
            correct_topics=["Inventory_management", "Costs"], incorrect_topics=["Management"],
            question_text=(
                "Analyse a JIT approach to inventory management and calculate contribution at break-even."
            ),
            mark_scheme_text="JIT inventory management and contribution/break-even are explicitly assessed.",
            reason=(
                "Source-grounded correction fixture: generic use of the word management is not evidence "
                "that the Management syllabus topic is assessed."
            ),
            classifier_version=CLASSIFIER_VERSION, taxonomy_version=config.version,
            syllabus_version=syllabus_version,
            source="source_grounded_validation_fixture_not_human_gold",
        )
        negative_record = memory.record_negative(
            subject=config.subject, level=config.level, paper="fixture", variant="22", question_number="Q2",
            incorrect_topics=["The_marketing_mix"],
            question_text="Explain mass market and analyse Just in Time inventory management.",
            mark_scheme_text="Mass market and JIT inventory management are assessed.",
            reason=(
                "Source-grounded negative fixture: mass-market evidence belongs to The_nature_of_marketing, "
                "not The_marketing_mix."
            ),
            classifier_version=CLASSIFIER_VERSION, taxonomy_version=config.version,
            syllabus_version=syllabus_version,
            source="source_grounded_validation_fixture_not_human_gold",
        )
        memory.record_similar_question_relation(
            q2_record, correction_record, similarity=0.88,
            evidence="Reviewed fixture relation: both contain JIT inventory and contribution/break-even concepts.",
            source="source_grounded_validation_fixture",
        )
        # q1_record is retained in the DB too; relation is deliberately only
        # asserted for the semantically overlapping Q2 fixture/correction pair.
        with_memory_classifier = TopicClassifier(config, classification_memory=memory)
        with_memory = {
            str(item.number_int): with_memory_classifier.classify_question(
                item, mark_scheme_text=index.text_for_question(item.number_int)
            )
            for item in matched
        }
        stats = memory.stats()
        relationships = memory.similar_question_relationships(q2_record)

    # Functional, source-grounded expectations. These are not represented as
    # independently verified answer-key labels and are not converted into an
    # accuracy percentage.
    expected_sets = {
        "1": {"The_marketing_mix", "Budgets", "Human_resource_management", "The_nature_of_operations"},
        "2": {"Inventory_management", "Costs", "Size_of_business", "The_nature_of_marketing"},
    }
    for number, expected in expected_sets.items():
        result = with_memory[number]
        if not expected.issubset(set(result.detailed_topics)):
            raise AssertionError(f"Q{number} source-grounded expected concepts missing: {expected} vs {result.detailed_topics}")
        if len(result.detailed_topics) > 4:
            raise AssertionError(f"Q{number} violated four-topic cap")
    if with_memory["2"].evidence_summary["memory"]["retrieved_count"] < 1:
        raise AssertionError("Q2 did not retrieve the selective source-grounded memory fixture")

    report = {
        "schema": "authentic-business-memory-validation/1",
        "purpose": "functional source-grounded validation, not an independent accuracy benchmark",
        "source_provenance": {
            "qp_path": str(QP.relative_to(ROOT)), "qp_sha256": _sha256(QP),
            "ms_path": str(MS.relative_to(ROOT)), "ms_sha256": _sha256(MS),
            "host_note": "QP/MS copies were acquired from a third-party host and locally identity-checked; they are not represented as direct Cambridge downloads.",
            "official_syllabus_url": config.official_source,
            "official_syllabus_profile": config.version,
        },
        "locks_observed": {
            "cropper_changed": False,
            "metadata_json_changed": False,
            "note": "Frozen crop engines were invoked only through their existing public process_paper APIs; no output bundle was written.",
        },
        "mark_scheme_index": index.audit_summary(),
        "without_memory": {number: _result_summary(result) for number, result in baseline.items()},
        "with_memory": {number: _result_summary(result) for number, result in with_memory.items()},
        "memory_fixture": {
            "database": str(DEMO_DB.relative_to(ROOT)),
            "stats": stats,
            "similar_question_relationships_for_q2_fixture": relationships,
            "trust_statement": "Records are isolated source-grounded validation fixtures. They are high_confidence/correction/negative records and are not claimed to be independent human-verified labels.",
        },
        "source_grounded_functional_expectations": {
            number: sorted(topics) for number, topics in expected_sets.items()
        },
        "accuracy_comparison": {
            "status": "NOT_MEASURED",
            "reason": "No independent human-verified per-question taxonomy labels are available for this authentic paper. Functional expectations above are derived from published QP/MS/syllabus evidence and must not be reported as generalized accuracy or improvement.",
        },
    }
    REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    return report


def main() -> int:
    report = run()
    print(f"[business-memory-validation] PASS: wrote {REPORT}")
    print("[business-memory-validation] accuracy: NOT_MEASURED (no independent human ground truth)")
    for number, value in report["with_memory"].items():
        print(
            f"  Q{number}: {value['detailed_topics']} -> {value['winning_major']} "
            f"(retrieved={value['memory'].get('retrieved_count', 0)})"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
