#!/usr/bin/env python3
"""Controlled maintenance commands for persistent classification memory.

Nothing in this tool reads or modifies question-folder metadata/crops. It is a
human-review workflow: add concise factual evidence records, review stale
versioned records, or explicitly link two reviewed similar questions. It never
runs automatic reclassification.

Record JSON format (one object or a list) uses ``record_type`` equal to
``verified``, ``high_confidence``, ``correction``, or ``negative``. Required
text fields are ``subject`` and ``question_text``; correction/negative records
also need ``incorrect_topics`` and a concise ``reason``. Use exact current
syllabus identifiers in topic fields.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.classification_memory import ClassificationMemory, default_memory_path


def _records_from_file(path: Path) -> list[dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        return [data]
    if isinstance(data, list) and all(isinstance(item, dict) for item in data):
        return data
    raise ValueError("record JSON must be an object or list of objects")


def add_records(memory: ClassificationMemory, rows: list[dict]) -> int:
    written = 0
    for index, row in enumerate(rows, 1):
        payload = dict(row)
        record_type = str(payload.pop("record_type", payload.pop("trust_level", ""))).strip()
        if record_type == "verified":
            memory.record_verified(**payload)
        elif record_type == "high_confidence":
            memory.record_high_confidence(**payload)
        elif record_type == "correction":
            # JSON calls the positive side ``correct_topics``; support the
            # public ``topics`` alias only for convenience, never guessing it.
            if "correct_topics" not in payload and "topics" in payload:
                payload["correct_topics"] = payload.pop("topics")
            memory.record_correction(**payload)
        elif record_type == "negative":
            memory.record_negative(**payload)
        else:
            raise ValueError(f"row {index}: unsupported record_type {record_type!r}")
        written += 1
    return written


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default=str(default_memory_path()))
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("stats", help="show store counts/version information")
    add = sub.add_parser("add", help="add human-reviewed factual evidence records")
    add.add_argument("--records", required=True, help="JSON object/list of reviewed records")
    relate = sub.add_parser("relate", help="persist a reviewed similar-question relationship")
    relate.add_argument("--left", type=int, required=True, help="first memory record id")
    relate.add_argument("--right", type=int, required=True, help="second memory record id")
    relate.add_argument("--similarity", type=float, required=True)
    relate.add_argument("--evidence", required=True, help="brief factual relation note")
    relate.add_argument("--source", default="human_reviewed_similarity")
    stale = sub.add_parser("stale", help="export records requiring human version review")
    stale.add_argument("--subject", required=True)
    stale.add_argument("--taxonomy-version", default="")
    stale.add_argument("--syllabus-version", default="")
    stale.add_argument("--classifier-version", default="")
    stale.add_argument("--out", default=None, help="optional JSON output path")
    args = parser.parse_args(argv)

    db = Path(args.db)
    with ClassificationMemory(db, create=True) as memory:
        if args.command == "stats":
            print(json.dumps(memory.stats(), indent=2, sort_keys=True))
            return 0
        if args.command == "add":
            count = add_records(memory, _records_from_file(Path(args.records)))
            print(f"[memory] added/updated {count} reviewed record(s); no automatic reclassification was run")
            return 0
        if args.command == "relate":
            relation_id = memory.record_similar_question_relation(
                args.left, args.right, similarity=args.similarity,
                evidence=args.evidence, source=args.source,
            )
            print(f"[memory] recorded reviewed similar-question relation id={relation_id}")
            return 0
        if args.command == "stale":
            rows = memory.stale_records(
                subject=args.subject, taxonomy_version=args.taxonomy_version,
                syllabus_version=args.syllabus_version,
                classifier_version=args.classifier_version,
            )
            text = json.dumps(rows, indent=2, sort_keys=True)
            print(text)
            if args.out:
                path = Path(args.out)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(text + "\n", encoding="utf-8")
                print(f"[memory] wrote review inventory to {path}; records were not reclassified automatically")
            return 0
    raise AssertionError("unreachable")


if __name__ == "__main__":
    raise SystemExit(main())
