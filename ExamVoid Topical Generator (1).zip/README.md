# ExamVoid Topical Generator - Official Syllabus Integration

**Transforms Chemistry 9701 reference into genuine universal generator for 22 Cambridge subjects**

Official Cambridge International syllabus documents are authoritative source for every subject's topic hierarchy. The point-based winner is written first in JSON and that exact, unmodified JSON string is the physical folder name; single-folder, no duplication.

## Final Supported Subject Matrix (Official Codes)

```
IGCSE (11 required + official)
├── Chemistry              0620 - 2026 syllabus, 14 major topics
├── Physics                0625 - 2026 syllabus
├── Biology                0610 - 2026 syllabus
├── Mathematics            0580 - 2025-2027 syllabus (Number, Algebra, Geometry...)
├── Computer Science       0478 - 2026-2028 syllabus (Data representation, Data transmission, Hardware, Software, Internet, Automated tech, Algorithm design, Programming, Databases, Boolean logic)
├── Economics              0455 - 2026 syllabus (Basic economic problem, Allocation of resources, Micro decision makers, Government macroeconomy, Economic development, International trade)
├── Business Studies       0450 - 2026 syllabus (Understanding business activity, People in business, Marketing, Operations, Financial, External influences)
├── Literature in English  0475 - 2026 syllabus (Poetry, Prose, Drama, Unseen, Literary techniques, Themes, Context)
├── History                0470 - 2027-2028 syllabus (Core 19th/20th century, Depth Studies: WWI, Germany, Russia, USA, WWII Europe/Asia)
├── ICT                    0417 - 2023-2025 syllabus (Types components, Input/output, Storage, Networks, Effects IT, ICT applications, Systems life cycle, Safety, Practical skills)
└── Geography              0460 - 2027-2029 syllabus (Changing river, coastal, ecosystems, Tectonic hazards, Climate change, Changing populations, towns, Development, economies, Resource provision)

A-LEVEL (11 required + Biology extra)
├── Chemistry              9701 - Reference implementation (Atomic, Bonding, Energetics, Equilibria, Kinetics, Electrochemistry, Inorganic, Organic)
├── Physics                9702
├── Mathematics            9709 - 2028-2030 syllabus (Pure 1,2,3, Mechanics, Stats 1,2)
├── Further Mathematics    9231 - 2026-2027 syllabus (Further Pure 1,2, Further Mechanics, Further Stats)
├── Computer Science       9618 - 2026 syllabus (Information representation, Communication, Hardware, Processor Fundamentals, System Software, Security, Ethics, Databases, Algorithm Design, Data Types, Programming, Software Development, Advanced: Data Rep, Communication tech, Virtual Machines, Security, AI, Computational thinking, Further Programming)
├── Economics              9708 - 2026-2028 syllabus (AS: Basic ideas, Price system, Govt micro, Macroeconomy, Govt macro, International + A-Level extensions Utility, Efficiency, Market structures, Labour market, Growth sustainability, Globalisation)
├── Business                9609 - 2025 syllabus (Business & environment, People, Marketing, Operations, Finance, Strategic management)
├── English Literature     9695 - 2026 syllabus (Poetry, Prose, Drama, Unseen, Literary techniques, Themes)
├── History                9489 - 2026 syllabus (Modern Europe 1750-1921, USA 1820-41, International 1870-1945, Paper 3: WWI origins, Holocaust, Cold War, Depth: European interwar, USA 1944-92, International 1945-92)
├── Information Technology 9626 - 2025-2027 syllabus (Data processing, Hardware software, Monitoring control, Algorithms, eSecurity, Digital divide, Expert systems, Spreadsheets, Modelling, Database, Video/audio, IT in society, Emerging tech, Communications, Project management, System life cycle, Data analysis, Mail merge, Graphics, Animation, Web programming)
└── Geography              9696 - 2025 syllabus (Core Physical: Hydrology, Atmosphere, Rocks; Core Human: Population, Migration, Settlement; Advanced Physical: Tropical, Coastal, Hazardous, Arid; Advanced Human: Production, Environmental management, Global interdependence, Economic transition)
```

All configs validated per Requirement 11.

## Architecture - Syllabus-Year Aware

```
LEVEL (IGCSE/A-Level)
↓
SUBJECT (Chemistry, CS, Econ...)
↓
SYLLABUS CODE (0620, 9618...)
↓
EXAMINATION YEAR (2026, 2027...) → Correct Historical Config
↓
OFFICIAL TOPIC HIERARCHY
↓
QUESTION
↓
DETAILED TOPICS → JSON
↓
MAJOR TOPIC MAPPING (official high-level)
↓
POINT SYSTEM (marks, subquestions, purpose, MS dependency, specialization)
↓
ONE WINNING FOLDER (no duplication)
↓
QP + MS WEBP (2280px)
↓
AUTOMATIC VALIDATION
```

**Year Awareness:** `subjects/A-Level/Chemistry_9701/config.json` default latest, plus optional `2025/config.json`, `2026/config.json` when syllabus differs. Loader: `load_subject_config_by_code_and_level(code, level, year)` picks correct. If paper 2023 uses old syllabus but code same, uses historical config.

## Official Syllabus Is Source Of Truth

Per prompt, not invented:
- Fetched official PDFs: `https://www.cambridgeinternational.org/Images/697167-2026-2028-syllabus.pdf` (0478), `697154-2026-syllabus.pdf` (0455), `596930-2023-2025-syllabus.pdf` (0450), `718150-2027-2029-syllabus.pdf` (0460), `697372-2026-syllabus.pdf` (9618), `744634-2028-2030-syllabus.pdf` (9709), `697357-2026-2027-syllabus.pdf` (9231), `697423-2026-2028-syllabus.pdf` (9708), `662482-2025-2027-syllabus.pdf` (9626), `664556-2025-2026-syllabus.pdf` (9696) etc.
- Preserved hierarchy: e.g., 0478 official shows `1 Data representation → 1.1 Number systems, 1.2 Text sound images, 1.3 Data storage compression` → config: major `Data_representation`, detailed `Number_systems`, `Text_sound_and_images`, `Data_storage_and_compression`
- Official wording preserved as safe identifiers: `"Security, privacy and data integrity"` → `Security_privacy_and_data_integrity`

## Major vs Detailed Rule

- **Major** = high-level official structure and the point-system routing winner.
  The routing winner is stored as `metadata.json` `topic[0]`; its exact string is the physical folder name.
  - Example 9618: `Information_Representation`, `Communication`, `Hardware`, `Processor_Fundamentals`, `System_Software`, `Security_privacy_and_data_integrity`, etc.
- **Detailed** = additional, legitimate multi-topic classification values in the JSON `topic` array. They remain exact reference strings.
  - Example: `{"topic": ["Information_Representation", "Data_Representation", "Compression"]}` routes to `Information_Representation/`—the exact `topic[0]` string.

## Special Handling Per Requirements

**English Literature 0475/9695:**
- Majors: Poetry, Prose, Drama, Unseen_texts, Literary_techniques, Themes_and_characterisation, Context_and_comparison
- NOT set-text names as folders. Detailed: Poetry_analysis, Characterisation_drama, Unseen_poetry, Language_and_imagery, Themes_exploration etc.
- Distinguishes literary techniques, themes, characterisation, structure, language, form, context, comparison per Requirement 13.

**History 0470/9489:**
- Majors: Core_History_19th_century, Core_History_20th_century, Depth_Study_Germany_1918_45, Depth_Study_Russia_1905_41 etc.
- NOT generic Causes/People/Events unless official syllabus uses.
- Preserves official Key Questions and Depth Studies per Requirement 14.

**Geography 0460/9696:**
- Majors: Changing_river_environments, Changing_coastal_environments, Changing_ecosystems, Tectonic_hazards, Climate_change, Changing_populations, Changing_towns_and_cities, Development, Changing_economies, Resource_provision (0460 official 2027-2029)
- And for 9696: Core_Physical_Hydrology, Core_Physical_Atmosphere, Core_Human_Population, Advanced_Physical_Tropical, Advanced_Human_Production etc.
- No invented folder structure per Requirement 15.

**Business + Economics Separate:**
- Business 0450/9609 uses Business syllabus, Economics 0455/9708 uses Economics syllabus
- Similar concepts Demand/Supply etc don't cause cross-subject classification

**Mathematics + Further Mathematics Separate:**
- 9709 vs 9231 completely separate configs, official 9231 topics: Roots polynomial, Rational functions, Polar coordinates, Hyperbolic functions etc.

**Computer Science + ICT/IT Separate:**
- CS: Algorithms, Programming, Data Structures, Computer Architecture
- ICT/IT: Spreadsheets, Databases, Document Production, Data Manipulation, Communication per official 0417/9626

## Configuration Validation (Requirement 11)

Before use, automatically verify per config:
✓ Syllabus code exists (4-digit)
✓ Level correct (IGCSE/A-Level) + code vs level consistency
✓ Subject name correct and contains code (e.g., Chemistry_0620)
✓ Major topics exist
✓ Every minor maps to a major
✓ No minor maps to invalid major
✓ No duplicate identifiers
✓ Folder-safe names (no spaces/illegal chars)
✓ Syllabus year defined (e.g., ["2026","2027","2028"])
✓ Internally consistent

If fails: "Do not process papers using that configuration"

Validated: All 24 configs pass - 12 IGCSE + 12 A-Level (including Additional Mathematics 0606 and Biology 9700).

## Testing - All Required Syllabuses

Demo mode generates official-syllabus-based PDFs for every required syllabus:

```
python main.py --demo --demo-all --clean --validate

IGCSE: 0478 CS, 0580 Math, 0606 Additional Math, 0455 Econ, 0450 Business, 0475 Lit, 0470 Hist, 0417 ICT, 0460 Geog, 0620 Chem, 0625 Phys, 0610 Bio
A-Level: 9618 CS, 9709 Math, 9231 Further Math, 9708 Econ, 9609 Business, 9695 Lit, 9489 Hist, 9626 IT, 9696 Geog (+9701 Chem Ref, 9702 Phys)
```

Demo smoke result varies with the configured fixture list; production completion is determined only by the guarded batch audit and its exit code.

Checks per Requirement 22:
✓ Subject detection, Syllabus detection, Correct config loaded (year-aware)
✓ Questions extracted, Cropping universal (barcode/footer/reference exclusion with validated proportional top margins - no 5px clips, multi-page, 2280px WebP)
✓ Detailed topics classified (official), Major resolved via point system, Exactly one folder, QP/MS pair, JSON, No empty/metadata-only, No duplicates, Final validation passes

Chemistry 9701 reference preserved after expansion.

## Usage

**Windows (run.bat control launcher):**
Double-click `run.bat` to open the Python control dashboard. The BAT file only
sets the repository directory, finds Python, delegates to `run_pipeline.py`,
and returns its exit code; all menu and processing behaviour lives in Python.

The dashboard supports incremental **Process New**, **Resume / Process
Pending**, exact selected scopes (file, folder, variant, subject, or
season/year), guarded **Reprocess Everything**, archive audit, read-only dry
run, proof generation, statistics, installation checks, safe cleanup, settings,
benchmarks, regression scenarios, and developer tools. A live run lock prevents
concurrent archive writers; a dead-PID lock is recovered automatically.

`Process New` is the normal workflow: it queues only new or changed logical
bundles and does not retry failed work unless **Resume / Process Pending** or
`--retry-failed` is selected. `--dry-run` is read-only: it does not create the
output directory, database, manifest, staging data, or lock.

Worker selection is RAM-aware: `workers=auto` requests 6 workers on 16 GB+,
4 on 12 GB+, and 2 below that, while the runtime guard may clamp the count.
Set an explicit value in `settings.ini` when needed.

Useful non-interactive commands:
```bat
python run_pipeline.py --input input --output output
python run_pipeline.py --input input --output output --session s26 --workers 1
python run_pipeline.py --input input --output output --year 2026 --syllabus-code 9701 --workers 1
python run_pipeline.py --input input --output output --variant 22 --dry-run
```
Session filters include `s26`, `summer`, `may-june`, `m26`, `w25`, and
`specimen`. Normal runs stay local-only; retrieval is always explicit opt-in.

**All platforms:**
```bash
pip install -r requirements.txt
python main.py --input input --output output --validate
python main.py --demo --demo-all --clean --validate  # Demo subjects
python run_pipeline.py --input input --output output --workers 1
python run_pipeline.py --input input --output output --performance   # fuller RAM/CPU profile for ~4GB+ machines
# Exit 0 = clean; exit 2 = safe output with review_required; exit 1 = failure

**Offline examiner-report inventory:**
The launcher menu option 7, or `check_existing_ers.bat`, recursively scans the
folders for QP/MS/ER PDFs and writes `missing_examiner_reports.txt`,
`examiner_report_inventory.csv`, and `examiner_report_inventory.json`. It does
not download anything:
```bat
check_existing_ers.bat
py -3 check_existing_ers.py --root input --root examiner_reports_2020_2025
```
May/June 2026 is reported as `s26` / `Summer` / `May-June (Summer) 2026`.
A session-wide file such as `9701_s26_er.pdf` is matched to every component in
that syllabus/session; component ER filenames are matched by paper number.

# Explicitly fetch missing mark schemes (official Cambridge index first):
python run_pipeline.py --input input --output output --workers 1 --fetch-missing-ms
# Benchmark worker counts on YOUR machine (e.g. 16GB host):
python tools/benchmark_workers.py --input input --output-root benchmark_runs --workers 3 4 5 10 --performance --fetch-missing-ms
```

Place PDFs like:
- IGCSE: `0478_m26_qp_12.pdf` + `0478_m26_ms_12.pdf` (CS), `0455_m26_qp_12.pdf` (Econ), `0450_m26_qp_12.pdf` (Business), `0475_m26_qp_12.pdf` (Lit), `0470_m26_qp_12.pdf` (Hist), `0417_m26_qp_12.pdf` (ICT), `0460_m26_qp_12.pdf` (Geog), `0580_m26_qp_42.pdf` (Math)
- A-Level: `9618_m26_qp_12.pdf` (CS), `9231_m26_qp_12.pdf` (Further Math), `9708_m26_qp_12.pdf` (Econ), `9609_m26_qp_12.pdf` (Business), `9695_m26_qp_12.pdf` (Lit), `9489_m26_qp_12.pdf` (Hist), `9626_m26_qp_12.pdf` (IT), `9696_m26_qp_12.pdf` (Geog)

## Production Workspace

```
core/ - universal engine (year-aware, official syllabus validation)
  config_loader.py - syllabus year awareness, validation per R11
  paper_identifier.py - code+year+level
  subject_detector.py - level+code+year conflict detection
  cropping_engine.py - preserved universal (DO NOT modify)
  classifier.py - detailed→major point system
  output_manager.py - IGCSE/A-Level separated, single-folder
  validation.py - cross-level, cross-subject, year-aware

subjects/
  IGCSE/ - 12 official (0478,0580,0606,0455,0450,0475,0470,0417,0460,0620,0625,0610)
  A-Level/ - 12 official (9618,9709,9231,9708,9609,9695,9489,9626,9696,9701,9702,9700)

main.py - supports --demo-all for all 22 official, year-aware config selection
run.bat - thin Windows launcher; opens the Python control menu by default and forwards explicit CLI arguments
requirements.txt
input/.gitkeep
output/.gitkeep
```

No empty configs, every subject has official major/detailed/mapping/keywords/weights/order/year/source/validation usable immediately.

## IGCSE low-RAM batch behavior

Older IGCSE PDFs can contain answer-option numbers that look like question
numbers. The low-RAM vector-first cropper chooses the earliest marker in
printed document order, so it cannot jump into an option row and render the
rest of a paper as one giant crop. Each batch bundle runs in a disposable
worker process, and older portrait 0580 mark schemes use a strict QP-proven
Question-column fallback. If a question is ambiguous, its crop is preserved
under `review_required` and the batch exits with code `2`; it is never silently
lost.

## Auto-downloading missing question papers (`--fetch-missing-qp`)

When a mark scheme (or examiner report) is present in the input folder but its
question paper is missing, the pipeline can fetch the QP automatically instead
of failing the bundle:

```bash
python run_guarded.py --input papers --output output --fetch-missing-qp
python main.py -i papers -o output --fetch-missing-qp
python run_pipeline.py --input papers --output output --fetch-missing-qp
```

How it works (`core/qp_fetcher.py`, mirror of `core/ms_fetcher.py`):

1. **Pre-flight** (guarded/main) — scans the input folder for `_ms_` / `_er_`
   files whose `_qp_` twin is absent, or (batch mode) queries the bundle
   database for `qp_file_id IS NULL` bundles.
2. **Source order (contractual)** — 1) Cambridge International official
   past-papers page (parsed for an exact year/season/component
   question-paper link), 2) pastpapers.co approved mirror patterns.
3. **Verify before use** — every download must be a real PDF that opens
   cleanly, carries the syllabus code / component / session, and looks like a
   question paper (candidate instructions present; mark-scheme or insert
   identity swap = rejected). Failures are quarantined as
   `*.unverified.pdf` and reported — never fed into the pipeline.
4. **Safety** — opt-in only, 2s rate limit between requests, 50 MB cap,
   every attempt logged (`qp_fetch_log` in `pipeline.sqlite`, or the run
   console), existing user files are never overwritten, and a stale identity
   manifest is refreshed so the downloaded QP is picked up on the same run.

Notes:
- The official page hosts only the current public window (e.g. June 2024 +
  specimen for 9701/0620); older or very recent sessions honestly fall
  through to the mirror candidates and fail loudly if absent.
- `--dry-run` lists the candidate URLs without downloading anything.
- To make fetching fully automatic (no flag), set `default=True` on the
  `--fetch-missing-qp` argument in `run_guarded.py` / `main.py` /
  `run_pipeline.py`, or wrap your command in a launcher script that always
  passes the flag.

## Classification coverage (review_required reduction)

Topic folders landing in `review_required/` are almost always caused by
**missing keyword evidence**, not classifier bugs: a question is only routed
when a topic's keyword list matches its text. A topic whose keyword list
contains only its own name (e.g. `Electrochemistry: [electrochemistry]`)
will match almost nothing on real papers.

Measured on the real 9701_s24_qp_11 corpus (40 MCQs): **16/40 → 0/40**
questions requiring review after the keyword-coverage expansion
(2026-08-13). The expansion added standard Cambridge syllabus vocabulary
(e.g. `isotope`, `ideal gas`, `silver nitrate`, `monomer`, `equilibrium
constant`) to weak topics across all 21 subject configs — ~1,100 keywords,
data-only, no classifier-threshold changes. To reproduce or extend:

```bash
python - <<'EOF'
import json
cfg = json.load(open('subjects/<level>/<Subject>_<code>/config.json'))
# add words to cfg['classification_keywords']['<topic>'] then save

## Classification coverage (review_required reduction)

Topic folders landing in `review_required/` are almost always caused by
**missing keyword evidence**, not classifier bugs: a question is only routed
when a topic's keyword list matches its text. A topic whose keyword list
contains only its own name (e.g. `Electrochemistry: [electrochemistry]`)
will match almost nothing on real papers.

Measured on the real 9701_s24_qp_11 corpus (40 MCQs): **16/40 to 0/40**
questions requiring review after the keyword-coverage expansion
(2026-08-13). The expansion added standard Cambridge syllabus vocabulary
(e.g. `isotope`, `ideal gas`, `silver nitrate`, `monomer`, `equilibrium
constant`) to weak topics across all 21 subject configs — about 1,100
keywords, data-only, no classifier-threshold changes. Coverage targets are
pinned by `tests/test_keyword_overhaul_targets.py`.

Tip for diagnosing a `review_required` question: classify it directly and
inspect `reasoning` — it says either `No deterministic topic evidence`
(keywords missing) or `Ambiguous classification` (top-2 scores too close;
add a distinctive term to the right topic).

## Diagram-based reasoning (corpus-hardened, 2026-08-13)

The classifier now looks at what a question *draws*, not just what it says.

**New raster signals** (`core/diagram_evidence.py`): `venn_diagram`,
`bond_line_structure` (organic zigzag), `energy_levels`, `wave_train`,
`circuit_like`, `grid_table`, `cell_like` — plus hardened versions of the
existing triangle/arc/circle/arrow detectors (text-glyph noise removed via
scale floors: triangles > 500 px², arcs/circles radius ≥ 14 px at 2280px
width, Venn = 1–8 similar-sized partially-overlapping blob pairs).

**Science boosts** (`core/science_diagram_signals.py`): per-subject
diagram→topic tables for Chemistry 0620/9701, Physics 0625/9702, Biology
0610/9700. E.g. bond-line structure → organic chemistry, circuit geometry →
Electricity/D_C_circuits, wave trains → Waves, cell-like blobs → cell
structure. Boosts are 1–3 points and are applied ONLY after text evidence
passes the fail-closed gate — diagram-only questions still go to
`review_required`.

**Math hardening** (`core/math_reference.py`): whitespace-normalised text
matching (fixes multi-line formula extraction like `tan\ntan`), distinctive
phrases (`cuboid`, `cyclic quadrilateral`, `venn diagram`, `sinx`) open the
evidence gate, and diagram fusion only bumps on multi-signal evidence
(angle arcs + triangle + greek label = trig figure; real Venn = Probability).

**Measured** on 27 real June-2024 Cambridge QPs (425 questions, 11
subjects): questions needing review dropped **57 → 10 (2.4%)**, 49 fixed,
zero regressions. The 10 remaining are honestly hard: mangled maths
extraction, a removed question, and genuine multi-topic questions.

## Categorization buffs (2026-08-13, corpus-measured)

| Buff | What it does |
|---|---|
| **MCQ option down-weighting** | Keyword hits in the A/B/C/D option block score 0.4×; the stem carries the true signal (options are distractor-rich) |
| **Phrase whitespace tolerance** | Per-glyph PDF extraction splits phrases with newlines (`reagents\nand\nconditions`); whitespace is collapsed before phrase matching — every multi-word phrase bonus now fires |
| **Paper-coherence prior** | Two-pass classification: a topic that won ≥2 questions elsewhere in the same paper nudges ambiguous near-ties (small bonus, ambiguous-only, never touches confident winners) |
| **Math vocabulary** | 0580 Number: exponential/depreciation + "as a fraction"/"calculate."; Algebra: "inequalit" stem + "factorise completely"/"inequalities that define" |
| **Science rebalance** | 0625 Thermal + Brownian/smoke; 9701 Reaction_kinetics drops generic "reaction" for order/rate terms; 0610 Biotech + sticky-end/recombinant; 0620 Organic gains carboxylic/propanoic acid |

Measured on 385 real questions (June-2024 corpus): **reviews 10 → 2 (0.5%)**,
zero new reviews, all route changes audited neutral-or-better. The 2
remaining are correct: a question Cambridge removed, and a genuine
differentiation+iteration hybrid. Pinned by `tests/test_classification_buffs.py`.

## 23-subject real-paper validation (2026-08-13)

Downloaded REAL June-2024 QPs for the 13 previously-untested subjects and
scanned them through the classifier. Every subject's keyword taxonomy has
now seen genuine Cambridge question text.

| Subject | Result |
|---|---|
| 0417 ICT, 0450 Business, 0455 Economics, 0470 History, 0478 CS, 0606 Add. Maths, 9231 Further Maths, 9489 History, 9609 Business, 9618 CS, 9695 Eng. Lit, 9700 Biology, 0475 Lit | **0 reviews** on their real papers after fixes |
| Full corpus | **512 Qs / 23 subjects / 0.39% review** (2 intentionally kept) |

Fixes this round: math pick-gate now routes single-distinctive-keyword
questions (0606 logarithms/binomial/kinematics, 9231 roots-of-polynomial);
0417/0455/9695/9489/9700 keyword expansions; a global plural-suffix buff was
tried and reverted (it caused cross-topic near-ties — explicit plurals live
in configs instead). Full detail in ROUTING_STATE_LOCK.md RS-42.

## All 24 subjects now validated on real papers (2026-08-13)

The last untested subject (0475 IGCSE Literature) is covered: essay-prompt
vocabulary ("read this poem/passage/extract", author names, prompt verbs)
took its real June-2024 paper from 13/22 reviews to 0/22. Full `run_guarded`
end-to-end verified on a mixed new-subject bag (0455 + 0417 with real
QP+MS): 43/43 saved, all stages green, audit clean.

**Corpus totals (all current code): 534 questions, 32 papers, all 24
subjects — 0.37% review (2 intentionally kept: a question Cambridge
removed, and a genuine differentiation+iteration hybrid).**

## Syllabus-code aliases + Combined/Coordinated Sciences (2026-08-14)

**Dual / superseded codes are now handled.** Cambridge assigns more than one
code to the same syllabus; the pipeline resolves them all to one subject
config while keeping the original code in metadata:

| Alias code | Canonical | Why |
|---|---|---|
| 0983 / 0971 / 0972 / 0970 / 0980 / 0987 / 0986 / 0976 / 0977 | 0478 / 0620 / 0625 / 0610 / 0580 / 0455 / 0450 / 0460 / 0470 | IGCSE 9-1 graded equivalents (same content) |
| 0973 / 0974 | 0653 / 0654 | 9-1 graded Combined / Coordinated Sciences |
| 9608 / 9389 | 9618 / 9489 | Superseded A-Level codes (CS / History) |

**New subjects:** `Combined_Science_0653` and `Coordinated_Sciences_0654`
(plus 9-1 aliases 0973/0974) — official syllabus structure with majors
`Biology` / `Chemistry` / `Physics` and 39 detailed topics each, keywords
reused from the single-science taxonomies. MCQ formats: 0653 Paper 1,
0654 Papers 1+2. Level inference fixed so 09xx codes are IGCSE (not A-Level).
Aliases are data-driven: add any pair to `CODE_ALIASES` in
`core/config_loader.py` and the whole pipeline picks it up.

## Automatic classification and missing-MS safety

The production CLI enables automatic **classification** by default. It may
select the best configured topic when a valid QP/MS pair has weak or ambiguous
classification evidence. It does **not** relax evidence required for output
artifacts:

- A structured question needs a usable mark-scheme WebP. If its MS is absent
  or the locked splitter declines it, the genuine QP crop and canonical
  metadata are retained under `review_required/review_required_no_ms`; no
  fabricated MS image or text placeholder is written.
- A known MCQ component may use its explicitly permitted `*_MS.txt` answer-grid
  sidecar (`A`–`D`, or the existing MCQ-unavailable state). No other text file
  is a question-folder delivery artifact.
- A bundle with no QP remains `review_required/missing_qp`, because the system
  cannot create a question-paper crop or safely invent one. Supply the QP or
  use `--fetch-missing-qp`.

Use the explicit alias when scripting automatic classification:

```bash
python run_pipeline.py --input papers --output output --trust-self
# equivalent guarded runner:
python run_guarded.py --input papers --output output --trust-self
```

Pass `--no-full-auto` to also route ambiguous/no-evidence classification to
review instead of selecting an automatic best-fit topic.

## Incremental bundle updates

The batch runner tracks QP/MS/ER input fingerprints in SQLite and
`.pipeline_state.json`. Re-running after a new MS is pasted beside an existing
QP requeues only that changed bundle; unchanged complete bundles remain
resume-skipped. Refreshed outputs replace the old snapshot transactionally and
stale question folders from the previous snapshot are removed.

Classifier decisions are written to the run-level hidden audit area
`output/.classification_audit/*.jsonl`. This contains confidence, evidence,
fallback source, and score details. It is intentionally outside question
folders, and `metadata.json` remains the strict canonical 11-field schema with
no audit or classifier fields added.

## Evidence-based classification memory

Classification memory is a separate, versioned SQLite store — never a field in
`metadata.json`, never a scan of existing question folders, and never a second
duplicate detector. The existing variant-scoped duplicate system remains
separate. Each query retrieves a small subject-local candidate set through the
indexed `(subject, token)` inverted index, rather than loading a JSONL archive
or all prior questions.

The evidence hierarchy is deliberate:

1. current whole-question wording and all subparts, assessed marks, command
   words, calculations/data/diagram signals, and the official configured
   taxonomy establish eligibility;
2. substantive mark-scheme text read **read-only from the original MS PDF** can
   strengthen a weak current-QP signal (the locked MS cropper's placeholder
   text is ignored);
3. selectively retrieved memory can make a bounded, auditable tie-breaking
   contribution only to an already eligible current topic. Negative memory can
   trim ranking evidence but cannot erase direct eligibility.

Records have one of four explicit trust types: `verified` (human-reviewed),
`high_confidence` (minimum confidence 0.90), `correction` (positive correction
plus rejected topics), or `negative` (known irrelevant association). Reviewed
similar-question links are stored separately. Records retain classifier,
taxonomy, syllabus, and memory versions. A changed taxonomy/syllabus version
is not silently reused at runtime; use `stale_records(...)` to inventory it
for a deliberate human review/reclassification.

Create a label template and fill only `expected_topic` with an exact canonical
identifier after human verification:

```bash
python tools/build_label_template.py \
  --output-root output \
  --csv topic_accuracy_labels.csv

python tools/build_classification_examples.py \
  --output-root output \
  --labels topic_accuracy_labels_filled.csv \
  --memory-db memory/classification_memory.sqlite3
```

The historically named import tool now writes indexed SQLite `verified`
records; the classifier no longer reads `classification_examples.jsonl`. An
old JSONL file can be migrated explicitly (and is not modified):

```bash
python tools/build_classification_examples.py \
  --migrate-legacy subjects/A-Level/Business_9609/classification_examples.jsonl \
  --legacy-subject Business_9609 --legacy-level A-Level \
  --memory-db memory/classification_memory.sqlite3
```

For production runs, an existing store is used as supporting evidence with:

```bash
python run_guarded.py --input papers --output output \
  --classification-memory memory/classification_memory.sqlite3
```

Automatic high-confidence writes are off by default to avoid self-training
feedback. If explicitly enabled, candidates are buffered in memory and are
committed only after the entire paper completes cleanly:

```bash
python run_guarded.py --input papers --output output \
  --classification-memory memory/classification_memory.sqlite3 \
  --write-high-confidence-memory \
  --memory-high-confidence-threshold 0.95
```

Use the `ClassificationMemory.record_correction`, `.record_negative`, and
`.record_similar_question_relation` APIs — or the human-controlled JSON CLI —
for reviewed feedback. The `stale` command only exports a review inventory; it
never reclassifies records automatically:

```bash
python tools/manage_classification_memory.py --db memory/classification_memory.sqlite3 \
  add --records reviewed_records.json
python tools/manage_classification_memory.py --db memory/classification_memory.sqlite3 \
  stale --subject Business_9609 --taxonomy-version 9609-2023-2025-official-profile/4 \
  --syllabus-version <official-syllabus-sha256> --out records_for_review.json
```

Store concise observable facts (for example, an assessed concept or source
reference), not private reasoning. Classification evidence and memory-match
summaries appear only in `output/.classification_audit/*.jsonl`; the canonical
question `metadata.json` schema and values remain unchanged.

`subjects/A-Level/Business_9609/2024/` is an explicit official 2023–2025
syllabus profile for 2024 papers. It preserves existing major-folder routing
identifiers while using official detailed-topic headings/equivalents and
Paper 1/2 AS-level scope. Its vocabulary provenance records the official
Cambridge source hash.

## Styled progress display

The batch runner uses a shared progress UI with a colored bar, percentage,
throughput, elapsed time, and live `OK`, `FAIL`, `REVIEW`, and `LAST bundle`
status text. It works in both sequential low-RAM mode and parallel mode. Set
`EXAMVOID_COLOR=never` or `NO_COLOR=1` for plain output; `run.bat` enables the
colorful console presentation automatically.
