# Cropping System Lock

The question-paper and mark-scheme crop/extraction/rendering code is read-only.
Topic classification, JSON metadata, folder routing, and validation must only consume
its output and must not change its behavior.

## Baseline verification

These SHA-256 values were verified against the originally downloaded project archive
`workspace-019fe775-86df-7d2b-ab07-2899f1093d24.zip`. Each current file is byte-for-byte
identical to that baseline.

| Locked file | SHA-256 |
|---|---|
| `core/cropping_engine.py` | `6a7ae3bb65012176cd6095d021e671418d9814986d15a63108367562073a9a01` |
| `core/cropping_engine_reference.py` | `9b88d3effa522e618fd631b44056602cc533aa5f151faef2cdd56999b0ba5c32` |
| `core/ms_cropping_engine.py` | `2f4c7aee5239cc99018a3fca9becaed1ccb5f9dc895e1d1be2463b9bdd006583` |
| `core/ms_crop_gold.py` | `8a55e3dbc790c4850cce44e3b324705a5652741ed8462f4794ebe3fa433641d6` |
| `core/question_split.py` | `2f8721d097f9302c3e13aa2ddda8c5d762e63d2a4195114b7198d1d9eb9f83ee` |
| `core/multipage_optimizer.py` | `17276c801666b72971fdae8aa2844d2e0feb5e2b2a75de5bdc052af01fb584ca` |
| `core/multipage_optimizer_reference.py` | `17276c801666b72971fdae8aa2844d2e0feb5e2b2a75de5bdc052af01fb584ca` |
| `core/mcq_support.py` | `76582bf541d1ef10cf3b5c4168338a66d0ed3feb5be84aaf71221f5a0c942d72` |
| `core/webp_utils.py` | `770e3ba06fb86517250c19ec6cfc620ae70eca8a147f7d559cb767210e1e4994` |
| `core/pdf_io.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` |
| `core/pdf_io_gold.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` |
| `core/markscheme_split_gold.py` | `a3213e2fe574c81b5a4a5c051638173816000c170d8fc80f733daaa251a02087` |

## Immutable behavior

Do not modify crop boundaries, dimensions, padding, page/question detection, QP/MS
cropping, multi-page assembly, image processing, WebP output, or crop quality. The
routing layer may call these components and route their already-generated outputs only.

## Amendment 1 (2026-08-10): Anti top-clipping fix — authorised by the maintainer

The maintainer explicitly ordered a fix for top-clipped question crops
("full question text always preserved; slight extra whitespace acceptable; text
clipping never acceptable; no blind hardcoded pixel padding; proportional or
validation-based adjustments"). The following controlled changes were made to the
QP cropping path only (MS path byte-identical, untouched):

- `question_split.adaptive_crop_page` (all three copies: `core/question_split.py`,
  `core/cropping_engine_reference.py`, `original_reference/cambridge_qb/question_split.py`):
  - REPLACED the blind fixed page-top constants (`QP_SAFE_TOP_PDF = 55.0`, and legacy
    `top_pdf - 5px` in the mirrors) with:
    1. structural header-junk recognition (page number = digits-only, centred,
       >= 9pt, vertically alone in the top band; `* 00008... *` barcode; running-header
       boilerplate) -> `header_floor` + `junk_boxes`;
    2. content-top detection with NO artificial y-floor (text spans + vector drawings),
       so question content starting high on the page is never destroyed;
    3. a proportional margin `0.45 * median body font size`, clamped [3, 16] pt,
       converted through the page's own render scale (adapts to layout and DPI);
    4. a raster validation pass (`_validate_top_against_ink`) that pulls the boundary
       UP over any unexpected non-junk ink (only ever adds whitespace, never clips);
    5. white-out of recognised junk boxes that survive inside the kept region
       (recognition is conservative; real content is never erased — same precedent as
       the existing watermark/imposition scrubbing).
  - `build_question_segments`: shared-page fallback split and prior-question `y0` now
    use this per-page proportional guard (`PageCropInfo.top_guard_px`) instead of the
    tight fixed 5 px.
- `multipage_optimizer.find_content_bbox` (all three copies): validation-based top
  extension absorbs faint anti-aliased rows just above the detected content top,
  bounded to one padding band (24 px). Purely additive.
- `core/cropping_engine.py`: docstring/comment updates only (no behavior change).
- Locked-output guarantees retained: final width EXACTLY 2280 px (LANCZOS, aspect
  preserved), bottom/left/right crop logic unchanged, marker detection unchanged,
  whitespace-cut algorithm unchanged, WebP output unchanged, MS cropping untouched.

Verified on the regression pack in `test-crops/fix-repro/` (7709/9709 real pages +
adversarial synthetic with content above the old 55pt cliff): zero clipping,
page numbers still excluded, outputs remain 2280-px-wide `.webp`.

### Updated baseline SHA-256

| Locked file | SHA-256 |
|---|---|
| `core/cropping_engine.py` | `01576fde63cfb005e7c71672842b1453392a5f51e7dc7dc846fa385e2c16b2a0` |
| `core/cropping_engine_reference.py` | `17e8917c759d100c498a8c5b191808d6ef61c3e8009330794af562fb49132924` |
| `core/ms_cropping_engine.py` | `9a1dc1e828f1e45e16686a8f8fcd0aaccd1dc543d68ca93468fe01832610d760` (unchanged by this amendment; already drifted from the original lock baseline before it) |
| `core/ms_crop_gold.py` | `8a55e3dbc790c4850cce44e3b324705a5652741ed8462f4794ebe3fa433641d6` (unchanged) |
| `core/question_split.py` | `17e8917c759d100c498a8c5b191808d6ef61c3e8009330794af562fb49132924` |
| `core/multipage_optimizer.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` |
| `core/multipage_optimizer_reference.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` |
| `core/mcq_support.py` | `76582bf541d1ef10cf3b5c4168338a66d0ed3feb5be84aaf71221f5a0c942d72` (unchanged) |
| `core/webp_utils.py` | `770e3ba06fb86517250c19ec6cfc620ae70eca8a147f7d559cb767210e1e4994` (unchanged) |
| `core/pdf_io.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` (unchanged) |
| `core/pdf_io_gold.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` (unchanged) |
| `core/markscheme_split_gold.py` | `a3213e2fe574c81b5a4a5c051638173816000c170d8fc80f733daaa251a02087` (unchanged) |

Also kept in sync (not locked, same fixed content): `original_reference/cambridge_qb/question_split.py`
(= `core/question_split.py`) and `original_reference/cambridge_qb/multipage_optimizer.py`
(= `core/multipage_optimizer.py`).

## Amendment 2 (2026-08-10): QP top boundary = 20px above detected question line

Maintainer instruction (QP CROPPING TEST - 20px above question + visual feedback loop):
for **every QP crop**, the top boundary begins **exactly 20 pixels above the detected
question line**. Only the QP top-boundary calculation changed.

- `question_split.build_question_segments`: the shared-page/continuation split and the
  per-question start-page top now use `cut / y0 = complete_first_line_top_px - 20`
  (`QUESTION_TOP_GUARD_PX = 20`).
- New `_question_first_line_top_pdf()`: "detected question line" = COMPLETE first line —
  walks upward from the marker through overlapping/adjoining text lines so fraction
  numerators / superscripts rising above the bare question number are preserved
  (e.g. 9709 s22 Q4: marker '4' at 72.19pt, true line top 62.65pt), then the fixed
  20px whitespace band is measured above that complete line top. The previous
  whitespace-band search for shared-page splits was superseded by this fixed rule.
- `adaptive_crop_page`: page-level structural/raster-validated anti-clip machinery
  (Amendment 1) retained; page guard floored at 24px so the 20px band always exists.
- Kept intact: 2280px exact width, horizontal alignment, marker/question detection,
  bottom boundary (mirror of the shared cut), multi-page handling & assembly,
  WebP output, question naming, and all other behavior. Untouched: MS cropping,
  Examiner Report cropping, JSON, folder structure, naming, classification.

Verification protocol (per maintainer): small visual test batch on a Biology paper,
images shown for approval BEFORE any full-paper processing; adjust 20px value only
on feedback.

### Amendment 2 refinements (2026-08-10), via maintainer's visual feedback loop

Maintainer verdict on the first visual batch was **B (adjust)**, then **A (approve)**
on the adjusted batch. The approved final state adds:

- **Junction-junk robustness fixes** (landed while preparing the visual batch):
  horizontal end-cap margin rules classified as junk alongside vertical margin rules;
  the off-page fill drawing `(0,-9.9,21,854.6)` now joins `junk_boxes` (clamped) so the
  raster validation pass masks it (root cause of a `top=0` clamp); junk paint pad
  raised to `max(4, round(2.5*scale_y))` to cover stroke spread (fixed "═" ghost lines).
  Detection-regression verified: Bio hf=51.02/ct=64.08/junk=10 per page;
  Math 62.65/86.48 — unchanged.
- **Visible-band anchor `_align_top_white_band_final()`** (applied in
  `crop_page_segments` after assembly, QP path only): because assembly re-trims
  sections to ink+24px and rescales ×2280/w, the render-scale 20px pre-cut drifted to
  ~24px *visible* white. The anchor measures the actual final 2280px image and
  trims/pads the top to exactly **20 rows of visible white above the first ink**
  (removes only rows verified all-white; never clips; pads if ever short). Width,
  bottoms, seams untouched — instrumented proof: everything below the band
  pixel-identical after anchoring.
- Unit tests 9/9 for the anchor; full-paper validation 6/6 questions of
  9700_w25_qp_22: width 2280 exact, band 20px at both ink thresholds (250/2px and
  QC's 246/3px), seam gaps clean, QC OK.

### Amendment 2 SHA-256 (changed files only; final approved state)

| Locked file | SHA-256 |
|---|---|
| `core/question_split.py` | `5c5c7a2bda2f23d74151df86e467e9d2d82b1733dedae73027f6cedf9f847837` |
| `core/cropping_engine_reference.py` | `5c5c7a2bda2f23d74151df86e467e9d2d82b1733dedae73027f6cedf9f847837` |

All other locked hashes from Amendment 1 remain valid (`core/multipage_optimizer.py` =
`c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5`, unchanged).
`original_reference/cambridge_qb/question_split.py` kept byte-identical to
`core/question_split.py`.

## Amendment 3 (2026-08-10): QP-fix audit trio — verified/aligned — authorised by the maintainer

The maintainer supplied the previous audit's QP fix (three parts) as locked. Conflict
mapping against the current locked state:

1. **`converter.py` — 300 DPI render at all times.** ALREADY SATISFIED and locked:
   `render_pdf_local` renders at fixed 2480×3508 geometry (= 300.0 DPI for A4 at
   595.3×841.9pt; `Matrix(scale, scale)` with `scale = max(2480/w, 3508/h)`), never
   below 300 DPI. The "72 DPI default" the audit cites predates this tree. No change.
2. **`question_split.py` — proportional guard + raster top validation.** SATISFIED and
   SUPERSEDED by something stronger: the proportional page-level machinery from
   Amendment 1 (structural header-junk recognition, `0.45 × median font` guard,
   `_validate_top_against_ink`) is retained, and per-question tops were replaced by the
   maintainer-approved fixed **20px visible band** (Amendment 2, verdict B→A: complete
   first line + raster-exact anchor at final 2280px scale). Reverting to the audit's
   literal `clamp(0.45 × median_line_height_px, 18, 60)` formula would regress the
   approved 20px rule, so no rollback is applied.
3. **`core/webp_utils.py` — compression strength.** ALIGNED: `save_webp` defaults raised
   quality 88 → **92**, method 2 → **4** (both save sites; the audit's "80" baseline
   never existed in this tree — it was already 88). Measured on a real assembled
   question (2280×5365, thin numeral glyph): 88/m2 lost thin-stroke ink (99.5% glyph
   retention) and deviated MAE 0.228 from lossless; **92/m4 retains 100.0% glyph ink,
   MAE 0.160**, +12% size, ~2× encode time. Note: the production pipeline's final question
   crops were already written ABOVE the audit target — `core/output_manager.OutputManager`
   (used by `main.py`) saves at quality=95, method=6; `original_reference/cambridge_qb`
   remains archive-pristine (its sibling already had method=4, keeps quality=88).

### Amendment 3 SHA-256 (changed files only)

| Locked file | SHA-256 |
|---|---|
| `core/webp_utils.py` | `4677261fdbdaf879b1b61c484ce0f4b2218b0ef54e584c350361eedd7ba6fa64` |

## Amendment 4 (2026-08-10): Imposition-mark scrub content guards — authorised by the maintainer

Root cause of the "MS label erasure" defect: `_scrub_imposition_marks` in
`core/webp_utils.py` (NOT the MS engine margins, which are gold/locked) was erasing
real markscheme ink — its barcode/comb heuristics matched table digits and label
columns on 9700 m25/w25 MS rasters.

Guards added:

1. **`_band_is_barcode`** — a candidate vertical band must pass all three tests
   before erasure: full-height dark-column coverage ≥ 60%, inter-bar gap CV ≤ 0.25,
   and ±8px white isolation on both sides.
2. **P2 restricted to comb-group erasure** — only groups of ≥ 8 tall periodic bars
   are erased; isolated specks and digit-like marks are kept by design (better a
   speck survives than a mark point is erased).

Evidence (ink wrongly targeted, real papers): m25@75dpi 16,657 → 0, w25@75dpi
24,246 → 0, m25@150dpi 39,230 → 0 dark pixels. Synthetic comb strips are still
erased (no regression). Suite: `test-crops/scrub-fix/test_scrub_guard.py` 9/9,
evidence pack `test-crops/scrub-fix/MS_scrubguard_dpi150_evidence_pack.html`.

### Amendment 4 SHA-256 (changed files only)

| Locked file | SHA-256 |
|---|---|
| `core/webp_utils.py` | `f865edff4e642a0b5ce983708f75ad8e38f7c2a03a0784f59742414ce258d723` |

## Amendment 5 (2026-08-10): QP frame side trim 45pt → 35pt (side air) — authorised by the maintainer

Maintainer directive "2 QP Crop Fixes", Fix 1 (≈ +40px whitespace per side). The
audit premise was fact-checked and found fabricated: there is NO `LEFT_MARGIN_PX` /
`RIGHT_MARGIN_PX` / `PAGE_WIDTH_PX` / `HEADER_ZONE_PX` / `FOOTER_ZONE_PX` /
`build_question_crop()` / `stitch_strips()` / `enforce_2280_width()` anywhere in
this codebase, and `CONTENT_PADDING_LR` in the multipage pair is a clamp CEILING
only (byte-identical output at 100 vs 140 — proven no-op for this path). The real
side-air knob is the page-frame trim in `adaptive_crop_page` (triplet).

Change (triplet only):

1. New constant **`PAGE_SIDE_TRIM_PT = 35.0`** in `core/question_split.py`
   (previously inline 45.0), used for both page sides; explanatory comment warns
   future auditors off the nonexistent constants.
2. **Sliver-paint**: the newly-kept [35pt, 45pt] band per side is whitened after the
   frame crop. On real 9700 m25 pages this band contains ONLY the printer's corner
   registration marks (identical every page, both sides); question ink starts
   ≥ ~50pt, so no content is touched. Verified: final outer 40px contain 0 dark
   pixels on 12/12 crops (m25 + w25).

Fix 2 (continuation-banner stripper) was SKIPPED as a verified no-op: Cambridge
structured QPs print no "Question N continues…" banners; `find_question_bottom_pdf`
already excludes footer furniture (© / Turn over / DO NOT WRITE, bbox < 94% page
height); the proposed banner regexes were a clip-risk on real question text.

Evidence: air +41/+42px per side on 12/12 crops (m25 v3 + w25); locked 20px top
band (engine metric) 12/12; width exactly 2280 12/12; ink-mass ratio inside the
geometric window [s²·0.995, s·1.005], s = 505/525 (content drawn 4% smaller in the
wider window; nothing clipped by construction); suites `test-crops/pad140/
test_pad140.py` 36/36 and `test-crops/pad140/w25_spot.py` 31/31; full regression
battery green (ER 56, extractor 32, classifier 21, routing 17, anchor 9, scrub 9,
boundary-shadow 8/8); m25 full-pipeline v3 run: validator 0 issues / 55 files.
Packs: `test-crops/pad140/AMENDMENT5_side_air_evidence_pack.html`,
`test-crops/m25-proof-v3/M25_V3_TEST_RUN_pack.html`.

### Amendment 5 SHA-256

| Locked file | SHA-256 |
|---|---|
| `core/question_split.py` | `00cc779ed631bdfc44c7ec537c7e5c7d255479d15f011680fdc1eda1d78b87c1` |
| `core/cropping_engine_reference.py` | `00cc779ed631bdfc44c7ec537c7e5c7d255479d15f011680fdc1eda1d78b87c1` (byte-identical triplet) |
| `original_reference/cambridge_qb/question_split.py` | `00cc779ed631bdfc44c7ec537c7e5c7d255479d15f011680fdc1eda1d78b87c1` (byte-identical triplet) |
| `core/multipage_optimizer.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` (unchanged) |
| `core/multipage_optimizer_reference.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` (unchanged) |


## Findings note (2026-08-10, no code change — documentation only)

**Upgrade 3 (reference-detector question-signal veto) — verified already
satisfied.** `core/chemistry_reference.py::classify_page` runs the question
structure veto BEFORE every reference detector; the only earlier exits are the
structural blank/candidate-info checks, and moving the veto above them is
PROVABLY harmful (real cover pages trip the veto via boilerplate: "1 hour 15
minutes" leading-number + "show" command word — A/B evidence on 9700 m25/w25
QPs in `test-crops/refdet-upgrade3/`; file restored byte-pristine, sha
`193820b9…` == packaged copy). Do not re-attempt that reorder.

## Amendment 6 (2026-08-10) — QP page-render scratch ownership + tempdir leak fix (Efficiency U2)

The locked triplet (`question_split.py:1230`) renders pages into
`tempfile.mkdtemp("qp_pages_*")` and never deletes it (no `rmtree` in file) —
an orphan tempdir of page webps per QP paper, forever (reproduced on a real
9700 m25 slice: 6 webps / 1517 KB per run). The triplet stays byte-untouched;
the caller now owns the scratch dir.

Change (behavior-neutral): `core/cropping_engine.py` passes an owned
`webp_dir` (RAM-backed `/dev/shm` when writable, system temp otherwise;
"ramdisk=yes/no" logged) to `split_questions(..., webp_dir=...)` and removes
it in a `finally`. Crops byte-identical pre/post (sha `a6a284304c876acb` on
the test slice; zero leaked dirs after). DPI, webp quality/method, all crop
logic untouched.

| File | sha256 |
|---|---|
| `core/cropping_engine.py` | `c0344ddb3bb01841c8c7b5a4cbb222431b981710d1f203181fba45b4bd38c2dc` (was `01576fde…`) |

## Amendment 7 (2026-08-11): Confidence-gate defect fixes (Overseer spec) — authorised by the maintainer

Approved decisions: wrap architecture (locked gold stays the production cropper;
new packages orchestrate around it), fix-bundle yes, year policy = loud flag.

1. **core/cropping_engine.py** — defect 5 (dummy fabrication) eliminated:
   `HAS_FITZ` false, gold-import failure and gold exception paths no longer
   fabricate `Question {i} dummy text` crops; they return zero crops with
   `self.last_error` set and a loud ❌ line. `_dummy_process` /
   `_fallback_process` deleted outright. Defect 4: gold QC verdicts are no
   longer dropped at the adapter — `CroppedQuestion` gains `needs_review` +
   `qc_reasons` (from the gold `Question`), and the engine exposes
   `last_confident` (+ low-confidence ⚠️ print). Defect 3 comments corrected
   to the audited truth (gold `crop_page_segments` stitches ALL segments; the
   adapter receives one fully-stitched image — approved artifact proof:
   2280x12422 4-page Q1) plus a defensive locked-`assemble_multipage_question`
   branch if a future gold ever returns >1 segment.
2. **core/ms_cropping_engine.py** — FIRST amendment of this engine. The
   "using dummy" log line lied (the engine always returned `[]`); print made
   honest + loud ❌; dead (never-called) `_dummy_process` fabrication code
   deleted. Its exceptions were and are fail-closed (traceback + `[]`).

Bounds honoured: question_split triplet `00cc779e…` ×3, multipage pair
`c384248b…`, converter `d8bf74d8…`, webp_utils `f865edff…`, all gold modules —
byte-untouched. No crop-geometry, DPI, quality or naming change.

Evidence: grep DUMMY-FREE across engines+runners; unit suite 14/14
(`tests/test_confidence_gate_fixes.py`: fail-closed on gold-unavailable /
fitz-unavailable / forced-gold-exception; QC propagation; honest prints);
real-paper guarded run (9700 m25+w25+er, --low-ram): 8 stages ALL GREEN,
both papers state=complete; 33/33 surviving RS-2 baseline webps
byte-identical; m25 Q1/Q2/Q4 folders (absent from the eroded reference tree)
restored and dims match the in-run assembly ledger exactly
(Q1 2280x11526, Q2 2280x8425, Q4 2280x11503). Log:
test-crops/redesign/defectfix_run.log.

| File | sha256 |
|---|---|
| `core/cropping_engine.py` | `b58110d3fc32666605274492b59e8ac9c928e9613c849f7e08dfe875f457aded` (was `c0344ddb…`) |
| `core/ms_cropping_engine.py` | `e87043e9eab533da004ad05cf12b7fefbb768bd82e76d7d6fded6fdf6205bc9a` (was `9a1dc1e8…`; first amendment) |
## Amendment 8 (2026-08-11): IGCSE paper-format round — MCQ answer-grid extraction + detection fast-path — authorised by the maintainer

Overseer IGCSE-format spec; approved decision set: prod_homes / rename /
advisory counts / letters. Spec-premise receipts recorded in
`test-crops/redesign/IGCSE_FORMATS_ROUND_EVIDENCE.md` (spec's `markscheme.py` /
`mcq_detector.py` filenames do not exist — real homes: locked
`markscheme_gold.py` / this module).

1. **core/ms_cropping_engine.py** — SECOND amendment of this engine: gains
   `extract_mcq_answers(pdf_path)`, a THIN ADAPTER delegating parsing to the
   LOCKED gold `core/markscheme_gold._parse_mcq_answers` over
   `core/pdf_io.render_pdf_with_rotation_info` — exactly the call pattern gold
   `process_mark_schemes()` itself uses for MCQ papers. No new parsing logic.
   Fail-closed: gold engine unavailable / exception → empty dict + loud ❌.
   No crop geometry, boundary, DPI, quality or naming change anywhere; the
   structured MS path is byte-identical in behavior.
2. **core/mcq_support.py** — gains `MCQPaperInfo` + `detect_mcq()`:
   `paper_meta` fast-path (`confirmed_by=["paper_meta_profile"]`), identifier
   profile fallback, unresolved identity fail-closed (not-MCQ). All prior
   detectors untouched.

Evidence: real grids 0620_s16_ms_21/22 and 9701_s15_ms_12 parse exactly 40
letters each; MCQ end-to-end 0620_s16 P22 (`--low-ram`): worker 348 checks +
full run 21 checks ALL GREEN, S8 audit errors=0; A-Level regression 9700_m25
P22: 6/6 overlapping webps byte-identical to the RS-2 baseline manifest;
suite 24/24 (`tests/test_igcse_formats.py` new: 10 tests, incl. the spec's
exact 17/17 truth table). Bounds honoured: triplet `00cc779e…` ×3, multipage
pair `c384248b…`, all gold modules byte-untouched.

| File | sha256 |
|---|---|
| `core/ms_cropping_engine.py` | `b69285eee913829874d5138ab933cb7ac534e340a01fcb0f312d045b2317125c` (was `e87043e9…`) |
| `core/mcq_support.py` | `d35afbc13b7213c922e2ebf48276c902acf17de24d391e8caa50ddf118cd5e9e` (was `76582bf5…`) |
## CROPPING-NOTE (2026-08-11) — RS-12 import-block-only amendment — authorised by the maintainer

`core/cropping_engine.py` was amended by the RS-12 page-classifier round in
its IMPORT BLOCK ONLY (sys.modules pre-seed binding the gold package's page
classifier to the maintained core copy). **No crop mathematics, no boundary
logic, no render DPI, no webp settings were touched**; the question_split
triplet `00cc779e…` remains the sole crop authority and is byte-untouched.
The amended file's hash is recorded in ROUTING_STATE_LOCK RS-12 (this note
carries no hash rows by design).

## Amendment 9 (2026-08-13): Continuation-page barcode / watermark / header scrub — authorised by the maintainer

**Reported defect:** multipage question crops show the printed barcode (and
third-party watermarks / paper-code strips) in the top-right corner — the
junk printed at the top of EVERY Cambridge page leaked into continuation
pages, which are stitched into the crop from y=0 of the page image.

**Root cause (audited):** `_analyse_page_top` only recognised junk that is
(a) legacy text barcodes (`* 00008 *`), (b) page numbers, (c) margin rules.
Modern barcodes are VECTOR BAR ART (never classified, so treated as content),
and mirror-site watermarks (`www.dynamicpapers.com`, ...), barcode strip text
(`This document has N pages`, `DC (LK) ...`) and the printed paper code
(`9701/21/M/J/24`) were unrecognised — they became "content", were never
junk-painted, and survived into continuation-page sections.

**Fix (QP cropping path only; all three triplet copies byte-identical):**
1. `_classify_header_span` gains three top-band junk classes:
   `barcodetext` ("this document has", "blank pages are indicated", "DC ("),
   `watermark` (www.* + known redistributor domains), `papercode`
   (`\d{4}/\d{2}/.../\d{2}`).
2. `_analyse_page_top` gains vector barcode-ART detection: a cluster of >= 8
   narrow (< 4.5 pt) tall (> 8 pt) height-aligned bars in the top band is a
   barcode block -> junk box; those bars no longer count as content.
3. `adaptive_crop_page` gains a raster fallback (`_find_raster_barcode_boxes`)
   for scanned papers with no text/vector layer: >= 8 tall (>= 18 px)
   contiguous dark runs per column, narrow (<= 8 px), gaps <= 10 px -> a
   barcode; painted with the same content-top clip as structural junk
   (dotted answer lines / tables verified non-matching).

**Verification:**
- Synthetic barcode page (vector art + `* NNN *` + "This document has" +
  "DC (" + watermark + paper code + page number): all 7 boxes detected,
  top-right corner of the crop is pure white, content preserved.
- Raster-only scanned-page simulation: pixel barcode detected and painted;
  negative control (short dashes) does not fire.
- Real 2015 paper with `www.dynamicpapers.com` on every page: the 171px
  top-band junk strip is removed from multipage crops; aligned continuation
  sections are BYTE-IDENTICAL otherwise (removed=0, added=0 ink).
- Real 2024 paper (clean official PDF): crops byte-identical to pre-fix.
- Full test suite: 153 passed / 1 pre-existing env failure (unchanged).

| `core/question_split.py` | `2d96cc167d1c34c99261a109929ea6788212c9e22fb2110d8ca8889290db5e0b` | (was `…`) |
| `core/cropping_engine_reference.py` | `2d96cc167d1c34c99261a109929ea6788212c9e22fb2110d8ca8889290db5e0b` | (was `…`) |
| `original_reference/cambridge_qb/question_split.py` | `2d96cc167d1c34c99261a109929ea6788212c9e22fb2110d8ca8889290db5e0b` | (was `…`) |

## Amendment 10 (2026-08-13): In-memory page rendering + raster-scan gating — authorised by the maintainer

**Motivation (profiled, not guessed):** per-paper crop pass was 10.4s, of
which 5.0s (~50%) was `WebPEncode` of the INTERMEDIATE full-page renders
(quality=90, method=1) that the splitter writes to webp_dir and immediately
reloads. That round-trip is pure cost AND a lossy intermediate.

**Changes (QP path only; triplet byte-identical):**
1. `core/converter.py` adds `render_pdf_to_memory()` — same scale math and
   final 2480x3508 resize as `render_pdf_local`, but returns PIL images
   directly (no WebP save/load). Crops are marginally sharper (no lossy
   intermediate) — accuracy-neutral-to-better.
2. `split_questions()` gains an optional `pre_rendered` param; when provided
   it skips the webp_dir render path entirely. `None` (default) keeps the
   legacy path byte-identical for every other caller.
3. `CroppingEngine.process_paper` renders in memory and passes it; any
   render failure falls back to `pre_rendered=None` so mocked/fail-closed
   callers behave exactly as before.
4. Raster barcode fallback (`_find_raster_barcode_boxes`) now runs ONLY when
   the structural scan found no junk boxes (text-layer pages are caught
   structurally; scanned pages have empty junk -> scan still runs).

**Measured:** crop pass 10.4s -> 3.6s per paper (~65% faster); end-to-end
guarded run on 2 real QP+MS pairs 60s -> 28s (~53% faster); 43/43 questions
saved, S8 audit errors=0, all 30 crops 2280px with ink; barcode fallback
positive/negative controls pass; full test suite green (ledger rows below).

| `core/question_split.py` | `54848ae0a8305cab544e5c4c67d48d335996b75946067bad27c1e7f0d1dba2c4` | (was `…`) |
| `core/cropping_engine_reference.py` | `54848ae0a8305cab544e5c4c67d48d335996b75946067bad27c1e7f0d1dba2c4` | (was `…`) |
| `original_reference/cambridge_qb/question_split.py` | `54848ae0a8305cab544e5c4c67d48d335996b75946067bad27c1e7f0d1dba2c4` | (was `…`) |

## Amendment 11 (2026-08-14): Instruction-boilerplate junk — authorised by the maintainer

**Reported defect:** the standard Cambridge instruction block ("Answer all
the questions in the spaces provided.", "The number of marks is given in
brackets [ ]...") printed at the top of the first question page survives
into page-level crops (and could be pulled into a question's first line by
the walk-up on layouts where it adjoins Q1).

**Fix (QP cropping path only; triplet byte-identical):**
1. `_INSTRUCTION_SIGNS` — the standard instruction phrases, matched ONLY in
   the top band (y < 15% page height), so mid-page section headers
   ("Answer all the questions in this section") are never touched.
2. Span-split lines ("Answer" | "all" | "the questions in the spaces
   provided.") are matched at LINE level: every span of an instruction line
   is flagged junk, while all span bboxes stay byte-identical for every
   other line (verified: clean 2024 papers show zero pixel changes).

**Verified:**
- 2015 paper page-2 crop top 144px -> 247px (instruction block excluded);
  the fix changes ZERO assembled question crops (isolation test: signs ON
  vs OFF -> 0 diffs on all 4 questions).
- All 27+24 corpus 2024 papers: zero top-band instruction-sign lines -> no
  false-positive surface.
- Full suite: 167 passed (5 new tests), pre-existing env failure only.

| `core/question_split.py` | `7e9e56c4c98e9290cebd2b9e4275be3e60dd9ed13586907d71242d43e9dcd790` | (was `…`) |
| `core/cropping_engine_reference.py` | `7e9e56c4c98e9290cebd2b9e4275be3e60dd9ed13586907d71242d43e9dcd790` | (was `…`) |
| `original_reference/cambridge_qb/question_split.py` | `7e9e56c4c98e9290cebd2b9e4275be3e60dd9ed13586907d71242d43e9dcd790` | (was `…`) |

## Amendment 12 (2026-08-29): Formal Locking of Insert & Examiner Report Croppers — authorised by the maintainer

**Scope:** The cropping mechanisms across all examination components (Question Papers, Mark Schemes, Insert Booklets, and Examiner Reports) are now fully finalized and LOCKED.

**1. Locked Insert Cropping Engine (`core/insert_engine.py`):**
- Strict 2280px final width on all whole-page and section crops.
- Structural header-junk and top page number exclusion (`top_pt` strictly below isolated top page numbers and running slugs).
- Trailing copyright / permissions notice removal (`_BACKMATTER_SIGNALS` detects all Cambridge clearance disclaimers and stops above them).
- Section content bounding (`last_word_bottom + 14.0 pt`).
- Generalized bottom-whitespace auto-trimming via `_trim_bottom_whitespace(img, pad=24)` (24px safety pad).
- Cover and instruction page exclusion from output.

**2. Locked Examiner Report Cropping Engine (`core/er_question_crops.py`):**
- Visual WebP cropping at exactly 2280px width (`{qid}_ER.webp`).
- Strict component and question-number identity verification.
- Invariant guarantee: pure visual deliverable (no `.txt` files emitted into question folders).

**3. Immutable Behavior:**
All cropping engines (`core/cropping_engine.py`, `core/question_split.py`, `core/ms_cropping_engine.py`, `core/insert_engine.py`, `core/er_question_crops.py`) are strictly read-only. Do not alter crop boundaries, dimensions, padding, page/question detection, multi-page assembly, image processing, WebP output, or crop quality.

| Locked file | SHA-256 |
|---|---|
| `core/insert_engine.py` | `deabb38f698a046ccdafd48e5242bc4d99656791de3a415dcdf9a5fe94682df5` |
| `core/er_question_crops.py` | `b93ad5f2b4bb83a4f428671cb60a151900fa133ec2046692b828059cc5cc50b8` |

---

## Amendment 13 (2026-08-29) — narrowly authorised actual-image QP/ER boundary remediation

**Authority and scope.** This is the explicit, narrowly scoped exception to the
otherwise read-only crop lock: repair the actual generated-image boundaries for
the authentic **9708/21** May/June 2024 diagnostic only. It is not a general
cropper redesign, a CSS/HTML concealment change, or evidence for the requested
9708/22 component. MS, Insert, page rendering DPI, WebP quality, multipage
assembly, metadata schema, routing, duplicate handling, and all unrelated QP
and ER behavior remain locked.

**QP triplet — source-coordinate structural end delimiters.** All three
required copies remain byte-identical. The same production splitter now:

1. recognises only five high-specificity Cambridge permissions/disclosure
   signatures (not a generic word such as `copyright`), derives the first
   source-PDF back-matter boundary, and excludes both that administrative block
   and an immediately preceding full-width separator rule before rasterisation;
2. recognises a standalone, whole-line `Section B`/`Section C` heading as an
   end delimiter only where it lies inside an already-computed preceding
   question band; and
3. uses the resulting materialised bands for `extract_question_text`, so
   excluded administrative/next-section text cannot affect classification.

This corrects the observed Q5 permissions/footer leak and stops Q1 before the
following Section B in the **actual WebPs**. It deliberately leaves genuine
question text mentioning copyright and headings that introduce the current
question untouched.

**ER cropper — source-coordinate continuation tightening.** The ER cropper
now uses exact PDF line boxes only on continuation edges, preserves the
established question-header parser and normal one-page bands, clips a
standalone in-band section heading before rendering, and omits only a
header-only/tiny continuation tile after that source delimiter. This removes
9708/21 Q1's proven page-break/header fragment and excessive natural-layout
white gap from the actual `{qid}_ER.webp`, without changing ordinary ER Q2/Q4
crops.

**Measured production evidence (not /22 evidence).** The clean rebuilt archive
is `validation_evidence/economics_9708_s24_21/archive_2024_profile_full_ram/`.
Relative to the retained pre-change production-path baseline, QP Q5 changed
from 2280×2209 to **2280×296**, QP Q1 from 2280×4037 to **2280×3596**, ER Q1
from 2280×1758 to **2280×1516**, and ER Q3 from 2280×987 to **2280×812**. QP
Q2/Q4 and ER Q2/Q4 retained their exact baseline dimensions. Independent raster
measurement found Q1 ER's largest interior all-white run reduced from 153px to
60px; all final QP/MS/ER assets retain 2280px width. The generated proof shows
the actual regenerated assets without visual masking:
`validation_evidence/economics_9708_s24_21/proof_9708_21_diagnostic.html`.

**Verification.** Focused `tests/test_9708_crop_remediation.py` passed 6/6;
the full guarded `/21` run completed S1–S8 all green (worker 105 checks,
parent 41 checks); a separate archive validation reported `errors=0`.
`examiner_report.txt` remains deliberately absent from final question folders.

| Locked file | SHA-256 | Amendment 13 status |
|---|---|---|
| `core/question_split.py` | `c028daa518aca539814b774da3193d7075d21d865a4ddc49bc3ba8942c619af8` | authorised QP boundary logic; byte-identical triplet |
| `core/cropping_engine_reference.py` | `c028daa518aca539814b774da3193d7075d21d865a4ddc49bc3ba8942c619af8` | authorised QP boundary logic; byte-identical triplet |
| `original_reference/cambridge_qb/question_split.py` | `c028daa518aca539814b774da3193d7075d21d865a4ddc49bc3ba8942c619af8` | authorised QP boundary logic; byte-identical triplet |

---

## Amendment 14 (2026-08-29) — standalone external QP `OR` choice-separator boundary

**Authority and limit.** The maintainer expressly authorised the smallest
necessary underlying **QP** boundary correction: exclude only a standalone
`OR` choice/separator that lies outside the actual preceding question. This is
not HTML/CSS concealment, not a broad text deletion rule, and does not alter
MS, Insert, ER, rendering width/DPI/quality, output naming, routing, metadata,
or duplicate handling. ER was deliberately not changed by this amendment.

**Source-coordinate rule.** The byte-identical QP triplet adds
`_standalone_or_choice_boundary_pdf()`. It accepts a marker only when all of
the following are true in the source PDF: (1) the extracted line is exactly
`OR` (case-insensitive); (2) it is left-margin aligned; (3) it lies after the
current question start and before the immediately following detected top-level
question marker on the same page; and (4) that successor is within a
layout-adaptive short gap (at least 22pt, otherwise 8% of page height). The
current question’s source-coordinate end is moved to the marker’s top before
rasterisation and the same materialised segment is used for classification
text. A word `or` embedded in prose, a centred/table `OR`, an isolated marker
without a prompt successor, and ordinary content remain untouched.

**Fresh positive and cross-paper evidence.** The authentic Cambridge
Economics **9708/21 M/J 2024** QP has exactly two whole-line uppercase source
markers: after Q2 (page 3) and Q4 (page 4). The fresh production output has no
standalone `OR` line in Q2/Q4; its QP dimensions changed only as expected:
Q2 `2280×363 → 2280×260` and Q4 `2280×589 → 2280×486`. Q3 has no standalone
source marker and preserves its legitimate phrase “price elasticity of supply
or cross elasticity of demand”. The current archive is
`validation_evidence/economics_9708_s24_21/archive_2024_profile_full_ram/`;
its independent JSON/visual proof is
`validation_evidence/economics_9708_s24_21/{independent_diagnostic_audit.json,proof_9708_21_diagnostic.html}`.

The independent authentic Cambridge Accounting **9706/32 M/J 2023** full
QP+MS+ER+Insert run found no source standalone-QP/ER `OR` marker, retained
valid QP/MS/Insert artifacts for all three questions, and passed the structural
validator. Its cross-paper evidence is
`validation_evidence/accounting_9706_s23_32_or_crosspaper/{crosspaper_audit_9706_s23_32.json,proof_9706_s23_32_crosspaper.html}`.
That audit correctly records a **separate failure**: ER Q3 has a `1874px`
trailing/internal blank run (threshold `120px`). The Q3 ER WebP is byte
identical to the pre-OR Accounting proof output, so it was not introduced by
this QP-only amendment; it is not silently marked passed.

**Verification.** `pytest -q tests/test_9708_crop_remediation.py
 tests/test_economics_2024_profile.py -vv` passed 10/10, including positive,
centred, and distant `OR` geometry controls, actual /21 output boundaries, and
historical-profile routing. Fresh guarded `/21` and `/32` production runs both
reached S8 all green; their separate structural `--validate` checks report
`errors=0`. Quality acceptance for fresh /32 ER Q3 remains FAIL as stated
above.

| Locked file | SHA-256 | Amendment 14 status |
|---|---|---|
| `core/question_split.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | authorised QP OR-boundary logic; byte-identical triplet |
| `core/cropping_engine_reference.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | authorised QP OR-boundary logic; byte-identical triplet |
| `original_reference/cambridge_qb/question_split.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | authorised QP OR-boundary logic; byte-identical triplet |

---

## Amendment 15 (2026-08-29) — Accounting 9706/32 ER Q3 terminal-boundary repair and final freeze

### CROPPING STATUS: 🔒 LOCKED

**Effective immediately, every cropping mechanism is frozen.** This amendment
is the final, narrowly authorised exception that was needed to repair a proven
actual-image defect. It supersedes only the obsolete **Q3 FAIL** wording in
Amendment 14; all historical amendment records remain evidence of how the
current frozen state was reached.

### Actual defect, source investigation, and smallest repair

The authentic Cambridge Accounting **9706/32 M/J 2023** ER Q3 is a fresh-page
terminal question. It begins on scoped ER source page 18 (PDF y=60.529pt), is
the first detected question header on that page, and has no later question,
section, or back-matter delimiter. The old conservative final-question fallback
therefore ended near the generic 94.5%-of-page footer limit (795.690pt), even
though the final Q3 body line ends at 290.183pt. This was an underlying
source-boundary defect, not an HTML/CSS presentation issue.

The only runtime change is in `core/er_question_crops.py`. It may replace that
old terminal fallback with the final real body line plus the already-established
semantic padding **only** when every condition below holds:

1. the candidate is the final detected question with no explicit later
   question/section/back-matter delimiter;
2. it starts on the final component-scoped page and is the first detected
   question header on that page;
3. that final-page band contains at least one real body line; and
4. `_terminal_text_only_tail_is_safe()` proves the discarded source tail has
   neither a non-text image/block nor vector drawing/rule.

If any condition fails, the former conservative endpoint remains authoritative.
In particular, this deliberately does **not** affect a terminal question that
shares its source page with an earlier question. The authentic Economics
9708/21 ER Q5 is the regression control for that rule and remains exactly
`2280×1996`.

### Verified actual-output result

The retained pre-fix Q3 WebP was `2280×2826` with a `1874px` largest
interior/trailing all-white run. The regenerated real crop is
`2280×934`, SHA-256
`83468e7b9de0175a6dff5363334f7b10514db06d1a6d0c92e13dc97dcb94222d`,
with a `56px` longest interior blank run (the same compact padding measured
for Accounting ER Q1/Q2). Direct image review confirms Q3(a)–(e) through the
final sentence, “information in the question.”, with no extra terminal space.

The complete source-band test confirms the beginning, middle, and final Q3
commentary; excludes `Question 4`, standalone `OR`, `Section B`, copyright,
and `2023` footer text; and confirms a vector/table in a proposed discarded
tail vetoes the trim. The fixed non-masked Q3 asset and its before/after
investigation are recorded in:

- `validation_evidence/accounting_9706_s23_32_or_crosspaper/q3_terminal_fix_investigation.json`
- `validation_evidence/accounting_9706_s23_32_or_crosspaper/crosspaper_audit_9706_s23_32.json`
- `validation_evidence/accounting_9706_s23_32_or_crosspaper/proof_9706_s23_32_crosspaper.html`

The latter embeds the exact pre-fix and regenerated WebPs and reports zero
audit failures; it does not crop, mask, or replace images in HTML.

### Freeze-verification receipt

- Focused cross-paper suite:
  `pytest -q tests/test_9708_crop_remediation.py tests/test_economics_2024_profile.py -vv`
  → **12 passed**.
- Authentic Accounting 9706/32 full QP+MS+Insert+ER run: guarded pipeline
  **38 checks all green**; final archive validation `errors=0`. Q1–Q3 each
  retain actual QP, MS, Insert, and ER WebPs; Insert attachments map Source
  A/B/C to Q1/Q2/Q3.
- Authentic Economics 9708/21 full QP+MS+ER regression run: guarded pipeline
  **41 checks all green**; final archive validation `errors=0`. It verifies
  QP Q2/Q4 standalone-OR exclusion, preserves Q3's legitimate inline `or`,
  keeps QP Q5 free of the permissions/copyright tail, keeps QP/ER Q1 before
  Section B, and preserves ER Q5 at `2280×1996`.
- These are authentic **9708/21** controls only. No unavailable 9708/22
  source or evidence has been fabricated or substituted.

### Frozen specification and change-control rule

The following are now read-only as a single cropping system: QP, MS, ER, and
Insert crop/boundary logic; question/page/section detection; source and raster
coordinates; padding and whitespace trimming; copyright/footer and back-matter
exclusion; Section-B/C exclusion; standalone external-`OR` exclusion; page
boundary and multi-page assembly; render geometry/DPI; image processing; WebP
encoding; crop verification helpers; and their production-reference copies.

The source-coordinate QP `OR` rule remains protected exactly as Amendment 14
states: it excludes only a proven standalone separator marker and never a
legitimate inline `or`. **No future crop-related code change, refactor,
optimisation, replacement, tuning, or documentation-led behavior change may be
made without explicit user permission.** If a future crop issue is observed,
stop after collecting evidence and report the proposed scope; do not implement
it under this lock.

### Final crop lock ledger

| Locked file | SHA-256 | Final frozen role |
|---|---|---|
| `core/cropping_engine.py` | `b2123545fa3d4db75a8805d67d08779e9e7885a646272f3d4b1310c259fa8c94` | production QP crop adapter |
| `core/question_split.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | QP question/boundary authority, including narrow OR rule |
| `core/cropping_engine_reference.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | byte-identical QP reference peer |
| `original_reference/cambridge_qb/question_split.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | byte-identical production-imported QP peer |
| `core/ms_cropping_engine.py` | `b69285eee913829874d5138ab933cb7ac534e340a01fcb0f312d045b2317125c` | MS crop adapter |
| `core/ms_crop_gold.py` | `8a55e3dbc790c4850cce44e3b324705a5652741ed8462f4794ebe3fa433641d6` | MS crop authority |
| `core/markscheme_split_gold.py` | `a3213e2fe574c81b5a4a5c051638173816000c170d8fc80f733daaa251a02087` | mark-scheme splitting authority |
| `core/insert_engine.py` | `deabb38f698a046ccdafd48e5242bc4d99656791de3a415dcdf9a5fe94682df5` | Insert crop/boundary authority |
| `core/er_question_crops.py` | `e34ff53b9e73d5508bfc22c04d52022f1551f89848c836e61a12d9cbfa115347` | ER crop/boundary authority, including this safe terminal rule |
| `core/examiner_report.py` | `d7f45986f459e0607c5691b7e406ddb0bae157bc3bbedb28a3a721107119a59d` | ER discovery/attachment integration |
| `core/multipage_optimizer.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` | multi-page assembly authority |
| `core/multipage_optimizer_reference.py` | `c384248b3862c8352f80efb080defdc1ec7f738d97ca67b41cd46e3759ed84d5` | byte-identical multi-page reference peer |
| `core/vector_first_cropper.py` | `28991113a88c8a63b05d1b54dd46cb5c705b2030fcbada9a81a774affd13f65c` | vector-first crop path |
| `core/converter.py` | `d8bf74d83bd6827e0fad14ae558c4ae49e6754d5185c94a913b748e6f24f74c5` | render geometry authority |
| `core/pdf_io.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` | PDF render helper |
| `core/pdf_io_gold.py` | `5ee6f81c13e524e64002402f29a767e9e02c44357f0d8bb8b8a65a58f2d60e1f` | PDF render reference peer |
| `core/webp_utils.py` | `8961d27dbdf0866ed43e63d70aac4ef707924cc71243e7aa87224dd3d332251e` | image/WebP post-processing authority |
