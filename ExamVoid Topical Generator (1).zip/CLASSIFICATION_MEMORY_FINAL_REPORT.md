# ExamVoid Classification-Memory Final Report

**Report date:** 2026-08-29  
**Requested 2024 Business acceptance:** **PASS**  
**Repository-wide pytest status:** **CLEAN — 358 passed, 51 skipped, 51 subtests passed**

## Scope and locks

- Classification, taxonomy-profile, evidence-indexing, and final-validation integration were changed.
- No crop boundary, coordinate, splitter, padding/whitespace, Section-B/OR/footer/copyright rule, raster/rendering helper, QP/MS/ER/Insert crop logic, or `metadata.json` schema/generation/value was changed for this work.
- Persistent classification evidence remains separate from canonical metadata in the SQLite classification-memory store and non-canonical audit material.
- Major-topic physical routing remains single-folder routing; detailed classifications remain ranked metadata values following the routing major.

## Completion evidence

### Historical-profile-aware final validation

The initial authentic 9609/31 run reached S8 but was rejected because the final validator used the root/current Business profile rather than the metadata-declared 2024 profile. `core/validation.py` now resolves the year-specific profile from normal canonical metadata (`level`, `subject`, `paper` syllabus code, and `year`) for both topic-classification and cross-contamination reference checks. It reads those fields only; it does not alter metadata.

### Official Business 9609 2024 profile and scope

The profile is `subjects/A-Level/Business_9609/2024/config.json`, version `9609-2023-2025-official-profile/5`, tied to the official 2023–2025 Cambridge syllabus SHA-256:

`edceae4a6c4996c747fa641ea22260e271e428c20b35d6620a7e558c6a991a5e`

The classifier now consumes the profile’s existing `paper_detailed_topics` constraint before scoring, memory retrieval, detailed-topic output, and full-auto fallback. This prevents Paper 3/4 assumed-AS material from becoming a direct A-Level answer. The corresponding decision-procedure identifier is `topic-classifier/2026-08-29-memory-2`; live retrieval now filters classifier, taxonomy, and syllabus versions, so prior-version records require controlled review/reclassification rather than silently influencing a new procedure. `SubjectConfig.validate()` validates this optional scope for known detailed identifiers and compatibility with its major-topic scope.

The local official vocabulary was strengthened only with wording from syllabus sections 6.1.3, 6.1.7, and 7.4, including CSR/social and environmental audits/pressure groups and flexible-working-contract terminology. No topic identifier was invented or renamed.

### Raw mark-scheme evidence

`MarkSchemeEvidenceIndex` now safely indexes all five authentic 9609/31 whole questions. Bare labels are accepted only in qualifying question context; generic marking-rubric numerals and standalone mark allocations preceding a true subpart label are rejected.

## Authentic guarded end-to-end run

Command executed after the validator and semantic-scope repairs:

```bash
python3 main.py \
  --input validation_evidence/business_9609_s24_31_full_stack/input \
  --output validation_evidence/business_9609_s24_31_full_stack/output \
  --clean --full-auto \
  --classification-memory validation_evidence/business_9609_s24_22_memory/business_2024_source_grounded_memory_demo.sqlite3
```

Source set: official Cambridge June 2024 Business 9609/31 QP, MS, Insert, and examiner report. The complete final log is `validation_evidence/business_9609_s24_31_full_stack/guarded_full_stack_final_memory_v2.log` (development evidence, deliberately not packaged).

| Stage | Result |
|---|---:|
| S0 environment/config validation | PASS (2 checks) |
| S1 identification/year-profile selection | PASS (11 checks) |
| S2 QP crops | PASS (5 questions; 22 checks) |
| S3 MS crops | PASS (5 questions; 17 checks) |
| S4 QP/MS pairing | PASS (5 paired; 3 checks) |
| S5 classify/save | PASS (5 bundles; 51 checks) |
| S6 ER attachment | PASS (5 attached; 3 checks) |
| S7 ER per-question crops | PASS (10 tiles; 13 checks) |
| S7b grade thresholds | PASS — correctly skipped; none supplied |
| S8 final audit | PASS (errors=0; 6 checks) |

The worker reported `saved=5`; the guarded runner reported **ALL GREEN**, 8 stages and 42 checks. The read-only current-version memory database opened successfully (4 records / 96 indexed tokens); no 9609/31 question crossed the bounded similarity threshold against its Paper-2 fixture records, so all five results below are direct QP/MS/syllabus evidence rather than an inappropriate memory transfer. The separate authentic 9609/22 functional run confirmed matching current-version Paper-2 records are selectively retrieved.

### Source-backed semantic review of the previously weak items

The prior low-confidence forced results for Q1 and Q5 were not accepted as semantic evidence. With exact official profile scope and official terms applied, the successful full-stack run produced:

| Question | Single physical routing major | Detailed official topic(s) |
|---|---|---|
| Q1 flexible part-time employment contracts | `People_in_organisations` | `Human_resource_management_strategy` |
| Q2 communication process innovation | `Operations_and_project_management` | `Operations_strategy` |
| Q3 ARR/NPV investment decision | `Finance_and_accounting` | `Investment_appraisal` |
| Q4 PED | `Marketing` | `Marketing_analysis` |
| Q5 CSR expansion decision | `Strategic_management` | `External_influences_on_business_activity` |

Q1 aligns with official section 7.4 flexible working contracts. Q5 aligns with section 6.1 social/demographic and environmental external influences. Q4 no longer leaks the assumed-AS `The_marketing_mix` topic into a Paper 3 direct classification. A post-run audit confirmed all five generated records retained exactly the canonical 11 metadata fields and exactly one matching physical major-topic folder.

## Regression coverage

Focused command:

```bash
pytest -q tests/test_classification_memory.py
```

**PASS: 17 passed** (five existing PyMuPDF deprecation warnings only).

Coverage includes indexed bounded retrieval, verified/high-confidence/correction/negative/similar-record persistence, version staleness, correction and negative-memory non-override, cross-variant supporting retrieval, raw-MS handling, bare-label parser false-positive guards, historical-profile final-validation selection, and source-backed Business 9609/31 Paper 3 scope classification.

All 78 physical subject-profile files (including the restored Economics 2024 child) passed explicit `SubjectConfig.validate()`; the loader registers 323 current lookup keys. This includes paper-scope validation where a profile declares it.

### Broader repository suite

The previously absent `subjects/A-Level/Economics_9708/2024/config.json` has now been restored as an exact-year 2023–2025 profile, independently tied to the retained official Cambridge syllabus PDF (SHA-256 `d4c06e4e792aae7c9a62591b78f757cb01329ff18fcf599e431372bdd01f5cad`). Its 11 major and 53 detailed identifiers were normalized against the official source; its Paper 1/2 scope is the six AS majors and its Paper 3/4 scope is the five A-Level majors. The compatible existing taxonomy/operational keyword inventory was retained without inventing or renaming identifiers. The profile is selected for 2024 without replacing the root 2026–2028 default.

`pytest -q tests/test_economics_2024_profile.py -vv` passed **3/3**. The full `pytest -q` suite then passed **358 passed, 51 skipped, 5 warnings, 51 subtests passed** in 22.41 seconds. The warnings are existing PyMuPDF deprecation warnings only. This closes the prior repository-wide readiness blocker; no crop or `metadata.json` implementation was changed.

### Lock verification

`python3 tools/run_proof.py --output /tmp/proof3.html --no-suite --check` passed after the authorised classifier-ledger amendment: **140/140 tracked files verified, 579 ledger rows, no mismatches**. The proof's locked crop invariants also passed. The current `core/json_generator.py` hash remains the locked `d06fcd9ecb85600e40ae35bfd8680a6883828c24ba603b19d8b705ed037c558c`; no metadata implementation change was made.

## Performance and measurement boundary

Existing synthetic retrieval evidence remains the relevant scale test: 10,000 records / 130,022 indexed tokens populated in 5.1604 seconds; 50 bounded subject-token retrievals averaged 48.383 ms and returned no more than eight matches. This measures selective indexed retrieval, not classification accuracy.

There is still no independent human-verified per-question Business 9609 ground-truth label set in the workspace. Therefore **without-memory vs with-memory accuracy remains `NOT_MEASURED`**. No percentage or general improvement claim is made.

## Remaining limitations / controlled follow-up

1. Source-backed semantic outcomes for the five 9609/31 questions now pass the pipeline and targeted regressions, but an independently adjudicated large-scale accuracy benchmark is still needed before making an accuracy claim.
2. The profile’s detailed paper scope is intentionally enforced only when a profile explicitly supplies it; legacy profiles retain prior behaviour.
3. Classification memory is supporting evidence only. It does not automatically reclassify stored bundles; stale/version-mismatched records require a controlled human review/reclassification workflow.
4. The final archive excludes development PDFs, test outputs, SQLite stores, logs, caches, and unrelated proof/runtime artifacts.

## Release package

`ExamVoid Topical Generator.zip` was rebuilt from implementation, configuration, test, tool, and documentation sources after the readiness closure. The 374-entry release passed `unzip -t`; an independent post-build manifest/source-hash audit found zero bundled `.sqlite`, `.sqlite3`, `.log`, `.pdf`, `.webp`, cache, validation-evidence, output, fixture, or proof-output runtime artifacts and zero archive-vs-workspace source mismatches. This report and the updated specification/lock receipts are included in the release.
