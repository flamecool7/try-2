"""tests/test_scalability_and_manifest.py — Unit and integration tests for
variant-scoped duplicate detection, persistent processing manifest,
in-memory question indexing, and launcher lock recovery.
"""

import json
import os
import shutil
import tempfile
import time
from pathlib import Path
import unittest

from core.dedup import VariantDuplicateIndex, IndexedQuestion
from core.manifest import ProcessingManifest, FileStatus, ExecutionMode
from core.output_manager import OutputManager


class TestVariantScopedDedup(unittest.TestCase):
    """Test Cambridge variant-scoped duplicate detection."""

    def setUp(self):
        self.idx = VariantDuplicateIndex(similarity_threshold=0.88)

    def test_exact_duplicate_in_same_variant(self):
        is_dup1, _ = self.idx.check_and_index(
            qid="q1", syllabus_code="9701", variant="21",
            paper_code="9701_s22_qp_21", question_number="Q1",
            raw_text="Calculate the enthalpy change of combustion of propane in kJ/mol.",
        )
        self.assertFalse(is_dup1)

        # Same question text in same variant (e.g., repeated across years)
        is_dup2, orig2 = self.idx.check_and_index(
            qid="q2", syllabus_code="9701", variant="21",
            paper_code="9701_s23_qp_21", question_number="Q1",
            raw_text="Calculate the enthalpy change of combustion of propane in kJ/mol.",
        )
        self.assertTrue(is_dup2)
        self.assertEqual(orig2, "q1")

    def test_no_cross_variant_duplicates(self):
        """Questions in different variants (e.g., 21 vs 22) must NEVER be flagged as duplicates."""
        is_dup1, _ = self.idx.check_and_index(
            qid="q1", syllabus_code="9701", variant="21",
            paper_code="9701_s23_qp_21", question_number="Q1",
            raw_text="State the trend in first ionisation energy down Group 2.",
        )
        self.assertFalse(is_dup1)

        # Identical question text in a DIFFERENT variant (Paper 22)
        is_dup2, _ = self.idx.check_and_index(
            qid="q2", syllabus_code="9701", variant="22",
            paper_code="9701_s23_qp_22", question_number="Q1",
            raw_text="State the trend in first ionisation energy down Group 2.",
        )
        self.assertFalse(is_dup2, "Cross-variant comparison must NOT occur!")

    def test_no_cross_syllabus_duplicates(self):
        """Questions in different syllabi (e.g. 9701 vs 9702) must NEVER be flagged as duplicates."""
        is_dup1, _ = self.idx.check_and_index(
            qid="q1", syllabus_code="9701", variant="21",
            paper_code="9701_s23_qp_21", question_number="Q1",
            raw_text="Define the term standard temperature and pressure.",
        )
        self.assertFalse(is_dup1)

        is_dup2, _ = self.idx.check_and_index(
            qid="q2", syllabus_code="9702", variant="21",
            paper_code="9702_s23_qp_21", question_number="Q1",
            raw_text="Define the term standard temperature and pressure.",
        )
        self.assertFalse(is_dup2, "Cross-syllabus comparison must NOT occur!")

    def test_number_aware_check_preserves_distinct_questions(self):
        """Questions with differing numerical values must NOT be flagged as duplicates."""
        is_dup1, _ = self.idx.check_and_index(
            qid="q1", syllabus_code="9701", variant="21",
            paper_code="9701_s23_qp_21", question_number="Q3",
            raw_text="A sample containing 0.250 mol of magnesium reacts completely with excess HCl.",
        )
        self.assertFalse(is_dup1)

        is_dup2, _ = self.idx.check_and_index(
            qid="q2", syllabus_code="9701", variant="21",
            paper_code="9701_w23_qp_21", question_number="Q3",
            raw_text="A sample containing 0.500 mol of magnesium reacts completely with excess HCl.",
        )
        self.assertFalse(is_dup2, "Differing numbers must reject duplicate match!")


class TestProcessingManifest(unittest.TestCase):
    """Test persistent processing manifest, lifecycle tracking, and execution modes."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.tmp_path = Path(self.tmp)
        self.out_dir = self.tmp_path / "output"
        self.out_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_manifest_lifecycle_and_modes(self):
        m = ProcessingManifest.load_or_create(self.out_dir)

        p1 = self.tmp_path / "9706_s24_qp_11.pdf"
        p1.write_bytes(b"%PDF-1.4 test QP 11")
        p2 = self.tmp_path / "9706_s24_ms_11.pdf"
        p2.write_bytes(b"%PDF-1.4 test MS 11")

        # Scan files: should be NEW
        rec1, ch1 = m.scan_input_file(p1, kind="qp")
        self.assertTrue(ch1)
        self.assertEqual(rec1.status, FileStatus.NEW.value)

        rec2, ch2 = m.scan_input_file(p2, kind="ms")
        self.assertTrue(ch2)
        self.assertEqual(rec2.status, FileStatus.NEW.value)

        # Fast scan without content re-read
        rec1_fast, ch1_fast = m.scan_input_file(p1)
        self.assertEqual(rec1_fast.sha256, rec1.sha256)

        bkey = "9706_s24_11"
        should_run, reason = m.should_process_bundle(bkey, [p1, p2], mode=ExecutionMode.DEFAULT)
        self.assertTrue(should_run)

        # Mark processing
        m.record_bundle_processing(bkey, [p1, p2])
        self.assertEqual(m.files[str(p1.resolve())].status, FileStatus.PROCESSING.value)

        # Mark completed with artifacts
        art = self.out_dir / "11_Summer_2024_Q1.webp"
        art.write_bytes(b"webp_dummy")
        m.record_bundle_completed(bkey, [p1, p2], artifacts=["11_Summer_2024_Q1.webp"],
                                  questions_found=30, questions_saved=30)
        self.assertEqual(m.files[str(p1.resolve())].status, FileStatus.COMPLETED.value)
        m.save(force=True)

        # Reload manifest: should skip completed bundle
        m_reloaded = ProcessingManifest.load_or_create(self.out_dir)
        should_run2, reason2 = m_reloaded.should_process_bundle(bkey, [p1, p2], mode=ExecutionMode.DEFAULT)
        self.assertFalse(should_run2)
        self.assertEqual(reason2, "already_complete")

        # Force all mode should re-run
        should_run_force, _ = m_reloaded.should_process_bundle(bkey, [p1, p2], mode=ExecutionMode.FORCE_ALL)
        self.assertTrue(should_run_force)

        # Modify input file: should trigger CHANGED and re-run
        time.sleep(0.01)
        p1.write_bytes(b"%PDF-1.4 MODIFIED QP 11")
        rec1_mod, ch1_mod = m_reloaded.scan_input_file(p1)
        self.assertTrue(ch1_mod)
        self.assertEqual(rec1_mod.status, FileStatus.CHANGED.value)

        should_run_changed, _ = m_reloaded.should_process_bundle(bkey, [p1, p2], mode=ExecutionMode.DEFAULT)
        self.assertTrue(should_run_changed)

    def test_version_change_preserves_completed_entries(self):
        """A software upgrade must not turn a large archive into force-all."""
        p1 = self.tmp_path / "9706_s24_qp_11.pdf"
        p1.write_bytes(b"%PDF-1.4 test QP 11")
        m = ProcessingManifest.load_or_create(self.out_dir, pipeline_version="2.0.0")
        m.scan_input_file(p1, kind="qp")
        artifact = self.out_dir / "Q1.webp"
        artifact.write_bytes(b"webp_dummy")
        m.record_bundle_completed("9706_s24_11", [p1], ["Q1.webp"], 1, 1)
        m.save(force=True)

        upgraded = ProcessingManifest.load_or_create(self.out_dir, pipeline_version="3.0.0")
        self.assertEqual(
            upgraded.files[str(p1.resolve())].status,
            FileStatus.COMPLETED.value,
        )
        should_run, reason = upgraded.should_process_bundle(
            "9706_s24_11", [p1], mode=ExecutionMode.DEFAULT
        )
        self.assertFalse(should_run)
        self.assertEqual(reason, "already_complete")


class TestOutputManagerIndexing(unittest.TestCase):
    """Test fast in-memory question indexing in OutputManager."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.out_dir = Path(self.tmp) / "output"
        self.om = OutputManager(output_root=self.out_dir)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_folder_indexing(self):
        level = "A-Level"
        subject = "Accounting_9706"
        q_name = "21_Summer_2024_Q1"
        q_path = self.out_dir / level / subject / "paper-2" / "Financial_Accounting" / q_name
        q_path.mkdir(parents=True)

        # Initial lookup builds index
        found = self.om._find_existing_question_folders(level, subject, q_name)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0], q_path)

        # Register another question folder
        q_name2 = "21_Summer_2024_Q2"
        q_path2 = self.out_dir / level / subject / "paper-2" / "Financial_Accounting" / q_name2
        q_path2.mkdir(parents=True)
        self.om._register_question_folder(level, subject, q_name2, q_path2)

        found2 = self.om._find_existing_question_folders(level, subject, q_name2)
        self.assertEqual(len(found2), 1)
        self.assertEqual(found2[0], q_path2)

        # Unregister upon deletion
        shutil.rmtree(q_path2)
        self.om._unregister_question_folder(level, subject, q_name2, q_path2)
        found_after = self.om._find_existing_question_folders(level, subject, q_name2)
        self.assertEqual(len(found_after), 0)


if __name__ == "__main__":
    unittest.main()
