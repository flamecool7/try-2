"""test_actual_accounting_pipeline.py — Verification using actual public Cambridge A-Level Accounting paper (9706/32).

Ensures:
  1. Real Cambridge PDF fixtures are parsed correctly by paper_identifier.
  2. InsertEngine detects 'Source A for Question 1', 'Source B for Question 2', 'Source C for Question 3'.
  3. Bottom-whitespace trimming operates correctly on actual insert crops.
  4. Output structure adheres strictly to the single-folder invariant and canonical schema.
"""
from __future__ import annotations

import json
from pathlib import Path
import pytest
from PIL import Image

from core.paper_identifier import parse_paper_filename
from core.insert_engine import InsertEngine, referenced_sections
from core.validation import FinalValidator

FIXTURES_DIR = Path(__file__).resolve().parent.parent / "fixtures" / "actual_accounting_9706"


@pytest.mark.skipif(not (FIXTURES_DIR / "9706_s23_qp_32.pdf").exists(), reason="Actual Cambridge fixtures missing")
class TestActualAccountingPipeline:

    def test_fixture_integrity(self):
        expected_files = [
            ("9706_s23_qp_32.pdf", "qp", "32"),
            ("9706_s23_ms_32.pdf", "ms", "32"),
            ("9706_s23_in_32.pdf", "insert", "32"),
            ("9706_s23_er.pdf", "er", ""),
        ]
        for fname, ptype, variant in expected_files:
            fpath = FIXTURES_DIR / fname
            assert fpath.exists(), f"Missing fixture {fname}"
            # Check %PDF- magic
            with open(fpath, "rb") as f:
                header = f.read(5)
                assert header == b"%PDF-", f"File {fname} is not a valid PDF"
            info = parse_paper_filename(fpath)
            assert info.paper_type == ptype
            assert info.variant == variant
            assert info.syllabus_code == "9706"
            assert info.year == "2023"

    def test_actual_insert_section_detection(self):
        in_path = FIXTURES_DIR / "9706_s23_in_32.pdf"
        eng = InsertEngine(target_width=2280)
        res = eng.process_insert(in_path)
        assert res is not None
        assert len(res.sections) == 3
        section_ids = [s.id for s in res.sections]
        assert "Source A" in section_ids
        assert "Source B" in section_ids
        assert "Source C" in section_ids

        # Verify page classification: Page 1 is cover, 2-4 are content
        assert res.page_kinds[0] == "cover"
        assert res.page_kinds[1] == "content"
        assert res.page_kinds[2] == "content"
        assert res.page_kinds[3] == "content"

        # Verify section referencing
        q1_text = "1 Read Source A in the insert. (a) Prepare a statement..."
        q2_text = "2 Read Source B in the insert. (a) Explain why M Limited..."
        q3_text = "3 Read Source C in the insert. (a) State two reasons..."

        refs1 = referenced_sections(q1_text, res.sections)
        refs2 = referenced_sections(q2_text, res.sections)
        refs3 = referenced_sections(q3_text, res.sections)

        assert len(refs1) == 1 and refs1[0].id == "Source A"
        assert len(refs2) == 1 and refs2[0].id == "Source B"
        assert len(refs3) == 1 and refs3[0].id == "Source C"

    def test_actual_insert_crops_trimmed_and_exact_width(self):
        import numpy as np
        in_path = FIXTURES_DIR / "9706_s23_in_32.pdf"
        eng = InsertEngine(target_width=2280)
        res = eng.process_insert(in_path)
        for s in res.sections:
            img = eng._section_image(in_path, s)
            assert img is not None
            assert img.width == 2280
            assert img.height > 100
            # Ensure not all-white by checking extrema
            extrema = img.convert("L").getextrema()
            assert extrema[0] < 200, f"Expected ink, got min brightness {extrema[0]}"

            # Ensure top ink begins with section header and strictly excludes top page numbers
            arr = np.array(img.convert("L"))[:150]
            ink_rows = np.where((arr < 200).any(axis=1))[0]
            assert len(ink_rows) > 0
            first_y = ink_rows[0]
            ink_cols = np.where(arr[first_y] < 200)[0]
            # Section header is wide (> 300px) and left-aligned (x < 300), unlike page numbers
            assert ink_cols[-1] - ink_cols[0] > 200, "First ink line must be section header, not page number"
            assert ink_cols[0] < 300, "Section header must be left-aligned"

            # Ensure bottom of crop stops cleanly after content and excludes copyright / permissions junk
            if s.id == "Source C":
                assert img.height < 2100, f"Source C crop height {img.height} includes bottom copyright boilerplate"

    def test_actual_output_directory_structure_and_validator(self):
        out_root = Path(__file__).resolve().parent.parent / "proof_output" / "actual_accounting_9706"
        assert out_root.exists()

        validator = FinalValidator(output_root=out_root)
        val_res = validator.validate_all()
        assert val_res["passed"] is True, f"Validation errors: {val_res.get('errors')}"

        # Invariant check: exactly 1 physical folder per question
        q_folders = [p for p in out_root.rglob("32_Summer_2023_Q*") if p.is_dir()]
        assert len(q_folders) == 3

        for qf in q_folders:
            meta_path = qf / "metadata.json"
            assert meta_path.exists()
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            # Canonical keys
            assert set(meta.keys()) == {
                "id", "level", "subject", "board", "topic",
                "paper", "question_number", "variant", "season", "year"
            }
            assert isinstance(meta["topic"], list)
            assert 1 <= len(meta["topic"]) <= 4
            # Single-folder invariant: parent directory name equals meta['topic'][0]
            assert qf.parent.name == meta["topic"][0]

            # QP crop exists and is 2280 wide
            qp_img = qf / f"{qf.name}.webp"
            assert qp_img.exists()
            with Image.open(qp_img) as im:
                assert im.width == 2280

            # MS crop exists and is 2280 wide
            ms_img = qf / f"{qf.name}_MS.webp"
            assert ms_img.exists()
            with Image.open(ms_img) as im:
                assert im.width == 2280

            # IN crop exists and is 2280 wide
            in_img = qf / f"{qf.name}_IN.webp"
            assert in_img.exists()
            with Image.open(in_img) as im:
                assert im.width == 2280

            # ER crop exists and is 2280 wide
            er_img = qf / f"{qf.name}_ER.webp"
            assert er_img.exists()
            with Image.open(er_img) as im:
                assert im.width == 2280

            # Invariant: .txt file (examiner_report.txt) must NOT be part of final product
            er_txt = qf / "examiner_report.txt"
            assert not er_txt.exists(), f"Found unwanted .txt file {er_txt} in final product"

        # Check whole-page insert outputs in _insert
        insert_dir = out_root / "A-Level" / "Accounting_9706" / "paper-3" / "_insert" / "9706_s23_32"
        assert insert_dir.exists()
        p3_path = insert_dir / "9706_s23_32_p3.webp"
        assert p3_path.exists()
        with Image.open(p3_path) as p3_im:
            assert p3_im.width == 2280
            # Bottom copyright text must be removed, so height is trimmed below 2100px
            assert p3_im.height < 2100, f"p3 height {p3_im.height} includes bottom copyright boilerplate"
