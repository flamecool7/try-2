"""Regression coverage for the official Economics 9708 2023–2025 profile.

The 2024 validation paper must resolve to the historical official syllabus
profile without replacing the default 2026–2028 configuration for modern runs.
"""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from core.classifier import TopicClassifier
from core.config_loader import load_subject_config_by_code_and_level


ROOT = Path(__file__).resolve().parents[1]
HISTORICAL_CONFIG = ROOT / "subjects" / "A-Level" / "Economics_9708" / "2024" / "config.json"
DEFAULT_CONFIG = ROOT / "subjects" / "A-Level" / "Economics_9708" / "config.json"
OFFICIAL_2023_2025_SYLLABUS = (
    "https://www.cambridgeinternational.org/Images/595463-2023-2025-syllabus.pdf"
)
OFFICIAL_2023_2025_SYLLABUS_SHA256 = (
    "d4c06e4e792aae7c9a62591b78f757cb01329ff18fcf599e431372bdd01f5cad"
)
AS_PAPER_MAJORS = {
    "Basic_economic_ideas_and_resource_allocation",
    "The_price_system_and_the_microeconomy_AS",
    "Government_microeconomic_intervention_AS",
    "The_macroeconomy_AS",
    "Government_macroeconomic_intervention_AS",
    "International_economic_issues_AS",
}
A_LEVEL_PAPER_MAJORS = {
    "The_price_system_and_the_microeconomy_A_Level",
    "Government_microeconomic_intervention_A_Level",
    "The_macroeconomy_A_Level",
    "Government_macroeconomic_intervention_A_Level",
    "International_economic_issues_A_Level",
}


def test_economics_2024_selects_official_historical_profile():
    assert HISTORICAL_CONFIG.is_file()
    cfg = load_subject_config_by_code_and_level("9708", "A-Level", "2024")

    assert cfg is not None
    assert cfg.config_path == HISTORICAL_CONFIG
    assert cfg.subject == "Economics_9708"
    assert cfg.syllabus_code == "9708"
    assert cfg.level == "A-Level"
    assert cfg.version == "2023-2025"
    assert cfg.official_source == OFFICIAL_2023_2025_SYLLABUS
    assert cfg.data["syllabus_source_sha256"] == OFFICIAL_2023_2025_SYLLABUS_SHA256
    assert cfg.syllabus_years == ["2023", "2024", "2025"]
    assert cfg.requested_year == "2024"
    assert cfg.year_verified is True
    assert cfg.year_review_required is False
    assert cfg.validate() == (True, [])
    # Official assessment overview: Papers 1/2 use AS content; Papers 3/4
    # use A-Level content with AS knowledge assumed. The profile's routing
    # scope deliberately reflects the directly assessed major sections.
    assert set(cfg.data["paper_topics"]["1"]) == AS_PAPER_MAJORS
    assert set(cfg.data["paper_topics"]["2"]) == AS_PAPER_MAJORS
    assert set(cfg.data["paper_topics"]["3"]) == A_LEVEL_PAPER_MAJORS
    assert set(cfg.data["paper_topics"]["4"]) == A_LEVEL_PAPER_MAJORS


def test_as_paper_scope_keeps_a_level_topics_out_of_2024_metadata():
    cfg = load_subject_config_by_code_and_level("9708", "A-Level", "2024")
    classifier = TopicClassifier(cfg)
    # This is the substantive subject context of 9708/21 M/J 2024 Q1.
    question = SimpleNamespace(
        qp=SimpleNamespace(
            text=(
                "Sri Lanka has a balance of trade deficit, weak international "
                "competitiveness, comparative advantage in tea, exports and "
                "imports. Assess whether increased exports will restore growth."
            ),
            marks=20,
        ),
        variant="21",
        question_number="Q1",
        year="2024",
        season="Summer",
    )

    result = classifier.classify_question(question, force_winner=True)

    assert result.winning_major == "International_economic_issues_AS"
    allowed = set(cfg.data["paper_topics"]["2"])
    assert result.detailed_topics
    assert all(cfg.mapping[topic] in allowed for topic in result.detailed_topics)
    assert all(not topic.endswith("_A_Level") for topic in result.detailed_topics)


def test_historical_child_does_not_replace_default_2026_profile():
    current = load_subject_config_by_code_and_level("9708", "A-Level", "2026")
    default = load_subject_config_by_code_and_level("9708", "A-Level")

    assert current is not None and default is not None
    assert current.config_path == DEFAULT_CONFIG
    assert default.config_path == DEFAULT_CONFIG
    assert current.version == "2026"
    assert current.syllabus_years == ["2026", "2027", "2028"]
    assert current.year_verified is True
    assert current.year_review_required is False
