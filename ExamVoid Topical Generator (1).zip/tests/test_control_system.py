"""tests/test_control_system.py — Complete Verification Suite for ExamVoid Control System & Launcher.

Tests all 19 functional features specified in the ExamVoid control system:
  1. Main menu
  2. Process New Files
  3. Resume / Process Pending
  4. Selected processing
  5. Reprocess Everything
  6. Archive audit
  7. Dry run
  8. Proof generation
  9. Statistics
  10. System verification
  11. Cleanup
  12. Settings
  13. Developer tools
  14. Benchmark
  15. Single-instance lock
  16. Graceful shutdown
  17. Progress display
  18. New-file scan
  19. BAT repeated execution
"""

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO))

from core.control_center import (
    ArchiveAuditor,
    ArchiveStatistics,
    ControlMenu,
    DryRunPreviewer,
    ExamVoidLock,
    GracefulShutdown,
    NewFilesScanner,
    PerformanceBenchmarker,
    SafeCleaner,
    SettingsManager,
    SystemVerifier,
    is_pid_alive,
)
from core.manifest import BundleRecord, FileRecord, FileStatus, ProcessingManifest


class TestControlSystem(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp(prefix="test_ctrl_")
        self.root = Path(self.tmp_dir)
        self.input_dir = self.root / "input"
        self.output_dir = self.root / "output"
        self.input_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    # -------------------------------------------------------------------------
    # 1. Main Menu
    # -------------------------------------------------------------------------
    def test_main_menu(self):
        menu = ControlMenu()
        # Verify header calculation
        total, comp, pend = menu._get_archive_header_stats()
        self.assertIsInstance(total, int)
        self.assertIsInstance(comp, int)
        self.assertIsInstance(pend, int)

        # Verify rendering doesn't crash
        with patch("builtins.print") as mock_print:
            menu.render_header()
            self.assertTrue(mock_print.called)

        with patch("builtins.print") as mock_print:
            menu.render_menu()
            self.assertTrue(mock_print.called)

    # -------------------------------------------------------------------------
    # 2. Process New Files
    # -------------------------------------------------------------------------
    def test_process_new_files(self):
        menu = ControlMenu()
        with patch.object(menu, "_execute_batch") as mock_exec:
            menu.process_new_files()
            mock_exec.assert_called_once_with(resume=True, retry_failed=False, force_all=False)

    # -------------------------------------------------------------------------
    # 3. Resume / Process Pending
    # -------------------------------------------------------------------------
    def test_resume_process_pending(self):
        menu = ControlMenu()
        with patch.object(menu, "_execute_batch") as mock_exec:
            menu.resume_pending()
            mock_exec.assert_called_once_with(resume=True, retry_failed=True, force_all=False)

    # -------------------------------------------------------------------------
    # 4. Process Selected Files
    # -------------------------------------------------------------------------
    def test_selected_processing(self):
        menu = ControlMenu()
        # Test Subject Filter selection (Option 1)
        with patch("builtins.input", side_effect=["1", "Accounting_9706"]):
            with patch.object(menu, "_execute_batch") as mock_exec:
                menu.process_selected_files()
                mock_exec.assert_called_once_with(subject_filter="Accounting_9706", resume=True)

        # Test exact Cambridge Variant Filter selection (Option 2)
        with patch("builtins.input", side_effect=["2", "32"]):
            with patch.object(menu, "_execute_batch") as mock_exec:
                menu.process_selected_files()
                mock_exec.assert_called_once_with(variant_filter="32", resume=True)

        # Test Year Filter selection (Option 3)
        with patch("builtins.input", side_effect=["3", "2024"]):
            with patch.object(menu, "_execute_batch") as mock_exec:
                menu.process_selected_files()
                mock_exec.assert_called_once_with(year_filter="2024", resume=True)

    def test_scoped_dry_run_filters_variant_and_single_file(self):
        """Variant and exact-file scopes select only matching bundle plans."""
        from core.batch_runner import run_pipeline as batch_run

        for variant in ("21", "22"):
            (self.input_dir / f"9706_s24_qp_{variant}.pdf").write_bytes(f"%PDF QP {variant}".encode())
            (self.input_dir / f"9706_s24_ms_{variant}.pdf").write_bytes(f"%PDF MS {variant}".encode())

        by_variant = batch_run(
            str(self.input_dir), str(self.output_dir), dry_run=True, variant_filter="22"
        )
        self.assertEqual(by_variant["bundles_seen"], 1)
        self.assertEqual(by_variant["new"], 1)
        self.assertEqual(by_variant["categories"]["new"], ["9706_s24_22"])

        selected = str((self.input_dir / "9706_s24_qp_21.pdf").resolve())
        by_file = batch_run(
            str(self.input_dir), str(self.output_dir), dry_run=True, selected_paths={selected}
        )
        self.assertEqual(by_file["bundles_seen"], 1)
        self.assertEqual(by_file["categories"]["new"], ["9706_s24_21"])

    # -------------------------------------------------------------------------
    # 5. Reprocess Everything
    # -------------------------------------------------------------------------
    def test_reprocess_everything(self):
        menu = ControlMenu()
        # Aborted if typing anything other than confirmation
        with patch("builtins.input", return_value="no"):
            with patch.object(menu, "_execute_batch") as mock_exec:
                menu.reprocess_everything()
                mock_exec.assert_not_called()

        # Confirmed only when typing exact phrase
        with patch("builtins.input", return_value="REPROCESS EVERYTHING"):
            with patch.object(menu, "_execute_batch") as mock_exec:
                menu.reprocess_everything()
                mock_exec.assert_called_once_with(force_all=True, resume=False)

    # -------------------------------------------------------------------------
    # 6. Archive Audit
    # -------------------------------------------------------------------------
    def test_archive_audit(self):
        auditor = ArchiveAuditor(self.input_dir, self.output_dir)

        # Populate synthetic inputs and manifest
        pdf1 = self.input_dir / "9706_s23_qp_32.pdf"
        pdf1.write_bytes(b"%PDF-1.4 sample content")

        manifest = ProcessingManifest.load_or_create(self.output_dir)
        manifest.files[str(pdf1.resolve())] = FileRecord(
            path=str(pdf1.resolve()),
            sha256="dummy_hash",
            size=len(pdf1.read_bytes()),
            mtime_ns=pdf1.stat().st_mtime_ns,
            status=FileStatus.COMPLETED.value,
            artifacts=["A-Level/Accounting_9706/32_Summer_2023_Q1/32_Summer_2023_Q1.webp"],
        )
        manifest.bundles["9706_s23_32"] = BundleRecord(
            bundle_key="9706_s23_32",
            status="complete",
            input_files=[str(pdf1.resolve())],
            artifacts=["A-Level/Accounting_9706/32_Summer_2023_Q1/32_Summer_2023_Q1.webp"],
            questions_saved=1,
        )
        manifest.save(force=True)

        res = auditor.audit()
        self.assertEqual(res["source_files"], 1)
        self.assertEqual(res["completed"], 1)
        # Artifact doesn't exist on disk yet -> missing outputs detected!
        self.assertEqual(res["missing_outputs"], 1)

        # Create the artifact on disk -> missing outputs drops to 0!
        art_path = self.output_dir / "A-Level/Accounting_9706/32_Summer_2023_Q1/32_Summer_2023_Q1.webp"
        art_path.parent.mkdir(parents=True, exist_ok=True)
        art_path.write_bytes(b"RIFF\x00\x00\x00\x00WEBPVP8 ")

        res2 = auditor.audit()
        self.assertEqual(res2["missing_outputs"], 0)

    # -------------------------------------------------------------------------
    # 7. Dry Run
    # -------------------------------------------------------------------------
    def test_dry_run(self):
        previewer = DryRunPreviewer(self.input_dir, self.output_dir)
        pdf1 = self.input_dir / "9701_s24_qp_22.pdf"
        pdf1.write_bytes(b"%PDF dummy data")

        res = previewer.preview()
        self.assertEqual(res["new_files"], 1)
        self.assertEqual(res["would_process"], 1)
        self.assertEqual(res["already_completed"], 0)

    def test_dry_run_is_read_only_and_uses_bundle_state(self):
        """Preview must not create a DB/manifest and must honor DB completion."""
        from core.batch_runner import run_pipeline as batch_run
        from core.database import Database

        fresh_input = self.root / "fresh_input"
        fresh_output = self.root / "fresh_output"
        fresh_input.mkdir()
        (fresh_input / "9706_s24_qp_32.pdf").write_bytes(b"%PDF QP")
        (fresh_input / "9706_s24_ms_32.pdf").write_bytes(b"%PDF MS")

        plan = batch_run(str(fresh_input), str(fresh_output), dry_run=True)
        self.assertTrue(plan["dry_run"])
        self.assertEqual(plan["new"], 1)
        self.assertFalse(fresh_output.exists(), "read-only dry run created archive state")

        # Build a completed bundle in the real DB, then assert preview sees it
        # as completed without writing a JSON manifest alongside it.
        fresh_output.mkdir()
        db = Database(fresh_output / "pipeline.sqlite")
        qp = fresh_input / "9706_s24_qp_32.pdf"
        ms = fresh_input / "9706_s24_ms_32.pdf"
        qp_id = db.register_file(qp, "qp", "9706", "s", "24", "32", "STRUCTURED")
        ms_id = db.register_file(ms, "ms", "9706", "s", "24", "32", "STRUCTURED")
        bundle_id, _changed, _reason = db.sync_bundle_inputs(
            "9706_s24_32", "9706", "Accounting_9706", "A-Level", "s", "24", "32",
            "STRUCTURED", qp_id, ms_id, None,
        )
        db.mark_bundle_complete(bundle_id, 1, 1)

        preview = DryRunPreviewer(fresh_input, fresh_output).preview()
        self.assertEqual(preview["completed"], 1)
        self.assertEqual(preview["would_process"], 0)
        self.assertFalse((fresh_output / ".processing_manifest.json").exists())

    # -------------------------------------------------------------------------
    # 8. Proof Generation
    # -------------------------------------------------------------------------
    def test_proof_generation(self):
        menu = ControlMenu()
        with patch("builtins.input", return_value="0"):
            menu.generate_proof()  # Safe cancel

        # Full archive visual proof delegates to the read-only existing-output
        # reporter rather than creating replacement crops.
        with patch("builtins.input", return_value="1"):
            with patch("subprocess.run") as mock_run:
                menu.generate_proof()
                mock_run.assert_called_once()
                self.assertIn("build_archive_proof.py", str(mock_run.call_args[0][0]))

        # The integrity suite remains available explicitly, not as a substitute
        # for visual archive proof.
        with patch("builtins.input", return_value="7"):
            with patch("subprocess.run") as mock_run:
                menu.generate_proof()
                self.assertIn("run_proof.py", str(mock_run.call_args[0][0]))

    def test_visual_proof_scopes_existing_output_only(self):
        """Visual proof filters real on-disk items without invoking a cropper."""
        from PIL import Image
        from tools.build_archive_proof import build_archive_proof, select_questions

        qdir = (self.output_dir / "A-Level" / "Accounting_9706" / "paper-3"
                / "Financial_statements" / "31_Summer_2024_Q1")
        qdir.mkdir(parents=True)
        metadata = {
            "id": "proof-test-id", "level": "A-Level", "subject": "Accounting_9706",
            "board": "CIE", "topic": ["Financial_statements"],
            "paper": "9706_s24_qp_31", "question_number": "Q1",
            "variant": "31", "season": "Summer", "year": "2024",
        }
        (qdir / "metadata.json").write_text(json.dumps(metadata), encoding="utf-8")
        Image.new("RGB", (24, 16), "white").save(qdir / "31_Summer_2024_Q1.webp", "WEBP")
        Image.new("RGB", (24, 16), "white").save(qdir / "31_Summer_2024_Q1_MS.webp", "WEBP")

        selected = select_questions(self.output_dir, subject="accounting", variant="31", year="24")
        self.assertEqual(len(selected), 1)
        self.assertEqual(select_questions(self.output_dir, variant="32"), [])
        (self.output_dir / ".processing_manifest.json").write_text(json.dumps({
            "bundles": {"9706_s24_31": {"status": "complete", "last_processed": "2026-08-29T10:00:00Z"}}
        }), encoding="utf-8")
        self.assertEqual(len(select_questions(self.output_dir, new_only=True)), 1)

        proof = self.root / "scoped_visual_proof.html"
        built = build_archive_proof(self.output_dir, proof, subject="Accounting", session="s24")
        markup = built.read_text(encoding="utf-8")
        self.assertIn("31_Summer_2024_Q1.webp", markup)
        self.assertIn("data:image/webp;base64,", markup)
        self.assertIn("Canonical metadata.json", markup)
        self.assertNotIn("<script", markup)

    # -------------------------------------------------------------------------
    # 9. Statistics
    # -------------------------------------------------------------------------
    def test_statistics(self):
        stats_calc = ArchiveStatistics(self.input_dir, self.output_dir)
        pdf1 = self.input_dir / "9706_s23_qp_32.pdf"
        pdf1.write_bytes(b"%PDF content 12345")

        qdir = self.output_dir / "A-Level" / "Accounting_9706" / "32_Summer_2023_Q1"
        qdir.mkdir(parents=True, exist_ok=True)
        (qdir / "32_Summer_2023_Q1.webp").write_bytes(b"WEBP_DATA")
        (qdir / "metadata.json").write_text("{}", encoding="utf-8")

        res = stats_calc.get_stats()
        self.assertEqual(res["files"], 1)
        self.assertGreaterEqual(res["questions"], 1)
        self.assertEqual(res["subjects"], 1)
        self.assertEqual(res["variants"], 1)
        self.assertGreater(res["input_pdf_mb"], 0)
        self.assertGreater(res["webp_mb"], 0)

    # -------------------------------------------------------------------------
    # 10. System Verification
    # -------------------------------------------------------------------------
    def test_system_verification(self):
        verifier = SystemVerifier(self.input_dir, self.output_dir)
        all_ok, checks = verifier.verify()
        self.assertTrue(all_ok, f"Verification failed on: {[c for c in checks if not c[1]]}")
        self.assertGreaterEqual(len(checks), 8)

    # -------------------------------------------------------------------------
    # 11. Cleanup Temporary Files
    # -------------------------------------------------------------------------
    def test_cleanup_temporary_files(self):
        cleaner = SafeCleaner(self.output_dir)

        # Create temporary files
        # Recognised ExamVoid-owned atomic manifest scratch files.
        tmp1 = self.output_dir / ".proc_manifest_test_1.tmp"
        tmp1.write_text("scratch", encoding="utf-8")
        tmp2 = self.output_dir / ".proc_manifest_test_2.tmp"
        tmp2.write_text("manifest_scratch", encoding="utf-8")
        staging = self.output_dir / ".staging" / "bundle_tmp"
        staging.mkdir(parents=True, exist_ok=True)
        (staging / "worker_log.txt").write_text("log", encoding="utf-8")

        # Non-temporary file that MUST be preserved
        keep_pdf = self.input_dir / "preserve.pdf"
        keep_pdf.write_bytes(b"%PDF")
        keep_webp = self.output_dir / "question.webp"
        keep_webp.write_bytes(b"WEBP")
        # Generic user files that merely end in .tmp are not assumed to be
        # ExamVoid scratch data and must remain untouched.
        user_tmp = self.output_dir / "user_notes.tmp"
        user_tmp.write_text("preserve", encoding="utf-8")

        temp_files = cleaner.scan_temp_files()
        self.assertGreaterEqual(len(temp_files), 3)

        deleted = cleaner.clean(interactive=False)
        self.assertGreaterEqual(deleted, 3)

        # Verify preserved files are completely untouched
        self.assertTrue(keep_pdf.exists())
        self.assertTrue(keep_webp.exists())
        self.assertTrue(user_tmp.exists())
        self.assertFalse(tmp1.exists())
        self.assertFalse(tmp2.exists())

    def test_cleanup_does_not_touch_active_run_resources(self):
        """An active lock protects its staging tree from cleanup."""
        lock = ExamVoidLock(self.output_dir / ".examvoid_run_lock")
        self.assertTrue(lock.acquire(interactive=False))
        staging_file = self.output_dir / ".staging" / "bundle" / "worker_log.txt"
        staging_file.parent.mkdir(parents=True)
        staging_file.write_text("active", encoding="utf-8")

        cleaner = SafeCleaner(self.output_dir)
        self.assertEqual(cleaner.clean(interactive=False), 0)
        self.assertTrue(staging_file.exists())
        self.assertTrue(lock.lock_dir.exists())

        lock.release()
        self.assertGreaterEqual(cleaner.clean(interactive=False), 1)
        self.assertFalse(staging_file.exists())

    # -------------------------------------------------------------------------
    # 12. Settings Management
    # -------------------------------------------------------------------------
    def test_settings_manager(self):
        cfg_file = self.root / "test_settings.ini"
        sm = SettingsManager(path=cfg_file)

        self.assertEqual(sm.get("workers"), "auto")
        sm.set("workers", "4")
        self.assertEqual(sm.get("workers"), "4")

        # Reload from disk to verify persistence
        sm2 = SettingsManager(path=cfg_file)
        self.assertEqual(sm2.get("workers"), "4")

    # -------------------------------------------------------------------------
    # 13. Developer Tools
    # -------------------------------------------------------------------------
    def test_developer_tools(self):
        menu = ControlMenu()
        with patch("builtins.input", side_effect=["0"]):
            menu.developer_tools_menu()

    # -------------------------------------------------------------------------
    # 14. Performance Benchmark
    # -------------------------------------------------------------------------
    def test_performance_benchmark(self):
        bench = PerformanceBenchmarker(self.output_dir)
        bench.benchmarks_dir = self.root / "benchmarks"
        res = bench.run_benchmark()
        self.assertIn("dedup_indexing_200_ms", res)
        self.assertIn("manifest_cache_500_ms", res)
        self.assertIn("output_manager_lookup_200_ms", res)
        self.assertIn("total_benchmark_sec", res)

        saved_files = list(bench.benchmarks_dir.glob("*.json"))
        self.assertEqual(len(saved_files), 1)

    # -------------------------------------------------------------------------
    # 15. Single-Instance Lock & Stale Lock Recovery
    # -------------------------------------------------------------------------
    def test_single_instance_lock(self):
        lock_dir = self.output_dir / ".test_lock"
        lock1 = ExamVoidLock(lock_dir)

        # Acquire lock
        self.assertTrue(lock1.acquire(interactive=False))
        self.assertTrue(lock_dir.exists())

        # Second acquire while alive should fail
        lock2 = ExamVoidLock(lock_dir)
        self.assertFalse(lock2.acquire(interactive=False))

        # Release
        lock1.release()
        self.assertFalse(lock_dir.exists())

        # Test Stale Lock Recovery with Dead PID (PID 9999999)
        lock_dir.mkdir(parents=True, exist_ok=True)
        (lock_dir / "pid.txt").write_text("9999999", encoding="utf-8")
        (lock_dir / "started.txt").write_text("Yesterday", encoding="utf-8")

        lock3 = ExamVoidLock(lock_dir)
        # Should auto-recover without crashing
        self.assertTrue(lock3.acquire(interactive=False))
        lock3.release()

    def test_database_interrupted_state_recovers_and_failed_stays_explicit(self):
        """PROCESSING resumes automatically; FAILED waits for explicit retry."""
        from core.database import Database

        pdf = self.input_dir / "9706_s24_qp_32.pdf"
        pdf.write_bytes(b"%PDF")
        db = Database(self.output_dir / "pipeline.sqlite")
        fid = db.register_file(pdf, "qp", "9706", "s", "24", "32", "STRUCTURED")
        bid = db.create_bundle(
            "9706_s24_32", "9706", "Accounting_9706", "A-Level", "s", "24", "32",
            "STRUCTURED", fid, None, None,
        )
        db.mark_bundle_processing(bid)
        self.assertEqual(db.recover_interrupted_bundles(), 1)
        self.assertEqual(len(db.get_pending_bundles(include_failed=False)), 1)

        db.mark_bundle_failed(bid, "intentional failure")
        self.assertEqual(len(db.get_pending_bundles(include_failed=False)), 0)
        self.assertEqual(len(db.get_pending_bundles(include_failed=True)), 1)

    # -------------------------------------------------------------------------
    # 16. Graceful Shutdown Handler
    # -------------------------------------------------------------------------
    def test_graceful_shutdown(self):
        gs = GracefulShutdown()
        cleaned = []

        gs.register("callback1", lambda: cleaned.append(1))
        gs.register("callback2", lambda: cleaned.append(2))
        gs.install()

        # Simulate SIGINT signal triggering handler
        with patch("sys.exit") as mock_exit:
            gs._handle_signal(signal.SIGINT, None)
            mock_exit.assert_called_once_with(130)

        # Ensure callbacks ran in reverse registration order
        self.assertEqual(cleaned, [2, 1])
        gs.uninstall()

    # -------------------------------------------------------------------------
    # 17. Progress Display
    # -------------------------------------------------------------------------
    def test_progress_display(self):
        from core.progress_ui import PlainProgress, format_postfix
        p = PlainProgress(total=10, desc="TestBatch")
        with patch("builtins.print") as mock_print:
            with p:
                p.update(1)
                p.set_postfix_str(format_postfix(ok=1, failed=0, review=0, last="test_key"))
            self.assertTrue(mock_print.called)

    # -------------------------------------------------------------------------
    # 18. New-file Scan
    # -------------------------------------------------------------------------
    def test_new_file_scan(self):
        scanner = NewFilesScanner(self.input_dir, self.output_dir)

        # Initially empty
        self.assertEqual(scanner.scan(), [])

        # Add a PDF
        pdf1 = self.input_dir / "9706_s24_qp_22.pdf"
        pdf1.write_bytes(b"%PDF content")

        found = scanner.scan()
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].name, "9706_s24_qp_22.pdf")

    def test_windows_launcher_is_thin_application_delegate(self):
        """Static contract: Windows BAT delegates rather than owning pipeline logic."""
        bat = (REPO / "run.bat").read_text(encoding="utf-8")
        self.assertIn('cd /d "%~dp0"', bat)
        self.assertIn('run_pipeline.py --menu', bat)
        self.assertIn('run_pipeline.py %*', bat)
        self.assertIn('exit /b %APP_EXIT%', bat)
        self.assertNotIn(':RUN_BATCH', bat)
        self.assertNotIn('tools\\run_with_log.py', bat)

    # -------------------------------------------------------------------------
    # 19. BAT Repeated Execution & Stale Lock Invariants
    # -------------------------------------------------------------------------
    def test_bat_repeated_execution(self):
        # Simulate 4 consecutive runs with zero manual cleanup
        lock_dir = self.output_dir / ".examvoid_run_lock"

        for run_idx in range(1, 5):
            lock = ExamVoidLock(lock_dir)
            acquired = lock.acquire(interactive=False, command_desc=f"Run {run_idx}")
            self.assertTrue(acquired, f"Run {run_idx} failed to acquire lock")
            lock.release()
            self.assertFalse(lock_dir.exists(), f"Run {run_idx} failed to release lock cleanly")


if __name__ == "__main__":
    unittest.main(verbosity=2)
