"""Regression coverage for the authorised 9708/21 crop-boundary remediation.

The approved source bundle is component /21 only.  These tests deliberately do
not call it /22: they establish that the real production QP path excludes a
Cambridge permissions tail, a standalone external OR choice marker, and the
next standalone section heading. They also retain unaffected-crop controls.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from core import er_question_crops as erc
from core import question_split as qsplit
from core.cropping_engine import CroppingEngine, gold_question_split
from run_guarded import er_crop_verification_gate


ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIR = ROOT / "validation_evidence" / "economics_9708_s24_21" / "source_pdfs"
QP_SOURCE = SOURCE_DIR / "9708_s24_qp_21.pdf"
ER_SOURCE = SOURCE_DIR / "9708_s24_er.pdf"
ACCOUNTING_ER_SOURCE = (
    ROOT / "validation_evidence" / "accounting_9706_s23_32_or_crosspaper" /
    "runtime_input" / "9706_s23_er.pdf"
)

_PERMISSION_SIGNATURE = (
    "permission to reproduce items where third-party owned material protected by copyright"
)


def _longest_interior_blank_run(image) -> int:
    """Largest all-white row run away from the outer crop margins."""
    gray = np.asarray(image.convert("L"))
    ink_per_row = (gray[:, 40:-40] < 230).sum(axis=1)
    blank = ink_per_row == 0
    # Crop-level white padding is legitimate.  The regression is specifically
    # about the large *internal* continuation gap that formerly separated ER
    # Q1(a)(i) and Q1(a)(ii).
    blank[:40] = False
    blank[-40:] = False
    best = current = 0
    for is_blank in blank:
        if is_blank:
            current += 1
            best = max(best, current)
        else:
            current = 0
    return int(best)


def test_er_crop_gate_honours_the_final_product_no_text_policy():
    ok, detail = er_crop_verification_gate(
        {"crops_written": 5, "verified": 0, "verify_failed": []}
    )
    assert ok
    assert "no-.txt policy" in detail

    failed, failed_detail = er_crop_verification_gate(
        {"crops_written": 5, "verified": 4, "verify_failed": ["21_Summer_2024_Q2"]}
    )
    assert not failed
    assert "containment failures" in failed_detail


def test_qp_permission_detector_is_deliberately_narrow():
    assert qsplit._is_qp_backmatter_text(
        "Permission to reproduce items where third-party owned material protected "
        "by copyright is included has been sought and cleared where possible."
    )
    # A genuine question may mention copyright.  That is not enough to cut it.
    assert not qsplit._is_qp_backmatter_text(
        "Explain how copyright protection can affect the supply of digital media."
    )


def test_qp_structural_delimiters_use_real_pdf_coordinates():
    fitz = pytest.importorskip("fitz")
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 100), "5  Explain the economic effect. [8]", fontsize=11)
    page.draw_line((50, 400), (545, 400))
    result = page.insert_textbox(
        fitz.Rect(50, 405, 545, 510),
        "Permission to reproduce items where third-party owned material protected "
        "by copyright is included has been sought and cleared where possible.",
        fontsize=9,
    )
    assert result >= 0
    boundary = qsplit._qp_backmatter_boundary_pdf(page)
    assert boundary is not None and boundary < 400
    assert qsplit.find_question_bottom_pdf(page) < 200

    page2 = doc.new_page(width=595, height=842)
    page2.insert_text((50, 250), "Section B", fontsize=11)
    assert qsplit._section_heading_ys_pdf(page2) == pytest.approx([238.175])
    doc.close()


def test_qp_or_choice_separator_requires_narrow_structural_context():
    """Only an external, left-margin OR immediately before the next Q qualifies."""
    fitz = pytest.importorskip("fitz")
    doc = fitz.open()

    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 160), "2  Complete the calculation. [8]", fontsize=11)
    page.insert_text((50, 260), "OR", fontsize=11)
    page.insert_text((50, 286), "3  Explain the result. [8]", fontsize=11)
    lines = page.get_text("dict")["blocks"]
    q2_y = next(line["bbox"][1] for block in lines if block.get("type") == 0
                for line in block["lines"]
                if "2  Complete" in "".join(span["text"] for span in line["spans"]))
    q3_y = next(line["bbox"][1] for block in lines if block.get("type") == 0
                for line in block["lines"]
                if "3  Explain" in "".join(span["text"] for span in line["spans"]))
    boundary = qsplit._standalone_or_choice_boundary_pdf(
        page, question_start_y_pdf=q2_y, next_question_y_pdf=q3_y
    )
    assert boundary is not None

    # A centred isolated OR is not a structural left-margin separator.
    centered = doc.new_page(width=595, height=842)
    centered.insert_text((50, 160), "2  Explain the outcome. [8]", fontsize=11)
    centered.insert_text((290, 260), "OR", fontsize=11)
    centered.insert_text((50, 286), "3  Explain the result. [8]", fontsize=11)
    assert qsplit._standalone_or_choice_boundary_pdf(
        centered, question_start_y_pdf=148.0, next_question_y_pdf=274.0
    ) is None

    # Even a left-margin OR is preserved unless a next top-level marker follows
    # promptly; it could otherwise be legitimate question content.
    distant = doc.new_page(width=595, height=842)
    distant.insert_text((50, 160), "2  Explain the outcome. [8]", fontsize=11)
    distant.insert_text((50, 260), "OR", fontsize=11)
    distant.insert_text((50, 600), "3  Explain the result. [8]", fontsize=11)
    assert qsplit._standalone_or_choice_boundary_pdf(
        distant, question_start_y_pdf=148.0, next_question_y_pdf=588.0
    ) is None
    doc.close()


def test_er_section_and_continuation_helpers_are_geometry_based():
    pages = [
        [(685.0, "Question 1", [10.0])],
        [(58.0, "(ii)", [10.0]), (369.0, "Section B", [10.0])],
    ]
    assert erc._section_boundary_in_segment(pages, 0, 685.0, 1, 392.0) == (1, 369.0)

    lines = [
        (35.0, 49.0, "Principal Examiner Report for Teachers"),
        (58.0, 84.0, "(ii) Commentary begins"),
        (93.0, 130.0, "The remaining commentary"),
    ]
    top, bottom = erc._tighten_continuation_band(
        lines, 842.0, 46.0, 392.0,
        is_continuation_start=True,
        is_continuation_end=False,
        pad_pt=3.0,
    )
    assert top == pytest.approx(55.0)
    assert bottom == pytest.approx(392.0)


def test_terminal_er_trim_refuses_vector_content_in_the_discarded_tail():
    """The Q3 terminal fix may trim text-only tails, never an untextual figure."""
    fitz = pytest.importorskip("fitz")
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((50, 100), "Question 3 commentary", fontsize=11)
    assert erc._terminal_text_only_tail_is_safe(page, 105.0, 700.0)

    # A table/diagram rule below the last body text makes the tail unsafe.
    page.draw_rect(fitz.Rect(50, 220, 540, 350), color=(0, 0, 0), width=1)
    assert not erc._terminal_text_only_tail_is_safe(page, 105.0, 700.0)
    doc.close()


@pytest.mark.skipif(not QP_SOURCE.is_file(), reason="approved 9708/21 QP source is absent")
def test_actual_9708_21_qp_crop_boundaries_and_standalone_or_remediation():
    """Exercise the actual production runtime, which imports original_reference."""
    engine = CroppingEngine(dpi=200, quality=95)
    questions = engine.process_paper(QP_SOURCE)
    assert gold_question_split.__file__.endswith(
        "original_reference/cambridge_qb/question_split.py"
    )
    assert [q.number_int for q in questions] == [1, 2, 3, 4, 5]
    by_number = {q.number_int: q for q in questions}

    q1, q2, q3, q4, q5 = (by_number[1], by_number[2], by_number[3],
                            by_number[4], by_number[5])
    assert "section b" not in q1.text.casefold()
    assert "answer one question" not in q1.text.casefold()
    assert _PERMISSION_SIGNATURE not in q5.text.casefold()
    assert "copyright acknowledgements booklet" not in q5.text.casefold()

    # Q5 now materializes only its two question parts, not a permissions tail.
    assert q5.assembled_image.size == (2280, 296)
    assert q5.assembled_image.height < 400
    # Strict QP top invariant survives the targeted end-boundary correction.
    q5_rgb = np.asarray(q5.assembled_image.convert("RGB"))
    assert not np.any(q5_rgb[:20] < 250)

    # The source has standalone external OR choice markers after Q2 and Q4.
    # They are outside the materialised bands, while a legitimate inline "or"
    # in Q3 is retained as normal question prose.
    no_or_line = lambda question: not any(
        line.strip().casefold() == "or" for line in question.text.splitlines()
    )
    assert no_or_line(q2) and no_or_line(q3) and no_or_line(q4)
    assert "price elasticity of supply or cross elasticity" in q3.text.casefold()
    assert q2.assembled_image.size == (2280, 260)
    assert q4.assembled_image.size == (2280, 486)
    assert "planned economic system" in q2.text.casefold()
    assert "aggregate demand" in q4.text.casefold()


@pytest.mark.skipif(not ER_SOURCE.is_file(), reason="approved 9708/21 ER source is absent")
def test_actual_9708_21_er_q1_gap_and_section_boundary_controls():
    crops, statuses, segment_texts, fmt = erc.build_question_crops_for_pdf(
        ER_SOURCE, "9708", "21", [1, 2, 3, 4, 5]
    )
    assert fmt == "full_with_sub"
    assert statuses == {f"Q{q}": "webp_cropped" for q in range(1, 6)}
    assert sorted(crops) == [1, 2, 3, 4, 5]
    assert all(image.width == 2280 for image in crops.values())

    # Q1 used to retain Section B and a 153px internal blank/header fragment.
    assert "sectionb" not in segment_texts[1]
    assert crops[1].height == 1516
    assert _longest_interior_blank_run(crops[1]) < 100

    # Q3 also terminates cleanly before the next Section C heading rather than
    # appending a header-only continuation sliver; Q2/Q4 remain controls.
    assert "sectionc" not in segment_texts[3]
    assert crops[3].height == 812
    assert crops[2].size == (2280, 716)
    assert crops[4].size == (2280, 760)
    # Q5 is a final question sharing Q4's source page, so the narrowly scoped
    # fresh-page terminal-Q3 rule must leave its established behavior intact.
    assert crops[5].size == (2280, 1996)


@pytest.mark.skipif(not ACCOUNTING_ER_SOURCE.is_file(), reason="approved 9706/32 ER source is absent")
def test_actual_accounting_9706_32_er_q3_terminal_boundary_is_content_complete_and_tight():
    """Regression for the proven text-only final-page Q3 fallback defect."""
    crops, statuses, segment_texts, fmt = erc.build_question_crops_for_pdf(
        ACCOUNTING_ER_SOURCE, "9706", "32", [1, 2, 3]
    )
    assert fmt == "full_with_sub"
    assert statuses == {"Q1": "webp_cropped", "Q2": "webp_cropped", "Q3": "webp_cropped"}
    assert sorted(crops) == [1, 2, 3]

    q3 = crops[3]
    text = segment_texts[3]
    # Full first-to-final commentary coverage, with the prior near-footer tail
    # reduced to the existing semantic padding after the final body line.
    assert q3.size == (2280, 934)
    assert _longest_interior_blank_run(q3) <= 120
    for phrase in (
        "manycandidatesstatedtwovalidreasonsforabusinessacquisition",
        "therealisationaccountwaswellprepared",
        "thejournalentriesweregenerallywellprepared",
        "informationinthequestion",
    ):
        assert phrase in text

    # No following question/section/admin material belongs to this ER band.
    assert "question4" not in text
    assert "sectionb" not in text
    assert "copyright" not in text
    assert "2023" not in text
