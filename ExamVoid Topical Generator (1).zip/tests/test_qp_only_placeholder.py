#!/usr/bin/env python3
"""Regression: a structured QP-only path must not publish a fake pair.

The historical crash was caused by dereferencing ``matched.ms`` when an MS
crop was unavailable. The production-safe resolution preserves the real QP
inside ``review_required_no_ms`` without a text placeholder. Only MCQ answer
grid papers may use an ``*_MS.txt`` sidecar in a question folder.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from PIL import Image

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.json_generator import CANONICAL_METADATA_FIELDS  # noqa: E402
from core.mcq_output import PLACEHOLDER_MS_CONTENT, is_placeholder_ms  # noqa: E402
from core.output_manager import OutputManager  # noqa: E402
from core.validation import FinalValidator  # noqa: E402
from tests.test_mcq_unified import _fake_classification, _fake_config  # noqa: E402


def _qp_only_matched():
    qp = SimpleNamespace(assembled_image=Image.new("RGB", (2280, 300), "white"),
                         question_number="Q1", number_int=1, text="Solve x.")
    return SimpleNamespace(
        qp=qp, ms=None, ms_answer=None, variant="42",
        paper_code="0606_s24_42", full_qp_code="0606_s24_qp_42",
        full_ms_code=None, question_number="Q1", season="Summer", year="2024",
    )


class TestQpOnlyPlaceholder(unittest.TestCase):
    def test_structured_qp_only_routes_to_review_without_text_placeholder(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            matched = _qp_only_matched()
            with self.assertRaisesRegex(ValueError, "Structured question has no usable mark-scheme crop"):
                mgr.save_question_pair(matched, _fake_classification(), _fake_config(tmp))

            saved = mgr.save_review_required_question(matched, "no_markscheme", _fake_config(tmp))
            qf = Path(saved["question_folder"])
            self.assertIn("review_required", qf.parts)
            self.assertTrue(list(qf.glob("*.webp")), "QP webp missing")
            self.assertEqual(list(qf.glob("*_MS.webp")), [], "MS webp fabricated")
            self.assertEqual(list(qf.glob("*.txt")), [], "structured review folder must contain no text artifact")
            self.assertFalse((qf / "REASON.txt").exists())
            md = json.loads((qf / "metadata.json").read_text())
            self.assertEqual(set(md.keys()), set(CANONICAL_METADATA_FIELDS), md.keys())

    def test_mcq_qp_only_uses_placeholder_not_empty_letter_file(self):
        # Full-auto QP-only mode must not enter review_required and must not
        # emit an empty MCQ answer file (the empty file means an MS existed but
        # its grid letter was unavailable).
        with tempfile.TemporaryDirectory() as tmp:
            from tests.test_mcq_unified import _fake_config as _mcq_cfg
            qp = SimpleNamespace(
                assembled_image=Image.new("RGB", (2280, 300), "white"),
                question_number="Q1", number_int=1, text="Which gas?",
            )
            matched = SimpleNamespace(
                qp=qp, ms=None, ms_answer=None, variant="22",
                paper_code="0620_s24_22", full_qp_code="0620_s24_qp_22",
                full_ms_code=None, question_number="Q1", season="Summer",
                year="2024",
            )
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_question_pair(matched, _fake_classification(),
                                           _mcq_cfg(tmp))
            qf = Path(saved["question_folder"])
            self.assertNotIn("review_required", qf.parts)
            self.assertEqual(
                (qf / f"{qf.name}_MS.txt").read_text().strip(),
                PLACEHOLDER_MS_CONTENT,
            )

    def test_validators_accept_structured_no_ms_review_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            mgr.save_review_required_question(_qp_only_matched(), "no_markscheme",
                                              _fake_config(tmp))
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertEqual(v.errors, [], v.errors)

    def test_non_mcq_placeholder_is_flagged(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = OutputManager(output_root=str(Path(tmp) / "out"))
            saved = mgr.save_review_required_question(_qp_only_matched(), "no_markscheme",
                                                      _fake_config(tmp))
            qf = Path(saved["question_folder"])
            (qf / f"{qf.name}_MS.txt").write_text("MS_UNAVAILABLE\n")
            v = FinalValidator(output_root=str(Path(tmp) / "out"))
            v.check_question_folders()
            self.assertTrue(any("only permitted for MCQ" in e for e in v.errors), v.errors)

    def test_placeholder_marker_constants(self):
        self.assertEqual(PLACEHOLDER_MS_CONTENT, "MS_UNAVAILABLE")
        self.assertTrue(is_placeholder_ms("MS_UNAVAILABLE\n"))
        self.assertTrue(is_placeholder_ms("ms_unavailable"))
        self.assertFalse(is_placeholder_ms("B"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
