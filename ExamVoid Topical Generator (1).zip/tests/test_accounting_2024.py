#!/usr/bin/env python3
"""Comprehensive Accounting 2024 test suite.

Validates the full Cambridge Accounting 9706 & 0452 pipeline requirements:
  1. Complete paper identification & document types (QP, MS, ER, Insert, CI, SF).
  2. Paper association & grouping (QP + MS + ER + Insert linked to paper identity).
  3. Classification across all required syllabus question styles:
     - Straightforward double-entry / ledger questions
     - Theory questions (accounting concepts: prudence, going concern, accruals)
     - Calculation questions (depreciation, gross/net profit, financial statements)
     - Multi-part questions (analyzing entire question stem + all subparts)
     - Multi-topic questions (internal multi-candidate ranking, canonical 4-cap)
     - Ambiguous / company accounts (share capital, dividends, equity statements)
     - Cost & management accounting (marginal costing, break-even, variance)
     - Ratio analysis (liquidity, profitability, efficiency, gearing)
  4. Complete 2024 paper relationship pipeline:
     - Insert cropping with unnecessary bottom whitespace removed while preserving content
     - Examiner Report processed as an ER (never as a topical question; no fabrication)
     - Single-folder distribution invariant (count == 1)
     - Strict canonical JSON metadata schema (zero forbidden fields)
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import fitz
import numpy as np
from PIL import Image

PROJ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJ))

from core.classifier import TopicClassifier
from core.config_loader import load_subject_config_by_code_and_level
from core.insert_engine import (InsertEngine, _trim_bottom_whitespace,
                                referenced_sections, write_insert_outputs)
from core.output_manager import OutputManager
from core.paper_identifier import parse_paper_filename
from core.qp_ms_matcher import QPMSMatcher
from core.validation import FinalValidator


def _make_accounting_pdf(path: Path, pages_content: list[list[str]], page_h: int = 842, page_w: int = 595):
    """Create a clean vector PDF with specified text lines per page."""
    doc = fitz.open()
    for page_lines in pages_content:
        pg = doc.new_page(width=page_w, height=page_h)
        y = 50
        for line in page_lines:
            pg.insert_text((40, y), line, fontsize=10)
            y += 20
    doc.save(str(path))
    doc.close()


class TestAccounting2024IdentificationAndAssociation(unittest.TestCase):
    """Verify document identification, classification of types, and grouping."""

    def test_identify_compact_2024_accounting_bundle(self):
        cases = [
            ("9706_s24_qp_22.pdf", "qp", "22", "9706_s24_qp_22"),
            ("9706_s24_ms_22.pdf", "ms", "22", "9706_s24_ms_22"),
            ("9706_s24_er.pdf", "er", "", "9706_s24_er"),
            ("9706_s24_in_22.pdf", "insert", "22", "9706_s24_insert_22"),
            ("9706_s24_insert_22.pdf", "insert", "22", "9706_s24_insert_22"),
            ("9706_s24_ci_22.pdf", "insert", "22", "9706_s24_insert_22"),
        ]
        for name, ptype, variant, full_code in cases:
            info = parse_paper_filename(Path(name))
            self.assertIsNotNone(info, f"Failed to parse {name}")
            self.assertEqual(info.syllabus_code, "9706", name)
            self.assertEqual(info.year, "2024", name)
            self.assertEqual(info.season, "Summer", name)
            self.assertEqual(info.paper_type, ptype, name)
            self.assertEqual(info.variant, variant, name)
            self.assertEqual(info.full_code, full_code, name)

    def test_identify_long_realworld_2024_accounting_bundle(self):
        cases = [
            ("9706 Accounting June 2024 Question Paper 22.pdf", "qp", "22", "9706_s24_qp_22"),
            ("9706 Accounting June 2024 Mark Scheme 22.pdf", "ms", "22", "9706_s24_ms_22"),
            ("9706 Accounting June 2024 Examiner Report.pdf", "er", "", "9706_s24_er"),
            ("9706 Accounting June 2024 Insert 22.pdf", "insert", "22", "9706_s24_insert_22"),
            ("9706 Accounting June 2024 Source Booklet 22.pdf", "insert", "22", "9706_s24_insert_22"),
        ]
        for name, ptype, variant, full_code in cases:
            info = parse_paper_filename(Path(name))
            self.assertIsNotNone(info, f"Failed to parse {name}")
            self.assertEqual(info.syllabus_code, "9706", name)
            self.assertEqual(info.year, "2024", name)
            self.assertEqual(info.season, "Summer", name)
            self.assertEqual(info.paper_type, ptype, name)
            self.assertEqual(info.variant, variant, name)
            self.assertEqual(info.full_code, full_code, name)

    def test_paper_association_grouping(self):
        matcher = QPMSMatcher()
        papers = [
            parse_paper_filename(Path("9706_s24_qp_22.pdf")),
            parse_paper_filename(Path("9706_s24_ms_22.pdf")),
            parse_paper_filename(Path("9706_s24_in_22.pdf")),
        ]
        groups = matcher.group_papers(papers)
        self.assertIn("9706_s24_22", groups)
        bundle = groups["9706_s24_22"]
        self.assertIn("qp", bundle)
        self.assertIn("ms", bundle)
        self.assertIn("insert", bundle)
        self.assertEqual(len(matcher.grouping_errors), 0)

    def test_duplicate_paper_detection(self):
        matcher = QPMSMatcher()
        with tempfile.TemporaryDirectory() as td:
            p1 = Path(td) / "9706_s24_qp_22.pdf"
            p2 = Path(td) / "9706_s24_qp_22_copy.pdf"
            p1.write_bytes(b"%PDF-1.4 qp content 1")
            p2.write_bytes(b"%PDF-1.4 different qp content 2")
            papers = [parse_paper_filename(p1), parse_paper_filename(p2)]
            groups = matcher.group_papers(papers)
            self.assertGreaterEqual(len(matcher.grouping_errors), 1)


class TestAccountingClassificationQuestionTypes(unittest.TestCase):
    """Verify classification across all syllabus concepts and question types."""

    @classmethod
    def setUpClass(cls):
        cls.config = load_subject_config_by_code_and_level("9706", "A-Level")
        assert cls.config is not None, "9706 A-Level config must exist"
        cls.classifier = TopicClassifier(cls.config)

    def _classify(self, qnum: str, text: str, marks: int | None = None):
        m = SimpleNamespace(
            question_number=qnum,
            number_int=int(qnum[1:]) if qnum[1:].isdigit() else 1,
            qp=SimpleNamespace(text=text, marks=marks),
            variant="22",
            season="Summer",
            year="2024",
        )
        return self.classifier.classify_question(m)

    def test_straightforward_question(self):
        # Double-entry bookkeeping and ledger accounts
        res = self._classify(
            "Q1",
            "Explain the purpose of double entry bookkeeping and prepare the "
            "sales ledger account for the customer using the transactions provided. [6]",
            marks=6,
        )
        self.assertEqual(res.winning_major, "Introduction_to_accounting")
        self.assertGreaterEqual(res.confidence, 0.85)

    def test_theory_question(self):
        # Accounting concepts: prudence, going concern, accruals, consistency
        res = self._classify(
            "Q2",
            "Explain how the prudence concept and the going concern concept apply "
            "to the valuation of inventory and bad debts in financial accounting records. [8]",
            marks=8,
        )
        self.assertEqual(res.winning_major, "Introduction_to_accounting")
        self.assertIn("Financial_statements", res.detailed_topics)

    def test_calculation_question(self):
        # Depreciation and financial statements (income statement, gross/net profit)
        res = self._classify(
            "Q3",
            "Calculate the depreciation charge using the straight line depreciation method. "
            "Prepare the income statement for the year ended 31 December showing gross profit "
            "and cost of sales. [12]",
            marks=12,
        )
        self.assertEqual(res.winning_major, "Financial_statements")
        self.assertIn("Financial_statements", res.detailed_topics)

    def test_multipart_question_whole_context(self):
        # Question with stem and subparts (a), (b), (c)
        text = (
            "Question 4\n"
            "(a) State two advantages of operating as a partnership rather than a sole trader. [2]\n"
            "(b) Calculate the interest on capital and the salary to partner for each partner. [4]\n"
            "(c) Prepare the profit and loss appropriation account for the year ended 30 April. [8]\n"
            "(d) Evaluate whether the partners should admit a new partner to the partnership. [6]"
        )
        res = self._classify("Q4", text, marks=20)
        self.assertEqual(res.winning_major, "Partnership_accounts")
        self.assertIn("Partnership_accounts", res.detailed_topics)

    def test_multitopic_question_and_canonical_cap(self):
        # Question that references partnership, financial position, and ratio analysis
        text = (
            "A partnership business provided its statement of financial position. "
            "(a) Prepare the capital accounts of the partners. [6]\n"
            "(b) Calculate the current ratio and return on capital employed (ROCE) for the business. [6]\n"
            "(c) Comment on the liquidity and profitability ratios of the partnership. [4]"
        )
        res = self._classify("Q5", text, marks=16)
        # Check that candidates are identified internally
        self.assertTrue(len(res.detailed_topics) >= 2)
        # Cap must never exceed 4
        self.assertLessEqual(len(res.detailed_topics), 4)
        # Valid syllabus topic winners only
        self.assertIn(res.winning_major, self.config.major_topics)

    def test_ambiguous_company_accounts_question(self):
        # Limited company, share capital, debentures, statement of changes in equity
        text = (
            "The directors of a public limited company (plc) made a rights issue of ordinary shares "
            "at a share premium and issued debentures. Prepare the statement of changes in equity "
            "and explain the treatment of the final dividend. [14]"
        )
        res = self._classify("Q6", text, marks=14)
        self.assertEqual(res.winning_major, "Company_accounts")

    def test_cost_and_management_accounting(self):
        # Break-even, contribution, margin of safety
        text = (
            "A manufacturing company uses marginal costing. "
            "Calculate the contribution per unit, the break-even point in units, "
            "and the margin of safety. Prepare a budget showing the variance analysis. [10]"
        )
        res = self._classify("Q7", text, marks=10)
        self.assertEqual(res.winning_major, "Cost_and_management_accounting")

    def test_ratio_analysis_question(self):
        # Ratio analysis: liquidity, profitability, efficiency
        text = (
            "Calculate the gross profit margin, net profit margin, inventory turnover, "
            "and price earnings ratio for the year. Evaluate the company performance. [10]"
        )
        res = self._classify("Q8", text, marks=10)
        self.assertEqual(res.winning_major, "Ratio_analysis")


class TestInsertCroppingWhitespaceRemoval(unittest.TestCase):
    """Verify Insert crops remove unnecessary empty whitespace while preserving content."""

    def test_trim_bottom_whitespace_function(self):
        # Synthetic 2280px wide image with content ending at y=300 in a 1200px tall canvas
        im = Image.new("RGB", (2280, 1200), "white")
        arr = np.asarray(im).copy()
        # draw ink rows from y=100 to y=300
        arr[100:300, 200:800] = 30
        im = Image.fromarray(arr)

        trimmed = _trim_bottom_whitespace(im, pad=24)
        # Width MUST be exactly 2280
        self.assertEqual(trimmed.width, 2280)
        # Height must be trimmed to last ink (299) + pad (24) + 1 = 324
        self.assertEqual(trimmed.height, 324)
        # Ink content must be 100% preserved
        trimmed_arr = np.asarray(trimmed)
        self.assertEqual(int((trimmed_arr < 248).sum()), int((arr < 248).sum()))

    def test_trim_bottom_preserves_full_page_content(self):
        # If content extends all the way to bottom, nothing is trimmed
        im = Image.new("RGB", (2280, 1000), "white")
        arr = np.asarray(im).copy()
        arr[950:995, 200:800] = 30
        im = Image.fromarray(arr)

        trimmed = _trim_bottom_whitespace(im, pad=24)
        self.assertEqual(trimmed.width, 2280)
        self.assertEqual(trimmed.height, 1000)

    def test_insert_engine_end_to_end_crops(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "9706_s24_in_22.pdf"
            # Create a 2-page insert where page 1 has stimulus ending at y=200
            _make_accounting_pdf(p, [
                ["Source A",
                 "Alpha Manufacturing Ltd produces two types of goods.",
                 "Direct materials cost $50,000.",
                 "Direct labour cost $30,000."],
                ["Source B",
                 "Beta Trading Co reported annual turnover of $200,000."]
            ], page_h=842, page_w=595)

            eng = InsertEngine(target_width=2280, dpi=150)
            res = eng.process_insert(p)
            self.assertIsNotNone(res)
            self.assertFalse(res.is_reference_data)

            # Whole page crops must be 2280 wide and bottom-trimmed
            for page_img in res.pages:
                self.assertEqual(page_img.width, 2280)
                # Content ended at y=110pt (~230px rendered at 150dpi); should not be full 1750px tall
                self.assertLess(page_img.height, 1000)

            # Section crop for Source A
            sec = [s for s in res.sections if s.id == "Source A"][0]
            sec_img = eng._section_image(p, sec)
            self.assertIsNotNone(sec_img)
            self.assertEqual(sec_img.width, 2280)
            self.assertLess(sec_img.height, 1000)


class TestComplete2024AccountingPaperPipeline(unittest.TestCase):
    """End-to-end integration: QP, MS, ER, and Insert processed and validated."""

    def test_full_pipeline_accounting_2024_bundle(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            out = td / "output"
            cfg = load_subject_config_by_code_and_level("9706", "A-Level")
            om = OutputManager(output_root=out, target_width=2280, quality=95)

            # 1. Simulate QP question crop
            qp_img = Image.new("RGB", (2280, 500), "white")
            qp_arr = np.asarray(qp_img).copy()
            qp_arr[100:400, 200:1000] = 0
            qp_crop = SimpleNamespace(
                question_number="Q1", number_int=1,
                assembled_image=Image.fromarray(qp_arr),
                text="Calculate the gross profit and prepare the income statement for the year.",
                marks=10
            )

            # 2. Simulate MS crop
            ms_img = Image.new("RGB", (2280, 300), "white")
            ms_arr = np.asarray(ms_img).copy()
            ms_arr[50:250, 100:900] = 0
            ms_crop = SimpleNamespace(
                question_number="Q1", number_int=1,
                assembled_image=Image.fromarray(ms_arr),
            )

            # 3. Simulate matched question
            matched = SimpleNamespace(
                question_number="Q1", number_int=1,
                qp=qp_crop, ms=ms_crop, ms_answer=None,
                paper_code="9706_s24_22",
                full_qp_code="9706_s24_qp_22",
                full_ms_code="9706_s24_ms_22",
                year="2024", season="Summer", variant="22",
                subject="Accounting_9706",
                paper_format="STRUCTURED",
            )

            # 4. Classify question
            classifier = TopicClassifier(cfg)
            c_res = classifier.classify_question(matched)
            self.assertEqual(c_res.winning_major, "Financial_statements")

            # 5. Save question to output
            saved = om.save_question_pair(matched, c_res, cfg)
            qfolder = Path(saved["question_folder"])
            self.assertTrue(qfolder.exists())

            # 6. Verify single-folder distribution rule
            # Folder name MUST match winning major topic character-for-character
            self.assertEqual(qfolder.parent.name, "Financial_statements")
            self.assertTrue((qfolder / "22_Summer_2024_Q1.webp").exists())
            self.assertTrue((qfolder / "22_Summer_2024_Q1_MS.webp").exists())
            self.assertTrue((qfolder / "metadata.json").exists())

            # 7. Check strict metadata schema
            meta = json.loads((qfolder / "metadata.json").read_text(encoding="utf-8"))
            self.assertEqual(meta["topic"][0], "Financial_statements")
            self.assertEqual(meta["subject"], "Accounting_9706")
            self.assertEqual(meta["year"], "2024")
            self.assertEqual(meta["season"], "Summer")
            for forbidden in ("topic_details", "primary", "secondary", "needs_review", "topic_scores"):
                self.assertNotIn(forbidden, meta)

            # 8. Simulate Insert booklet attachment
            ins_pdf = td / "9706_s24_in_22.pdf"
            _make_accounting_pdf(ins_pdf, [
                ["Source A", "Financial data for Alpha Ltd. Revenue: $100,000."],
            ])
            eng = InsertEngine(target_width=2280, dpi=150)
            ins_res = eng.process_insert(ins_pdf)
            summary = write_insert_outputs(
                eng, ins_res, ins_pdf, out, "A-Level", "Accounting_9706",
                "paper-2", "9706_s24_22",
                question_refs=[(str(qfolder), "Refer to Source A to calculate profit.")]
            )
            self.assertEqual(summary["sections"], 1)
            in_crop = qfolder / "22_Summer_2024_Q1_IN.webp"
            self.assertTrue(in_crop.exists())
            with Image.open(in_crop) as im:
                self.assertEqual(im.width, 2280)

            # 9. No fabricated examiner-report text is written. The final
            # product permits only WebP artifacts and canonical metadata here;
            # real ER attachment/cropping is exercised with the public fixture
            # suite rather than a made-up commentary file.
            self.assertFalse((qfolder / "examiner_report.txt").exists())

            # 10. Run FinalValidator
            fv = FinalValidator(output_root=out)
            v_res = fv.validate_all()
            self.assertTrue(v_res["passed"], getattr(fv, "errors", []))


if __name__ == "__main__":
    unittest.main()
