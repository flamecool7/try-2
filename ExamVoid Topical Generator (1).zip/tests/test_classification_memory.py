"""Regression coverage for indexed classification memory and raw MS evidence.

The tests use controlled labels to verify system behaviour, not to claim an
external accuracy percentage.  The authentic Business checks only assert
published-source extraction and transparent, syllabus-backed functionality.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJ = Path(__file__).resolve().parent.parent
if str(PROJ) not in sys.path:
    sys.path.insert(0, str(PROJ))

from core.classification_memory import ClassificationMemory  # noqa: E402
from core.classifier import CLASSIFIER_VERSION, TopicClassifier  # noqa: E402
from core.config_loader import SubjectConfig, load_subject_config_by_code_and_level  # noqa: E402
from core.mark_scheme_evidence import MarkSchemeEvidenceIndex  # noqa: E402
from core.validation import FinalValidator  # noqa: E402
from run_guarded import (  # noqa: E402
    _flush_high_confidence_memory_records,
    _queue_high_confidence_memory_record,
)

BUSINESS_MS = PROJ / "validation_evidence/business_9609_s24_22_memory/source_pdfs/9609_s24_ms_22.pdf"
BUSINESS_31_MS = PROJ / "validation_evidence/business_9609_s24_31_full_stack/source_pdfs/9609_s24_ms_31.pdf"


def _memory_config() -> SubjectConfig:
    data = {
        "subject": "Memory_Test_9999",
        "syllabus_code": "9999",
        "level": "A-Level",
        "major_topics": ["Operations", "Marketing", "Finance"],
        "detailed_topics": ["Inventory_management", "The_marketing_mix", "Costs"],
        "mapping": {
            "Inventory_management": "Operations",
            "The_marketing_mix": "Marketing",
            "Costs": "Finance",
        },
        "classification_keywords": {
            "Inventory_management": ["inventory", "just in time", "jit", "stock control"],
            "The_marketing_mix": ["packaging", "branding", "promotion"],
            "Costs": ["break-even", "contribution", "fixed cost"],
        },
        "specialization_weights": {},
        "syllabus_order": {"Operations": 1, "Marketing": 2, "Finance": 3},
        "syllabus_years": ["2024"],
        "version": "memory-test-taxonomy/1",
    }
    return SubjectConfig(data)


def _matched(text: str, *, number: int = 1, marks: int = 8,
             variant: str = "22", syllabus_code: str = "9999") -> SimpleNamespace:
    return SimpleNamespace(
        qp=SimpleNamespace(text=text, marks=marks, assembled_image=None),
        ms=SimpleNamespace(text=f"Mark scheme for question {number}"),
        number_int=number,
        question_number=f"Q{number}",
        variant=variant,
        year="2024",
        season="Summer",
        full_qp_code=f"{syllabus_code}_s24_qp_{variant}",
        paper_code=f"{syllabus_code}_s24_{variant}",
    )


class TestClassificationMemoryStorage(unittest.TestCase):
    def test_trust_categories_relationships_versions_and_staleness(self):
        with tempfile.TemporaryDirectory() as tmp:
            with ClassificationMemory(Path(tmp) / "memory.sqlite3") as memory:
                verified = memory.record_verified(
                    subject="Business_9609", topics=["Inventory_management"],
                    question_text="Explain the purpose of just in time inventory management.",
                    evidence=["Published mark scheme assesses JIT inventory management."],
                    taxonomy_version="9609-2023-2025", syllabus_version="source-current", classifier_version="test/1",
                )
                high = memory.record_high_confidence(
                    subject="Business_9609", topics=["Costs"], confidence=0.95,
                    question_text="Calculate contribution and break-even output.",
                    evidence=["Contribution and break-even are directly requested."],
                    taxonomy_version="old-taxonomy", syllabus_version="source-old", classifier_version="old-classifier",
                )
                correction = memory.record_correction(
                    subject="Business_9609", correct_topics=["Costs"],
                    incorrect_topics=["Business_strategy"],
                    reason="Published mark scheme assesses contribution, not strategy.",
                    question_text="Calculate contribution for a batch of shoes.",
                    taxonomy_version="9609-2023-2025", syllabus_version="source-current", classifier_version="test/1",
                )
                negative = memory.record_negative(
                    subject="Business_9609", incorrect_topics=["The_marketing_mix"],
                    reason="Packaging is mentioned in the scenario but is not an assessed task.",
                    question_text="Evaluate contribution and break-even analysis.",
                    taxonomy_version="9609-2023-2025", syllabus_version="source-current", classifier_version="test/1",
                )
                relation = memory.record_similar_question_relation(
                    verified, high, similarity=0.72,
                    evidence="Both are short quantitative inventory/cost questions.",
                )
                self.assertGreater(relation, 0)
                stats = memory.stats()
                self.assertEqual(stats["records"], 4)
                self.assertEqual(stats["by_trust_level"], {
                    "correction": 1, "high_confidence": 1, "negative": 1, "verified": 1,
                })
                self.assertEqual(stats["similar_question_relationships"], 1)
                self.assertEqual(len(memory.similar_question_relationships(verified)), 1)
                stale = memory.stale_records(
                    subject="Business_9609", taxonomy_version="9609-2023-2025",
                    syllabus_version="source-current", classifier_version="test/1",
                )
                self.assertEqual([row["id"] for row in stale], [high])
                # A correction/negative record is its own persisted type, not
                # silently folded into a positive verified example.
                self.assertNotEqual(correction, negative)

    def test_live_retrieval_excludes_classifier_version_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            with ClassificationMemory(Path(tmp) / "memory.sqlite3") as memory:
                stale_id = memory.record_verified(
                    subject="Business_9609", topics=["Inventory_management"],
                    question_text="Analyse Just in Time inventory control.",
                    evidence=["Controlled version-staleness fixture."],
                    classifier_version="classifier/old", taxonomy_version="taxonomy/1",
                    syllabus_version="syllabus/1",
                )
                stale = memory.retrieve(
                    subject="Business_9609", question_text="Analyse JIT inventory control.",
                    allowed_detailed_topics=["Inventory_management"],
                    classifier_version="classifier/current", taxonomy_version="taxonomy/1",
                    syllabus_version="syllabus/1",
                )
                self.assertEqual(stale.matches, ())
                current = memory.retrieve(
                    subject="Business_9609", question_text="Analyse JIT inventory control.",
                    allowed_detailed_topics=["Inventory_management"],
                    classifier_version="classifier/old", taxonomy_version="taxonomy/1",
                    syllabus_version="syllabus/1",
                )
                self.assertEqual([match.record_id for match in current.matches], [stale_id])
                self.assertEqual(
                    [row["id"] for row in memory.stale_records(
                        subject="Business_9609", classifier_version="classifier/current",
                    )],
                    [stale_id],
                )

    def test_explicit_legacy_jsonl_migration_creates_indexed_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            legacy = root / "classification_examples.jsonl"
            legacy.write_text(
                json.dumps({
                    "topic": "Inventory_management", "text": "Explain Just in Time inventory control.",
                    "verified": True, "paper": "9609_s24_qp_21", "variant": "21",
                }) + "\n" + json.dumps({
                    "topic": "Not_an_official_topic", "text": "Ignore this row.", "verified": True,
                }) + "\n",
                encoding="utf-8",
            )
            with ClassificationMemory(root / "memory.sqlite3") as memory:
                count = memory.import_legacy_examples(
                    legacy, subject="Business_9609",
                    detailed_topics=["Inventory_management"], major_topics=["Operations"],
                    taxonomy_version="t1", syllabus_version="s1", classifier_version="c1",
                )
                self.assertEqual(count, 1)
                context = memory.retrieve(
                    subject="Business_9609", question_text="Explain JIT inventory control.",
                    allowed_detailed_topics=["Inventory_management"], taxonomy_version="t1", syllabus_version="s1",
                )
                self.assertEqual(context.matches[0].variant, "21")

    def test_high_confidence_has_explicit_confidence_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            with ClassificationMemory(Path(tmp) / "memory.sqlite3") as memory:
                with self.assertRaises(ValueError):
                    memory.record_high_confidence(
                        subject="S", topics=["T"], confidence=0.89,
                        question_text="A meaningful assessed concept.", evidence=["fact"],
                    )

    def test_retrieval_is_subject_scoped_indexed_and_bounded(self):
        with tempfile.TemporaryDirectory() as tmp:
            with ClassificationMemory(Path(tmp) / "memory.sqlite3") as memory:
                target = memory.record_verified(
                    subject="Business_9609", topics=["Inventory_management"],
                    question_text="Analyse just in time inventory control for a retailer.",
                    evidence=["JIT inventory control is assessed."],
                )
                # Noise records prove another subject is not considered. This
                # is a small controlled stand-in for a large archive; the
                # implementation query additionally has a hard LIMIT.
                for i in range(40):
                    memory.record_verified(
                        subject="Other_0000", topics=["Other_topic"],
                        question_text=f"Unrelated specialised concept signal{i}.",
                        evidence=["unrelated"],
                    )
                context = memory.retrieve(
                    subject="Business_9609",
                    question_text="Evaluate a just-in-time inventory control system.",
                    allowed_detailed_topics=["Inventory_management"],
                    allowed_major_topics=["Operations"],
                    limit=3,
                )
                self.assertLessEqual(len(context.matches), 3)
                self.assertEqual([match.record_id for match in context.matches], [target])
                self.assertGreater(context.detailed_positive["Inventory_management"], 0)
                self.assertLessEqual(len(context.query_tokens), 36)
                indexes = [row[1] for row in memory._conn.execute("PRAGMA index_list(memory_tokens)")]  # noqa: SLF001
                self.assertIn("idx_memory_tokens_subject_token", indexes)


class TestMemoryEvidenceHierarchy(unittest.TestCase):
    def test_misleading_and_negative_memory_cannot_create_or_override_direct_topic(self):
        config = _memory_config()
        question = _matched("(a) Analyse a just-in-time inventory control system. [8]")
        with tempfile.TemporaryDirectory() as tmp:
            with ClassificationMemory(Path(tmp) / "memory.sqlite3") as memory:
                # Deliberately misleading historical association: same words,
                # wrong topic. It may be retrieved but cannot make Marketing
                # eligible because the current question has no direct marketing
                # QP/MS/taxonomy support.
                memory.record_verified(
                    subject=config.subject, topics=["The_marketing_mix"],
                    question_text="Analyse a just-in-time inventory control system.",
                    evidence=["Controlled misleading-memory fixture."],
                    classifier_version=CLASSIFIER_VERSION,
                    taxonomy_version=config.version, syllabus_version="2024",
                )
                memory.record_negative(
                    subject=config.subject, incorrect_topics=["Inventory_management"],
                    question_text="Analyse a just-in-time inventory control system.",
                    reason="Controlled negative-memory fixture.",
                    classifier_version=CLASSIFIER_VERSION,
                    taxonomy_version=config.version, syllabus_version="2024",
                )
                result = TopicClassifier(config, classification_memory=memory).classify_question(
                    question,
                    mark_scheme_text="Indicative content: Just in Time inventory management and stock control.",
                )
        self.assertEqual(result.winning_major, "Operations")
        self.assertIn("Inventory_management", result.detailed_topics)
        self.assertNotIn("The_marketing_mix", result.detailed_topics)
        audit = result.evidence_summary
        self.assertGreaterEqual(audit["memory"]["retrieved_count"], 1)
        self.assertIn("Inventory_management", audit["memory_topic_effects"])
        self.assertNotIn("The_marketing_mix", audit["memory_topic_effects"])

    def test_cross_variant_memory_is_support_not_duplicate_detection(self):
        config = _memory_config()
        question = _matched("(a) Analyse just-in-time inventory control. [8]", number=1)
        with tempfile.TemporaryDirectory() as tmp:
            with ClassificationMemory(Path(tmp) / "memory.sqlite3") as memory:
                # A different component variant is useful related evidence, but
                # this creates one memory record only; it never invokes or
                # substitutes for the variant-scoped duplicate subsystem.
                memory.record_verified(
                    subject=config.subject, paper="9999_s24_qp_21", variant="21",
                    question_number="Q1", topics=["Inventory_management"],
                    question_text="Analyse Just in Time inventory control for a retailer.",
                    evidence=["Human-reviewed cross-variant fixture."],
                    classifier_version=CLASSIFIER_VERSION,
                    taxonomy_version=config.version, syllabus_version="2024",
                )
                result = TopicClassifier(config, classification_memory=memory).classify_question(
                    question, mark_scheme_text="Just in Time inventory management."
                )
        matches = result.evidence_summary["memory"]["matches"]
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["variant"], "21")
        self.assertIn("Inventory_management", result.detailed_topics)

    def test_ambiguous_multi_topic_question_retains_only_material_topics(self):
        config = _memory_config()
        question = _matched(
            "(a) Analyse just-in-time inventory control and calculate contribution at break-even. [10]",
            marks=10,
        )
        result = TopicClassifier(config).classify_question(
            question,
            mark_scheme_text="JIT inventory management, contribution and break-even analysis are assessed.",
        )
        self.assertIn("Inventory_management", result.detailed_topics)
        self.assertIn("Costs", result.detailed_topics)
        self.assertLessEqual(len(result.detailed_topics), 4)

    def test_raw_ms_is_used_but_cropper_placeholder_is_ignored(self):
        config = _memory_config()
        question = _matched("(a) Explain the purpose of just in time. [3]")
        classifier = TopicClassifier(config)
        placeholder = classifier.classify_question(
            question, mark_scheme_text="Mark scheme for question 1"
        )
        raw = classifier.classify_question(
            question,
            mark_scheme_text=(
                "Question 1. Indicative content: the purpose of Just in Time "
                "inventory management and stock control."
            ),
        )
        self.assertFalse(placeholder.evidence_summary["mark_scheme"]["available"])
        self.assertTrue(raw.evidence_summary["mark_scheme"]["available"])
        self.assertIn("Inventory_management", raw.evidence_summary["mark_scheme"]["topic_hits"])
        self.assertIn("Inventory_management", raw.detailed_topics)

    def test_high_confidence_records_are_buffered_until_explicit_flush(self):
        config = _memory_config()
        matched = _matched("(a) Analyse just-in-time inventory control. [8]")
        classification = TopicClassifier(config).classify_question(
            matched,
            mark_scheme_text="Just in Time inventory management is assessed.",
        )
        # Make the controlled flushing property independent of a margin value.
        classification.confidence = 0.99
        with tempfile.TemporaryDirectory() as tmp:
            with ClassificationMemory(Path(tmp) / "memory.sqlite3") as memory:
                queue: list[dict] = []
                _queue_high_confidence_memory_record(
                    queue, matched=matched, classification=classification, config=config,
                    mark_scheme_text="Just in Time inventory management is assessed.", threshold=0.95,
                )
                self.assertEqual(memory.stats()["records"], 0)
                self.assertEqual(len(queue), 1)
                self.assertEqual(_flush_high_confidence_memory_records(memory, queue), 1)
                self.assertEqual(memory.stats()["by_trust_level"], {"high_confidence": 1})


class TestBareMarkSchemeQuestionLabels(unittest.TestCase):
    def test_context_qualified_bare_labels_exclude_front_matter_and_rubrics(self):
        # A naked number is not evidence by itself. The parser admits it only
        # next to a genuine command stem, or an AO/Indicative section when it
        # repeats an already-started question.
        self.assertEqual(
            MarkSchemeEvidenceIndex._question_labels(  # noqa: SLF001 - parser unit boundary
                ["1", "Components using point-based marking", "2", "Calculation questions"],
                current_question=None,
            ),
            [],
        )
        self.assertEqual(
            MarkSchemeEvidenceIndex._question_labels(  # noqa: SLF001 - parser unit boundary
                ["1", "Analyse two advantages to a business of flexible contracts"],
                current_question=None,
            ),
            [(0, 1)],
        )
        self.assertEqual(
            MarkSchemeEvidenceIndex._question_labels(  # noqa: SLF001 - parser unit boundary
                ["1", "AO2 Application", "Limited application"],
                current_question=1,
            ),
            [(0, 1)],
        )

    @unittest.skipUnless(BUSINESS_31_MS.is_file(), "authentic Business 9609/31 M/J 2024 MS fixture unavailable")
    def test_authentic_paper3_bare_labels_index_every_question(self):
        index = MarkSchemeEvidenceIndex.from_pdf(BUSINESS_31_MS)
        self.assertEqual(index.question_numbers, (1, 2, 3, 4, 5))
        self.assertIn("flexible part-time employment contracts", index.text_for_question(1).lower())
        self.assertIn("communication process innovation", index.text_for_question(2).lower())
        self.assertIn("accounting rate of return", index.text_for_question(3).lower())
        self.assertIn("price elasticity of demand", index.text_for_question(4).lower())
        self.assertIn("corporate social responsibility", index.text_for_question(5).lower())

    def test_final_validator_uses_historical_profile_from_canonical_metadata(self):
        # The canonical schema remains unchanged; this proves the validator
        # selects the existing year-specific profile from its normal paper/year
        # fields instead of incorrectly judging 2024 topics against 2026 only.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "output"
            folder = (root / "A-Level" / "Business_9609" / "paper-3" /
                      "Operations_and_project_management" / "31_Summer_2024_Q2")
            folder.mkdir(parents=True)
            (folder / "metadata.json").write_text(json.dumps({
                "id": "Business_9609_31_Summer_2024_Q2",
                "level": "A-Level", "subject": "Business_9609", "board": "CIE",
                "topic": ["Operations_and_project_management", "Operations_strategy"],
                "paper": "9609_s24_qp_31", "question_number": "Q2",
                "variant": "31", "season": "Summer", "year": "2024",
            }), encoding="utf-8")
            validator = FinalValidator(root)
            validator.check_topic_classification()
            self.assertEqual(validator.errors, [])
            validator.errors = []
            validator.check_no_cross_contamination()
            self.assertEqual(validator.errors, [])


@unittest.skipUnless(BUSINESS_MS.is_file(), "authentic Business 9609/22 M/J 2024 MS fixture unavailable")
class TestAuthenticBusiness2024Evidence(unittest.TestCase):
    def test_historical_profile_is_explicitly_syllabus_backed(self):
        config = load_subject_config_by_code_and_level("9609", "A-Level", "2024")
        self.assertIsNotNone(config)
        self.assertEqual(config.config_path.parent.name, "2024")
        self.assertTrue(config.year_verified)
        self.assertFalse(config.year_review_required)
        self.assertEqual(config.version, "9609-2023-2025-official-profile/5")
        self.assertIn("Inventory_management", config.detailed_topics)
        self.assertIn("Human_resource_management", config.detailed_topics)
        self.assertNotIn("Strategic_management", config.data["paper_topics"]["2"])

    def test_raw_mark_scheme_index_extracts_substantive_whole_question_evidence(self):
        index = MarkSchemeEvidenceIndex.from_pdf(BUSINESS_MS)
        self.assertEqual(index.question_numbers, (1, 2))
        q1, q2 = index.for_question(1), index.for_question("Q2")
        self.assertEqual(q1.pages, tuple(range(12, 28)))
        self.assertEqual(q2.pages, tuple(range(28, 44)))
        self.assertIn("private limited company", q1.text.lower())
        self.assertIn("assessment centre", q1.text.lower())
        self.assertIn("effective packaging", q1.text.lower())
        self.assertIn("mass market", q2.text.lower())
        self.assertIn("break-even", q2.text.lower())
        self.assertIn("JIT", q2.text)
        self.assertIn("small business", q2.text.lower())

    @unittest.skipUnless(BUSINESS_31_MS.is_file(), "authentic Business 9609/31 M/J 2024 MS fixture unavailable")
    def test_paper3_scope_and_official_terms_classify_known_2024_stems(self):
        # These are literal prompts from the official 9609/31 QP. The asserted
        # identifiers are the matching official 2023–25 sections: 7.4, 8.1 and
        # 6.1.3/6.1.7. This is a regression of source-backed behaviour, not an
        # independently measured archive-accuracy claim.
        config = load_subject_config_by_code_and_level("9609", "A-Level", "2024")
        index = MarkSchemeEvidenceIndex.from_pdf(BUSINESS_31_MS)
        classifier = TopicClassifier(config)
        q1 = _matched(
            "Analyse two advantages to GBS of using flexible part-time employment contracts. [8]",
            number=1, marks=8, variant="31", syllabus_code="9609",
        )
        q4 = _matched(
            "(a) Calculate the price elasticity of demand (PED) for GBS’s gravel product "
            "when the price decreased from $90 to $81 per tonne. [4]",
            number=4, marks=4, variant="31", syllabus_code="9609",
        )
        q5 = _matched(
            "Evaluate the extent to which corporate social responsibility (CSR) should influence "
            "GBS’s decision to expand into new land. [12]",
            number=5, marks=12, variant="31", syllabus_code="9609",
        )
        r1 = classifier.classify_question(q1, mark_scheme_text=index.text_for_question(1))
        r4 = classifier.classify_question(q4, mark_scheme_text=index.text_for_question(4))
        r5 = classifier.classify_question(q5, mark_scheme_text=index.text_for_question(5))
        self.assertEqual(r1.winning_major, "People_in_organisations")
        self.assertIn("Human_resource_management_strategy", r1.detailed_topics)
        self.assertEqual(r4.winning_major, "Marketing")
        self.assertIn("Marketing_analysis", r4.detailed_topics)
        self.assertNotIn("The_marketing_mix", r4.detailed_topics)
        self.assertEqual(r5.winning_major, "Strategic_management")
        self.assertIn("External_influences_on_business_activity", r5.detailed_topics)
        self.assertNotIn("Business_objectives", r5.detailed_topics)
        for result in (r1, r4, r5):
            self.assertTrue(result.evidence_summary["paper_scope"]["detailed_scope_enforced"])
            self.assertTrue(result.evidence_summary["mark_scheme"]["available"])

    def test_real_published_question_prompts_stay_capped_and_syllabus_normalized(self):
        # Exact/near-exact prompt content from the authentic 9609/22 QP. This
        # controlled functional assertion is source-grounded, not an external
        # human adjudication accuracy claim.
        q1 = _matched(
            "(a)(i) Identify one feature of a private limited company. [1]\n"
            "(a)(ii) Explain the term sustainability. [3]\n"
            "(b)(i) Calculate the variances and state whether each variance is favourable or adverse. [3]\n"
            "(b)(ii) Explain one benefit of using incremental budgeting. [3]\n"
            "(c) Analyse one advantage and one disadvantage of using an assessment centre when selecting a marketing manager. [8]\n"
            "(d) Evaluate the role of effective packaging. [12]",
            number=1, marks=30,
        )
        q2 = _matched(
            "(a)(i) Identify one type of training. [1]\n"
            "(a)(ii) Explain the term mass market. [3]\n"
            "(b)(i) Calculate contribution per unit. [3]\n"
            "(b)(ii) Explain one limitation of break-even analysis. [3]\n"
            "(c) Analyse two disadvantages of adopting a JIT approach to inventory management. [8]\n"
            "(d) Evaluate the importance of being a small business. [12]",
            number=2, marks=30,
        )
        index = MarkSchemeEvidenceIndex.from_pdf(BUSINESS_MS)
        classifier = TopicClassifier(load_subject_config_by_code_and_level("9609", "A-Level", "2024"))
        result1 = classifier.classify_question(q1, mark_scheme_text=index.text_for_question(1))
        result2 = classifier.classify_question(q2, mark_scheme_text=index.text_for_question(2))
        self.assertLessEqual(len(result1.detailed_topics), 4)
        self.assertLessEqual(len(result2.detailed_topics), 4)
        self.assertIn("The_marketing_mix", result1.detailed_topics)
        self.assertIn("Budgets", result1.detailed_topics)
        self.assertIn("Human_resource_management", result1.detailed_topics)
        self.assertIn("Inventory_management", result2.detailed_topics)
        self.assertIn("Costs", result2.detailed_topics)
        self.assertIn("Size_of_business", result2.detailed_topics)
        self.assertIn("The_nature_of_marketing", result2.detailed_topics)
        self.assertTrue(result1.evidence_summary["mark_scheme"]["available"])
        self.assertTrue(result2.evidence_summary["mark_scheme"]["available"])


if __name__ == "__main__":
    unittest.main()
