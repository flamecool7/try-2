@echo off
setlocal EnableExtensions DisableDelayedExpansion

title ExamVoid Topical Archive Generator

rem ============================================================================
rem ExamVoid Production Launcher
rem
rem Simple, reliable launcher establishing the working directory, activating the
rem Python environment, launching the ExamVoid application / control center,
rem and propagating the exit code cleanly.
rem
rem Python application layer owns:
rem   - Interactive control menu
rem   - Incremental manifest and change detection
rem   - Single-instance locking and dead PID stale lock auto-recovery
rem   - Graceful shutdown and resource cleanup
rem   - Archive auditing and statistics
rem   - Real performance benchmarks and developer tools
rem ============================================================================

rem 1. Establish the correct working directory
cd /d "%~dp0"
if errorlevel 1 (
    echo [ERROR] Could not switch to repository directory: "%~dp0"
    exit /b 1
)

rem 2. Basic startup validation
if not exist "run_pipeline.py" (
    echo [ERROR] run_pipeline.py was not found beside run.bat.
    echo Please ensure run.bat is located in the root of the ExamVoid project.
    pause
    exit /b 1
)

rem 3. Find and activate the appropriate Python runtime
set "PYTHON_EXE="
set "PYTHON_ARGS="
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=.venv\Scripts\python.exe"
if not defined PYTHON_EXE if exist "venv\Scripts\python.exe" set "PYTHON_EXE=venv\Scripts\python.exe"
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where py.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
    if defined PYTHON_EXE set "PYTHON_ARGS=-3"
)
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)
if not defined PYTHON_EXE (
    echo [ERROR] Python 3 was not found on PATH or in a virtual environment.
    echo Please install Python 3.10+ and ensure Python is added to PATH.
    pause
    exit /b 1
)

rem 4. Launch the ExamVoid application / CLI
if "%~1"=="" (
    "%PYTHON_EXE%" %PYTHON_ARGS% run_pipeline.py --menu
) else (
    "%PYTHON_EXE%" %PYTHON_ARGS% run_pipeline.py %*
)

set "APP_EXIT=%ERRORLEVEL%"

rem 5. Return cleanly with the application exit code
exit /b %APP_EXIT%
