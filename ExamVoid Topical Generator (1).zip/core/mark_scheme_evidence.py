"""Read-only mark-scheme evidence extraction for classification.

The cropper's mark-scheme wrapper intentionally returns image crops and a
placeholder text field.  This module does *not* change that behavior: it reads
the original mark-scheme PDF independently, indexes question-labelled text in
memory, and gives classifiers substantive evidence for the matching question.
No crop coordinate, image, PDF, output bundle, or metadata document is edited.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Mapping


EXTRACTION_VERSION = "mark-scheme-evidence/1"
# The label is deliberately strict enough not to confuse mark allocations such
# as "1 mark" with a question/subquestion label.  It supports 1(a), 1(a)(i),
# and common "Question 1(a)" text-extraction variants.
_QUESTION_LABEL = re.compile(
    r"^(?:question\s+)?([1-9][0-9]?)\s*\([a-z]\)(?:\s*\([ivxlcdm]+\))?(?=\s|$)",
    re.IGNORECASE,
)
# Some structured Cambridge components (for example Business 9609 Paper 3)
# label their whole-question mark-scheme pages simply ``1`` or ``Question 1``
# rather than ``1(a)``. A bare numeral cannot be accepted blindly: front matter
# and level descriptors contain many numbers. It is therefore admitted only
# when the following text has a question-stem or question-section shape.
_BARE_QUESTION_LABEL = re.compile(r"^(?:question\s+)?([1-9][0-9]?)\.?$", re.IGNORECASE)
_BARE_QUESTION_STEM = re.compile(
    r"^(?:analyse|analyze|assess|calculate|comment|define|describe|determine|"
    r"discuss|evaluate|explain|identify|outline|recommend|state|suggest|"
    r"to\s+what\s+extent)",
    re.IGNORECASE,
)
_BARE_QUESTION_SECTION = re.compile(
    r"^(?:note:|indicative content|level$|ao[1-4]\b)",
    re.IGNORECASE,
)
_PAGE_NUMBER = re.compile(r"^page\s+\d+\s+of\s+\d+$", re.IGNORECASE)
_DOCUMENT_NOISE = re.compile(
    r"^(?:\d{4}/\d{2}|cambridge international .*mark scheme|published|"
    r"may/june\s+\d{4}|©\s*cambridge university.*|question\s+answer\s+marks)$",
    re.IGNORECASE,
)


class MarkSchemeEvidenceError(RuntimeError):
    """Raised only when source-PDF evidence cannot be read."""


@dataclass(frozen=True)
class MarkSchemeEvidence:
    """Substantive source text for one whole question, including subparts."""

    question_number: int
    text: str
    pages: tuple[int, ...]
    source_path: str
    extraction_version: str = EXTRACTION_VERSION

    @property
    def available(self) -> bool:
        return bool(self.text.strip())

    def concise_excerpt(self, max_chars: int = 900) -> str:
        return self.text[:max_chars].strip()

    def audit_dict(self) -> dict:
        return {
            "question_number": self.question_number,
            "available": self.available,
            "page_numbers": list(self.pages),
            "character_count": len(self.text),
            "source_path": self.source_path,
            "extraction_version": self.extraction_version,
        }


class MarkSchemeEvidenceIndex:
    """An in-memory, read-only question-to-mark-scheme-text index.

    The source PDF is parsed once per paper.  Subsequent question lookups are
    dictionary lookups, not repeated scans.  The parser only consumes raw PDF
    text and has no dependency on, or side effect on, the locked crop engines.
    """

    def __init__(self, *, source_path: str, evidence: Mapping[int, MarkSchemeEvidence]):
        self.source_path = str(source_path)
        self._evidence = dict(evidence)

    @classmethod
    def from_pdf(cls, pdf_path: str | Path, *, max_chars_per_question: int = 30000) -> "MarkSchemeEvidenceIndex":
        """Build a read-only index from a raw mark-scheme PDF.

        A question starts at an unambiguous subpart label such as ``1(a)(ii)``
        or at a context-qualified whole-question label such as ``Question 1``.
        Text on continuation pages without another label stays with the prior
        question, while front matter before the first labelled question is
        excluded.
        """
        path = Path(pdf_path)
        if not path.is_file():
            raise MarkSchemeEvidenceError(f"mark-scheme PDF not found: {path}")
        try:
            import fitz  # PyMuPDF; deliberately optional at module import time.
        except ImportError as exc:  # pragma: no cover - environment dependent
            raise MarkSchemeEvidenceError(
                "PyMuPDF is required to read raw mark-scheme evidence"
            ) from exc

        by_question: dict[int, list[str]] = defaultdict(list)
        pages_by_question: dict[int, list[int]] = defaultdict(list)
        current_question: int | None = None
        try:
            with fitz.open(path) as document:
                for page_number, page in enumerate(document, 1):
                    raw_lines = page.get_text("text").splitlines()
                    lines = cls._clean_lines(raw_lines)
                    labels = cls._question_labels(lines, current_question)
                    if not labels:
                        # This is a continuation only when a question has
                        # already begun; title/annotation pages stay excluded.
                        if current_question is not None and lines:
                            cls._append_fragment(
                                by_question, pages_by_question, current_question,
                                page_number, "\n".join(lines), max_chars_per_question,
                            )
                        continue

                    # Prefix before the first label can be a continuation from
                    # the previous question on a page where a new question
                    # begins part-way through.
                    first_index = labels[0][0]
                    if current_question is not None and first_index > 0:
                        cls._append_fragment(
                            by_question, pages_by_question, current_question,
                            page_number, "\n".join(lines[:first_index]), max_chars_per_question,
                        )
                    for position, (start, number) in enumerate(labels):
                        end = labels[position + 1][0] if position + 1 < len(labels) else len(lines)
                        fragment = "\n".join(lines[start:end])
                        cls._append_fragment(
                            by_question, pages_by_question, number, page_number,
                            fragment, max_chars_per_question,
                        )
                        current_question = number
        except Exception as exc:
            if isinstance(exc, MarkSchemeEvidenceError):
                raise
            raise MarkSchemeEvidenceError(f"could not parse mark-scheme PDF {path}: {exc}") from exc

        evidence = {
            number: MarkSchemeEvidence(
                question_number=number,
                text="\n".join(fragments).strip(),
                pages=tuple(pages_by_question[number]),
                source_path=str(path),
            )
            for number, fragments in by_question.items()
            if "\n".join(fragments).strip()
        }
        return cls(source_path=str(path), evidence=evidence)

    @staticmethod
    def _question_labels(lines: list[str], current_question: int | None) -> list[tuple[int, int]]:
        """Return safe question starts from one already-cleaned PDF page.

        Standard subpart labels are unambiguous. A bare question number is
        accepted only where its following line looks like an actual question
        stem (or, for a continuation of the current question, a question
        section such as ``AO2`` or ``Indicative content``). This preserves the
        front-matter exclusion rule and prevents rubric numbers such as
        ``1`` / ``2`` from becoming fictitious questions.
        """
        labels: list[tuple[int, int]] = []
        for index, line in enumerate(lines):
            match = _QUESTION_LABEL.match(line)
            if match:
                labels.append((index, int(match.group(1))))
                continue
            bare = _BARE_QUESTION_LABEL.match(line)
            if not bare:
                continue
            number = int(bare.group(1))
            # Scan just the immediate remaining textual context. Cleaning has
            # already removed blank/header lines, so this is bounded and cannot
            # drift into an unrelated next question.
            following = lines[index + 1:index + 4]
            if not following:
                continue
            # A stand-alone numeral immediately before a real subpart label is
            # a mark allocation (e.g. the ``1`` before ``2(a)(ii)``), not a
            # repeated whole-question header.
            if any(_QUESTION_LABEL.match(candidate) for candidate in following):
                continue
            first = following[0]
            if _BARE_QUESTION_STEM.match(first):
                labels.append((index, number))
                continue
            # Repeated bare labels on continuation pages are valid only after
            # an actual question has begun and only for that same question.
            if number == current_question and any(
                _BARE_QUESTION_SECTION.match(candidate) for candidate in following
            ):
                labels.append((index, number))
        return labels

    @staticmethod
    def _clean_lines(lines: list[str]) -> list[str]:
        cleaned: list[str] = []
        for raw in lines:
            line = re.sub(r"\s+", " ", str(raw or "")).strip()
            if (not line or _PAGE_NUMBER.match(line) or _DOCUMENT_NOISE.match(line)
                    or line.lower() in {"question", "answer", "marks"}):
                continue
            cleaned.append(line)
        return cleaned

    @staticmethod
    def _append_fragment(by_question: dict[int, list[str]],
                         pages_by_question: dict[int, list[int]], number: int,
                         page_number: int, fragment: str, maximum: int) -> None:
        if not fragment.strip():
            return
        current_size = sum(len(item) + 1 for item in by_question[number])
        remaining = max(0, maximum - current_size)
        if remaining <= 0:
            return
        by_question[number].append(fragment[:remaining])
        if page_number not in pages_by_question[number]:
            pages_by_question[number].append(page_number)

    @staticmethod
    def _normalise_question_number(value: int | str) -> int | None:
        if isinstance(value, int):
            return value if value > 0 else None
        match = re.search(r"\d+", str(value or ""))
        return int(match.group(0)) if match else None

    def for_question(self, question_number: int | str) -> MarkSchemeEvidence:
        number = self._normalise_question_number(question_number)
        if number is not None and number in self._evidence:
            return self._evidence[number]
        return MarkSchemeEvidence(
            question_number=number or 0,
            text="",
            pages=(),
            source_path=self.source_path,
        )

    def text_for_question(self, question_number: int | str, *, max_chars: int = 12000) -> str:
        """Return bounded substantive text for classifier input."""
        return self.for_question(question_number).text[:max(0, int(max_chars))]

    @property
    def question_numbers(self) -> tuple[int, ...]:
        return tuple(sorted(self._evidence))

    def audit_summary(self) -> dict:
        return {
            "source_path": self.source_path,
            "extraction_version": EXTRACTION_VERSION,
            "question_numbers": list(self.question_numbers),
            "questions": [self.for_question(number).audit_dict() for number in self.question_numbers],
        }
