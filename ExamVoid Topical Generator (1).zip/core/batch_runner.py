"""Batch orchestrator (Overseer batch-infrastructure spec, Phase 5 — honest
port; the spec text targeted the fictional cambridge_qb.pipeline module).

Main entry point for batch processing:

    preflight (main process, scans input + registers bundles in SQLite)
      -> work queue from the database (resume / retry_failed supported)
      -> bounded worker execution (sequential at workers==1, bounded
         ProcessPoolExecutor otherwise; concurrency clamped by the measured
         RAM guard from pipeline.py so a batch can never OOM itself)
      -> examiner-report attach + final locked audit ONCE over the real
         output tree, after all workers (same shape as pipeline.py S6/S7/S8)
      -> progress report from the database (single source of truth)

Audited deviations from the spec text (receipts in the round evidence log):
  * file homes: cambridge_qb/* does not exist; the port lives in core/.
    root pipeline.py is already the approved efficiency-round orchestrator,
    so this runner is core/batch_runner.py with run_pipeline.py as the CLI.
  * workers never rescan the input directory (pre-built args from the DB)
    and never reload all 23 subject configs.
  * the RAM guard calibration is real (measured worker peaks, RS-2) rather
    than the spec's unchecked use of the requested worker count.
"""

import logging
import os
import re
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

logger = logging.getLogger(__name__)


def _auto_worker_request() -> int:
    """Choose a conservative requested worker count before the RAM guard.

    Cropping workers are memory-heavy isolated processes.  This is only the
    *request*; ``pipeline.guard_decision`` remains authoritative and clamps
    it again using currently available memory immediately before work starts.
    """
    total_mb = None
    try:
        import psutil
        total_mb = int(psutil.virtual_memory().total // (1024 * 1024))
    except Exception:
        try:
            with open("/proc/meminfo", encoding="ascii") as fh:
                for line in fh:
                    if line.startswith("MemTotal:"):
                        total_mb = int(line.split()[1]) // 1024
                        break
        except OSError:
            pass

    if total_mb is not None and total_mb >= 16 * 1024:
        requested = 6
    elif total_mb is not None and total_mb >= 12 * 1024:
        requested = 4
    else:
        requested = 2
    cpu_count = os.cpu_count() or requested
    return max(1, min(requested, cpu_count))


def _safe_console_output():
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(errors="replace")
        except Exception:
            pass


_safe_console_output()


def _handle_result(result: dict):
    status = result["status"]
    key = result["bundle_key"]

    if status == "complete":
        q = result.get("questions", 0)
        r = result.get("needs_review", [])
        logger.info(f"[OK] {key}: {q} questions ({len(r)} need review)")
        print(f"  [OK] {key}: {q} questions ({len(r)} need review)")
    elif status == "already_complete":
        print(f"  [SKIP] {key}: already complete (resume-skip)")
    elif status == "failed":
        logger.error(f"[FAIL] {key}: {result.get('error', 'unknown')}")
        print(f"  [FAIL] {key}: {result.get('error', 'unknown')}")
    elif status == "review_required":
        logger.warning(f"[REVIEW] {key}: {result.get('reason', '')}")
        print(f"  [REVIEW] {key}: {result.get('reason', '')}")



def _normalise_session_filter(value: str):
    """Return (season, year_short|None) for a friendly session filter."""
    text = str(value or "").strip().lower()
    if not text:
        return None, None
    text = text.replace("/", "-").replace("_", "-").replace(" ", "-")
    aliases = {
        "spring": "m", "february-march": "m", "february-march-spring": "m",
        "summer": "s", "may-june": "s", "may-june-summer": "s",
        "winter": "w", "october-november": "w", "october-november-winter": "w",
        "specimen": "sp", "spec": "sp",
    }
    if text in aliases:
        return aliases[text], None
    for label, season_code in (
        ("spring", "m"), ("february-march", "m"),
        ("summer", "s"), ("may-june", "s"),
        ("winter", "w"), ("october-november", "w"),
        ("specimen", "sp"), ("spec", "sp"),
    ):
        named = re.fullmatch(re.escape(label) + r"-?(20\d{2}|\d{2})", text)
        if named:
            return season_code, named.group(1)[-2:]
    match = re.fullmatch(r"(sp|spec|specimen|mj|on|fm|f|m|s|j|w|n)-?(20\d{2}|\d{2})", text)
    if match:
        season = {
            "mj": "s", "j": "s", "on": "w", "n": "w",
            "fm": "m", "f": "m", "spec": "sp", "specimen": "sp",
        }.get(match.group(1), match.group(1))
        return season, match.group(2)[-2:]
    if re.fullmatch(r"20\d{2}", text):
        return None, text[-2:]
    if text in {"m", "s", "w", "sp"}:
        return text, None
    return text, None


def _path_matches_scope(path_value, selected_paths=None, selected_folder=None) -> bool:
    """Return whether a bundle input path belongs to an explicit user scope."""
    if not selected_paths and not selected_folder:
        return True
    if not path_value:
        return False
    candidate = Path(path_value).resolve()
    if selected_paths and str(candidate) in selected_paths:
        return True
    if selected_folder:
        try:
            candidate.relative_to(Path(selected_folder).resolve())
            return True
        except ValueError:
            pass
    return False


def _row_matches_filters(row, *, session=None, year=None, subject=None,
                         syllabus_code=None, level=None, variant=None,
                         selected_paths=None, selected_folder=None) -> bool:
    if session:
        season, session_year = _normalise_session_filter(session)
        if season and str(row["season"]).lower() != season:
            return False
        if session_year and str(row["year"])[-2:] != session_year:
            return False
    if year:
        year_text = str(year).strip()
        if len(year_text) == 4:
            year_text = year_text[-2:]
        if str(row["year"])[-2:] != year_text:
            return False
    if subject and str(subject).casefold() not in str(row["subject"]).casefold():
        return False
    if syllabus_code and str(row["syllabus_code"]) != str(syllabus_code):
        return False
    if level and str(row["level"]).casefold() != str(level).casefold():
        return False
    if variant and str(row["component"]) != str(variant):
        return False
    if selected_paths or selected_folder:
        paths = (row["qp_path"] if "qp_path" in row.keys() else None,
                 row["ms_path"] if "ms_path" in row.keys() else None,
                 row["er_path"] if "er_path" in row.keys() else None,
                 row["insert_path"] if "insert_path" in row.keys() else None,
                 row["ci_path"] if "ci_path" in row.keys() else None)
        if not any(_path_matches_scope(p, selected_paths, selected_folder) for p in paths):
            return False
    return True


def _filters_active(session=None, year=None, subject=None,
                    syllabus_code=None, level=None, variant=None,
                    selected_paths=None, selected_folder=None) -> bool:
    return any(value not in (None, "") for value in
               (session, year, subject, syllabus_code, level, variant,
                selected_paths, selected_folder))


def _filtered_status_counts(db, *, session=None, year=None, subject=None,
                            syllabus_code=None, level=None, variant=None,
                            selected_paths=None, selected_folder=None) -> dict:
    with db._conn() as conn:
        rows = conn.execute("""
            SELECT b.*, qp.path AS qp_path, ms.path AS ms_path, er.path AS er_path,
                   ins.path AS insert_path, ci.path AS ci_path
            FROM bundles b
            LEFT JOIN files qp ON b.qp_file_id=qp.id
            LEFT JOIN files ms ON b.ms_file_id=ms.id
            LEFT JOIN files er ON b.er_file_id=er.id
            LEFT JOIN files ins ON b.insert_file_id=ins.id
            LEFT JOIN files ci ON b.ci_file_id=ci.id
        """).fetchall()
    counts = {}
    for row in rows:
        if _row_matches_filters(row, session=session, year=year, subject=subject,
                                syllabus_code=syllabus_code, level=level,
                                variant=variant, selected_paths=selected_paths,
                                selected_folder=selected_folder):
            status = str(row["status"])
            counts[status] = counts.get(status, 0) + 1
    return counts


def _post_run_attach_and_audit(db, output_dir: Path, touched_bundle_keys):
    """Verified ER visual attach + ER question crops + final archive audit.

    This runs once over the committed output tree after all workers. Product
    policy disables free-form ER text artifacts; only visual ER assets may be
    attached when identity verification succeeds.
    """
    from .paper_identifier import parse_paper_filename
    from .examiner_report import attach_examiner_reports_to_output
    from .er_question_crops import attach_question_er_crops
    from .output_manager import OutputManager
    from .validation import FinalValidator

    # ER inputs = every ER file this DB knows about (preflight registered
    # them this run or a prior resumed one).
    with db._conn() as conn:
        er_rows = conn.execute("SELECT path FROM files WHERE kind='er'").fetchall()
    er_papers = []
    for row in er_rows:
        info = parse_paper_filename(Path(row["path"]))
        if info is not None:
            er_papers.append(info)

    if er_papers:
        stats = attach_examiner_reports_to_output(er_papers, output_dir)
        print(f"  [ER] visual attach: {stats.get('questions_attached', 0)} question folder(s)"
              + (f", errors={stats['errors'][:2]}" if stats.get("errors") else ""))
        stats2 = attach_question_er_crops(er_papers, output_dir)
        print(f"  [ER] crops: {stats2.get('crops_written', 0)} written / "
              f"{stats2.get('verified', 0)} verified"
              + (f", errors={stats2['errors'][:2]}" if stats2.get("errors") else ""))
        _sync_er_artifacts(db, output_dir)
    else:
        print("  [ER] no ER papers supplied — stage skipped by design")

    removed = OutputManager(output_root=output_dir, target_width=2280, quality=95) \
        .cleanup_empty_and_invalid_folders()
    if removed:
        print(f"  [audit] cleanup removed {len(removed)} invalid folders")
    result = FinalValidator(output_root=str(output_dir)).validate_all()
    print(f"  [audit] final validation: {'PASSED' if result['passed'] else 'FAILED'} "
          f"(errors={result.get('total_errors', 0)})")
    return result


def _sync_er_artifacts(db, output_dir: Path):
    """Post-attach bookkeeping: ER crops land in question folders AFTER the
    worker's commit-time artifact registration, so they would otherwise be
    invisible to the artifacts table. Register any *_ER*.webp whose path is
    not already recorded (idempotent; DB remains the single truth).
    """
    from PIL import Image
    output_dir = Path(output_dir)
    with db._conn() as conn:
        known = {r["path"] for r in conn.execute("SELECT path FROM artifacts")}
        qrows = {r["folder_path"]: r["id"] for r in conn.execute("SELECT id, folder_path FROM questions")}
    added = 0
    for webp in output_dir.rglob("*_ER*.webp"):
        rel = str(webp.relative_to(output_dir))
        if rel in known:
            continue
        q_id = qrows.get(str(webp.parent.relative_to(output_dir)))
        if q_id is None:
            continue
        try:
            with Image.open(webp) as im:
                w, h = im.size
        except Exception:
            w = h = None
        db.register_artifact(question_id=q_id, kind="er", path=rel,
                             width_px=w, height_px=h, file_size=webp.stat().st_size)
        added += 1
    if added:
        print(f"  [ER] artifacts registered post-attach: {added} ER crop rows")


def _reconcile_manifest_from_database(db, manifest) -> int:
    """Repair manifest records after an ungraceful parent-process stop.

    SQLite commits each worker outcome transactionally; the JSON manifest is a
    durable incremental index written in batches. If power loss or SIGKILL
    happens between those writes, only entries whose DB terminal status differs
    are repaired here. This performs two indexed SQL reads and no output-tree
    rescan, even for a 10,000-file archive.
    """
    with db._conn() as conn:
        rows = conn.execute("""
            SELECT b.*, qp.path AS qp_path, ms.path AS ms_path, er.path AS er_path,
                   ins.path AS insert_path, ci.path AS ci_path
            FROM bundles b
            LEFT JOIN files qp ON b.qp_file_id=qp.id
            LEFT JOIN files ms ON b.ms_file_id=ms.id
            LEFT JOIN files er ON b.er_file_id=er.id
            LEFT JOIN files ins ON b.insert_file_id=ins.id
            LEFT JOIN files ci ON b.ci_file_id=ci.id
        """).fetchall()
        artifact_rows = conn.execute("""
            SELECT q.bundle_id, a.path
            FROM artifacts a JOIN questions q ON q.id=a.question_id
            ORDER BY a.id ASC
        """).fetchall()
    artifacts_by_bundle = {}
    for row in artifact_rows:
        artifacts_by_bundle.setdefault(int(row["bundle_id"]), []).append(str(row["path"]))

    repaired = 0
    for row in rows:
        status = str(row["status"])
        if status not in {"complete", "failed", "review_required"}:
            continue
        key = str(row["bundle_key"])
        existing = manifest.bundles.get(key)
        # Reconciliation may be refreshing DB-registered post-processing
        # assets (not a new processing attempt), so retain the original
        # terminal timestamp when the status itself was already correct.
        previous_processed_at = existing.last_processed if existing is not None else None
        current_artifacts = artifacts_by_bundle.get(int(row["id"]), [])
        same_terminal_status = existing is not None and str(existing.status).lower() == status
        same_artifacts = (
            status != "complete"
            or (existing is not None and set(existing.artifacts) == set(current_artifacts))
        )
        if same_terminal_status and same_artifacts:
            continue
        inputs = [Path(value) for value in (
            row["qp_path"], row["ms_path"], row["er_path"],
            row["insert_path"], row["ci_path"],
        ) if value]
        if status == "complete":
            manifest.record_bundle_completed(
                key, inputs, artifacts_by_bundle.get(int(row["id"]), []),
                int(row["questions_found"] or 0), int(row["questions_saved"] or 0),
            )
        elif status == "review_required":
            manifest.record_bundle_review(
                key, inputs, str(row["error_message"] or "needs review"),
                artifacts_by_bundle.get(int(row["id"]), []),
            )
        else:
            manifest.record_bundle_failed(
                key, inputs, str(row["error_message"] or "worker failed"),
            )
        if same_terminal_status and previous_processed_at is not None:
            manifest.bundles[key].last_processed = previous_processed_at
        repaired += 1

    if repaired:
        manifest.save(force=True)
    return repaired


def run_pipeline(
    pdf_dir: str,
    output_dir: str,
    topics_dir: str = "topics",
    workers: int = None,
    resume: bool = True,
    retry_failed: bool = False,
    force_all: bool = False,
    dry_run: bool = False,
    low_ram: bool = True,
    full_auto: bool = True,
    session: str | None = None,
    year_filter: str | None = None,
    subject_filter: str | None = None,
    syllabus_code_filter: str | None = None,
    level_filter: str | None = None,
    variant_filter: str | None = None,
    selected_paths: set[str] | None = None,
    selected_folder: str | None = None,
) -> dict:
    """
    Main entry point for batch processing.

    Args:
        pdf_dir:      Input directory containing PDFs
        output_dir:   Output directory for question bank
        topics_dir:   Accepted for spec-signature compatibility; the real
                      system resolves approved subject configs from
                      subjects/<Level>/<Subject>/config.json.
        workers:      Number of parallel workers (default: cpu_count // 2,
                      RAM-guard clamped)
        resume:       skip bundles the DB already marks complete (the DB is
                      queried for pending/failed work only, so a completed
                      bundle never re-runs unless retried)
        retry_failed: Re-attempt previously failed bundles
        dry_run:      Run preflight only, no processing
        low_ram:      Route QP cropping through the RAM-safe streaming path
                      (required on this 2GB box)
        full_auto:    Trust the deterministic classifier and categorize every
                      usable QP crop; false restores fail-closed review routing.
                      Defaults to True for the production policy.
        session:      Optional session filter (s26, summer, m26, winter, sp).
        year_filter:  Optional two- or four-digit exam-year filter.
        subject_filter: Optional case-insensitive subject-name filter.
        syllabus_code_filter: Optional exact syllabus-code filter.
        level_filter: Optional IGCSE or A-Level filter.
        variant_filter: Optional exact Cambridge component/variant filter,
                        e.g. ``21`` or ``42``.
        selected_paths: Optional set of absolute input paths. A matching
                        bundle is selected only when one of its components is
                        in this set.
        selected_folder: Optional directory scope. A matching bundle has at
                         least one component under this directory.

    Returns a summary dict (also printed).
    """
    import os
    from .database import Database
    from .preflight import Preflight
    from .bundle_worker import process_bundle

    pdf_dir = Path(pdf_dir)
    output_dir = Path(output_dir)

    if workers is None:
        workers = _auto_worker_request()

    # Dry runs must not create the output directory, SQLite database, manifest,
    # staging tree, or crop artifacts.  They reuse the real scanner/grouping
    # rules through Preflight.preview() but perform no state writes.
    if dry_run:
        preflight = Preflight(pdf_dir, output_dir, db=None)
        plan = preflight.preview(
            retry_failed=retry_failed,
            session=session,
            year=year_filter,
            subject=subject_filter,
            syllabus_code=syllabus_code_filter,
            level=level_filter,
            variant=variant_filter,
            selected_paths=selected_paths,
            selected_folder=selected_folder,
        )
        print("\nEXAMVOID DRY RUN")
        print(f"  Source files:       {plan['source_files']:,}")
        print(f"  Bundles in scope:   {plan['bundles_seen']:,}")
        print(f"  New:                {plan['new']:,}")
        print(f"  Changed:            {plan['changed']:,}")
        print(f"  Pending/resumable:  {plan['pending'] + plan['processing']:,}")
        print(f"  Failed:             {plan['failed']:,}")
        print(f"  Completed:          {plan['completed']:,}")
        print(f"  Needs review:       {plan['needs_review']:,}")
        print("  ------------------------------------------------")
        print(f"  Would process now:  {plan['would_process']:,}")
        if plan['failed'] and not plan['retry_failed']:
            print("  Note: failed bundles are shown but excluded; use --retry-failed to include them.")
        print("  No files or archive state will be modified.")
        return {"dry_run": True, "new_bundles": plan['new'] + plan['changed'], **plan}

    output_dir.mkdir(parents=True, exist_ok=True)

    # ── Initialise database ─────────────────────────
    db_path = output_dir / "pipeline.sqlite"
    db = Database(db_path)
    recovered = db.recover_interrupted_bundles()
    if recovered:
        print(f"[batch] Recovered {recovered} interrupted bundle(s) to pending state.")

    # ── Run preflight ───────────────────────────────
    preflight = Preflight(pdf_dir, output_dir, db)
    preflight._check_ram(workers)
    new_bundles = preflight.run()

    from .manifest import ProcessingManifest
    manifest = ProcessingManifest.load_or_create(output_dir)
    reconciled = _reconcile_manifest_from_database(db, manifest)
    if reconciled:
        print(f"  [manifest] Reconciled {reconciled} terminal bundle record(s) from SQLite.")
    msum = manifest.get_summary()
    print(f"  [manifest] Status: {msum['total_files']} files tracked ({msum['files_by_status'].get('COMPLETED', 0)} completed, {msum['files_by_status'].get('NEW', 0)} new, {msum['files_by_status'].get('CHANGED', 0)} changed)")

    # ── Get work queue ──────────────────────────────
    if force_all:
        print("[batch] --force-all active: re-queuing all known bundles.")
        with db._conn() as conn:
            # An explicit force reprocess intentionally resets retry counts;
            # otherwise an old failed bundle at attempts=3 would be silently
            # omitted from an action explicitly named "everything".
            conn.execute("""
                UPDATE bundles
                SET status='pending', attempts=0, error_message=NULL,
                    started_at=NULL, completed_at=NULL
            """)
    elif retry_failed:
        # Failed bundles are never silently retried in normal incremental
        # mode.  Only the explicit Resume / Retry Failed action returns
        # retryable failures to the pending queue.
        with db._conn() as conn:
            conn.execute("""
                UPDATE bundles
                SET status='pending', started_at=NULL
                WHERE status='failed'
                AND attempts < 3
            """)

    filter_active = _filters_active(
        session=session, year=year_filter, subject=subject_filter,
        syllabus_code=syllabus_code_filter, level=level_filter,
        variant=variant_filter, selected_paths=selected_paths,
        selected_folder=selected_folder,
    )
    pending = db.get_pending_bundles(include_failed=False)
    if not resume:
        # resume=False is used only by an explicitly confirmed force-all
        # operation. Reset attempts so the scope is genuinely comprehensive.
        with db._conn() as conn:
            conn.execute("UPDATE bundles SET status='pending', attempts=0, started_at=NULL")
        pending = db.get_pending_bundles(include_failed=False)
    if filter_active:
        pending = [row for row in pending if _row_matches_filters(
            row, session=session, year=year_filter, subject=subject_filter,
            syllabus_code=syllabus_code_filter, level=level_filter,
            variant=variant_filter, selected_paths=selected_paths,
            selected_folder=selected_folder,
        )]
        print("[batch] filters: "
              f"session={session or '-'} year={year_filter or '-'} "
              f"subject={subject_filter or '-'} code={syllabus_code_filter or '-'} "
              f"level={level_filter or '-'} variant={variant_filter or '-'} "
              f"selected_files={len(selected_paths or ()) or '-'} "
              f"selected_folder={selected_folder or '-'} -> {len(pending)} pending bundle(s)")

    if not pending:
        # Resume must still report unresolved state.  The old early return
        # treated a tree containing review_required bundles as clean simply
        # because there was no pending work left in SQLite.
        if filter_active:
            counts = _filtered_status_counts(
                db, session=session, year=year_filter, subject=subject_filter,
                syllabus_code=syllabus_code_filter, level=level_filter,
                variant=variant_filter, selected_paths=selected_paths,
                selected_folder=selected_folder,
            )
        else:
            with db._conn() as conn:
                rows = conn.execute(
                    "SELECT status, COUNT(*) AS n FROM bundles GROUP BY status"
                ).fetchall()
            counts = {str(row["status"]): int(row["n"]) for row in rows}
        review_existing = counts.get("review_required", 0)
        failed_existing = counts.get("failed", 0)
        unresolved = counts.get("pending", 0) + counts.get("processing", 0)
        if unresolved:
            failed_existing += unresolved
            print(f"Found {unresolved} bundle(s) still pending/processing; "
                  "failing closed instead of reporting a clean resume.")

        print("No bundles to process.")
        audit = None
        if counts.get("complete", 0) or review_existing:
            audit = _post_run_attach_and_audit(db, output_dir, [])
        db.print_progress()
        return {
            "processed": 0,
            "complete": counts.get("complete", 0),
            "failed": failed_existing,
            "review_required": review_existing,
            "new_bundles": new_bundles,
            "results": [],
            "audit_passed": (audit or {}).get("passed"),
        }

    # Measured RAM guard (pipeline.py): clamp concurrency, loudly.
    try:
        from pipeline import available_mem_mb, guard_decision
        conc, reasons = guard_decision(workers, available_mem_mb())
        for r in reasons:
            print(f"[batch] {r}")
    except Exception:
        conc = max(1, workers)

    print(
        f"Processing {len(pending)} bundles "
        f"with {conc} workers..."
    )
    print(f"[batch] QP path: {'RAM-SAFE streaming (--low-ram)' if low_ram else 'production CroppingEngine'}")
    print(f"[batch] staging: {output_dir}/.staging/ (final output touched only at commit)")

    # ── Build args for workers ──────────────────────
    # Workers receive pre-built args dicts.
    # They do NOT rescan the input directory.
    args_list = []
    for row in pending:
        args_list.append({
            "bundle_key": row["bundle_key"],
            "bundle_id": row["id"],
            "qp_path": row["qp_path"],
            "ms_path": row["ms_path"],
            "er_path": row["er_path"],
            "insert_path": row["insert_path"],
            "ci_path": row["ci_path"],
            "output_dir": str(output_dir),
            "db_path": str(db_path),
            "syllabus_code": row["syllabus_code"],
            "subject": row["subject"],
            "level": row["level"],
            "season": row["season"],
            "year": row["year"],
            "component": row["component"],
            "paper_format": row["paper_format"],
            "topics_dir": topics_dir,
            "low_ram": low_ram,
            "full_auto": full_auto,
            "quiet_worker": conc > 1,
            # A single parent owns manifest writes. Parallel workers otherwise
            # each load an older JSON snapshot and race to atomically replace
            # it, which can lose completed records on large batches.
            "manifest_owner": "parent",
        })

    # ── Process with bounded pool ───────────────────
    start_time = time.time()
    complete = 0
    failed = 0
    review = 0
    results = []
    manifest_updates = 0
    manifest_last_flush = time.monotonic()

    def _input_paths(worker_args):
        return [Path(p) for p in (
            worker_args.get("qp_path"), worker_args.get("ms_path"),
            worker_args.get("er_path"), worker_args.get("insert_path"),
            worker_args.get("ci_path"),
        ) if p]

    def _flush_manifest(force=False):
        """Persist a batch of state updates without turning a 10k run into
        repeated full JSON rewrites. At most one small atomic write per 25
        outcomes or five seconds; a Ctrl+C may requeue only the unflushed tail
        safely on the next run."""
        nonlocal manifest_updates, manifest_last_flush
        if not manifest_updates:
            return
        if force or manifest_updates >= 25 or time.monotonic() - manifest_last_flush >= 5.0:
            manifest.save(force=True)
            manifest_updates = 0
            manifest_last_flush = time.monotonic()

    def _record_manifest_outcome(worker_args, result):
        """Parent-only manifest update after the database transaction commits."""
        nonlocal manifest_updates
        status = result.get("status")
        input_paths = _input_paths(worker_args)
        key = worker_args["bundle_key"]
        if status == "complete":
            artifacts = db.get_bundle_artifacts(worker_args["bundle_id"])
            questions = int(result.get("questions", 0) or 0)
            manifest.record_bundle_completed(key, input_paths, artifacts, questions, questions)
        elif status == "review_required":
            artifacts = db.get_bundle_artifacts(worker_args["bundle_id"])
            manifest.record_bundle_review(
                key, input_paths, str(result.get("reason", "needs review")), artifacts,
            )
        elif status == "failed":
            manifest.record_bundle_failed(
                key, input_paths, str(result.get("error", "unknown worker failure")),
            )
        else:
            return
        manifest_updates += 1
        _flush_manifest()

    # Persist PROCESSING before dispatch. This prevents a crash between
    # scheduling and child startup from ever losing a resumable bundle.
    for worker_args in args_list:
        manifest.record_bundle_processing(worker_args["bundle_key"], _input_paths(worker_args))
    manifest_updates = len(args_list)
    _flush_manifest(force=True)

    def _record(result, worker_args):
        """Record one isolated-worker result without letting a dead child kill
        the parent batch controller."""
        nonlocal complete, failed, review
        _handle_result(result)
        results.append(result)
        complete += result["status"] == "complete"
        failed += result["status"] == "failed"
        review += result["status"] == "review_required"
        _record_manifest_outcome(worker_args, result)

    def _worker_failure(args, exc):
        error = f"isolated worker exception: {exc}"
        # A SIGKILL/BrokenProcessPool can happen before the child gets to its
        # normal exception handler.  Repair the DB lifecycle in the parent so
        # the bundle is retryable instead of remaining PROCESSING forever.
        try:
            from .database import Database
            Database(args["db_path"]).mark_bundle_failed(
                args["bundle_id"], error
            )
        except Exception as db_exc:
            error += f"; parent DB repair failed: {db_exc}"
        return {
            "status": "failed",
            "bundle_key": args["bundle_key"],
            "error": error,
        }

    def _one_isolated(args):
        """Run exactly one bundle in a disposable process.

        Calling process_bundle directly for workers=1 kept all PDF/rendering
        allocations in the parent process. That was the reason a mixed IGCSE
        batch could finish 0580 and then be killed while starting 0625. The
        process boundary is now used even for one-worker runs.
        """
        with ProcessPoolExecutor(max_workers=1) as pool:
            try:
                return pool.submit(process_bundle, args).result()
            except Exception as exc:
                return _worker_failure(args, exc)

    # Styled progress is shared by sequential and parallel modes, so a
    # low-RAM run does not lose the visual progress indicator merely because
    # the RAM guard clamps concurrency to one worker.
    try:
        from tqdm import tqdm as _tqdm
        from .progress_ui import PlainProgress, format_postfix, make_progress
        progress, _progress_colors = make_progress(_tqdm, len(args_list), "ExamVoid")
    except ImportError:
        from .progress_ui import PlainProgress, format_postfix
        progress, _progress_colors = PlainProgress(len(args_list), "ExamVoid"), False

    interrupted = False
    try:
        with progress:
            if conc == 1:
                # One disposable worker per bundle. The child dies before the next
                # paper, returning PyMuPDF/Pillow/native allocator memory to the OS.
                for args in args_list:
                    _record(_one_isolated(args), args)
                    progress.update(1)
                    progress.set_postfix_str(format_postfix(
                        complete, failed, review, args["bundle_key"],
                        enabled=_progress_colors,
                    ))
            else:
                # Recycle every worker after one bundle where supported. This keeps
                # long 300+ file runs from accumulating native PDF/image allocations.
                import inspect
                pool_kwargs = {"max_workers": conc}
                if "max_tasks_per_child" in inspect.signature(ProcessPoolExecutor).parameters:
                    pool_kwargs["max_tasks_per_child"] = 1
                pool = ProcessPoolExecutor(**pool_kwargs)
                futures = {}
                try:
                    for args in args_list:
                        futures[pool.submit(process_bundle, args)] = args
                    for future in as_completed(futures):
                        args = futures[future]
                        try:
                            result = future.result()
                        except Exception as exc:
                            result = _worker_failure(args, exc)
                        _record(result, args)
                        progress.update(1)
                        progress.set_postfix_str(format_postfix(
                            complete, failed, review, args["bundle_key"],
                            enabled=_progress_colors,
                        ))
                except KeyboardInterrupt:
                    # Do not let a Ctrl+C drain a 10,000-bundle submission
                    # queue. Cancel work that has not started, then wait for
                    # only currently active workers to finish their current
                    # atomic staging/DB operation.
                    for future in futures:
                        future.cancel()
                    pool.shutdown(wait=True, cancel_futures=True)
                    raise
                else:
                    pool.shutdown(wait=True)
    except KeyboardInterrupt:
        # The executor context has waited for any currently-running worker to
        # return before reaching this handler. Unstarted bundles remain PENDING
        # and any worker left in PROCESSING is recovered on the next launch.
        interrupted = True
        print("\nShutdown requested. Finishing current operation and saving manifest...")
        recovered_now = db.recover_interrupted_bundles()
        if recovered_now:
            print(f"[batch] {recovered_now} incomplete bundle(s) returned to pending for safe resume.")

        # Reconcile outcomes that completed while the executor was shutting
        # down but before the parent could consume their futures. Database rows
        # are transactional and are the recovery authority.
        for worker_args in args_list:
            snap = db.get_bundle_snapshot(worker_args["bundle_id"])
            if snap is None:
                continue
            status = str(snap["status"])
            inputs = _input_paths(worker_args)
            if status == "complete":
                artifacts = db.get_bundle_artifacts(worker_args["bundle_id"])
                manifest.record_bundle_completed(
                    worker_args["bundle_key"], inputs, artifacts,
                    int(snap["questions_found"] or 0), int(snap["questions_saved"] or 0),
                )
                manifest_updates += 1
            elif status == "review_required":
                manifest.record_bundle_review(
                    worker_args["bundle_key"], inputs,
                    str(snap["error_message"] or "needs review"),
                    db.get_bundle_artifacts(worker_args["bundle_id"]),
                )
                manifest_updates += 1
            elif status == "failed":
                manifest.record_bundle_failed(
                    worker_args["bundle_key"], inputs,
                    str(snap["error_message"] or "interrupted worker failure"),
                )
                manifest_updates += 1
        _flush_manifest(force=True)
        print("Shutdown complete. Resume with Process Pending when ready.")

    # Ensure the final state tail is durable before parent-side post stages.
    _flush_manifest(force=True)
    if interrupted:
        return {
            "processed": len(results), "complete": complete, "failed": failed,
            "review_required": review, "new_bundles": new_bundles,
            "results": results, "interrupted": True, "audit_passed": None,
        }

    # ── ER attach + final audit (once, parent side) ──
    audit = None
    if complete + review > 0:
        audit = _post_run_attach_and_audit(db, output_dir, [a["bundle_key"] for a in args_list])

    # SQLite is the source of truth after workers finish.  Include review or
    # failed bundles left by an earlier run; only counting this invocation's
    # futures made resume capable of printing a false clean result.
    if filter_active:
        final_counts = _filtered_status_counts(
            db, session=session, year=year_filter, subject=subject_filter,
            syllabus_code=syllabus_code_filter, level=level_filter,
            variant=variant_filter, selected_paths=selected_paths,
            selected_folder=selected_folder,
        )
    else:
        with db._conn() as conn:
            final_rows = conn.execute(
                "SELECT status, COUNT(*) AS n FROM bundles GROUP BY status"
            ).fetchall()
        final_counts = {str(row["status"]): int(row["n"]) for row in final_rows}
    review = final_counts.get("review_required", review)
    failed = final_counts.get("failed", failed)
    unresolved = final_counts.get("pending", 0) + final_counts.get("processing", 0)
    if unresolved:
        failed += unresolved
        print(f"  {unresolved} bundles remain pending/processing; treating run as failed.")

    # ── Final report ────────────────────────────────
    elapsed = time.time() - start_time
    mins = int(elapsed // 60)
    secs = int(elapsed % 60)

    print(f"\nBatch complete in {mins}m {secs}s")
    db.print_progress()

    if failed > 0:
        print(
            f"  {failed} failed bundles. "
            f"Run with --retry-failed to retry."
        )

    if review > 0:
        print(
            f"  {review} bundles need manual review. "
            f"Check output tree + .staging/ worker logs."
        )

    return {
        "processed": len(args_list),
        "complete": complete,
        "failed": failed,
        "review_required": review,
        "new_bundles": new_bundles,
        "results": results,
        "audit_passed": (audit or {}).get("passed"),
    }
