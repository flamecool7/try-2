"""core/manifest.py — Persistent Incremental Processing & Manifest Architecture.

Tracks input file states, SHA-256 hashes, file sizes, mtimes, output artifacts,
and execution modes (Default: Process New/Changed, Retry Failed, Force All)
with safe resume capability and sub-millisecond change detection.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

MANIFEST_VERSION = "2.1.0"
DEFAULT_MANIFEST_NAME = ".processing_manifest.json"


class FileStatus(str, Enum):
    NEW = "NEW"
    PROCESSING = "PROCESSING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CHANGED = "CHANGED"
    NEEDS_REVIEW = "NEEDS_REVIEW"


class ExecutionMode(str, Enum):
    DEFAULT = "default"             # Process only NEW and CHANGED files
    RETRY_FAILED = "retry_failed"   # Retry only FAILED and NEEDS_REVIEW files
    FORCE_ALL = "force_all"         # Reprocess everything


def compute_sha256(path: str | Path, chunk_size: int = 65536) -> str:
    """Compute SHA-256 hash using chunked streaming."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


@dataclass
class FileRecord:
    path: str
    sha256: str
    size: int
    mtime_ns: int
    status: str = FileStatus.NEW.value
    artifacts: List[str] = field(default_factory=list)
    error_message: Optional[str] = None
    last_processed: Optional[str] = None
    bundle_key: Optional[str] = None
    kind: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> FileRecord:
        return cls(**data)


@dataclass
class BundleRecord:
    bundle_key: str
    status: str
    input_files: List[str] = field(default_factory=list)
    artifacts: List[str] = field(default_factory=list)
    questions_found: int = 0
    questions_saved: int = 0
    error_message: Optional[str] = None
    last_processed: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> BundleRecord:
        return cls(**data)


class ProcessingManifest:
    """Persistent processing manifest tracking file lifecycle and artifact mappings."""

    def __init__(
        self,
        manifest_path: Path,
        pipeline_version: str = MANIFEST_VERSION,
        output_dir: Optional[Path] = None,
    ):
        self.manifest_path = Path(manifest_path).resolve()
        self.output_dir = (
            Path(output_dir).resolve()
            if output_dir
            else self.manifest_path.parent.resolve()
        )
        self.pipeline_version = pipeline_version
        self.created_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.updated_utc = self.created_utc
        self.files: Dict[str, FileRecord] = {}
        self.bundles: Dict[str, BundleRecord] = {}
        self._dirty = False

    @classmethod
    def load_or_create(
        cls,
        output_dir: Path | str,
        manifest_name: str = DEFAULT_MANIFEST_NAME,
        pipeline_version: str = MANIFEST_VERSION,
    ) -> ProcessingManifest:
        out_path = Path(output_dir).resolve()
        mpath = out_path / manifest_name
        manifest = cls(mpath, pipeline_version=pipeline_version, output_dir=out_path)

        if not mpath.is_file():
            return manifest

        try:
            with open(mpath, "r", encoding="utf-8") as f:
                data = json.load(f)

            manifest.created_utc = data.get("created_utc", manifest.created_utc)
            manifest.updated_utc = data.get("updated_utc", manifest.updated_utc)
            cached_version = data.get("pipeline_version")

            # Load file records
            for path_str, frec in data.get("files", {}).items():
                manifest.files[path_str] = FileRecord.from_dict(frec)

            # Load bundle records
            for bkey, brec in data.get("bundles", {}).items():
                manifest.bundles[bkey] = BundleRecord.from_dict(brec)

            # A software-version change alone is NOT an input change.  A past
            # archive can hold thousands of successfully completed papers, so
            # automatically invalidating every completed entry on an app
            # version bump would turn a safe upgrade into an accidental full
            # reprocessing job.  Input SHA-256 changes, missing artifacts,
            # explicit --force-all, and manual review remain the authorities
            # for reprocessing decisions.
            #
            # Mark the manifest dirty only so the new version is recorded at
            # the next normal atomic save; statuses and artifact mappings are
            # deliberately retained unchanged.
            if cached_version and cached_version != pipeline_version:
                logger.info(
                    "Pipeline version changed (%s -> %s); retaining completed "
                    "entries. Use explicit force-all only when a migration "
                    "requires reprocessing.",
                    cached_version,
                    pipeline_version,
                )
                manifest._dirty = True

        except Exception as e:
            logger.warning(f"Could not load existing manifest at {mpath}: {e}. Creating fresh.")

        return manifest

    def save(self, force: bool = False) -> None:
        """Atomically persist manifest to disk via temporary file and fsync."""
        if not self._dirty and not force:
            return

        self.updated_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.manifest_path.parent.mkdir(parents=True, exist_ok=True)

        summary = self.get_summary()
        payload = {
            "manifest_version": MANIFEST_VERSION,
            "pipeline_version": self.pipeline_version,
            "created_utc": self.created_utc,
            "updated_utc": self.updated_utc,
            "output_dir": str(self.output_dir),
            "summary": summary,
            "bundles": {k: v.to_dict() for k, v in sorted(self.bundles.items())},
            "files": {k: v.to_dict() for k, v in sorted(self.files.items())},
        }

        tmp_dir = self.manifest_path.parent
        fd, tmp_file = tempfile.mkstemp(prefix=".proc_manifest_", dir=str(tmp_dir), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp_file, str(self.manifest_path))
            self._dirty = False
        except Exception:
            if os.path.exists(tmp_file):
                try:
                    os.unlink(tmp_file)
                except OSError:
                    pass
            raise

    def scan_input_file(self, file_path: Path | str, kind: Optional[str] = None) -> Tuple[FileRecord, bool]:
        """
        Fast stat-based change detection:
        - If (size, mtime_ns) match cached entry, returns cached record in O(1) time.
        - If (size, mtime_ns) differ, re-computes SHA-256.
        - Returns (FileRecord, is_new_or_changed).
        """
        p = Path(file_path).resolve()
        path_key = str(p)
        st = p.stat()
        size = st.st_size
        mtime_ns = st.st_mtime_ns

        cached = self.files.get(path_key)
        if cached is not None:
            # Fast check: identical size and timestamp means unchanged bytes
            if cached.size == size and cached.mtime_ns == mtime_ns:
                if kind and not cached.kind:
                    cached.kind = kind
                    self._dirty = True
                return cached, (cached.status in (FileStatus.NEW.value, FileStatus.CHANGED.value))

            # Stat changed: compute SHA-256 to verify if bytes actually changed
            new_sha = compute_sha256(p)
            if new_sha == cached.sha256:
                # Content identical, only timestamp touched
                cached.size = size
                cached.mtime_ns = mtime_ns
                self._dirty = True
                return cached, (cached.status in (FileStatus.NEW.value, FileStatus.CHANGED.value))

            # Content actually changed
            cached.size = size
            cached.mtime_ns = mtime_ns
            cached.sha256 = new_sha
            cached.status = FileStatus.CHANGED.value
            cached.artifacts = []
            cached.error_message = None
            if kind:
                cached.kind = kind
            self._dirty = True
            return cached, True

        # Brand new file never seen before
        sha = compute_sha256(p)
        rec = FileRecord(
            path=path_key,
            sha256=sha,
            size=size,
            mtime_ns=mtime_ns,
            status=FileStatus.NEW.value,
            kind=kind,
        )
        self.files[path_key] = rec
        self._dirty = True
        return rec, True

    def should_process_bundle(
        self,
        bundle_key: str,
        input_paths: List[Path | str],
        mode: ExecutionMode | str = ExecutionMode.DEFAULT,
        check_artifacts_on_disk: bool = True,
    ) -> Tuple[bool, str]:
        """
        Determine if bundle needs processing under the selected execution mode.
        Modes:
          - ExecutionMode.FORCE_ALL: Reprocess everything.
          - ExecutionMode.RETRY_FAILED: Reprocess FAILED and NEEDS_REVIEW.
          - ExecutionMode.DEFAULT: Process NEW and CHANGED. Resumes cleanly.
        """
        if isinstance(mode, str):
            mode = ExecutionMode(mode)

        if mode == ExecutionMode.FORCE_ALL:
            return True, "force_all"

        b_rec = self.bundles.get(bundle_key)

        # Check input file statuses
        input_keys = [str(Path(p).resolve()) for p in input_paths if p]
        has_new_or_changed = False
        for k in input_keys:
            f_rec = self.files.get(k)
            if f_rec is None or f_rec.status in (FileStatus.NEW.value, FileStatus.CHANGED.value):
                has_new_or_changed = True
                break

        if mode == ExecutionMode.RETRY_FAILED:
            if b_rec and b_rec.status in ("failed", "review_required"):
                return True, f"retry_{b_rec.status}"
            for k in input_keys:
                f_rec = self.files.get(k)
                if f_rec and f_rec.status in (FileStatus.FAILED.value, FileStatus.NEEDS_REVIEW.value):
                    return True, "retry_failed_file"
            if has_new_or_changed:
                return True, "new_or_changed_input"
            return False, "not_failed"

        # Default incremental mode:
        if has_new_or_changed:
            return True, "new_or_changed_input"

        if b_rec is None:
            return True, "bundle_unrecorded"

        if b_rec.status == "complete":
            # Verify output artifacts still exist on disk (safe resume safeguard)
            if check_artifacts_on_disk and b_rec.artifacts:
                for art in b_rec.artifacts:
                    art_p = self.output_dir / art if not Path(art).is_absolute() else Path(art)
                    if not art_p.exists():
                        return True, f"missing_output_artifact:{art}"
            return False, "already_complete"

        if b_rec.status in ("pending", "processing"):
            return True, "interrupted_or_pending"

        if b_rec.status in ("failed", "review_required"):
            # In default mode, don't re-fail unless inputs changed or retry requested
            return False, f"already_{b_rec.status}"

        return True, "unknown_status"

    def record_bundle_processing(self, bundle_key: str, input_paths: List[Path | str]) -> None:
        """Mark bundle and constituent files as PROCESSING."""
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        input_keys = [str(Path(p).resolve()) for p in input_paths if p]

        b_rec = self.bundles.get(bundle_key)
        if b_rec is None:
            b_rec = BundleRecord(
                bundle_key=bundle_key,
                status="processing",
                input_files=input_keys,
                last_processed=now,
            )
            self.bundles[bundle_key] = b_rec
        else:
            b_rec.status = "processing"
            b_rec.input_files = input_keys
            b_rec.last_processed = now

        for k in input_keys:
            f = self.files.get(k)
            if f:
                f.status = FileStatus.PROCESSING.value
                f.bundle_key = bundle_key
                f.last_processed = now

        self._dirty = True

    def record_bundle_completed(
        self,
        bundle_key: str,
        input_paths: List[Path | str],
        artifacts: List[Path | str],
        questions_found: int,
        questions_saved: int,
    ) -> None:
        """Mark bundle and constituent files as COMPLETED with output artifact mappings."""
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        input_keys = [str(Path(p).resolve()) for p in input_paths if p]
        str_artifacts = [str(a) for a in artifacts]

        b_rec = self.bundles.get(bundle_key)
        if b_rec is None:
            b_rec = BundleRecord(
                bundle_key=bundle_key,
                status="complete",
                input_files=input_keys,
                artifacts=str_artifacts,
                questions_found=questions_found,
                questions_saved=questions_saved,
                last_processed=now,
            )
            self.bundles[bundle_key] = b_rec
        else:
            b_rec.status = "complete"
            b_rec.input_files = input_keys
            b_rec.artifacts = str_artifacts
            b_rec.questions_found = questions_found
            b_rec.questions_saved = questions_saved
            b_rec.error_message = None
            b_rec.last_processed = now

        for k in input_keys:
            f = self.files.get(k)
            if f:
                f.status = FileStatus.COMPLETED.value
                f.bundle_key = bundle_key
                f.artifacts = str_artifacts
                f.error_message = None
                f.last_processed = now

        self._dirty = True

    def record_bundle_failed(
        self,
        bundle_key: str,
        input_paths: List[Path | str],
        error_message: str,
    ) -> None:
        """Mark bundle and files as FAILED."""
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        input_keys = [str(Path(p).resolve()) for p in input_paths if p]

        b_rec = self.bundles.get(bundle_key)
        if b_rec is None:
            b_rec = BundleRecord(
                bundle_key=bundle_key,
                status="failed",
                input_files=input_keys,
                error_message=error_message,
                last_processed=now,
            )
            self.bundles[bundle_key] = b_rec
        else:
            b_rec.status = "failed"
            b_rec.error_message = error_message
            b_rec.last_processed = now

        for k in input_keys:
            f = self.files.get(k)
            if f:
                f.status = FileStatus.FAILED.value
                f.bundle_key = bundle_key
                f.error_message = error_message
                f.last_processed = now

        self._dirty = True

    def record_bundle_review(
        self,
        bundle_key: str,
        input_paths: List[Path | str],
        reason: str,
        artifacts: Optional[List[str]] = None,
    ) -> None:
        """Mark bundle and files as NEEDS_REVIEW."""
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        input_keys = [str(Path(p).resolve()) for p in input_paths if p]

        b_rec = self.bundles.get(bundle_key)
        if b_rec is None:
            b_rec = BundleRecord(
                bundle_key=bundle_key,
                status="review_required",
                input_files=input_keys,
                artifacts=artifacts or [],
                error_message=reason,
                last_processed=now,
            )
            self.bundles[bundle_key] = b_rec
        else:
            b_rec.status = "review_required"
            b_rec.artifacts = artifacts or b_rec.artifacts
            b_rec.error_message = reason
            b_rec.last_processed = now

        for k in input_keys:
            f = self.files.get(k)
            if f:
                f.status = FileStatus.NEEDS_REVIEW.value
                f.bundle_key = bundle_key
                f.error_message = reason
                f.last_processed = now

        self._dirty = True

    def get_summary(self) -> Dict[str, Any]:
        """Aggregate summary counts of file and bundle statuses."""
        file_counts = {s.value: 0 for s in FileStatus}
        for f in self.files.values():
            file_counts[f.status] = file_counts.get(f.status, 0) + 1

        bundle_counts: Dict[str, int] = {}
        for b in self.bundles.values():
            bundle_counts[b.status] = bundle_counts.get(b.status, 0) + 1

        return {
            "total_files": len(self.files),
            "files_by_status": file_counts,
            "total_bundles": len(self.bundles),
            "bundles_by_status": bundle_counts,
        }
