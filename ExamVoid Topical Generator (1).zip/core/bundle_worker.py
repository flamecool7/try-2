"""Bundle worker (Overseer batch-infrastructure spec, Phase 4 — honest port
onto the REAL locked per-paper stages).

The spec's worker called a fictional API stack (converter.render_pdf_to_images,
question_split.split_questions(qp_images, pages, ...), markscheme.parse_markscheme,
topics_enhanced.classify, organize.route_question, webp_utils.save_question_crop —
the same hallucinated names pipeline.py's docstring lists), never saved MS
crops, and hard-required examiner_report.webp per question. Instead of faking
that, this worker drives the production machinery — the exact stage function
the guarded runner uses (run_guarded.run_paper_stages): locked gold QP/MS
cropping, MCQ answer-grid letters (RS-7), locked classifier, locked
OutputManager routing, locked on-disk stage checks — with the OutputManager
rooted INSIDE the bundle's staging directory (spec rule 6: never write
directly to final output during processing).

Spec rules honoured:
  4  workers receive pre-built bundle args (explicit file paths from the DB)
     and NEVER rescan the input directory;
  5  workers load only THEIR subject's config
     (config_loader.load_subject_config_by_code_and_level), never all 23;
  6  all writes go to <output>/.staging/bundle_<key>/ first;
  7  bundle COMPLETE only after every question saved + validated + committed;
  8  failed bundles keep their staging directory (worker_log.txt included);
  9  the SQLite database is the single source of truth for batch state
     (the per-run .pipeline_state.json inside staging is throwaway scratch
     the real stage function insists on having — it is never committed);
 10  .pipeline_state.json in the REAL output is untouched by batch runs.
"""

import gc
import json
import logging
import os
import shutil
import traceback
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _validate_staging(staging_root: Path, paper_format: str | None = None) -> list:
    """Validate staged output before commit (honest replacement of the spec's
    _validate_staging, which hard-required examiner_report.webp on every
    question — that would force-review every ER-less bundle).

    Rules enforced = the production output contract:
      * every question folder has exactly one QP webp, 2280px wide
        (multi-part QP twins use the _partN suffix — count bits-by-stem);
      * metadata.json parses and carries 2280-independent fields the locked
        schema requires (delegated to FinalValidator at batch level; here we
        check parse + question_number);
      * an MS webp UNLESS the folder is a deliberate
        ``review_required_no_ms`` home;
      * a `*_MS.txt` sidecar is permitted only for an MCQ component; all
        other .txt question-folder artifacts are rejected.
    Returns list of error strings; empty = all good.
    """
    from PIL import Image

    errors = []
    q_folders = [p for p in staging_root.rglob("*")
                 if p.is_dir() and "_Q" in p.name
                 and p.name.rsplit("_Q", 1)[1].isdigit()]
    if not q_folders:
        errors.append(f"no question folders staged under {staging_root}")
        return errors
    for folder in sorted(q_folders):
        webps = [w for w in folder.glob("*.webp") if "_ER" not in w.name]
        qp_webps = [w for w in webps if "_MS" not in w.name and "_CI" not in w.name and "_IN" not in w.name]
        ms_webps = [w for w in webps if w.name.endswith("_MS.webp")]
        if len(qp_webps) != 1:
            errors.append(f"{folder.name}: expected 1 QP webp, found {len(qp_webps)}")
        else:
            try:
                with Image.open(qp_webps[0]) as im:
                    if im.width != 2280:
                        errors.append(f"{folder.name}: QP width {im.width}px != 2280px")
            except Exception as e:
                errors.append(f"{folder.name}: QP image error: {e}")
        meta_path = folder / "metadata.json"
        if not meta_path.exists():
            errors.append(f"{folder.name}: metadata.json missing")
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception as e:
            errors.append(f"{folder.name}: metadata.json invalid: {e}")
            continue
        all_txts = sorted(folder.glob("*.txt"))
        ms_txts = sorted(folder.glob("*_MS.txt"))
        if len(all_txts) != len(ms_txts):
            errors.append(f"{folder.name}: non-MCQ text artifact(s) are forbidden in question folders")
        is_mcq = str(paper_format or "").upper() == "MCQ"
        if ms_txts and not is_mcq:
            errors.append(f"{folder.name}: structured question must not contain an _MS.txt sidecar")
        if ms_webps:
            continue
        # A sidecar is the legitimate MCQ mark-scheme representation. A
        # structured question missing an MS is preserved only under the
        # explicit review sentinel, never as a falsely complete pair.
        from .mcq_output import valid_ms_sidecar as _valid_sidecar
        topic = meta.get("topic")
        sentinel = topic[0] if isinstance(topic, list) and topic else None
        if is_mcq and len(ms_txts) == 1 and _valid_sidecar(ms_txts[0].read_text(encoding="utf-8")):
            pass
        elif sentinel == "review_required_no_ms" and not ms_txts:
            pass
        else:
            errors.append(f"{folder.name}: no MS webp and not a valid MCQ sidecar or review_required_no_ms home")
    return errors


def _remove_declared_blank_insert_pages(staging_root: Path, insert_path: Path | None) -> list[str]:
    """Keep invalid blank insert-page stubs out of the final archive.

    The locked InsertEngine correctly strips page furniture and may reduce an
    *explicitly declared* ``BLANK PAGE`` to a two-pixel white stub.  Publishing
    that stub makes the final validator (correctly) flag a cutoff.  This
    post-stage guard does not crop or alter the InsertEngine: it only omits a
    file when (1) the emitted image is below the archive's minimum useful
    height and (2) the mapped source page itself says ``BLANK PAGE``.  Any
    other tiny image is fail-closed and leaves staging intact for review.
    """
    from PIL import Image

    errors: list[str] = []
    if insert_path is None or not Path(insert_path).is_file():
        return errors
    try:
        import fitz
        source_doc = fitz.open(str(insert_path))
    except Exception as exc:
        return [f"could not inspect Insert source for tiny-page safety check: {exc}"]

    try:
        for manifest_path in staging_root.rglob("manifest.json"):
            # Only the paper-level Insert manifest has this expected shape.
            if "_insert" not in manifest_path.parts:
                continue
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                page_map = manifest.get("page_map")
                if not isinstance(page_map, dict):
                    continue
            except (OSError, ValueError, TypeError) as exc:
                errors.append(f"invalid staged Insert manifest {manifest_path}: {exc}")
                continue

            omitted: dict[str, str] = {}
            for webp in sorted(manifest_path.parent.glob("*.webp")):
                try:
                    with Image.open(webp) as image:
                        width, height = image.size
                except Exception as exc:
                    errors.append(f"invalid staged Insert image {webp.name}: {exc}")
                    continue
                if width == 2280 and height >= 60:
                    continue
                page_key = webp.stem.rsplit("_", 1)[-1]
                source_label = page_map.get(page_key, "")
                try:
                    source_page = int(str(source_label).rsplit(" ", 1)[-1])
                    source_text = source_doc[source_page - 1].get_text("text")
                except Exception:
                    source_page = None
                    source_text = ""
                if source_page is not None and "blank page" in source_text.casefold():
                    webp.unlink(missing_ok=True)
                    omitted[page_key] = f"source page {source_page}: explicitly declared BLANK PAGE"
                    page_map.pop(page_key, None)
                    print(f"    [insert-guard] omitted {webp.name}: declared blank source page {source_page}")
                else:
                    errors.append(
                        f"Insert image {webp.name} is {width}x{height}; refusing to publish a tiny page "
                        "unless its mapped source page explicitly declares BLANK PAGE"
                    )
            if omitted:
                existing = manifest.get("omitted_blank_pages")
                if not isinstance(existing, dict):
                    existing = {}
                existing.update(omitted)
                manifest["omitted_blank_pages"] = existing
                manifest["pages"] = len(list(manifest_path.parent.glob("*.webp")))
                manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    finally:
        source_doc.close()
    return errors


def _staged_insert_asset_snapshot(staging_root: Path) -> dict[str, set[str]]:
    """Capture expected paper-level Insert asset names before staging is moved."""
    expected_by_rel_dir: dict[str, set[str]] = {}
    for staged_manifest in staging_root.rglob("manifest.json"):
        if "_insert" not in staged_manifest.parts:
            continue
        staged_dir = staged_manifest.parent
        try:
            rel_dir = str(staged_dir.relative_to(staging_root))
        except ValueError:
            continue
        expected_by_rel_dir[rel_dir] = {p.name for p in staged_dir.glob("*.webp")}
    return expected_by_rel_dir


def _remove_stale_insert_output_assets(output_dir: Path, expected_by_rel_dir: dict[str, set[str]]) -> list[str]:
    """Remove stale whole-page Insert assets after an otherwise successful commit.

    StagedWriter replaces files atomically but intentionally does not infer
    deletions. Once the declared-blank guard has omitted a page, this narrow
    reconciliation removes only WebPs inside that staging manifest's dedicated
    ``_insert/<bundle-key>`` directory that are absent from the new snapshot.
    It never walks or deletes another bundle's directory.
    """
    removed: list[str] = []
    for rel_dir, expected in expected_by_rel_dir.items():
        final_dir = output_dir / rel_dir
        if not final_dir.is_dir():
            continue
        for old_asset in final_dir.glob("*.webp"):
            if old_asset.name not in expected:
                try:
                    old_asset.unlink()
                    removed.append(str(old_asset.relative_to(output_dir)))
                except OSError as exc:
                    logger.warning("Could not remove stale Insert asset %s: %s", old_asset, exc)
    if removed:
        print(f"    [insert-guard] removed {len(removed)} stale whole-page Insert asset(s)")
    return removed


def _commit_and_register(db, bundle_id, bundle_key, staging_root, output_dir,
                         writer, qc_review_reason=None,
                         replace_existing=True):
    """Move staged question-tree files to the real output (via StagedWriter)
    and register questions + artifacts in the database.
    Returns (ok, committed_folders, errors)."""
    final_paths = []
    for p in sorted(staging_root.rglob("*")):
        if not p.is_file():
            continue
        if p.name.startswith(".") or p.name in (
            "worker_log.txt", "failure_report.txt", "pipeline.sqlite",
            "pipeline.sqlite-wal", "pipeline.sqlite-shm",
        ):
            # Worker scratch/state is never an output artifact. The parent DB
            # owns batch state; the final tree must contain only question assets.
            continue
        rel = p.relative_to(staging_root)
        final_paths.append((str(rel), str(output_dir / rel)))

    # StagedWriter removes its staging directory when the transactional file
    # commit succeeds, so capture this bundle's narrow Insert snapshot first.
    expected_insert_assets = _staged_insert_asset_snapshot(staging_root)
    committed = writer.commit(
        bundle_key, staging_root, final_paths,
        replace_existing=bool(replace_existing),
    )
    if not committed:
        return False, [], ["staging commit failed (destination conflict or I/O error)"]

    _remove_stale_insert_output_assets(output_dir, expected_insert_assets)

    # The commit succeeded, so the refreshed tree is now authoritative. Remove
    # stale DB question/artifact rows before registering the new snapshot; this
    # is what makes a QP-only -> QP+MS promotion idempotent.
    db.clear_bundle_questions(bundle_id)

    # Register questions/artifacts from the COMMITTED tree (real bytes only)
    from PIL import Image
    committed_folders = set()
    q_found = 0
    for src_rel, dest_abs in final_paths:
        dest = Path(dest_abs)
        if not dest.exists():
            continue
        folder = dest.parent
        # Insert-booklet pages live in the dedicated ``_insert`` tree and are
        # valid production artifacts, but they are not topical question
        # folders and intentionally have no metadata.json. Register only the
        # canonical question folders in the questions/artifacts tables.
        if (folder / "metadata.json").is_file():
            committed_folders.add(folder)
    for folder in sorted(committed_folders):
        meta = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        topic = meta.get("topic")
        topic0 = topic[0] if isinstance(topic, list) and topic else ""
        folder_rel = str(folder.relative_to(output_dir))
        needs_review = ("review_required" in folder.parts)
        q_id = db.register_question(
            bundle_id=bundle_id,
            question_num=str(meta.get("question_number", folder.name.rsplit("_", 1)[-1])),
            topic_assigned=topic0,
            folder_path=folder_rel,
            needs_review=needs_review,
        )
        q_found += 1
        for webp in sorted(folder.glob("*.webp")):
            name = webp.name
            kind = ("ms" if name.endswith("_MS.webp") else ("er" if "_ER" in name else ("ci" if "_CI" in name else ("in" if "_IN" in name else "qp"))))
            try:
                with Image.open(webp) as im:
                    w, h = im.size
            except Exception:
                w = h = None
            db.register_artifact(
                question_id=q_id, kind=kind,
                path=str(webp.relative_to(output_dir)),
                width_px=w, height_px=h, file_size=webp.stat().st_size,
            )
    return True, sorted(str(f.relative_to(output_dir)) for f in committed_folders), []


def _remove_stale_bundle_question_folders(
    output_dir: Path,
    qp_full_code: str,
    committed_folders: set[Path],
    scope_dir: Path | None = None,
) -> list[str]:
    """Remove question folders from an older snapshot of the same QP that
    were not produced by the refreshed run.  This prevents a changed
    classification or question count from leaving duplicate/stale folders.
    """
    output_dir = Path(output_dir).resolve()
    committed = {Path(p).resolve() for p in committed_folders}
    removed = []

    # Determine subject-scoped directory to avoid scanning the entire archive
    if scope_dir is None and committed:
        first_folder = next(iter(committed))
        # Folder is output_dir / Level / Subject / PaperType / Major / Q_folder
        try:
            rel = first_folder.relative_to(output_dir)
            if len(rel.parts) >= 2:
                scope_dir = output_dir / rel.parts[0] / rel.parts[1]
        except Exception:
            scope_dir = None

    search_root = scope_dir if (scope_dir and scope_dir.is_dir()) else output_dir

    # Derive question folder prefixes for this paper (e.g. 32_Summer_2023_ / 32_Summer_23_)
    target_prefixes = None
    try:
        from .paper_identifier import parse_paper_filename
        info = parse_paper_filename(qp_full_code + ".pdf")
        if info and info.variant and info.season and info.year:
            target_prefixes = (
                f"{info.variant}_{info.season}_{info.year}_",
                f"{info.variant}_{info.season}_{info.year_short}_",
            )
    except Exception:
        target_prefixes = None

    candidate_metadatas = []
    if target_prefixes and search_root.is_dir():
        # Fast path: inspect only directories matching the paper's prefix
        for root, dirs, files in os.walk(search_root):
            d_name = os.path.basename(root)
            if d_name.startswith(target_prefixes) and "metadata.json" in files:
                candidate_metadatas.append(Path(root) / "metadata.json")
    else:
        # Safe fallback
        candidate_metadatas = list(search_root.rglob("metadata.json"))

    for metadata in candidate_metadatas:
        if ".staging" in metadata.parts or metadata.parent in committed:
            continue
        try:
            data = json.loads(metadata.read_text(encoding="utf-8"))
        except Exception:
            continue
        if data.get("paper") != qp_full_code:
            continue
        folder = metadata.parent.resolve()
        if folder in committed:
            continue
        try:
            shutil.rmtree(folder)
            removed.append(str(folder))
            # Prune only empty topic/paper-type parents; never climb into the
            # subject or level root.
            parent = folder.parent
            while parent != output_dir and parent.parent != output_dir:
                if parent.exists() and not any(parent.iterdir()):
                    parent.rmdir()
                    parent = parent.parent
                else:
                    break
        except OSError:
            logger.exception("Could not remove stale bundle folder %s", folder)
    if removed:
        print(f"  [bundle] removed {len(removed)} stale question folder(s) for {qp_full_code}")
    return removed


def process_bundle(args: dict) -> dict:
    """
    Process one complete QP/MS(/ER) bundle end-to-end through the REAL
    locked stages, inside staging, then commit + register.

    Standalone function safe for multiprocessing: receives a pre-built
    bundle dict from preflight/the DB and loads only its own subject config.
    Returns status dict.
    """
    bundle_key = args["bundle_key"]
    bundle_id = args["bundle_id"]
    qp_path = Path(args["qp_path"]) if args.get("qp_path") else None
    ms_path = Path(args["ms_path"]) if args.get("ms_path") else None
    # ER crops are attached parent-side after bundle commits, but its input
    # identity belongs in the manifest so a changed ER is observable.
    er_path = Path(args["er_path"]) if args.get("er_path") else None
    insert_path = Path(args["insert_path"]) if args.get("insert_path") else None
    ci_path = Path(args["ci_path"]) if args.get("ci_path") else None
    output_dir = Path(args["output_dir"])
    db_path = Path(args["db_path"])
    syllabus_code = args["syllabus_code"]
    subject = args["subject"]
    level = args["level"]
    year = args.get("year", "")
    quiet = bool(args.get("quiet_worker"))

    from .database import Database
    from .staged_writer import StagedWriter

    db = Database(db_path)
    writer = StagedWriter(output_dir)

    # Resume short-circuit: constant-time identity check (spec rule 9)
    if db.bundle_is_complete(bundle_key):
        return {"status": "already_complete", "bundle_key": bundle_key}

    staging_path = writer.get_staging_path(bundle_key)

    # Worker stdout → staging log when running pooled (readable alongside
    # preserved staging on failure; live prints when workers==1)
    log_fh = None
    if quiet:
        import contextlib
        import sys
        log_fh = open(staging_path / "worker_log.txt", "w", encoding="utf-8", errors="replace")
        sys.stdout = contextlib.redirect_stdout(log_fh).__enter__()
        sys.stderr = contextlib.redirect_stderr(log_fh).__enter__()

    try:
        # ── Input verification (fail-closed) ─────────────────────────
        if qp_path is None or not qp_path.exists():
            raise FileNotFoundError(f"QP input missing for {bundle_key}: {qp_path}")
        if ms_path is not None and not ms_path.exists():
            raise FileNotFoundError(f"MS input missing for {bundle_key}: {ms_path}")
        if insert_path is not None and not insert_path.exists():
            raise FileNotFoundError(f"Insert input missing for {bundle_key}: {insert_path}")
        if ci_path is not None and not ci_path.exists():
            raise FileNotFoundError(f"CI input missing for {bundle_key}: {ci_path}")

        db.mark_bundle_processing(bundle_id)

        # ── Identity WITHOUT rescanning the input dir (rule 4) ───────
        from .paper_identifier import parse_paper_filename
        qp_info = parse_paper_filename(qp_path)
        ms_info = parse_paper_filename(ms_path) if ms_path is not None else None
        insert_info = parse_paper_filename(insert_path) if insert_path is not None else None
        ci_info = parse_paper_filename(ci_path) if ci_path is not None else None
        if qp_info is None:
            raise ValueError(f"cannot re-identify QP {qp_path.name}")
        if ms_path is not None and ms_info is None:
            raise ValueError(f"cannot re-identify MS {ms_path.name}")

        # ── This subject's config ONLY (rule 5) ──────────────────────
        from .config_loader import load_subject_config_by_code_and_level
        year_full = str(year)
        if len(year_full) == 2 and year_full.isdigit():
            year_full = "20" + year_full
        config = load_subject_config_by_code_and_level(
            syllabus_code, level, year_full
        )
        if config is None:
            raise ValueError(
                f"no approved subject config for {syllabus_code}/{level}/{year_full}"
            )

        # ── Real locked stages, rooted inside staging (rule 6) ───────
        import sys as _sys
        proj_root = str(Path(__file__).resolve().parent.parent)
        if proj_root not in _sys.path:
            _sys.path.insert(0, proj_root)
        from types import SimpleNamespace
        from run_guarded import Gate, StageAbort, run_paper_stages
        from core.cropping_engine import CroppingEngine
        from core.ms_cropping_engine import MSCroppingEngine
        from core.qp_ms_matcher import QPMSMatcher
        from core.output_manager import OutputManager
        from core.pipeline_state import PipelineState

        cropping_engine = CroppingEngine(target_width=2280, quality=95, dpi=75)
        ms_engine = MSCroppingEngine(target_width=2280, quality=95, dpi=150)
        gate = Gate(staging_path)
        # Throwaway scratch state living INSIDE staging (never committed) —
        # run_paper_stages requires it; the DB is the batch source of truth.
        state = PipelineState.load_or_create(
            staging_path, subject=subject, syllabus_code=syllabus_code, level=level,
        )
        output_mgr = OutputManager(output_root=staging_path)

        local_status, local_error, saved_n = "failed", "worker did not finish", 0
        try:
            run_args = SimpleNamespace(
                low_ram=bool(args.get("low_ram", True)),
                # Full-auto is the default policy. Callers that explicitly
                # request fail-closed behavior pass full_auto=False.
                full_auto=bool(args.get("full_auto", True)),
                output=str(staging_path),
                # Keep audit traces outside staging so they are not treated as
                # question artifacts during commit, and never touch metadata.
                classification_audit_path=str(
                    output_dir / ".classification_audit" / f"{bundle_key}.jsonl"
                ),
            )
            saved_n = run_paper_stages(
                gate, run_args, bundle_key, qp_info, ms_info, subject, config,
                state, cropping_engine, ms_engine, QPMSMatcher(), output_mgr,
                insert_info=insert_info,
                ci_info=ci_info,
            )
        except StageAbort as e:
            local_status, local_error = "failed", f"stage gate abort: {e}"
        except SystemExit as e:
            local_status, local_error = "failed", f"stage runner exited: code {e.code}"
        else:
            rec = state.papers.get(bundle_key)
            if rec is not None:
                st = rec.status.value if hasattr(rec.status, "value") else str(rec.status)
                local_status = "complete" if st == "complete" else "review_or_failed"
                local_error = rec.error_message or getattr(rec, "review_reason", "") or ""
            else:
                local_status, local_error = "failed", "no local record"

        # ── Verdict mapping (local scratch verdict -> batch DB verdict) ──
        review_markers = ("QC needs_review", "MISSING_MS", "CROP_EMPTY")
        commit_ok_shapes = ("complete",) + tuple(review_markers)

        review_folders = [
            p for p in staging_path.rglob("*")
            if p.is_dir() and "review_required" in p.parts
        ]
        if local_status == "complete" and review_folders:
            verdict = "review_required"
            local_error = (
                f"{len(review_folders)} question folder(s) require review; "
                "bundle output is preserved but not marked complete"
            )
        elif local_status == "complete":
            verdict = "complete"
        elif local_status == "review_or_failed":
            # PipelineState has an explicit REVIEW_REQUIRED status even when
            # the crops themselves live in normal topic folders (for example,
            # a paper year outside the verified syllabus editions).
            verdict = "review_required"
            local_error = local_error or "bundle marked REVIEW_REQUIRED by guarded stages"
        elif any(m in local_error for m in review_markers):
            verdict = "review_required"
        else:
            verdict = "failed"

        stage_errors = []
        if local_status in {"complete", "review_or_failed"} or any(
                m in local_error for m in commit_ok_shapes[1:]):
            # CROP_EMPTY stages nothing worth committing; fail review-closed.
            has_questions = any(
                d.is_dir() and "_Q" in d.name
                for d in staging_path.rglob("*")
            )
            if has_questions:
                # The InsertEngine itself is locked. This integration-only
                # guard removes only explicitly declared blank-page stubs that
                # would otherwise fail final output validation.
                stage_errors = _remove_declared_blank_insert_pages(staging_path, insert_path)
                stage_errors.extend(_validate_staging(
                    staging_path, paper_format=args.get("paper_format")
                ))
                if stage_errors:
                    for err in stage_errors:
                        logger.warning(f"Validation: {err}")
                    db.mark_bundle_review(
                        bundle_id, f"{len(stage_errors)} staging validation issues: "
                                   f"{stage_errors[0]}")
                    _finish(log_fh)
                    return {"status": "review_required", "bundle_key": bundle_key,
                            "errors": stage_errors}

                ok, committed, commit_errors = _commit_and_register(
                    db, bundle_id, bundle_key, staging_path, output_dir, writer,
                    replace_existing=bool(args.get("replace_existing", True)))
                if not ok:
                    db.mark_bundle_failed(bundle_id, "Staging commit failed: "
                                          + "; ".join(commit_errors))
                    writer.rollback(bundle_key, staging_path, preserve=True)
                    _finish(log_fh)
                    return {"status": "failed", "bundle_key": bundle_key,
                            "error": "commit_failed"}

                _remove_stale_bundle_question_folders(
                    output_dir,
                    qp_info.full_code,
                    {output_dir / rel for rel in committed},
                    scope_dir=output_dir / level / subject,
                )

                rec = state.papers.get(bundle_key)
                # Local record counts are zero on review paths (mark_failed
                # never sets them) — fall back to the runner's own saved_n
                # and then the committed-folder count. Never report 0 beside
                # a committed tree.
                found = ((rec.questions_found if rec is not None else 0) or 0) \
                        or saved_n or len(committed)
                saved = ((rec.questions_saved if rec is not None else 0) or 0) \
                        or saved_n or len(committed)

                # Direct callers retain local manifest recording. The batch
                # runner passes manifest_owner='parent' so one parent process
                # serializes every manifest mutation and avoids multi-worker
                # last-writer-wins JSON races.
                if args.get("manifest_owner") != "parent":
                    try:
                        from .manifest import ProcessingManifest
                        manifest = ProcessingManifest.load_or_create(output_dir)
                        input_paths = [p for p in (qp_path, ms_path, er_path, insert_path, ci_path) if p is not None]
                        if verdict == "review_required":
                            manifest.record_bundle_review(bundle_key, input_paths, local_error, committed)
                        else:
                            manifest.record_bundle_completed(bundle_key, input_paths, committed, found, saved)
                        manifest.save()
                    except Exception as e:
                        logger.warning(f"Could not record bundle in processing manifest: {e}")

                if verdict == "review_required":
                    # Crops committed; humans must triage. DB truthfully says so —
                    # and the counts stay visible in progress reporting.
                    db.set_bundle_counts(bundle_id, found, saved)
                    db.mark_bundle_review(bundle_id, local_error)
                else:
                    db.mark_bundle_complete(
                        bundle_id, questions_found=found, questions_saved=saved)
                _finish(log_fh)
                return {"status": verdict, "bundle_key": bundle_key,
                        "questions": saved, "needs_review": [],
                        **({"reason": local_error} if verdict == "review_required" else {})}

        # failed / nothing committable
        if args.get("manifest_owner") != "parent":
            try:
                from .manifest import ProcessingManifest
                manifest = ProcessingManifest.load_or_create(output_dir)
                input_paths = [p for p in (qp_path, ms_path, er_path, insert_path, ci_path) if p is not None]
                manifest.record_bundle_failed(bundle_key, input_paths, local_error or "unknown worker failure")
                manifest.save()
            except Exception:
                pass

        db.mark_bundle_failed(bundle_id, local_error or "unknown worker failure")
        writer.rollback(bundle_key, staging_path, preserve=True)
        gc.collect()
        _finish(log_fh)
        return {"status": verdict if verdict != "complete" else "failed",
                "bundle_key": bundle_key,
                "error": local_error or "unknown worker failure"}

    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"Bundle {bundle_key} failed: {e}")
        if args.get("manifest_owner") != "parent":
            try:
                from .manifest import ProcessingManifest
                manifest = ProcessingManifest.load_or_create(output_dir)
                input_paths = [p for p in (qp_path, ms_path, er_path, insert_path, ci_path) if p is not None]
                manifest.record_bundle_failed(bundle_key, input_paths, str(e))
                manifest.save()
            except Exception:
                pass
        try:
            db.mark_bundle_failed(bundle_id, str(e), tb)
        except Exception:
            logger.error(f"DB mark_bundle_failed also failed for {bundle_key}")
        writer.rollback(bundle_key, staging_path, preserve=True)
        gc.collect()
        _finish(log_fh)
        return {"status": "failed", "bundle_key": bundle_key,
                "error": str(e), "trace": tb}


def _finish(log_fh):
    if log_fh is not None:
        import sys
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
        log_fh.close()
