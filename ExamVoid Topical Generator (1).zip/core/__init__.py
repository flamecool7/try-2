# Core package - universal components supporting IGCSE + A-Level
from .config_loader import (
    load_all_subject_configs, SubjectConfig,
    load_subject_config_by_code_and_level, get_configs_by_level,
    infer_level_from_code
)
from .paper_identifier import parse_paper_filename, PaperInfo, infer_level_from_code as infer_level_paper
from .subject_detector import detect_subject, separate_papers_by_subject
from .cropping_engine import CroppingEngine, CroppedQuestion
from .qp_ms_matcher import QPMSMatcher, MatchedQuestion
from .classifier import TopicClassifier, ClassificationResult
from .classification_memory import ClassificationMemory, MemoryContext
from .mark_scheme_evidence import MarkSchemeEvidenceIndex, MarkSchemeEvidence
from .json_generator import JSONGenerator
from .output_manager import OutputManager
from .validation import FinalValidator

__all__ = [
    "load_all_subject_configs",
    "SubjectConfig",
    "load_subject_config_by_code_and_level",
    "get_configs_by_level",
    "infer_level_from_code",
    "parse_paper_filename",
    "PaperInfo",
    "detect_subject",
    "separate_papers_by_subject",
    "CroppingEngine",
    "CroppedQuestion",
    "QPMSMatcher",
    "MatchedQuestion",
    "TopicClassifier",
    "ClassificationResult",
    "ClassificationMemory",
    "MemoryContext",
    "MarkSchemeEvidenceIndex",
    "MarkSchemeEvidence",
    "JSONGenerator",
    "OutputManager",
    "FinalValidator",
]
