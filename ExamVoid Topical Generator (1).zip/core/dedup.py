"""dedup.py — Variant-Scoped Duplicate Detection for Cambridge Examination Papers.

CRITICAL CAMBRIDGE INVARIANT:
Duplicate detection must NOT be global across the entire question bank.
Cambridge repeats similar questions primarily within the SAME paper variant
(e.g., 9701 Paper 21 vs Paper 21 across series).
A question from 9701 May/June 2026 Paper 21 is checked against Paper 21 questions only.
It is NEVER compared against Paper 22, Paper 31, or other subjects.

DUPLICATE DEFINITION & SAFETY RULES:
  1. Variant Partitioning: Index partitioned by (syllabus_code, variant).
  2. Exact-Match Fast Path: SHA-256 of cleaned normalized text (_exact_hash) -> O(1) lookup.
  3. Candidate Filtering: Token/length pre-filtering prunes non-candidate pairs before similarity.
  4. Number-Aware Safety Check: Questions that share template phrasing but have differing
     numerical parameters (e.g. 2.0 kg vs 5.0 kg) are DIFFERENT questions, NOT duplicates.
  5. Perceptual Hashing: For image-only questions, Hamming distance <= 8 bits.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Dict, List, Optional, Sequence, Set, Tuple

# Default similarity threshold — questions at or above this similarity are candidates
SIMILARITY_THRESHOLD = 0.94

# Text normalisation regexes
_WS = re.compile(r"\s+")
_PUNCT = re.compile(r"[^\w\d]")

# Cambridge running header / footer lines that differ between papers/variants
_HEADER_FOOTER_PATTERNS = [
    re.compile(r"\b\d{4}\s*/\s*\d{2,3}(?:\s*/\s*[A-Za-z]+)*\b"),
    re.compile(r"\bpage\s+\d+\s*(of\s+\d+)?\b", re.IGNORECASE),
    re.compile(r"^\s*\d{1,3}\s*$"),
    re.compile(r"^\s*\d{4}\s*$"),
    re.compile(r"\[turn\s+over\]", re.IGNORECASE),
    re.compile(r"\bblank\s+page\b", re.IGNORECASE),
    re.compile(r"\buniversity\s+of\s+cambridge\b", re.IGNORECASE),
    re.compile(r"\bcambridge\s+international\b", re.IGNORECASE),
    re.compile(r"\binternational\s+examinations\b", re.IGNORECASE),
    re.compile(r"\bgeneral\s+certificate\s+of\s+education\b", re.IGNORECASE),
    re.compile(r"\badvanced\s+(subsidiary\s+)?level\b", re.IGNORECASE),
    re.compile(r"\bpaper\s+\d+\b", re.IGNORECASE),
    re.compile(r"\b(january|february|march|april|may|june|july|august|september|october|november|december)"
               r"\s*/?\s*(january|february|march|april|may|june|july|august|september|october|november|december)?"
               r"\s*\d{4}\b", re.IGNORECASE),
    re.compile(r"\b\d+\s+hour(s)?\s*(\d+\s+minute(s)?)?\b", re.IGNORECASE),
    re.compile(r"\bucles\b", re.IGNORECASE),
    re.compile(r"©\s*\d{4}"),
    re.compile(r"\bdo\s+not\s+write\s+(in|on)\s+this\s+margin\b", re.IGNORECASE),
    re.compile(r"\bpermission\s+to\s+reproduce\b", re.IGNORECASE),
    re.compile(r"\bcopyright\s+acknowledgements?\b", re.IGNORECASE),
    re.compile(r"\bthis\s+document\s+consists\b", re.IGNORECASE),
]

_NUMBER_RE = re.compile(
    r"(?<![.\w])"
    r"\d+\.?\d*"
    r"(?:[eE][+-]?\d+)?"
    r"(?![.\w])"
)


def normalize_text(text: str) -> str:
    """Lower-case, collapse whitespace, strip edges."""
    t = (text or "").lower()
    t = _WS.sub(" ", t)
    return t.strip()


def clean_question_text(text: str) -> str:
    """Strip Cambridge headers, footers, page numbers, and copyright lines."""
    lines = (text or "").split("\n")
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if any(pat.search(stripped) for pat in _HEADER_FOOTER_PATTERNS):
            continue
        cleaned.append(stripped)
    return " ".join(cleaned)


def extract_numbers(text: str) -> List[float]:
    """Extract numeric values for number-aware parameter safety check."""
    nums = []
    for m in _NUMBER_RE.finditer(text):
        try:
            nums.append(float(m.group()))
        except ValueError:
            pass
    return nums


def numbers_match(nums_a: Sequence[float], nums_b: Sequence[float], tolerance: float = 0.01) -> bool:
    """True if sorted numbers have same length and correspond within relative tolerance."""
    if not nums_a and not nums_b:
        return True
    if len(nums_a) != len(nums_b):
        return False
    sa = sorted(nums_a)
    sb = sorted(nums_b)
    for a, b in zip(sa, sb):
        if a == 0 and b == 0:
            continue
        if a == 0 or b == 0:
            return False
        if abs(a - b) / max(abs(a), abs(b)) > tolerance:
            return False
    return True


def compute_exact_hash(cleaned_text: str) -> str:
    return hashlib.sha256(cleaned_text.encode("utf-8")).hexdigest()


def hamming_distance(hex_a: str, hex_b: str) -> int:
    try:
        return bin(int(hex_a, 16) ^ int(hex_b, 16)).count("1")
    except Exception:
        return 999


@dataclass
class IndexedQuestion:
    qid: str
    paper_code: str
    question_number: str
    variant: str
    cleaned_norm: str
    exact_hash: str
    numbers: List[float]
    length: int
    tokens: Set[str]
    perceptual_hash: Optional[str] = None


class VariantDuplicateIndex:
    """
    Variant-scoped duplicate detection index.
    Maintains independent partitions for each (syllabus_code, variant).

    Structure:
      index[(syllabus_code, variant)] -> Partition
    """

    def __init__(self, similarity_threshold: float = SIMILARITY_THRESHOLD, hamming_threshold: int = 8):
        self.similarity_threshold = similarity_threshold
        self.hamming_threshold = hamming_threshold
        # Partitioned storage: (syllabus, variant) -> list of IndexedQuestion
        self.partitions: Dict[Tuple[str, str], List[IndexedQuestion]] = {}
        # Fast exact-hash lookup per partition
        self.exact_hash_map: Dict[Tuple[str, str], Dict[str, str]] = {}
        # Statistics
        self.comparisons_made = 0
        self.exact_hits = 0
        self.similar_hits = 0
        self.rejected_by_numbers = 0

    def _get_partition_key(self, syllabus_code: str, variant: str) -> Tuple[str, str]:
        # Normalize variant to clean string (e.g., '21', '22', '1', '2')
        v = str(variant or "").strip()
        return (str(syllabus_code or "").strip(), v)

    def check_and_index(
        self,
        qid: str,
        syllabus_code: str,
        variant: str,
        paper_code: str,
        question_number: str,
        raw_text: str,
        perceptual_hash: Optional[str] = None,
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if question is a duplicate within its variant partition.
        If duplicate: returns (True, duplicate_of_qid).
        If unique: indexes the question in that variant partition and returns (False, None).
        """
        pkey = self._get_partition_key(syllabus_code, variant)
        if pkey not in self.partitions:
            self.partitions[pkey] = []
            self.exact_hash_map[pkey] = {}

        part = self.partitions[pkey]
        hash_map = self.exact_hash_map[pkey]

        cleaned = normalize_text(clean_question_text(raw_text))
        has_text = len(cleaned) >= 20

        if has_text:
            ehash = compute_exact_hash(cleaned)
            # 1. Fast path: exact text hash in variant partition (O(1))
            if ehash in hash_map:
                self.exact_hits += 1
                return True, hash_map[ehash]

            nums = extract_numbers(cleaned)
            q_len = len(cleaned)
            # Token set for candidate pruning (words with len >= 4)
            q_tokens = set(re.findall(r"\b[a-z]{4,}\b", cleaned))

            best_sim = 0.0
            best_qid = None
            best_nums_match = False

            for cand in part:
                # Length filter: if lengths differ by more than 20%, similarity cannot exceed 0.83
                if cand.length > 0:
                    ratio = cand.length / float(q_len)
                    if ratio < 0.75 or ratio > 1.33:
                        continue

                # Token intersection filter: must share significant vocabulary
                if q_tokens and cand.tokens:
                    shared = len(q_tokens & cand.tokens)
                    if shared < min(3, len(q_tokens) // 3):
                        continue

                self.comparisons_made += 1
                sim = SequenceMatcher(None, cleaned, cand.cleaned_norm).ratio()
                if sim > best_sim:
                    best_sim = sim
                    best_qid = cand.qid
                    best_nums_match = numbers_match(nums, cand.numbers)

            if best_sim >= self.similarity_threshold:
                if best_nums_match:
                    self.similar_hits += 1
                    return True, best_qid
                else:
                    self.rejected_by_numbers += 1

            # Unique question: index it in this variant partition
            record = IndexedQuestion(
                qid=qid,
                paper_code=paper_code,
                question_number=question_number,
                variant=variant,
                cleaned_norm=cleaned,
                exact_hash=ehash,
                numbers=nums,
                length=q_len,
                tokens=q_tokens,
                perceptual_hash=perceptual_hash,
            )
            part.append(record)
            hash_map[ehash] = qid
            return False, None

        else:
            # Image-only comparison within variant partition
            if perceptual_hash:
                for cand in part:
                    if cand.perceptual_hash:
                        if hamming_distance(perceptual_hash, cand.perceptual_hash) <= self.hamming_threshold:
                            self.similar_hits += 1
                            return True, cand.qid

            # Unique image question
            record = IndexedQuestion(
                qid=qid,
                paper_code=paper_code,
                question_number=question_number,
                variant=variant,
                cleaned_norm="",
                exact_hash="",
                numbers=[],
                length=0,
                tokens=set(),
                perceptual_hash=perceptual_hash,
            )
            part.append(record)
            return False, None

    def partition_counts(self) -> Dict[str, int]:
        return {f"{s}/v{v}": len(p) for (s, v), p in self.partitions.items()}


# Global singleton instance for pipeline-wide variant duplicate checking
_GLOBAL_DEDUP_INDEX = VariantDuplicateIndex()


def get_global_duplicate_index() -> VariantDuplicateIndex:
    return _GLOBAL_DEDUP_INDEX


def reset_global_duplicate_index() -> None:
    global _GLOBAL_DEDUP_INDEX
    _GLOBAL_DEDUP_INDEX = VariantDuplicateIndex()
