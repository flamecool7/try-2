"""core/insert_engine.py — Insert (source booklet) cropping engine.

NEW MODULE (2026-08-15, maintainer-directed).

Business / Economics / English / Geography papers ship a separate INSERT
booklet (case studies, source extracts, data tables, stimulus material) that
questions reference by label ("Source A", "Figure 1", "Case Study 1", ...).
Historically the pipeline recognised insert files but discarded them.

This engine crops inserts independently of the locked QP/MS croppers (which
are byte-untouched).  Two outputs per insert:
  1. Clean whole pages — junk (barcode/header/footer) stripped, 2280px wide —
     written to a paper-level ``_insert/`` folder with a manifest.
  2. Per-question referenced sections — the section(s) a question's text
     names ("Source A") are cropped and attached into that question folder as
     ``{QID}_IN.webp`` (e.g. ``22_Winter_2025_Q5_IN.webp``).  Multiple
     referenced sections are stitched vertically into the single webp.

Science "inserts" are actually data booklets (periodic table / formula sheet /
constants) and are skipped as reference data (100% reference-removal
invariant).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
from PIL import Image

try:
    import fitz  # PyMuPDF
except ImportError:
    import pymupdf as fitz

TARGET_WIDTH = 2280

# Section-header grammar: "Source A", "Figure 1", "Case Study 2", "Extract B",
# "Item 3", "Section A", "Stimulus 1", "Exhibit 4", "Table 2", "Diagram 1".
# Also handles Cambridge suffixes like "Source A for Question 1", "Source B: Question 2".
_SECTION_HEADER_RE = re.compile(
    r"^\s*(?P<kind>Source|Figure|Fig\.?|Extract|Case\s*Study|Case|Item|"
    r"Section|Stimulus|Exhibit|Table|Diagram|Photo|Map|Chart|Text)\s*"
    r"(?P<id>[A-Z]|\d{1,3})(?:\s*[:–-]?\s*(?:for\s+)?(?:Questions?|Q\b)?[^\n]*)?\s*$",
    re.IGNORECASE,
)

# Reference-data signals (science data booklet inserts).
_REF_SIGNALS = (
    "periodic table",
    "physical constants",
    "ionisation energies",
    "ionization energies",
    "bond energies",
    "standard entropy",
    "electrode potentials",
    "qualitative analysis",
    "formula sheet",
    "mathematical formulae",
    "data booklet",
    "mf19", "mf9", "mf20",
    "spectroscopy",
    "chemical shift",
)

# Insert cover/instruction-page signals (the front page of an insert carries
# only the "This document has N pages" banner, the "INFORMATION" block and the
# annotate/planning instructions — no stimulus content).
_COVER_SIGNALS = (
    "this insert contains",
    "you may annotate this insert",
    "do not write your answers on the insert",
    "use the blank spaces for planning",
)

# Back-matter signals (copyright / disclosure acknowledgements at the end).
_BACKMATTER_SIGNALS = (
    "permission to reproduce",
    "to avoid the issue of disclosure",
    "copyright acknowledgements",
    "acknowledgements booklet",
    "reasonable effort has been made",
    "publisher (ucles)",
    "cambridge assessment international education",
    "brand name of the university of cambridge",
    "department of the university of cambridge",
    "online in the cambridge",
    "freely available to download",
    "third-party owned material",
    "trace copyright holders",
)


def _classify_page(text: str, has_sections: bool = False) -> str:
    """Return 'cover' | 'backmatter' | 'content' for an insert page."""
    if has_sections:
        return "content"
    t = text.lower()
    if any(s in t for s in _BACKMATTER_SIGNALS):
        return "backmatter"
    cover_hits = sum(1 for s in _COVER_SIGNALS if s in t)
    if cover_hits >= 2:
        return "cover"
    return "content"


@dataclass
class InsertSection:
    id: str                 # full label, e.g. "Source A"
    kind: str               # "Source"
    page_idx: int
    top_pdf: float          # PDF y (pt) of the section header
    bottom_pdf: float       # PDF y (pt) of the section end (next header / page end)
    text: str = ""


@dataclass
class InsertResult:
    pages: List[Image.Image] = field(default_factory=list)   # junk-stripped, 2280px
    sections: List[InsertSection] = field(default_factory=list)
    page_texts: List[str] = field(default_factory=list)
    page_kinds: List[str] = field(default_factory=list)      # 'cover'|'content'|'backmatter'
    is_reference_data: bool = False
    source_name: str = ""


def _detect_reference_data(full_text: str) -> bool:
    t = full_text.lower()
    # periodic table: many element symbols in a compact block
    elements = {"hydrogen", "helium", "lithium", "beryllium", "boron",
                "carbon", "nitrogen", "oxygen", "fluorine", "neon", "sodium",
                "magnesium", "aluminium", "silicon", "phosphorus", "sulfur",
                "chlorine", "argon", "potassium", "calcium", "iron", "copper",
                "zinc", "bromine", "iodine", "silver", "lead", "uranium"}
    if sum(1 for e in elements if re.search(rf"\b{e}\b", t)) >= 20:
        return True
    return any(s in t for s in _REF_SIGNALS)


def _trim_bottom_whitespace(img: Image.Image, pad: int = 24,
                            dark_threshold: int = 248,
                            min_ink_pixels: int = 3) -> Image.Image:
    """Trim excessive empty whitespace from the bottom of an insert crop.

    Preserves all legitimate content (text, tables, borders, diagrams, footnotes).
    Ensures width is kept at exactly img.width (target 2280px).
    pad: padding in pixels below the lowest detected ink row (default 24px per spec).
    dark_threshold: pixel brightness below which a pixel is considered ink (<248).
    min_ink_pixels: minimum number of dark pixels in a row to count as ink,
                    preventing isolated noise artifacts from preventing trim.
    """
    if img.width <= 10 or img.height <= 50:
        return img
    gray = np.asarray(img.convert("L"))
    dark = gray < dark_threshold
    row_counts = dark.sum(axis=1)
    active_rows = np.where(row_counts >= min_ink_pixels)[0]
    if active_rows.size == 0:
        active_rows = np.where(row_counts >= 1)[0]
        if active_rows.size == 0:
            return img

    last_ink_row = int(active_rows.max())
    new_bottom = min(img.height, last_ink_row + pad + 1)
    if new_bottom < img.height and new_bottom > 20:
        return img.crop((0, 0, img.width, new_bottom))
    return img


class InsertEngine:
    def __init__(self, target_width: int = TARGET_WIDTH, quality: int = 95,
                 dpi: int = 150):
        self.target_width = target_width
        self.quality = quality
        self.dpi = dpi

    # ------------------------------------------------------------------
    def _render(self, pdf_path: Path):
        from .pdf_io import render_pdf_with_rotation_info
        return render_pdf_with_rotation_info(str(pdf_path), dpi=self.dpi)

    def _strip_junk(self, page_img: Image.Image, page, scale: float) -> Image.Image:
        """Crop out header/footer junk bands and copyright backmatter, then resize to target width."""
        h = float(page.rect.height)

        # 1. Top boundary: strip top page numbers (y < 55) and running slugs, but preserve section headers and content
        top_pt = 0.0
        for wd in page.get_text("words"):
            y0, y1, txt = wd[1], wd[3], wd[4].strip()
            if y1 < 55 and (re.fullmatch(r"\d{1,3}", txt) or any(s in txt.lower() for s in ("turn", "over", "insert", "ucles"))):
                top_pt = max(top_pt, y1 + 3.0)

        # 2. Bottom boundary: strip footer and copyright/backmatter
        bottom_pt = h
        for b in page.get_text("blocks"):
            txt_l = b[4].lower()
            if any(s in txt_l for s in _BACKMATTER_SIGNALS):
                bottom_pt = min(bottom_pt, b[1] - 8.0)

        for wd in page.get_text("words"):
            y0, txt = wd[1], wd[4].strip().lower()
            if y0 > h * 0.92:
                if any(s in txt for s in ("©", "ucles", "copyright", "turn", "over", "insert", "acknowledgement", "publisher")) or re.fullmatch(r"\d{1,3}", txt):
                    bottom_pt = min(bottom_pt, y0 - 4.0)

        px_top = max(0, int(round(top_pt * scale)))
        px_bottom = min(page_img.height, int(round(bottom_pt * scale)))
        if px_bottom <= px_top:
            px_bottom = page_img.height
            px_top = 0
        img = page_img.crop((0, px_top, page_img.width, px_bottom))

        # resize to 2280 wide
        if img.width != self.target_width:
            scale2 = self.target_width / float(img.width)
            new_h = max(1, int(round(img.height * scale2)))
            img = img.resize((self.target_width, new_h), Image.Resampling.LANCZOS)
        img = _trim_bottom_whitespace(img, pad=24)
        return img

    def _detect_sections(self, doc, page_count: int) -> List[InsertSection]:
        sections: List[InsertSection] = []
        for pi in range(page_count):
            page = doc[pi]
            h = float(page.rect.height)
            lines = page.get_text("dict").get("blocks", [])
            headers = []  # (top_pdf, label)
            backmatter_top = h
            for block in lines:
                for ln in block.get("lines", []):
                    txt = "".join(
                        s.get("text", "") for s in ln.get("spans", [])
                    ).strip()
                    txt_l = txt.lower()
                    if any(bm in txt_l for bm in _BACKMATTER_SIGNALS):
                        backmatter_top = min(backmatter_top, ln["bbox"][1])
                    m = _SECTION_HEADER_RE.match(txt)
                    if not m:
                        continue
                    y0 = ln["bbox"][1]
                    label = f"{m.group('kind').title()} {m.group('id').upper()}".replace("  ", " ")
                    # normalise "Fig." kind
                    label = re.sub(r"^Fig\.?\s", "Figure ", label, flags=re.I)
                    headers.append((y0, label))
            headers.sort(key=lambda x: x[0])

            # Determine footer top on this page (page numbers, © UCLES, [Turn over, printer slugs)
            footer_top = h
            for wd in page.get_text("words"):
                y0_wd, txt_wd = wd[1], wd[4].lower().strip()
                if y0_wd > h * 0.92:
                    if any(s in txt_wd for s in ("©", "ucles", "copyright", "turn", "over", "insert", "acknowledgement", "publisher")) or re.fullmatch(r"\d{1,3}", txt_wd):
                        footer_top = min(footer_top, y0_wd)
            page_content_bottom = min(h, footer_top, backmatter_top - 8.0)

            for i, (y0, label) in enumerate(headers):
                bottom = headers[i + 1][0] if i + 1 < len(headers) else (
                    page_content_bottom if page_content_bottom > y0 else h
                )
                kind = label.split()[0]
                sections.append(InsertSection(
                    id=label, kind=kind, page_idx=pi,
                    top_pdf=y0, bottom_pdf=bottom, text="",
                ))
        return sections

    # ------------------------------------------------------------------
    def process_insert(self, pdf_path) -> Optional[InsertResult]:
        pdf_path = Path(pdf_path)
        try:
            images, scale, rotations, doc = self._render(pdf_path)
        except Exception:
            return None
        try:
            result = InsertResult(source_name=pdf_path.name)
            full_text = ""
            result.sections = self._detect_sections(doc, len(doc))
            section_pages = {s.page_idx for s in result.sections}
            for pi in range(len(doc)):
                pt = doc[pi].get_text("text") or ""
                full_text += pt + "\n"
                result.page_texts.append(pt)
                result.page_kinds.append(_classify_page(pt, has_sections=(pi in section_pages)))
            result.is_reference_data = _detect_reference_data(full_text)
            for pi in range(len(doc)):
                page = doc[pi]
                img = self._strip_junk(images[pi], page, scale)
                result.pages.append(img)
            return result
        finally:
            doc.close()

    # ------------------------------------------------------------------
    def _section_image(self, pdf_path: Path, section: InsertSection) -> Optional[Image.Image]:
        from .pdf_io import render_pdf_with_rotation_info
        images, scale, rotations, doc = render_pdf_with_rotation_info(str(pdf_path), dpi=self.dpi)
        try:
            page = doc[section.page_idx]
            img = images[section.page_idx]
            h = page.rect.height

            # Top boundary: ensure clean padding above section header,
            # but strictly exclude any text above it (such as top page numbers)
            words_above = [
                wd for wd in page.get_text("words")
                if wd[3] <= section.top_pdf
            ]
            if words_above:
                highest_bottom_above = max(wd[3] for wd in words_above)
                top_pt = max(section.top_pdf - 8.0, highest_bottom_above + 3.0)
            else:
                top_pt = max(0.0, section.top_pdf - 8.0)

            # Bottom boundary: stop above any footer, bottom page number, or copyright block
            bottom_pt = section.bottom_pdf

            # Stop above backmatter / copyright acknowledgement block
            for b in page.get_text("blocks"):
                txt_l = b[4].lower()
                if any(sig in txt_l for sig in _BACKMATTER_SIGNALS):
                    if b[1] > section.top_pdf:
                        bottom_pt = min(bottom_pt, b[1] - 8.0)

            for wd in page.get_text("words"):
                y0_wd, txt_wd = wd[1], wd[4].lower().strip()
                if y0_wd > h * 0.92 and y0_wd > section.top_pdf:
                    if any(term in txt_wd for term in ("©", "ucles", "copyright", "turn", "over", "insert", "acknowledgement", "publisher")) or re.fullmatch(r"\d{1,3}", txt_wd):
                        bottom_pt = min(bottom_pt, y0_wd - 4.0)

            # Bound strictly by the last content word that actually belongs to this section
            sec_words = [w for w in page.get_text("words") if section.top_pdf <= w[1] <= bottom_pt]
            if sec_words:
                last_word_bottom = max(w[3] for w in sec_words)
                bottom_pt = min(bottom_pt, last_word_bottom + 14.0)

            top = int(round(top_pt * scale))
            bottom = int(round(bottom_pt * scale))
            top = max(0, top)
            bottom = min(img.height, bottom)
            if bottom <= top:
                return None
            crop = img.crop((0, top, img.width, bottom))
            if crop.width != self.target_width:
                s2 = self.target_width / float(crop.width)
                crop = crop.resize((self.target_width, max(1, int(round(crop.height * s2)))),
                                   Image.Resampling.LANCZOS)
            crop = _trim_bottom_whitespace(crop, pad=24)
            return crop
        finally:
            doc.close()

    # ------------------------------------------------------------------
    def save_webp(self, img: Image.Image, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        img.save(path, "WEBP", quality=self.quality, method=2)


# ---------------------------------------------------------------------------
# Convenience helpers used by the orchestrator
# ---------------------------------------------------------------------------

# The set of labels a question's text may reference.  Matched case-insensitively
# against section ids (e.g. "Source A" references section "Source A").
def referenced_sections(question_text: str, sections: List[InsertSection]) -> List[InsertSection]:
    """Return the sections whose label appears in the question text."""
    if not question_text or not sections:
        return []
    t = question_text.lower()
    out = []
    for s in sections:
        # "Source A" and "source a" and "source A" all match
        label_l = s.id.lower()
        # also match "figure 1" vs "fig. 1"
        alt = re.sub(r"^figure\s+", "fig. ", label_l)
        if label_l in t or alt in t:
            out.append(s)
    return out


def write_insert_outputs(engine: InsertEngine, result: InsertResult,
                         pdf_path: Path, output_root: Path,
                         level: str, subject: str, paper_type_folder: str,
                         paper_code: str,
                         question_refs: List[Tuple[str, str]] = None) -> dict:
    """Write whole-page crops + per-question section crops.

    question_refs: list of (question_folder_path_str, question_text) for
    per-question section attachment.
    Returns a summary dict.
    """
    summary = {"whole_pages": 0, "sections": 0, "reference_data_skipped": False,
               "skipped_pages": 0}

    if result.is_reference_data:
        print(f"    [insert] {pdf_path.name}: reference data (data booklet) — "
              f"skipped per 100% reference-removal invariant")
        summary["reference_data_skipped"] = True
        return summary

    # 1. whole pages — SKIP cover/instruction and back-matter pages so only the
    #    actual stimulus content is emitted (2026-08-15, user requirement).
    if paper_type_folder:
        base = output_root / level / subject / paper_type_folder / "_insert" / paper_code
    else:
        base = output_root / level / subject / "_insert" / paper_code
    base.mkdir(parents=True, exist_ok=True)
    src_page_of_output = []  # (output_index, source_page_1based)
    out_i = 0
    for i, img in enumerate(result.pages):
        kind = result.page_kinds[i] if i < len(result.page_kinds) else "content"
        if kind in ("cover", "backmatter"):
            summary["skipped_pages"] += 1
            print(f"    [insert] {pdf_path.name}: skipped {kind} page {i + 1}")
            continue
        out_i += 1
        p = base / f"{paper_code}_p{out_i}.webp"
        engine.save_webp(img, p)
        summary["whole_pages"] += 1
        src_page_of_output.append((out_i, i + 1))
    # manifest
    manifest = {
        "paper": paper_code,
        "source": pdf_path.name,
        "pages": summary["whole_pages"],
        "skipped_pages": summary["skipped_pages"],
        "page_map": {f"p{out}": f"source page {src}" for out, src in src_page_of_output},
        "sections": [{"id": s.id, "page": s.page_idx + 1,
                      "top": round(s.top_pdf, 1), "bottom": round(s.bottom_pdf, 1)}
                     for s in result.sections],
    }
    (base / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    # 2. per-question sections -> {QID}_IN.webp (stitch multiple sections)
    if question_refs:
        for qfolder_str, qtext in question_refs:
            refs = referenced_sections(qtext, result.sections)
            if not refs:
                continue
            qfolder = Path(qfolder_str)
            qname = qfolder.name
            imgs = []
            for s in refs:
                img = engine._section_image(pdf_path, s)
                if img is not None:
                    imgs.append(img)
            if not imgs:
                continue
            combined = _stitch_vertical(imgs, target_width=engine.target_width)
            p = qfolder / f"{qname}_IN.webp"
            engine.save_webp(combined, p)
            summary["sections"] += 1
    return summary


def _stitch_vertical(images: List[Image.Image], target_width: int = TARGET_WIDTH,
                     gap_px: int = 20) -> Image.Image:
    """Stack a list of (already width-normalised) images into one tall image,
    with a white gap between them.  Returns a single 2280px-wide image."""
    if not images:
        raise ValueError("no images to stitch")
    if len(images) == 1:
        img = images[0]
        if img.width != target_width:
            s = target_width / float(img.width)
            img = img.resize((target_width, max(1, int(round(img.height * s)))),
                             Image.Resampling.LANCZOS)
        return _trim_bottom_whitespace(img, pad=24)
    norm = []
    for im in images:
        if im.width != target_width:
            s = target_width / float(im.width)
            im = im.resize((target_width, max(1, int(round(im.height * s)))),
                           Image.Resampling.LANCZOS)
        norm.append(_trim_bottom_whitespace(im, pad=24))
    total_h = sum(im.height for im in norm) + gap_px * (len(norm) - 1)
    canvas = Image.new("RGB", (target_width, max(1, total_h)), "white")
    y = 0
    for im in norm:
        canvas.paste(im, (0, y))
        y += im.height + gap_px
    return _trim_bottom_whitespace(canvas, pad=24)
