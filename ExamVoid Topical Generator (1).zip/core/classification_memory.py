"""Persistent, indexed classification memory.

This module is deliberately separate from both crop engines and ``metadata.json``.
It stores concise, reusable classification evidence in SQLite and retrieves only a
small subject-local candidate set through an inverted token index.  It never scans
an output archive during classification and never writes into a question folder.

The classifier remains responsible for deciding what the *current* question
assesses.  Memory is supporting evidence only: callers receive bounded positive
and negative support, then apply it only where direct current-question evidence
already exists.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Mapping, Sequence


MEMORY_SCHEMA_VERSION = "1"
MEMORY_VERSION = "classification-memory/1"
DEFAULT_DB_NAME = "classification_memory.sqlite3"
MAX_TOPICS_PER_RECORD = 4
MAX_QUERY_TOKENS = 36
DEFAULT_RESULT_LIMIT = 8
MIN_SIMILARITY = 0.055
HIGH_CONFIDENCE_MINIMUM = 0.90

# Intentional broad stop list: the memory index should retrieve meaningful
# syllabus/concept signals, not every occurrence of "explain" or "question".
_TOKEN_RE = re.compile(r"[a-z][a-z0-9]{1,}")
_MEMORY_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "being", "by", "can",
    "could", "describe", "determine", "do", "does", "each", "explain", "for",
    "from", "give", "has", "have", "how", "identify", "in", "is", "it", "its",
    "may", "of", "on", "or", "question", "show", "state", "the", "their",
    "this", "to", "use", "using", "was", "what", "when", "which", "who", "will",
    "with", "would", "you", "your", "answer", "business", "candidate", "context",
    "marks", "mark", "knowledge", "understanding", "analysis", "application",
    "evaluation", "indicative", "content", "response", "responses", "including",
}

TRUST_LEVELS = frozenset({"verified", "high_confidence", "correction", "negative"})


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def default_memory_path() -> Path:
    """Return the configurable repository-local memory database path.

    The path is intentionally outside output archives and subject configs.  An
    environment override is useful for isolated tests, batch jobs, and review
    environments without changing pipeline metadata.
    """
    configured = os.environ.get("EXAMVOID_CLASSIFICATION_MEMORY_DB", "").strip()
    if configured:
        return Path(configured).expanduser()
    root = Path(__file__).resolve().parents[1]
    return root / "memory" / DEFAULT_DB_NAME


def _normalise_text(value: str | None) -> str:
    return re.sub(r"\s+", " ", str(value or "").lower()).strip()


def _excerpt(value: str | None, max_chars: int) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text[:max_chars]


def _unique_strings(values: Iterable[str] | None, *, maximum: int = MAX_TOPICS_PER_RECORD) -> list[str]:
    out: list[str] = []
    for raw in values or ():
        value = str(raw or "").strip()
        if value and value not in out:
            out.append(value)
    if len(out) > maximum:
        raise ValueError(f"classification memory accepts at most {maximum} topics per record")
    return out


def _evidence_list(values: Iterable[str] | None) -> list[str]:
    """Keep short factual evidence, never a private chain-of-thought trace."""
    out: list[str] = []
    for raw in values or ():
        item = re.sub(r"\s+", " ", str(raw or "")).strip()
        if item and item not in out:
            out.append(item[:280])
    return out[:12]


def _field_tokens(text: str | None, *, source_weight: float) -> dict[str, float]:
    """Return a compact unigram + adjacent-phrase feature vector.

    Prefixing phrase keys avoids accidental collisions with ordinary words.
    The vector is stored once at write time and is queried through SQLite's
    B-tree index; no record corpus is loaded into a classifier process.
    """
    words = [
        token for token in _TOKEN_RE.findall(_normalise_text(text))
        if token not in _MEMORY_STOPWORDS and len(token) >= 2
    ]
    weights: dict[str, float] = {}
    for word in words:
        weights[word] = max(weights.get(word, 0.0), source_weight)
    # Adjacent phrases preserve high-value concepts such as ``break even``,
    # ``assessment centre`` and ``working capital`` without an embeddings
    # dependency.  A phrase has slightly more discriminative weight.
    for left, right in zip(words, words[1:]):
        if left == right:
            continue
        phrase = f"p:{left}_{right}"
        weights[phrase] = max(weights.get(phrase, 0.0), source_weight * 1.45)
    return weights


def memory_feature_vector(question_text: str | None, mark_scheme_text: str | None = None) -> dict[str, float]:
    """Build a weighted retrieval vector with QP evidence dominant over MS text."""
    vector = _field_tokens(question_text, source_weight=1.0)
    # Mark schemes are useful evidence but cannot become the primary object of
    # classification.  Their retrieval contribution is deliberately weaker.
    for token, weight in _field_tokens(mark_scheme_text, source_weight=0.35).items():
        vector[token] = max(vector.get(token, 0.0), weight)
    return vector


def _query_tokens(vector: Mapping[str, float]) -> list[str]:
    # Phrases first, then longer terms.  This limits the SQL IN clause to a
    # small, high-information query even for a very long multi-page question.
    ranked = sorted(
        vector,
        key=lambda token: (
            token.startswith("p:"),
            vector[token],
            len(token),
            token,
        ),
        reverse=True,
    )
    return ranked[:MAX_QUERY_TOKENS]


@dataclass(frozen=True)
class MemoryMatch:
    """A single selectively retrieved memory record, safe for classifier audit."""

    record_id: int
    trust_level: str
    similarity: float
    topics: tuple[str, ...]
    major_topics: tuple[str, ...]
    negative_topics: tuple[str, ...]
    evidence: tuple[str, ...]
    source: str
    paper: str
    variant: str
    question_number: str
    classifier_version: str
    taxonomy_version: str
    syllabus_version: str
    memory_version: str

    def audit_dict(self) -> dict:
        return {
            "record_id": self.record_id,
            "trust_level": self.trust_level,
            "similarity": round(self.similarity, 4),
            "topics": list(self.topics),
            "major_topics": list(self.major_topics),
            "negative_topics": list(self.negative_topics),
            "evidence": list(self.evidence),
            "source": self.source,
            "paper": self.paper,
            "variant": self.variant,
            "question_number": self.question_number,
            "classifier_version": self.classifier_version,
            "taxonomy_version": self.taxonomy_version,
            "syllabus_version": self.syllabus_version,
            "memory_version": self.memory_version,
        }


@dataclass
class MemoryContext:
    """Bounded aggregate support derived from a handful of retrieved records."""

    query_tokens: tuple[str, ...] = ()
    matches: tuple[MemoryMatch, ...] = ()
    detailed_positive: dict[str, float] = field(default_factory=dict)
    detailed_negative: dict[str, float] = field(default_factory=dict)
    major_positive: dict[str, float] = field(default_factory=dict)
    major_negative: dict[str, float] = field(default_factory=dict)
    high_confidence_counts: dict[str, int] = field(default_factory=dict)

    @classmethod
    def empty(cls) -> "MemoryContext":
        return cls()

    def audit_summary(self) -> dict:
        """Compact, factual audit data; no question corpus is exposed."""
        return {
            "query_token_count": len(self.query_tokens),
            "retrieved_count": len(self.matches),
            "matches": [match.audit_dict() for match in self.matches],
            "detailed_positive": {k: round(v, 4) for k, v in self.detailed_positive.items()},
            "detailed_negative": {k: round(v, 4) for k, v in self.detailed_negative.items()},
            "major_positive": {k: round(v, 4) for k, v in self.major_positive.items()},
            "major_negative": {k: round(v, 4) for k, v in self.major_negative.items()},
            "high_confidence_counts": dict(self.high_confidence_counts),
        }


class ClassificationMemory:
    """SQLite-backed classification memory with indexed, subject-local retrieval.

    ``ClassificationMemory`` stores only concise excerpts, factual evidence and
    an inverted feature index.  It does not read question folders, output
    archives or metadata.json.  A caller can use a temporary database for a
    review session or the default ``memory/classification_memory.sqlite3`` for
    a persistent installation.
    """

    def __init__(self, db_path: str | Path | None = None, *, create: bool = True,
                 read_only: bool = False):
        self.path = Path(db_path) if db_path is not None else default_memory_path()
        self._conn: sqlite3.Connection | None = None
        if read_only and not self.path.exists():
            return
        if not create and not self.path.exists():
            return
        if not read_only:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        if read_only:
            uri = f"file:{self.path.resolve().as_posix()}?mode=ro"
            self._conn = sqlite3.connect(uri, uri=True, timeout=30)
        else:
            self._conn = sqlite3.connect(str(self.path), timeout=30)
        self._conn.row_factory = sqlite3.Row
        if not read_only:
            self._initialise_schema()

    @classmethod
    def open_default(cls, *, create: bool = False) -> "ClassificationMemory | None":
        """Open the configured default only when it already exists by default.

        This keeps a fresh installation byte- and behavior-compatible until a
        review/import process intentionally initializes a memory database.
        """
        path = default_memory_path()
        if not create and not path.exists():
            return None
        return cls(path, create=create)

    @property
    def available(self) -> bool:
        return self._conn is not None

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> "ClassificationMemory":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @contextmanager
    def _transaction(self):
        if self._conn is None:
            raise RuntimeError("classification memory database is unavailable")
        try:
            self._conn.execute("BEGIN IMMEDIATE")
            yield self._conn
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

    def _initialise_schema(self) -> None:
        assert self._conn is not None
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS memory_meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS memory_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_key TEXT NOT NULL UNIQUE,
                subject TEXT NOT NULL,
                level TEXT NOT NULL DEFAULT '',
                paper TEXT NOT NULL DEFAULT '',
                variant TEXT NOT NULL DEFAULT '',
                question_number TEXT NOT NULL DEFAULT '',
                trust_level TEXT NOT NULL,
                topics_json TEXT NOT NULL,
                major_topics_json TEXT NOT NULL,
                negative_topics_json TEXT NOT NULL,
                evidence_json TEXT NOT NULL,
                question_excerpt TEXT NOT NULL,
                mark_scheme_excerpt TEXT NOT NULL,
                token_weight_sum REAL NOT NULL,
                classifier_version TEXT NOT NULL,
                taxonomy_version TEXT NOT NULL,
                syllabus_version TEXT NOT NULL DEFAULT '',
                memory_version TEXT NOT NULL,
                confidence REAL,
                source TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1
            );
            CREATE INDEX IF NOT EXISTS idx_memory_records_subject_active
                ON memory_records(subject, active);
            CREATE INDEX IF NOT EXISTS idx_memory_records_versions
                ON memory_records(subject, taxonomy_version, classifier_version);
            CREATE TABLE IF NOT EXISTS memory_tokens (
                record_id INTEGER NOT NULL REFERENCES memory_records(id) ON DELETE CASCADE,
                subject TEXT NOT NULL,
                token TEXT NOT NULL,
                weight REAL NOT NULL,
                PRIMARY KEY (record_id, token)
            );
            CREATE INDEX IF NOT EXISTS idx_memory_tokens_subject_token
                ON memory_tokens(subject, token, record_id);
            CREATE TABLE IF NOT EXISTS memory_topics (
                record_id INTEGER NOT NULL REFERENCES memory_records(id) ON DELETE CASCADE,
                subject TEXT NOT NULL,
                topic TEXT NOT NULL,
                topic_kind TEXT NOT NULL,
                polarity INTEGER NOT NULL,
                PRIMARY KEY (record_id, topic, topic_kind, polarity)
            );
            CREATE INDEX IF NOT EXISTS idx_memory_topics_subject_topic
                ON memory_topics(subject, topic, topic_kind, polarity, record_id);
            CREATE TABLE IF NOT EXISTS memory_relationships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject TEXT NOT NULL,
                left_record_id INTEGER NOT NULL REFERENCES memory_records(id) ON DELETE CASCADE,
                right_record_id INTEGER NOT NULL REFERENCES memory_records(id) ON DELETE CASCADE,
                relation_type TEXT NOT NULL DEFAULT 'similar_question',
                similarity REAL NOT NULL,
                evidence TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                CHECK (left_record_id < right_record_id),
                UNIQUE(left_record_id, right_record_id, relation_type)
            );
            CREATE INDEX IF NOT EXISTS idx_memory_relationships_left
                ON memory_relationships(subject, left_record_id, relation_type);
            CREATE INDEX IF NOT EXISTS idx_memory_relationships_right
                ON memory_relationships(subject, right_record_id, relation_type);
            """
        )
        # Forward-compatible lightweight migration for databases made by an
        # earlier memory schema before explicit syllabus-version provenance.
        _columns = {row[1] for row in self._conn.execute("PRAGMA table_info(memory_records)")}
        if "syllabus_version" not in _columns:
            self._conn.execute(
                "ALTER TABLE memory_records ADD COLUMN syllabus_version TEXT NOT NULL DEFAULT ''"
            )
        if "variant" not in _columns:
            self._conn.execute(
                "ALTER TABLE memory_records ADD COLUMN variant TEXT NOT NULL DEFAULT ''"
            )
        self._conn.execute(
            "INSERT OR IGNORE INTO memory_meta(key, value) VALUES (?, ?)",
            ("memory_schema_version", MEMORY_SCHEMA_VERSION),
        )
        self._conn.execute(
            "INSERT OR IGNORE INTO memory_meta(key, value) VALUES (?, ?)",
            ("memory_version", MEMORY_VERSION),
        )
        self._conn.commit()

    def _store(self, *, subject: str, level: str = "", paper: str = "", variant: str = "",
               question_number: str = "", trust_level: str,
               topics: Iterable[str] | None = None,
               major_topics: Iterable[str] | None = None,
               negative_topics: Iterable[str] | None = None,
               evidence: Iterable[str] | None = None,
               question_text: str = "", mark_scheme_text: str = "",
               classifier_version: str = "", taxonomy_version: str = "",
               syllabus_version: str = "", confidence: float | None = None, source: str = "",
               record_key: str | None = None) -> int:
        if trust_level not in TRUST_LEVELS:
            raise ValueError(f"unsupported memory trust level: {trust_level!r}")
        subject = str(subject or "").strip()
        if not subject:
            raise ValueError("memory record requires a subject")
        positives = _unique_strings(topics)
        majors = _unique_strings(major_topics)
        negatives = _unique_strings(negative_topics)
        if set(positives) & set(negatives) or set(majors) & set(negatives):
            raise ValueError("a memory record cannot mark the same topic positive and negative")
        if trust_level in {"verified", "high_confidence", "correction"} and not (positives or majors):
            raise ValueError(f"{trust_level} memory requires a positive detailed or major topic")
        if trust_level == "negative" and not negatives:
            raise ValueError("negative memory requires at least one rejected topic")
        if trust_level == "high_confidence":
            if confidence is None or not (HIGH_CONFIDENCE_MINIMUM <= float(confidence) <= 1.0):
                raise ValueError(
                    f"high-confidence memory requires confidence >= {HIGH_CONFIDENCE_MINIMUM:.2f}"
                )
        if confidence is not None and not (0.0 <= float(confidence) <= 1.0):
            raise ValueError("confidence must be between 0 and 1")

        vector = memory_feature_vector(question_text, mark_scheme_text)
        if not vector:
            raise ValueError("memory record requires meaningful question or mark-scheme text")
        factual_evidence = _evidence_list(evidence)
        question_excerpt = _excerpt(question_text, 1400)
        mark_scheme_excerpt = _excerpt(mark_scheme_text, 1000)
        now = _utc_now()
        payload = {
            "subject": subject,
            "level": str(level or ""),
            "paper": str(paper or ""),
            "variant": str(variant or ""),
            "question_number": str(question_number or ""),
            "trust_level": trust_level,
            "topics": positives,
            "major_topics": majors,
            "negative_topics": negatives,
            "taxonomy_version": str(taxonomy_version or ""),
            "syllabus_version": str(syllabus_version or ""),
            "question_excerpt": question_excerpt,
            "mark_scheme_excerpt": mark_scheme_excerpt,
            "source": str(source or ""),
        }
        stable_key = record_key or hashlib.sha256(
            json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest()

        with self._transaction() as conn:
            conn.execute(
                """
                INSERT INTO memory_records(
                    record_key, subject, level, paper, variant, question_number, trust_level,
                    topics_json, major_topics_json, negative_topics_json, evidence_json,
                    question_excerpt, mark_scheme_excerpt, token_weight_sum,
                    classifier_version, taxonomy_version, syllabus_version, memory_version, confidence,
                    source, created_at, updated_at, active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                ON CONFLICT(record_key) DO UPDATE SET
                    subject=excluded.subject, level=excluded.level, paper=excluded.paper,
                    variant=excluded.variant, question_number=excluded.question_number, trust_level=excluded.trust_level,
                    topics_json=excluded.topics_json, major_topics_json=excluded.major_topics_json,
                    negative_topics_json=excluded.negative_topics_json, evidence_json=excluded.evidence_json,
                    question_excerpt=excluded.question_excerpt,
                    mark_scheme_excerpt=excluded.mark_scheme_excerpt,
                    token_weight_sum=excluded.token_weight_sum,
                    classifier_version=excluded.classifier_version,
                    taxonomy_version=excluded.taxonomy_version,
                    syllabus_version=excluded.syllabus_version,
                    memory_version=excluded.memory_version, confidence=excluded.confidence,
                    source=excluded.source, updated_at=excluded.updated_at, active=1
                """,
                (
                    stable_key, subject, str(level or ""), str(paper or ""), str(variant or ""),
                    str(question_number or ""), trust_level,
                    json.dumps(positives, ensure_ascii=False),
                    json.dumps(majors, ensure_ascii=False),
                    json.dumps(negatives, ensure_ascii=False),
                    json.dumps(factual_evidence, ensure_ascii=False),
                    question_excerpt, mark_scheme_excerpt, float(sum(vector.values())),
                    str(classifier_version or ""), str(taxonomy_version or ""),
                    str(syllabus_version or ""), MEMORY_VERSION,
                    float(confidence) if confidence is not None else None,
                    str(source or ""), now, now,
                ),
            )
            row = conn.execute(
                "SELECT id FROM memory_records WHERE record_key=?", (stable_key,)
            ).fetchone()
            assert row is not None
            record_id = int(row["id"])
            conn.execute("DELETE FROM memory_tokens WHERE record_id=?", (record_id,))
            conn.execute("DELETE FROM memory_topics WHERE record_id=?", (record_id,))
            conn.executemany(
                "INSERT INTO memory_tokens(record_id, subject, token, weight) VALUES (?, ?, ?, ?)",
                [(record_id, subject, token, weight) for token, weight in vector.items()],
            )
            topic_rows = [
                (record_id, subject, topic, "detailed", 1) for topic in positives
            ] + [
                (record_id, subject, topic, "major", 1) for topic in majors
            ] + [
                (record_id, subject, topic, "negative", -1) for topic in negatives
            ]
            if topic_rows:
                conn.executemany(
                    "INSERT INTO memory_topics(record_id, subject, topic, topic_kind, polarity) VALUES (?, ?, ?, ?, ?)",
                    topic_rows,
                )
        return record_id

    def record_verified(self, *, subject: str, topics: Iterable[str] | None = None,
                        major_topics: Iterable[str] | None = None,
                        evidence: Iterable[str] | None = None, question_text: str,
                        mark_scheme_text: str = "", level: str = "", paper: str = "", variant: str = "",
                        question_number: str = "", classifier_version: str = "",
                        taxonomy_version: str = "", syllabus_version: str = "", source: str = "human_verified",
                        record_key: str | None = None) -> int:
        return self._store(
            subject=subject, level=level, paper=paper, variant=variant, question_number=question_number,
            trust_level="verified", topics=topics, major_topics=major_topics,
            evidence=evidence, question_text=question_text, mark_scheme_text=mark_scheme_text,
            classifier_version=classifier_version, taxonomy_version=taxonomy_version,
            syllabus_version=syllabus_version, source=source, record_key=record_key,
        )

    def record_high_confidence(self, *, subject: str, topics: Iterable[str] | None = None,
                               major_topics: Iterable[str] | None = None,
                               evidence: Iterable[str] | None = None, question_text: str,
                               mark_scheme_text: str = "", confidence: float,
                               level: str = "", paper: str = "", variant: str = "", question_number: str = "",
                               classifier_version: str = "", taxonomy_version: str = "",
                               syllabus_version: str = "", source: str = "high_confidence_classifier",
                               record_key: str | None = None) -> int:
        return self._store(
            subject=subject, level=level, paper=paper, variant=variant, question_number=question_number,
            trust_level="high_confidence", topics=topics, major_topics=major_topics,
            evidence=evidence, question_text=question_text, mark_scheme_text=mark_scheme_text,
            classifier_version=classifier_version, taxonomy_version=taxonomy_version,
            syllabus_version=syllabus_version, confidence=confidence, source=source, record_key=record_key,
        )

    def record_correction(self, *, subject: str, correct_topics: Iterable[str] | None = None,
                          correct_major_topics: Iterable[str] | None = None,
                          incorrect_topics: Iterable[str], reason: str,
                          question_text: str, mark_scheme_text: str = "", level: str = "",
                          paper: str = "", variant: str = "", question_number: str = "",
                          classifier_version: str = "", taxonomy_version: str = "",
                          syllabus_version: str = "", source: str = "human_correction",
                          record_key: str | None = None) -> int:
        return self._store(
            subject=subject, level=level, paper=paper, variant=variant, question_number=question_number,
            trust_level="correction", topics=correct_topics,
            major_topics=correct_major_topics, negative_topics=incorrect_topics,
            evidence=[reason], question_text=question_text, mark_scheme_text=mark_scheme_text,
            classifier_version=classifier_version, taxonomy_version=taxonomy_version,
            syllabus_version=syllabus_version, source=source, record_key=record_key,
        )

    def record_negative(self, *, subject: str, incorrect_topics: Iterable[str], reason: str,
                        question_text: str, mark_scheme_text: str = "", level: str = "",
                        paper: str = "", variant: str = "", question_number: str = "",
                        classifier_version: str = "", taxonomy_version: str = "",
                        syllabus_version: str = "", source: str = "reviewed_negative_example",
                        record_key: str | None = None) -> int:
        return self._store(
            subject=subject, level=level, paper=paper, variant=variant, question_number=question_number,
            trust_level="negative", negative_topics=incorrect_topics,
            evidence=[reason], question_text=question_text, mark_scheme_text=mark_scheme_text,
            classifier_version=classifier_version, taxonomy_version=taxonomy_version,
            syllabus_version=syllabus_version, source=source, record_key=record_key,
        )

    def record_similar_question_relation(self, left_record_id: int, right_record_id: int,
                                         *, similarity: float, evidence: str = "",
                                         source: str = "reviewed_similarity") -> int:
        """Persist a reviewed relationship between two existing memory records.

        Similarity is evidence, not a classification label.  Relationships are
        therefore explicit and review-controlled rather than being written for
        every retrieval query.
        """
        if self._conn is None:
            raise RuntimeError("classification memory database is unavailable")
        left, right = sorted((int(left_record_id), int(right_record_id)))
        if left == right:
            raise ValueError("a similar-question relationship needs two different records")
        if not 0.0 < float(similarity) <= 1.0:
            raise ValueError("similarity must be in (0, 1]")
        with self._transaction() as conn:
            records = conn.execute(
                "SELECT id, subject FROM memory_records WHERE id IN (?, ?)", (left, right)
            ).fetchall()
            if len(records) != 2:
                raise ValueError("both related memory records must exist")
            subjects = {str(row["subject"]) for row in records}
            if len(subjects) != 1:
                raise ValueError("similar-question relationships cannot cross subjects")
            subject = subjects.pop()
            conn.execute(
                """
                INSERT INTO memory_relationships(
                    subject, left_record_id, right_record_id, relation_type,
                    similarity, evidence, source, created_at
                ) VALUES (?, ?, ?, 'similar_question', ?, ?, ?, ?)
                ON CONFLICT(left_record_id, right_record_id, relation_type) DO UPDATE SET
                    similarity=excluded.similarity, evidence=excluded.evidence,
                    source=excluded.source, created_at=excluded.created_at
                """,
                (subject, left, right, float(similarity), _excerpt(evidence, 280), str(source or ""), _utc_now()),
            )
            row = conn.execute(
                "SELECT id FROM memory_relationships WHERE left_record_id=? AND right_record_id=? "
                "AND relation_type='similar_question'", (left, right)
            ).fetchone()
            assert row is not None
            return int(row["id"])

    def similar_question_relationships(self, record_id: int, *, limit: int = 20) -> list[dict]:
        """Return persisted reviewed similar-question links for one record."""
        if self._conn is None:
            return []
        rows = self._conn.execute(
            """
            SELECT id, subject, left_record_id, right_record_id, similarity,
                   evidence, source, created_at
            FROM memory_relationships
            WHERE relation_type='similar_question' AND (left_record_id=? OR right_record_id=?)
            ORDER BY similarity DESC, id ASC LIMIT ?
            """,
            (int(record_id), int(record_id), max(1, min(int(limit), 100))),
        ).fetchall()
        return [dict(row) for row in rows]

    def retrieve(self, *, subject: str, question_text: str,
                 mark_scheme_text: str = "",
                 allowed_detailed_topics: Iterable[str] | None = None,
                 allowed_major_topics: Iterable[str] | None = None,
                 classifier_version: str = "", taxonomy_version: str = "",
                 syllabus_version: str = "", limit: int = DEFAULT_RESULT_LIMIT) -> MemoryContext:
        """Retrieve only indexed, relevant records for one subject.

        The only corpus query is an indexed ``subject + token IN (...)`` lookup
        limited to a small candidate set.  The method never iterates over all
        stored questions and therefore remains suitable for large archives.
        """
        if self._conn is None:
            return MemoryContext.empty()
        subject = str(subject or "").strip()
        if not subject:
            return MemoryContext.empty()
        vector = memory_feature_vector(question_text, mark_scheme_text)
        tokens = _query_tokens(vector)
        if not tokens:
            return MemoryContext.empty()
        limit = max(1, min(int(limit), 20))
        placeholders = ",".join("?" for _ in tokens)
        candidate_limit = max(24, limit * 6)
        _version_clauses: list[str] = []
        _version_params: list[str] = []
        # A classifier/taxonomy/syllabus mismatch is a deliberate review
        # concern, not a reason to silently re-use old labels under a changed
        # decision procedure or changed meaning. Stale records remain
        # discoverable through ``stale_records`` for controlled
        # migration/reclassification but do not influence a live decision.
        if classifier_version:
            _version_clauses.append("r.classifier_version=?")
            _version_params.append(str(classifier_version))
        if taxonomy_version:
            _version_clauses.append("r.taxonomy_version=?")
            _version_params.append(str(taxonomy_version))
        if syllabus_version:
            _version_clauses.append("r.syllabus_version=?")
            _version_params.append(str(syllabus_version))
        _version_sql = (" AND " + " AND ".join(_version_clauses)) if _version_clauses else ""
        rows = self._conn.execute(
            f"""
            SELECT t.record_id, SUM(t.weight) AS overlap
            FROM memory_tokens AS t
            JOIN memory_records AS r ON r.id=t.record_id
            WHERE t.subject=? AND r.active=1{_version_sql} AND t.token IN ({placeholders})
            GROUP BY t.record_id
            ORDER BY overlap DESC, t.record_id ASC
            LIMIT ?
            """,
            [subject, *_version_params, *tokens, candidate_limit],
        ).fetchall()
        if not rows:
            return MemoryContext(query_tokens=tuple(tokens))
        overlaps = {int(row["record_id"]): float(row["overlap"] or 0.0) for row in rows}
        ids = sorted(overlaps)
        id_placeholders = ",".join("?" for _ in ids)
        records = self._conn.execute(
            f"SELECT * FROM memory_records WHERE id IN ({id_placeholders}) AND active=1",
            ids,
        ).fetchall()
        query_norm = max(1.0, sum(vector[token] for token in tokens))
        candidates: list[MemoryMatch] = []
        for row in records:
            record_id = int(row["id"])
            denom = math.sqrt(query_norm * max(1.0, float(row["token_weight_sum"])))
            similarity = overlaps.get(record_id, 0.0) / denom
            if similarity < MIN_SIMILARITY:
                continue
            try:
                topics = tuple(json.loads(row["topics_json"]))
                major_topics = tuple(json.loads(row["major_topics_json"]))
                negative_topics = tuple(json.loads(row["negative_topics_json"]))
                evidence = tuple(json.loads(row["evidence_json"]))
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            candidates.append(MemoryMatch(
                record_id=record_id,
                trust_level=str(row["trust_level"]),
                similarity=float(similarity),
                topics=topics,
                major_topics=major_topics,
                negative_topics=negative_topics,
                evidence=evidence,
                source=str(row["source"]),
                paper=str(row["paper"]),
                variant=str(row["variant"]),
                question_number=str(row["question_number"]),
                classifier_version=str(row["classifier_version"]),
                taxonomy_version=str(row["taxonomy_version"]),
                syllabus_version=str(row["syllabus_version"]),
                memory_version=str(row["memory_version"]),
            ))
        candidates.sort(key=lambda match: (-match.similarity, match.record_id))
        matches = tuple(candidates[:limit])

        allowed_detailed = set(str(t) for t in (allowed_detailed_topics or ()))
        allowed_major = set(str(t) for t in (allowed_major_topics or ()))
        detailed_positive: dict[str, float] = {}
        detailed_negative: dict[str, float] = {}
        major_positive: dict[str, float] = {}
        major_negative: dict[str, float] = {}
        high_counts: dict[str, set[int]] = {}

        # Trust is intentionally bounded.  A verified correction is stronger
        # than a single high-confidence prediction, while negative evidence is
        # advisory and later capped again by the classifier's direct score.
        positive_authority = {"verified": 1.00, "correction": 1.00, "high_confidence": 0.30, "negative": 0.0}
        negative_authority = {"verified": 0.0, "correction": 0.72, "high_confidence": 0.0, "negative": 0.55}
        for match in matches:
            pos = match.similarity * positive_authority.get(match.trust_level, 0.0)
            neg = match.similarity * negative_authority.get(match.trust_level, 0.0)
            for topic in match.topics:
                if not allowed_detailed or topic in allowed_detailed:
                    detailed_positive[topic] = detailed_positive.get(topic, 0.0) + pos
                    if match.trust_level == "high_confidence":
                        high_counts.setdefault(topic, set()).add(match.record_id)
            for topic in match.major_topics:
                if not allowed_major or topic in allowed_major:
                    major_positive[topic] = major_positive.get(topic, 0.0) + pos
                    if match.trust_level == "high_confidence":
                        high_counts.setdefault(topic, set()).add(match.record_id)
            for topic in match.negative_topics:
                # A negative topic can be either detailed or major.  It is
                # routed only to a declared taxonomy target where possible.
                if not allowed_detailed or topic in allowed_detailed:
                    detailed_negative[topic] = detailed_negative.get(topic, 0.0) + neg
                if not allowed_major or topic in allowed_major:
                    major_negative[topic] = major_negative.get(topic, 0.0) + neg

        return MemoryContext(
            query_tokens=tuple(tokens),
            matches=matches,
            detailed_positive={k: min(1.5, v) for k, v in detailed_positive.items()},
            detailed_negative={k: min(0.9, v) for k, v in detailed_negative.items()},
            major_positive={k: min(1.5, v) for k, v in major_positive.items()},
            major_negative={k: min(0.9, v) for k, v in major_negative.items()},
            high_confidence_counts={k: len(v) for k, v in high_counts.items()},
        )

    def stats(self) -> dict:
        if self._conn is None:
            return {"available": False, "records": 0, "tokens": 0, "by_trust_level": {}}
        by_level = {
            str(row["trust_level"]): int(row["n"])
            for row in self._conn.execute(
                "SELECT trust_level, COUNT(*) AS n FROM memory_records WHERE active=1 GROUP BY trust_level"
            )
        }
        records = int(self._conn.execute(
            "SELECT COUNT(*) FROM memory_records WHERE active=1"
        ).fetchone()[0])
        tokens = int(self._conn.execute("SELECT COUNT(*) FROM memory_tokens").fetchone()[0])
        relationships = int(self._conn.execute("SELECT COUNT(*) FROM memory_relationships").fetchone()[0])
        return {
            "available": True,
            "path": str(self.path),
            "schema_version": self._meta("memory_schema_version"),
            "memory_version": self._meta("memory_version"),
            "records": records,
            "tokens": tokens,
            "similar_question_relationships": relationships,
            "by_trust_level": by_level,
        }

    def _meta(self, key: str) -> str:
        if self._conn is None:
            return ""
        row = self._conn.execute("SELECT value FROM memory_meta WHERE key=?", (key,)).fetchone()
        return str(row[0]) if row else ""

    def stale_records(self, *, subject: str, taxonomy_version: str = "",
                      syllabus_version: str = "", classifier_version: str = "") -> list[dict]:
        """List stale records for a deliberate review/reclassification workflow.

        This is an inventory operation invoked by a maintainer/tool; it never
        reclassifies records automatically merely because code changed.
        """
        if self._conn is None:
            return []
        clauses = ["subject=?", "active=1"]
        params: list[str] = [str(subject)]
        stale_parts: list[str] = []
        if taxonomy_version:
            stale_parts.append("taxonomy_version<>?")
            params.append(str(taxonomy_version))
        if syllabus_version:
            stale_parts.append("syllabus_version<>?")
            params.append(str(syllabus_version))
        if classifier_version:
            stale_parts.append("classifier_version<>?")
            params.append(str(classifier_version))
        if not stale_parts:
            return []
        sql = (
            "SELECT id, paper, variant, question_number, trust_level, topics_json, major_topics_json, "
            "taxonomy_version, syllabus_version, classifier_version FROM memory_records WHERE "
            + " AND ".join(clauses)
            + " AND (" + " OR ".join(stale_parts) + ") ORDER BY id"
        )
        return [dict(row) for row in self._conn.execute(sql, params)]

    def import_legacy_examples(self, path: str | Path, *, subject: str,
                               detailed_topics: Iterable[str] = (),
                               major_topics: Iterable[str] = (),
                               taxonomy_version: str = "", syllabus_version: str = "",
                               classifier_version: str = "") -> int:
        """One-time migration for old ``classification_examples.jsonl`` files.

        Importing is explicit rather than automatic, so a large legacy file is
        never loaded by every classifier invocation.  Rows tagged ``verified``
        become indexed verified records; a legacy major-topic label remains a
        major-routing support record rather than being guessed as a detail.
        """
        p = Path(path)
        if not p.is_file():
            return 0
        detailed = set(str(t) for t in detailed_topics)
        majors = set(str(t) for t in major_topics)
        imported = 0
        for line_number, raw in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            try:
                row = json.loads(raw)
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            if row.get("verified") is False or not str(row.get("text", "")).strip():
                continue
            topic = str(row.get("topic", "")).strip()
            if not topic:
                continue
            record_topics = [topic] if topic in detailed else []
            record_majors = [topic] if topic in majors else []
            if not record_topics and not record_majors:
                continue
            self.record_verified(
                subject=subject,
                level=str(row.get("level", "")),
                paper=str(row.get("paper", "")), variant=str(row.get("variant", "")),
                question_number=str(row.get("question_number", "")),
                topics=record_topics,
                major_topics=record_majors,
                evidence=["Imported explicit verified classification example."],
                question_text=str(row.get("text", "")),
                taxonomy_version=taxonomy_version, syllabus_version=syllabus_version,
                classifier_version=classifier_version,
                source=str(row.get("source", "legacy_classification_examples")),
                record_key=f"legacy:{p.resolve()}:{line_number}",
            )
            imported += 1
        return imported
