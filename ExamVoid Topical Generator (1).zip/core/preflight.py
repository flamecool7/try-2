"""Preflight & manifest builder (Overseer batch-infrastructure spec, Phase 2 —
honest port onto the production identifier + config registry).

Runs once before any processing begins, in the MAIN PROCESS ONLY (spec rule:
workers never call this). Scans the input directory, identifies all files,
groups them into QP/MS/ER bundles, estimates storage, and populates the
SQLite database.

Audited deviations from the spec's code (receipts in the round evidence log):

1. Spec's `_scan_and_identify` called `scan_paper(str(pdf_path), pdf_path.name)`
   and read meta["subject"] / meta["kind"] — none of that exists (the real
   shim takes ONE filename argument and returns no subject/kind keys).
   Here identification goes through core.paper_identifier.scan_papers()
   (production entry, one pass) and the subject/level is resolved against
   the approved subjects/<Level>/<Subject>/config.json registry.
2. Spec's `_group_bundles` attached ER files only to bundles ALREADY in the
   dict — and glob order sorts `*_er.pdf` before `*_qp_*.pdf`, so on a real
   directory EVERY ER would have attached to nothing. Fixed as a two-pass
   group: qp/ms bundles first, ER attach second (spec's own "ER matches all
   variants of same paper number" semantic preserved).
3. The spec's bundle key `code_seasonyear_component` is kept and equals the
   production base_key convention (e.g. `0620_s16_22`); season/year stored
   as the canonical season letter + 2-digit year the identifier emits.
4. Markdown-linkification corruption repaired on write.
"""

import shutil
import logging
from pathlib import Path
from typing import List, Dict

logger = logging.getLogger(__name__)


class Preflight:
    """
    Runs once before any processing begins.
    Scans input directory, identifies all files,
    groups into bundles, estimates storage,
    and populates the SQLite database.

    Workers never call this. It runs in the
    main process only.
    """

    # Estimated output size per question
    # QP crop + MS crop + ER crop + metadata
    BYTES_PER_QUESTION = 900_000  # ~900KB per question

    def __init__(
        self,
        pdf_dir: Path,
        output_dir: Path,
        db: "Database",
    ):
        self.pdf_dir = Path(pdf_dir)
        self.output_dir = Path(output_dir)
        self.db = db
        from .manifest import ProcessingManifest
        self.manifest = ProcessingManifest.load_or_create(self.output_dir)

    def run(self) -> int:
        """
        Full preflight sequence.
        Returns number of new bundles queued.
        """
        print("Running preflight checks...")

        # 1. Storage check
        self._check_storage()

        # 2. Scan and identify all PDFs
        identified = self._scan_and_identify()

        # 3. Group into bundles
        bundles = self._group_bundles(identified)

        # 4. Register new bundles in database
        new_count = self._register_bundles(bundles)

        # 5. Persist incremental processing manifest
        self.manifest.save()

        print(
            f"Preflight complete. "
            f"{new_count} new or changed bundles queued. "
            f"{len(bundles) - new_count} unchanged."
        )
        return new_count

    def preview(
        self,
        *,
        retry_failed: bool = False,
        session: str | None = None,
        year: str | None = None,
        subject: str | None = None,
        syllabus_code: str | None = None,
        level: str | None = None,
        variant: str | None = None,
        selected_paths: set[str] | None = None,
        selected_folder: str | None = None,
    ) -> dict:
        """Build a non-destructive, bundle-level execution plan.

        This deliberately reuses the production scanner and grouping logic but
        does *not* register files, write SQLite, save the manifest, create an
        output folder, or alter archive state.  It is used for ``--dry-run``
        and the Control Center's Preview Changes view.
        """
        import sqlite3

        identified = self._scan_and_identify()
        bundles = self._group_bundles(identified)
        source_files = [p for p in self.pdf_dir.rglob("*")
                        if p.is_file() and p.suffix.lower() == ".pdf"]

        # Read the existing database only if it already exists.  Connecting
        # read-only avoids a dry run creating a database on a fresh archive.
        existing_bundles = {}
        existing_files = {}
        db_path = self.output_dir / "pipeline.sqlite"
        if db_path.is_file():
            try:
                uri = f"file:{db_path.resolve().as_posix()}?mode=ro"
                conn = sqlite3.connect(uri, uri=True)
                conn.row_factory = sqlite3.Row
                for row in conn.execute("SELECT * FROM bundles"):
                    existing_bundles[str(row["bundle_key"])] = row
                for row in conn.execute("SELECT id, path, sha256 FROM files"):
                    existing_files[str(row["path"])] = row
                conn.close()
            except Exception as e:
                logger.warning("Could not read existing database for dry run: %s", e)

        def _filter_matches(bundle: dict) -> bool:
            if session:
                from .batch_runner import _normalise_session_filter
                season, session_year = _normalise_session_filter(session)
                if season and str(bundle["season"]).lower() != season:
                    return False
                if session_year and str(bundle["year"])[-2:] != session_year:
                    return False
            if year:
                expected = str(year).strip()[-2:]
                if str(bundle["year"])[-2:] != expected:
                    return False
            if subject and str(subject).casefold() not in str(bundle["subject"]).casefold():
                return False
            if syllabus_code and str(bundle["syllabus_code"]) != str(syllabus_code):
                return False
            if level and str(bundle["level"]).casefold() != str(level).casefold():
                return False
            if variant and str(bundle["component"]) != str(variant):
                return False
            paths = [bundle.get(k) for k in ("qp_path", "ms_path", "er_path", "insert_path", "ci_path")]
            resolved = {str(Path(p).resolve()) for p in paths if p is not None}
            if selected_paths and not (resolved & selected_paths):
                return False
            if selected_folder:
                folder = Path(selected_folder).resolve()
                if not any(_is_under(Path(p), folder) for p in resolved):
                    return False
            return True

        def _is_under(path: Path, folder: Path) -> bool:
            try:
                path.resolve().relative_to(folder)
                return True
            except ValueError:
                return False

        categories = {
            "new": [], "changed": [], "completed": [], "failed": [],
            "pending": [], "processing": [], "needs_review": [],
        }

        for key, bundle in bundles.items():
            if not _filter_matches(bundle):
                continue

            old = existing_bundles.get(key)
            if old is None:
                categories["new"].append(key)
                continue

            # Compare only actual input identities.  This mirrors
            # Database.sync_bundle_inputs(): a real hash/path/attachment
            # change queues exactly that bundle, while an older DB lacking
            # stored fingerprints is backfilled later without mass rework.
            changed = False
            for path_key, id_col, hash_col in (
                ("qp_path", "qp_file_id", "qp_sha256"),
                ("ms_path", "ms_file_id", "ms_sha256"),
                ("er_path", "er_file_id", "er_sha256"),
                ("insert_path", "insert_file_id", "insert_sha256"),
                ("ci_path", "ci_file_id", "ci_sha256"),
            ):
                input_path = bundle.get(path_key)
                old_id = old[id_col] if id_col in old.keys() else None
                old_hash = old[hash_col] if hash_col in old.keys() else None
                if input_path is None:
                    if old_id is not None:
                        changed = True
                    continue
                resolved = str(Path(input_path).resolve())
                rec, _ = self.manifest.scan_input_file(input_path)
                registered = existing_files.get(resolved)
                if old_id is None:
                    changed = True
                    continue
                if old_hash is not None:
                    if old_hash != rec.sha256:
                        changed = True
                    continue
                # Legacy DB rows may have a null bundle hash.  Compare the
                # file registry's existing hash if present; otherwise retain
                # the historical status and let a normal preflight backfill.
                if registered is not None and registered["sha256"] != rec.sha256:
                    changed = True

            if changed:
                categories["changed"].append(key)
            else:
                db_status = str(old["status"])
                category = {
                    "complete": "completed",
                    "failed": "failed",
                    "pending": "pending",
                    "processing": "processing",
                    "review_required": "needs_review",
                }.get(db_status, "pending")
                categories[category].append(key)

        would_process = (
            len(categories["new"]) + len(categories["changed"]) +
            len(categories["pending"]) + len(categories["processing"])
        )
        if retry_failed:
            would_process += len(categories["failed"])

        return {
            "source_files": len(source_files),
            "bundles_seen": sum(len(v) for v in categories.values()),
            "new": len(categories["new"]),
            "changed": len(categories["changed"]),
            "completed": len(categories["completed"]),
            "failed": len(categories["failed"]),
            "pending": len(categories["pending"]),
            "processing": len(categories["processing"]),
            "needs_review": len(categories["needs_review"]),
            "would_process": would_process,
            "retry_failed": bool(retry_failed),
            "categories": categories,
        }

    def _check_storage(self):
        """Estimate output size and verify disk space."""
        pdfs = [p for p in self.pdf_dir.rglob("*")
                if p.is_file() and p.suffix.lower() == ".pdf"
                and "_qp_" in p.stem.lower()]
        if not pdfs:
            return

        # Rough estimate: 15 questions per QP average
        estimated_questions = len(pdfs) * 15
        estimated_bytes = (
            estimated_questions * self.BYTES_PER_QUESTION
        )
        estimated_gb = estimated_bytes / 1e9

        free_bytes = shutil.disk_usage(
            self.output_dir.parent
        ).free
        free_gb = free_bytes / 1e9

        print(
            f"Storage estimate: "
            f"~{estimated_gb:.1f}GB needed, "
            f"{free_gb:.1f}GB free"
        )

        if estimated_bytes > free_bytes * 0.9:
            raise RuntimeError(
                f"Insufficient disk space. "
                f"Need ~{estimated_gb:.1f}GB, "
                f"have {free_gb:.1f}GB free. "
                f"Free up space before processing."
            )

    def _check_ram(self, workers: int):
        """Warn if RAM may be insufficient."""
        try:
            import psutil
            ram_gb = psutil.virtual_memory().total / 1e9
            needed_gb = workers * 1.5  # ~1.5GB per worker

            if needed_gb > ram_gb * 0.8:
                logger.warning(
                    f"RAM warning: {workers} workers needs "
                    f"~{needed_gb:.1f}GB, system has "
                    f"{ram_gb:.1f}GB. "
                    f"Consider reducing --workers."
                )
        except ImportError:
            pass

    def _scan_and_identify(self) -> List[dict]:
        """
        Scan input directory and identify every PDF via the production
        identifier. Returns list of identified file dicts.

        Subject/level resolution runs against the approved subject config
        registry (config_loader) — a subject with no approved config is loud
        and skipped, never guessed.
        """
        from .paper_identifier import identify_papers_in_dir
        from .config_loader import load_subject_config_by_code_and_level

        papers = identify_papers_in_dir(self.pdf_dir)
        all_pdfs = [p for p in self.pdf_dir.rglob("*")
                    if p.is_file() and p.suffix.lower() == ".pdf"]
        print(f"Scanning {len(all_pdfs)} PDF files...")

        _identified_paths = {str(Path(info.file_path)) for info in papers}
        for pdf in all_pdfs:
            if str(pdf) not in _identified_paths:
                logger.warning(f"Could not identify: {pdf.name}")

        identified = []
        # Valid document kinds that are NOT part of a QP/MS/ER bundle but ARE
        # processed by the wider pipeline (grade thresholds, insert booklets).
        # They are recognised here so their files never log "unsupported kind".
        _SIDECAR_KINDS = {"gt", "insert", "in", "ir", "ci", "sf"}
        _INSERT_KINDS = {"insert", "in", "ir", "ci", "sf"}
        for info in papers:
            kind = getattr(info, "paper_type", None)
            if kind == "gt":
                logger.info(
                    f"{Path(info.file_path).name}: grade-threshold sidecar "
                    "handled separately"
                )
                continue
            if kind not in ("qp", "ms", "er") and kind not in _INSERT_KINDS:
                logger.warning(
                    f"Skipping {Path(info.file_path).name}: unsupported kind "
                    f"{kind!r} (bundles are built from qp/ms/er)"
                )
                continue
            cfg = load_subject_config_by_code_and_level(
                info.syllabus_code, info.level
            )
            if cfg is None:
                logger.warning(
                    f"Skipping {Path(info.file_path).name}: no approved "
                    f"subject config for {info.syllabus_code} / {info.level}"
                )
                continue
            identified.append({
                "path": Path(info.file_path),
                "kind": kind,
                "syllabus_code": info.syllabus_code,
                "subject": cfg.subject,
                "level": info.level,
                "season": info.season_letter,
                "year": info.year_short,
                "component": str(info.variant),
                "paper_format": getattr(info, "paper_format", None) or "STRUCTURED",
            })

        print(f"Identified {len(identified)}/{len(all_pdfs)} files")
        return identified

    def _group_bundles(
        self, identified: List[dict]
    ) -> Dict[str, dict]:
        """
        Group identified files into QP/MS/ER bundles.
        Key: syllabus_code + season + year + component
        (== the production base_key convention, e.g. 0620_s16_22).

        TWO PASSES (audit fix 2): qp/ms bundles are all built first; ER files
        attach afterwards to every bundle of the same
        code/season/year/paper-number ("ER matches all variants of same
        paper number"), regardless of directory listing order.
        """
        bundles: Dict[str, dict] = {}
        er_files: List[dict] = []

        # Pass 1: QP/MS bundles
        for f in identified:
            code = f["syllabus_code"]
            season = f["season"]
            year = f["year"]
            component = f["component"]
            kind = f["kind"]

            if kind == "er":
                er_files.append(f)
                continue

            bundle_key = f"{code}_{season}{year}_{component}"
            if bundle_key not in bundles:
                bundles[bundle_key] = {
                    "bundle_key": bundle_key,
                    "syllabus_code": code,
                    "subject": f["subject"],
                    "level": f["level"],
                    "season": season,
                    "year": year,
                    "component": component,
                    "paper_format": f["paper_format"],
                    "qp_path": None,
                    "ms_path": None,
                    "er_path": None,
                    "insert_path": None,
                    "ci_path": None,
                }

            bundle = bundles[bundle_key]
            if kind == "qp":
                bundle["qp_path"] = f["path"]
            elif kind == "ms":
                bundle["ms_path"] = f["path"]
            elif kind == "ci":
                bundle["ci_path"] = f["path"]
            elif kind in {"insert", "in", "ir", "sf"}:
                bundle["insert_path"] = f["path"]

        # Pass 2: ER attach (order-independent). Component-less session ERs
        # (e.g. 9700_m25_er.pdf — the overwhelmingly common shape) attach to
        # EVERY bundle of the same code/season/year; the spec's first-digit
        # rule additionally applies when an ER does name a component.
        # (The real ER attach itself runs once on the committed output tree,
        # parent-side — core/examiner_report works at that level, not inside
        # per-bundle staging.)
        for f in er_files:
            code = f["syllabus_code"]
            season = f["season"]
            year = f["year"]
            component = f["component"]
            paper_num = component[0] if component else ""
            for bundle in bundles.values():
                b_comp = bundle["component"]
                b_pnum = b_comp[0] if b_comp else ""
                if (bundle["syllabus_code"] == code
                        and bundle["season"] == season
                        and bundle["year"] == year
                        and (not paper_num or b_pnum == paper_num)):
                    bundle["er_path"] = f["path"]

        # Filter: must have at least a QP
        valid = {
            k: v for k, v in bundles.items()
            if v["qp_path"] is not None
        }

        no_qp = len(bundles) - len(valid)
        if no_qp > 0:
            logger.warning(
                f"{no_qp} bundles skipped (no QP file found)"
            )

        return valid

    def _register_bundles(
        self, bundles: Dict[str, dict]
    ) -> int:
        """Register new bundles and requeue bundles whose input set changed.

        This is deliberately keyed by file identities rather than just the
        logical bundle name: adding an MS to an already-completed QP-only
        bundle is an input change and must trigger exactly that bundle again.
        """
        queued_count = 0

        for bundle_key, bundle in bundles.items():
            # Register files even when the logical bundle already exists.  The
            # old implementation skipped this block for known bundles, which
            # made a newly pasted MS invisible to the SQLite runner.
            def reg(path, kind):
                if path is None:
                    return None
                rec, _ = self.manifest.scan_input_file(path, kind=kind)
                return self.db.register_file(
                    path=path,
                    kind=kind,
                    syllabus_code=bundle["syllabus_code"],
                    season=bundle["season"],
                    year=bundle["year"],
                    component=bundle["component"],
                    paper_format=bundle["paper_format"],
                    checksum=rec.sha256,
                )

            qp_id = reg(bundle["qp_path"], "qp")
            ms_id = reg(bundle["ms_path"], "ms")
            er_id = reg(bundle["er_path"], "er")
            insert_id = reg(bundle.get("insert_path"), "insert")
            ci_id = reg(bundle.get("ci_path"), "ci")

            _bundle_id, changed, reason = self.db.sync_bundle_inputs(
                bundle_key=bundle_key,
                syllabus_code=bundle["syllabus_code"],
                subject=bundle["subject"],
                level=bundle["level"],
                season=bundle["season"],
                year=bundle["year"],
                component=bundle["component"],
                paper_format=bundle["paper_format"],
                qp_file_id=qp_id,
                ms_file_id=ms_id,
                er_file_id=er_id,
                insert_file_id=insert_id,
                ci_file_id=ci_id,
            )
            if changed:
                queued_count += 1
                print(f"  [preflight] {bundle_key}: queued ({reason})")

        return queued_count

    def print_manifest_report(self, db):
        """Manifest status report: QP/MS/ER availability for every bundle,
        incl. fetch-log state for missing MS (MS-fetcher spec).

        F5 fix: ensure_fetch_log first — the spec's LEFT JOIN crashes with
        OperationalError when no fetch has ever run (table absent)."""
        import sqlite3
        from .ms_fetcher import ensure_fetch_log
        ensure_fetch_log(db.db_path)

        conn = sqlite3.connect(str(db.db_path))
        conn.row_factory = sqlite3.Row
        bundles = conn.execute("""
            SELECT b.bundle_key,
                   b.syllabus_code,
                   b.subject,
                   b.season,
                   b.year,
                   b.component,
                   b.status,
                   b.qp_file_id,
                   b.ms_file_id,
                   b.er_file_id,
                   fl.success    as fetch_success,
                   fl.verified   as fetch_verified,
                   fl.source     as fetch_source
            FROM bundles b
            LEFT JOIN ms_fetch_log fl
                ON fl.bundle_key = b.bundle_key
                AND fl.id = (
                    SELECT MAX(id) FROM ms_fetch_log
                    WHERE bundle_key = b.bundle_key
                )
            ORDER BY b.syllabus_code, b.season, b.year,
                     b.component ASC
        """).fetchall()
        conn.close()

        print(f"\n{'='*70}")
        print(f"  MANIFEST REPORT ({len(bundles)} bundles)")
        print(f"{'='*70}")
        print(
            f"  {'BUNDLE':<30} "
            f"{'QP':>3} {'MS':>3} {'ER':>3} "
            f"{'STATUS':<18}"
        )
        print(f"  {'-'*66}")

        ready = 0
        for b in bundles:
            qp_ok = "✅" if b["qp_file_id"] else "❌"
            er_ok = "✅" if b["er_file_id"] else "⚠️ "

            if b["ms_file_id"]:
                ms_ok = "✅"
            elif b["fetch_verified"]:
                ms_ok = "📥"   # fetched and verified
            elif b["fetch_success"]:
                ms_ok = "👁 "   # fetched but needs review
            else:
                ms_ok = "❌"

            status = b["status"]
            if (b["qp_file_id"] and b["ms_file_id"]
                    and status == "pending"):
                status = "READY"
                ready += 1
            elif not b["ms_file_id"]:
                status = "MS_MISSING"

            print(
                f"  {b['bundle_key']:<30} "
                f"{qp_ok:>3} {ms_ok:>3} {er_ok:>3} "
                f"{status:<18}"
            )

        print(f"  {'-'*66}")
        print(f"  Ready to process: {ready}/{len(bundles)}")
        print(f"{'='*70}\n")
