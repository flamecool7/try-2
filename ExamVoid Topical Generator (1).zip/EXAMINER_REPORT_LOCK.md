# Examiner Report System Lock

The Examiner Report implementation is read-only. Topic and folder routing must not
change report discovery, exact-paper verification, parsing, question matching, report
content, report naming, report placement, or report validation.

## Baseline verification

`core/examiner_report_gold.py` remains byte-for-byte identical to the original
downloaded project archive. `core/examiner_report.py` contains the approved ER-only
integration addition: strict metadata-to-report matching and validated creation of
`examiner_report.txt` for files identified by the `_er` suffix.

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `7fa54fbd8242139b0a58c60fedf45dc674ba4ed530f1453f0d45080503fab528` |
| `core/examiner_report_gold.py` | `7750c213d4b1ce71225d44d13d77f7dcd19274c6a1f787c4855db599d9782b08` |

## Routing compatibility verification

The existing main-pipeline integration locates each processed question through its
own `metadata.json` and writes `examiner_report.txt` to `json_path.parent`. Therefore
an exact-topic-folder rename or routing change does not change the report's question
association: the report remains in that question's actual folder. No examiner-report
code was changed.

An end-to-end extraction test requires a real matching Examiner Report PDF; no such
PDF is present in the supplied workspace. When one is supplied, the existing strict
matching pipeline remains responsible for accepting or rejecting it.

## Amendment ER-1 (2026-08-10): Merged ER engine v1.1 — authorised by the maintainer

The maintainer approved (`er_approach=merge`) upgrading `core/examiner_report.py` in
place to the layered spec engine (ERPdfLoader / ERCleaner / ERSectionSplitter /
ERQuestionParser / ERMatcher / ERWriter), keeping the strict matcher and the existing
main.py integration points unchanged. `core/examiner_report_gold.py` remains
byte-for-byte identical to the original archive (verified).

Maintainer decisions folded into the merge:
- **Fallback = "if there is no er continue process"** (maintainer's custom decision;
  supersedes the spec's 4-file Invariant 6). No placeholder files are written when no
  ER exists or no question-specific commentary is found; the pipeline continues.
- **Artifacts = text + webp**: keep `_ER.webp` rendering and additionally write
  `examiner_report.txt` (question-specific) / `examiner_report_full.txt` (general).

Documented spec fixes applied during reconstruction: question-header pattern A
(`Question 1` / `Q1` forms), bare page numbers stripped only at page edges, sub-part
header groups use `[ \t]*` (never `\s*` — it ate next-line `(a)` labels), section
titles line-anchored (`re.MULTILINE`), hyphen healing across page breaks
(`([a-z])-\n(?:[ \t]*\n)*([a-z])`). Also fixed two latent bugs: dead `.organize`
import (-> `.output_manager`) and `_source_doc_for` so the webp renders from the
MATCHED report document instead of `parsed_docs[0]`.

Evidence: 56/56 checks green (`test-crops/er-tests/run_er_tests.py`) against the real
`9709_s22_er_paper11_pages.pdf`; sample artifacts in `test-crops/er-tests/sample-output/`.
Status values: `written` / `general_fallback` / `no_verified_er` / `skipped_no_content`.

### Updated SHA-256 (Amendment ER-1)

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `83fe747ec1ab02e06f0e10884925e6434e7533e8ef53f6af57acb2872fc2eff6` |
| `core/examiner_report_gold.py` | `7750c213d4b1ce71225d44d13d77f7dcd19274c6a1f787c4855db599d9782b08` (unchanged) |

## Amendment ER-2 (2026-08-10): Grouped question headers + per-question ER crops — authorised by the maintainer

Two parts:

1. **`core/examiner_report.py`** — question-header detection extended with the
   `grouped_range` pattern ("Questions 1-10" grouped ranges, MCQ style) inside
   `QUESTION_HEADER_PATTERNS`; consumed by both ER text attach and the new crop
   module. No other behavioural change; ER text pipeline re-verified 56/56.
2. **NEW module `core/er_question_crops.py`** (additive; locked gold files
   untouched) — per-question ER boundary crops written into each question folder
   as `{variant}_{Season}_{Year}_Q{n}_ER.webp` (e.g. `41_Winter_2025_Q5_ER.webp`),
   2280px wide, 150dpi streamed renders, `save_webp` quality 95. Every crop is
   verified by text containment (subpart-line normalisation) before write; no
   placeholders are ever emitted. Wired into `main.py` after
   `attach_examiner_reports_to_output` inside try/except (failure never fatal to
   the pipeline).

Documented spec-bug fixes applied during reconstruction (the supplied spec again
described a nonexistent codebase): component scoping ("Paper 9700/22" inside
multi-component ER booklets), locked import of `QUESTION_HEADER_PATTERNS`
(including `grouped_range`), guarded bare-number matching, line-anchored header
matching, streamed (not list-held) 150dpi page renders, q95 webp tiling, and
text-containment verification.

Evidence: 56/56 ER suite green; m25 full-pipeline runs — 6/6 crops written and
verified on m25 v2 and v3 (`test-crops/m25-proof-v3/M25_V3_TEST_RUN_pack.html`).

### Updated SHA-256 (Amendment ER-2)

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `972e68d3dc6085b6852e3f266f28665692887aeaa5867c1fcd91d5130e1ce9ac` |
| `core/er_question_crops.py` | `b93ad5f2b4bb83a4f428671cb60a151900fa133ec2046692b828059cc5cc50b8` (new module) |
| `core/examiner_report_gold.py` | `7750c213d4b1ce71225d44d13d77f7dcd19274c6a1f787c4855db599d9782b08` (unchanged) |

## Amendment ER-3 (2026-08-10): Subject-level full-report placement for QP-only trees + mixed-tree ordering fix — authorised by the maintainer

Part of the RS-5 (Uncategorized) round: QP-only trees have no paper-type folder.
1. `examiner_report_full.txt` previously required a paper-type folder, so on
   QP-only trees it had nowhere to land. The subject folder is now captured at
   registration and, when no paper-type folder exists, the full report writes at
   SUBJECT level with a loud print.
2. ER-3b (same amendment): on mixed trees the stored paper-type folder is
   upgraded when a later classified json reveals that directory, so the full
   report lands beside the question folders instead of being orphaned at subject
   level.

Strict matcher, discovery, parsing, question matching, report content, naming,
placement of question-specific commentary and the per-question ER crops are all
unchanged. `core/er_question_crops.py` byte-untouched; `core/examiner_report_gold.py`
byte-untouched.

Evidence: T1 QP-only real-tree run (9700 m25 qp+er, no MS) — full report at
subject level, per-question commentary still attached inside the Uncategorized
question folders, validator ALL GREEN; mixed-tree ordering unit green
(test-crops/eff-bench logs, UNCATEGORIZED_IMPLEMENTATION.md).

### Updated SHA-256 (Amendment ER-3)

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `44a7dd8235d2d9d37beec758c6b2e38f434009369196524b401096eb386be247` (was `972e68d3…`) |
| `core/er_question_crops.py` | `b93ad5f2b4bb83a4f428671cb60a151900fa133ec2046692b828059cc5cc50b8` (unchanged) |
| `core/examiner_report_gold.py` | `e4f29c597490b86002227971743339b944adec09ecc4aaa6329ee7702ab2880f` (unchanged) |

---

## RS-17/18 (2026-08-12) — taxonomy + mega-spec amendments touching this lock's files — standing pre-approval

Full receipts: `test-crops/redesign/RS161718_ROUND_EVIDENCE.md` (§2–§3).

| `core/examiner_report.py` | `6acf5fd5f1868e94fbac93a0817f326739b8a8a0a28640109b0a8d6e2df5d5d3` | (was `44a7dd8235d2d9d3…`)

---

## RS-18b (2026-08-12) — ER tile-cache tempdir cleanup — standing pre-approval

Same round as ROUTING_STATE_LOCK RS-18b: cached tile tempdirs are tracked in
`_ER_TILE_DIRS` and dropped by `clear_er_tile_cache()` after the ER stages.

| `core/examiner_report.py` | `d67af641789fbce9816a5921b6a6791a1536b45588a9ea0a0ad0767ceb5292ff` | (was 6acf5fd5f1868e94…) |

---

## 2026-08 User Directive — Exclusion of .txt files from final deliverables

Per explicit user instruction ("the .txt file should NOT be part of the final product"),
`write_question_er`, `write_full_er`, and attach functions default `write_txt` to False.
Examiner report commentary is delivered visually via `{qid}_ER.webp` crops.

| `core/examiner_report.py` | `0835e77f1830e72ba4d209ebf8c48f3f77b9f076a357c388fce77e7d334f1c71` | (was `d67af641789fbce9…`) |

---

## ER-4 (2026-08-29) — final-product text-policy reporting correction

The user-directed final product excludes free-form ER text. This non-crop
change makes `write_full_er()` return whether it actually wrote a file and
makes the production attachment path log/count a component summary only when
that return value is true. With the normal `write_txt=False` product policy,
the log now truthfully says that the text summary is disabled. Identity
matching, ER rendering, strict question-boundary crop verification, crop
geometry, and `core/er_question_crops.py` remain unchanged.

| File | SHA-256 |
|---|---|
| `core/examiner_report.py` | `d7f45986f459e0607c5691b7e406ddb0bae157bc3bbedb28a3a721107119a59d` |
| `core/er_question_crops.py` | `b93ad5f2b4bb83a4f428671cb60a151900fa133ec2046692b828059cc5cc50b8` (unchanged) |

---

## ER-5 (2026-08-29) — narrowly authorised 9708/21 actual-image boundary remediation

This is the explicit limited exception to the ER cropper's normal read-only
lock. It addresses only the observed authentic 9708/21 diagnostic defects:
Q1's excessive continuation-page whitespace/header fragment and an in-band
standalone next-section heading. The repair happens in source PDF coordinates
before the `{qid}_ER.webp` is rendered; it is not an HTML/CSS mask and does not
alter MS, Insert, ER identity matching, component scoping, normal question
header detection, rendering DPI, WebP width/quality, or `core/examiner_report.py`.

`core/er_question_crops.py` adds exact PDF line boxes for continuation-edge
trimming, detects only whole-line standalone section headings, preserves the
existing start/end question bounds, and omits a continuation tile only when it
has no body lines and is demonstrably header-only/tiny. The direct production
result is Q1 ER 2280×1758 → **2280×1516** and largest interior white run
153px → **60px**; unaffected ER Q2/Q4 dimensions remain 2280×716 and 2280×760.
The final product still contains only WebPs and canonical `metadata.json`; the
legacy `examiner_report.txt` verification probe remains intentionally disabled.

Focused remediation tests passed 6/6; a full guarded `/21` diagnostic run and
its separate final archive validation both passed. These facts are expressly
not a claim that `/21` is the requested `/22` paper.

| File | SHA-256 | Status |
|---|---|---|
| `core/er_question_crops.py` | `0f945c3093bfab1c3891c3053fb6fe3def010eccfc6fd85fc9ef6e97a796a2d4` | authorised narrow ER source-band remediation |
| `core/examiner_report.py` | `d7f45986f459e0607c5691b7e406ddb0bae157bc3bbedb28a3a721107119a59d` | unchanged from ER-4 |

---

## ER-6 (2026-08-29) — Accounting 9706/32 Q3 terminal repair; ER cropping frozen

### CROPPING STATUS: 🔒 LOCKED

This is the final explicitly authorised ER crop exception. It supersedes only
the historical Accounting Q3 whitespace-failure state recorded elsewhere; it
does not reopen the ER cropper for general changes.

The authentic Accounting 9706/32 ER Q3 starts as the first question header on
the final scoped source page and has no later explicit boundary. The old
near-footer fallback therefore retained an excessive blank tail. The smallest
source-coordinate correction permits end tightening after the final real body
line plus existing semantic padding only for this narrow fresh-final-page,
first-header, final-open-fallback shape and only after
`_terminal_text_only_tail_is_safe()` verifies that the discarded tail contains
no image, vector rule/table, or other non-text object. Every other terminal
shape keeps the old fallback. The Economics 9708/21 ER Q5 control, which shares
its page with Q4, remains exactly `2280×1996`.

Authentic 9706/32 Q3 changed from `2280×2826` / `1874px` blank run to
`2280×934` / `56px` blank run while retaining all Q3(a)–(e) commentary and
excluding next-question, standalone-OR, Section-B, copyright/footer content.
The rebuilt full Accounting archive and its validator passed; focused
cross-paper tests passed 12/12. Exact unmasked proof:
`validation_evidence/accounting_9706_s23_32_or_crosspaper/proof_9706_s23_32_crosspaper.html`.

All ER boundary detection, component scoping, header detection, coordinates,
padding, continuation handling, whitespace behavior, rendering, verification,
and output settings are now read-only. A future possible ER crop change must
stop at evidence collection and await explicit user permission.

| File | SHA-256 | Status |
|---|---|---|
| `core/er_question_crops.py` | `e34ff53b9e73d5508bfc22c04d52022f1551f89848c836e61a12d9cbfa115347` | final frozen ER crop authority; ER-5 plus safe Q3 terminal exception |
| `core/examiner_report.py` | `d7f45986f459e0607c5691b7e406ddb0bae157bc3bbedb28a3a721107119a59d` | unchanged; final frozen ER integration |
