# Classification System Lock

The topic classifier is read-only except by maintainer-authorised amendment.
Folder routing and metadata must only consume its output.

## Baseline (Amendment CLS-1, 2026-08-10): Merged classifier v1.1 — authorised by the maintainer

The maintainer approved (`cls_approach=merge_into_core`) folding the five spec scoring
factors into the existing `core/classifier.py` point system **in place**, keeping the
routing contract (main.py integration unchanged). `original_reference/cambridge_qb/topics_enhanced.py`
and all `original_reference/topics/*/*_topics.json` remain byte-for-byte untouched.

Maintainer decisions folded into the merge:
- **Fallback = spec_forced**: paper-hint chain then alphabetical-first, loudly logged
  (`[classifier-fallback]` ERROR lines). No `Needs_Review` topic.
- **QP-only evidence**: MS corpus input and the `ms_hits * 0.8` bonus are retired.
- **No taxonomy JSON file**: taxonomy stays in the existing per-subject `config.json`
  (`major_topics` / `detailed_topics` / `classification_keywords` / `mapping` /
  `specialization_weights`, plus optional `paper_affinity`).

Engineering facts of the merged engine:
- `MAX_TOPICS = 4`, `FORMULA_BONUS = 3.0`, `COMMAND_MULTIPLIER = 1.5`,
  `COLLISION_THRESHOLD = 0.40`, `COLLISION_DAMPEN = 0.5`.
- Relative mark weight = `subpart_marks / mean_part_marks` (absolute mark weights
  break the calibrated 1.5/1.0 thresholds; `[Total: n]` excluded from extraction).
- `_CHEM_SYMBOL_MAP` includes the U+2212 minus fix; `_SUBSCRIPT_MAP` normalises
  Unicode subscripts; command-verb boost and sub-part parsing per spec.

Evidence: 21/21 exact-arithmetic factor checks
(`test-crops/cls-tests/test_factor_units.py`); 5/6 production baseline decisions
byte-identical (`test-crops/cls-tests/capture_classification.py` + `baseline.json`);
F5 intentionally DIFF (MS-isolation now QP-only, per the approved QP-only decision).

## Locked SHA-256

| File | SHA-256 |
|---|---|
| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

Note: quality tooling may read classifier output via `metadata.json` only; the
metadata schema (single `topic` array, max 4 entries, no score sidecars) is part of
this lock.

## Amendment CLS-2 (2026-08-10): Subject-aware fallback paper hints — authorised by the maintainer

Final-upgrade Issue 2. `_FALLBACK_PAPER_HINTS` was a single Chemistry-shaped
map keyed by paper number; it is now keyed **per subject**
(`Chemistry_9701` content preserved verbatim; `Biology_9700` and `Physics_9702`
added from the directive; unlisted subjects keep the previous behaviour).
Resolution is guarded: `_resolve_hint_topic` maps a hint onto a CONFIGURED
detailed topic only (exact, then case/space-insensitive, then unique normalised
prefix/containment) and can never invent a topic. The forced-fallback chain
order (weak-keyword → paper hints → alphabetical-first, always loudly logged)
is unchanged, as are the 1.5 threshold, ≤4-topic cap, metadata schema and all
scoring factors.

Evidence: new suite `test-crops/final-fixes/test_final_fixes.py` 36/36 (I2
section: Chem hints fire only on Chemistry config; Biology paper 2 can never
receive `Atomic_structure`/`Bonding`; unlisted subjects keep the old chain);
real-paper classify regression `test-crops/final-fixes/classify_regression.py`
18/18 on 9700 m25 + w25 — m25 winners byte-identical to the CLS-1 approved set
(Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5 Genetics);
factor suite 21/21 re-run green.

### Updated SHA-256 (Amendment CLS-2)

| File | SHA-256 |
|---|---|
| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

Data note (recorded, unwired): the maintainer-supplied 22-file taxonomy batch
now lives at `topics/A-Level/*.json` (9) and `topics/IGCSE/*.json` (13) as
shadow assets — 148 topics total, validated. Nothing in the pipeline reads
`topics/`; wiring any file into `subjects/*/config.json` requires a CLS
amendment with evidence.

## CLS-3 (2026-08-10) — per-keyword regex compiled once per process (Efficiency U3)

`classify_question`'s scoring loop re-invoked `re.compile` once per
topic x subpart x keyword (15,170 compiles of 82 distinct patterns per
process on 9700). Now `core/classifier.py::_keyword_pattern` (module-level
`@lru_cache(maxsize=None)`); pattern string byte-identical. Equivalence
proven: `findall` results identical for all 82 real keywords x real subpart
texts, and end-to-end classifications on 9700 m25/w25 equal the approved
baselines exactly (folder-path identical, webp bytes identical vs RS-2
approved tree). Measured gain ~0.6ms/question — small, honest, never a
behavior change.

| File | sha256 |
|---|---|
| `core/classifier.py` | `375772889600fe0dff5565fce5333bdd0780712a061ff31a0a51b58c68af245f` (was `2936b7a6…`) |

## CLS-4 (2026-08-10) — fallback-tier reporting on ClassificationResult (Uncategorized routing support) — authorised by the maintainer

Overseer Uncategorized directive; decision set desperate_only / adopt_keep_crop /
single_level / quality_scorer_flag (maintainer-confirmed). `ClassificationResult`
gains `fallback_tier: str = "scored"` (defaulted — every math early-return keeps the
default, so all CLS-1..3 behaviour stays bit-compatible). Tiers assigned across the
UNCHANGED fallback chain: `scored` (>= 1.5 threshold) -> `weak_keyword` ->
`paper_hint` (desperate) -> `alphabetical_first` (desperate). Scoring math, 1.5
threshold, <=4-topic cap, chain order, loud `[classifier-fallback]` logging and the
metadata schema are all unchanged. Routing contract for consumers: ONLY the two
desperate tiers may trigger Uncategorized routing; `weak_keyword` must not.

Evidence (real 9700 m25/w25 uploads): classifications equal the approved CLS-2
baselines exactly; 33/33 webp byte-parity vs RS-2 approved tree (eff-bench
regression3); T3 forced-tier unit — desperate tiers route, weak_keyword does NOT,
no-shadow rule verified.

| File | sha256 |
|---|---|
| `core/classifier.py` | `e756cb9a7527ae426d3d28ea362a004dfa84f09f6c1c6c0d620da7403a2269f1` (was `37577288…`) |
## CLS-5 (2026-08-11) — metadata additive keys for MCQ papers (schema note; zero file changes) — authorised by the maintainer

IGCSE paper-format round (mcq_ms=letters decision). Question-folder
`metadata.json` gains two OPTIONAL keys, written only for MCQ papers:

- `paper_format: "MCQ"` — the resolved component format;
- `ms_answer: "A".."D"` — the extracted grid letter, which IS the mark
  scheme for MCQ papers (Cambridge publishes a bare answer grid; there is
  nothing to crop). The MS webp is absent BY DESIGN in exactly these
  folders; every validator exemption requires this letter to be present and
  valid, and the fail-closed gates refuse completion when the grid parses
  empty.

`core/json_generator.py` is UNCHANGED (`4b905aec…`, still neither required
nor forbidden in `check_json_structure` — additive by design). No hash table
entries change in this amendment.
## CLS-6 (2026-08-11) — MCQ additive schema mirror + `_MS.txt` artifact class (schema note; zero file changes) — authorised by the maintainer

Unified-MCQ round (decisions additive / literal-with-gates-kept). The CLS-5
keys stay locked; MCQ question folders gain a PLAIN-TEXT mirror and two
additive metadata keys:

- `_MS.txt` — a new artifact class written beside `metadata.json` in MCQ
  folders ONLY: exactly one letter A/B/C/D + `\n`. When the answer grid
  yields no letter, an EMPTY file is still written (literal decision —
  never skipped) and loudly flagged; the fail-closed routing gates are
  UNCHANGED, so a letterless MCQ folder still routes Uncategorized.
- `question_type: "MCQ"` + `correct_answer: "A".."D"` — additive
  `metadata.json` keys that MUST exactly mirror the locked CLS-5
  `ms_answer`; validators cross-check both directions
  (txt ⟺ metadata, and MCQ folder + `_MS.txt` with a missing `ms_answer`
  remains an error, preserving the CLS-5 negative gate).

The MS webp is STILL never fabricated for MCQ papers — the CLS-5 design
stands (the grid letter IS the mark scheme). Folder naming is unchanged
(`P1_MCQ`); the overseer spec's literal `MCQ_P1/` name and literal
`examiner_report.webp` filename were NOT adopted — the validator accepts the
real `*_ER.webp(+_partN)` naming, so previously-produced banks stay valid.
`core/json_generator.py` remains unchanged (`4b905aec…`). No hash table
entries change in this amendment.
## CLS-7 (2026-08-11) — letterless-MCQ routing semantics + 9990 removal + `_Review/` artifact class (schema note; zero file changes) — authorised by the maintainer

RS-13 schema/routing notes (no hash-table entries change here):

- **Letterless MCQ questions route by classification.** A missing answer-grid
  letter is a MARKSCHEME completeness signal, not a classification one: such a
  question lands in its topic folder when classifiable (CLS-4 desperate tiers
  alone may route it Uncategorized). The folder then carries the CLS-6 loud
  surface UNCHANGED: empty `_MS.txt`, `question_type:"MCQ"` with
  `correct_answer:""`, NO `ms_answer`, OutputManager console flag, the RS-7
  negative validator gate (final-audit error -> paper NOT marked complete)
  and the batch staging error. Nothing about this relaxes a gate — it only
  changes WHERE the flagged crop lives.
- **9990 Psychology is not an MCQ syllabus** (Cambridge-verified:
  short-answer/extended-response/essay written papers only). Its registry rows
  are removed outright (RS-13 record); earlier "spec-asserted" provenance is
  preserved as receipt D2-RESOLVED.
- **`_Review/` is a new output-tree area**, written ONLY by the opt-in tool
  `tools/quarantine_reviewed_crops.py` (never by the pipeline itself). Each
  subfolder name is the QC review reason; a README.md records source log,
  reason, and original location for every moved folder. FinalValidator treats
  `_Review` trees as out-of-sanctioned-namespace review storage (the pipeline
  never routes anything there; user-driven only).

---

## RS-17/18 (2026-08-12) — taxonomy + mega-spec amendments touching this lock's files — standing pre-approval

Full receipts: `test-crops/redesign/RS161718_ROUND_EVIDENCE.md` (§2–§3).

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

## CLS-8 (2026-08-12) — Chemistry 9701 evidence coverage and 0606 routing seam

The production classifier remains fail-closed, but the 9701 profile now carries
verified vocabulary for formulae, VSEPR, radical/electron-shell evidence,
energetics, Boltzmann distributions, Group 2, ammonium, alcohol oxidation,
halogen mechanisms, stereoisomerism, and carbonyl chemistry. This removes the
previous false review fallbacks on the tested 9701_s24_qp_12 MCQ paper without
introducing a paper-hint or alphabetical fallback. The 0606 question-level
router lives in `core/math_reference.py` and is selected by the subject code.

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

## CLS-9 (2026-08-12) — target-science phrase bonuses + ambiguity gate

To improve real-world accuracy for the approved target subjects without touching
crop/ER code, the production classifier now adds high-signal phrase bonuses for
A-Level/IGCSE Chemistry, Physics, and Biology, and it fail-closes ambiguous
near-tie science outputs to `review_required` instead of forcing a likely-wrong
folder. This raises accepted-output trust by preferring abstention over silent
misrouting on weak evidence.

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |
| `tests/test_science_accuracy_hardening.py` | `1e310531e834167a038b4bee6bc35d106a027616f7db972ba7419cd109a6cbd1` | (new amendment) |

## CLS-10 (2026-08-13) — Biology 0610 practical-evidence boost

0610 practical papers can be sparse in prose and heavy in method wording. The
0610 keyword/profile layer and the classifier's phrase bonuses were extended to
recognise common practical evidence such as potato-cylinder diffusion setups,
amylase/starch water-bath investigations, potometer transpiration language,
food-test terms, and germinating-seed/yeast respiration cues.

| `subjects/IGCSE/Biology_0610/config.json` | `676fc25bed53a565c3ade6fda930ef3eaee1e3cb8cdd53e30a99dc6af2a909cf` | (was `9b9bd6a626c5ea44…`) |
| `tests/test_0610_practical_routing.py` | `5bde25bdad0ff217adcb5a69c97e65dc85ec0c92e96065307148182f0e61adf8` | (was `748c672a76eaee1e…`) |

## CLS-11 (2026-08-13) — trust-self fallback for all classification

The dominant real-world failure mode was bulk REVIEW_REQUIRED routing from the
hard confidence gates. The production classifier now trusts itself globally:
when normal evidence is weak or an ambiguity gate fires, it still chooses the
best-fit topic instead of exiling the question to manual review. This applies
across supported science subjects; mathematics uses its own runtime picker and
its classifier branch now also forces best-fit routing when the dedicated math
router abstains. This intentionally trades some caution for throughput.

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |
| `tests/test_weak_fallback_science.py` | `64e918e000f1eefcb5d2805a76c36958d53abd7094de900463d9b91973f27eb9` | (was `f0b12403ad8f030b…`) |

## Amendment RS-40 (2026-08-13) — science diagram evidence wiring

The non-math classification path now harvests diagram evidence and applies
corpus-derived topic boosts (`core/science_diagram_signals.py`) AFTER the
fail-closed text gate, before winner selection. Weights 1-3 points; diagram-
only input remains REVIEW_REQUIRED. Full description and corpus results in
ROUTING_STATE_LOCK.md Amendment RS-40.

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

## Amendment RS-41 (2026-08-13) — categorization buffs (classifier)

MCQ option down-weighting (options 0.4x, stem-first), phrase-bonus
whitespace tolerance (newline-split phrases now match), and paper-coherence
prior (two-pass; ambiguous questions only). Full description + corpus
results in ROUTING_STATE_LOCK.md Amendment RS-41.

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

## Amendment RS-44 (2026-08-13) — diagram-harvest memoization

`_harvest_diagram_evidence` memoized per question_number: the paper-coherence
two-pass harvested diagram signals twice per question (2.24s/paper);
now once. Accuracy identical (same signal dict returned). See
ROUTING_STATE_LOCK.md RS-44 for the full speed round.

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

## Amendment RS-48 (2026-08-14) — per-paper topic gating (paper_topics)

New hard filter: topics outside the paper's allowed list are excluded from
scoring/winner/metadata; gated-empty fails closed to review_required.
Configs 9702/9701 ship AS/A2 splits. See ROUTING_STATE_LOCK.md RS-48.

| `core/classifier.py` | `164e40a3ae11a187ea460d15407785dec5f064e5e72ecf09cfd08b2220143f29` | (was `…`) |

## Amendment RS-50 — --full-auto (force_winner) in the classifier

`classify_question(..., force_winner=True)` resolves ambiguous/no-evidence/
paper-gated-empty results to a best-guess topic (fallback_tier
"auto_forced", auto_assigned flag). See ROUTING_STATE_LOCK.md RS-50.

| `core/classifier.py` | `656b1d9d32f76b402eb986388b0b97d2e66869b4f36f956aaa2a4dd50ab07ffc` | (was `…`) |
| `tests/test_classification_buffs.py` | `a9d6b43222663a05db201b254a0b824a876c7427e42a8faec50141dba1b3ad72` | (was `…`) |

## Amendment CLS-5 (2026-08-15) — categorization beef-up: TF-IDF weighting, formula/unit signals, calibrated confidence — authorised by the maintainer

Three additive classifier variables (plus one replaced term-weighting factor),
all deterministic, no new dependencies.  Requested as "more words AND some
variables" for categorisation quality.

1. **Continuous TF-IDF term weighting** (replaces the binary collision
   dampening): `_idf_weight(kw)` computes a smooth inverse-document-frequency
   weight clamped to [IDF_MIN=0.15, IDF_MAX=3.0], so rare diagnostic terms
   ("kc", "nucleon", "amylase") dominate generic shared terms ("reaction",
   "energy").  The old >40%-prevalence behaviour is preserved as a composing
   factor (prevalence > COLLISION_THRESHOLD still halves the weight and is
   still recorded in `collision_dampened_terms` for reasoning transparency).
2. **Formula/unit/symbol signal** (new dimension): `_extract_units_and_symbols`
   detects SI units (mol, kJ, kPa, cm3, ...) and maths operators, and
   `units_symbols.intersection(keywords)` adds FORMULA_UNIT_BONUS (2.0) per
   unique match — a strong pin for quantitative science/maths questions.
3. **Calibrated confidence**: `ClassificationResult.confidence` in [0,1]
   (softmax of the winner/runner-up margin; 0 for review_required).  Lets the
   caller surface borderline calls to review_required instead of forcing a
   guess.  Not part of the canonical metadata schema (never serialised).

Evidence: full suite 252 passed (7 pre-existing env failures unchanged);
targeted probes now route correctly — "equilibrium constant Kc ..." ->
Equilibria (was Halogen_compounds), "enthalpy change of combustion" ->
Chemical_energetics, "electrolysis of molten sodium chloride" ->
Electrochemistry, "rate = k[A][B]" -> Reaction_kinetics, "ionisation energy
across period 3" -> The_Periodic_Table.  Borderline probes get low confidence
("bonding" -> States_of_matter at 0.676) so callers can review.

| `core/classifier.py` | `3c9e0c0a71c49b621a322717befc728a1b855f029c6399a7f9c3c0111fbe54e7` | (was `656b1d9d…`) |

## Amendment CLS-6 (2026-08-15) — official syllabus vocabulary signal — authorised by the maintainer

Third categorisation beef-up variable (completes the "50k+ words AND some
variables" request).  The official Cambridge syllabus learning-outcome
vocabulary is now consumed as a SEPARATE, supplementary signal — NOT merged
into config keywords (an earlier merge attempt cross-contaminated topics and
degraded accuracy, so it was rejected).

`TopicClassifier._load_syllabus_vocab()` reads
`subjects/{Level}/{Subject}/syllabus_vocab.json` (built by
`tools/build_syllabus_index.py`); each topic's terms are matched against the
question text (word-boundary, precompiled) and add `SYLLABUS_VOCAB_BONUS` (0.8)
per hit, capped at `SYLLABUS_VOCAB_MAX_HITS` (5).  Weight is deliberately below
config-keyword hits so the curated source stays primary; the signal is fully
optional (absent index -> no-op).

Evidence: full suite 252 passed (7 pre-existing env failures unchanged);
targeted probes 7/7 correct (Equilibria, Chemical_energetics, Electrochemistry,
Reaction_kinetics, Periodic Table, Electricity, Energy_and_respiration); real
Environmental Management 0680/11 paper still ALL GREEN (8/8 saved, audit 0).

| `core/classifier.py` | `f11921da2b68a2ae6ba6a42a202ff084b8098ca4e89c30b73f2b45bb3e5dcc32` | (was `3c9e0c0a…`) |

## Amendment CLS-12 (2026-08-29) — evidence-based persistent classification memory and raw-MS support — authorised by the user

The user explicitly authorised categorisation/classification-memory work while
permanently locking all crop mechanisms and `metadata.json`. This amendment
supersedes the historical QP-only/exemplar-loader statement **for
classification evidence only**. It does not permit a crop, output-image, or
metadata change.

### Design invariants

- Classify the whole QP question and all parsed subparts, retaining at most four
  materially assessed detailed topics, ranked by score plus an optional
  official-profile assessed-mark relevance signal. Existing single-major-folder
  routing remains unchanged.
- Direct current-QP structure, command words, calculations/data/formula/diagram
  signals, mark allocation, and official taxonomy establish eligibility.
  Substantive raw-MS evidence is a capped secondary direct signal only after a
  QP signal. The locked cropper's `Mark scheme for question N` placeholder is
  explicitly rejected.
- `ClassificationMemory` is a separate SQLite store, never a `metadata.json`
  field or output-archive scan. It uses a subject-scoped inverted token index
  and bounded retrieval. Memory supports an already eligible detail/major only;
  it cannot create a topic or erase direct eligibility. Negative/correction
  evidence is capped and auditable.
- `verified`, `high_confidence` (>=0.90), `correction`, `negative`, and reviewed
  `similar_question` relations are separate persistent record categories.
  Classifier, taxonomy, syllabus, and memory versions are retained. Changed
  taxonomy/syllabus versions are excluded from live retrieval and exported via
  an explicit `stale_records` review workflow; no automatic reclassification
  occurs.
- The old eager `classification_examples.jsonl` runtime path is removed.
  `tools/build_classification_examples.py` now imports filled human labels into
  the indexed SQLite store and offers explicit legacy migration. Automatic
  high-confidence writes are off by default and, when opt-in, are buffered
  until a whole paper completes.

### Read-only MS evidence and historical Business profile

`core/mark_scheme_evidence.py` parses original source-PDF text in memory only;
it neither calls nor alters the locked `MSCroppingEngine`. The guarded runner
feeds per-question raw MS text into classification and records evidence only in
the external `.classification_audit` stream. `metadata.json` remains the
canonical eleven-field document.

`subjects/A-Level/Business_9609/2024/config.json` is a versioned official
2023–2025 syllabus profile selected for 2024 (year verified), retaining existing
major physical folder names while using official detailed section headings or
clear existing equivalents. The source hash is recorded in its vocabulary
provenance file. This is not a silent relabel of the root 2025/26 profile.

### Evidence / limitations

`tests/test_classification_memory.py` exercises persistence, trust gates,
relationship handling, selective retrieval, strict version behavior,
misleading/negative memory non-override, raw MS evidence, buffering,
cross-variant supporting retrieval, ambiguity/multi-topic behavior, and the
authentic Business MS/profile. `tools/validate_business_9609_memory.py` gives
a source-grounded functional receipt for authentic Business 9609/22 M/J 2024.
It explicitly reports accuracy `NOT_MEASURED`: no independent human-verified
per-question topic labels exist locally, so no generalized accuracy or
improvement percentage is claimed.

### Current SHA-256

| File | SHA-256 | Status |
|---|---|---|
| `core/classifier.py` | `ee6b6aa20f31bfb0f92f1723e5ec68cd03e06fd7b1cd852771133dd3a03a9260` | modified classification only |
| `run_guarded.py` | `8368f066895643f45f074a00e38a2e368eae3e9a8a482e56563bc32e23ab312b` | modified orchestration/audit only; crop calls untouched |
| `main.py` | `d96c90d686ba53d8b9e8d92d9cd0360d7a54bfa7488f4d7715d64624b403c2bb` | forwards production memory options only |
| `core/classification_memory.py` | `c72a4cbdee85d82c611e6c1e02111b2c405337756dbc76613a409749ccf48392` | new separate persistent store |
| `core/mark_scheme_evidence.py` | `0b80eb01143b45ffbd250da916ac3ae1b8c58cb6c7b8d89eefa996c59e83181b` | new read-only raw-PDF evidence index |
| `core/__init__.py` | `b716015a55a133249561c40162586532048d94b4e40e6ee72a9d037a3bec1d0e` | exports new non-crop modules |
| `tools/build_classification_examples.py` | `32368d6baab1073ecc965fec73d36bd7017afeadf8fe83460737a513a2265542` | SQLite label importer / legacy migration |
| `tools/manage_classification_memory.py` | `d22a179d4e2ca9bc1b4e12dea87ce8da910376ea33cc2dabd6833a6ffb246616` | controlled review maintenance CLI |
| `tools/benchmark_classification_memory.py` | `d9c76618fec1ae583842bfc00537b6804907039fdc59574de73ef085ed5042ee` | synthetic indexed-retrieval benchmark |
| `tools/validate_business_9609_memory.py` | `c4d471842545d5c17b54d4fa66c214f21d8802fe4aec2670f76f1b78c1070b74` | authentic source-grounded functional validator |
| `tests/test_classification_memory.py` | `93d7c466095d3ff41928d24ea78c9bf0e62950071f8a3cbae241e18b5cf2e9b9` | controlled regression coverage |
| `subjects/A-Level/Business_9609/2024/config.json` | `0b6efc179cb47b937be8957459542b0f3bca5f7e8e353a2fd43e73f4bd9df0d2` | new official historical profile |



## Amendment CLS-13 (2026-08-29) — historical-profile audit and Paper-3 detailed scope — authorised by the user

The requested authentic 2024 Business 9609 QP/MS/Insert/ER validation exposed
one taxonomy-validation integration defect and two low-confidence forced
classifications. This amendment is confined to classification evidence,
profile selection, and validation. It does **not** alter any crop implementation,
raster/image output, crop coordinate/boundary, QP/MS/ER/Insert splitter, or the
canonical `metadata.json` schema/generator/values.

- `FinalValidator` resolves the profile appropriate to the normal canonical
  `level`, `subject`, paper-code, and `year` values before reference-topic
  validation. A historical 2024 detail is no longer incorrectly tested against
  the root/current Business taxonomy.
- `paper_detailed_topics`, where an official profile supplies it, constrains
  scoring, indexed memory retrieval, output selection, and full-auto fallback.
  This ensures A-Level Paper 3/4 direct classifications do not leak assumed-AS
  entries. The optional field is validated for known identifiers and compatible
  major scope; all 320 configurations pass.
- The Business 9609 profile advances to `/5` solely for exact official
  6.1.3/6.1.7/7.4 evidence wording and scope consumption. Topic identifiers,
  physical major routing, and source-syllabus hash are unchanged.
- Raw-MS bare whole-question label recognition remains context bounded and now
  indexes authentic 9609/31 questions 1–5 without accepting generic rubric or
  standalone allocation numerals.

Evidence: `pytest -q tests/test_classification_memory.py` = 16 passed; the
complete official 9609/31 guarded QP+MS+Insert+ER command passed S0–S8,
`saved=5`, and final audit `errors=0`. The source-backed former Q1/Q5 forced
outputs are now `Human_resource_management_strategy` and
`External_influences_on_business_activity`, respectively. Independent
per-question archive accuracy remains explicitly NOT_MEASURED.

### Current SHA-256 (CLS-13)

| File | SHA-256 | Status |
|---|---|---|
| `core/classifier.py` | `d0329e9da0c57138aa96ed054753b90545c02e2ce7d8627f5a1e5a55407709ef` | classification scope/evidence only |
| `core/config_loader.py` | `8cd3a8758610bd589e0f5922ef706d43b663de91cb2891ca12a18f1908d0d64f` | validates optional classification paper scope |
| `core/validation.py` | `9a0a236fbd1941700ce2761cb318a9d2fba944e15c1e1540d383f261d07c2f64` | read-only historical-profile validation lookup |
| `core/mark_scheme_evidence.py` | `ae05260d09dd4459e0a6ea936bcb3feab24b1a59bba8bae3ef99d7bf26d3ebe6` | read-only bounded raw-MS evidence index |
| `tests/test_classification_memory.py` | `63dbb07fa0bcd915dc57959c56e4819798897e49df6071153dffccab9e0f57c0` | regression coverage |
| `subjects/A-Level/Business_9609/2024/config.json` | `ab7624263b4d53aeaeb8e4c2d8ae1811635c18f69250cde8aa3e8877ef2aa768` | official 2024 profile `/5` |
| `subjects/A-Level/Business_9609/2024/syllabus_vocab.json` | `ca7916cc50fc8b229bf2d1ed9d3f078bae5505757059079fd3ef390e084b5a7c` | official evidence vocabulary only |
| `subjects/A-Level/Business_9609/2024/syllabus_vocab_provenance.json` | `48c00a6930fbad8ff413385492d219018106019949d5e95ace307a52f4fa8728` | profile provenance `/5` |


## Amendment CLS-14 (2026-08-29) — classifier-version live retrieval gate

The Paper-3 detailed-scope decision changes the classifier procedure, so storing
a classifier version without applying it to live retrieval would be incomplete.
`topic-classifier/2026-08-29-memory-2` is therefore passed to indexed retrieval
alongside taxonomy and syllabus versions. Records made under a different
classifier version are excluded from live influence and remain available only to
the explicit `stale_records(...)` controlled-review workflow. This is a
classification-memory safety change only: no crop, image, routing layout, or
`metadata.json` implementation changed.

Evidence: the new regression creates a classifier-old record, proves current
live retrieval returns no match, proves the matching historical procedure can
retrieve it, and proves `stale_records` exposes it. Focused regression suite:
17 passed. The authentic 9609/22 memory fixture was rebuilt under `/5` +
`memory-2` and passed; the final authentic 9609/31 QP+MS+Insert+ER full run
also passed S0–S8 with all five classifications scored directly and S8 errors=0.

### Current SHA-256 (CLS-14)

| File | SHA-256 | Status |
|---|---|---|
| `core/classifier.py` | `a6c1d4e5b8bb4ec5d17c4023c55fa3dba8779b8249d365279d2f6b93168cac33` | classifier `/memory-2`, scoped retrieval/fallback |
| `core/classification_memory.py` | `1ea12e6382563f0480813c0f251292a403140f8d715ca8d6eb00be8b7974f9aa` | live classifier/taxonomy/syllabus version filtering |
| `core/config_loader.py` | `8cd3a8758610bd589e0f5922ef706d43b663de91cb2891ca12a18f1908d0d64f` | optional detailed-paper-scope validation |
| `core/validation.py` | `9a0a236fbd1941700ce2761cb318a9d2fba944e15c1e1540d383f261d07c2f64` | read-only historical-profile validation lookup |
| `core/mark_scheme_evidence.py` | `ae05260d09dd4459e0a6ea936bcb3feab24b1a59bba8bae3ef99d7bf26d3ebe6` | read-only bounded raw-MS evidence index |
| `tests/test_classification_memory.py` | `1f627f9177147887052bf78ce3b7376144b37b347d24edcc6e0005813e642819` | 17 focused regressions |
| `subjects/A-Level/Business_9609/2024/config.json` | `ab7624263b4d53aeaeb8e4c2d8ae1811635c18f69250cde8aa3e8877ef2aa768` | official historical profile `/5` |

## Amendment CLS-15 (2026-08-29) — Economics 9708 exact-year historical profile restoration

Following the authorised readiness follow-up, the documented but missing
`subjects/A-Level/Economics_9708/2024/config.json` was restored as the official
2023–2025 profile for a 2024 request. This is a classification configuration
repair only. It changes no crop mechanism, page/splitter boundary, image output,
physical routing policy, duplicate detector, or `metadata.json` implementation.

The profile pins the retained official Cambridge 9708 2023–2025 syllabus
(`https://www.cambridgeinternational.org/Images/595463-2023-2025-syllabus.pdf`,
source SHA-256 `d4c06e4e792aae7c9a62591b78f757cb01329ff18fcf599e431372bdd01f5cad`).
Its 11 official major identifiers and 53 detailed identifiers normalized against
that retained source (64/64); its mapping is complete. Existing compatible
operational classification vocabulary was retained, without inventing or
renaming any official topic identifier. Papers 1/2 are scoped to the six AS
majors and Papers 3/4 to the five A-Level majors, matching the source assessment
overview. The exact child is selected for 2024 while the root 2026–2028 profile
remains the default for 2026 requests.

Evidence: `tests/test_economics_2024_profile.py` 3/3 passed; subsequent full
`pytest -q` passed 358 with 51 skipped and 51 subtests. The former two failures
were resolved by the restored source-provenanced profile rather than suppressed.

| File | SHA-256 | Status |
|---|---|---|
| `subjects/A-Level/Economics_9708/2024/config.json` | `2021a1c3c39bde2d276ae922875246d1ead3926ba246c3e25ed13fd0bdcbc3e6` | restored official 2023–2025 exact-year profile; 2024 selected |
| `tests/test_economics_2024_profile.py` | `c3241f70e11192950b6cd7dd7794860a93b62d1d0c4de95540ef9a8b646998b1` | exact profile/source-pin/paper-scope/default-selection regression |

