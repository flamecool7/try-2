# EFFICIENCY AUDIT — Overseer "Strategic Efficiency Audit" + "6 Upgrades" specs
### Executed 2026-08-10. Evidence in `/home/user/test-crops/eff-bench/`.

Both specs arrived markdown-linkification-corrupted (**misfire #10**): phantom modules
`cambridge_qb.pipeline/markscheme/topics_enhanced/metadata/organize/output_validator`,
wrong call signatures (`split_questions(page_images, pages, meta, sx, sy)` —
real: `split_questions(pdf_path, dpi=, paper_code=, cfg=, webp_dir=)`),
`[pool.map](http://pool.map)`, `*process*single_paper` → `_process_single_paper`,
`state.papers[...] = **import**(...)`, quality preset `92` vs locked `95`.
Every upgrade was mapped onto the real, locked codebase; nothing was applied blind.

---

## The 6 upgrades — applied in order, each confirmed before the next

| # | Upgrade | Status | Evidence |
|---|---|---|---|
| U1 | Parallel paper processing | ✅ PORTED with RAM guard — new `pipeline.py` | Guard table below; `GUARDED_CHILD_NO_STATE=1` child mode in `run_guarded.py`; parent owns `.pipeline_state.json` (no concurrent writers); per-worker logs at `output/.worker_logs/` |
| U2 | Zero intermediate disk writes | ✅ PARTIALLY TRUE → real bug found & fixed | MS path already pure in-memory (`pdf_io.py:98`). **QP path leaked an undeleted `qp_pages_*` tempdir per paper** (locked triplet has no `rmtree`): BEFORE `1 dir / 6 webps / 1517KB orphaned` → AFTER `0 dirs`, crops byte-identical (`a6a284304c876acb`). Fix lives in `cropping_engine.py` (owned scratch dir, `/dev/shm` when writable, `finally: rmtree`). Locked splitter untouched. DPI/quality/method untouched. |
| U3 | Module-level regex | ✅ ONE real site fixed | Hot loops were already module-level (locked triplet, examiner_report, paper_*). The one genuine hotspot: `classifier.py:453` per-keyword compile (15,170 compiles → 82 per process). `_keyword_pattern` lru_cache; findall equivalence proven for all 82 real keywords; end-to-end classifications byte-path-identical to approved m25/w25 baselines. **Honest gain ≈ 0.6ms/question (CPython's re cache already deduped).** |
| U4 | Global taxonomy cache | ✅ REAL equivalent implemented | `TaxonomyLoader` never existed; **but** `load_subject_config_by_code_and_level` re-parsed ALL 23 config.jsons on every call (115 json.loads per 5 calls, 24.7ms → 0 loads, 2.4ms warm). `_CONFIG_TREE_CACHE` keyed on (path,mtime,size) — edit-invalidation proven. Spec's "fork shares cache" claim false for spawn processes; ours caches per worker process. |
| U5 | tqdm progress bar | ✅ APPLIED as optional dependency | `tqdm>=4.65.0` added to requirements; bar renders live with per-paper postfix (`9700_m25_22 rc=0 saved=6 25s`); ImportError → loud plain-lines fallback. |
| U6 | gc + memory logging | ✅ ALREADY STRONG → extended | main.py had 4× gc.collect; worker now also `gc.collect()` + `[mem] RSS at worker end` line immediately before `WORKER-RESULT` (measured 777–815MB post-sweep). `psutil>=5.9.0` listed optional; runner reads /proc natively. |

### RAM-guard decision table (pure function, `pipeline.guard_decision`)
| MemAvailable | requested | concurrency | note |
|---|---|---|---|
| 900–1286MB (this box) | any | 1 | floor of 1; sequential RS-2 path proven at this pressure |
| 2600MB | 2 / 4 | 2 / 2 | fits / clamped |
| 8200MB | 2 / 4 | 2 / 4 | full parallel engages |
| 16400MB | auto(1 for 2-core) / 4 | 1 / 4 | cpu_count//2 default honored |

## Tier-audit leftovers (first spec) — verdicts
- **U1-tier claims (2–5x)**: unreachable on 2-core/1984MB — 2 workers × 933MB measured RSS = guaranteed OOM-137 (full-mode OOM actually reproduced during baseline: `exit=-9 SIGKILL`). On ≥8GB machines the guard allows real concurrency.
- **Batch WebP save (q92/m4)**: REJECTED — conflicts with locked quality 95; per-question outputs are already sequential; encode dominates.
- **Lazy reference detection**: REJECTED — locked triplet + pristine chemistry_reference; CROPPING_LOCK documents the proven cover-page regression.
- **State skip / grouping / gc**: ALREADY SATISFIED (main.py:174-176 RESUME-SKIP loud; matcher.group_papers main.py:129; gc ×4 + subprocess isolation).

## Benchmark (spec's own format, 9700 m25 A-Level Biology, 6 questions + ER)
```
Single worker:            93.3s   (pre-upgrade baseline run_guarded: 93.0s)
Parallel workers (auto):  92.3s   Speedup: 1.01x   (guard clamped 1: physics, not code)
CPU cores detected:       2
Peak memory:              933MB worker RSS; parent <160MB; end 1187MB free
Errors:                   none (exit 0, ALL GREEN, 2-paper run 124s wall)
tqdm visible:             yes
```

## Regression gate (the part that matters)
- 33/33 webps shared with the RS-2 approved tree: **byte-identical**
- 9/9 shared metadata.json: **identical** (uuid id excluded)
- Classifications == approved baselines exactly (m25: Q1/Q4/Q6 Cell_Structure, Q2 Biological_Molecules, Q3 Physiology, Q5 Genetics; w25: Q1/Q2 Cell_Structure, Q3/Q5 Genetics, Q4 Cell_Membranes, Q6 Physiology)
- Resume-gate: second invocation returns instantly (`Skipped 1 already-completed papers`)
- **Gate catch**: RS-2 evidence tree found to have only 9/12 question folders (validator test rig deleted 3 during that session) — discrepancy explained, not introduced by these patches.
- Locked/pristine files byte-unchanged: triplet (00cc779e), multipage pair (c384248b), ms_cropping_engine (9a1dc1e8), webp_utils (f865edff), examiner_report (972e68d3), er_question_crops (b93ad5f2), validation (2a62f1ce), output_manager (1ae25f9d), converter.py (DPI untouched).

## Pending lock amendments (⏸️ awaiting approval — NOT yet written)
- CROPPING_LOCK Am-6: `core/cropping_engine.py` new hash (U2 scratch-dir + leak fix; behavior-neutral, proven byte-identical crops)
- CLASSIFICATION_LOCK CLS-3: `core/classifier.py` new hash (U3 lru_cache; equivalence proven)
- ROUTING_STATE_LOCK RS-4: `run_guarded.py` new hash (U1 child-state mode + U6 end-sweep) + NEW records: `pipeline.py`, `core/config_loader.py` (U4)
- requirements.txt: +tqdm, +psutil(optional) — not a locked file
- Still outstanding from before: RS-3 (`core/quality_scorer.py` 5dd491d8…) and the Uncategorized directive's 4 open decisions.


## Archive synchronization amendment (2026-08-16)

The supplied `ExamVoid_FINAL_v9.zip` contains the post-amendment source tree,
but several historical lock ledgers still ended at the hashes from an earlier
round.  The proof tool verifies the latest ledger row for each path; record the
actual current bytes here rather than weakening that check or rewriting the
historical rows.  This amendment changes documentation only.

| Path | sha256 | Note |
|---|---|---|
| `core/cropping_engine.py` | `b2123545fa3d4db75a8805d67d08779e9e7885a646272f3d4b1310c259fa8c94` | current archive content; ledger synchronized for proof verification |
| `core/webp_utils.py` | `8961d27dbdf0866ed43e63d70aac4ef707924cc71243e7aa87224dd3d332251e` | current archive content; ledger synchronized for proof verification |
| `core/json_generator.py` | `d06fcd9ecb85600e40ae35bfd8680a6883828c24ba603b19d8b705ed037c558c` | current archive content; ledger synchronized for proof verification |
| `main.py` | `2b494136cfea89a1c31709a514ab68d799edb43a12f18060d4bdd161a01a5eb7` | current archive content; ledger synchronized for proof verification |
| `pipeline.py` | `d2299baaaf6a5664f89ae9227b3a5c5ed0fd0ac21e86e07d30d9fb90abe2f644` | current archive content; ledger synchronized for proof verification |
| `tests/test_igcse_formats.py` | `5a848b3a9e6bba8306e758ca5604beaea36859a39e756f866ff36cfdb6b3f6e9` | current archive content; ledger synchronized for proof verification |
| `core/bundle_worker.py` | `9a7593f44c1d1a359b5c47c989dedc19f9bfbc02262ec96ac8bfd7e1b6b0d7a3` | current archive content; ledger synchronized for proof verification |
| `core/batch_runner.py` | `4ad2a0210c53b2e6f469dacdff59a9d6179ce08a6a0a1aff563601e8388897dd` | current archive content; ledger synchronized for proof verification |
| `run_pipeline.py` | `be574a41d1c87967a65f791e491dd3a900144a7eeb5a8f13989feadae44d8f79` | current archive content; ledger synchronized for proof verification |
| `tests/test_batch_infra.py` | `22bdebb77feb2b5013e41c340d4583936ed7e6d5c9cd153a58782abdeb24e0de` | current archive content; ledger synchronized for proof verification |
| `core/mcq_output.py` | `f9a0f045b92798580acb2bfee283abb3aaa9e786c8d4cffda5972fbc2c6bd4d7` | current archive content; ledger synchronized for proof verification |
| `tests/test_mcq_unified.py` | `62d9b23d0a1ff68505ccaf257f1e1aa77dc7b39a161fd1c97ee75e1b81a8900d` | current archive content; ledger synchronized for proof verification |
| `core/chemistry_reference.py` | `953394a0b1e70bc502bc12eaad6264ba0fd28c9aecab1080b444dc16ea6c2f16` | current archive content; ledger synchronized for proof verification |
| `tests/test_letterless_mcq_routing.py` | `a87dfd35955a1bdf8962c7c0e9cb5a05af08ed27da04b95d11fb480875d22e1f` | current archive content; ledger synchronized for proof verification |
| `core/math_reference.py` | `72ec53076a7885acb38ac76de89316a767bba6c4ea1cca96b26d7b2685879534` | current archive content; ledger synchronized for proof verification |
| `tests/test_classification_buffs.py` | `98aeb7d8235f568736fc099c5b4ce52743925a4bb86dd69dc08523be524ef563` | current archive content; ledger synchronized for proof verification |
| `tests/test_code_aliases_combined.py` | `d4be6ffc70690aee259d1fc3b02b8d56df2daa38dd7cfeaa6a60b225d1776183` | current archive content; ledger synchronized for proof verification |

Additional baseline-fix rows:

| Path | sha256 | Note |
|---|---|---|
| `tools/run_proof.py` | `a2f850cde4439b0111f221290e7c572483c8f63ff79d6079dbd391bd93988286` | test-baseline fix in supplied archive checkout |
| `core/er_fetcher.py` | `d2b13ad1f6fc4019314d7f2c8e16b60c8ab7577783c752dbb7c914e2d164e96d` | test-baseline fix in supplied archive checkout |


## Full-auto trust-self amendment (2026-08-16)

The production full-auto policy now applies consistently across the guarded
and SQLite batch runners. Usable QP crops are categorized even when the MS is
missing/unsplittable, the MCQ grid is incomplete, the syllabus year is
unverified, or deterministic QC flags are advisory. `--no-full-auto` retains
the previous fail-closed behavior.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `8dbda9e052e71bfa94861adc227f1ea7cb2b86ec19244708301451a4155442ce` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `run_guarded.py` | `908d88662603763987a5bed4f6c4b217033b9143803a2240c8714dad1904530a` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `core/bundle_worker.py` | `17ee0f0495278126e4084afe2731912cd95311e08d122a03a940bc54b7b89d3b` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `core/batch_runner.py` | `6b24f216d38275c1b08c217174f4a4a9c1571f423cceeccbdd5b5bb32178c5f9` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |
| `run_pipeline.py` | `884ae2c4a6858022029a3f2003b836e6ee1fe1dfcd4c3e734cc4044f9e53727f` | full-auto trust-self policy; QP-only categorization and deterministic fallbacks |


## Full-auto CLI wording amendment (2026-08-16)

Help text now states that deterministic fallback decisions are recorded in
logs/sidecars; canonical metadata remains the strict 11-field schema.

| Path | sha256 | Note |
|---|---|---|
| `run_guarded.py` | `34715130da43ecd174f8b545b6743f1158e16d70b1028a068527232bb4573b67` | full-auto help text aligned with canonical metadata contract |
| `run_pipeline.py` | `0bc219da8797adb8ae46434493a5dd1814f9793713aaecab74a385b2ac1ac917` | full-auto help text aligned with canonical metadata contract |


## Incremental refresh and classifier-evidence amendment (2026-08-16)

Added input-fingerprint requeueing for QP/MS/ER changes, transactional output
replacement for refreshed bundles, run-level classification audit traces, and
optional verified-example retrieval. The canonical question metadata schema
was not changed.

| Path | sha256 | Note |
|---|---|---|
| `core/database.py` | `0d4a1e5ed23ce328979f543eb727cb69fe4c72ae4f3a9772748bd618f2fb06de` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/preflight.py` | `9725e5caaa9219ce031e82312297d1238b529bc9efe7ab8c9751b6dc09f40361` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/pipeline_state.py` | `b29c8b54d44542323380e62170b1d8f1411cae3a0367968bb0c2be1c8f2e5b21` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/staged_writer.py` | `3eedc22f8711c542b3774b593e10ffe5faf10f183da305cb524cf5ba98919a60` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/bundle_worker.py` | `ce918b53d7a11d4778d148301e42a7c4e38b5872d73e0b33ed2eb2c72477a3f9` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/output_manager.py` | `08fc8b7027889763b2a3390406bda1b3e369b8e9c99ac914bd8e64c3ff3757b8` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `run_guarded.py` | `e96d1b820ee8ad34cd3d989b2f5f59359fe0554c46053bf3784cfe40cc52b4eb` | incremental input refresh, external classifier audit, and verified fallback improvements |
| `core/classifier.py` | `633b02f3e3cf93c9a675e480aa17cda3a20f332de8bae387542f7f3566e978be` | incremental input refresh, external classifier audit, and verified fallback improvements |


## Styled progress UI amendment (2026-08-17)

Shared colored progress UI for the SQLite batch runner and root parallel
orchestrator. `run.bat` enables color presentation; `NO_COLOR=1` disables it.

| Path | sha256 | Note |
|---|---|---|
| `core/progress_ui.py` | `6b006b98ce65161929c2a2fad07533e94d830981921283409a3659d814d363e3` | colored progress display and sequential/parallel UI parity |
| `core/batch_runner.py` | `1b72cd569494f7fb82eaf5b25f28caae7ec545fd40238401dd986133844a212a` | colored progress display and sequential/parallel UI parity |
| `pipeline.py` | `7371d095935741b9a895caa55692c30e78ee0c9dc3537965616e69c29440954e` | colored progress display and sequential/parallel UI parity |
| `tests/test_progress_ui.py` | `72886b50ef467c0869dd361c5a20e93b92dbb83273a91410141728f9c40afa76` | colored progress display and sequential/parallel UI parity |


## MCQ and paper-folder routing amendment (2026-08-17)

Accounting 9706 and 0452 Paper 1 MCQ components are now registered, with a
PDF-content identity fallback for compatible subjects whose formats are not
static yet. All physical paper-type directories use `paper-N`; legacy names
are migrated during output cleanup. Insert sidecars are carried through the
SQLite batch path into the existing insert engine. No cropping mechanism files
were changed.

| Path | sha256 | Note |
|---|---|---|
| `core/mcq_registry.py` | `c210c6f6e71cf2453398873e042dc05cc1861c3a69df0c415cbd5897a924153d` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/paper_identifier.py` | `52e2f8b793fcf147501e49ed090bacca1d6de3b854358f75f2f36b35bafde60d` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/qp_ms_matcher.py` | `388df5d1bc8af56d3ba53d6512112993569d8c1ec6bc3ae11c2b22b09d816894` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/output_manager.py` | `f8d057b96f8633a28c293338e53baaa57d19872c785c0ff3fd1112df0e4f6b91` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/database.py` | `046f3ca8eae842d9d4a2c5bf908085588f38f43e974153a859d475c5c00c7770` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/preflight.py` | `e05cb9105e204b203e3dbbf6923e2f3c3e7f9a41d7eb86e983726320d51fc0c1` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/bundle_worker.py` | `c78127377aee1cdc6ae56e576eef8263501ece09bf59d07a8b2ff349675fceac` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `core/batch_runner.py` | `a6257f659c3a5ed4c4fee54d0ea40e6a2255fdd2b9345bb3ed258fcc6e244082` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `run_guarded.py` | `baedeefc12a78c25d52e942e57d2ee3b38d95797a098cb36d8dc003c71d95679` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_confidence_gate_fixes.py` | `2baee1ffcc8028904993c4b40dd7790cf4aba4c06ce54afe0d1da4998231a155` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_igcse_formats.py` | `90642aa6fcb3066f62081cfa84cdba66f7d70ce71b3292ce3e46c143379e1bce` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_batch_infra.py` | `477aa37c49ed62929af184216329a0383154c08d17b04a4f2bf2cd2c102fd2a3` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_mcq_unified.py` | `ac589f28161bfd101191af034cfabb876d88476851ec32a18c77f2e0d9ebed37` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_quarantine_tool.py` | `114eea8a1cb23cb11c0dae1cedf28d465ae93766d33440e23b8e49e5b226ffcc` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_spec_buildout_rs18.py` | `f9680614a81f6905f3acc401ce3cf6cde128b49d7b1fad8bd84b2ed58b222b1a` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_topic_accuracy_workflow.py` | `159c96c66ee06e422eac118100a987a3f06d917bff34c491a3aca8e93f2206a3` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_missing_papers_and_insert.py` | `4524748f91a29f93e046b9cbc43ccc4e187da582e6114722df41b997028b97eb` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |
| `tests/test_extended_variants.py` | `7a6ccb240ec9fa83de491ccc9fa5f8b9ee6e1d640dde68253cc989069acd9513` | MCQ format coverage, universal paper-N folders, and insert wiring; crop mechanisms untouched |


## MCQ compatibility polish amendment (2026-08-17)

Finalized generic content-driven MCQ output handling and regression coverage.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `509246be44799e4e6d7e9cbf3ab72412f732790fc6c71ee8f43c7e3e11e74648` | content-driven MCQ fallback and paper-N output contract |
| `tests/test_content_mcq_formats.py` | `907c4c6d2770731f7fabb01aa4953fdaebeabd6fdc670cfdb97575f9c64f1344` | content-driven MCQ fallback and paper-N output contract |


## Insert filename-variant and content-format amendment (2026-08-17)

Insert/source-booklet naming variants now normalize to the insert sidecar kind
without touching cropping code.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `c1da35b3a8fce49c9b2885bb749f4ce1ba0e9608367ab8bb1adc2b2702ceed5d` | insert filename-variant recognition and content-format regression coverage |
| `tests/test_content_mcq_formats.py` | `9f4d7ffa1a14b66397e3a32b026bca9a0c58d92d9a5c424a8da4376267fa83fd` | insert filename-variant recognition and content-format regression coverage |


## Insert sidecar skip-log fix (2026-08-18)

Insert/in/ir/ci/sf files now enter the bundle sidecar path instead of being
misreported as unsupported kinds; only grade-threshold sidecars are skipped
from QP/MS bundle construction.

| Path | sha256 | Note |
|---|---|---|
| `core/preflight.py` | `d244774f3ff620fc7f68b3e31f76976c5baf58cfa3265b3e5b6f967deae525dc` | insert recognition wiring fix |


## Confidential-instructions sidecar amendment (2026-08-18)

Confidential-instruction files are now carried separately from insert source
booklets and copied intact into the matching `paper-N/_confidential/` folder.
They are never sent through a cropping engine.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `90c5856d3df32f0709d69f7e199a57269a708cd63a60f8085b7972ddd73d42bd` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/validation.py` | `629fdda361a7feb1a9295c7d0194ac62ef73e4ba2a004ade700fc4232fda370f` | confidential-instructions recognition/copy sidecar; no crop changes |
| `run_guarded.py` | `fa0597e8fa6a3a74784d8d3bfc06559f61444aa17d2f922d1aafdf2331b099c8` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/database.py` | `74bebd75bd30d67531e49f8066690cf9916d0d1e718f1c190a161efb97578e2e` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/preflight.py` | `2de5114bb0f7f9612ab2ef196292ef1afe2563c22899584882f110150207c045` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/bundle_worker.py` | `6f0c50ca21cdee8610e884b2cce1607c695876d3c9e62fe8b7fcb518ec8ed563` | confidential-instructions recognition/copy sidecar; no crop changes |
| `core/batch_runner.py` | `05a9f307ce6f0600001c5931aed406d35bb07a473aad0c11cd9fb20b79ca4d92` | confidential-instructions recognition/copy sidecar; no crop changes |
| `tests/test_ci_sidecar.py` | `b8b84ccfedc520dbf6c99558b0f76df9fa9d0979e18b664c6d3db360f703e4a4` | confidential-instructions recognition/copy sidecar; no crop changes |


## CI per-question page attachment amendment (2026-08-18)

Confidential instructions can now be retained intact at paper level and
rendered as full-page `_CI.webp` sidecars inside every saved question folder.
The pages are excluded from QP counting and are never question crops.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `bc0958670af8e3c1543ad7b40516aa1d66c6e8d48e1b367a3a2a73a0ab595678` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `core/validation.py` | `856bd51233e4d084df1744adb0fa96590c61f6cd11e5a591f81ed830c3a5ed28` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `run_guarded.py` | `c3ae1a5da3d27ba4e78e88ffa5883fbd382d2d995d31726e5f7051b0c624aab0` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `core/bundle_worker.py` | `4a1d09cbd9b2081f7f46b822b0ed18a222c5e4168bef2f4e5cc6b387cbf0bbe5` | confidential-instructions page attachment sidecars; no crop mechanism changes |
| `tests/test_ci_sidecar.py` | `5afab4a098a2177ccf0b014370b3ebb0b2261d843277398959f13b653ccc33c0` | confidential-instructions page attachment sidecars; no crop mechanism changes |


## S26 filename normalization amendment (2026-08-18)

Expanded filename parsing for S26 and May/June 2026 variants, including
compound month names, question-paper/mark-scheme separators, and insert/CI
sidecar suffixes.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `9a0be7e013b636340eeb1498c194343864dd712553d079974595eaaa51cdf0ea` | S26 and non-standard filename identity parsing |


## Future-session identity hardening amendment (2026-08-18)

Identity parsing is now season/year agnostic for supported syllabus codes. It
accepts standard S26/S27 tokens, compound May-June/October-November/February-March
names, varied separators, and uppercase PDF extensions. A wholly new syllabus code
still requires an approved taxonomy profile rather than a guessed subject.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `82c8f2619c75239c2e6da9ad7449bf48dcb164065e8863489572d9cd46e76175` | future session/year naming normalization and case-insensitive PDF scan |
| `core/preflight.py` | `5335d938e5e419e9a989bf805ede1b8fe14c80b3198853ffcc194e85028635c6` | future session/year naming normalization and case-insensitive PDF scan |
| `tests/test_content_mcq_formats.py` | `d822a0e178c00b7239ca45aa81f60dc9339e8b5484441cc8d97e149ea113936c` | future session/year naming normalization and case-insensitive PDF scan |


## Additional S26 long-name hardening amendment (2026-08-18)

Added support for compound-session names with short QP/MS markers and underscore
separators, plus four-digit future years in loose identity fallback.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `82c8f2619c75239c2e6da9ad7449bf48dcb164065e8863489572d9cd46e76175` | additional future S26 long-name and compound-session normalization |
| `core/preflight.py` | `5335d938e5e419e9a989bf805ede1b8fe14c80b3198853ffcc194e85028635c6` | additional future S26 long-name and compound-session normalization |
| `tests/test_content_mcq_formats.py` | `d822a0e178c00b7239ca45aa81f60dc9339e8b5484441cc8d97e149ea113936c` | additional future S26 long-name and compound-session normalization |


## S26 batch-abort fix amendment (2026-08-18)

Fixed the S1 hard abort seen with the 2026 batch: insert/CI sidecars are valid
parsed inputs, known filename codes take precedence over noisy header-level
heuristics, and byte-identical `(1)` duplicate downloads are ignored rather
than treated as identity conflicts.

| Path | sha256 | Note |
|---|---|---|
| `core/subject_detector.py` | `be8b784d051048fa9b217a68dbca53ac901f4826f638606fbc39a93187a7f006` | S26 sidecar acceptance, filename-code level precedence, and duplicate-copy de-duplication |
| `core/qp_ms_matcher.py` | `8a60da099c7344580424a7547e0416aec09aa259d99193f7628f463be15e3e90` | S26 sidecar acceptance, filename-code level precedence, and duplicate-copy de-duplication |
| `run_guarded.py` | `33955322109ac190085516b995c54f75e57b0567824ce816bdaee8d6d591ace9` | S26 sidecar acceptance, filename-code level precedence, and duplicate-copy de-duplication |


## Long-horizon year interpretation amendment (2026-08-18)

Modern two-digit session years no longer wrap 50-99 to the 1900s; future
sessions such as S50 resolve to 2050 while existing modern papers remain
unchanged.

| Path | sha256 | Note |
|---|---|---|
| `core/paper_identifier.py` | `fd3291f5ab2ceaec3ebe00b6ccb46c5a2a82d4a4b0a3dcdc6203d043a05ce213` | modern two-digit years remain future-compatible through 2099 |
| `tests/test_content_mcq_formats.py` | `bf36d81eb8b3f0bddcf7f88751083f90b534359fb0f7022d73626f81fc34c056` | modern two-digit years remain future-compatible through 2099 |


## 2026-08-26 launcher, ER integration, and classifier robustness round

The current implementations below supersede earlier hashes in this ledger. The changes add the real-run launcher/report path, ER-only auxiliary output protection, session filters, and separator-tolerant all-subject classification signals; locked crop geometry and metadata schema remain unchanged.

| Path | SHA-256 | Note |
|---|---|---|
| `core/output_manager.py` | `620c4154286b5db60e3b2ffe6d1cc0c8b47482ab3ab74beb2e29d6233c9e41ab` | 2026-08-26 current round |
| `core/validation.py` | `f60360dad22cea45f63fe83b0fa5befaf9e4baa5b42d80c8c67a0ed56dad8403` | 2026-08-26 current round |
| `run_guarded.py` | `68e9854e35bb4e14cf364cc1cd33080c97ed395bcba0b9d0438ad243078c555b` | 2026-08-26 current round |
| `core/batch_runner.py` | `8509bf8c3ef5ac3043ee16cd0bc215f9864f16c98020f4252d8003d354049789` | 2026-08-26 current round |
| `run_pipeline.py` | `fb781fee62117f7b6edbc81d0bc04dae6c09de3f5497d39df6684cfbf5e6825c` | 2026-08-26 current round |
| `core/classifier.py` | `914607f17f52f36b865b3c8255ae1a3e34a231fac5d6379b6c618763cbc6fd30` | 2026-08-26 current round |


## 2026-08-26 final integrated ER-output protection and all-subject routing hashes

Final hashes after integrating the ER-only organizer under `output/Examiner_Reports` and protecting that auxiliary tree from topical cleanup/validation.

| Path | SHA-256 | Note |
|---|---|---|
| `core/output_manager.py` | `620c4154286b5db60e3b2ffe6d1cc0c8b47482ab3ab74beb2e29d6233c9e41ab` | final integrated round |
| `core/validation.py` | `f60360dad22cea45f63fe83b0fa5befaf9e4baa5b42d80c8c67a0ed56dad8403` | final integrated round |
| `run_guarded.py` | `68e9854e35bb4e14cf364cc1cd33080c97ed395bcba0b9d0438ad243078c555b` | final integrated round |
| `core/batch_runner.py` | `8509bf8c3ef5ac3043ee16cd0bc215f9864f16c98020f4252d8003d354049789` | final integrated round |
| `run_pipeline.py` | `fb781fee62117f7b6edbc81d0bc04dae6c09de3f5497d39df6684cfbf5e6825c` | final integrated round |
| `core/classifier.py` | `914607f17f52f36b865b3c8255ae1a3e34a231fac5d6379b6c618763cbc6fd30` | final integrated round |


## 2026-08-26 syllabus-reference anchor layer

| Path | SHA-256 | Note |
|---|---|---|
| `core/classifier.py` | `ef9e13af36f5c4d8c2b9cc9344cabed8a87ee23476bc00c4e5cb57b584d610f6` | unique local syllabus anchors; no crop changes |


## 2026-08-26 long filename worker-identity compatibility and Windows console safety

| Path | SHA-256 | Note |
|---|---|---|
| `run_guarded.py` | `4ebbe12cc90223a4a88c98ce1c125d3d0a68be14d972367454233a4d3c94632a` | current worker compatibility round |
| `core/batch_runner.py` | `e9fb8abe8f4e89b1eabf7c4a0f6d9b9c1c6c23f88dc554bca079b77317c3ed28` | current worker compatibility round |
| `run_pipeline.py` | `c6bc1b0e230c32c700b2bbf3d1f220966eb64e8adc3651e658623b27c864cf9b` | current worker compatibility round |


## 2026-08-26 long-filename alias and console-encoding final hashes

| Path | SHA-256 | Note |
|---|---|---|
| `run_guarded.py` | `4ebbe12cc90223a4a88c98ce1c125d3d0a68be14d972367454233a4d3c94632a` | final S2 compatibility fix |
| `core/batch_runner.py` | `e9fb8abe8f4e89b1eabf7c4a0f6d9b9c1c6c23f88dc554bca079b77317c3ed28` | final S2 compatibility fix |
| `run_pipeline.py` | `c6bc1b0e230c32c700b2bbf3d1f220966eb64e8adc3651e658623b27c864cf9b` | final S2 compatibility fix |


## 2026-08-26 ASCII Windows bundle status labels

| Path | SHA-256 | Note |
|---|---|---|
| `core/batch_runner.py` | `cf37c4ed9684b9f2a181838d0151d9ce0aa79592ee2609fcac5da123c33d7bd9` | [OK]/[FAIL]/[REVIEW]/[SKIP] console labels |


## 2026-08-26 human-readable failure categories and no REASON.txt artifacts

| Path | SHA-256 | Note |
|---|---|---|
| `core/output_manager.py` | `e93bd7469948057c61343355a507ef3ef8ff0c1ebe3db7b9795c322101c51f14` | current support-report/reason policy |
| `core/validation.py` | `4926c641a0e92a195060efc28281a2c86b4950e5603a190366d06004c154a7f3` | current support-report/reason policy |
| `tools/build_run_report.py` | `b4bc9b4c76e218a3e91ecba8f74b039e4ccc294e181afb2685d254c0b945f046` | current support-report/reason policy |
| `tests/test_missing_papers_and_insert.py` | `fd513971f86a15ab67758041f63746d7a825d405ba539641be11a72a99d112a3` | current support-report/reason policy |
| `tests/test_qp_only_placeholder.py` | `e4c0f57cbf418cfff5884de27f4cfb28954b8cd6b96ce15a1d9b99038783b444` | current support-report/reason policy |


## 2026-08-26 safe worker concurrency (2 workers) & internet categorizer integration

| Path | SHA-256 | Note |
|---|---|---|
| `core/batch_runner.py` | `50fca1574af7de5b5fa2d09a2cf3e09913dbca8c8d2aa182892c41aaaac92754` | OOM-safe default concurrency (2 workers) & internet categorization bridge |
| `run.bat` | `39c38de9cf8661c2a6ea651fc98b789b81637b24112dc72cea1e61e153ab34d2` | interactive prompt for internet categorization & tools menu option |
| `tools/internet_categorizer.py` | `ff066ec258fcc5e2bfc5a24271ea08e39221ad7984a082f1ab00b20c4dc11dc4` | standalone internet/LLM subject & topic classifier with SQLite caching & thread pooling |


## 2026-08-29 Insert crop whitespace trimming & 2024 Accounting test suite

| Path | SHA-256 | Note |
|---|---|---|
| `core/insert_engine.py` | `c7d9d017079deec48599920271d7fb0fafa0ed6f90cac91c0e6d9edd897f1012` | generalized bottom-whitespace trimming on insert crops + Cambridge header grammar |
| `core/paper_identifier.py` | `5e0ece3b666297cdf0569e39f688209c606a442d292bc5f263c89ad3aac4d0eb` | variantless ER/GT resolution for descriptive long filenames |



## 2026-08-29 Production Scalability, Duplicate Detection & Incremental Manifest

| Path | SHA-256 | Note |
|---|---|---|
| `core/output_manager.py` | `09881b29411d566f57f4f0466202ab31bcf45939441aaca43329fae621ef3e52` | fast in-memory question folder indexing eliminating O(N*M) rglob |
| `core/database.py` | `c6e74e2657416a56b134436eec5c2d24af31d4c7a5837266e49b864b04fd186a` | checksum pass-through for register_file avoiding redundant SHA-256 |
| `core/preflight.py` | `7dab2ef0a94fbe5af01b5adc192e8864a799a3aa71ea5bb83c08d3f021a56557` | incremental processing manifest integration with stat-based hashing |
| `core/bundle_worker.py` | `b8fc1fed543ca3665a87a42f361cb71b1e8587bb265de4f9b5eee4f1d1e545f5` | subject-scoped question folder cleanup and processing manifest recording |
| `core/batch_runner.py` | `f47f1eda4d492d9a7261a950a64dec61ae768fc66e5e264d9eaaa69a9675f6c0` | manifest status tracking and --force-all flag support |
| `run_pipeline.py` | `e9c7d9ecfb2a959691052ed1807f841287e87947c204c1bcbe337eb5c057f03a` | --force-all command line flag |
| `core/insert_engine.py` | `deabb38f698a046ccdafd48e5242bc4d99656791de3a415dcdf9a5fe94682df5` | top page number exclusion and bottom copyright/permissions removal |


## 2026-08-29 ExamVoid Launcher & Production Control System

| Path | SHA-256 | Note |
|---|---|---|
| `run_pipeline.py` | `900620a5d3995fffe97e596f227564ec65a752759c5f9dfcae792ec450b8581c` | production control system flags (--menu, --audit, --stats, --sys-check, --cleanup, --benchmark, --scan-new) and lock protection |


## Production artifact-contract and 2024 Accounting validation amendment (2026-08-29)

This final production-safety round preserves the locked QP, MS, Insert, and ER
cropping mechanisms byte-for-byte. It corrects only orchestration, delivery
artifact validation, and reporting around those mechanisms:

1. **Structured MS fail-closed contract.** A structured question for which no
   usable MS crop is available is retained with its genuine QP crop and
   canonical metadata in `review_required/review_required_no_ms`; it never
   receives a fabricated image or a text stand-in. Only a registry-confirmed
   MCQ component may retain a `*_MS.txt` answer-grid sidecar.
2. **Final-product text contract.** Writer and archive validation reject
   non-MCQ question-folder text artifacts, including legacy `REASON.txt` and
   `examiner_report.txt`. Cleanup removes only those known legacy generated
   names; canonical metadata and WebPs remain untouched.
3. **Insert safety.** The staging/commit wrapper reconciles stale Insert
   assets and drops an empty-looking Insert page only when the source PDF text
   explicitly declares that page `BLANK PAGE`; it does not use a generic
   image-size heuristic.
4. **Accurate ER reporting.** The non-crop ER attachment path now reports a
   visual attachment and a disabled component text summary accurately. It no
   longer claims it wrote `examiner_report_full.txt` when final-product policy
   correctly disabled that write.
5. **Reproducible official validation.**
   `validation_evidence/accounting_9706_s24_41/` records public official
   Cambridge 9706/41 M/J/2024 QP/MS/Insert/ER URLs, SHA-256 hashes, a complete
   first run, an unchanged same-path default resume, and an artifact audit.
   The two real top-level questions have QP/MS/Insert/ER visual artifacts;
   all question WebPs are 2280px wide and the archive contains zero `.txt`
   artifacts. `accounting_9706_s24_31/` separately records the safe
   review-required outcome when the locked MS splitter declines full coverage,
   including source-proven blank Insert-page omissions.

The two `tests/` rows below are regression evidence, not runtime delivery
artifacts. The `database`/`preflight` rows refresh stale ledger entries to the
verified current working-copy hashes; no crop mechanism is included here.

| Path | sha256 | Note |
|---|---|---|
| `core/output_manager.py` | `aafc523e073e2a9ebbfe1e086aab321e65dc952c4892742238bfeff331342a95` | structured-Missing-MS write rejection and legacy question-text cleanup |
| `core/validation.py` | `f3891ef8319d764ef8c9e4c5fe9d3e3913a630cc1e7dec8a504785167ace81a2` | metadata/registry-aware MCQ-sidecar-only archive validation |
| `run_guarded.py` | `ed3eb6e727b69e8d8aea6a17c46e828fc45c3893d5403822514f7d9def82959c` | structured review routing, retained Insert attachment, and accurate CLI guidance |
| `core/database.py` | `6105d8626fac558404e09df200b7c99b8096677cf2153efeafdb5e3e83d408b5` | verified current ledger refresh |
| `core/preflight.py` | `a2b301f911667a1833e593fc60cdd4a2e9e21473f5b5fa9b7649258eb15fee2a` | verified current ledger refresh |
| `core/bundle_worker.py` | `d5871cdc4ba9e4a009cf95eb7361cd70f1fa036c299ee50ca4fe46a55a04ca08` | explicit-source blank Insert guard and format-aware staging validation |
| `core/batch_runner.py` | `d54a8f982593b46b24a49675b734dc8e81e99d998ce8a7ea204f00905298d9e2` | accurate visual-ER status reporting; crop stage untouched |
| `run_pipeline.py` | `bb9b090d8ceaa1ac4d49d0d457ddb41b1d93a6bf86cd85915aaba7003bd75a01` | accurate full-auto help: never bypass structured MS safety |
| `tests/test_batch_infra.py` | `2f105280a57e8921dd9e7af7885f95ab4246d5fcef53d64cca6884155b04cc84` | explicit-declared-blank Insert regression |
| `tests/test_qp_only_placeholder.py` | `db27d808504c86d14994bfd9f8b2d6df4a66f62e7a6b932143355f303ee2555b` | structured QP-only review/no-text regression |

## Documentation-truth and proof-contract amendment (2026-08-29)

User-facing CLI help, guarded-stage labels, and generated proof language now
state the same safety rule as the writer/validator: automatic mode can choose a
topic but cannot publish a structured QP without an MS crop. The proof manifest
no longer describes retired `REASON.txt` delivery artifacts, and the regression
checks the current locked-triplet prefix rather than an obsolete one. No crop,
classification, or output-routing algorithm changed in this amendment.

| Path | sha256 | Note |
|---|---|---|
| `run_guarded.py` | `7727e1e1d6a647fa15bf313c748fcf6de47879c684572330aeb13178de3f33c9` | accurate automatic-mode descriptions and ER visual-stage label |
| `tools/run_proof.py` | `e3cc5d8adf6bea13542c0bb86f1f48431b69d713c08a8c38a71c7e17710b4fb3` | current MCQ/review contract and current triplet proof prefix |
| `tests/test_proof_report.py` | `7bf87873d4fc3a9adaf604d072802aba0aa660d42828c48c0ed158a664c43d32` | current dynamic-proof expectation |

## Release-location proof correction (2026-08-29)

`tools/run_proof.py` now looks for `ExamVoid Topical Generator.zip` beside the
repository first, retaining the historical parent-directory location only as a
fallback. This makes a freshly built workspace release visible to the proof
report instead of falsely reporting it missing. Packaging, crop behavior, and
runtime processing are unchanged.

| Path | sha256 | Note |
|---|---|---|
| `tools/run_proof.py` | `2b50b51fff0bfacf739d848db13eda53c311bacdd226d571715ad02684eefc1f` | repository-local release discovery with legacy fallback |

## Historical Economics 9708 profile and component-scope correction (2026-08-29)

This evidence-led amendment supports a genuine May/June 2024 Economics 9708
run without changing any locked QP, MS, Insert, ER, stitching, or multipage
crop mechanism.

1. **Exact-year registration precedence.** `core/config_loader.py` now detects
   a `subjects/{Level}/{Subject}/{Year}/config.json` child before registering
   generic aliases. A historical child is available only through exact-year
   lookup keys and cannot overwrite the root/default profile merely because
   recursive discovery encounters it later. A child-only subject remains
   supported as a fallback, but it cannot clobber an already registered root
   profile.
2. **Official historical profile.**
   `subjects/A-Level/Economics_9708/2024/config.json` is sourced from Cambridge
   International's 2023–2025 Economics 9708 syllabus
   (`https://www.cambridgeinternational.org/Images/595463-2023-2025-syllabus.pdf`,
   locally hash-recorded in the validation evidence). It selects 2024 as a
   verified year while leaving the root 2026–2028 profile as the default.
3. **Data-driven component scope.** Economics now declares `paper_topics`:
   Papers 1–2 use the six AS-level topic areas; Papers 3–4 use the five A Level
   topic areas. The existing generic classifier gate is used — no subject-name
   branch was added. The classifier also filters metadata detail topics through
   that same approved paper scope, so an AS Paper 2 folder cannot contain an
   A Level-only detail label after routing is constrained.
4. **Regression evidence.** `tests/test_economics_2024_profile.py` proves exact
   2024 selection, non-clobbering 2026/default selection, and AS-only details
   for a 9708/21-style international-trade question: **3 passed**. The
   historical source bundle was then reprocessed with the full production QP
   path; output sits under
   `validation_evidence/economics_9708_s24_21/archive_2024_profile_full_ram/`.

| Path | SHA-256 | Note |
|---|---|---|
| `core/config_loader.py` | `b0a235707927ec9a205378059eaab0b9ae2d21dd2c07b988040e596175164041` | exact-year child registration cannot overwrite default aliases |
| `core/classifier.py` | `81c5b99b8efc909ad82a95a54bdf2e02ff9a08200e1f64bad42697743a217b46` | paper-scope filter applies equally to metadata detail labels |
| `tests/test_economics_2024_profile.py` | `8e579be07e320b11040a00a4cbabebcfbde6afa6a414d40491a543a1481d1b34` | historical-profile and AS-scope regression coverage |

## 2026-08-29 `/21` crop-remediation completion and S7 text-policy reconciliation

This entry records the smallest authorised remediation after the actual
9708/21 production images, rather than adding duplicate pipeline features.
It does **not** change the requested target: `/22` QP/MS and a standalone
Insert remain absent and fail closed.

1. `run_guarded.py` S7 now distinguishes an unavailable legacy ER text probe
   from a real crop-containment failure. Under the explicit no-`.txt`
   final-product policy, `written > verified` with an empty `verify_failed`
   list is reported as a policy-aware visual-crop success; an explicit
   `verify_failed` entry remains fatal, and geometry/write/error checks remain
   unchanged. This removes the runner-policy contradiction without reintroducing
   prohibited `examiner_report.txt` files.
2. The QP triplet and ER cropper have the separately documented, narrowly
   authorised source-coordinate boundary changes in CROPPING_LOCK Amendment 13
   and EXAMINER_REPORT_LOCK ER-5. No generic hardcoded per-file crop, UI layer,
   or delivery schema was added.
3. `tools/run_proof.py` and its regression expectation now surface the current
   authorised triplet pin and lock exception honestly. The focused remediation
   test is evidence only, not a runtime output artifact.

Evidence: `pytest -q tests/test_9708_crop_remediation.py -vv` = **6 passed**;
full `pytest -q` after the remediation = **343 passed, 46 skipped, 51 subtests
passed** (five dependency deprecation warnings); the clean `/21` guarded run
reached S8 all green and its separate `--validate` audit passed `errors=0`.

| Path | SHA-256 | Note |
|---|---|---|
| `run_guarded.py` | `5cadd11df8c38b2ce6b165ea7c788e87131390603386936edb066e1da4eae45d` | S7 policy-aware no-text ER verification gate; explicit failures remain fatal |
| `tools/run_proof.py` | `1b86f21963a582924e6bc336845037011867ee42b28995d8778996c0d913a813` | proof limitation names current authorised triplet pin and scope |
| `tests/test_proof_report.py` | `55f01ea6cdfae6222fb8def5ece99b181b89f504a905682b31f39cacc34fdc3d` | proof contract expects current c028daa5 triplet prefix |
| `tests/test_9708_crop_remediation.py` | `6351ea181d2a08569499fc912bbb4fe6b0338e4392a999eaeca22e9bd1d389a3` | QP/ER actual-crop and S7 policy regression evidence (6 tests) |

================================================================================
SECTION 14.21: QP STANDALONE-OR BOUNDARY REGRESSION & FRESH CROSS-PAPER AUDIT (2026-08-29)
================================================================================

This entry records the completed evidence cycle for the narrowly authorised
QP-only standalone-`OR` correction. It does not substitute Economics 9708/21
for the unavailable requested 9708/22 bundle, and it does not modify ER in
response to the QP fix.

1. **Underlying crop-boundary implementation, not a display mask.** The
   identical QP splitter triplet now ends a preceding question at a proven
   source-PDF standalone `OR` choice marker only when the exact isolated,
   left-margin marker falls between that question and a promptly following
   top-level marker on the same page. Segment image and segment text use that
   same source-coordinate boundary. Inline prose (`or`), centred/table text,
   and distant/unlinked markers are rejected by regression controls.

2. **Fresh authentic positive regression — Economics 9708/21 M/J 2024.** The
   QP source scan identifies exactly two markers: after Q2 on source page 3
   and after Q4 on source page 4. New full guarded output contains neither
   standalone marker in the Q2/Q4 crop text; Q2 is `2280×260` (pre-OR
   `2280×363`) and Q4 is `2280×486` (pre-OR `2280×589`). Q3 correctly retains
   “price elasticity of supply or cross elasticity of demand”. QP Q5 remains
   `2280×296` without the permissions tail; Q1 still ends before Section B;
   ER Q1 remains `2280×1516` with a `60px` largest interior white run. The
   historical 2023–2025 config resolves exactly for the 2024 source and routes
   the AS Paper 2 questions into the historical AS topic scope. The full run
   reported worker 105 checks and guarded parent 41 checks, all green; separate
   `--validate` reported `errors=0`.

3. **Fresh independent cross-paper full-document run — Accounting 9706/32
   M/J 2023.** An authentic local QP+MS+ER+Insert bundle passed source
   identification, association, classification, canonical metadata/folder,
   duplicate-folder, artifact, 2280px-width, and final structural-validation
   checks. It produced QP/MS/ER/Insert WebPs for Q1–Q3. Its source has no
   standalone QP/ER `OR` line, providing a non-trigger cross-paper control.
   The audit deliberately reports one visual-quality failure: question-specific
   ER Q3 contains an `1874px` internal/trailing all-white run versus the
   `120px` threshold. The fresh Q3 ER bytes match the pre-OR Accounting output,
   showing this is a pre-existing ER terminal-boundary defect and not an effect
   of the QP OR correction. It remains FAIL rather than being hidden behind
   S8's structural success.

4. **Source/proof receipts.** The data-driven proof generators embed actual
   final WebPs and write both machine-readable audits and standalone HTML:
   `validation_evidence/economics_9708_s24_21/independent_diagnostic_audit.json`,
   `validation_evidence/economics_9708_s24_21/proof_9708_21_diagnostic.html`,
   `validation_evidence/accounting_9706_s23_32_or_crosspaper/crosspaper_audit_9706_s23_32.json`,
   and
   `validation_evidence/accounting_9706_s23_32_or_crosspaper/proof_9706_s23_32_crosspaper.html`.
   9708/22 still has no approved local QP+MS source and no standalone Insert;
   its delivery status remains fail closed.

5. **Focused checks.** `pytest -q tests/test_9708_crop_remediation.py
   tests/test_economics_2024_profile.py -vv` passed **10/10**. This includes
   the actual production `CroppingEngine` /21 crop check, restrictive synthetic
   OR geometry, ER Q1 source-band controls, and exact-year-profile selection.
   The complete current suite then passed **344 passed, 46 skipped, 5 warnings,
   51 subtests passed**. The refreshed lock-proof readback also passed with its
   15-module masthead.

| Path | SHA-256 | Note |
|---|---|---|
| `core/question_split.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | Amendment 14 source-coordinate standalone-OR boundary; QP triplet is identical |
| `core/cropping_engine_reference.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | Amendment 14 QP triplet peer |
| `original_reference/cambridge_qb/question_split.py` | `533a26d4159a3bb29a749a93a319e1b53e2a09744d52b420e03966ceadf0c497` | production-imported QP triplet peer |
| `tests/test_9708_crop_remediation.py` | `4bc0b837662730ba809539d0016e2366ca6705e3bee3dffd27dbcb8095839f9e` | actual /21 and restrictive standalone-OR regressions (7 tests) |
| `tests/test_economics_2024_profile.py` | `8e579be07e320b11040a00a4cbabebcfbde6afa6a414d40491a543a1481d1b34` | exact historical-profile and AS-paper-scope checks (3 tests) |
| `tools/run_proof.py` | `95663b7a808fb7dbc6871fb992d3639a4848b047a597dedebd9d14c8917ce70e` | proof limitation updated to Amendment 13–14 / current triplet pin |
| `tests/test_proof_report.py` | `9aecac0f82a6a7b2b8d36b6d07fc2faa0da44415157192b35ea1250adfaf1d06` | proof-report expected current QP triplet pin |

---

## 2026-08-29 — Accounting 9706/32 terminal-Q3 completion and final crop freeze

### CROPPING STATUS: 🔒 LOCKED

This entry supersedes the historical Q3-failure wording in the preceding
cross-paper audit record. The actual fault was an ER source-boundary fallback,
not a UI issue: an otherwise unbounded final Q3 on a fresh final scoped page
was carried to the conservative near-footer limit. `core/er_question_crops.py`
now tightens only that final fresh-page/first-header/no-delimiter shape, after
proving the discarded source tail is text-only (no image or vector content).
The unchanged shared-page final-question control is Economics 9708/21 ER Q5,
which remains `2280×1996`.

The actual Accounting Q3 output changed `2280×2826` → `2280×934`; its largest
interior/trailing all-white run changed `1874px` → `56px`. Full commentary is
retained through “information in the question”; no Question 4, standalone OR,
Section B, copyright/footer, or unnecessary blank tail survives. The fresh
Accounting QP+MS+Insert+ER guarded run (38 checks) and fresh Economics /21
regression run (41 checks) are all green; each archive's final validation has
`errors=0`; focused tests are 12/12. The Accounting proof and machine-readable
audit are `validation_evidence/accounting_9706_s23_32_or_crosspaper/proof_9706_s23_32_crosspaper.html`
and `crosspaper_audit_9706_s23_32.json`.

The QP standalone-OR rule remains the narrowly source-coordinate rule from
Amendment 14. All QP/MS/ER/Insert crop mechanisms, question-boundary and page
logic, coordinates, padding, whitespace, footer/copyright, Section-B,
standalone-OR, multi-page, renderer, and WebP behavior are now frozen. Do not
modify/refactor/optimise/replace any of them without explicit user permission.

| Path | SHA-256 | Note |
|---|---|---|
| `core/er_question_crops.py` | `e34ff53b9e73d5508bfc22c04d52022f1551f89848c836e61a12d9cbfa115347` | final locked ER source-boundary implementation |
| `tests/test_9708_crop_remediation.py` | `254dad864ae261a2ac822dad5cbac347c2b0da722c3f18dc611acf553e6aa54f` | 9 focused crop regressions, including Accounting Q3/vector-tail and /21 Q5 preservation |

## Amendment EA-23 (2026-08-29) — bounded indexed classification-memory retrieval

Authorised classification-only work adds an SQLite `(subject, token, record)`
inverted index rather than loading all historical examples into every
classifier. The current authentic/source-grounded validation and synthetic
10,000-record benchmark are documented in `SPECIFICATION_FOR_AI_AGENT.txt`
Section 14.22. This does not change crop code, `metadata.json`, output WebP
writing, or the separate variant-scoped duplicate detector.

| File | SHA-256 | Note |
|---|---|---|
| `core/classifier.py` | `ee6b6aa20f31bfb0f92f1723e5ec68cd03e06fd7b1cd852771133dd3a03a9260` | direct evidence hierarchy + bounded memory/MS support |
| `run_guarded.py` | `8368f066895643f45f074a00e38a2e368eae3e9a8a482e56563bc32e23ab312b` | read-only MS index, audit, post-completion write buffer |
| `main.py` | `d96c90d686ba53d8b9e8d92d9cd0360d7a54bfa7488f4d7715d64624b403c2bb` | guarded production CLI forwarding only |
| `core/classification_memory.py` | `c72a4cbdee85d82c611e6c1e02111b2c405337756dbc76613a409749ccf48392` | new indexed SQLite implementation |
| `core/mark_scheme_evidence.py` | `0b80eb01143b45ffbd250da916ac3ae1b8c58cb6c7b8d89eefa996c59e83181b` | read-only source-PDF evidence index |
| `tools/benchmark_classification_memory.py` | `d9c76618fec1ae583842bfc00537b6804907039fdc59574de73ef085ed5042ee` | repeatable bounded-retrieval timing fixture |



## 2026-08-29 — Classification-memory completion: profile-aware audit and scoped retrieval

This audit amendment records classification-only changes made after the authentic
Business 9609/31 QP+MS+Insert+ER validation. No crop, image-rendering, QP/MS/ER/
Insert splitting, or `metadata.json` implementation changed.

- Historical final validation now resolves the metadata-declared yearly syllabus
  profile rather than testing 2024 output against a root/current profile.
- Exact official detailed Paper-3/Paper-4 scope is applied before scoring,
  bounded memory retrieval, and fallback when a profile declares it. This
  reduces irrelevant candidates rather than scanning the full detailed taxonomy,
  while legacy profiles with no scope preserve existing behaviour.
- Configuration validation catches malformed detailed paper scope before a run.
- The authentic 9609/31 run passed S0–S8 with five saved bundles, source raw-MS
  evidence for all five questions, Insert and ER processing, and final audit
  errors=0. Focused memory regressions: 16 passed.

| File | SHA-256 | Status |
|---|---|---|
| `core/classifier.py` | `d0329e9da0c57138aa96ed054753b90545c02e2ce7d8627f5a1e5a55407709ef` | detailed-scope filtering and bounded retrieval/fallback support |
| `core/config_loader.py` | `8cd3a8758610bd589e0f5922ef706d43b663de91cb2891ca12a18f1908d0d64f` | optional detailed-paper-scope validation |
| `core/validation.py` | `9a0a236fbd1941700ce2761cb318a9d2fba944e15c1e1540d383f261d07c2f64` | metadata-driven historical-profile lookup only |
| `core/mark_scheme_evidence.py` | `ae05260d09dd4459e0a6ea936bcb3feab24b1a59bba8bae3ef99d7bf26d3ebe6` | read-only bounded raw-MS whole-question indexing |


## 2026-08-29 — classification-memory procedure-version gate

The exact detailed-scope procedure is now versioned as
`topic-classifier/2026-08-29-memory-2`. Bounded indexed retrieval filters this
version in addition to taxonomy and syllabus provenance, so stale records do
not influence a newer classifier until explicitly reviewed/reclassified. The
change adds one indexed SQL equality predicate and no archive scan. Focused
regression: 17 passed; authentic 9609/22 memory functional run and 9609/31
QP+MS+Insert+ER guarded S0–S8 run both passed. Crop and metadata implementations
remain untouched.

| File | SHA-256 | Status |
|---|---|---|
| `core/classifier.py` | `a6c1d4e5b8bb4ec5d17c4023c55fa3dba8779b8249d365279d2f6b93168cac33` | procedure-version propagation to bounded retrieval |
| `core/classification_memory.py` | `1ea12e6382563f0480813c0f251292a403140f8d715ca8d6eb00be8b7974f9aa` | indexed classifier-version equality gate |
| `core/config_loader.py` | `8cd3a8758610bd589e0f5922ef706d43b663de91cb2891ca12a18f1908d0d64f` | optional detailed-paper-scope validation |
| `core/validation.py` | `9a0a236fbd1941700ce2761cb318a9d2fba944e15c1e1540d383f261d07c2f64` | metadata-driven historical-profile lookup only |
| `core/mark_scheme_evidence.py` | `ae05260d09dd4459e0a6ea936bcb3feab24b1a59bba8bae3ef99d7bf26d3ebe6` | read-only raw-MS whole-question indexing |


## 2026-08-29 — Economics 9708 exact-year profile restoration (readiness closure)

The documented 2023–2025 Economics 9708 child profile for 2024 was missing
from the working tree. It was restored from the retained official syllabus
source, with the existing compatible taxonomy/operational vocabulary retained
and the source-backed 1/2 AS and 3/4 A-Level paper scopes declared. This is a
configuration/classification readiness repair only: it adds no archive-wide
work, no new retrieval path, no crop or image operation, and no
`metadata.json` behavior. The regression now also pins the official syllabus
hash and all four paper-major scopes, while proving the root 2026 profile still
wins for modern requests.

| File | SHA-256 | Status |
|---|---|---|
| `tests/test_economics_2024_profile.py` | `c3241f70e11192950b6cd7dd7794860a93b62d1d0c4de95540ef9a8b646998b1` | source-pin, exact-year, AS/A-Level scope, and default-selection regression |
